"""Shared Agent-Gateway WebSocket transport client.

Implements the version-neutral transport state machine:

* WebSocket handshake with ``t.hello`` / ``t.welcome``.
* Server-driven heartbeat (``t.ping`` -> ``t.pong``).
* Ordered ``t.data`` delivery with cumulative ``t.ack``.
* In-memory outbox replay on successful resume.
* Automatic reconnect with backoff for recoverable closes.

Wire-level details such as protocol version, frame parse/encode functions,
close codes, and default limits are supplied by v1/v2 modules through
``TransportWireProtocol``.

The payload carried by ``t.data.payload`` is opaque to this module.
"""

from __future__ import annotations

import asyncio
import contextlib
import errno as _errno
import random
import socket as _socket
import ssl as _ssl
import time
from collections import deque
from collections.abc import AsyncIterator, Awaitable, Callable, Mapping
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import websockets
import websockets.exceptions as ws_exceptions
from loguru import logger

HeadersProvider = Callable[[], Awaitable[Mapping[str, str]]]
UrlProvider = Callable[[], Awaitable[str]]

DEFAULT_DUPLICATE_ABUSE_THRESHOLD = 1024
DEFAULT_DUPLICATE_ABUSE_WINDOW_S = 30.0
_CLOSED_SENTINEL = object()
# RFC 6455 reserves 1006 for the client to report an abnormal close when no
# close frame was received. It usually means a transient network/proxy/server
# drop and should not kill the reconnect loop.
RECOVERABLE_WEBSOCKET_CLOSE_CODE_VALUES = frozenset({1006})
MAX_CONSECUTIVE_AUTH_FAILURES = 3


# OSError subclasses (besides ``ConnectionError`` / ``TimeoutError`` /
# ``socket.gaierror`` / ``socket.herror`` which are unambiguous) that are
# explicitly network-layer failures. Everything else that's only a generic
# ``OSError`` must additionally match :data:`_TRANSIENT_NETWORK_ERRNOS`.
_TRANSIENT_NETWORK_EXC_TYPES: tuple[type[BaseException], ...] = (
    _socket.gaierror,
    _socket.herror,
    ConnectionError,
    TimeoutError,
)

# ``errno`` codes that mean 'network/host/socket is currently unavailable'.
# Restricted to genuinely transient failures so callers can safely retry.
# Notably excludes ``ENOENT`` / ``EACCES`` / ``EISDIR`` / ``EEXIST``
# (filesystem) and SSL-cert validation (which uses ``ssl.SSLError`` /
# ``ssl.SSLCertVerificationError`` \u2014 not transient and must surface).
_TRANSIENT_NETWORK_ERRNOS: frozenset[int] = frozenset(
    value
    for value in (
        getattr(_errno, name, None)
        for name in (
            "ECONNREFUSED",
            "ECONNRESET",
            "ECONNABORTED",
            "EHOSTUNREACH",
            "EHOSTDOWN",
            "ENETUNREACH",
            "ENETRESET",
            "ENETDOWN",
            "ENOTCONN",
            "EPIPE",
            "ETIMEDOUT",
            "EAGAIN",
            "EWOULDBLOCK",
        )
    )
    if isinstance(value, int)
)


def _is_transient_network_error(exc: BaseException) -> bool:
    """Return True if ``exc`` (or anything in its ``__cause__`` /
    ``__context__`` chain) is a network-layer failure that should retry.

    Used to distinguish ``url_provider`` / ``headers_provider`` failures
    that should be retried indefinitely (DNS lookup blip, connection
    refused, network unreachable, socket timeout) from genuine auth /
    config / TLS failures (revoked token, malformed cache, expired cert)
    that should count toward ``MAX_CONSECUTIVE_AUTH_FAILURES`` and
    eventually fatal-exit.

    Match strategy:

    1. **First pass**: scan the full cause / context chain for any
       :class:`ssl.SSLError`. Cert validation / handshake / verify
       failures are auth-class problems and must surface promptly, even
       when a third-party HTTP client wraps them in a ``ConnectError``
       (which would otherwise hit the module-name fast path below).
       Found anywhere in the chain \u2192 return ``False`` immediately.
    2. **Second pass** (only reached when the chain is SSL-free):
       per-node classification.

       * Explicit network exception classes
         (:data:`_TRANSIENT_NETWORK_EXC_TYPES`) \u2014
         :class:`socket.gaierror`, :class:`socket.herror`,
         :class:`ConnectionError`, :class:`TimeoutError`.
       * Bare :class:`OSError` whose ``errno`` is in
         :data:`_TRANSIENT_NETWORK_ERRNOS`. ``OSError`` is intentionally
         NOT a blanket accept: it also covers
         :class:`FileNotFoundError`, :class:`PermissionError`, etc.,
         which are real configuration bugs.
       * Third-party HTTP clients matched by ``type(exc).__module__`` so
         we handle :class:`httpx.ConnectError` /
         :class:`httpx.ConnectTimeout` / :class:`httpx.NetworkError` and
         :mod:`aiohttp`'s ``ClientConnector*`` / ``ClientConnectionError``
         / ``*Timeout*`` exceptions without requiring those packages to
         be importable.
    """
    # Visit ``exc`` plus every exception reachable through ``__cause__``
    # *and* ``__context__`` (DFS, cycle-safe). A raise inside ``except``
    # can produce a node where both attrs point at different exceptions
    # (e.g. ``raise NewError("...") from cleanup_err`` inside
    # ``except SSLError``: ``__cause__ = cleanup_err``,
    # ``__context__ = ssl_err``), so we have to follow both edges or
    # an SSL veto / transient match on the unfollowed branch is missed.
    seen: set[int] = set()
    chain: list[BaseException] = []
    stack: list[BaseException] = [exc]
    while stack:
        node = stack.pop()
        if id(node) in seen:
            continue
        seen.add(id(node))
        chain.append(node)
        if node.__cause__ is not None:
            stack.append(node.__cause__)
        if node.__context__ is not None:
            stack.append(node.__context__)

    # ── Pass 1: SSL anywhere in the chain disqualifies retry ────────────
    for node in chain:
        if isinstance(node, _ssl.SSLError):
            return False

    # ── Pass 2: classify the chain as transient if any node matches ─────
    for node in chain:
        # Explicit network exception classes.
        if isinstance(node, _TRANSIENT_NETWORK_EXC_TYPES):
            return True

        # Bare ``OSError`` only counts when ``errno`` is on the allow-list.
        # This is the branch that filters out ``FileNotFoundError``
        # (``ENOENT``), ``PermissionError`` (``EACCES``), ``IsADirectoryError``
        # (``EISDIR``), ``FileExistsError`` (``EEXIST``), etc.
        if (
            isinstance(node, OSError)
            and node.errno is not None
            and node.errno in _TRANSIENT_NETWORK_ERRNOS
        ):
            return True

        # Third-party HTTP clients \u2014 keyed by module path so the
        # transport stays free of httpx / aiohttp imports.
        mod = type(node).__module__
        name = type(node).__qualname__
        if mod.startswith("httpx") and (
            "Connect" in name or "Timeout" in name or "Network" in name
        ):
            return True
        if mod.startswith("aiohttp") and (
            "Connector" in name or "Connection" in name or "Timeout" in name
        ):
            return True

    return False


def _invalid_status_code(exc: BaseException) -> int | None:
    """Return the HTTP status code from a websockets InvalidStatus error."""

    response = getattr(exc, "response", None)
    status_code = getattr(response, "status_code", None)
    return status_code if isinstance(status_code, int) else None


@dataclass(frozen=True)
class TransportCloseCodes:
    normal: int
    authentication_failed: int
    server_internal_error: int
    protocol_error: int
    sequence_error: int
    payload_too_large: int
    heartbeat_timeout: int
    superseded: int
    resume_rejected: int
    version_unsupported: int


@dataclass(frozen=True)
class TransportWireProtocol:
    name: str
    protocol_version: int
    close_codes: TransportCloseCodes
    default_ping_interval_ms: int
    default_pong_timeout_ms: int
    default_resume_ttl_ms: int
    default_max_payload_bytes: int
    default_max_outbox_bytes: int
    recoverable_close_codes: frozenset[int]
    error_code_close_codes: Mapping[str, int]
    parse_frame: Callable[[str | bytes], dict[str, Any]]
    encode_frame: Callable[[Mapping[str, Any]], str]
    encoded_json_size: Callable[[Any], int]


class TransportState(str, Enum):
    """Client send-pump state."""

    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    REPLAYING = "replaying"
    LIVE = "live"
    CLOSING = "closing"
    CLOSED = "closed"


@dataclass(frozen=True)
class TransportEvent:
    """Coarse transport lifecycle event exposed to upper layers."""

    kind: str
    session_id: str | None = None
    prior_session_id: str | None = None
    connection_epoch: int | None = None
    reason: str | None = None
    resumed: bool | None = None


class TransportError(Exception):
    """Raised when a transport frame or state transition violates the protocol."""

    def __init__(self, code: int, reason: str) -> None:
        super().__init__(reason)
        self.code = int(code)
        self.reason = reason


class TransportClosedError(TransportError):
    """Raised when using a closed transport."""

    def __init__(self, reason: str = "transport is closed") -> None:
        super().__init__(1000, reason)


class PayloadTooLargeError(TransportError):
    """Raised when an outbound payload exceeds the negotiated limit."""

    def __init__(self, size: int, limit: int, code: int) -> None:
        super().__init__(code, f"payload size {size} exceeds {limit}")
        self.size = size
        self.limit = limit


class TransportDisconnectedBackpressureError(TransportError):
    """Raised when disconnected sends would exceed the local soft cap."""

    def __init__(self, size: int, limit: int, code: int) -> None:
        super().__init__(
            code,
            f"disconnected outbox size {size} exceeds soft cap {limit}",
        )
        self.size = size
        self.limit = limit


@dataclass
class TransportClientConfig:
    """Configuration for :class:`GatewayTransportClient`."""

    url: str
    wire_protocol: TransportWireProtocol | None = None
    url_provider: UrlProvider | None = None
    headers: Mapping[str, str] = field(default_factory=dict)
    headers_provider: HeadersProvider | None = None
    """Optional async callable invoked before each connect attempt.

    When set, its return value REPLACES :attr:`headers` for that attempt.
    Use this to refresh short-lived bearer tokens across reconnects. The
    provider must be safe to call from the reconnect loop.
    """
    protocol_version: int | None = None
    min_protocol_version: int | None = None
    features: tuple[str, ...] = ("resume", "ack", "server_ping")
    connect_timeout_s: float = 15.0
    handshake_timeout_s: float = 30.0
    close_timeout_s: float = 5.0
    reconnect_initial_delay_s: float = 1.0
    reconnect_max_delay_s: float = 10.0
    ack_delay_s: float = 1.0
    ack_frame_threshold: int = 32
    ack_byte_threshold: int = 256 * 1024
    receive_queue_size: int = 100
    max_payload_bytes: int | None = None
    max_outbox_bytes: int | None = None
    disconnected_outbox_soft_cap_bytes: int | None = None
    max_disconnected_duration_s: float | None = None
    happy_eyeballs_delay: float = 0.25
    interleave: int = 1
    websocket_ping_interval_s: float | None = None
    websocket_ping_timeout_s: float | None = None


@dataclass
class _OutboxEntry:
    seq: int
    frame_text: str
    byte_len: int
    sent_epoch: int | None = None


def _require_uint(
    frame: Mapping[str, Any],
    field_name: str,
    *,
    code: int,
    minimum: int = 0,
) -> int:
    value = frame.get(field_name)
    if not isinstance(value, int) or isinstance(value, bool) or value < minimum:
        raise TransportError(code, f"{field_name} must be uint >= {minimum}")
    return value


class GatewayTransportClient:
    """Standalone agent-side client for the Gateway transport protocol."""

    wire_protocol: TransportWireProtocol | None = None

    def __init__(self, config: TransportClientConfig) -> None:
        self.config = config
        wire = config.wire_protocol or self.wire_protocol
        if wire is None:
            raise ValueError(
                "TransportClientConfig.wire_protocol is required when using "
                "GatewayTransportClient directly"
            )
        self._wire: TransportWireProtocol = wire
        self._close_codes = self._wire.close_codes

        self._state = TransportState.DISCONNECTED
        self._session_id: str | None = None
        self._session_token: str | None = None
        self._connection_epoch = 0
        self._features: frozenset[str] = frozenset()
        self._max_payload_bytes = config.max_payload_bytes or self._wire.default_max_payload_bytes
        self._max_outbox_bytes = config.max_outbox_bytes or self._wire.default_max_outbox_bytes
        self._ping_interval_s = self._wire.default_ping_interval_ms / 1000
        self._pong_timeout_s = self._wire.default_pong_timeout_ms / 1000
        self._resume_ttl_s = self._wire.default_resume_ttl_ms / 1000

        self._next_outgoing_seq = 1
        self._delivered_next_seq = 1
        self._pending_ack_seq = 0
        self._last_sent_ack_seq = 0

        self._outbox: deque[_OutboxEntry] = deque()
        self._outbox_bytes = 0
        self._cv = asyncio.Condition()
        self._send_lock = asyncio.Lock()
        self._recv_queue: asyncio.Queue[Any] = asyncio.Queue(maxsize=config.receive_queue_size)
        self._event_queue: asyncio.Queue[TransportEvent] = asyncio.Queue(maxsize=100)

        self._runner_task: asyncio.Task[None] | None = None
        self._ack_timer_task: asyncio.Task[None] | None = None
        self._ws: Any = None
        self._close_requested = False
        self._accepting_sends = True
        self._connected_event = asyncio.Event()
        self._last_frame_at = time.monotonic()
        self._ack_frames_since_flush = 0
        self._ack_bytes_since_flush = 0
        self._last_welcome_resumed: bool | None = None
        self._disconnected_since: float | None = None
        self._duplicate_run_count = 0
        self._duplicate_run_started_at: float | None = None

    @property
    def state(self) -> TransportState:
        return self._state

    @property
    def session_id(self) -> str | None:
        return self._session_id

    @property
    def connection_epoch(self) -> int:
        return self._connection_epoch

    @property
    def last_received_seq(self) -> int:
        """Largest Gateway->agent sequence delivered to the receive queue."""

        return self._delivered_next_seq - 1

    @property
    def next_outgoing_seq(self) -> int:
        return self._next_outgoing_seq

    @property
    def outbox_bytes(self) -> int:
        return self._outbox_bytes

    @property
    def outbox_size(self) -> int:
        return len(self._outbox)

    @property
    def negotiated_features(self) -> frozenset[str]:
        return self._features

    @property
    def last_welcome_resumed(self) -> bool | None:
        return self._last_welcome_resumed

    async def start(self) -> None:
        """Start the reconnect loop."""

        if self._runner_task and not self._runner_task.done():
            return
        self._close_requested = False
        self._accepting_sends = True
        self._runner_task = asyncio.create_task(self._run_loop(), name="gateway-transport-client")

    async def wait_connected(self, timeout: float | None = None) -> None:
        """Wait until the current WebSocket has completed transport negotiation."""

        await asyncio.wait_for(self._connected_event.wait(), timeout=timeout)

    async def send(self, payload: Any) -> int:
        """Append an opaque business payload to the ordered transport outbox."""

        if not self._accepting_sends or self._state in {
            TransportState.CLOSING,
            TransportState.CLOSED,
        }:
            raise TransportClosedError()

        payload_size = self._json_size(payload)
        if payload_size > self._max_payload_bytes:
            raise PayloadTooLargeError(
                payload_size,
                self._max_payload_bytes,
                self._close_codes.payload_too_large,
            )

        async with self._cv:
            seq = self._next_outgoing_seq
            frame_text = self._encode_frame({"type": "t.data", "seq": seq, "payload": payload})
            frame_size = len(frame_text.encode("utf-8"))
            outbox_limit = self._outbox_limit_for_current_state()
            if (
                self._state in {TransportState.DISCONNECTED, TransportState.CONNECTING}
                and self._outbox_bytes + frame_size > outbox_limit
            ):
                raise TransportDisconnectedBackpressureError(
                    self._outbox_bytes + frame_size,
                    outbox_limit,
                    self._close_codes.server_internal_error,
                )
            while self._outbox_bytes + frame_size > outbox_limit:
                if not self._accepting_sends:
                    raise TransportClosedError()
                await self._cv.wait()

            self._next_outgoing_seq += 1
            self._outbox.append(_OutboxEntry(seq=seq, frame_text=frame_text, byte_len=frame_size))
            self._outbox_bytes += frame_size
            self._cv.notify_all()
            return seq

    async def receive(self) -> Any:
        """Receive a single opaque business payload."""

        item = await self._recv_queue.get()
        if item is _CLOSED_SENTINEL:
            raise TransportClosedError()
        return item

    async def recv(self) -> AsyncIterator[Any]:
        """Yield opaque business payloads in transport order."""

        while True:
            item = await self._recv_queue.get()
            if item is _CLOSED_SENTINEL:
                break
            yield item

    async def events(self) -> AsyncIterator[TransportEvent]:
        """Yield coarse lifecycle events for upper layers."""

        while True:
            yield await self._event_queue.get()

    async def close(self, *, graceful: bool = True, timeout: float = 5.0) -> None:
        """Stop the client and close the current transport session."""

        self._close_requested = True
        self._accepting_sends = False
        self._state = TransportState.CLOSING
        async with self._cv:
            self._cv.notify_all()

        try:
            if graceful and self._ws is not None:
                with contextlib.suppress(Exception):
                    await asyncio.wait_for(
                        self._close_websocket_gracefully(timeout), timeout=timeout
                    )
        finally:
            if self._runner_task:
                self._runner_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await self._runner_task
            if self._ack_timer_task:
                self._ack_timer_task.cancel()
                self._ack_timer_task = None
            self._session_token = None
            self._session_id = None
            self._reset_fresh_session()
            self._state = TransportState.CLOSED
            await self._put_closed_sentinel()

    async def _close_websocket_gracefully(self, timeout: float) -> None:
        deadline = time.monotonic() + timeout
        async with self._cv:
            while self._outbox and time.monotonic() < deadline:
                remaining = max(0.0, deadline - time.monotonic())
                with contextlib.suppress(TimeoutError):
                    await asyncio.wait_for(self._cv.wait(), timeout=remaining)
                    continue
                break
        remaining = max(0.0, deadline - time.monotonic())
        if remaining <= 0:
            logger.debug("transport: graceful close timed out waiting for outbox")
            return
        await asyncio.wait_for(self._flush_ack(), timeout=remaining)
        remaining = max(0.0, deadline - time.monotonic())
        if remaining <= 0:
            logger.debug("transport: graceful close timed out before t.close")
            return
        await asyncio.wait_for(
            self._send_frame(
                {"type": "t.close", "code": self._close_codes.normal, "reason": "closing"}
            ),
            timeout=remaining,
        )
        remaining = max(0.0, deadline - time.monotonic())
        if remaining <= 0:
            logger.debug("transport: graceful close timed out before websocket close")
            return
        await asyncio.wait_for(
            self._ws.close(code=self._close_codes.normal, reason="closing"),
            timeout=remaining,
        )

    async def _run_loop(self) -> None:
        delay = self.config.reconnect_initial_delay_s
        consecutive_auth_failures = 0
        attempt = 0
        logger.info(
            "transport: reconnect loop starting url={}",
            self.config.url,
        )
        exit_reason = "normal"
        try:
            await self._reconnect_loop_body(delay, consecutive_auth_failures, attempt)
        except asyncio.CancelledError:
            exit_reason = "cancelled"
            raise
        except BaseException as exc:  # noqa: BLE001 - log then re-raise
            exit_reason = f"unhandled:{type(exc).__name__}"
            raise
        finally:
            # Fatal exits still need to be loud because the channel will not
            # recover by itself. Task cancellation during process shutdown is
            # normal, though: on Ctrl+C asyncio may cancel child tasks before
            # CloudChannel.stop() has set _close_requested.
            log = logger.critical
            if exit_reason == "cancelled" or self._close_requested:
                log = logger.debug
            log(
                "transport: reconnect loop exited — no further reconnect will happen "
                "(reason={} close_requested={} state={} session={})",
                exit_reason,
                self._close_requested,
                self._state.value if hasattr(self._state, "value") else self._state,
                self._session_id,
            )

    async def _reconnect_loop_body(
        self,
        delay: float,
        consecutive_auth_failures: int,
        attempt: int,
    ) -> None:
        while not self._close_requested:
            attempt += 1
            attempt_started_at = time.monotonic()
            try:
                await self._run_connection(attempt=attempt)
                # Only reset backoff if the connection stayed up long enough
                # to count as stable; otherwise the next iteration grows the
                # delay (avoid hot reconnect loops on flapping handshakes).
                if time.monotonic() - attempt_started_at >= 30.0:
                    delay = self.config.reconnect_initial_delay_s
                consecutive_auth_failures = 0
            except asyncio.CancelledError:
                raise
            except TransportClosedError as exc:
                logger.info(
                    "transport: closed gracefully session={} reason={}",
                    self._session_id,
                    exc.reason,
                )
                self._session_token = None
                self._emit_event_nowait(
                    TransportEvent(
                        kind="closed",
                        session_id=self._session_id,
                        connection_epoch=self._connection_epoch or None,
                        reason=exc.reason,
                    )
                )
                self._state = TransportState.CLOSED
                await self._put_closed_sentinel()
                return
            except TransportError as exc:
                await self._emit_event("error", reason=exc.reason)
                if exc.code == self._close_codes.authentication_failed:
                    consecutive_auth_failures += 1
                    self._invalidate_url_provider()
                else:
                    consecutive_auth_failures = 0
                fatal = exc.code not in self._wire.recoverable_close_codes or (
                    exc.code == self._close_codes.authentication_failed
                    and consecutive_auth_failures >= MAX_CONSECUTIVE_AUTH_FAILURES
                )
                logger.log(
                    "ERROR" if fatal else "WARNING",
                    "transport: error code={} reason={} fatal={} auth_failures={} attempt={}",
                    exc.code,
                    exc.reason,
                    fatal,
                    consecutive_auth_failures,
                    attempt,
                )
                if fatal:
                    self._invalidate_url_provider()
                    self._session_token = None
                    self._emit_event_nowait(
                        TransportEvent(
                            kind="closed",
                            session_id=self._session_id,
                            connection_epoch=self._connection_epoch or None,
                            reason=exc.reason,
                        )
                    )
                    self._state = TransportState.CLOSED
                    await self._put_closed_sentinel()
                    return
            except ws_exceptions.ConnectionClosed as exc:
                code = getattr(exc, "code", None)
                reason = getattr(exc, "reason", None) or None
                # Surface the server-provided close reason so upper layers
                # don't lose it. Format: "<code>:<reason>" when both, else
                # whichever exists, else None.
                event_reason: str | None
                if reason and code:
                    event_reason = f"{code}:{reason}"
                elif reason:
                    event_reason = reason
                elif code:
                    event_reason = str(code)
                else:
                    event_reason = None
                await self._emit_event("disconnected", reason=event_reason)
                if code == self._close_codes.authentication_failed:
                    consecutive_auth_failures += 1
                    self._invalidate_url_provider()
                else:
                    consecutive_auth_failures = 0
                recoverable_websocket_close_codes = (
                    self._wire.recoverable_close_codes | RECOVERABLE_WEBSOCKET_CLOSE_CODE_VALUES
                )
                fatal = code is not None and (
                    code not in recoverable_websocket_close_codes
                    or (
                        code == self._close_codes.authentication_failed
                        and consecutive_auth_failures >= MAX_CONSECUTIVE_AUTH_FAILURES
                    )
                )
                logger.log(
                    "ERROR" if fatal else "WARNING",
                    "transport: ws closed code={} reason={!r} fatal={} attempt={}",
                    code,
                    reason,
                    fatal,
                    attempt,
                )
                if fatal:
                    self._invalidate_url_provider()
                    self._session_token = None
                    self._emit_event_nowait(
                        TransportEvent(
                            kind="closed",
                            session_id=self._session_id,
                            connection_epoch=self._connection_epoch or None,
                            reason=event_reason,
                        )
                    )
                    self._state = TransportState.CLOSED
                    await self._put_closed_sentinel()
                    return
            except ws_exceptions.InvalidStatus as exc:
                status_code = _invalid_status_code(exc)
                reason = f"websocket handshake rejected: HTTP {status_code or '?'}"
                await self._emit_event("disconnected", reason=reason)

                auth_like = status_code in {401, 403}
                if auth_like:
                    # AWPS client URLs are bearer credentials. A 401/403 at
                    # the websocket handshake means the cached client URL (or
                    # auth material behind it) is no longer acceptable even if
                    # the provider's local expires_at says it should still be
                    # valid. Invalidate so the next attempt negotiates a fresh
                    # URL instead of burning the full resume window replaying
                    # the same rejected URL. See issue #350.
                    consecutive_auth_failures += 1
                    self._invalidate_url_provider()
                else:
                    consecutive_auth_failures = 0

                fatal = auth_like and consecutive_auth_failures >= MAX_CONSECUTIVE_AUTH_FAILURES
                logger.log(
                    "ERROR" if fatal else "WARNING",
                    "transport: websocket handshake rejected status={} fatal={} "
                    "auth_failures={} attempt={}",
                    status_code,
                    fatal,
                    consecutive_auth_failures,
                    attempt,
                )
                if fatal:
                    self._session_token = None
                    self._emit_event_nowait(
                        TransportEvent(
                            kind="closed",
                            session_id=self._session_id,
                            connection_epoch=self._connection_epoch or None,
                            reason=reason,
                        )
                    )
                    self._state = TransportState.CLOSED
                    await self._put_closed_sentinel()
                    return
            except Exception as exc:
                logger.exception(
                    "transport: unexpected error during connection attempt={}: {}",
                    attempt,
                    exc,
                )
                await self._emit_event("disconnected", reason=str(exc))

            self._connected_event.clear()
            self._ws = None
            self._state = TransportState.DISCONNECTED
            if self._close_requested:
                break
            if self._disconnected_since is None:
                self._disconnected_since = time.monotonic()
            max_disconnected_s = self._max_disconnected_duration_s()
            elapsed_disconnected_s = time.monotonic() - self._disconnected_since
            if elapsed_disconnected_s >= max_disconnected_s:
                prior_session_id = self._session_id
                logger.error(
                    "transport: resume window exceeded ({:.0f}s >= {:.0f}s) — giving up session={}",
                    elapsed_disconnected_s,
                    max_disconnected_s,
                    prior_session_id,
                )
                self._session_token = None
                self._reset_fresh_session()
                self._emit_event_nowait(
                    TransportEvent(
                        kind="resume_failed",
                        prior_session_id=prior_session_id,
                        session_id=None,
                        reason="max_disconnected_duration",
                        resumed=False,
                    )
                )
                self._state = TransportState.CLOSED
                await self._put_closed_sentinel()
                return
            jittered = delay + random.uniform(0, delay * 0.25)  # noqa: S311 - reconnect jitter only
            sleep_for = min(jittered, max_disconnected_s - elapsed_disconnected_s)
            logger.info(
                "transport: reconnect in {:.1f}s (attempt={} disconnected_for={:.0f}s)",
                sleep_for,
                attempt + 1,
                elapsed_disconnected_s,
            )
            await asyncio.sleep(sleep_for)
            delay = min(delay * 2, self.config.reconnect_max_delay_s)

        self._state = TransportState.CLOSED
        await self._put_closed_sentinel()

    async def _run_connection(self, *, attempt: int = 0) -> None:
        self._state = TransportState.CONNECTING
        attempted_resume = self._session_token is not None
        if self.config.url_provider is not None:
            try:
                url = await self.config.url_provider()
            except Exception as exc:  # noqa: BLE001 - surface to reconnect loop
                if _is_transient_network_error(exc):
                    logger.warning(
                        "transport: url_provider hit transient network error "
                        "(treated as recoverable, not auth): {}",
                        exc,
                    )
                    raise TransportError(
                        self._close_codes.server_internal_error,
                        f"url_provider network error: {exc}",
                    ) from exc
                raise TransportError(
                    self._close_codes.authentication_failed,
                    f"url_provider failed: {exc}",
                ) from exc
        else:
            url = self.config.url
        logger.info(
            "transport: connecting attempt={} resume={} prior_session={}",
            attempt,
            attempted_resume,
            self._session_id if attempted_resume else None,
        )
        if self.config.headers_provider is not None:
            try:
                provided = await self.config.headers_provider()
            except Exception as exc:  # noqa: BLE001 - surface to reconnect loop
                if _is_transient_network_error(exc):
                    logger.warning(
                        "transport: headers_provider hit transient network error "
                        "(treated as recoverable, not auth): {}",
                        exc,
                    )
                    raise TransportError(
                        self._close_codes.server_internal_error,
                        f"headers_provider network error: {exc}",
                    ) from exc
                logger.warning(
                    "transport: headers_provider failed (treated as auth failure): {}",
                    exc,
                )
                raise TransportError(
                    self._close_codes.authentication_failed,
                    f"headers_provider failed: {exc}",
                ) from exc
            headers = dict(provided)
        else:
            headers = dict(self.config.headers)

        async with websockets.connect(
            url,
            additional_headers=headers,
            ping_interval=self.config.websocket_ping_interval_s,
            ping_timeout=self.config.websocket_ping_timeout_s,
            open_timeout=self.config.connect_timeout_s,
            close_timeout=self.config.close_timeout_s,
            happy_eyeballs_delay=self.config.happy_eyeballs_delay,
            interleave=self.config.interleave,
        ) as ws:
            self._ws = ws
            self._last_frame_at = time.monotonic()
            logger.info(
                "transport: ws upgraded, sending t.hello session_token={} features={}",
                "present" if self._session_token else "none",
                list(self.config.features),
            )
            await self._send_frame(self._hello_frame())
            welcome = await asyncio.wait_for(
                self._read_welcome(ws), timeout=self.config.handshake_timeout_s
            )
            resumed = self._apply_welcome(welcome, attempted_resume=attempted_resume)
            logger.info(
                "transport: welcome received session={}/{} resumed={} features={}",
                self._session_id,
                self._connection_epoch,
                resumed,
                sorted(self._features),
            )
            self._state = TransportState.REPLAYING if resumed else TransportState.LIVE
            self._connected_event.set()
            self._disconnected_since = None

            reader_task = asyncio.create_task(self._reader(ws), name="gateway-transport-reader")
            pump_task = asyncio.create_task(
                self._send_pump(ws, replay=resumed), name="gateway-transport-pump"
            )
            tasks = {reader_task, pump_task}
            idle_task: asyncio.Task[None] | None = None
            if "server_ping" in self._features:
                idle_task = asyncio.create_task(
                    self._idle_watchdog(ws), name="gateway-transport-idle"
                )
                tasks.add(idle_task)
            try:
                done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_EXCEPTION)
                for task in pending:
                    task.cancel()
                for task in pending:
                    with contextlib.suppress(asyncio.CancelledError):
                        await task
                for task in done:
                    task.result()
            finally:
                self._connected_event.clear()
                if self._ack_timer_task:
                    self._ack_timer_task.cancel()
                    self._ack_timer_task = None

    def _invalidate_url_provider(self) -> None:
        provider = self.config.url_provider
        invalidate = getattr(provider, "invalidate", None)
        if callable(invalidate):
            invalidate()

    def _protocol_version(self) -> int:
        return self.config.protocol_version or self._wire.protocol_version

    def _parse_frame(self, raw: str | bytes) -> dict[str, Any]:
        return self._wire.parse_frame(raw)

    def _encode_frame(self, frame: Mapping[str, Any]) -> str:
        return self._wire.encode_frame(frame)

    def _json_size(self, value: Any) -> int:
        return self._wire.encoded_json_size(value)

    def _require_uint(
        self,
        frame: Mapping[str, Any],
        field_name: str,
        *,
        minimum: int = 0,
    ) -> int:
        return _require_uint(
            frame,
            field_name,
            code=self._close_codes.protocol_error,
            minimum=minimum,
        )

    def _hello_frame(self) -> dict[str, Any]:
        protocol_version = self._protocol_version()
        frame: dict[str, Any] = {
            "type": "t.hello",
            "protocol_version": protocol_version,
            "features": list(self.config.features),
            "last_received_seq": self.last_received_seq,
        }
        if (
            self.config.min_protocol_version is not None
            and self.config.min_protocol_version != protocol_version
        ):
            frame["min_protocol_version"] = self.config.min_protocol_version
        if self._session_token:
            frame["session_token"] = self._session_token
        return frame

    async def _read_welcome(self, ws: Any) -> dict[str, Any]:
        raw = await ws.recv()
        frame = self._parse_frame(raw)
        if frame["type"] == "t.error":
            code = str(frame.get("code", "transport_error"))
            close_code = self._t_error_close_code(code)
            # On resumable session-state errors, drop the token so the next
            # attempt does a fresh handshake instead of looping on a stale id.
            if code in {"unknown_session", "expired_session", "resume_rejected"}:
                self._session_token = None
                self._reset_fresh_session()
            elif code == "protocol_error" and self._session_token is not None:
                logger.warning(
                    "transport: server rejected resume handshake with protocol_error; "
                    "dropping session and reconnecting fresh session={}",
                    self._session_id,
                )
                self._session_token = None
                self._reset_fresh_session()
                close_code = self._close_codes.resume_rejected
            raise TransportError(close_code, code)
        if frame["type"] != "t.welcome":
            raise TransportError(self._close_codes.protocol_error, "expected t.welcome")
        return frame

    def _t_error_close_code(self, code: str) -> int:
        return self._wire.error_code_close_codes.get(code, self._close_codes.protocol_error)

    def _apply_welcome(self, frame: Mapping[str, Any], *, attempted_resume: bool) -> bool:
        protocol_version = self._require_uint(frame, "protocol_version", minimum=1)
        max_protocol_version = self._protocol_version()
        min_protocol_version = self.config.min_protocol_version or max_protocol_version
        if not (min_protocol_version <= protocol_version <= max_protocol_version):
            raise TransportError(
                self._close_codes.version_unsupported,
                "unsupported protocol version",
            )

        features_value = frame.get("features", [])
        if not isinstance(features_value, list) or not all(
            isinstance(item, str) for item in features_value
        ):
            raise TransportError(self._close_codes.protocol_error, "features must be a string list")
        features = frozenset(features_value)

        session_id = frame.get("session_id")
        session_token = frame.get("session_token")
        if not isinstance(session_id, str) or not session_id:
            raise TransportError(self._close_codes.protocol_error, "session_id is required")
        if not isinstance(session_token, str) or not session_token:
            raise TransportError(self._close_codes.protocol_error, "session_token is required")

        resumed = frame.get("resumed")
        if not isinstance(resumed, bool):
            raise TransportError(self._close_codes.protocol_error, "resumed must be bool")
        if resumed and not attempted_resume:
            raise TransportError(
                self._close_codes.protocol_error,
                "fresh connection cannot be resumed",
            )
        gateway_last_received = self._require_uint(frame, "last_received_seq")
        connection_epoch = self._require_uint(frame, "connection_epoch", minimum=1)

        prior_session_id = self._session_id
        if resumed:
            first_replayable_seq = self._first_unacked_or_next_seq()
            if gateway_last_received < first_replayable_seq - 1:
                reject_reason = "resume_cursor_behind"
                logger.warning(
                    "transport: cannot resume session={} because gateway cursor {} "
                    "is behind first replayable seq {}; reconnecting fresh",
                    prior_session_id,
                    gateway_last_received,
                    first_replayable_seq,
                )
                self._session_token = None
                self._reset_fresh_session()
                self._emit_event_nowait(
                    TransportEvent(
                        kind="resume_failed",
                        session_id=session_id,
                        prior_session_id=prior_session_id,
                        connection_epoch=connection_epoch,
                        reason=reject_reason,
                        resumed=False,
                    )
                )
                raise TransportError(self._close_codes.resume_rejected, reject_reason)
        if attempted_resume and not resumed:
            reason = frame.get("resume_failed_reason")
            self._reset_fresh_session()
            self._emit_event_nowait(
                TransportEvent(
                    kind="resume_failed",
                    session_id=session_id,
                    prior_session_id=prior_session_id,
                    connection_epoch=connection_epoch,
                    reason=str(reason) if reason is not None else None,
                    resumed=False,
                )
            )
        elif resumed:
            self._trim_outbox_from_peer_ack(gateway_last_received)
            self._emit_event_nowait(
                TransportEvent(
                    kind="resumed",
                    session_id=session_id,
                    connection_epoch=connection_epoch,
                    resumed=True,
                )
            )
        else:
            self._emit_event_nowait(
                TransportEvent(
                    kind="connected",
                    session_id=session_id,
                    connection_epoch=connection_epoch,
                    resumed=False,
                )
            )

        self._session_id = session_id
        self._session_token = session_token
        self._connection_epoch = connection_epoch
        self._features = features
        self._max_payload_bytes = self._require_uint(frame, "max_payload_bytes", minimum=1)
        self._max_outbox_bytes = self._require_uint(frame, "max_outbox_bytes", minimum=1)
        self._ping_interval_s = self._require_uint(frame, "ping_interval_ms", minimum=1) / 1000
        self._pong_timeout_s = self._require_uint(frame, "pong_timeout_ms", minimum=1) / 1000
        resume_ttl_ms = frame.get("resume_ttl_ms")
        if (
            isinstance(resume_ttl_ms, int)
            and not isinstance(resume_ttl_ms, bool)
            and resume_ttl_ms > 0
        ):
            self._resume_ttl_s = resume_ttl_ms / 1000
        self._last_welcome_resumed = resumed
        return resumed

    async def _reader(self, ws: Any) -> None:
        async for raw in ws:
            self._last_frame_at = time.monotonic()
            frame = self._parse_frame(raw)
            frame_type = frame["type"]
            if frame_type == "t.ping":
                logger.info(
                    "transport: received t.ping session={}",
                    self._session_id,
                )
                await self._send_frame({"type": "t.pong"})
            elif frame_type == "t.pong":
                continue
            elif frame_type == "t.ack":
                await self._handle_ack(frame)
            elif frame_type == "t.data":
                await self._handle_data(frame, raw_size=len(str(raw).encode("utf-8")))
            elif frame_type == "t.close":
                self._accepting_sends = False
                self._close_requested = True
                reason = str(frame.get("reason", "peer closed"))
                logger.info(
                    "transport: server sent t.close session={} reason={}",
                    self._session_id,
                    reason,
                )
                await self._flush_ack()
                raise TransportClosedError(reason)
            elif frame_type == "t.error":
                code = str(frame.get("code", "transport_error"))
                logger.warning(
                    "transport: server sent t.error code={} session={}",
                    code,
                    self._session_id,
                )
                if code in {"unknown_session", "expired_session", "resume_rejected"}:
                    self._session_token = None
                    self._reset_fresh_session()
                    raise TransportError(self._t_error_close_code(code), code)
                if code == "protocol_error" and self._last_welcome_resumed:
                    logger.warning(
                        "transport: protocol_error after resume; dropping session and "
                        "reconnecting fresh session={}",
                        self._session_id,
                    )
                    self._session_token = None
                    self._reset_fresh_session()
                    raise TransportError(self._close_codes.resume_rejected, code)
                raise TransportError(self._t_error_close_code(code), code)
            else:
                raise TransportError(self._close_codes.protocol_error, f"unexpected {frame_type}")

        if not self._close_requested:
            logger.warning(
                "transport: ws stream closed without t.close session={}",
                self._session_id,
            )
            raise TransportError(self._close_codes.heartbeat_timeout, "websocket disconnected")

    async def _send_pump(self, ws: Any, *, replay: bool) -> None:
        epoch = self._connection_epoch
        replay_tail_seq = self._outbox[-1].seq if replay and self._outbox else None
        self._state = (
            TransportState.REPLAYING if replay_tail_seq is not None else TransportState.LIVE
        )

        while not self._close_requested:
            async with self._cv:
                entry = self._next_unsent_entry(epoch)
                while entry is None and not self._close_requested:
                    await self._cv.wait()
                    entry = self._next_unsent_entry(epoch)
                if self._close_requested:
                    return

            await self._send_text(entry.frame_text)
            entry.sent_epoch = epoch
            if replay_tail_seq is not None and entry.seq >= replay_tail_seq:
                replay_tail_seq = None
                self._state = TransportState.LIVE

    async def _idle_watchdog(self, ws: Any) -> None:
        if "server_ping" not in self._features:
            await asyncio.Event().wait()
            return
        timeout_s = self._ping_interval_s + self._pong_timeout_s
        while not self._close_requested:
            await asyncio.sleep(min(1.0, timeout_s))
            if time.monotonic() - self._last_frame_at > timeout_s:
                logger.warning(
                    "transport: heartbeat timeout — closing session={} (no inbound frame for {:.0f}s)",
                    self._session_id,
                    time.monotonic() - self._last_frame_at,
                )
                with contextlib.suppress(Exception):
                    await ws.close(
                        code=self._close_codes.heartbeat_timeout,
                        reason="heartbeat timeout",
                    )
                raise TransportError(
                    self._close_codes.heartbeat_timeout,
                    "gateway heartbeat timeout",
                )

    async def _handle_ack(self, frame: Mapping[str, Any]) -> None:
        ack = self._require_uint(frame, "ack")
        async with self._cv:
            if ack >= self._next_outgoing_seq:
                raise TransportError(self._close_codes.sequence_error, "peer acked unsent data")
            first_unacked = self._first_unacked_or_next_seq()
            if ack < first_unacked:
                return
            self._trim_outbox(ack)
            self._cv.notify_all()

    async def _handle_data(self, frame: Mapping[str, Any], *, raw_size: int) -> None:
        seq = self._require_uint(frame, "seq", minimum=1)
        payload = frame.get("payload")
        payload_size = self._json_size(payload)
        if payload_size > self._max_payload_bytes:
            raise PayloadTooLargeError(
                payload_size,
                self._max_payload_bytes,
                self._close_codes.payload_too_large,
            )

        if seq < self._delivered_next_seq:
            self._record_duplicate_data()
            self._pending_ack_seq = max(self._pending_ack_seq, self._delivered_next_seq - 1)
            self._schedule_ack(raw_size=0, count_for_threshold=False)
            return
        if seq > self._delivered_next_seq:
            raise TransportError(self._close_codes.sequence_error, "data sequence gap")

        try:
            self._recv_queue.put_nowait(payload)
        except asyncio.QueueFull:
            raise TransportError(
                self._close_codes.server_internal_error,
                "receive queue overloaded",
            )

        self._delivered_next_seq = seq + 1
        self._duplicate_run_count = 0
        self._duplicate_run_started_at = None
        self._pending_ack_seq = seq
        self._schedule_ack(raw_size=raw_size, count_for_threshold=True)

    def _schedule_ack(self, *, raw_size: int, count_for_threshold: bool) -> None:
        if count_for_threshold:
            self._ack_frames_since_flush += 1
            self._ack_bytes_since_flush += raw_size
        threshold_hit = (
            self._ack_frames_since_flush >= self.config.ack_frame_threshold
            or self._ack_bytes_since_flush >= self.config.ack_byte_threshold
        )
        if threshold_hit:
            if self._ack_timer_task:
                self._ack_timer_task.cancel()
            # Reuse the timer slot so the task is referenced and cannot be
            # GC'd mid-flight (see CPython asyncio.create_task warning).
            self._ack_timer_task = asyncio.create_task(self._flush_ack())
            return
        if count_for_threshold:
            if self._ack_timer_task is None or self._ack_timer_task.done():
                self._ack_timer_task = asyncio.create_task(self._delayed_ack())
        elif self._ack_timer_task is None or self._ack_timer_task.done():
            self._ack_timer_task = asyncio.create_task(self._delayed_ack())

    async def _delayed_ack(self) -> None:
        await asyncio.sleep(self.config.ack_delay_s)
        await self._flush_ack()

    async def _flush_ack(self) -> None:
        if self._pending_ack_seq <= self._last_sent_ack_seq:
            return
        self._ack_frames_since_flush = 0
        self._ack_bytes_since_flush = 0
        await self._send_frame({"type": "t.ack", "ack": self._pending_ack_seq})
        self._last_sent_ack_seq = self._pending_ack_seq

    async def _send_frame(self, frame: Mapping[str, Any]) -> None:
        await self._send_text(self._encode_frame(frame))

    async def _send_text(self, text: str) -> None:
        if self._ws is None:
            return
        async with self._send_lock:
            await self._ws.send(text)

    def _next_unsent_entry(self, epoch: int) -> _OutboxEntry | None:
        for entry in self._outbox:
            if entry.sent_epoch != epoch:
                return entry
        return None

    def _first_unacked_or_next_seq(self) -> int:
        return self._outbox[0].seq if self._outbox else self._next_outgoing_seq

    def _trim_outbox(self, ack: int) -> None:
        while self._outbox and self._outbox[0].seq <= ack:
            entry = self._outbox.popleft()
            self._outbox_bytes -= entry.byte_len

    def _trim_outbox_from_peer_ack(self, ack: int) -> None:
        if ack >= self._next_outgoing_seq:
            raise TransportError(self._close_codes.sequence_error, "peer acked unsent data")
        first_unacked = self._first_unacked_or_next_seq()
        if ack < first_unacked:
            return
        self._trim_outbox(ack)

    def _reset_fresh_session(self) -> None:
        self._outbox.clear()
        self._outbox_bytes = 0
        self._next_outgoing_seq = 1
        self._delivered_next_seq = 1
        self._pending_ack_seq = 0
        self._last_sent_ack_seq = 0
        self._duplicate_run_count = 0
        self._duplicate_run_started_at = None

    def _outbox_limit_for_current_state(self) -> int:
        if self._state in {TransportState.DISCONNECTED, TransportState.CONNECTING}:
            return min(self._max_outbox_bytes, self._disconnected_soft_cap_bytes())
        return self._max_outbox_bytes

    def _disconnected_soft_cap_bytes(self) -> int:
        configured = self.config.disconnected_outbox_soft_cap_bytes
        if configured is not None:
            return max(0, configured)
        return max(1, self._max_outbox_bytes // 2)

    def _max_disconnected_duration_s(self) -> float:
        configured = self.config.max_disconnected_duration_s
        if configured is not None:
            return max(0.0, configured)
        return self._resume_ttl_s

    def _record_duplicate_data(self) -> None:
        now = time.monotonic()
        if (
            self._duplicate_run_started_at is None
            or now - self._duplicate_run_started_at > DEFAULT_DUPLICATE_ABUSE_WINDOW_S
        ):
            self._duplicate_run_started_at = now
            self._duplicate_run_count = 1
            return
        self._duplicate_run_count += 1
        if self._duplicate_run_count >= DEFAULT_DUPLICATE_ABUSE_THRESHOLD:
            raise TransportError(self._close_codes.sequence_error, "duplicate data frame abuse")

    async def _emit_event(self, kind: str, *, reason: str | None = None) -> None:
        self._emit_event_nowait(
            TransportEvent(
                kind=kind,
                session_id=self._session_id,
                connection_epoch=self._connection_epoch or None,
                reason=reason,
            )
        )

    def _emit_event_nowait(self, event: TransportEvent) -> None:
        with contextlib.suppress(asyncio.QueueFull):
            self._event_queue.put_nowait(event)

    async def _put_closed_sentinel(self) -> None:
        with contextlib.suppress(asyncio.QueueFull):
            self._recv_queue.put_nowait(_CLOSED_SENTINEL)
