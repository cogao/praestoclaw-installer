"""MCP Manager — centralized MCP server lifecycle manager.

Replaces scattered MCP state in Runtime (``_mcp_clients``, ``_connected_mcp``)
with a single orchestrator that handles connection, namespace, progressive
loading, and graceful shutdown.
"""

from __future__ import annotations

import asyncio
import contextlib
from collections.abc import Callable
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.registry import ToolRegistry
from praestoclaw.config.schema import MCPServerConfig, ProvidersConfig
from praestoclaw.mcp.auth import pre_connect_agency_check, resolve_auth_for_transport
from praestoclaw.mcp.client import MCPClient
from praestoclaw.mcp.defaults import get_default_description
from praestoclaw.mcp.health import MCPHealthMonitor
from praestoclaw.mcp.types import ConnectionState, MCPCapabilities, ServerInfo


class MCPManager:
    """Centralized MCP server lifecycle manager."""

    def __init__(
        self,
        configs: dict[str, MCPServerConfig],
        registry: ToolRegistry,
        security_profile: str | None = None,
        on_tools_registered: Callable[[list[str]], None] | None = None,
        providers: ProvidersConfig | None = None,
        risk_policy: dict[str, Any] | None = None,
        risk_variables: dict[str, str] | None = None,
    ) -> None:
        self._configs = configs
        self._registry = registry
        self._security_profile = security_profile
        self._on_tools_registered = on_tools_registered
        self._providers = providers
        self._risk_policy = risk_policy
        self._risk_variables = risk_variables

        # Connection state
        self._clients: dict[str, MCPClient] = {}
        self._states: dict[str, ConnectionState] = {name: ConnectionState.IDLE for name in configs}
        # Health monitor (lazy init)
        self._health_monitor: MCPHealthMonitor | None = None
        # Cached tool descriptors (for progressive loading — describe action)
        self._tool_cache: dict[str, list[dict[str, Any]]] = {}
        # Registered tool names per server (for unregistration)
        self._registered_tools: dict[str, list[str]] = {}
        # Stored overrides for reconnection (health monitor calls connect_server
        # without overrides — these preserve LLM-provided params).
        self._server_overrides: dict[str, dict[str, str]] = {}
        # Per-server connection lock: warm-up, manual connect, health reconnect,
        # and probe reconnect can all converge on connect_server(name). Serialize
        # by server so only one stdio subprocess can be spawned per name at once.
        self._connect_locks: dict[str, asyncio.Lock] = {}

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    async def _has_cached_token(self, name: str, config: MCPServerConfig) -> bool:
        """Check if a cached auth token exists (for ``enabled: auto``)."""
        # SDK OAuth token storage needs await — can't use asyncio.run() in event loop.
        # This covers: oauth without client_id, and implicit without MSAL/GitHub.
        if config.auth.type == "oauth" and not config.auth.client_id:
            from praestoclaw.mcp.oauth_storage import MCPTokenStorage

            return await MCPTokenStorage(name).get_tokens() is not None

        if config.auth.type == "implicit":
            from praestoclaw.mcp.auth import _is_github_url, has_msal_account

            if config.auth.client_id and config.auth.scopes:
                return has_msal_account(config.auth.client_id)
            if _is_github_url(config.url):
                from praestoclaw.mcp.auth import _resolve_github_token

                return _resolve_github_token() is not None
            # Other implicit: check SDK token storage
            from praestoclaw.mcp.oauth_storage import MCPTokenStorage

            return await MCPTokenStorage(name).get_tokens() is not None

        from praestoclaw.mcp.auth import has_cached_token

        return has_cached_token(name, config)

    def _server_timeout(self, name: str) -> float:
        """Return the effective timeout (seconds) for a server's operations."""
        config = self._configs.get(name)
        if config is None:
            return 60.0  # unknown server → standard default
        if config.timeout is not None:
            return max(1.0, float(config.timeout))  # clamp to ≥1s
        return 120.0 if config.is_agency else 60.0

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    async def connect_server(
        self,
        name: str,
        *,
        force: bool = False,
        auto_describe: bool = True,
        overrides: dict[str, str] | None = None,
    ) -> str:
        """Connect a single MCP server.

        Serializes connects per server name. Different servers may still connect
        concurrently, but concurrent attempts for the same server share one
        lifecycle path and cannot spawn duplicate stdio transports.
        """
        if name not in self._configs:
            available = [n for n, c in self._configs.items() if c.enabled is not False]
            return f"Unknown MCP server '{name}'. Available: {', '.join(available)}"

        lock = self._connect_locks.get(name)
        if lock is None:
            lock = asyncio.Lock()
            self._connect_locks[name] = lock
        async with lock:
            return await self._connect_server_locked(
                name,
                force=force,
                auto_describe=auto_describe,
                overrides=overrides,
            )

    async def _connect_server_locked(
        self,
        name: str,
        *,
        force: bool = False,
        auto_describe: bool = True,
        overrides: dict[str, str] | None = None,
    ) -> str:
        """Connect a single MCP server while holding its per-server lock.

        Returns a one-line summary for the LLM (progressive loading step 1).
        Tools are cached but NOT registered into the ToolRegistry until
        ``describe_server()`` or ``ensure_tools_registered()`` is called.
        Activation into the function calling schema is a separate step
        (caller must call ``registry.activate()`` per tool).

        Args:
            name: Server name.
            force: Force reconnect even if already connected.
            auto_describe: If True and ≤5 tools, auto-describe (register tools).
                Set False for warm-up (connect only, no registration).
            overrides: Runtime parameter overrides (e.g. from LLM arguments)
                for ``{var}`` placeholders in URL/headers/env.
        """
        if not force and self._states.get(name) == ConnectionState.CONNECTED:
            # Verify the client is actually still connected (adapter may have
            # disconnected it on ConnectionError without updating manager state)
            client = self._clients.get(name)
            if client and client.is_connected:
                # If overrides changed (e.g. switching org), force reconnect.
                # Coerce to str for consistent comparison (LLM may pass non-string types).
                coerced = (
                    {k: str(v) for k, v in overrides.items() if v is not None} if overrides else {}
                )
                if coerced and coerced != self._server_overrides.get(name):
                    logger.info(f"MCP server '{name}': overrides changed, reconnecting")
                    force = True
                else:
                    return f"MCP server '{name}' is already connected."
            # Stale state — fall through to reconnect
            if not force:
                logger.info(f"MCP server '{name}': stale CONNECTED state, reconnecting")
                force = True

        config = self._configs[name]

        if config.enabled is False:
            return f"MCP server '{name}' is disabled. Enable it in praestoclaw.yaml."

        # enabled: "auto" — connect only if a cached token is available.
        # Command/stdio servers manage their own auth; the auto token gate
        # applies only to HTTP/url servers.
        if config.enabled == "auto" and not config.command:
            if not await self._has_cached_token(name, config):
                self._states[name] = ConnectionState.SKIPPED
                logger.debug("MCP server '{}': auto-skipped (no cached token)", name)
                return (
                    f"MCP server '{name}': auto-skipped — "
                    f"run `pc mcp login {name}` to authenticate."
                )

        # Resolve {var} placeholders in URL and headers
        from praestoclaw.mcp.defaults import resolve_server_params

        # Merge stored overrides (from prior connect) with new overrides
        merged_overrides = {**self._server_overrides.get(name, {}), **(overrides or {})}
        # Coerce values to strings — LLM arguments may contain non-string types
        merged_overrides = {k: str(v) for k, v in merged_overrides.items() if v is not None}
        resolved_url, resolved_headers, resolved_env, unresolved = resolve_server_params(
            config.url,
            config.headers,
            env=config.env or None,
            overrides=merged_overrides or None,
        )
        if unresolved:
            params_list = ", ".join(sorted(unresolved))
            self._states[name] = ConnectionState.IDLE
            logger.debug("MCP server '{}': unresolved params: {}", name, params_list)
            args_hint = ", ".join(f'"{p}": "..."' for p in sorted(unresolved))
            return (
                f"MCP server '{name}' requires parameters: {params_list}. "
                f'Use tools(name="MCP_{name}", action="enable", '
                f"arguments={{{args_hint}}})"
            )
        # Store overrides for health-monitor reconnects
        if merged_overrides:
            self._server_overrides[name] = merged_overrides

        # Clean up old connection on force reconnect
        if force:
            if self._health_monitor:
                self._health_monitor.stop_monitoring(name)
            old_client = self._clients.pop(name, None)
            if old_client:
                try:
                    await old_client.disconnect()
                except Exception:
                    pass
            # Clear old registrations so describe_server re-registers
            old_ns = f"MCP_{config.namespace or name}_"
            self._registry.unregister_prefix(old_ns)
            self._registered_tools.pop(name, None)

        self._states[name] = ConnectionState.CONNECTING

        # Agency pre-flight check
        if config.is_agency:
            ok, msg = await pre_connect_agency_check()
            if not ok:
                logger.warning(f"MCP server '{name}': Agency auth issue: {msg}")
                # Still attempt connection — Agency may prompt interactively

        # Pre-bind so the except block below can safely reference `client`
        # even if we fail before MCPClient(...) is constructed.
        client = None
        try:
            # Auth: resolve token or httpx.Auth for transport.
            # MSAL paths return MSALAuth (per-request token refresh);
            # static paths (bearer/GitHub) return headers only.
            auth_result = await resolve_auth_for_transport(
                config,
                self._providers,
                resolved_url=resolved_url,
                resolved_headers=resolved_headers,
            )
            headers = {**resolved_headers, **auth_result.headers}
            # When MSALAuth handles auth, strip any stale Authorization
            # from static headers — MSALAuth sets it per-request.
            if auth_result.auth is not None:
                headers = {k: v for k, v in headers.items() if k.lower() != "authorization"}

            # SDK OAuth provider — only when no auth already resolved.
            # Cannot coexist with static Authorization header because httpx
            # calls auth.async_auth_flow() on EVERY request (not just 401):
            # the provider may override the header or trigger registration/
            # auth-code flows that crash for implicit-mode servers.
            auth_provider = auth_result.auth
            if auth_provider is None and not any(k.lower() == "authorization" for k in headers):
                from praestoclaw.mcp.oauth_provider import create_oauth_auth

                try:
                    auth_provider = await create_oauth_auth(
                        name,
                        config,
                        self._providers,
                        resolved_url=resolved_url,
                    )
                except Exception as exc:
                    if config.auth.type == "oauth":
                        raise  # explicit OAuth — fail loudly
                    logger.debug("OAuth auto-discovery setup skipped for '{}': {}", name, exc)

            # HTTP servers with known Entra scopes use Streamable HTTP only
            is_modern_http = resolved_url and config.auth.client_id
            client = MCPClient(
                command=config.command,
                args=config.args,
                env=resolved_env or None,
                url=resolved_url,
                headers=headers or None,
                auth=auth_provider,
                name=name,
                skip_sse=bool(is_modern_http),
                legacy_protocol=bool(config.command),  # stdio may need older protocol
            )
            timeout = self._server_timeout(name)
            try:
                await client.connect(timeout=timeout)
            except Exception:
                # If no configured client_id and SDK OAuth failed (likely
                # dynamic registration not supported or Entra resource/scope
                # mismatch — AADSTS9010010), retry with MSAL direct auth.
                # MSALAuth with a cached token handles its own lifecycle —
                # re-raise.  MSALAuth WITHOUT a token means the Entra probe
                # detected Entra but no MSAL session exists; fall through
                # to interactive login.
                from praestoclaw.mcp.auth import MSALAuth

                if (
                    config.auth.client_id
                    or auth_provider is None
                    or (isinstance(auth_provider, MSALAuth) and auth_provider.has_token)
                ):
                    raise
                from praestoclaw.mcp.oauth_storage import MCPTokenStorage

                storage = MCPTokenStorage(name)
                if not isinstance(auth_provider, MSALAuth) and await storage.get_client_info():
                    raise  # already has client_info — not a registration issue

                # Clean up failed client before retry
                try:
                    await client.disconnect()
                except Exception:
                    pass

                # Probe for Entra auth — if found, use MSAL directly instead
                # of SDK OAuth (avoids resource/scope mismatch on Entra).
                from praestoclaw.mcp.auth import acquire_entra_token_for_server

                effective_url = resolved_url or config.url or ""
                is_entra, entra_token = await asyncio.to_thread(
                    acquire_entra_token_for_server,
                    effective_url,
                    {
                        k: v
                        for k, v in (resolved_headers or config.headers or {}).items()
                        if k.lower() != "authorization"
                    }
                    or None,
                )
                if is_entra and entra_token:
                    logger.info(
                        "MCP server '{}': retrying with Entra MSAL token",
                        name,
                    )
                    # Interactive login populated the MSAL cache — use MSALAuth
                    # so tokens refresh automatically on long-lived sessions.
                    from praestoclaw.mcp.auth import discover_entra_auth

                    entra_info = await asyncio.to_thread(
                        discover_entra_auth,
                        effective_url,
                        {
                            k: v
                            for k, v in (resolved_headers or config.headers or {}).items()
                            if k.lower() != "authorization"
                        }
                        or None,
                    )
                    if entra_info:
                        entra_cid, entra_scopes, _ = entra_info
                        msal_auth = MSALAuth(entra_cid, entra_scopes)
                    else:
                        # Probe failed on retry — fall back to static token
                        msal_auth = None
                    retry_headers = {
                        k: v
                        for k, v in (resolved_headers or {}).items()
                        if k.lower() != "authorization"
                    }
                    if msal_auth is None:
                        retry_headers["Authorization"] = f"Bearer {entra_token}"
                    client = MCPClient(
                        command=config.command,
                        args=config.args,
                        env=resolved_env or None,
                        url=resolved_url,
                        headers=retry_headers or None,
                        auth=msal_auth,
                        name=name,
                        skip_sse=bool(is_modern_http),
                        legacy_protocol=bool(config.command),
                    )
                    await client.connect(timeout=timeout)  # second attempt
                elif is_entra:
                    raise RuntimeError(
                        f"Entra login failed for '{name}'. "
                        "Check that your account has access to this resource."
                    )
                elif isinstance(auth_provider, MSALAuth):
                    # First probe detected Entra but the retry probe
                    # failed transiently — don't fall through to SDK
                    # OAuth which would reintroduce resource/scope mismatch.
                    raise
                else:
                    # Non-Entra: retry with SHARED_ENTRA_CLIENT_ID as
                    # fallback for dynamic registration failures.
                    from praestoclaw.mcp.defaults import SHARED_ENTRA_CLIENT_ID

                    logger.info(
                        "MCP server '{}': retrying with shared Entra client ({})",
                        name,
                        SHARED_ENTRA_CLIENT_ID,
                    )
                    from mcp.shared.auth import OAuthClientInformationFull
                    from pydantic import AnyUrl

                    await storage.set_client_info(
                        OAuthClientInformationFull(
                            client_id=SHARED_ENTRA_CLIENT_ID,
                            redirect_uris=[
                                AnyUrl(f"http://localhost:{config.auth.callback_port or 0}/")
                            ],
                            client_name="PraestoClaw",
                        )
                    )
                    from praestoclaw.mcp.oauth_provider import create_oauth_auth

                    auth_provider = await create_oauth_auth(
                        name,
                        config,
                        self._providers,
                        resolved_url=resolved_url,
                    )
                    client = MCPClient(
                        command=config.command,
                        args=config.args,
                        env=resolved_env or None,
                        url=resolved_url,
                        headers=headers or None,
                        auth=auth_provider,
                        name=name,
                        skip_sse=bool(is_modern_http),
                        legacy_protocol=bool(config.command),
                    )
                    await client.connect(timeout=timeout)  # second attempt

            # Cache tool descriptors (do NOT register yet — progressive loading)
            try:
                descriptors = await client.list_tools(timeout=timeout)
            except Exception as exc:
                logger.warning(f"MCP server '{name}': failed to list tools: {exc}")
                descriptors = []

            self._clients[name] = client
            self._states[name] = ConnectionState.CONNECTED
            self._tool_cache[name] = descriptors

            # Health monitoring: periodic ping only for stdio servers.
            # HTTP servers are stateless — token lifecycle (MSALAuth) handles
            # auth refresh, and reactive reconnect (probe_and_reconnect →
            # reconnect_now) handles server failures on tool calls.
            if self._health_monitor is None:
                self._health_monitor = MCPHealthMonitor(self)
            is_stdio = config.command is not None
            if is_stdio:
                await self._health_monitor.start_monitoring(name)

            # Wire up reconnect callbacks:
            # - _receive_loop uses trigger_reconnect (transport already dead,
            #   wakes the monitor loop which runs check_server then _reconnect)
            # - probe_and_reconnect uses reconnect_now (probe already confirmed
            #   server is unreachable, skip redundant check_server ping and
            #   spawn a dedicated reconnect task directly)
            health_monitor = self._health_monitor
            client._on_connection_lost = lambda: health_monitor.trigger_reconnect(name)
            client._on_probe_failed = lambda: health_monitor.reconnect_now(name)

            caps = client.capabilities
            logger.debug(f"MCP server '{name}': connected, {len(descriptors)} tools cached")

            # Smart shortcut: ≤5 tools → auto-describe (saves an LLM round)
            if auto_describe and len(descriptors) <= 5:
                return await self.describe_server(name)

            return self._build_summary(name, config, descriptors, caps)

        except Exception as exc:
            self._states[name] = ConnectionState.DISCONNECTED
            # If connect/list_tools failed before the client was published into
            # ``self._clients``, the local ``client`` variable may still own a
            # live stdio subprocess (e.g. ``agency mcp ...``). Historically this
            # path returned an error string without disconnecting that temporary
            # client, so health reconnect storms leaked one child process per
            # failed attempt until the daemon hit EMFILE. Always reap untracked
            # clients before returning the failure summary. See issue #356.
            if client is not None and self._clients.get(name) is not client:
                with contextlib.suppress(Exception):
                    await client.disconnect()
            # 401/Unauthorized is expected for HTTP servers until the user
            # completes interactive sign-in — downgrade to WARNING (not ERROR)
            # and include the remediation hint inline so first-run users
            # don't see a screenful of red noise.
            exc_str = str(exc)
            # When the subprocess exits early (e.g. agency proxy bailing out
            # before the MCP handshake), the bubbled-up exception is just
            # "transport not available". The richer stderr-tail reason lives
            # on the client — fold it into exc_str so classifiers below see it.
            reason = getattr(client, "last_disconnect_reason", None) if client is not None else None
            if reason:
                exc_str = f"{exc_str} | {reason}"
            is_auth_error = "401" in exc_str or "Unauthorized" in exc_str
            # Agency-proxied servers (ado, bluebird, ...) auto-detect ADO org
            # from the current dir's git remote. When started outside an ADO
            # repo they exit immediately with a clear stderr message. Surface
            # this as a one-line hint instead of an ERROR — users who later
            # `cd` into an ADO repo and restart will get them working.
            is_ado_context_missing = (
                "auto-detect organization" in exc_str
                or "not a git repository" in exc_str
                or "Failed to auto-detect" in exc_str
                or "Could not parse ADO remote URL" in exc_str
                or "Failed to determine organization name" in exc_str
                or "please provide --org" in exc_str.lower()
            )
            if is_auth_error:
                logger.warning(
                    f"MCP server '{name}' not authenticated (run `pc mcp login {name}` to sign in)."
                )
                msg = (
                    f"MCP server '{name}' requires sign-in. "
                    f"Run `pc mcp login {name}` to authenticate."
                )
            elif is_ado_context_missing:
                logger.warning(
                    f"MCP server '{name}' skipped: needs an Azure DevOps git remote in the "
                    f"current directory. cd into an ADO repo and restart to enable it."
                )
                msg = (
                    f"MCP server '{name}' needs an ADO git remote in the current directory. "
                    f"cd into an ADO repo (or set --organization in tools.mcp_servers.{name}.args) "
                    f"and restart to enable it."
                )
            else:
                logger.error(f"MCP server '{name}' failed to start: {exc}")
                msg = f"Failed to connect MCP server '{name}': {exc}"
            return msg

    async def describe_server(self, name: str, *, keyword: str | None = None) -> str:
        """Return full server capabilities: tools, resources, prompts.

        Auto-connects if not already connected. Registers tools into the
        ToolRegistry (but does NOT activate them — caller must activate
        separately for tools to appear in the function calling schema).

        Args:
            name: Server name.
            keyword: Optional filter — only tools whose name or description
                contains this keyword (case-insensitive) are returned.
        """
        # Auto-connect if needed
        if self._states.get(name) != ConnectionState.CONNECTED:
            result = await self.connect_server(name)
            if self._states.get(name) != ConnectionState.CONNECTED:
                return result  # connection failed — return error

        descriptors = self._tool_cache.get(name, [])
        client = self._clients.get(name)
        config = self._configs.get(name)
        ns = (config.namespace if config and config.namespace else name) if config else name

        # Register tools if not already registered
        if name not in self._registered_tools:
            self._register_cached_tools(name)

        sections: list[str] = []

        # --- Tools section ---
        if descriptors:
            if keyword:
                kw = keyword.lower()
                filtered = [
                    d
                    for d in descriptors
                    if kw in d.get("name", "").lower() or kw in d.get("description", "").lower()
                ]
            else:
                filtered = descriptors

            if filtered:
                tool_lines: list[str] = []
                for desc in filtered:
                    raw_name = desc.get("name", "")
                    tool_desc = desc.get("description", "")
                    params = desc.get("inputSchema", {}).get("properties", {})
                    required = desc.get("inputSchema", {}).get("required", [])
                    param_str = ", ".join(
                        f"{k}: {v.get('type', 'any')}{'?' if k not in required else ''}"
                        for k, v in params.items()
                    )
                    tool_lines.append(f"  MCP_{ns}_{raw_name}({param_str}) — {tool_desc}")
                suffix = f", filtered by '{keyword}'" if keyword else ""
                sections.append(
                    f"Tools ({len(filtered)}/{len(descriptors)}{suffix}):\n" + "\n".join(tool_lines)
                )
            elif keyword:
                sections.append(f"Tools: no matches for '{keyword}' ({len(descriptors)} total)")
        else:
            sections.append("Tools: none")

        # --- Resources section ---
        timeout = self._server_timeout(name)
        if client:
            try:
                resources = await client.list_resources(timeout=timeout)
                if resources:
                    res_lines = [
                        f"  {r.get('uri', '?')} — {r.get('name', '')}: {r.get('description', '')}"
                        for r in resources
                    ]
                    sections.append(f"Resources ({len(resources)}):\n" + "\n".join(res_lines))
            except Exception:
                pass  # server doesn't support resources

        # --- Prompts section ---
        if client:
            try:
                prompts = await client.list_prompts(timeout=timeout)
                if prompts:
                    prompt_lines: list[str] = []
                    for p in prompts:
                        pname = p.get("name", "?")
                        pdesc = p.get("description", "")
                        pargs = p.get("arguments", [])
                        arg_str = ", ".join(a.get("name", "") for a in pargs) if pargs else ""
                        prompt_lines.append(f"  {pname}({arg_str}) — {pdesc}")
                    sections.append(f"Prompts ({len(prompts)}):\n" + "\n".join(prompt_lines))
            except Exception:
                pass  # server doesn't support prompts

        return f"MCP server '{name}':\n\n" + "\n\n".join(sections)

    async def read_resource(self, name: str, uri: str) -> str:
        """Read a resource from a connected server by URI."""
        client = self._clients.get(name)
        if client is None:
            return f"MCP server '{name}' is not connected."
        try:
            return await client.read_resource(uri, timeout=self._server_timeout(name))
        except Exception as exc:
            return f"Failed to read resource '{uri}' from '{name}': {exc}"

    async def get_prompt(
        self, name: str, prompt: str, arguments: dict[str, str] | None = None
    ) -> str:
        """Get a rendered prompt from a connected server."""
        client = self._clients.get(name)
        if client is None:
            return f"MCP server '{name}' is not connected."
        try:
            return await client.get_prompt(prompt, arguments, timeout=self._server_timeout(name))
        except Exception as exc:
            return f"Failed to get prompt '{prompt}' from '{name}': {exc}"

    def ensure_tools_registered(self, name: str) -> None:
        """Register cached tool descriptors into the ToolRegistry if not already done.

        Registered tools are added to the registry but NOT activated (caller
        must call ``registry.activate()`` separately). Lightweight alternative
        to ``describe_server()`` — no formatting, no resources/prompts listing,
        no network calls beyond the initial connect.
        """
        if name not in self._registered_tools:
            self._register_cached_tools(name)

    async def disconnect_server(self, name: str) -> None:
        """Disconnect a server and unregister its tools."""
        # Stop health monitor
        if self._health_monitor:
            self._health_monitor.stop_monitoring(name)

        # Unregister tools
        config = self._configs.get(name)
        ns = (config.namespace if config and config.namespace else name) if config else name
        prefix = f"MCP_{ns}_"
        self._registry.unregister_prefix(prefix)
        self._registered_tools.pop(name, None)
        self._tool_cache.pop(name, None)

        # Disconnect client
        client = self._clients.pop(name, None)
        if client:
            try:
                await client.disconnect()
            except Exception as exc:
                logger.warning(f"MCP server '{name}' disconnect error: {exc}")

        self._states[name] = ConnectionState.DISCONNECTED

    async def disconnect_all(self) -> None:
        """Graceful shutdown of all connected servers."""
        if self._health_monitor:
            self._health_monitor.stop_all()
        names = list(self._clients.keys())
        for name in names:
            await self.disconnect_server(name)

    async def warm_up(self, timeout: float = 3.0) -> None:
        """Connect all enabled servers at startup.

        HTTP servers connect in parallel (MSAL auth is non-interactive).
        Stdio servers connect sequentially with 1s pause (Agency may prompt).
        Tasks that exceed *timeout* continue in the background.
        """
        from praestoclaw.mcp.defaults import has_unresolved_params

        enabled = [name for name, cfg in self._configs.items() if cfg.enabled]
        # Skip servers with unresolved {var} — params are optional, LLM fills at runtime
        skipped = [
            n
            for n in enabled
            if has_unresolved_params(
                self._configs[n].url, self._configs[n].headers, self._configs[n].env
            )
        ]
        if skipped:
            logger.debug(
                "MCP warm-up: skipping {} server(s) with unresolved params: {}",
                len(skipped),
                ", ".join(skipped),
            )
        skipped_set = set(skipped)
        enabled = [n for n in enabled if n not in skipped_set]
        if not enabled:
            return

        # command takes precedence: merged configs may have both url and command
        stdio_servers = [n for n in enabled if self._configs[n].command]
        http_servers = [n for n in enabled if not self._configs[n].command]

        total = len(enabled)
        logger.debug(
            f"MCP warm-up: {total} servers ({len(http_servers)} HTTP parallel,"
            f" {len(stdio_servers)} stdio sequential)"
        )

        # Phase 1: HTTP servers in parallel
        if http_servers:
            tasks = {
                asyncio.create_task(
                    self.connect_server(n, auto_describe=False),
                    name=f"mcp-warmup-{n}",
                ): n
                for n in http_servers
            }
            done, pending = await asyncio.wait(tasks, timeout=timeout)
            for t in done:
                name = tasks[t]
                if t.exception():
                    self._states[name] = ConnectionState.IDLE
                    logger.warning(f"MCP warm-up {name}: failed — {t.exception()}")
                else:
                    logger.debug(f"MCP warm-up {name}: OK")
            for t in pending:
                name = tasks[t]
                logger.debug(f"MCP warm-up {name}: still connecting in background")

                def _on_done(t: asyncio.Task, _name: str = name) -> None:
                    exc = t.exception() if not t.cancelled() else None
                    if exc:
                        self._states[_name] = ConnectionState.IDLE
                        logger.warning(f"MCP background connect '{_name}' failed: {exc}")

                t.add_done_callback(_on_done)

        # Phase 2: stdio servers sequentially (may trigger interactive auth)
        for i, name in enumerate(stdio_servers):
            task = asyncio.create_task(
                self.connect_server(name, auto_describe=False),
                name=f"mcp-warmup-{name}",
            )
            try:
                result = await asyncio.wait_for(asyncio.shield(task), timeout=timeout)
                logger.debug(f"MCP warm-up {name}: OK — {result[:100]}")
            except TimeoutError:
                logger.debug(f"MCP warm-up {name}: still connecting in background")

                def _on_done_stdio(t: asyncio.Task, _name: str = name) -> None:
                    exc = t.exception() if not t.cancelled() else None
                    if exc:
                        self._states[_name] = ConnectionState.IDLE
                        logger.warning(f"MCP background connect '{_name}' failed: {exc}")

                task.add_done_callback(_on_done_stdio)
            except Exception as exc:
                self._states[name] = ConnectionState.IDLE
                logger.warning(f"MCP warm-up {name}: failed — {exc}")

            if i < len(stdio_servers) - 1:
                await asyncio.sleep(1.0)

        connected = len(self.get_connected_servers())
        logger.info(f"MCP warm-up done: {connected}/{total} servers connected")

    # ------------------------------------------------------------------
    # Discovery
    # ------------------------------------------------------------------

    def list_servers(self) -> list[ServerInfo]:
        """List all configured servers with connection status."""
        result: list[ServerInfo] = []
        for name, config in self._configs.items():
            state = self._states.get(name, ConnectionState.IDLE)
            if not config.enabled:
                state = ConnectionState.IDLE  # disabled servers are always idle
            tool_count = len(self._registered_tools.get(name, []))
            result.append(
                ServerInfo(
                    name=name,
                    state=state,
                    is_agency=config.is_agency,
                    enabled=config.enabled,
                    description=(
                        config.description
                        if config.description is not None
                        else get_default_description(name, is_agency=config.is_agency)
                    ),
                    tool_count=tool_count,
                )
            )
        return result

    def get_connected_servers(self) -> list[str]:
        """Return names of currently connected servers."""
        return [name for name, state in self._states.items() if state == ConnectionState.CONNECTED]

    def get_server_config(self, name: str) -> MCPServerConfig | None:
        """Return the MCPServerConfig for a server, or None."""
        return self._configs.get(name)

    def get_server_status(self, name: str) -> ServerInfo | None:
        """Get detailed status for a single server."""
        config = self._configs.get(name)
        if not config:
            return None
        return ServerInfo(
            name=name,
            state=self._states.get(name, ConnectionState.IDLE),
            is_agency=config.is_agency,
            enabled=config.enabled,
            description=(
                config.description
                if config.description is not None
                else get_default_description(name, is_agency=config.is_agency)
            ),
            tool_count=len(self._registered_tools.get(name, [])),
        )

    def build_system_prompt_summary(self) -> str:
        """Build one-line-per-server summary for system prompt injection.

        Only includes connected servers. Each line ≤100 chars.
        """
        connected = self.get_connected_servers()
        if not connected:
            return ""
        lines: list[str] = []
        for name in connected:
            config = self._configs.get(name)
            descriptors = self._tool_cache.get(name, [])
            explicit_desc = config.description if config else None
            preset_desc = (
                get_default_description(name, is_agency=config.is_agency) if config else None
            )
            if explicit_desc is not None:
                summary = explicit_desc
            elif preset_desc:
                tool_snippet = self._short_summary(name, config, descriptors)
                # Combine preset with tool snippet so prompt reflects available tools
                summary = f"{preset_desc} — {tool_snippet}" if descriptors else preset_desc
            else:
                summary = self._short_summary(name, config, descriptors)
            tool_count = len(self._registered_tools.get(name, []))
            tools_info = f" ({tool_count} tools)" if tool_count > 0 else ""
            line = f"  MCP_{name}{tools_info} — {summary}"
            lines.append(line[:100] if len(line) > 100 else line)
        return "MCP servers connected:\n" + "\n".join(lines)

    def get_client(self, name: str) -> MCPClient | None:
        """Get the MCPClient for a connected server."""
        return self._clients.get(name)

    def agency_servers(self) -> list[str]:
        """List all servers where command == 'agency'."""
        return [name for name, cfg in self._configs.items() if cfg.is_agency]

    def tool_namespace(self, name: str) -> str:
        """Return the tool namespace for a server (may differ from server name)."""
        config = self._configs.get(name)
        return config.namespace or name if config and config.namespace else name

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _register_cached_tools(self, name: str) -> None:
        """Synchronously register cached tool descriptors into the ToolRegistry."""
        config = self._configs.get(name)
        client = self._clients.get(name)
        if not client or not config:
            return

        descriptors = self._tool_cache.get(name, [])
        ns = config.namespace or name

        from praestoclaw.mcp.adapter import (
            MCPToolAdapter,
            _build_risk_config,
            _resolve_server_timeout,
        )

        timeout = _resolve_server_timeout(config)
        streaming = client.capabilities.streaming
        risk_config = _build_risk_config(config)

        registered: list[str] = []
        for descriptor in descriptors:
            raw_name = descriptor.get("name", "")
            if not raw_name:
                continue
            reg_name = f"MCP_{ns}_{raw_name}"
            if self._registry.get(reg_name) is not None:
                continue
            adapter = MCPToolAdapter(
                descriptor,
                client,
                server_name=ns,
                timeout=timeout,
                streaming=streaming,
                risk_config=risk_config,
                risk_policy=self._risk_policy,
                risk_variables=self._risk_variables,
            )
            try:
                self._registry.register(adapter)
                registered.append(reg_name)
            except ValueError:
                pass

        self._registered_tools[name] = registered
        logger.debug(f"MCP server '{name}': registered {len(registered)} tools (not yet activated)")

        # Notify agent loop that new tools are available (not yet activated)
        if registered and self._on_tools_registered:
            self._on_tools_registered(registered)

    @staticmethod
    def _build_summary(
        name: str,
        config: MCPServerConfig,
        descriptors: list[dict[str, Any]],
        caps: MCPCapabilities | None = None,
    ) -> str:
        """One-line connect summary for LLM."""
        info = [f"Tools: {len(descriptors)}"]
        if caps and caps.resources:
            info.append("Resources: yes")
        if caps and caps.prompts:
            info.append("Prompts: yes")
        return (
            f"Connected to MCP_{name} — {' | '.join(info)}.\n"
            f'Call tools(name="MCP_{name}", action="describe") to see tool details.'
        )

    @staticmethod
    def _short_summary(
        name: str,
        config: MCPServerConfig | None,
        descriptors: list[dict[str, Any]],
    ) -> str:
        """Short summary for system prompt (≤100 chars)."""
        if not descriptors:
            return "connected, no tools"
        # Collect unique verbs from tool names for a quick summary
        tool_names = [d.get("name", "") for d in descriptors[:5]]
        snippet = ", ".join(tool_names)
        if len(descriptors) > 5:
            snippet += f" +{len(descriptors) - 5} more"
        # Truncate to ~100 chars
        if len(snippet) > 95:
            snippet = snippet[:92] + "..."
        return snippet
