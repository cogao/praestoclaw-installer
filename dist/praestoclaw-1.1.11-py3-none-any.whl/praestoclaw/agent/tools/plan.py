"""Plan tool — structured TODO / SOP runtime for long-running tasks.

The agent uses ``plan`` to:
  - break a long task into ordered, verifiable items (``create``)
  - track progress (``update``)
  - check in with the user at SOP-defined gates (``checkpoint``)
  - emit non-blocking progress (``report``)
  - validate that "done" actually means done (``verify``)
  - inspect current state (``show``)

Plans are stored at ``<data_dir>/plans/<session_id>.json`` so they survive
process restarts and can be resumed via ``praestoclaw resume``. The store
is intentionally a single JSON file per session — small, human-readable,
and trivial to back up or hand-edit.

This tool is the foundation for steps 3-8 of the long-task design
(see design/features/long-task-workflows.md, future).
"""

from __future__ import annotations

import json
import re
import uuid
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.risk import RiskAssessment, RiskScore

# ── Constants ────────────────────────────────────────────────────────────────

_VALID_STATUSES = ("not_started", "in_progress", "blocked", "done", "skipped")
_TERMINAL_STATUSES = ("done", "skipped")
_FAIL_PATTERNS = re.compile(
    r"\b(fail|failed|failure|error|traceback|exit\s*code\s*[1-9])\b",
    re.IGNORECASE,
)
_MAX_ITEMS = 50
_MAX_TITLE_LEN = 200
_MAX_TEXT_LEN = 4000


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _safe_session_filename(session_id: str) -> str:
    """Sanitize a session id into a safe filename component.

    The same logic SessionManager uses for its JSONL files.
    """
    safe = session_id.replace(":", "_").replace("/", "_").replace("\\", "_")
    safe = re.sub(r"[^A-Za-z0-9_\-.]", "_", safe)
    return safe[:200] or "default"


# ── Data model ──────────────────────────────────────────────────────────────


@dataclass
class PlanItem:
    id: str
    title: str
    acceptance: str = ""
    status: str = "not_started"
    note: str = ""
    evidence: str = ""
    depends_on: list[str] = field(default_factory=list)
    started_at: str = ""
    completed_at: str = ""

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> PlanItem:
        return cls(
            id=str(d.get("id") or uuid.uuid4().hex[:8]),
            title=str(d.get("title", "")).strip()[:_MAX_TITLE_LEN],
            acceptance=str(d.get("acceptance", "")).strip()[:_MAX_TEXT_LEN],
            status=str(d.get("status", "not_started")),
            note=str(d.get("note", ""))[:_MAX_TEXT_LEN],
            evidence=str(d.get("evidence", ""))[:_MAX_TEXT_LEN],
            depends_on=[str(x) for x in (d.get("depends_on") or [])],
            started_at=str(d.get("started_at", "")),
            completed_at=str(d.get("completed_at", "")),
        )


@dataclass
class Checkpoint:
    ts: str
    summary: str
    next_step: str = ""
    asked_user: bool = False


@dataclass
class Plan:
    session_id: str
    items: list[PlanItem] = field(default_factory=list)
    checkpoints: list[Checkpoint] = field(default_factory=list)
    workflow: str = ""  # SOP name (e.g. "feature-implement")
    created_at: str = ""
    updated_at: str = ""
    # ISO timestamp of the agent loop iteration that received the
    # "plan just completed — deliver the result" nudge. Used to fire
    # that nudge exactly once per completion (prevents nagging on every
    # follow-up user turn). Empty until the nudge has been delivered.
    delivered_at: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id,
            "workflow": self.workflow,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "delivered_at": self.delivered_at,
            "items": [asdict(it) for it in self.items],
            "checkpoints": [asdict(cp) for cp in self.checkpoints],
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Plan:
        return cls(
            session_id=str(d.get("session_id", "")),
            workflow=str(d.get("workflow", "")),
            created_at=str(d.get("created_at", "")),
            updated_at=str(d.get("updated_at", "")),
            delivered_at=str(d.get("delivered_at", "")),
            items=[PlanItem.from_dict(x) for x in (d.get("items") or [])],
            checkpoints=[Checkpoint(**x) for x in (d.get("checkpoints") or [])],
        )

    @property
    def progress(self) -> tuple[int, int]:
        """(done_count, total_count) — skipped counts as done for progress."""
        done = sum(1 for it in self.items if it.status in _TERMINAL_STATUSES)
        return done, len(self.items)

    @property
    def active_item(self) -> PlanItem | None:
        for it in self.items:
            if it.status == "in_progress":
                return it
        return None

    @property
    def is_complete(self) -> bool:
        return bool(self.items) and all(it.status in _TERMINAL_STATUSES for it in self.items)


# ── Persistent store ────────────────────────────────────────────────────────


class PlanStore:
    """Per-session JSON-file plan storage.

    Each session has at most one plan. The store is process-safe via atomic
    write (write-temp + rename) and tolerates concurrent reads.
    """

    def __init__(self, data_dir: Path | None = None) -> None:
        if data_dir is None:
            from praestoclaw.utils.helpers import get_data_dir

            data_dir = get_data_dir()
        self._root = data_dir / "plans"
        self._root.mkdir(parents=True, exist_ok=True)

    def path_for(self, session_id: str) -> Path:
        return self._root / f"{_safe_session_filename(session_id)}.json"

    def exists(self, session_id: str) -> bool:
        return self.path_for(session_id).is_file()

    def load(self, session_id: str) -> Plan | None:
        path = self.path_for(session_id)
        if not path.is_file():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning("Plan file unreadable: {} ({})", path, exc)
            return None
        return Plan.from_dict(data)

    def save(self, plan: Plan) -> None:
        plan.updated_at = _now()
        path = self.path_for(plan.session_id)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(
            json.dumps(plan.to_dict(), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        tmp.replace(path)

    def delete(self, session_id: str) -> bool:
        path = self.path_for(session_id)
        if path.is_file():
            path.unlink()
            return True
        return False

    def list_active(self) -> list[Plan]:
        """All plans with at least one non-terminal item, newest first."""
        plans: list[Plan] = []
        for path in sorted(
            self._root.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True
        ):
            try:
                p = Plan.from_dict(json.loads(path.read_text(encoding="utf-8")))
            except Exception as exc:  # noqa: BLE001
                logger.debug("Skipping unreadable plan {}: {}", path, exc)
                continue
            if not p.is_complete and p.items:
                plans.append(p)
        return plans

    def list_all(self) -> list[Plan]:
        plans: list[Plan] = []
        for path in sorted(
            self._root.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True
        ):
            try:
                plans.append(Plan.from_dict(json.loads(path.read_text(encoding="utf-8"))))
            except Exception as exc:  # noqa: BLE001
                logger.debug("Skipping unreadable plan {}: {}", path, exc)
                continue
        return plans


# Module-level singleton — the agent loop uses it to read the active plan
# without instantiating the tool itself.
_default_store: PlanStore | None = None


def get_plan_store() -> PlanStore:
    global _default_store  # noqa: PLW0603
    if _default_store is None:
        _default_store = PlanStore()
    return _default_store


# ── Rendering helpers ───────────────────────────────────────────────────────

_STATUS_ICON = {
    "not_started": "[ ]",
    "in_progress": "[▶]",
    "blocked": "[!]",
    "done": "[✓]",
    "skipped": "[~]",
}

# Pretty-print status icons for live-update messages (rendered in chat
# clients that support emoji + Markdown; falls back to monochrome blocks
# in plain terminals).
_STATUS_PILL = {
    "not_started": ("⚪", "Default"),
    "in_progress": ("🔵", "Accent"),
    "blocked": ("🟡", "Warning"),
    "done": ("🟢", "Good"),
    "skipped": ("⚫", "Default"),
}

# Adaptive Card schema constants — duplicated here (rather than imported
# from channels/teams_cards) to keep the agent-tool layer free of
# channel-specific imports. Cards are pure dicts the channel forwards
# verbatim; both teams_cards.wrap_for_teams and the cloud channel's
# _extract_card_from_activity_json key off the same content type.
_AC_SCHEMA = "http://adaptivecards.io/schemas/adaptive-card.json"
_AC_VERSION = "1.4"
_AC_CONTENT_TYPE = "application/vnd.microsoft.card.adaptive"


def render_plan(plan: Plan, *, compact: bool = False) -> str:
    """Render a plan as a short text block suitable for tool output / prompts."""
    if not plan.items:
        return "(plan is empty)"
    done, total = plan.progress
    header_bits = [f"Plan ({done}/{total} done)"]
    if plan.workflow:
        header_bits.append(f"workflow={plan.workflow}")
    lines = [" — ".join(header_bits)]
    for i, it in enumerate(plan.items, 1):
        icon = _STATUS_ICON.get(it.status, "[?]")
        line = f"  {i}. {icon} {it.title}"
        if it.status == "blocked" and it.note:
            line += f"   ⚠ {it.note[:120]}"
        lines.append(line)
    if not compact and plan.checkpoints:
        last = plan.checkpoints[-1]
        lines.append(f"\nLast checkpoint: {last.summary[:200]}")
    return "\n".join(lines)


# Per-item evidence cap inside the completion nudge. Each item's evidence
# is already capped at _MAX_TEXT_LEN at write time; we cap again here so a
# plan with many items can't blow up the nudge into a multi-thousand-token
# system message that itself competes for attention.
_NUDGE_EVIDENCE_PER_ITEM = 1200


def _plan_complete_nudge(plan: Plan) -> str:
    """Build the 'plan just finished — deliver the result' nudge.

    Inlines each item's collected evidence so the actual data the user
    asked for sits right next to the deliver instruction. Without this,
    the LLM tends to produce a vague "task complete — see above" reply
    even though the original tool output is buried many turns earlier
    in the conversation.
    """
    lines: list[str] = []
    for it in plan.items:
        ev = (it.evidence or "").strip()
        if not ev:
            continue
        if len(ev) > _NUDGE_EVIDENCE_PER_ITEM:
            ev = ev[:_NUDGE_EVIDENCE_PER_ITEM] + " […evidence truncated]"
        lines.append(f"- **{it.title}** — evidence:\n{ev}")
    evidence_block = ""
    if lines:
        evidence_block = (
            "\n\n**Evidence collected during this plan** "
            "(this is the actual data the user asked for; quote or "
            "paraphrase it directly in your reply):\n\n" + "\n\n".join(lines)
        )
    return (
        "\n\n🎯 **All plan items are now done.**"
        + evidence_block
        + "\n\nYour next message MUST be your final assistant reply to "
        "the user, and it MUST contain the actual answer / data the "
        "user asked for — not just a 'task complete / 任务完成' "
        "acknowledgement, and not a vague 'see above / 以上是…' that "
        "points at the plan card. If any item's title was about "
        "reporting / telling / 报告 / 告诉 / 汇报 the user, the "
        "substance of that report goes into the assistant reply "
        "itself — not into another tool call."
    )


# ── Adaptive Card builder for live progress (Teams / Web Chat) ─────────────


def _ac_text(
    text: str,
    *,
    weight: str | None = None,
    size: str | None = None,
    color: str | None = None,
    is_subtle: bool = False,
    spacing: str | None = None,
    wrap: bool = True,
    font_type: str | None = None,
    horizontal_alignment: str | None = None,
) -> dict[str, Any]:
    """Tiny helper to build an Adaptive Card TextBlock dict."""
    block: dict[str, Any] = {"type": "TextBlock", "text": text, "wrap": wrap}
    if weight:
        block["weight"] = weight
    if size:
        block["size"] = size
    if color:
        block["color"] = color
    if is_subtle:
        block["isSubtle"] = True
    if spacing:
        block["spacing"] = spacing
    if font_type:
        block["fontType"] = font_type
    if horizontal_alignment:
        block["horizontalAlignment"] = horizontal_alignment
    return block


# Unicode block characters used to draw the progress bar. ▰ (U+25B0) for
# filled cells, ▱ (U+25B1) for empty — both visually balanced in
# proportional and monospace fonts, so the bar renders the same on
# Teams desktop, Teams web, and Outlook actionable messages.
_BAR_FILLED = "\u25b0"
_BAR_EMPTY = "\u25b1"


def _ac_progress_text(done: int, total: int, *, segments: int = 14) -> dict[str, Any]:
    """Render the progress bar as a single bold monospace TextBlock.

    Avoids the multi-Container approach (which Teams rendered as one
    flat grey strip — the per-cell ``style`` colours were collapsed by
    the host's column compaction). Block characters always render and
    align identically across renderers.
    """
    total_safe = max(total, 1)
    filled = round(segments * done / total_safe)
    bar = _BAR_FILLED * filled + _BAR_EMPTY * (segments - filled)
    pct = round(100 * done / total_safe)
    color = "Good" if done == total else ("Accent" if done > 0 else "Default")
    return _ac_text(
        f"{bar}  {pct}%",
        font_type="Monospace",
        weight="Bolder",
        size="Medium",
        color=color,
        spacing="Medium",
    )


def _ac_item_row(item: PlanItem) -> dict[str, Any]:
    """Render a single plan item as a 2-column row (status pill + title).

    No leading numeric prefix — Adaptive Card's markdown renderer
    re-numbers ordered lists per TextBlock, which made every item show
    up as "1." in Teams. The status pill carries the visual anchor
    instead.
    """
    pill_glyph, _ac_color = _STATUS_PILL.get(item.status, ("\u26aa", "Default"))
    if item.status == "done":
        title_color: str | None = "Good"
        title_subtle = True
        title_weight: str | None = None
        title_text = f"~~{item.title}~~"
    elif item.status == "in_progress":
        title_color = "Accent"
        title_subtle = False
        title_weight = "Bolder"
        title_text = item.title
    elif item.status == "blocked":
        title_color = "Warning"
        title_subtle = False
        title_weight = "Bolder"
        title_text = item.title
    elif item.status == "skipped":
        title_color = "Default"
        title_subtle = True
        title_weight = None
        title_text = f"~~{item.title}~~"
    else:  # not_started
        title_color = None
        title_subtle = True
        title_weight = None
        title_text = item.title

    title_block = _ac_text(
        title_text,
        weight=title_weight,
        color=title_color,
        is_subtle=title_subtle,
    )
    extras: list[dict[str, Any]] = [title_block]
    if item.status == "blocked" and item.note:
        extras.append(
            _ac_text(
                f"\u26a0 {item.note[:120]}",
                color="Warning",
                is_subtle=True,
                spacing="None",
            )
        )
    return {
        "type": "ColumnSet",
        "spacing": "Small",
        "columns": [
            {
                "type": "Column",
                "width": "auto",
                "verticalContentAlignment": "Center",
                "items": [
                    _ac_text(pill_glyph, size="Medium"),
                ],
            },
            {
                "type": "Column",
                "width": "stretch",
                "items": extras,
            },
        ],
    }


# Footer styles — pick a Container `style` that matches the action
# semantics so the action banner reads at a glance.
_FOOTER_STYLE_DEFAULT = "default"
_FOOTER_STYLE_BY_OUTCOME: dict[str, str] = {
    "good": "good",
    "accent": "accent",
    "warning": "warning",
    "attention": "attention",
    "default": "default",
}


def _ac_footer(text: str, style: str) -> dict[str, Any]:
    """Wrap a footer line in a coloured Container — gives it card-pill prominence."""
    return {
        "type": "Container",
        "style": _FOOTER_STYLE_BY_OUTCOME.get(style, _FOOTER_STYLE_DEFAULT),
        "spacing": "Medium",
        "bleed": True,
        "items": [
            _ac_text(text, weight="Bolder", wrap=True),
        ],
    }


def build_progress_card(
    plan: Plan,
    *,
    action: str,
    last_item: PlanItem | None = None,
    last_status: str = "",
    note: str = "",
) -> dict[str, Any]:
    """Build a Bot Framework activity wrapping an Adaptive Card.

    The card is the same dict shape ``teams_cards.wrap_for_teams`` produces
    so the cloud channel's ``_extract_card_from_activity_json`` hoists it
    transparently into the gateway notify body's ``content.card`` field.

    Args:
        plan: The current plan after the action has been applied.
        action: The plan action that triggered this update — drives the
            footer message ("Plan created", "Verified: X", "Plan complete").
        last_item: Item touched by the action (for ``update`` / ``verify``).
        last_status: Outcome string from ``_verify`` ("FAILED" / "PARTIAL"
            / "" for success).
        note: Free-form note (used for checkpoint / report summaries).
    """
    done, total = plan.progress
    is_complete = plan.is_complete
    pct = round(100 * done / max(total, 1))

    # Header band: title + progress fraction badge.
    header_color = "Good" if is_complete else ("Accent" if 0 < done else "Default")
    header_text = "\U0001f4cb \u8ba1\u5212\u8fdb\u5ea6"  # 📋 计划进度
    if action == "create":
        header_text = "\U0001f4cb \u4efb\u52a1\u8ba1\u5212\u5df2\u521b\u5efa"  # 任务计划已创建
    if is_complete:
        header_text = "\U0001f389 \u8ba1\u5212\u5b8c\u6210"  # 🎉 计划完成
    header = {
        "type": "ColumnSet",
        "columns": [
            {
                "type": "Column",
                "width": "stretch",
                "items": [
                    _ac_text(
                        header_text,
                        weight="Bolder",
                        size="Large",
                        color=header_color,
                    ),
                ],
            },
            {
                "type": "Column",
                "width": "auto",
                "verticalContentAlignment": "Center",
                "items": [
                    _ac_text(
                        f"{done}/{total} \u00b7 {pct}%",
                        weight="Bolder",
                        size="Medium",
                        color=header_color,
                        horizontal_alignment="Right",
                    ),
                ],
            },
        ],
    }
    body: list[dict[str, Any]] = [header]

    # Workflow tag line (optional).
    if plan.workflow:
        body.append(
            _ac_text(
                f"workflow \u00b7 {plan.workflow}",
                size="Small",
                is_subtle=True,
                spacing="None",
            )
        )

    # Unicode-block progress bar — single bold monospace TextBlock, so
    # all rendering hosts (Teams desktop / web / mobile, Outlook,
    # bf-emulator) draw it identically.
    body.append(_ac_progress_text(done, total))

    # Item list — emphasis container clusters the rows visually and
    # provides a subtle background tint that separates them from the
    # header / progress bar above.
    body.append(
        {
            "type": "Container",
            "style": "emphasis",
            "spacing": "Medium",
            "items": [_ac_item_row(it) for it in plan.items],
        }
    )

    # Footer: a colour-styled Container so the latest action reads as
    # a prominent banner, not a plain sentence.
    footer_text = ""
    footer_style = "accent"
    if action == "create":
        footer_text = f"\U0001f680 \u5df2\u751f\u6210 {total} \u4e2a\u6b65\u9aa4\uff0c\u5f00\u59cb\u6267\u884c..."
        footer_style = "accent"
    elif action == "update" and last_item is not None:
        if last_item.status == "done":
            footer_text = f"\u2713 \u5df2\u5b8c\u6210\uff1a{last_item.title}"
            footer_style = "good"
        elif last_item.status == "in_progress":
            footer_text = f"\u25b6 \u6b63\u5728\u6267\u884c\uff1a{last_item.title}"
            footer_style = "accent"
        elif last_item.status == "blocked":
            footer_text = f"\u26a0 \u53d7\u963b\uff1a{last_item.title}"
            footer_style = "warning"
        elif last_item.status == "skipped":
            footer_text = f"\u21b7 \u5df2\u8df3\u8fc7\uff1a{last_item.title}"
            footer_style = "default"
        else:
            footer_text = f"\u25cb \u5f85\u529e\uff1a{last_item.title}"
            footer_style = "default"
    elif action == "verify" and last_item is not None:
        if last_status == "FAILED":
            footer_text = f"\u274c \u9a8c\u8bc1\u5931\u8d25\uff1a{last_item.title}"
            footer_style = "attention"
        elif last_status == "PARTIAL":
            footer_text = f"\u26a0 \u9a8c\u8bc1\u90e8\u5206\u901a\u8fc7\uff1a{last_item.title}"
            footer_style = "warning"
        else:
            footer_text = f"\u2705 \u5df2\u9a8c\u8bc1\uff1a{last_item.title}"
            footer_style = "good"
    elif action == "checkpoint" and note:
        footer_text = f"\U0001f4cd \u68c0\u67e5\u70b9\uff1a{note[:160]}"
        footer_style = "accent"
    elif action == "report" and note:
        footer_text = f"\U0001f4e3 \u8fdb\u5ea6\uff1a{note[:160]}"
        footer_style = "accent"

    if is_complete:
        footer_text = (
            "\U0001f389 \u5168\u90e8\u6b65\u9aa4\u5df2\u5b8c\u6210 "
            "\u2014 \u73b0\u5728\u7528\u4e00\u6bb5\u8bdd\u628a\u5b9e\u9645"
            "\u7ed3\u679c\u544a\u8bc9\u7528\u6237\u3002"
        )
        footer_style = "good"

    if footer_text:
        body.append(_ac_footer(footer_text, footer_style))

    card = {
        "type": "AdaptiveCard",
        "$schema": _AC_SCHEMA,
        "version": _AC_VERSION,
        "body": body,
    }
    return {
        "type": "message",
        "attachments": [
            {"contentType": _AC_CONTENT_TYPE, "content": card},
        ],
    }


# ── The Tool ────────────────────────────────────────────────────────────────


class PlanTool(Tool):
    """Structured task plan with persistence and self-verification."""

    risk_range = (0, 2)

    def __init__(self, store: PlanStore | None = None, bus: Any = None) -> None:
        self._store = store or get_plan_store()
        self._session_resolver: Any = None  # set by runtime → returns current session_id
        self._bus = bus  # optional MessageBus — used to push live progress messages

    def set_bus(self, bus: Any) -> None:
        """Inject the message bus so each plan action pushes a live update."""
        self._bus = bus

    def set_session_resolver(self, fn: Any) -> None:
        """Inject a callable returning the *current* session id for the agent.

        The runtime wires this so the LLM doesn't have to pass session_id on
        every call. If unset, callers must pass ``session_id`` explicitly.
        """
        self._session_resolver = fn

    @property
    def name(self) -> str:
        return "plan"

    @property
    def description(self) -> str:
        return (
            "Manage a persistent, structured task plan for long-running work. "
            "Always create a plan first when the task has 3+ steps or follows a workflow SOP. "
            "Actions: "
            "create (start a plan with ordered items), "
            "update (change item status: not_started|in_progress|blocked|done|skipped), "
            "checkpoint (summarize progress and optionally pause for user input), "
            "report (non-blocking progress note), "
            "verify (validate evidence for a 'done' item — prevents false-completes), "
            "show (return the current plan). "
            "Plans persist across sessions and survive restart."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=15, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        action = args.get("action", "")
        if action in ("show", "report"):
            return RiskScore(0, reason="Read-only / informational")
        return RiskScore(1, reason="Local plan-file write")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": [
                        "create",
                        "update",
                        "checkpoint",
                        "report",
                        "verify",
                        "show",
                        "delete",
                    ],
                    "description": "Action to perform.",
                },
                "items": {
                    "type": "array",
                    "description": (
                        "For 'create': ordered list of plan items. Each item: "
                        "{title (required), acceptance (recommended — concrete "
                        "completion criterion), id (optional), depends_on "
                        "(optional list of prior item ids)}."
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "title": {"type": "string"},
                            "acceptance": {"type": "string"},
                            "depends_on": {
                                "type": "array",
                                "items": {"type": "string"},
                            },
                        },
                        "required": ["title"],
                    },
                },
                "workflow": {
                    "type": "string",
                    "description": (
                        "For 'create': SOP name driving this plan (e.g. "
                        "'feature-implement'). Optional."
                    ),
                },
                "id": {
                    "type": "string",
                    "description": "Item id (or 1-based index as string). Required for update/verify.",
                },
                "status": {
                    "type": "string",
                    "enum": list(_VALID_STATUSES),
                    "description": "New status (for 'update').",
                },
                "note": {
                    "type": "string",
                    "description": "Free-form note (for update / blocked items).",
                },
                "evidence": {
                    "type": "string",
                    "description": (
                        "Concrete proof for 'done' items: test output, file diff, "
                        "URL, or shell exit. Required for 'verify'."
                    ),
                },
                "summary": {
                    "type": "string",
                    "description": "For 'checkpoint' or 'report': what just happened.",
                },
                "next_step": {
                    "type": "string",
                    "description": "For 'checkpoint': what you plan to do next.",
                },
                "ask_user": {
                    "type": "boolean",
                    "description": "For 'checkpoint': true = pause and wait for user 'go'.",
                },
                "session_id": {
                    "type": "string",
                    "description": "Optional override; usually auto-resolved.",
                },
                "replace": {
                    "type": "boolean",
                    "description": (
                        "For 'create': if true, replace any existing plan for this "
                        "session. Default false → reject if a plan already exists."
                    ),
                },
            },
            "required": ["action"],
        }

    def validate(self, args: dict[str, Any]) -> list[str]:
        errors: list[str] = []
        action = args.get("action", "")
        if action not in {
            "create",
            "update",
            "checkpoint",
            "report",
            "verify",
            "show",
            "delete",
        }:
            errors.append(f"Unknown action: {action!r}")
        if action == "create":
            items = args.get("items") or []
            if not isinstance(items, list) or not items:
                errors.append("'items' must be a non-empty list for action='create'")
            elif len(items) > _MAX_ITEMS:
                errors.append(f"Too many items (max {_MAX_ITEMS})")
        if action == "update":
            if not args.get("id"):
                errors.append("'id' is required for action='update'")
            status = args.get("status")
            if status and status not in _VALID_STATUSES:
                errors.append(f"Invalid status: {status!r}")
        if action == "verify":
            if not args.get("id"):
                errors.append("'id' is required for action='verify'")
        return errors

    # ── Execution ────────────────────────────────────────────────────────

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "")
        sid = self._resolve_session_id(kwargs)
        if not sid:
            return (
                "Error: cannot resolve current session_id. "
                "Pass session_id explicitly or ensure the runtime wired the resolver."
            )

        try:
            if action == "create":
                result = self._create(sid, kwargs)
            elif action == "update":
                result = self._update(sid, kwargs)
            elif action == "checkpoint":
                result = self._checkpoint(sid, kwargs)
            elif action == "report":
                result = self._report(sid, kwargs)
            elif action == "verify":
                result = self._verify(sid, kwargs)
            elif action == "show":
                result = self._show(sid)
            elif action == "delete":
                result = self._delete(sid)
            else:
                return f"Error: unknown action {action!r}"
        except Exception as exc:  # noqa: BLE001
            logger.exception("Plan tool error")
            return f"Error: {exc}"

        # Push a short live update to the user's channel so they see
        # intermediate progress (not just the final lump). Skip 'show' and
        # the no-op delete; CLI channel already echoes tool output.
        if action not in ("show",):
            await self._push_live_update(sid, action, kwargs, result)
        return result

    async def _push_live_update(
        self, sid: str, action: str, kwargs: dict[str, Any], result: str
    ) -> None:
        """Send a one-line progress message to the originating channel.

        Silent on errors and on channels where it would be redundant (CLI
        already prints tool output inline).
        """
        if self._bus is None:
            return
        if str(result).startswith("Error"):
            return
        channel_raw = kwargs.get("_channel", "")
        channel_id = kwargs.get("_channel_id", "")
        if not channel_raw or not channel_id:
            return
        try:
            from praestoclaw.bus.events import OutboundMessage
            from praestoclaw.config.schema import ChannelType

            ch = ChannelType.of(channel_raw)
            # CLI users already see tool output inline — skip to avoid noise.
            if ch == ChannelType.CLI:
                return
        except Exception:  # noqa: BLE001
            return

        body = self._format_live_update(sid, action, kwargs, result)
        if not body:
            return

        # Build a richer Adaptive Card payload when the originating
        # conversation is on Teams (detected via the inbound metadata
        # source the runtime injected as ``_metadata``). Other surfaces
        # keep the markdown body — Web Chat / web UI already render
        # markdown well enough that the spam is acceptable, and we
        # avoid a routing decision (push_target=teams) on conversations
        # that aren't Teams-originated.
        metadata: dict[str, Any] = {"keep_context": True}
        meta_in = kwargs.get("_metadata") or {}
        source = ""
        if isinstance(meta_in, dict):
            source = str(meta_in.get("source", ""))
        is_teams = source in ("cloud_teams", "teams_bridge")
        outbound_content = body
        if is_teams and ch == ChannelType.CLOUD:
            try:
                activity = self._build_progress_activity(sid, action, kwargs, result)
                if activity is not None:
                    import json as _json

                    outbound_content = _json.dumps(activity, ensure_ascii=False)
                    metadata["push_target"] = "teams"
                    # Pin every progress emit for this plan to the same
                    # Teams activity so the bridge animates one card in
                    # place instead of stacking a new card per tick.
                    # Including ``plan.created_at`` keeps successive plans
                    # in the same session on separate cards (a fresh
                    # ``create`` action gets a fresh activity, then all
                    # its updates / completion overwrite that card).
                    plan = self._store.load(sid)
                    if plan is not None and plan.created_at:
                        metadata["update_key"] = f"plan:{sid}:{plan.created_at}"
            except Exception as exc:  # noqa: BLE001
                logger.debug("Plan progress card build failed (falling back to markdown): {}", exc)

        try:
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=ch,
                    channel_id=channel_id,
                    content=outbound_content,
                    # keep_context=True → cloud channel sends as "notification"
                    # frame so the gateway preserves the conversation reply
                    # context for subsequent updates and the final answer.
                    metadata=metadata,
                )
            )
        except Exception as exc:  # noqa: BLE001
            logger.debug("Plan live-update push failed: {}", exc)

    def _build_progress_activity(
        self, sid: str, action: str, kwargs: dict[str, Any], result: str
    ) -> dict[str, Any] | None:
        """Build a Bot Framework activity dict (with Adaptive Card) for *action*.

        Returns ``None`` when there's nothing to render (no plan, or an
        action that doesn't produce a user-facing card).
        """
        plan = self._store.load(sid)
        if plan is None or not plan.items:
            return None
        last_item: PlanItem | None = None
        last_status = ""
        note = ""
        if action in ("update", "verify"):
            ref = str(kwargs.get("id", ""))
            last_item = self._find_item(plan, ref)
            if action == "verify":
                if "FAILED" in result:
                    last_status = "FAILED"
                elif "PARTIAL" in result:
                    last_status = "PARTIAL"
        elif action == "checkpoint":
            cp = plan.checkpoints[-1] if plan.checkpoints else None
            if cp:
                note = cp.summary
        elif action == "report":
            note = str(kwargs.get("summary", ""))
        return build_progress_card(
            plan,
            action=action,
            last_item=last_item,
            last_status=last_status,
            note=note,
        )

    def _format_live_update(
        self, sid: str, action: str, kwargs: dict[str, Any], result: str
    ) -> str:
        """Render a compact progress message per action. Returns "" to skip."""
        plan = self._store.load(sid)
        if plan is None or not plan.items:
            return ""
        done, total = plan.progress
        header = f"📋 **Plan progress** ({done}/{total})"
        if plan.workflow:
            header += f" — _{plan.workflow}_"

        if action == "create":
            lines = [header, "", "**Todo:**"]
            for i, it in enumerate(plan.items, 1):
                lines.append(f"{i}. ⬜ {it.title}")
            return "\n".join(lines)

        if action == "update":
            ref = str(kwargs.get("id", ""))
            item = self._find_item(plan, ref)
            if not item:
                return ""
            icon = _STATUS_ICON.get(item.status, "[?]")
            line = f"{icon} **{item.title}** → _{item.status}_"
            if item.status == "blocked" and item.note:
                line += f"\n   ⚠ {item.note[:160]}"
            return f"{header}\n{line}"

        if action == "checkpoint":
            cp = plan.checkpoints[-1] if plan.checkpoints else None
            if not cp:
                return ""
            prefix = (
                "🛑 **Checkpoint** — awaiting your input" if cp.asked_user else "📍 **Checkpoint**"
            )
            out = [f"{header}\n{prefix}", f"_{cp.summary[:300]}_"]
            if cp.next_step:
                out.append(f"Next: {cp.next_step[:200]}")
            return "\n".join(out)

        if action == "report":
            summary = str(kwargs.get("summary", "")).strip()[:300]
            if not summary:
                return ""
            return f"{header}\n📣 {summary}"

        if action == "verify":
            ref = str(kwargs.get("id", ""))
            item = self._find_item(plan, ref)
            if not item:
                return ""
            if "FAILED" in result:
                return f"{header}\n❌ Verify failed: **{item.title}** — reset to in_progress"
            if "PARTIAL" in result:
                return f"{header}\n⚠ Verify partial: **{item.title}**"
            return f"{header}\n✅ Verified: **{item.title}**"

        return ""

    # ── Helpers ──────────────────────────────────────────────────────────

    def _resolve_session_id(self, kwargs: dict[str, Any]) -> str:
        # ``_session_id`` is injected by ToolRegistry from the *current
        # turn's* session_id in loop_v2 — trust it above all else. It
        # cannot be stomped by another concurrent loop on the shared
        # PlanTool singleton (unlike ``self._session_resolver`` which is
        # a per-turn lambda set on the singleton and races between
        # cloud / scheduler loops), and the LLM cannot influence it
        # (unlike the public ``session_id`` argument, which we've seen
        # the model populate with arbitrary ULIDs lifted from
        # ``tool_status`` update_keys).
        injected = kwargs.get("_session_id")
        if injected:
            return str(injected)
        if self._session_resolver:
            try:
                resolved = self._session_resolver()
                if resolved:
                    return str(resolved)
            except Exception as exc:  # noqa: BLE001
                logger.debug("Session resolver failed: {}", exc)
        # Last-resort fallback for callers that don't go through
        # ToolRegistry (CLI, tests) and don't wire a session resolver.
        sid = kwargs.get("session_id")
        return str(sid) if sid else ""

    def _find_item(self, plan: Plan, ref: str) -> PlanItem | None:
        # try id match first
        for it in plan.items:
            if it.id == ref:
                return it
        # try 1-based index
        if ref.isdigit():
            idx = int(ref) - 1
            if 0 <= idx < len(plan.items):
                return plan.items[idx]
        return None

    # ── Action implementations ───────────────────────────────────────────

    def _create(self, sid: str, kwargs: dict[str, Any]) -> str:
        items_raw = kwargs.get("items") or []
        replace = bool(kwargs.get("replace"))
        existing = self._store.load(sid)
        if existing and existing.items and not replace:
            done, total = existing.progress
            return (
                f"Error: a plan already exists for this session ({done}/{total} done). "
                "Use action='show' to inspect it, action='update' to advance items, "
                "or pass replace=true to start over."
            )

        items: list[PlanItem] = []
        seen_ids: set[str] = set()
        for raw in items_raw:
            if not isinstance(raw, dict):
                continue
            it = PlanItem.from_dict(raw)
            if not it.title:
                continue
            if it.id in seen_ids:
                it.id = uuid.uuid4().hex[:8]
            seen_ids.add(it.id)
            items.append(it)

        if not items:
            return "Error: no valid items provided."

        plan = Plan(
            session_id=sid,
            items=items,
            workflow=str(kwargs.get("workflow", "")),
            created_at=_now(),
        )
        self._store.save(plan)
        return f"Plan created with {len(items)} item(s).\n" + render_plan(plan)

    def _update(self, sid: str, kwargs: dict[str, Any]) -> str:
        plan = self._store.load(sid)
        if not plan:
            return "Error: no plan exists for this session. Create one first."
        ref = str(kwargs.get("id", ""))
        item = self._find_item(plan, ref)
        if not item:
            return f"Error: item {ref!r} not found."
        new_status = kwargs.get("status")
        note = kwargs.get("note")
        evidence = kwargs.get("evidence")

        if new_status:
            if new_status == "in_progress" and not item.started_at:
                item.started_at = _now()
            if new_status == "done":
                # structural verify gate — prevents 'done' without acceptance evidence
                if item.acceptance and not (evidence or item.evidence):
                    return (
                        f"Refusing to mark item {ref!r} as 'done' without evidence. "
                        "Pass evidence=... (test output / diff / URL) or call "
                        "action='verify' first."
                    )
                item.completed_at = _now()
            item.status = new_status
        if note is not None:
            item.note = str(note)[:_MAX_TEXT_LEN]
        if evidence is not None:
            item.evidence = str(evidence)[:_MAX_TEXT_LEN]
        self._store.save(plan)
        out = f"Updated item {ref}.\n" + render_plan(plan, compact=True)
        # Plan-completion nudge — fires inline in the tool result so the
        # LLM sees it on THIS iteration (active_plan_block is computed
        # once per user turn, so a mid-turn completion would otherwise
        # miss the "deliver the result" reminder until the next turn,
        # by which point the agent has already replied with a useless
        # "task complete" acknowledgement).
        if plan.is_complete:
            out += _plan_complete_nudge(plan)
        return out

    def _checkpoint(self, sid: str, kwargs: dict[str, Any]) -> str:
        plan = self._store.load(sid)
        if not plan:
            return "Error: no plan exists for this session."
        cp = Checkpoint(
            ts=_now(),
            summary=str(kwargs.get("summary", ""))[:_MAX_TEXT_LEN],
            next_step=str(kwargs.get("next_step", ""))[:_MAX_TEXT_LEN],
            asked_user=bool(kwargs.get("ask_user")),
        )
        plan.checkpoints.append(cp)
        self._store.save(plan)
        prefix = "🛑 Checkpoint (waiting for user)" if cp.asked_user else "📍 Checkpoint"
        out = [f"{prefix}: {cp.summary}"]
        if cp.next_step:
            out.append(f"Next: {cp.next_step}")
        if cp.asked_user:
            out.append("\n→ Stop and ask the user before proceeding.")
        return "\n".join(out)

    def _report(self, sid: str, kwargs: dict[str, Any]) -> str:
        plan = self._store.load(sid)
        summary = str(kwargs.get("summary", "")).strip()
        if not summary:
            return "Error: 'summary' is required for action='report'."
        if plan:
            plan.checkpoints.append(Checkpoint(ts=_now(), summary=summary, asked_user=False))
            self._store.save(plan)
        return f"📣 Progress: {summary[:300]}"

    def _verify(self, sid: str, kwargs: dict[str, Any]) -> str:
        plan = self._store.load(sid)
        if not plan:
            return "Error: no plan exists for this session."
        ref = str(kwargs.get("id", ""))
        item = self._find_item(plan, ref)
        if not item:
            return f"Error: item {ref!r} not found."
        evidence = str(kwargs.get("evidence", item.evidence))
        if not evidence.strip():
            return (
                f"Verification FAILED for item {ref}: no evidence provided. "
                "Pass evidence=... with concrete proof (test output, diff, URL)."
            )

        # Heuristic signal scan — catches the most common false-completes.
        if _FAIL_PATTERNS.search(evidence):
            item.status = "in_progress"
            item.note = "Verification failed — evidence contains failure signal."
            item.evidence = evidence[:_MAX_TEXT_LEN]
            self._store.save(plan)
            return (
                f"❌ Verification FAILED for item {ref}: evidence contains a "
                "failure signal (fail/error/traceback). Item reset to in_progress."
            )

        if item.acceptance and item.acceptance.lower() not in evidence.lower():
            # Soft warning — record evidence but flag it
            item.evidence = evidence[:_MAX_TEXT_LEN]
            self._store.save(plan)
            return (
                f"⚠ Verification PARTIAL for item {ref}: evidence does not visibly "
                f"address the acceptance criterion. Acceptance: {item.acceptance[:200]!r}. "
                "Either provide more relevant evidence, or mark status=done explicitly "
                "if you're confident."
            )

        item.evidence = evidence[:_MAX_TEXT_LEN]
        item.status = "done"
        item.completed_at = _now()
        self._store.save(plan)
        out = f"✅ Verified item {ref} as done.\n" + render_plan(plan, compact=True)
        if plan.is_complete:
            out += _plan_complete_nudge(plan)
        return out

    def _show(self, sid: str) -> str:
        plan = self._store.load(sid)
        if not plan or not plan.items:
            return "(no plan for this session)"
        return render_plan(plan)

    def _delete(self, sid: str) -> str:
        if self._store.delete(sid):
            return "Plan deleted."
        return "(no plan to delete)"


# ── Helpers used by the agent loop ──────────────────────────────────────────


def active_plan_block(session_id: str) -> str:
    """Return a system-message body describing the active plan, or "".

    Called by the agent loop on every turn so the LLM never loses sight of
    its own plan, even after compaction.
    """
    if not session_id:
        return ""
    store = get_plan_store()
    plan = store.load(session_id)
    if not plan or not plan.items:
        return ""
    if plan.is_complete:
        # Plan just finished — give the LLM one strong push to actually
        # report the result. Without this, models tend to call
        # plan(update,status=done) on a "report to user" item and then
        # reply with a one-liner like "✅ task complete!" without ever
        # writing the substantive result the user asked for.
        #
        # We re-emit this nudge on every iteration while the plan stays
        # complete. delivered_at is only used to soften the wording on
        # follow-up turns (after the agent has had at least one chance
        # to produce a final reply); the chat history already carries
        # the delivered result so a softer reminder is enough.
        first_time = not plan.delivered_at
        if first_time:
            plan.delivered_at = _now()
            try:
                store.save(plan)
            except Exception as exc:  # noqa: BLE001
                logger.debug("Could not persist plan delivered_at: {}", exc)
        if first_time:
            body = ["## Plan Just Completed (DELIVER THE RESULT)"]
            body.append(render_plan(plan))
            body.append(_plan_complete_nudge(plan).lstrip())
            return "\n".join(body)
        # Soft reminder on subsequent turns — the prior turn already
        # delivered the result; just keep the plan visible as context.
        body = ["## Plan (already completed and delivered)"]
        body.append(render_plan(plan))
        body.append(
            "\nThe result was already delivered in your earlier reply. "
            "If the user is asking a follow-up, answer that — don't "
            "re-emit the original report unless explicitly asked."
        )
        return "\n".join(body)
    body = ["## Active Plan (persistent across turns and sessions)"]
    body.append(render_plan(plan))
    body.append(
        "\nUse plan(action='update', id=..., status=...) to advance items. "
        "Use plan(action='checkpoint', summary=..., ask_user=true) at SOP gates. "
        "Do NOT mark items 'done' without evidence."
    )
    body.append(
        "**Reporting items**: any item whose title contains "
        "'report' / 'tell' / 'show' / 'announce' / '报告' / '告诉' / "
        "'汇报' / '展示' is only complete when your assistant reply for "
        "this turn contains the actual content. Calling "
        "plan(action='update', status='done') is bookkeeping, not "
        "delivery. The user sees your assistant text, not the tool call."
    )
    return "\n".join(body)
