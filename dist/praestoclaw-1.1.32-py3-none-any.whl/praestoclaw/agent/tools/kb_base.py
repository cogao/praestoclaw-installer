"""Shared repository resolution for the knowledge-base tools.

The three KB tools each used to carry their own copy of "map what the model
asked for onto the operator's allowlist". The copies drifted, and all of them
matched by substring — fine when the allowlist held one repository, actively
dangerous once it holds every repository the employee can reach, because a
short word typed in a group chat could select the wrong one and still report
success.

Resolution now lives here, once, and answers a different question than it used
to. The operator's allowlist says what *may* be written to; the group's own
binding (``kb_scope``) says what this conversation actually uses. A tool asks
for "this group's repository" and gets either that, or an explanation of what
is missing — never a guess.
"""

from __future__ import annotations

import hashlib
from dataclasses import replace
from pathlib import Path
from typing import Any

from praestoclaw.kb.draft import (
    STATUS_INITIALIZING,
    CurationTask,
    CurationTaskStore,
    proposal_branch_name,
)
from praestoclaw.kb.repo import KbRepo, KbRepoError, RepoStatus
from praestoclaw.kb.scope import (
    GroupScopeStore,
    KbScope,
    RepoAmbiguousError,
    RepoNotAllowedError,
    allowlist,
    resolve_allowed_repo,
)


def validate_scheduled_scope(
    scopes: GroupScopeStore | None,
    kb_config: Any,
    capability: Any,
) -> KbScope | str:
    """Revalidate a scheduled snapshot against the original conversation binding."""
    if scopes is None:
        return "Error: scheduled KB capability has no scope store wired."
    scope = scopes.read(capability.conversation_id)
    if scope is None:
        return "Error: scheduled KB capability is blocked because its KB scope was cleared."
    try:
        current_repo = resolve_allowed_repo(allowlist(kb_config), scope.repo)
        snapshot_repo = resolve_allowed_repo(allowlist(kb_config), capability.repo)
    except (RepoNotAllowedError, RepoAmbiguousError):
        return "Error: scheduled KB capability targets a repository that is no longer allowed."
    if (
        current_repo != snapshot_repo
        or scope.subfolder != capability.subfolder
        or scope.set_at != capability.scope_set_at
        or (capability.base_branch and scope.base_branch != capability.base_branch)
        or scope.subject_id != capability.subject_id
        or scope.tenant_id != capability.tenant_id
    ):
        return (
            "Error: scheduled KB capability is blocked because the original conversation "
            "scope changed; recreate the scheduled job from that personal Teams chat."
        )
    return scope


class KbToolBase:
    """Configuration, allowlist and group-binding lookup shared by the KB tools."""

    def __init__(self, kb_config: Any = None, scope_store: Any = None) -> None:
        self._config = kb_config
        self._scopes: GroupScopeStore | None = scope_store

    # ── configuration ────────────────────────────────────────────────────

    def _enabled(self) -> bool:
        return bool(getattr(self._config, "enabled", True))

    def _sync_timeout(self) -> int:
        return int(getattr(self._config, "sync_timeout_s", 180) or 180)

    def _allowlist(self) -> list[str]:
        return allowlist(self._config)

    # ── group binding ────────────────────────────────────────────────────

    def _scope(self, cid: str) -> KbScope | None:
        if self._scopes is None or not cid:
            return None
        return self._scopes.read(cid)

    def _fetch_scope(self, cid: str, repo: KbRepo, scope: KbScope | None) -> RepoStatus:
        """Resolve/backfill a conversation's target without checking it out."""
        changed = "Knowledge-base scope changed while fetching; retry this operation."
        if self._scope(cid) != scope:
            raise KbRepoError(changed)
        status = repo.fetch_branch(scope.base_branch if scope else "", timeout=self._sync_timeout())
        if scope and self._scopes:
            if not self._scopes.compare_and_write(
                cid, scope, replace(scope, base_branch=scope.base_branch or status.branch)
            ):
                raise KbRepoError(changed)
        elif self._scope(cid) != scope:
            raise KbRepoError(changed)
        return status

    @staticmethod
    def _worktree_path(repo: KbRepo, task: CurationTask, *, kind: str = "worktrees") -> Path:
        # Teams IDs are long; use a compact directory key for Git for Windows.
        conversation_key = hashlib.sha256(task.cid.encode("utf-8")).hexdigest()[:12]
        return repo.shared_path.parent.parent / kind / repo.slug / conversation_key / task.task_id

    def _task_worktree(self, store: CurationTaskStore, task: CurationTask) -> KbRepo:
        """Open a task worktree, or migrate an unfinished legacy proposal."""
        self._require_initialized_task(task)
        resolved = self._repo_for_task(task.repo)
        if isinstance(resolved, str):
            raise KbRepoError(resolved)
        if task.worktree_path:
            worktree = resolved.at_path(task.worktree_path)
            if not worktree.is_cloned:
                raise KbRepoError(f"Task {task.task_id} worktree is missing; restart this task.")
            if not task.proposal_branch or worktree.branch() != task.proposal_branch:
                raise KbRepoError(
                    f"Task worktree is not on proposal branch {task.proposal_branch!r}; "
                    "restore that branch before accessing this task."
                )
            self._validate_task_head(task, worktree)
            return worktree
        if not task.is_active:
            raise KbRepoError(f"Task {task.task_id} is {task.status}; no draft worktree exists.")
        scope = self._scope(task.cid)
        if scope and self._resolve_entry(scope.repo) != self._resolve_entry(task.repo):
            raise KbRepoError(
                f"Legacy task {task.task_id} repository differs from the binding. Restart this task."
            )
        status = self._fetch_scope(task.cid, resolved, scope)
        if task.base_branch != status.branch:
            raise KbRepoError(
                f"Legacy task {task.task_id} targets {task.base_branch!r}, but the binding "
                f"targets {status.branch!r}. Restart this task; its approval cannot be transferred."
            )
        branch = task.proposal_branch or proposal_branch_name(task.task_id)
        path = self._worktree_path(resolved, task)
        worktree = resolved.migrate_legacy_worktree(
            path, task.base_head, branch, existing_branch=bool(task.proposal_branch)
        )
        task.worktree_path = str(path)
        task.proposal_branch = branch
        store.save(task)
        self._validate_task_head(task, worktree)
        return worktree

    @staticmethod
    def _require_initialized_task(task: CurationTask) -> None:
        if task.status == STATUS_INITIALIZING:
            raise KbRepoError(
                f"Task {task.task_id} creation is incomplete; use kb_draft "
                "with action='cancel' or action='restart' and this task_id to recover."
            )

    @staticmethod
    def _validate_task_head(task: CurationTask, worktree: KbRepo) -> None:
        expected = task.proposal_sha or task.base_head
        if worktree.head() != expected:
            raise KbRepoError(
                f"Task worktree HEAD does not match recorded revision {expected!r}; "
                "restore that revision before accessing this task."
            )

    @staticmethod
    def _pending_publish(task: CurationTask) -> dict[str, Any] | None:
        return next(
            (
                item
                for item in reversed(task.publish_attempts)
                if task.publish_worktree_path
                and item.get("outcome") == "pushing"
                and item.get("worktree_path") == task.publish_worktree_path
            ),
            None,
        )

    def _require_resolved_publish(self, task: CurationTask) -> None:
        if self._pending_publish(task) is not None:
            raise KbRepoError(
                f"Resolve the interrupted publish with kb_publish(task_id='{task.task_id}') "
                "before changing this proposal. You may cancel or restart the task "
                "without resolving the remote outcome."
            )

    def _cleanup_task(self, store: CurationTaskStore, task: CurationTask, repo: KbRepo) -> bool:
        """Remove only this task's worktrees and proposal ref, preserving failures."""
        if task.publish_worktree_path:
            repo.remove_worktree(task.publish_worktree_path, force=True)
            task.publish_worktree_path = ""
            store.save(task)
        if task.worktree_path:
            repo.remove_worktree(task.worktree_path)
            task.worktree_path = ""
            store.save(task)
        else:
            return repo.discard_legacy_proposal(task.proposal_branch, task.base_head)
        return repo.delete_local_branch(task.proposal_branch)

    def _resolve_entry(self, requested: str) -> str | None:
        """Allowlist entry for *requested*, or ``None`` when it is not allowed."""
        try:
            return resolve_allowed_repo(self._allowlist(), requested)
        except (RepoNotAllowedError, RepoAmbiguousError):
            return None

    def _repo_for_group(self, cid: str, requested: str = "") -> KbRepo | str:
        return self._repo_for_scope(self._scope(cid), requested)

    def _repo_for_scope(self, scope: KbScope | None, requested: str = "") -> KbRepo | str:
        """This group's repository, or a message explaining what to do first.

        An explicit *requested* repository is honoured only when it resolves to
        the same entry the group is bound to. Silently working against a
        different repository than the one the group configured is precisely the
        surprise the binding exists to prevent — so a mismatch is reported and
        the group is pointed at ``kb_scope`` to change it deliberately.
        """
        allowed = self._allowlist()
        if not allowed:
            return (
                "No knowledge base is configured for this agent at all. The person "
                "running it has to list one under praesto_tag_exp.kb.repos in "
                "praestoclaw.local.yaml and restart."
            )

        if scope is None:
            return self._unconfigured_message()

        entry = self._resolve_entry(scope.repo)
        if entry is None:
            return (
                f"This group is bound to '{scope.repo}', which is no longer in the "
                "allowed list — it may have been removed from the config. Allowed "
                f"now: {', '.join(allowed)}. Re-configure with kb_scope(action='set')."
            )

        wanted = (requested or "").strip()
        if wanted and self._resolve_entry(wanted) != entry:
            return (
                f"This group's knowledge base is '{entry}', not '{wanted}'. Use the "
                "configured one, or change the binding with kb_scope(action='set') "
                "after the group agrees."
            )
        return KbRepo(entry)

    def _repo_for_scheduled(self, capability: Any, requested: str = "") -> KbRepo | str:
        scope = validate_scheduled_scope(self._scopes, self._config, capability)
        if isinstance(scope, str):
            return scope
        entry = self._resolve_entry(capability.repo)
        if entry is None:
            return "Error: scheduled KB capability repository is no longer allowed."
        wanted = (requested or "").strip()
        if wanted and self._resolve_entry(wanted) != entry:
            return (
                "Error: scheduled KB reads are pinned to the scope captured when the job "
                "was created; recreate the job to use another repository."
            )
        return KbRepo(entry)

    @staticmethod
    def _unconfigured_message() -> str:
        return (
            "This group has not chosen a knowledge base yet, so there is nothing to "
            "work against. Call kb_scope(action='show') to see what may be chosen, "
            "ask the group which repository (and optionally which folder) to use, "
            "and record their answer with kb_scope(action='set')."
        )

    def _repo_for_task(self, task_repo: str) -> KbRepo | str:
        """Repository an in-flight task is pinned to.

        Deliberately resolved against the allowlist rather than the group's
        current binding: a task carries the repository the group reviewed a diff
        against, and re-pointing it because someone re-ran ``kb_scope`` midway
        would publish approved content somewhere nobody approved.
        """
        allowed = self._allowlist()
        entry = self._resolve_entry(task_repo)
        if entry is None:
            return (
                f"This task targets '{task_repo}', which is not an allowed knowledge "
                f"base. Allowed: {', '.join(allowed) or '(none)'}."
            )
        return KbRepo(entry)
