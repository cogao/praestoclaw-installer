"""Bind a group to its knowledge base, and to the folder it prefers inside it.

Configuration used to be agent-level: one operator list served every group, so
a second group with a different knowledge base meant editing a YAML file on the
employee's devbox. This tool moves the *choice* into the conversation that has
to live with it, while leaving the *authorisation* where it was.

The split matters. ``praesto_tag_exp.kb.repos`` still decides what this agent
may ever write to on the lending employee's behalf, and only they can widen it —
``kb_publish`` commits and pushes with their git credentials, so a group message
must never be able to aim that at a new repository. Inside that boundary the
group picks freely, with no approval and no config edit.

A rejected request therefore has to say which of two different things went
wrong, because the fix is different: a repository outside the allowlist needs a
person, whereas a folder that does not exist just needs a better answer.
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import replace
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.agent.tools.kb_base import validate_scheduled_scope
from praestoclaw.kb.repo import KbRepo, KbRepoError
from praestoclaw.kb.scope import (
    GroupScopeStore,
    KbScope,
    RepoAmbiguousError,
    RepoNotAllowedError,
    SubfolderMissingError,
    SubfolderNotADirectoryError,
    allowlist,
    resolve_allowed_repo,
    resolve_subfolder,
)
from praestoclaw.security.kb_curation import (
    kb_curation_read_is_active,
    scheduled_kb_capability,
)
from praestoclaw.security.risk import RiskAssessment, RiskScore

_ACTIONS = ("show", "set", "clear")

# Used when the lending employee's display name is unavailable (no cloud login
# yet, or a test harness). Naming them is better, but an unnamed instruction is
# still actionable — the group knows who runs the bot.
_FALLBACK_ADMIN = "管理员"

# Notify category the cloud channel exempts from the group-chat verbosity gate
# (``channels/cloud.py:_UNDROPPABLE_GROUP_CATEGORIES``). Kept as a literal so
# this tool does not import the channel layer.
_GROUP_NOTICE_CATEGORY = "group_notice"

# Ceiling on the announcement push. It is best-effort: a stuck outbound handler
# must not fail a binding that is already saved.
_NOTICE_TIMEOUT_S = 10


def _notice_text(scope: KbScope, metadata: dict[str, Any] | None = None) -> str:
    """The announcement itself — addressed to the current chat, in its language.

    Deliberately short and correctable: it states what was recorded and invites
    a correction in the same breath, because the conversation is being told
    about a choice it did not explicitly make.
    """
    where = (
        f"，默认写入 `{scope.subfolder}`" if scope.subfolder else "，未指定文件夹，整个仓库都可以写"
    )
    del metadata
    return (
        f"📚 当前的知识库已记为 **{scope.repo}**，目标分支 `{scope.base_branch}`{where}。\n"
        "如果不对，在这里说一声要换成哪个仓库、分支或文件夹，我改。"
    )


class KbScopeTool(Tool):
    """Show, set or clear which knowledge base this group writes to."""

    risk_range = (0, 2)

    def __init__(self, kb_config: Any = None, scope_store: Any = None, bus: Any = None) -> None:
        self._config = kb_config
        self._scopes: GroupScopeStore | None = scope_store
        # Message bus, so a saved binding announces itself to the group rather
        # than depending on the model to mention it (see ``_announce``).
        self._bus = bus

    def set_bus(self, bus: Any) -> None:
        """Inject the message bus so a saved binding is announced to the group."""
        self._bus = bus

    @property
    def name(self) -> str:
        return "kb_scope"

    @property
    def description(self) -> str:
        return (
            "Which knowledge-base repository this group writes to, and which "
            "folder in it the group prefers. Actions: 'show' returns the current "
            "binding (or reports that none is set, with the repositories that may "
            "be chosen); 'set' records repo, branch and optional subfolder after checking "
            "the repository is allowed and the folder really exists, and posts a "
            "short notice to the group naming what was recorded; 'clear' "
            "removes it. Take the repository and folder from what the group said — "
            "asked now, or said earlier in this chat — never from your own "
            "preference. The subfolder is a preference for where work lands, not "
            "a restriction. Omitted fields retain the existing same-repository binding; "
            "branch alone changes its target branch. New bindings use the remote default branch."
        )

    @property
    def metadata(self) -> ToolMetadata:
        # 'set' clones the repository on first use to verify the folder exists.
        return ToolMetadata(timeout=300, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        if str(args.get("action") or "") == "show":
            return RiskScore(0, reason="Read this group's knowledge-base binding")
        return RiskScore(
            2, reason="Record this group's knowledge-base binding (no repository write)"
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": list(_ACTIONS),
                    "description": (
                        "show = current binding; set = record repo/branch/subfolder; clear = forget it."
                    ),
                },
                "repo": {
                    "type": "string",
                    "description": (
                        "For 'set': the repository the group named, as 'owner/name', "
                        "a clone URL, or a bare name when it is unambiguous. "
                        "Omit to retain the current repository."
                    ),
                },
                "subfolder": {
                    "type": "string",
                    "description": (
                        "For 'set': optional repository-relative folder the group "
                        "prefers, any depth (e.g. 'context/teams/atlas'). Omit when "
                        "they did not name one — do not guess. Omitted retains the current "
                        "folder for the same repository; empty means the whole repository."
                    ),
                },
                "branch": {
                    "type": "string",
                    "description": (
                        "For 'set': an existing remote target branch. May be set alone. "
                        "Omitted or blank retains the same repository's branch, "
                        "or detects its remote default if no branch is recorded."
                    ),
                },
            },
            "required": ["action"],
        }

    # ── configuration ────────────────────────────────────────────────────

    def _enabled(self) -> bool:
        return bool(getattr(self._config, "enabled", True))

    def _sync_timeout(self) -> int:
        return int(getattr(self._config, "sync_timeout_s", 180) or 180)

    def _allowed(self) -> list[str]:
        return allowlist(self._config)

    @staticmethod
    def _dump(payload: dict[str, Any]) -> str:
        return json.dumps(payload, ensure_ascii=False, indent=2)

    # ── execution ────────────────────────────────────────────────────────

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata") or {}
        if not kb_curation_read_is_active(metadata):
            return (
                "kb_scope requires a trusted Teams group experiment, a verified personal "
                "Teams turn, or a scheduler-issued KB capability."
            )
        if not self._enabled():
            return "Knowledge-base curation is disabled in this PraestoClaw config."
        if self._scopes is None:
            return "Error: kb_scope has no group store wired."

        scheduled = scheduled_kb_capability(metadata)
        cid = scheduled.conversation_id if scheduled else str(metadata.get("cid") or "").strip()
        if not cid:
            return "Error: kb_scope needs a Teams conversation id on this turn."

        action = str(kwargs.get("action") or "").strip()
        if action not in _ACTIONS:
            return f"Error: action must be one of {', '.join(_ACTIONS)}."

        if scheduled is not None:
            if action != "show":
                return (
                    "Error: scheduled KB capability is read-only; only kb_scope(show) is allowed."
                )
            scope = validate_scheduled_scope(self._scopes, self._config, scheduled)
            if isinstance(scope, str):
                return scope
            return self._dump(
                {
                    "configured": True,
                    "repo": scheduled.repo,
                    "subfolder": scheduled.subfolder,
                    "base_branch": scope.base_branch,
                    "set_by": scope.set_by,
                    "set_at": scope.set_at,
                    "scheduled_read_only": True,
                }
            )

        try:
            if action == "show":
                return self._action_show(cid, metadata)
            if action == "clear":
                return self._action_clear(cid, metadata)
            return await self._action_set(cid, kwargs, metadata)
        except KbRepoError as exc:
            return f"Error: {exc}"

    def _save_scope(self, cid: str, expected: KbScope | None, scope: KbScope) -> KbScope:
        if self._scopes is None:
            return scope
        stored = self._scopes.compare_and_write(cid, expected, scope)
        if stored is None:
            raise KbRepoError("Knowledge-base scope changed; retry this operation.")
        return stored

    def _action_show(self, cid: str, metadata: dict[str, Any]) -> str:
        scope = self._scopes.read(cid) if self._scopes else None
        allowed = self._allowed()
        if scope is None:
            return self._dump(
                {
                    "configured": False,
                    "selectable_repos": allowed,
                    "next_step": (
                        "Ask which knowledge-base repository to use and, "
                        "optionally, which folder inside it — then record the answer "
                        "with kb_scope(action='set'). Do not invent a repository."
                    ),
                }
            )
        if scope.set_at:
            try:
                resolve_allowed_repo(allowed, scope.repo)
            except (RepoNotAllowedError, RepoAmbiguousError):
                pass
            else:
                scope = self._upgrade_personal_identity(cid, scope, metadata)
        return self._dump(
            {
                "configured": True,
                "repo": scope.repo,
                "subfolder": scope.subfolder,
                "base_branch": scope.base_branch,
                "set_by": scope.set_by,
                "set_at": scope.set_at,
                "selectable_repos": allowed,
                "note": (
                    "The subfolder is where work is preferred, not a limit — read its "
                    "rules first and draft there unless the repository's own "
                    "conventions point elsewhere."
                ),
            }
        )

    def _upgrade_personal_identity(
        self, cid: str, scope: KbScope, metadata: dict[str, Any]
    ) -> KbScope:
        """Backfill only the current verified personal chat, never a background scan."""
        ctype = (
            str(metadata.get("ctype") or metadata.get("teams_conversation_type") or "")
            .strip()
            .casefold()
        )
        trusted = metadata.get("_trusted_teams_personal")
        if metadata.get("praesto_tag_exp") or ctype != "personal" or not isinstance(trusted, dict):
            return scope
        subject_id = str(trusted.get("subject_id") or "").strip()
        tenant_id = str(trusted.get("tenant_id") or "").strip()
        if (
            not subject_id
            or not tenant_id
            or (scope.subject_id and scope.subject_id != subject_id)
            or (scope.tenant_id and scope.tenant_id != tenant_id)
            or (scope.subject_id and scope.tenant_id)
            or self._scopes is None
        ):
            return scope
        return self._save_scope(
            cid, scope, replace(scope, subject_id=subject_id, tenant_id=tenant_id)
        )

    def _action_clear(self, cid: str, metadata: dict[str, Any]) -> str:
        del metadata
        if self._scopes and self._scopes.clear(cid):
            return "Knowledge-base binding cleared for the current conversation."
        return "The current conversation had no knowledge-base binding."

    async def _action_set(self, cid: str, kwargs: dict[str, Any], metadata: dict[str, Any]) -> str:
        read_scope = getattr(self._scopes, "read", None)
        existing = read_scope(cid) if callable(read_scope) else None
        original = existing
        requested = str(kwargs.get("repo", existing.repo if existing else "") or "").strip()
        if not requested:
            return (
                "Error: repo is required for 'set'. Ask which knowledge base "
                "to use and pass exactly what they answer."
            )

        allowed = self._allowed()
        try:
            entry = resolve_allowed_repo(allowed, requested)
        except RepoAmbiguousError as exc:
            return (
                f"'{exc.wanted}' matches more than one allowed knowledge base: "
                f"{', '.join(exc.candidates)}. Ask which one they mean and "
                "pass it as 'owner/name'."
            )
        except RepoNotAllowedError:
            return self._not_allowed_message(requested, allowed, metadata)

        try:
            if existing is not None and resolve_allowed_repo(allowed, existing.repo) != entry:
                existing = None
        except (RepoNotAllowedError, RepoAmbiguousError):
            existing = None
        branch = str(kwargs.get("branch") or "").strip() or (
            existing.base_branch if existing else ""
        )
        wanted_subfolder = str(
            kwargs.get("subfolder", existing.subfolder if existing else "") or ""
        )
        repo = KbRepo(entry)

        def validate_target() -> tuple[str, str]:
            status = repo.fetch_branch(branch=branch, timeout=self._sync_timeout())
            with repo.snapshot(status.head) as snapshot:
                return status.branch, resolve_subfolder(snapshot, wanted_subfolder)

        try:
            base_branch, subfolder = await asyncio.to_thread(validate_target)
        except KbRepoError as exc:
            return (
                f"'{entry}' is allowed, but its target branch could not be checked "
                f"and nothing was saved.\n{exc}"
            )
        except SubfolderNotADirectoryError as exc:
            return (
                f"'{exc.subfolder}' is a file in {entry}, not a folder. Name a folder "
                "or leave it out to use the whole repository."
            )
        except SubfolderMissingError as exc:
            return self._missing_subfolder_message(entry, exc)

        trusted_personal = metadata.get("_trusted_teams_personal")
        trusted_identity = trusted_personal if isinstance(trusted_personal, dict) else {}
        if (
            existing is not None
            and existing.subfolder == subfolder
            and (existing.base_branch == base_branch or (not existing.base_branch and not branch))
        ):
            existing = self._save_scope(cid, original, replace(existing, base_branch=base_branch))
            upgraded = self._upgrade_personal_identity(cid, existing, metadata)
            identity_upgraded = upgraded != existing
            existing = upgraded
            return self._dump(
                {
                    "configured": True,
                    "unchanged": True,
                    "identity_upgraded": identity_upgraded,
                    "repo": existing.repo,
                    "subfolder": existing.subfolder,
                    "base_branch": existing.base_branch,
                    "set_by": existing.set_by,
                    "set_at": existing.set_at,
                    "announced_to_group": False,
                    "announced_to_chat": False,
                    "next": (
                        "The existing binding already matches. Do not announce or repeat it; "
                        "continue with the requested task."
                    ),
                }
            )
        scope = KbScope(
            repo=entry,
            subfolder=subfolder,
            base_branch=base_branch,
            set_by=str(metadata.get("sender_name") or "").strip(),
            subject_id=str(trusted_identity.get("subject_id") or "").strip(),
            tenant_id=str(trusted_identity.get("tenant_id") or "").strip(),
        )
        stored = self._save_scope(cid, original, scope)
        logger.info("kb_scope: cid={} repo={} subfolder={}", cid, entry, subfolder)
        announced = await self._announce(stored, kwargs)
        payload = {
            "configured": True,
            "repo": stored.repo,
            "subfolder": stored.subfolder,
            "base_branch": stored.base_branch,
            "set_by": stored.set_by,
            "set_at": stored.set_at,
            "summary": stored.describe(),
            "announced_to_group": announced,
            "announced_to_chat": announced,
            "note": (
                "Saved for this conversation only. The subfolder is the preferred "
                "place for this conversation's knowledge, not a restriction."
            ),
        }
        payload["next"] = (
            "The current chat has been told what was recorded, so do not repeat it — say "
            "what you are doing next. If they correct it, call 'set' again."
            if announced
            else "Tell this conversation which repository, branch and folder "
            "were recorded, so they can correct it if it is wrong."
        )
        return self._dump(payload)

    async def _announce(self, scope: KbScope, kwargs: dict[str, Any]) -> bool:
        """Tell the group which knowledge base was just recorded for them.

        The binding is normally inferred from what the group already said rather
        than put to them as a question, which is convenient and occasionally
        wrong. Announcing it is what keeps "inferred" from becoming "silent":
        the group cannot object to a choice nobody showed them, and asking the
        model to mention it has proved unreliable — it reports the binding when
        the turn happens to be about configuration and omits it when the turn is
        about something else.

        Best-effort. A binding that is already saved must not be undone by a
        stuck channel, so every failure is logged and reported as *not*
        announced, which puts the job back on the model.
        """
        channel_raw = kwargs.get("_channel", "")
        channel_id = str(kwargs.get("_channel_id", "") or "")
        if self._bus is None or not channel_raw or not channel_id:
            return False
        try:
            from praestoclaw.bus.events import OutboundMessage
            from praestoclaw.config.schema import ChannelType

            ch = ChannelType.of(channel_raw)
        except Exception as exc:  # noqa: BLE001
            logger.debug("kb_scope announce: unusable channel {!r} — {}", channel_raw, exc)
            return False

        meta_in = kwargs.get("_metadata") or {}
        source = str(meta_in.get("source", "")) if isinstance(meta_in, dict) else ""
        metadata: dict[str, Any] = {
            # Intermediate: this must not consume the turn's reply slot.
            "keep_context": True,
            # …but the group has to see it, so it is exempt from the verbosity
            # gate that silences ordinary progress chatter.
            "notify_category": _GROUP_NOTICE_CATEGORY,
        }
        if source in ("cloud_teams", "teams_bridge"):
            metadata["push_target"] = "teams"

        try:
            await asyncio.wait_for(
                self._bus.publish_outbound(
                    OutboundMessage(
                        channel=ch,
                        channel_id=channel_id,
                        content=_notice_text(scope, meta_in if isinstance(meta_in, dict) else {}),
                        metadata=metadata,
                    )
                ),
                timeout=_NOTICE_TIMEOUT_S,
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("kb_scope announce failed for {} — {}", scope.repo, exc)
            return False
        return True

    # ── refusals ─────────────────────────────────────────────────────────

    def _not_allowed_message(
        self, requested: str, allowed: list[str], metadata: dict[str, Any]
    ) -> str:
        """Explain that only the profile's owner can widen the allowlist.

        Naming them is the point: the allowlist lives in that person's own
        ``praestoclaw.local.yaml`` on the machine this agent runs on, so an
        instruction that cannot say who to ask is not actionable.
        """
        admin = str(metadata.get("owner_display_name") or "").strip() or _FALLBACK_ADMIN
        lines = [
            f"'{requested}' is not a knowledge base this agent may write to, so nothing was saved.",
            "",
            f"To use it, {admin} has to add it on the machine running this agent — "
            "in praestoclaw.local.yaml under praesto_tag_exp.kb.repos — and restart. "
            "Ask them, then configure again.",
        ]
        if allowed:
            lines += ["", f"Available right now: {', '.join(allowed)}."]
        else:
            lines += [
                "",
                "No knowledge base is configured at all yet, so every repository "
                "needs that same step first.",
            ]
        return "\n".join(lines)

    @staticmethod
    def _missing_subfolder_message(entry: str, exc: SubfolderMissingError) -> str:
        """A folder that does not exist is re-asked, never created on a guess.

        Predictability is the whole reason the binding exists: later work is
        supposed to land somewhere the group already agreed on. Curation may
        still propose a *new* area when the repository's rules call for one —
        that decision goes through the group's own review, not through a
        silently invented binding.
        """
        where = f"{entry}/{exc.existing_at}" if exc.existing_at else entry
        lines = [
            f"'{exc.subfolder}' does not exist in {entry}, so nothing was saved.",
            f"The path exists as far as {where}.",
        ]
        if exc.siblings:
            lines.append(f"Folders there: {', '.join(exc.siblings)}.")
        else:
            lines.append("There are no subfolders at that level.")
        lines.append(
            "Ask them to name an existing folder, or to leave it out and use the whole repository."
        )
        return "\n".join(lines)
