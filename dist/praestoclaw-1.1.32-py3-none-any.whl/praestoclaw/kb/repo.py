"""Local git working copies of the knowledge-base repositories.

Why a real clone rather than the GitHub API: the curation stage has to read a
repository's *current* rules — its READMEs, CONTRIBUTING, conventions and the
neighbouring documents it is about to sit beside — and those rules change. A
checkout makes that a filesystem read instead of dozens of API calls, and it is
the same artefact a future text/embedding index will be built over.

Credentials are deliberately **not** configured here. This runs on an enrolled
devbox whose git already has whatever helper the org mandates, so a PAT in
config or a `gh` shell-out would just be a second, worse copy of a thing that
already works. Git remote operations use that helper normally; the optional
GitHub Draft PR mirror reads the same already-cached credential without
prompting. Every operation has prompts disabled and a bounded timeout, and a
refusal is reported as :class:`KbAuthRequiredError` telling the human to
authenticate once, manually, on this machine. A hung credential dialog can
never stall a group turn.

Every function here is blocking. Call them from a tool with
``asyncio.to_thread`` so a clone cannot stall the event loop.
"""

from __future__ import annotations

import hashlib
import os
import re
import shutil
import stat
import subprocess
import tempfile
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from threading import Lock, RLock
from types import TracebackType
from urllib.parse import urlparse, urlsplit, urlunsplit

from loguru import logger

from praestoclaw.kb import repos_dir

DEFAULT_TIMEOUT_S = 120
PROBE_TIMEOUT_S = 30

# Tool calls run in worker threads and construct independent KbRepo instances.
# Key by the shared clone, so worktrees and all instances use the same lock.
_REPO_LOCKS: dict[str, RLock] = {}
_REPO_LOCKS_GUARD = Lock()

_SLUG_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")
_OWNER_NAME = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")
# Checkout directory names are capped because a branch ref becomes a path
# beneath them; see remote_slug.
_MAX_SLUG_LEN = 64

# Prompts off, everywhere. Without this a missing credential opens a dialog on
# the lending employee's desktop and the turn blocks until someone notices it.
_NONINTERACTIVE_ENV = {
    "GIT_TERMINAL_PROMPT": "0",
    "GIT_OPTIONAL_LOCKS": "0",
    "GCM_INTERACTIVE": "never",
}
_NONINTERACTIVE_ARGS = (
    "-c",
    "credential.interactive=false",
    "-c",
    "core.longpaths=true",
)

# Curation content is normalized to LF before it reaches the managed checkout.
# Ignore machine-wide Windows autocrlf/safecrlf settings while staging so Git
# records those exact bytes instead of rejecting them or translating them.
_CANONICAL_TEXT_ARGS = (
    "-c",
    "core.autocrlf=false",
    "-c",
    "core.safecrlf=false",
)

# Substrings that mean "the remote refused us", as opposed to a transport or
# repository-state problem. GitHub answers an unauthenticated request for a
# private repository with "Repository not found", so that phrasing has to be
# treated as an auth signal too — reporting it as "missing" would send the user
# looking for the wrong problem.
_AUTH_MARKERS = (
    "could not read username",
    "could not read password",
    "terminal prompts disabled",
    "authentication failed",
    "invalid username or password",
    "permission denied",
    "access rights",
    "403 forbidden",
    "repository not found",
    "not found: https",
    "no such device or address",
)

# Identity used only when the machine has no git identity configured at all.
_FALLBACK_AUTHOR_NAME = "PraestoClaw"
_FALLBACK_AUTHOR_EMAIL = "praestoclaw@users.noreply.github.com"

# ``scheme://user:password@`` — the password half only. The username is kept
# (see ``_redact_passwords``); the match stops at the first ``@`` so a path or
# query containing ``@`` cannot extend it.
_URL_PASSWORD = re.compile(r"(?P<prefix>[A-Za-z][A-Za-z0-9+.\-]*://[^/\s:@]+):[^/\s@]*@")


def _strip_userinfo(url: str) -> str:
    """Drop any ``user`` / ``user:password`` prefix from an http(s) URL.

    A clone URL may legitimately carry a username — someone with several
    accounts on the same host pins one so git stops picking the wrong identity
    and opening a login prompt. That belongs in the remote, not in a link: the
    review URL for a staged commit is posted into a group chat, where the
    username is noise at best. A URL carrying a *password* or token there would
    be worse than noise, and this is the one place such a URL is handed to
    people.

    Only the authority is touched; path, query and fragment are left alone.
    """
    parts = urlsplit(url)
    if not parts.username and not parts.password:
        return url
    host = parts.hostname or ""
    if parts.port:
        host = f"{host}:{parts.port}"
    return urlunsplit((parts.scheme, host, parts.path, parts.query, parts.fragment))


def _redact_passwords(text: str) -> str:
    """Blank out ``:password@`` inside any URL in *text*, keeping the username.

    Used on what we quote back to a human: our own error messages and git's
    stderr, both of which echo the remote URL and can end up relayed into a
    group chat. Unlike :func:`_strip_userinfo` the username survives, because
    these messages tell someone to run ``git ls-remote <url>`` themselves and
    the pinned username is exactly what makes that command reproduce the
    failure on a machine with several accounts.

    Operates on free text rather than a parsed URL: git's stderr is prose with
    a URL somewhere inside it. The password is removed rather than masked, so
    the command in the message stays runnable — with no password in the URL git
    falls back to the prompt, which is what the message asks the human to do.
    """
    return _URL_PASSWORD.sub(r"\g<prefix>@", text or "")


class KbRepoError(RuntimeError):
    """A knowledge-base repository operation failed."""


class GitUnavailableError(KbRepoError):
    """``git`` is not installed or not on PATH."""


class KbAuthRequiredError(KbRepoError):
    """The remote refused the request; a human must authenticate once."""


class KbDirtyError(KbRepoError):
    """The checkout has local modifications that were not made by this flow."""


class KbPathError(KbRepoError):
    """A path escaped the checkout."""


@dataclass(frozen=True, slots=True)
class GitResult:
    """Outcome of one git invocation."""

    args: tuple[str, ...]
    returncode: int
    stdout: str
    stderr: str

    @property
    def ok(self) -> bool:
        return self.returncode == 0

    @property
    def message(self) -> str:
        return (self.stderr.strip() or self.stdout.strip()).strip()


@dataclass(frozen=True, slots=True)
class RepoStatus:
    """What the local checkout looks like right now."""

    slug: str
    remote_url: str
    path: str
    exists: bool
    branch: str = ""
    head: str = ""
    dirty: bool = False
    ahead: int = 0
    behind: int = 0

    def to_dict(self) -> dict[str, object]:
        return {
            "slug": self.slug,
            "remote_url": self.remote_url,
            "path": self.path,
            "exists": self.exists,
            "branch": self.branch,
            "head": self.head,
            "dirty": self.dirty,
            "ahead": self.ahead,
            "behind": self.behind,
        }


def normalize_remote(remote: str) -> str:
    """Accept ``owner/name``, a full URL, or a local path → clone source."""
    value = (remote or "").strip()
    if not value:
        raise ValueError("remote is required")
    if value.startswith(("http://", "https://", "ssh://", "git@", "file://")):
        return value
    if _OWNER_NAME.match(value):
        return f"https://github.com/{value}.git"
    # A local path is a legitimate git remote (and the only kind a test can use
    # without a network). Accept it only when it actually exists, so a typo in
    # an owner/name reference still fails loudly instead of becoming a path.
    candidate = Path(value).expanduser()
    if candidate.exists():
        return str(candidate.resolve())
    raise ValueError(
        f"Unrecognised repository reference {remote!r}. "
        "Use 'owner/name', a full clone URL, or an existing local path."
    )


def remote_slug(remote_url: str) -> str:
    """``https://github.com/gim-home/Kb.git`` → ``github.com__gim-home__Kb``.

    Host is part of the slug on purpose: two forges can host the same
    ``owner/name`` pair, and a checkout of the wrong one would be a silent,
    confusing failure rather than a loud one.
    """
    url = remote_url.strip()
    if url.startswith("git@"):
        host, _, path = url[4:].partition(":")
    elif "://" in url:
        parsed = urlparse(url)
        host = parsed.netloc
        path = parsed.path
    else:
        # Local path remote: no host, so the trailing components carry the name.
        host = ""
        path = Path(url).as_posix()
    host = host.split("@")[-1]
    path = path.strip("/")
    if path.endswith(".git"):
        path = path[: -len(".git")]
    parts = [part for part in (host, *path.split("/")) if part and part not in (".", "..")]
    parts = [part for part in parts if not re.fullmatch(r"[A-Za-z]:", part)]
    if not parts:
        raise ValueError(f"Cannot derive a directory name from {remote_url!r}")
    slug = "__".join(_SLUG_UNSAFE.sub("_", part).strip("_.") or "_" for part in parts)
    if len(slug) <= _MAX_SLUG_LEN:
        return slug
    # A ref name becomes a path under .git/refs/heads, so an over-long checkout
    # directory can push a perfectly ordinary branch past the Windows path
    # limit. Truncate, but keep a digest of the full URL so two long remotes
    # cannot collide onto one checkout.
    digest = hashlib.sha1(remote_url.encode("utf-8")).hexdigest()[:8]  # noqa: S324
    return f"{slug[: _MAX_SLUG_LEN - 9].rstrip('_')}-{digest}"


def git_executable() -> str:
    """Return the git executable, or explain that it is missing."""
    found = shutil.which("git")
    if not found:
        raise GitUnavailableError(
            "git is not installed or not on PATH, so the knowledge base cannot be "
            "checked out. Install git on this machine and retry."
        )
    return found


def _auth_hint(remote_url: str, detail: str) -> str:
    # Both halves quote a URL back at a human — ours, and git's own stderr,
    # which names the remote it was refused by. The username stays so the
    # command reproduces the failure on a machine with several accounts; any
    # password does not.
    url = _redact_passwords(remote_url)
    return (
        f"git was refused by {url}. This session will not guess or store "
        "credentials. Sign in once, by hand, on this machine — for example run "
        f"`git ls-remote {url}` in a terminal and complete the prompt (or "
        "`gh auth login`) — then ask again.\n"
        f"git said: {_redact_passwords(detail)}"
    )


def _is_auth_failure(text: str) -> bool:
    lowered = (text or "").lower()
    return any(marker in lowered for marker in _AUTH_MARKERS)


def _relabel_diff(diff: str, rel: str, *, created: bool) -> str:
    """Rewrite ``--no-index`` temp paths back to the repository-relative name.

    Without this the group would be asked to approve a diff whose header points
    at a temporary directory — technically correct and completely unreadable.
    ``created`` is passed in rather than sniffed out of the text: the temp
    filename is an implementation detail and matching on it would break the
    header the moment that detail changes.
    """
    if not diff.strip():
        return ""
    lines: list[str] = []
    for line in diff.splitlines():
        if line.startswith("diff --git "):
            lines.append(f"diff --git a/{rel} b/{rel}")
            if created:
                lines.append("new file mode 100644")
        elif line.startswith("index ") and created:
            lines.append("index 0000000..0000000")
        elif line.startswith("--- "):
            lines.append("--- /dev/null" if created else f"--- a/{rel}")
        elif line.startswith("+++ "):
            lines.append(f"+++ b/{rel}")
        else:
            lines.append(line)
    return "\n".join(lines) + "\n"


def _rmtree_managed(path: Path) -> None:
    """Remove a managed Git tree, clearing Windows read-only object bits."""

    def _clear_readonly(
        func: Callable[..., object],
        target: str,
        exc_info: tuple[type[BaseException], BaseException, TracebackType | None],
    ) -> None:
        del exc_info
        os.chmod(target, stat.S_IWRITE | stat.S_IREAD)
        func(target)

    # ``onexc`` was added after Python 3.11; ``onerror`` keeps the managed
    # checkout recovery path compatible with the project's minimum version.
    shutil.rmtree(path, onerror=_clear_readonly)


class KbRepo:
    """One knowledge-base repository, checked out inside the profile."""

    def __init__(self, remote: str, *, root: Path | None = None) -> None:
        self.remote_url = normalize_remote(remote)
        self.slug = remote_slug(self.remote_url)
        self._root = root or repos_dir()
        self.shared_path = self._root / self.slug
        self.path = self.shared_path
        key = os.path.normcase(str(self.shared_path.resolve()))
        with _REPO_LOCKS_GUARD:
            self._shared_lock = _REPO_LOCKS.setdefault(key, RLock())

    def at_path(self, path: str | Path) -> KbRepo:
        """Select a worktree while retaining the shared clone and remote."""
        repo = KbRepo(self.remote_url, root=self._root)
        repo.path = Path(path)
        return repo

    # ── plumbing ────────────────────────────────────────────────────────

    def _run(
        self,
        *args: str,
        cwd: Path | None = None,
        timeout: int = DEFAULT_TIMEOUT_S,
        check: bool = True,
    ) -> GitResult:
        """Run one git command with prompts disabled and a bounded timeout."""
        exe = git_executable()
        env = {**os.environ, **_NONINTERACTIVE_ENV}
        cmd = [exe, *_NONINTERACTIVE_ARGS, *args]
        try:
            completed = subprocess.run(  # noqa: S603 - fixed executable, list args
                cmd,
                cwd=str(cwd) if cwd else None,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout,
                env=env,
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            raise KbRepoError(
                f"git {_redact_passwords(' '.join(args))} timed out after {timeout}s. "
                "If a credential dialog is waiting on this machine, complete it and retry."
            ) from exc
        result = GitResult(
            args=tuple(args),
            returncode=completed.returncode,
            stdout=completed.stdout or "",
            stderr=completed.stderr or "",
        )
        if check and not result.ok:
            # ``args`` carries the remote URL for clone/ls-remote/push, and git's
            # own stderr names it too — so both halves are redacted before they
            # become an error a human (or a group chat) sees.
            if _is_auth_failure(result.message):
                raise KbAuthRequiredError(_auth_hint(self.remote_url, result.message))
            raise KbRepoError(
                f"git {_redact_passwords(' '.join(args))} failed: "
                f"{_redact_passwords(result.message)}"
            )
        return result

    def _git_in_repo(self, *args: str, **kwargs: object) -> GitResult:
        return self._run(*args, cwd=self.path, **kwargs)  # type: ignore[arg-type]

    @property
    def is_cloned(self) -> bool:
        return (self.path / ".git").exists()

    # ── inspection ──────────────────────────────────────────────────────

    def probe(self) -> GitResult:
        """Ask the remote whether we may read it, without cloning anything.

        This is the whole credential strategy: try, and let the failure carry
        the instruction. Raises :class:`KbAuthRequiredError` when the remote
        refuses.
        """
        return self._run(
            "ls-remote",
            "--heads",
            self.remote_url,
            timeout=PROBE_TIMEOUT_S,
        )

    def head(self) -> str:
        return self._git_in_repo("rev-parse", "HEAD").stdout.strip()

    def branch(self) -> str:
        return self._git_in_repo("rev-parse", "--abbrev-ref", "HEAD").stdout.strip()

    def origin_url(self) -> str:
        """Return the clone's effective origin, including any account hint."""
        result = self._git_in_repo("remote", "get-url", "origin", check=False)
        return result.stdout.strip() if result.ok and result.stdout.strip() else self.remote_url

    def is_dirty(self) -> bool:
        return bool(self._git_in_repo("status", "--porcelain").stdout.strip())

    def _ahead_behind(self) -> tuple[int, int]:
        """``(ahead, behind)`` versus the upstream, or ``(0, 0)`` if unknown."""
        result = self._git_in_repo(
            "rev-list", "--left-right", "--count", "HEAD...@{u}", check=False
        )
        if not result.ok:
            return (0, 0)
        parts = result.stdout.split()
        if len(parts) != 2:
            return (0, 0)
        try:
            return (int(parts[0]), int(parts[1]))
        except ValueError:
            return (0, 0)

    def status(self) -> RepoStatus:
        if not self.is_cloned:
            return RepoStatus(
                slug=self.slug,
                remote_url=self.remote_url,
                path=str(self.path),
                exists=False,
            )
        ahead, behind = self._ahead_behind()
        return RepoStatus(
            slug=self.slug,
            remote_url=self.remote_url,
            path=str(self.path),
            exists=True,
            branch=self.branch(),
            head=self.head(),
            dirty=self.is_dirty(),
            ahead=ahead,
            behind=behind,
        )

    # ── synchronisation ─────────────────────────────────────────────────

    def ensure_clone(self, *, timeout: int = DEFAULT_TIMEOUT_S) -> RepoStatus:
        """Create the shared clone if missing; leave existing checkouts alone."""
        with self._shared_lock:
            shared = self.at_path(self.shared_path)
            if not shared.is_cloned:
                self.shared_path.parent.mkdir(parents=True, exist_ok=True)
                self._run("clone", "--", self.remote_url, str(self.shared_path), timeout=timeout)
                logger.info("kb: cloned {} into {}", self.remote_url, self.shared_path)
            return shared.status()

    def default_branch(self, *, timeout: int = DEFAULT_TIMEOUT_S) -> str:
        """Query the remote HEAD, independent of any local checkout or cached ref."""
        shared = self.at_path(self.shared_path)
        remote = shared.origin_url() if shared.is_cloned else self.remote_url
        result = self._run("ls-remote", "--symref", remote, "HEAD", timeout=timeout)
        for line in result.stdout.splitlines():
            if line.startswith("ref: refs/heads/") and line.endswith("\tHEAD"):
                return line.removeprefix("ref: refs/heads/").split("\t", 1)[0]
        raise KbRepoError("The remote HEAD does not identify a default branch.")

    def _validate_branch_name(self, branch: str) -> None:
        """Accept one literal branch name, never refspec syntax or checkout shorthand."""
        invalid = KbRepoError(f"Invalid branch name: {branch!r}.")
        if "\0" in branch:
            raise invalid
        result = self._run("check-ref-format", "--branch", branch, check=False)
        if not result.ok or result.stdout.rstrip("\r\n") != branch:
            raise invalid

    def fetch_branch(self, branch: str = "", *, timeout: int = DEFAULT_TIMEOUT_S) -> RepoStatus:
        """Fetch a target branch without moving any worktree's HEAD or index."""
        with self._shared_lock:
            branch = branch or self.default_branch(timeout=timeout)
            self._validate_branch_name(branch)
            self.ensure_clone(timeout=timeout)
            shared = self.at_path(self.shared_path)
            ref = f"refs/remotes/origin/{branch}"
            shared._git_in_repo(
                "fetch",
                "--no-write-fetch-head",
                "origin",
                f"+refs/heads/{branch}:{ref}",
                timeout=timeout,
            )
            return RepoStatus(
                slug=self.slug,
                remote_url=self.remote_url,
                path=str(self.path),
                exists=True,
                branch=branch,
                head=shared._git_in_repo("rev-parse", ref).stdout.strip(),
            )

    @contextmanager
    def reserve_worktree(self, path: str | Path, branch: str) -> Iterator[None]:
        """Check a new task key and hold shared administration until creation."""
        with self._shared_lock:
            shared = self.at_path(self.shared_path)
            if (
                Path(path).exists()
                or shared._git_in_repo(
                    "show-ref", "--verify", "--quiet", f"refs/heads/{branch}", check=False
                ).ok
            ):
                raise FileExistsError(f"Task worktree or branch already exists: {branch}")
            yield

    def migrate_legacy_worktree(
        self, path: str | Path, base: str, branch: str, *, existing_branch: bool
    ) -> KbRepo:
        with self._shared_lock:
            if existing_branch:
                self._detach_legacy_proposal(branch, base)
            return self.create_worktree(path, base, branch, existing_branch=existing_branch)

    def discard_legacy_proposal(self, branch: str, base: str) -> bool:
        with self._shared_lock:
            self._detach_legacy_proposal(branch, base)
            return self.delete_local_branch(branch)

    def _detach_legacy_proposal(self, branch: str, base: str) -> None:
        # Callers hold the shared lock across this probe and their next mutation.
        if branch and self.branch() == branch:
            if self.is_dirty():
                raise KbRepoError("Legacy proposal checkout has local edits; cannot move it.")
            self.checkout(base)

    def create_worktree(
        self,
        path: str | Path,
        base: str,
        branch: str = "",
        *,
        existing_branch: bool = False,
    ) -> KbRepo:
        """Create a detached snapshot, a new task branch, or attach an existing one."""
        with self._shared_lock:
            path = Path(path).resolve()
            path.parent.mkdir(parents=True, exist_ok=True)
            args = ["worktree", "add"]
            if existing_branch:
                args.extend([str(path), branch])
            elif branch:
                args.extend(["-b", branch, str(path), base])
            else:
                args.extend(["--detach", str(path), base])
            self.at_path(self.shared_path)._git_in_repo(*args)
            return self.at_path(path)

    def remove_worktree(self, path: str | Path, *, force: bool = False) -> None:
        """Remove a worktree through Git; propagate cleanup errors to the caller."""
        with self._shared_lock:
            path = Path(path).resolve()
            shared = self.at_path(self.shared_path)
            registered = [
                Path(line.removeprefix("worktree ")).resolve()
                for line in shared._git_in_repo(
                    "worktree", "list", "--porcelain"
                ).stdout.splitlines()
                if line.startswith("worktree ")
            ]
            # Paths are persisted before creation and cleared after removal. Either
            # transition can be interrupted without leaving a registered worktree.
            if path not in registered and not path.exists():
                return
            args = ["worktree", "remove"]
            if force:
                args.append("--force")
            args.append(str(path))
            shared._git_in_repo(*args)

    @contextmanager
    def snapshot(self, base: str) -> Iterator[KbRepo]:
        """Read a fixed commit in an independent temporary detached worktree."""
        with tempfile.TemporaryDirectory(prefix="kb-snapshot-") as directory:
            path = Path(directory) / "tree"
            repo = self.create_worktree(path, base)
            try:
                yield repo
            finally:
                self.remove_worktree(path, force=True)

    def sync(self, *, timeout: int = DEFAULT_TIMEOUT_S) -> RepoStatus:
        """Clone if absent, otherwise fast-forward to the remote.

        A full clone, not a shallow one: the curation stage compares against
        history, and a future index wants the same objects. Fast-forward only —
        this flow must never invent a merge commit in a shared knowledge base.
        """
        with self._shared_lock:
            if not self.is_cloned:
                if self.path.exists() and any(self.path.iterdir()):
                    raise KbRepoError(
                        f"{self.path} exists but is not a git checkout. Remove it and retry."
                    )
                self.path.parent.mkdir(parents=True, exist_ok=True)
                self._run(
                    "clone",
                    "--",
                    self.remote_url,
                    str(self.path),
                    timeout=max(timeout, DEFAULT_TIMEOUT_S),
                )
                logger.info("kb: cloned {} into {}", self.remote_url, self.path)
                return self.status()

            self._git_in_repo("fetch", "--prune", "origin", timeout=timeout)
            ahead, behind = self._ahead_behind()
            if behind and not self.is_dirty():
                self._git_in_repo("merge", "--ff-only", "@{u}", timeout=timeout)
                logger.info("kb: fast-forwarded {} ({} commits)", self.slug, behind)
            elif behind:
                logger.warning(
                    "kb: {} is {} commits behind but has local edits — left as is",
                    self.slug,
                    behind,
                )
            return self.status()

    # ── publishing ──────────────────────────────────────────────────────

    def _author_args(self) -> list[str]:
        """Use the machine's git identity; fall back only when it has none."""
        name = self._git_in_repo("config", "user.name", check=False).stdout.strip()
        email = self._git_in_repo("config", "user.email", check=False).stdout.strip()
        if name and email:
            return []
        logger.warning(
            "kb: no git identity configured for {} — committing as {}",
            self.slug,
            _FALLBACK_AUTHOR_EMAIL,
        )
        return [
            "-c",
            f"user.name={name or _FALLBACK_AUTHOR_NAME}",
            "-c",
            f"user.email={email or _FALLBACK_AUTHOR_EMAIL}",
        ]

    def commit(self, paths: list[str], message: str) -> str:
        """Stage *paths* and commit them. Returns the new commit sha.

        Only the listed paths are staged, so an unrelated stray file in the
        checkout can never ride along into a shared knowledge base.
        """
        if not paths:
            raise KbRepoError("commit needs at least one path.")
        if not message.strip():
            raise KbRepoError("commit needs a message.")
        self._git_in_repo(*_CANONICAL_TEXT_ARGS, "add", "--", *paths)
        staged = self._git_in_repo("diff", "--cached", "--name-only").stdout.strip()
        if not staged:
            raise KbRepoError("Nothing to commit — the staged content matches HEAD.")
        self._run(*self._author_args(), "commit", "-m", message, cwd=self.path)
        return self.head()

    def push(self, *, timeout: int = DEFAULT_TIMEOUT_S) -> str:
        """Push the current branch to its origin counterpart."""
        branch = self.branch()
        if not branch or branch == "HEAD":
            raise KbRepoError("Cannot push a detached HEAD.")
        return self.push_to(branch, timeout=timeout)

    def push_to(
        self, branch: str, *, expected_head: str = "", timeout: int = DEFAULT_TIMEOUT_S
    ) -> str:
        """Publish HEAD, including detached HEAD, to an explicit target branch."""
        if expected_head:
            self._validate_branch_name(branch)
            # The explicit lease guards deletion and rewind as well as forward
            # movement; require a descendant locally so it cannot force history.
            self._git_in_repo("merge-base", "--is-ancestor", expected_head, "HEAD")
            self._git_in_repo(
                "push",
                f"--force-with-lease=refs/heads/{branch}:{expected_head}",
                "origin",
                f"HEAD:refs/heads/{branch}",
                timeout=timeout,
            )
        else:
            self.push_ref("HEAD", branch, timeout=timeout)
        return branch

    def remote_contains(self, sha: str, branch: str, *, timeout: int = DEFAULT_TIMEOUT_S) -> bool:
        """Check whether a refreshed remote branch already contains a commit."""
        status = self.fetch_branch(branch, timeout=timeout)
        result = self.at_path(self.shared_path)._git_in_repo(
            "merge-base", "--is-ancestor", sha, status.head, check=False
        )
        if result.returncode not in (0, 1):
            raise KbRepoError(f"git merge-base failed: {result.message}")
        return result.ok

    # ── proposal branches ───────────────────────────────────────────────

    def start_branch(self, branch: str, base: str) -> None:
        """Create (or reset) *branch* at *base* and check it out."""
        if not branch.strip():
            raise KbRepoError("a branch name is required.")
        with self._shared_lock:
            self._git_in_repo("checkout", "-B", branch, base or "HEAD")

    def checkout(self, branch: str) -> None:
        with self._shared_lock:
            self._git_in_repo("checkout", branch)

    def squash_merge(self, branch: str) -> None:
        """Stage *branch* as one squashed change on the current branch.

        Proposal branches stay local. Publish first updates the real branch,
        then uses this operation to turn the complete proposal into the single
        commit that is pushed.
        """
        if not branch.strip():
            raise KbRepoError("a proposal branch is required.")
        self._run(
            *self._author_args(),
            "merge",
            "--squash",
            "--no-commit",
            branch,
            cwd=self.path,
        )

    def push_ref(self, sha: str, branch: str, *, force: bool = False, timeout: int = 120) -> None:
        """Push one commit to ``refs/heads/<branch>`` on origin.

        ``force`` exists for the scratch branch, which this flow owns outright
        and rewrites on every restage. Publishing never forces: a push to the
        real branch that is not a fast-forward means the knowledge base moved,
        and that has to fail loudly rather than overwrite someone.
        """
        self._validate_branch_name(branch)
        spec = f"{'+' if force else ''}{sha}:refs/heads/{branch}"
        self._git_in_repo("push", "origin", spec, timeout=timeout)

    def delete_local_branch(self, branch: str) -> bool:
        """Delete a local proposal branch and report whether it is gone.

        Publishing treats cleanup as best-effort, while replacing an unfinished
        proposal must be fail-closed: the new task may not start while the old
        branch still exists.  Returning the verified outcome supports both
        callers without making publish cleanup fatal.
        """
        with self._shared_lock:
            if not branch.strip():
                return True
            ref = f"refs/heads/{branch}"
            if not self._git_in_repo("show-ref", "--verify", "--quiet", ref, check=False).ok:
                return True
            self._git_in_repo("branch", "-D", branch, check=False)
            return not self._git_in_repo("show-ref", "--verify", "--quiet", ref, check=False).ok

    def force_discard_local_proposal(
        self,
        branch: str,
        *,
        base_branch: str,
        base_head: str = "",
        timeout: int = DEFAULT_TIMEOUT_S,
    ) -> str:
        """Force an obsolete proposal out of this managed checkout.

        Normal branch deletion is preferred.  If it fails, reset the managed
        working copy to its remote/base state, remove untracked proposal debris,
        and delete the ref directly.  A damaged checkout is rebuilt from the
        configured remote as the last resort.  None of these operations touches
        a remote ref.

        Returns ``delete``, ``hard_reset`` or ``reclone``.
        """
        self._assert_managed_checkout()
        try:
            remote_ref = f"refs/remotes/origin/{base_branch}" if base_branch else ""
            if (
                remote_ref
                and self._git_in_repo("rev-parse", "--verify", remote_ref, check=False).ok
            ):
                target = remote_ref
            elif (
                base_head and self._git_in_repo("rev-parse", "--verify", base_head, check=False).ok
            ):
                target = base_head
            else:
                target = "HEAD"

            self._git_in_repo("reset", "--hard", target, timeout=timeout)
            self._git_in_repo("clean", "-fd", timeout=timeout)
            if base_branch:
                self._git_in_repo("checkout", "-B", base_branch, target, timeout=timeout)
            self._git_in_repo(
                "update-ref", "-d", f"refs/heads/{branch}", timeout=timeout, check=False
            )
            if not self._git_in_repo(
                "show-ref", "--verify", "--quiet", f"refs/heads/{branch}", check=False
            ).ok:
                logger.warning("kb: force-discarded proposal branch {} with hard reset", branch)
                return "hard_reset"
        except KbRepoError as exc:
            logger.warning("kb: hard-reset cleanup failed for {} — {}", branch, exc)

        self._reclone_managed_checkout(timeout=timeout)
        if self._git_in_repo(
            "show-ref", "--verify", "--quiet", f"refs/heads/{branch}", check=False
        ).ok:
            raise KbRepoError(
                f"proposal branch {branch} still exists after rebuilding the KB checkout."
            )
        logger.warning("kb: rebuilt managed checkout to discard proposal branch {}", branch)
        return "reclone"

    def _assert_managed_checkout(self) -> None:
        root = self._root.resolve()
        path = self.path.resolve()
        if path == root or path.parent != root or path.name != self.slug:
            raise KbRepoError(
                f"Refusing destructive recovery outside the managed KB repo root: {path}"
            )

    def _reclone_managed_checkout(self, *, timeout: int) -> None:
        """Rebuild this exact managed clone, restoring the old copy on failure."""
        self._assert_managed_checkout()
        self._root.mkdir(parents=True, exist_ok=True)
        placeholder = Path(tempfile.mkdtemp(prefix=f".{self.slug}-recovery-", dir=self._root))
        placeholder.rmdir()
        backup = placeholder
        moved = False
        try:
            if self.path.exists():
                self.path.replace(backup)
                moved = True
            self.sync(timeout=timeout)
        except Exception:
            if self.path.exists():
                _rmtree_managed(self.path)
            if moved and backup.exists():
                backup.replace(self.path)
            raise
        if moved and backup.exists():
            _rmtree_managed(backup)

    def delete_remote_branch(self, branch: str, *, timeout: int = 120) -> bool:
        """Best-effort: the branch may already be gone, which is the goal anyway."""
        if not branch.strip():
            return True
        result = self._git_in_repo(
            "push", "origin", "--delete", branch, timeout=timeout, check=False
        )
        if result.ok:
            return True
        message = result.message.casefold()
        if "remote ref does not exist" in message:
            return True
        logger.info("kb: could not delete remote branch {} — {}", branch, result.message)
        return False

    def branch_url(self, branch: str) -> str:
        base = self._web_base()
        return f"{base}/tree/{branch}" if base else ""

    def commit_url(self, sha: str) -> str:
        """Best-effort web URL for a commit; empty when the host is unknown."""
        base = self._web_base()
        return f"{base}/commit/{sha}" if base else ""

    def _web_base(self) -> str:
        url = self.remote_url
        if url.startswith("git@"):
            host, _, path = url[4:].partition(":")
            url = f"https://{host}/{path}"
        if url.endswith(".git"):
            url = url[: -len(".git")]
        if not url.startswith("http"):
            return ""
        return _strip_userinfo(url)

    # ── working-tree helpers ────────────────────────────────────────────

    def resolve_within(self, relative: str) -> Path:
        """Resolve a repository-relative path, refusing anything outside it.

        Every path in this flow originates in a model response, which means it
        originates in a group chat. ``..`` must therefore be a hard error, not a
        best-effort filter.
        """
        root = self.path.resolve()
        candidate = (root / (relative or "").strip().lstrip("/\\")).resolve()
        try:
            candidate.relative_to(root)
        except ValueError:
            raise KbPathError(
                f"Path '{relative}' is outside the knowledge-base checkout."
            ) from None
        if candidate == root:
            raise KbPathError("A change must name a file, not the repository root.")
        return candidate

    def file_at_head(self, relative: str, *, ref: str = "HEAD") -> str | None:
        """Committed content of a path, or ``None`` when HEAD does not have it.

        The committed state is the only truth worth diffing against. A working
        tree can hold an untracked leftover or a half-applied edit, and treating
        either as "what the knowledge base says" would show the group a diff
        that does not match what a commit would actually change.
        """
        target = self.resolve_within(relative)
        rel = target.relative_to(self.path.resolve()).as_posix()
        result = self._git_in_repo("show", f"{ref}:{rel}", check=False)
        return result.stdout if result.ok else None

    def diff_text(self, relative: str, new_text: str, *, context: int = 3) -> str:
        """Unified diff between the committed file and *new_text*.

        Produced by git itself rather than difflib so what the group approves is
        rendered exactly the way the eventual commit will read. Nothing is
        written into the checkout: the proposal stays in the task file until
        publish, so an abandoned draft leaves no debris behind.
        """
        target = self.resolve_within(relative)
        rel = target.relative_to(self.path.resolve()).as_posix()
        committed = self.file_at_head(relative)
        created = committed is None
        with tempfile.TemporaryDirectory(prefix="kb-diff-") as tmp:
            new_path = Path(tmp) / "new"
            new_path.write_text(new_text, encoding="utf-8", newline="\n")
            old_path = Path(tmp) / "old"
            old_path.write_text(committed or "", encoding="utf-8", newline="\n")
            result = self._run(
                "diff",
                "--no-index",
                f"--unified={context}",
                "--",
                str(old_path),
                str(new_path),
                check=False,
            )
        if result.returncode not in (0, 1):
            raise KbRepoError(f"git diff failed: {result.message}")
        return _relabel_diff(result.stdout, rel, created=created)

    def rollback(self, base_sha: str, paths: list[str]) -> None:
        """Undo a failed publish: drop our local commit and our file writes.

        A push can fail *after* the commit succeeded, which leaves a local
        commit the remote has never seen. Neither half can be left behind: the
        stray commit would make the next attempt report "nothing to commit",
        and the stray files would make the next diff report "no change" for
        edits that were never published. Both failures look like success, which
        is the worst way for this to break.

        The checkout belongs to this flow, so resetting it is safe — nobody
        else is editing it.
        """
        if base_sha and self.is_cloned:
            # Reset even when HEAD never moved. ``merge --squash`` populates the
            # index before ``commit``; if commit fails, comparing only HEAD to
            # base_sha would leave that staged state behind for the next retry.
            self._git_in_repo("reset", "--hard", base_sha, check=False)
        for relative in paths:
            try:
                target = self.resolve_within(relative)
            except KbPathError:
                continue
            rel = target.relative_to(self.path.resolve()).as_posix()
            if self.file_at_head(relative) is None:
                target.unlink(missing_ok=True)
            else:
                self._git_in_repo("checkout", "--", rel, check=False)


__all__ = [
    "DEFAULT_TIMEOUT_S",
    "GitResult",
    "GitUnavailableError",
    "KbAuthRequiredError",
    "KbDirtyError",
    "KbPathError",
    "KbRepo",
    "KbRepoError",
    "PROBE_TIMEOUT_S",
    "RepoStatus",
    "git_executable",
    "normalize_remote",
    "remote_slug",
]
