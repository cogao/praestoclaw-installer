"""Per-meeting task-flow profile persistence."""

from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import uuid
from copy import deepcopy
from datetime import UTC, datetime
from pathlib import Path
from threading import RLock
from typing import Any
from zoneinfo import ZoneInfo

from loguru import logger

from praestoclaw.meeting_automation.models import (
    MeetingTaskGroupInstance,
    MeetingTaskGroupTemplate,
    TaskGroupConfig,
)

_TERMINAL = {"completed", "skipped", "failed"}

_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")


def meeting_id_slug(meeting_id: str) -> str:
    """Stable readable directory name for a Teams meeting thread id."""
    value = str(meeting_id or "").strip()
    if not value:
        raise ValueError("meeting id is required")
    readable = _UNSAFE.sub("_", value).strip("_.")[:72]
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()[:12]
    return f"{readable}-{digest}" if readable else digest


class MeetingAutomationStore:
    """Persist current templates and independent, retained instance records."""

    def __init__(self, data_dir: Path) -> None:
        self._root = data_dir / "meetings"
        self._lock = RLock()
        self._templates: dict[str, MeetingTaskGroupTemplate] = {}
        self._instances: dict[str, MeetingTaskGroupInstance] = {}
        self._indexes: dict[str, dict[str, Any]] = {}
        self._instance_paths: dict[str, Path] = {}
        self._load()

    def profile_dir(self, meeting_chat_id: str) -> Path:
        return self._root / meeting_id_slug(meeting_chat_id)

    def template_path(self, meeting_chat_id: str) -> Path:
        return self.profile_dir(meeting_chat_id) / "template.json"

    def index_path(self, meeting_chat_id: str) -> Path:
        return self.profile_dir(meeting_chat_id) / "index.json"

    def instance_path(self, instance: MeetingTaskGroupInstance) -> Path:
        return (
            self.profile_dir(instance.meeting.chat_id)
            / "instances"
            / f"{meeting_id_slug(instance.instance_id)}.json"
        )

    def revision_path(self, meeting_chat_id: str, version: int) -> Path:
        return self.profile_dir(meeting_chat_id) / "revisions" / f"{version}.json"

    def change_path(self, meeting_chat_id: str, change_id: str) -> Path:
        return self.profile_dir(meeting_chat_id) / "changes" / f"{change_id}.json"

    def get_template(self, meeting_chat_id: str) -> MeetingTaskGroupTemplate | None:
        with self._lock:
            value = self._templates.get(meeting_chat_id)
            return deepcopy(value) if value is not None else None

    def put_template(self, template: MeetingTaskGroupTemplate) -> None:
        if not template.meeting_chat_id:
            raise ValueError("meeting template requires meeting_chat_id")
        with self._lock:
            self._templates[template.meeting_chat_id] = deepcopy(template)
            self._persist_template(template.meeting_chat_id)

    def latest_version(self, meeting_chat_id: str) -> int:
        with self._lock:
            current = self._templates.get(meeting_chat_id)
            versions = [
                int(path.stem)
                for path in (self.profile_dir(meeting_chat_id) / "revisions").glob("*.json")
            ]
            return max([current.version if current else 0, *versions])

    def delete_template(self, meeting_chat_id: str) -> None:
        with self._lock:
            current = self._templates.get(meeting_chat_id)
            if current is not None:
                revision_path = self.revision_path(meeting_chat_id, current.version)
                if not revision_path.exists():
                    self._write_json(
                        revision_path, {"version": current.version, "template": current.to_dict()}
                    )
                previous_version = self.latest_version(meeting_chat_id)
                self.finalize_revision(
                    meeting_chat_id,
                    {
                        "version": previous_version + 1,
                        "previous_version": previous_version,
                        "change_id": uuid.uuid4().hex,
                        "operation": "delete",
                        "requested_at": datetime.now(UTC).isoformat(),
                        "before": {"task_groups": current.to_dict()["task_groups"]},
                        "after": {"task_groups": []},
                        "status": "applied",
                    },
                )
            self.template_path(meeting_chat_id).unlink(missing_ok=True)
            self._templates.pop(meeting_chat_id, None)

    def apply_revision(
        self,
        template: MeetingTaskGroupTemplate,
        *,
        expected_version: int,
        revision: dict[str, Any],
        change_id: str,
    ) -> None:
        """CAS the current template and publish its files under the store lock."""
        meeting_id = template.meeting_chat_id
        with self._lock:
            current_version = self.latest_version(meeting_id)
            if current_version != expected_version:
                raise ValueError(
                    f"expected_version {expected_version} does not match current version {current_version}"
                )
            self._templates[meeting_id] = deepcopy(template)
            self._persist_template(meeting_id)
            self._write_json(self.revision_path(meeting_id, template.version), revision)
            self._write_json(self.change_path(meeting_id, change_id), revision)

    def record_change(self, meeting_chat_id: str, change: dict[str, Any]) -> str:
        change_id = str(change.get("change_id") or uuid.uuid4().hex)
        change["change_id"] = change_id
        with self._lock:
            self._write_json(self.change_path(meeting_chat_id, change_id), change)
        return change_id

    def finalize_revision(self, meeting_chat_id: str, revision: dict[str, Any]) -> None:
        with self._lock:
            self._write_json(
                self.revision_path(meeting_chat_id, int(revision["version"])), revision
            )
            self._write_json(
                self.change_path(meeting_chat_id, str(revision["change_id"])), revision
            )

    def history(self, meeting_chat_id: str, version: int | None = None) -> list[dict[str, Any]]:
        directory = self.profile_dir(meeting_chat_id) / "revisions"
        if version is not None:
            path = directory / f"{version}.json"
            return [json.loads(path.read_text(encoding="utf-8"))] if path.is_file() else []
        values: list[dict[str, Any]] = []
        for path in directory.glob("*.json") if directory.is_dir() else []:
            values.append(json.loads(path.read_text(encoding="utf-8")))
        return sorted(values, key=lambda item: int(item.get("version") or 0), reverse=True)

    def changes(self, meeting_chat_id: str) -> list[dict[str, Any]]:
        directory = self.profile_dir(meeting_chat_id) / "changes"
        values = [
            json.loads(path.read_text(encoding="utf-8"))
            for path in directory.glob("*.json")
            if directory.is_dir()
        ]
        return sorted(values, key=lambda item: str(item.get("requested_at") or ""), reverse=True)

    def templates(self) -> list[MeetingTaskGroupTemplate]:
        with self._lock:
            return deepcopy(list(self._templates.values()))

    def get_instance(self, instance_id: str) -> MeetingTaskGroupInstance | None:
        with self._lock:
            value = self._instances.get(instance_id)
            if value is None and instance_id in self._instance_paths:
                path = self._instance_paths[instance_id]
                try:
                    value = self._read_instance(path, instance_id)
                except (OSError, ValueError, TypeError, KeyError, AttributeError):
                    logger.exception("Could not load meeting instance {}", path)
                    self._instance_paths.pop(instance_id, None)
                    return None
                self._instances[instance_id] = value
            return deepcopy(value) if value is not None else None

    def _read_instance(self, path: Path, instance_id: str) -> MeetingTaskGroupInstance:
        value = MeetingTaskGroupInstance.from_dict(json.loads(path.read_text(encoding="utf-8")))
        if value.instance_id != instance_id or self.instance_path(value) != path:
            raise ValueError("meeting instance identity does not match its index path")
        return value

    def put_instance(self, instance: MeetingTaskGroupInstance) -> None:
        meeting_chat_id = instance.meeting.chat_id
        if not meeting_chat_id:
            raise ValueError("meeting instance requires meeting.chat_id")
        with self._lock:
            path = self.instance_path(instance)
            self._write_json(path, instance.to_dict())
            self._instances[instance.instance_id] = deepcopy(instance)
            self._instance_paths[instance.instance_id] = path
            self._index_instance(instance)
            self._write_json(self.index_path(meeting_chat_id), self._indexes[meeting_chat_id])

    def _index_instance(self, instance: MeetingTaskGroupInstance) -> None:
        index = self._indexes.setdefault(
            instance.meeting.chat_id, {"schema_version": 1, "tasks": {}}
        )
        refs = index["tasks"].setdefault(instance.task_id, {}).setdefault(instance.cycle_key, [])
        ref = next((item for item in refs if item["instance_id"] == instance.instance_id), None)
        if ref is None:
            ref = {"instance_id": instance.instance_id}
            refs.append(ref)
        ref.update(rev=instance.task_source_revision, state=instance.state)

    def instance_refs(
        self,
        meeting_chat_id: str,
        *,
        task_id: str | None = None,
        cycle_key: str | None = None,
        states: set[str] | None = None,
    ) -> list[dict[str, Any]]:
        with self._lock:
            tasks = self._indexes.get(meeting_chat_id, {}).get("tasks", {})
            return deepcopy(
                [
                    ref
                    for key, cycles in tasks.items()
                    if task_id is None or task_id == key
                    for cycle, refs in cycles.items()
                    if cycle_key is None or cycle_key == cycle
                    for ref in refs
                    if states is None or ref["state"] in states
                ]
            )

    def instances(
        self,
        *,
        meeting_chat_id: str | None = None,
        task_id: str | None = None,
        cycle_key: str | None = None,
        states: set[str] | None = None,
    ) -> list[MeetingTaskGroupInstance]:
        with self._lock:
            meeting_ids = [meeting_chat_id] if meeting_chat_id is not None else self._indexes
            return [
                instance
                for meeting_id in meeting_ids
                for ref in self.instance_refs(
                    meeting_id, task_id=task_id, cycle_key=cycle_key, states=states
                )
                if (instance := self.get_instance(ref["instance_id"])) is not None
            ]

    def find_by_background_task(self, task_id: str) -> MeetingTaskGroupInstance | None:
        return next((item for item in self.instances() if item.background_task_id == task_id), None)

    def claim_cycle(self, meeting_chat_id: str, cycle_key: str, cycle_start: str) -> bool:
        """Advance the cycle watermark under the profile lock; return False when stale."""
        with self._lock:
            template = self._templates[meeting_chat_id]
            current = (
                datetime.fromisoformat(template.latest_started_cycle_start)
                if template.latest_started_cycle_start
                else None
            )
            candidate = datetime.fromisoformat(cycle_start)
            if template.latest_started_cycle_key == cycle_key:
                if candidate != current:
                    template.latest_started_cycle_start = cycle_start
                    self._persist_template(meeting_chat_id)
                return True
            if current is not None and candidate < current:
                return False
            if current is None or candidate > current:
                template.latest_started_cycle_key = cycle_key
                template.latest_started_cycle_start = cycle_start
                self._persist_template(meeting_chat_id)
            return True

    @staticmethod
    def _legacy_task_id(identity: str, key: str) -> str:
        return uuid.uuid5(uuid.NAMESPACE_URL, f"{identity}:{key}").hex

    def _upgrade_template(self, raw: dict[str, Any]) -> MeetingTaskGroupTemplate:
        identity = str(raw.get("template_id") or f"meeting:{raw['meeting_chat_id']}")
        for task in raw.get("task_groups", []):
            task.setdefault("task_id", self._legacy_task_id(identity, task["key"]))
        return MeetingTaskGroupTemplate.from_dict(raw)

    def _upgrade_instance(
        self, raw: dict[str, Any], template: MeetingTaskGroupTemplate | None
    ) -> MeetingTaskGroupInstance:
        instance = MeetingTaskGroupInstance.from_dict(raw)
        current = (
            next((task for task in template.task_groups if task.key == instance.task_key), None)
            if template is not None
            else None
        )
        identity = str(raw.get("template_id") or f"meeting:{instance.meeting.chat_id}")
        if "task_id" not in raw:
            instance.task_id = self._legacy_task_id(identity, instance.task_key)
            if instance.started_at:
                instance.continuation_generation = max(1, instance.continuation_generation)
        if instance.task_snapshot is None:
            candidates: list[tuple[int, TaskGroupConfig]] = []
            if current is not None and template is not None:
                candidates.append((template.version, current))
            for revision in self.history(instance.meeting.chat_id):
                for section in ("template", "before", "after"):
                    config_version = int(
                        revision.get("previous_version" if section == "before" else "version") or 0
                    )
                    for task in revision.get(section, {}).get("task_groups", []):
                        if task.get("key") == instance.task_key:
                            candidate = TaskGroupConfig.from_dict(task)
                            candidate.task_id = str(task.get("task_id") or instance.task_id)
                            candidates.append((config_version, candidate))
            if not instance.task_source_revision:
                started_version = raw.get("template_version_started")
                inferred = None
                if started_version is not None:
                    inferred = next(
                        (
                            task
                            for version, task in candidates
                            if version == int(started_version) and task.task_id == instance.task_id
                        ),
                        None,
                    )
                elif instance.state == "scheduled" and not instance.started_at:
                    inferred = (
                        current
                        if current is not None and current.task_id == instance.task_id
                        else None
                    )
                if inferred is not None:
                    instance.task_source_revision = inferred.source_revision
                    instance.task_snapshot = deepcopy(inferred)
            if instance.task_snapshot is None and instance.task_source_revision:
                instance.task_snapshot = next(
                    (
                        deepcopy(task)
                        for _, task in candidates
                        if task.task_id == instance.task_id
                        and task.source_revision == instance.task_source_revision
                    ),
                    None,
                )
        if not instance.cycle_key:
            instance.cycle_key = instance.meeting.occurrence_key or instance.instance_id
        if "task_id" not in raw:
            if instance.manual_action == "run_task":
                instance.cycle_key = f"adhoc:{instance.instance_id}"
            elif (
                instance.task_snapshot is not None
                and instance.task_snapshot.schedule.type == "weekly"
            ):
                if instance.scheduled_for:
                    instance.cycle_key = (
                        datetime.fromisoformat(instance.scheduled_for)
                        .astimezone(
                            ZoneInfo(template.timezone if template is not None else "Asia/Shanghai")
                        )
                        .strftime("%G-W%V-%uT%H:%M")
                    )
        return instance

    def _load(self) -> None:
        if not self._root.is_dir():
            return
        for path in self._root.glob("*/flow.json"):
            try:
                self._migrate_legacy(path)
            except OSError:
                logger.exception("Could not migrate meeting profile {}", path)
        for path in self._root.glob("*/template.json"):
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
                template = self._upgrade_template(raw)
                self._templates[template.meeting_chat_id] = template
                if raw != template.to_dict():
                    self._write_json(path, template.to_dict())
            except (OSError, ValueError, TypeError, KeyError):
                continue
        for directory in self._root.iterdir():
            if not directory.is_dir():
                continue
            if not self._load_index(directory):
                for path in (directory / "instances").glob("*.json"):
                    try:
                        raw = json.loads(path.read_text(encoding="utf-8"))
                        current_template = self._templates.get(raw["meeting"]["chat_id"])
                        instance = self._upgrade_instance(raw, current_template)
                        if self.instance_path(instance) != path:
                            raise ValueError("meeting instance identity does not match its file")
                        self.put_instance(instance)
                    except (OSError, ValueError, TypeError, KeyError, AttributeError):
                        logger.exception("Could not restore meeting instance {}", path)
                        continue
        for instance in self.instances(states={"scheduled", "running", "waiting_user"}):
            current_template = self._templates.get(instance.meeting.chat_id)
            if (
                current_template is None
                or instance.task_id not in {task.task_id for task in current_template.task_groups}
                or instance.task_snapshot is None
            ):
                instance.state = "skipped"
                instance.status_reason = "Task definition or execution snapshot no longer exists."
                self._finish_restored_instance(instance)
                self.put_instance(instance)

    def _load_index(self, directory: Path) -> bool:
        path = directory / "index.json"
        if not path.is_file():
            return False
        try:
            index = json.loads(path.read_text(encoding="utf-8"))
            paths: dict[str, Path] = {}
            for cycles in index["tasks"].values():
                for refs in cycles.values():
                    if not isinstance(refs, list):
                        raise ValueError("meeting index references must be a list")
                    for ref in refs:
                        if (
                            not isinstance(ref["instance_id"], str)
                            or not isinstance(ref["state"], str)
                            or not isinstance(ref["rev"], int)
                        ):
                            raise ValueError("invalid meeting index reference")
                        paths[ref["instance_id"]] = (
                            directory / "instances" / f"{meeting_id_slug(ref['instance_id'])}.json"
                        )
            meeting_id = next(
                (key for key in self._templates if self.profile_dir(key) == directory), None
            )
            # Deleted templates retain history even if the first reference is unreadable.
            if meeting_id is None:
                for instance_id, instance_path in paths.items():
                    try:
                        meeting_id = self._read_instance(instance_path, instance_id).meeting.chat_id
                        break
                    except (OSError, ValueError, TypeError, KeyError, AttributeError):
                        logger.exception("Could not load meeting instance {}", instance_path)
            if meeting_id is None:
                return False
            self._indexes[meeting_id] = index
            self._instance_paths.update(paths)
            return True
        except (OSError, ValueError, TypeError, KeyError, AttributeError):
            logger.exception("Could not load meeting index {}; rebuilding from instances", path)
            return False

    @staticmethod
    def _archive_legacy(path: Path) -> None:
        archive = path.with_name("flow.legacy.json")
        if archive.exists():
            archive = path.with_name(f"flow.legacy.{uuid.uuid4().hex}.json")
        os.replace(path, archive)

    def _migrate_legacy(self, path: Path) -> None:
        # Parse completely before writing: invalid input is archived; failed writes retry.
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            if raw.get("version") != 2:
                self._archive_legacy(path)
                return
            data = raw["template"]
            meeting_chat_id = data["meeting_chat_id"]
            template = self._upgrade_template(deepcopy(data))
            task_keys = {
                task.key for task in template.task_groups if template.enabled and task.enabled
            }
            instances = []
            for value in (raw.get("instances") or {}).values():
                value = dict(value)
                original_state = value.get("state")
                if original_state == "paused":
                    reason = str(value.get("status_reason") or "")
                    value["state"] = "failed" if "自动续跑已暂停" in reason else "skipped"
                elif original_state == "validating":
                    value["state"] = "scheduled"
                instance = self._upgrade_instance(value, template)
                if instance.state not in _TERMINAL and instance.task_key not in task_keys:
                    instance.state = "skipped"
                    instance.status_reason = "Legacy task definition no longer exists."
                if instance.state in {"failed", "skipped"} and original_state not in _TERMINAL:
                    self._finish_restored_instance(instance)
                instances.append(instance)
        except (ValueError, TypeError, KeyError, AttributeError):
            logger.exception("Archiving invalid legacy meeting profile {}", path)
            self._archive_legacy(path)
            return
        self._write_json(self.template_path(meeting_chat_id), template.to_dict())
        for instance in instances:
            self._write_json(self.instance_path(instance), instance.to_dict())
        self._archive_legacy(path)

    @staticmethod
    def _finish_restored_instance(instance: MeetingTaskGroupInstance) -> None:
        instance.finished_at = datetime.now(UTC).isoformat()
        instance.updated_at = instance.finished_at
        instance.run_epoch = ""
        instance.run_turn_id = ""
        if instance.state == "skipped":
            instance.pending_delivery = ""

    def _persist_template(self, meeting_chat_id: str) -> None:
        template = self._templates[meeting_chat_id]
        directory = self.profile_dir(meeting_chat_id)
        directory.mkdir(parents=True, exist_ok=True)
        id_path = directory / "MEETING_ID"
        if not id_path.exists():
            id_path.write_text(meeting_chat_id + "\n", encoding="utf-8")
        self._write_json(self.template_path(meeting_chat_id), template.to_dict())

    @staticmethod
    def _write_json(path: Path, payload: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_name = tempfile.mkstemp(prefix=path.stem + "-", suffix=".tmp", dir=path.parent)
        tmp = Path(tmp_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2, ensure_ascii=False)
                handle.write("\n")
            os.replace(tmp, path)
        finally:
            tmp.unlink(missing_ok=True)
