"""Session metadata in SQLite with append-only JSONL transcripts."""

from __future__ import annotations

import asyncio
import json
import os
import re
import sqlite3
import uuid
from collections.abc import AsyncIterator, Callable, Coroutine
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, TypeVar

import aiosqlite
from filelock import FileLock
from loguru import logger

from praestoclaw.agent.compaction import count_tokens
from praestoclaw.session.transcript import TranscriptCorruptionError, TranscriptStore
from praestoclaw.utils.helpers import get_data_dir

LLM_ROLES: frozenset[str] = frozenset({"user", "assistant", "system", "tool"})
_T = TypeVar("_T")


class SessionNotFoundError(LookupError):
    """A write targeted a session that no longer exists."""


_APPLICATION_ID = 0x5052434C  # ASCII "PRCL"
_SCHEMA_VERSION = 1
_BUSY_TIMEOUT_MS = 30_000
_LEGACY_LOCAL_SCHEDULER_CHANNEL = "cli"
_LOCAL_SCHEDULER_CHANNEL = "internal"
_SCHEDULER_SENDER = "scheduler"
_PRAESTO_TAG_EXP_SESSION_MARKER = ":praesto_tag_exp:"

_SCHEMA_STATEMENTS = (
    """CREATE TABLE sessions (
    id TEXT PRIMARY KEY,
    channel TEXT NOT NULL,
    sender TEXT NOT NULL,
    model TEXT,
    parent_session_id TEXT,
    prompt_tokens INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    cost REAL NOT NULL DEFAULT 0.0,
    title TEXT,
    message_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(parent_session_id) REFERENCES sessions(id) ON DELETE SET NULL
)""",
    """CREATE TABLE counters (
    key TEXT PRIMARY KEY,
    value INTEGER NOT NULL DEFAULT 0
)""",
    """CREATE TABLE schema_migrations (
    version INTEGER PRIMARY KEY,
    migrated_at TEXT NOT NULL,
    source_version INTEGER NOT NULL,
    sessions_copied INTEGER NOT NULL,
    messages_copied INTEGER NOT NULL,
    orphan_messages_dropped INTEGER NOT NULL,
    backup_path TEXT
)""",
    "CREATE INDEX sessions_channel_sender_updated ON sessions(channel, sender, updated_at DESC)",
)

_LEGACY_OBJECTS = {
    ("table", "sessions"),
    ("table", "messages"),
    ("table", "messages_fts"),
    ("table", "counters"),
    ("table", "messages_fts_data"),
    ("table", "messages_fts_idx"),
    ("table", "messages_fts_docsize"),
    ("table", "messages_fts_config"),
    ("trigger", "messages_ai"),
    ("trigger", "messages_ad"),
    ("trigger", "messages_au"),
}

_LEGACY_TABLE_INFO = {
    "sessions": (
        ("id", "TEXT", 0, None, 1),
        ("channel", "TEXT", 1, None, 0),
        ("sender", "TEXT", 1, None, 0),
        ("model", "TEXT", 0, None, 0),
        ("parent_session_id", "TEXT", 0, None, 0),
        ("prompt_tokens", "INTEGER", 0, "0", 0),
        ("completion_tokens", "INTEGER", 0, "0", 0),
        ("cost", "REAL", 0, "0.0", 0),
        ("title", "TEXT", 0, None, 0),
        ("created_at", "TEXT", 1, None, 0),
        ("updated_at", "TEXT", 1, None, 0),
    ),
    "messages": (
        ("id", "INTEGER", 0, None, 1),
        ("session_id", "TEXT", 1, None, 0),
        ("role", "TEXT", 1, None, 0),
        ("content", "TEXT", 0, None, 0),
        ("tool_calls", "TEXT", 0, None, 0),
        ("tool_call_id", "TEXT", 0, None, 0),
        ("tokens", "INTEGER", 0, "0", 0),
        ("created_at", "TEXT", 1, None, 0),
    ),
    "counters": (("key", "TEXT", 0, None, 1), ("value", "INTEGER", 1, "0", 0)),
}

_LEGACY_SQL = {
    "messages_fts": """CREATE VIRTUAL TABLE messages_fts USING fts5(
        content, content=messages, content_rowid=id)""",
    "messages_ai": """CREATE TRIGGER messages_ai AFTER INSERT ON messages BEGIN
        INSERT INTO messages_fts(rowid, content) VALUES (new.id, new.content); END""",
    "messages_ad": """CREATE TRIGGER messages_ad AFTER DELETE ON messages BEGIN
        INSERT INTO messages_fts(messages_fts, rowid, content)
        VALUES ('delete', old.id, old.content); END""",
    "messages_au": """CREATE TRIGGER messages_au AFTER UPDATE ON messages BEGIN
        INSERT INTO messages_fts(messages_fts, rowid, content)
        VALUES ('delete', old.id, old.content);
        INSERT INTO messages_fts(rowid, content) VALUES (new.id, new.content); END""",
}


class SessionSchemaError(RuntimeError):
    """The SQLite file is not a supported PraestoClaw session schema."""


def _configure_sqlite_before_classification(conn: sqlite3.Connection) -> None:
    """Set connection-local safety options that do not mutate an unknown DB."""
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute(f"PRAGMA busy_timeout={_BUSY_TIMEOUT_MS}")


def _configure_supported_sqlite(conn: sqlite3.Connection) -> None:
    """Apply persistent/runtime settings after the DB is known to be ours."""
    journal = str(conn.execute("PRAGMA journal_mode=WAL").fetchone()[0]).lower()
    if journal != "wal":
        raise SessionSchemaError(
            f"sessions.db requires WAL journal mode; SQLite returned {journal!r}"
        )
    conn.execute("PRAGMA synchronous=FULL")
    conn.execute("PRAGMA wal_autocheckpoint=1000")
    if int(conn.execute("PRAGMA foreign_keys").fetchone()[0]) != 1:
        raise SessionSchemaError("sessions.db could not enable foreign keys")


def _is_empty_database(conn: sqlite3.Connection) -> bool:
    return (
        conn.execute(
            "SELECT 1 FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%' LIMIT 1"
        ).fetchone()
        is None
    )


def _is_legacy_v0(conn: sqlite3.Connection) -> bool:
    objects = {
        (str(row[0]), str(row[1]))
        for row in conn.execute(
            "SELECT type, name FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%'"
        )
    }
    # sqlite_autoindex_* is excluded by the query. Everything else, including
    # extra indexes/views/triggers, makes this an unknown database.
    if objects != _LEGACY_OBJECTS:
        return False
    for table, expected in _LEGACY_TABLE_INFO.items():
        actual = tuple(
            (str(row[1]), str(row[2]).upper(), int(row[3]), row[4], int(row[5]))
            for row in conn.execute(f"PRAGMA table_info({table})")
        )
        if actual != expected:
            return False
    fks = tuple(conn.execute("PRAGMA foreign_key_list(messages)"))
    if len(fks) != 1 or tuple(fks[0][2:8]) != (
        "sessions",
        "session_id",
        "id",
        "NO ACTION",
        "NO ACTION",
        "NONE",
    ):
        return False
    if tuple(conn.execute("PRAGMA foreign_key_list(sessions)")):
        return False
    sql_by_name = {
        str(row[0]): str(row[1] or "")
        for row in conn.execute(
            "SELECT name, sql FROM sqlite_schema WHERE name IN "
            "('messages_fts','messages_ai','messages_ad','messages_au')"
        )
    }

    def normalize(sql: str) -> str:
        return re.sub(r"\s+", "", sql.lower()).replace("ifnotexists", "").rstrip(";")

    if any(
        normalize(sql_by_name.get(name, "")) != normalize(sql) for name, sql in _LEGACY_SQL.items()
    ):
        return False
    return True


def _validate_database(conn: sqlite3.Connection) -> None:
    if conn.execute("PRAGMA quick_check").fetchone()[0] != "ok":
        raise SessionSchemaError("sessions.db failed PRAGMA quick_check")
    if conn.execute("PRAGMA foreign_key_check").fetchone() is not None:
        raise SessionSchemaError("sessions.db failed PRAGMA foreign_key_check")


def _migrate_legacy_local_scheduler_ownership(conn: sqlite3.Connection) -> int:
    """Normalize local scheduler sessions whose delivery route became their owner."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        cursor = conn.execute(
            "UPDATE sessions SET channel = ?, sender = ? "
            "WHERE id GLOB 'scheduler_*' AND channel IN (?, ?) AND sender = id",
            (
                _LOCAL_SCHEDULER_CHANNEL,
                _SCHEDULER_SENDER,
                _LEGACY_LOCAL_SCHEDULER_CHANNEL,
                _LOCAL_SCHEDULER_CHANNEL,
            ),
        )
        changed = cursor.rowcount
        conn.commit()
        return changed
    except BaseException:
        conn.rollback()
        raise


def _migrate_legacy_praesto_tag_exp_ownership(conn: sqlite3.Connection) -> int:
    """Replace the first tagger's OID with the shared group's stable principal."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        rows = list(
            conn.execute(
                "SELECT id, channel, sender FROM sessions WHERE instr(id, ?) > 0",
                (_PRAESTO_TAG_EXP_SESSION_MARKER,),
            )
        )
        updates: list[tuple[str, str]] = []
        for row in rows:
            session_id = str(row["id"])
            expected_prefix = f"{row['channel']}{_PRAESTO_TAG_EXP_SESSION_MARKER}"
            if not session_id.startswith(expected_prefix):
                continue
            conversation_id = session_id.split(_PRAESTO_TAG_EXP_SESSION_MARKER, 1)[1]
            expected_sender = f"praesto_tag_exp:{conversation_id}"
            if str(row["sender"]) != expected_sender:
                updates.append((expected_sender, session_id))
        if updates:
            conn.executemany("UPDATE sessions SET sender = ? WHERE id = ?", updates)
        conn.commit()
        return len(updates)
    except BaseException:
        conn.rollback()
        raise


def _has_table(conn: sqlite3.Connection, name: str) -> bool:
    return (
        conn.execute(
            "SELECT 1 FROM sqlite_schema WHERE type='table' AND name=?", (name,)
        ).fetchone()
        is not None
    )


def _is_current_schema(conn: sqlite3.Connection) -> bool:
    """Recognize the unreleased v1 metadata-only shape exactly enough to fail safe."""
    if not all(_has_table(conn, name) for name in ("sessions", "counters", "schema_migrations")):
        return False
    if _has_table(conn, "messages") or _has_table(conn, "messages_fts"):
        return False
    columns = {str(row[1]) for row in conn.execute("PRAGMA table_info(sessions)")}
    return columns == {
        "id",
        "channel",
        "sender",
        "model",
        "parent_session_id",
        "prompt_tokens",
        "completion_tokens",
        "cost",
        "title",
        "message_count",
        "created_at",
        "updated_at",
    }


def _is_pre_release_sqlite_v1(conn: sqlite3.Connection) -> bool:
    """Recognize this branch's earlier, SQLite-transcript v1 representation."""
    if not all(
        _has_table(conn, name)
        for name in ("sessions", "messages", "messages_fts", "counters", "schema_migrations")
    ):
        return False
    session_columns = {str(row[1]) for row in conn.execute("PRAGMA table_info(sessions)")}
    message_columns = {str(row[1]) for row in conn.execute("PRAGMA table_info(messages)")}
    return session_columns == {
        "id",
        "channel",
        "sender",
        "model",
        "parent_session_id",
        "prompt_tokens",
        "completion_tokens",
        "cost",
        "title",
        "created_at",
        "updated_at",
    } and message_columns == {
        "id",
        "session_id",
        "role",
        "content",
        "tool_calls",
        "tool_call_id",
        "tokens",
        "created_at",
    }


def _create_current_schema(
    conn: sqlite3.Connection,
    *,
    backup_path: str | None = None,
    counts: tuple[int, int, int] = (0, 0, 0),
) -> None:
    for statement in _SCHEMA_STATEMENTS:
        conn.execute(statement)
    sessions, messages, orphans = counts
    conn.execute(
        "INSERT INTO schema_migrations VALUES (?, ?, ?, ?, ?, ?, ?)",
        (_SCHEMA_VERSION, _now(), 0, sessions, messages, orphans, backup_path),
    )


def _backup_database(conn: sqlite3.Connection, db_path: Path, *, label: str) -> Path:
    backup_path = db_path.with_name(f"{db_path.name}.{label}.{uuid.uuid4().hex}.bak")
    backup_tmp = backup_path.with_suffix(backup_path.suffix + ".tmp")
    try:
        backup = sqlite3.connect(str(backup_tmp))
        try:
            conn.backup(backup)
            if backup.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                raise SessionSchemaError("sessions.db migration backup failed quick_check")
        finally:
            backup.close()
        os.replace(backup_tmp, backup_path)
        if os.name != "nt":
            try:
                backup_path.chmod(0o600)
            except OSError as exc:
                logger.warning(
                    "Could not restrict session migration backup {}: {}", backup_path, exc
                )
    except BaseException:
        try:
            backup_tmp.unlink(missing_ok=True)
        except OSError:
            pass
        raise

    return backup_path


def _legacy_message(row: sqlite3.Row) -> dict[str, Any]:
    message: dict[str, Any] = {"role": row["role"]}
    content = row["content"]
    if row["tool_calls"]:
        message["tool_calls"] = json.loads(row["tool_calls"])
        if content:
            message["content"] = content
    else:
        message["content"] = content or ""
    if row["tool_call_id"]:
        message["tool_call_id"] = row["tool_call_id"]
    return message


def _export_sqlite_transcripts(
    conn: sqlite3.Connection,
    transcript_dir: Path,
    *,
    source: str,
) -> tuple[list[Path], int, int, int]:
    transcripts = TranscriptStore(transcript_dir)
    session_rows = list(conn.execute("SELECT id, created_at FROM sessions ORDER BY id"))
    total_messages = int(conn.execute("SELECT count(*) FROM messages").fetchone()[0])
    valid_messages = int(
        conn.execute(
            "SELECT count(*) FROM messages m JOIN sessions s ON s.id=m.session_id"
        ).fetchone()[0]
    )
    published: list[Path] = []
    try:
        for session in session_rows:
            rows = list(
                conn.execute(
                    "SELECT role, content, tool_calls, tool_call_id, created_at "
                    "FROM messages WHERE session_id=? ORDER BY id",
                    (session["id"],),
                )
            )
            messages = [(_legacy_message(row), str(row["created_at"])) for row in rows]
            published.append(
                transcripts.write_migrated_snapshot(
                    str(session["id"]),
                    messages,
                    created_at=str(session["created_at"]),
                    source=source,
                )
            )
    except BaseException:
        for path in published:
            path.unlink(missing_ok=True)
        raise
    return published, len(session_rows), valid_messages, total_messages - valid_messages


def _migrate_sqlite_transcripts(
    conn: sqlite3.Connection,
    db_path: Path,
    transcript_dir: Path,
    *,
    source: str,
) -> Path:
    backup_path = _backup_database(conn, db_path, label=source)
    published: list[Path] = []
    try:
        published, sessions, valid_messages, orphans = _export_sqlite_transcripts(
            conn, transcript_dir, source=source
        )
    except BaseException:
        for path in published:
            path.unlink(missing_ok=True)
        raise

    conn.execute("BEGIN IMMEDIATE")
    try:
        conn.execute("DROP TRIGGER IF EXISTS messages_ai")
        conn.execute("DROP TRIGGER IF EXISTS messages_ad")
        conn.execute("DROP TRIGGER IF EXISTS messages_au")
        conn.execute("DROP TABLE IF EXISTS messages_fts")
        conn.execute("DROP INDEX IF EXISTS messages_session_id_id")
        conn.execute("DROP INDEX IF EXISTS sessions_channel_sender_updated")
        conn.execute("ALTER TABLE sessions RENAME TO source_sessions")
        conn.execute("ALTER TABLE messages RENAME TO source_messages")
        conn.execute("ALTER TABLE counters RENAME TO source_counters")
        conn.execute("DROP TABLE IF EXISTS schema_migrations")
        _create_current_schema(
            conn, backup_path=str(backup_path), counts=(sessions, valid_messages, orphans)
        )
        conn.execute(
            "INSERT INTO sessions "
            "(id, channel, sender, model, parent_session_id, prompt_tokens, "
            "completion_tokens, cost, title, message_count, created_at, updated_at) "
            "SELECT id, channel, sender, model, "
            "CASE WHEN parent_session_id IN (SELECT id FROM source_sessions) "
            "THEN parent_session_id ELSE NULL END, COALESCE(prompt_tokens,0), "
            "COALESCE(completion_tokens,0), COALESCE(cost,0.0), title, "
            "(SELECT count(*) FROM source_messages m WHERE m.session_id=source_sessions.id), "
            "created_at, updated_at FROM source_sessions"
        )
        conn.execute("INSERT INTO counters SELECT key, COALESCE(value,0) FROM source_counters")
        conn.execute("DROP TABLE source_messages")
        conn.execute("DROP TABLE source_sessions")
        conn.execute("DROP TABLE source_counters")
        conn.execute(f"PRAGMA application_id={_APPLICATION_ID}")
        conn.execute(f"PRAGMA user_version={_SCHEMA_VERSION}")
        _validate_database(conn)
        conn.commit()
    except BaseException:
        conn.rollback()
        for path in published:
            path.unlink(missing_ok=True)
        raise
    return backup_path


def _prepare_database(db_path: Path, transcript_dir: Path | None = None) -> None:
    transcript_dir = transcript_dir or (db_path.parent / "sessions")
    lock = FileLock(str(db_path) + ".schema.lock", timeout=60)
    with lock:
        conn = sqlite3.connect(str(db_path), isolation_level=None)
        conn.row_factory = sqlite3.Row
        try:
            _configure_sqlite_before_classification(conn)
            application_id = int(conn.execute("PRAGMA application_id").fetchone()[0])
            version = int(conn.execute("PRAGMA user_version").fetchone()[0])
            if (
                application_id == _APPLICATION_ID
                and version == _SCHEMA_VERSION
                and _is_current_schema(conn)
            ):
                _configure_supported_sqlite(conn)
            elif (
                application_id == _APPLICATION_ID
                and version == _SCHEMA_VERSION
                and _is_pre_release_sqlite_v1(conn)
            ):
                _configure_supported_sqlite(conn)
                backup = _migrate_sqlite_transcripts(
                    conn,
                    db_path,
                    transcript_dir,
                    source="pre-release-sqlite-v1",
                )
                logger.info(
                    "Replaced pre-release SQLite transcript schema v1 with JSONL transcripts "
                    "backup={}",
                    backup,
                )
            elif application_id == _APPLICATION_ID and version > _SCHEMA_VERSION:
                raise SessionSchemaError(
                    f"sessions.db schema v{version} is newer than supported v{_SCHEMA_VERSION}"
                )
            elif application_id == 0 and version == 0 and _is_empty_database(conn):
                _configure_supported_sqlite(conn)
                conn.execute("BEGIN IMMEDIATE")
                try:
                    _create_current_schema(conn)
                    conn.execute(f"PRAGMA application_id={_APPLICATION_ID}")
                    conn.execute(f"PRAGMA user_version={_SCHEMA_VERSION}")
                    _validate_database(conn)
                    conn.commit()
                except BaseException:
                    conn.rollback()
                    raise
            elif application_id == 0 and version == 0 and _is_legacy_v0(conn):
                _configure_supported_sqlite(conn)
                backup = _migrate_sqlite_transcripts(
                    conn, db_path, transcript_dir, source="legacy-v0"
                )
                logger.info(
                    "Migrated legacy session schema v0 to v{} backup={}", _SCHEMA_VERSION, backup
                )
            else:
                raise SessionSchemaError(
                    "sessions.db has an unknown schema identity/version "
                    f"(application_id={application_id}, user_version={version}); move it aside "
                    "or delete it explicitly before starting PraestoClaw"
                )
            migrated_scheduler_sessions = _migrate_legacy_local_scheduler_ownership(conn)
            if migrated_scheduler_sessions:
                logger.info(
                    "Migrated {} legacy local scheduler session owner(s) channel={} sender={}",
                    migrated_scheduler_sessions,
                    _LOCAL_SCHEDULER_CHANNEL,
                    _SCHEDULER_SENDER,
                )
            migrated_group_sessions = _migrate_legacy_praesto_tag_exp_ownership(conn)
            if migrated_group_sessions:
                logger.info(
                    "Migrated {} legacy praesto tag experiment session owner(s)",
                    migrated_group_sessions,
                )
            _validate_database(conn)
            session_count = int(conn.execute("SELECT count(*) FROM sessions").fetchone()[0])
            message_count = int(
                conn.execute("SELECT COALESCE(sum(message_count), 0) FROM sessions").fetchone()[0]
            )
            logger.info(
                "Session DB ready schema={} sqlite={} journal=wal synchronous=full "
                "foreign_keys=on sessions={} messages={}",
                _SCHEMA_VERSION,
                sqlite3.sqlite_version,
                session_count,
                message_count,
            )
        finally:
            conn.close()


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _normalize_ts(ts: object, *, fallback: str | None = None) -> str:
    """Normalize a caller-supplied timestamp to the canonical ``_now()`` form.

    All transcript message timestamps are sorted/compared as strings and
    parsed via ``datetime.fromisoformat`` elsewhere. ``_now()`` emits UTC
    ``...+00:00``, so caller input must converge on the same shape. We:

    1. Reject non-string input by falling back to ``fallback`` (or, if
       unset, ``_now()``). The parameter is typed ``object`` because the
       defensive check is part of the contract, not just a belt-and-braces
       guard.
    2. Substitute trailing ``Z`` with ``+00:00`` so callers using the
       compact UTC spelling are accepted regardless of which ISO 8601
       sub-format their source emits.
    3. Parse, then force to UTC: naive inputs are assumed UTC; aware
       offsets are converted. This guarantees every stored value is a
       UTC ``...+00:00`` string regardless of caller spelling.
    4. Re-emit via ``datetime.isoformat`` to converge on one shape.

    Unparseable input falls back to ``fallback`` (or ``_now()``) rather
    than poisoning the column with arbitrary strings. Callers that have
    already captured a ``now`` should pass it as ``fallback`` so a malformed
    override does not drift the transcript timestamp past the matching
    ``sessions.updated_at`` metadata written by the same mutation.
    """
    if not isinstance(ts, str):
        return fallback if fallback is not None else _now()
    try:
        cleaned = ts[:-1] + "+00:00" if ts.endswith("Z") else ts
        parsed = datetime.fromisoformat(cleaned)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=UTC)
        else:
            parsed = parsed.astimezone(UTC)
        return parsed.isoformat()
    except (TypeError, ValueError):
        return fallback if fallback is not None else _now()


# Maps a session id prefix or channel alias to a UI group.
# Single source of truth — chat.js trusts the `group` field on each row.
_CHANNEL_PREFIXES: tuple[tuple[tuple[str, ...], str], ...] = (
    (("teams:", "cloud_teams"), "teams"),
    (("webchat:", "cloud_web", "cloud_webchat"), "web"),
    (("scheduler",), "scheduler"),
    (("a2a:", "u2u:"), "a2a"),
)

_CHANNEL_ID_MARKERS: tuple[tuple[tuple[str, ...], str], ...] = (
    ((":teams:",), "teams"),
    ((":webchat:",), "web"),
    ((":a2a", ":u2u"), "a2a"),
)

# Direct channel -> UI group mapping. Aliases collapse here (e.g. local_webchat -> web).
_CHANNEL_TO_GROUP: dict[str, str] = {
    "web": "web",
    "local_webchat": "web",
    "teams": "teams",
    "scheduler": "scheduler",
    "a2a": "a2a",
}

_INTERACTIVE_SESSION_SQL = (
    "(LOWER(s.channel) IN ('web', 'local_webchat', 'teams') "
    "OR LOWER(s.id) LIKE 'teams:%' "
    "OR LOWER(s.id) LIKE 'webchat:%' "
    "OR LOWER(s.id) LIKE '%:teams:%' "
    "OR LOWER(s.id) LIKE '%:webchat:%')"
)


def _infer_channel_from_id(session_id: str) -> str:
    sid = (session_id or "").lower()
    for prefixes, channel in _CHANNEL_PREFIXES:
        if sid.startswith(prefixes):
            return channel
    for markers, channel in _CHANNEL_ID_MARKERS:
        if any(marker in sid for marker in markers):
            return channel
    return "cloud"


def _group_for_row(session_id: str, channel: str | None) -> str:
    ch = (channel or "").lower()
    if ch in _CHANNEL_TO_GROUP:
        return _CHANNEL_TO_GROUP[ch]
    return _infer_channel_from_id(session_id)


class _AsyncReadWriteLock:
    """Writer-preferring per-session lock owned by the store's event loop."""

    def __init__(self) -> None:
        self._condition = asyncio.Condition()
        self._readers = 0
        self._writer = False
        self._waiting_writers = 0

    async def acquire_read(self) -> None:
        async with self._condition:
            await self._condition.wait_for(lambda: not self._writer and self._waiting_writers == 0)
            self._readers += 1

    async def release_read(self) -> None:
        async with self._condition:
            self._readers -= 1
            self._condition.notify_all()

    async def acquire_write(self) -> None:
        async with self._condition:
            self._waiting_writers += 1
            try:
                await self._condition.wait_for(lambda: not self._writer and self._readers == 0)
                self._writer = True
            finally:
                self._waiting_writers -= 1
                # A cancelled writer may have been the only reason queued
                # readers were still blocked by writer preference.
                self._condition.notify_all()

    async def release_write(self) -> None:
        async with self._condition:
            self._writer = False
            self._condition.notify_all()


class SessionStore:
    """Async metadata store backed by append-only per-session transcripts."""

    def __init__(self, db_path: Path | None = None) -> None:
        self._db_path = db_path or (get_data_dir() / "sessions.db")
        self._transcripts = TranscriptStore(self._db_path.parent / "sessions")
        self._writer: aiosqlite.Connection | None = None
        self._reader: aiosqlite.Connection | None = None
        self._owner_loop: asyncio.AbstractEventLoop | None = None
        self._writer_lock: asyncio.Lock | None = None
        self._transcript_locks: dict[str, _AsyncReadWriteLock] = {}
        self._transaction_task: asyncio.Task[object] | None = None
        self._active_readers = 0
        self._no_active_readers: asyncio.Event | None = None
        self._initializing = False
        self._initialize_event: asyncio.Event | None = None
        self._closing = False

    async def initialize(self) -> None:
        loop = asyncio.get_running_loop()
        if self._owner_loop is not None:
            self._check_owner()
            if self._initializing:
                assert self._initialize_event is not None
                await self._initialize_event.wait()
                if self.is_initialized:
                    return
                raise RuntimeError("SessionStore initialization failed")
            raise RuntimeError("SessionStore is already initialized")
        # Claim lifecycle ownership before the first await so two initialize
        # tasks cannot both open and install independent connection pairs.
        self._owner_loop = loop
        self._writer_lock = asyncio.Lock()
        self._no_active_readers = asyncio.Event()
        self._no_active_readers.set()
        self._initializing = True
        self._initialize_event = asyncio.Event()
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        writer: aiosqlite.Connection | None = None
        reader: aiosqlite.Connection | None = None
        try:
            # The blocking cross-process gate runs off-loop. No reader or business
            # connection exists until it has committed the schema transition.
            await self._cleanup(
                asyncio.to_thread(
                    _prepare_database,
                    self._db_path,
                    self._transcripts.directory,
                )
            )
            writer = await aiosqlite.connect(str(self._db_path))
            writer.row_factory = aiosqlite.Row
            await self._configure_connection(writer)
            reader = await aiosqlite.connect(str(self._db_path))
            reader.row_factory = aiosqlite.Row
            await self._configure_connection(reader)
        except BaseException:
            try:
                if reader is not None:
                    await self._cleanup(reader.close())
            finally:
                try:
                    if writer is not None:
                        await self._cleanup(writer.close())
                finally:
                    self._owner_loop = None
                    self._writer_lock = None
                    self._transcript_locks.clear()
                    self._no_active_readers = None
                    self._initializing = False
                    assert self._initialize_event is not None
                    self._initialize_event.set()
            raise
        self._writer = writer
        self._reader = reader
        self._initializing = False
        assert self._initialize_event is not None
        self._initialize_event.set()

    @staticmethod
    async def _configure_connection(conn: aiosqlite.Connection) -> None:
        await conn.execute("PRAGMA foreign_keys=ON")
        await conn.execute(f"PRAGMA busy_timeout={_BUSY_TIMEOUT_MS}")
        cursor = await conn.execute("PRAGMA journal_mode=WAL")
        row = await cursor.fetchone()
        if row is None or str(row[0]).lower() != "wal":
            raise SessionSchemaError("sessions.db could not enable WAL journal mode")
        await conn.execute("PRAGMA synchronous=FULL")
        await conn.execute("PRAGMA wal_autocheckpoint=1000")
        fk = await (await conn.execute("PRAGMA foreign_keys")).fetchone()
        if fk is None or int(fk[0]) != 1:
            raise SessionSchemaError("sessions.db could not enable foreign keys")

    async def close(self) -> None:
        if self._owner_loop is None:
            return
        if asyncio.get_running_loop() is not self._owner_loop:
            raise RuntimeError("SessionStore cannot be used from a different event loop")
        if self._initializing:
            raise RuntimeError("SessionStore is still initializing")
        assert self._writer_lock is not None
        lock = self._writer_lock
        async with lock:
            # Another close call may have completed while this task waited.
            if self._writer_lock is not lock:
                return
            self._closing = True
            assert self._no_active_readers is not None
            try:
                await self._no_active_readers.wait()
            except BaseException:
                self._closing = False
                raise
            reader, writer = self._reader, self._writer
            self._reader = None
            self._writer = None
            try:
                if reader is not None:
                    await self._cleanup(reader.close())
            finally:
                try:
                    if writer is not None:
                        try:
                            await self._cleanup(writer.execute("PRAGMA wal_checkpoint(PASSIVE)"))
                        finally:
                            await self._cleanup(writer.close())
                finally:
                    self._owner_loop = None
                    self._writer_lock = None
                    self._transcript_locks.clear()
                    self._no_active_readers = None
                    self._closing = False

    def _check_owner(self) -> None:
        if self._owner_loop is None:
            raise RuntimeError("SessionStore is not initialized")
        if asyncio.get_running_loop() is not self._owner_loop:
            raise RuntimeError("SessionStore cannot be used from a different event loop")
        if self._closing:
            raise RuntimeError("SessionStore is closing")

    @asynccontextmanager
    async def _read_connection(self) -> AsyncIterator[aiosqlite.Connection]:
        """Keep the reader open for the full execute/fetch operation."""
        self._check_owner()
        if self._no_active_readers is None:
            raise RuntimeError("SessionStore is not initialized")
        reader = self._reader_conn
        no_active_readers = self._no_active_readers
        self._active_readers += 1
        no_active_readers.clear()
        try:
            yield reader
        finally:
            self._active_readers -= 1
            if self._active_readers == 0:
                no_active_readers.set()

    async def _fetchone(
        self, query: str, parameters: tuple[object, ...] = ()
    ) -> aiosqlite.Row | None:
        async with self._read_connection() as conn:
            cursor = await conn.execute(query, parameters)
            return await cursor.fetchone()

    async def _fetchall(
        self, query: str, parameters: tuple[object, ...] = ()
    ) -> list[aiosqlite.Row]:
        async with self._read_connection() as conn:
            cursor = await conn.execute(query, parameters)
            return list(await cursor.fetchall())

    @staticmethod
    async def _cleanup(awaitable: Coroutine[Any, Any, object]) -> None:
        """Finish transaction cleanup even if the caller is cancelled again."""
        task: asyncio.Task[object] = asyncio.create_task(awaitable)
        cancellation: asyncio.CancelledError | None = None
        while not task.done():
            try:
                await asyncio.shield(task)
            except asyncio.CancelledError as exc:
                cancellation = exc
        task.result()
        if cancellation is not None:
            raise cancellation

    @staticmethod
    async def _complete_mutation(awaitable: Coroutine[Any, Any, _T]) -> _T:
        """Let a cross-file mutation finish before propagating cancellation."""
        task: asyncio.Task[_T] = asyncio.create_task(awaitable)
        cancellation: asyncio.CancelledError | None = None
        while not task.done():
            try:
                await asyncio.shield(task)
            except asyncio.CancelledError as exc:
                cancellation = exc
        result = task.result()
        if cancellation is not None:
            raise cancellation
        return result

    @asynccontextmanager
    async def _transaction(self) -> AsyncIterator[aiosqlite.Connection]:
        """Own one complete write transaction on this store's writer connection."""
        self._check_owner()
        assert self._writer_lock is not None
        current = asyncio.current_task()
        if current is not None and current is self._transaction_task:
            raise RuntimeError("Nested SessionStore transactions are not supported")
        lock = self._writer_lock
        await lock.acquire()
        try:
            if self._writer_lock is not lock:
                raise RuntimeError("SessionStore lifecycle changed while waiting to write")
            self._transaction_task = current
            writer = self._write_conn
            try:
                await writer.execute("BEGIN IMMEDIATE")
            except BaseException:
                await self._cleanup(writer.rollback())
                raise
            try:
                yield writer
            except BaseException:
                await self._cleanup(writer.rollback())
                raise
            else:
                try:
                    await self._cleanup(writer.commit())
                except BaseException:
                    if writer.in_transaction:
                        await self._cleanup(writer.rollback())
                    raise
        finally:
            self._transaction_task = None
            lock.release()

    @asynccontextmanager
    async def _session_guard(self, session_id: str) -> AsyncIterator[None]:
        """Serialize transcript and lifecycle operations across processes."""
        self._check_owner()
        session_lock = self._transcript_locks.setdefault(session_id, _AsyncReadWriteLock())
        lock = self._transcripts.file_lock(session_id)
        await session_lock.acquire_write()
        try:
            await self._acquire_thread_lock(lock.acquire, lock.release)
            try:
                yield
            finally:
                await self._cleanup(asyncio.to_thread(lock.release))
        finally:
            await self._cleanup(session_lock.release_write())

    @asynccontextmanager
    async def _session_read_guard(self, session_id: str) -> AsyncIterator[None]:
        """Allow parallel readers while excluding this process's JSONL writer."""
        self._check_owner()
        session_lock = self._transcript_locks.setdefault(session_id, _AsyncReadWriteLock())
        await session_lock.acquire_read()
        try:
            yield
        finally:
            await self._cleanup(session_lock.release_read())

    @staticmethod
    async def _acquire_thread_lock(
        acquire: Callable[[], object], release: Callable[[], object]
    ) -> None:
        """Acquire a blocking lock without leaking it if this task is cancelled."""
        task = asyncio.create_task(asyncio.to_thread(acquire))
        cancellation: asyncio.CancelledError | None = None
        while not task.done():
            try:
                await asyncio.shield(task)
            except asyncio.CancelledError as exc:
                cancellation = exc
        task.result()
        if cancellation is not None:
            await asyncio.to_thread(release)
            raise cancellation

    async def _read_transcript(
        self, session_id: str, method: str, *args: object, **kwargs: object
    ) -> Any:
        """Read normally under a shared lock, upgrading only to repair a bad tail."""
        try:
            async with self._session_read_guard(session_id):
                return await asyncio.to_thread(
                    getattr(self._transcripts, method), session_id, *args, **kwargs
                )
        except TranscriptCorruptionError:
            async with self._session_guard(session_id):
                await asyncio.to_thread(self._transcripts.repair_tail_if_needed, session_id)
                return await asyncio.to_thread(
                    getattr(self._transcripts, method), session_id, *args, **kwargs
                )

    @property
    def _write_conn(self) -> aiosqlite.Connection:
        self._check_owner()
        if self._writer is None:
            raise RuntimeError("SessionStore is not initialized")
        return self._writer

    @property
    def _reader_conn(self) -> aiosqlite.Connection:
        self._check_owner()
        if self._reader is None:
            raise RuntimeError("SessionStore is not initialized")
        return self._reader

    @property
    def is_initialized(self) -> bool:
        return self._writer is not None and self._reader is not None

    @staticmethod
    def generate_id() -> str:
        """Generate a new opaque session identifier."""
        return str(uuid.uuid4())

    async def get_or_create_session(self, channel: str, sender: str) -> str:
        created_at: str | None = None
        async with self._transaction() as conn:
            cursor = await conn.execute(
                "SELECT id FROM sessions WHERE channel = ? AND sender = ? "
                "ORDER BY updated_at DESC LIMIT 1",
                (channel, sender),
            )
            row = await cursor.fetchone()
            if row is not None:
                sid = str(row["id"])
            else:
                sid = str(uuid.uuid4())
                created_at = _now()
                await conn.execute(
                    "INSERT INTO sessions (id, channel, sender, created_at, updated_at) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (sid, channel, sender, created_at, created_at),
                )
        async with self._session_guard(sid):
            await asyncio.to_thread(
                self._transcripts.ensure_file,
                sid,
                created_at=created_at,
            )
        return sid

    async def find_session(self, channel: str, sender: str) -> str | None:
        row = await self._fetchone(
            "SELECT id FROM sessions WHERE channel = ? AND sender = ? ORDER BY updated_at DESC LIMIT 1",
            (channel, sender),
        )
        return str(row["id"]) if row else None

    async def ensure_session(
        self, session_id: str, channel: str, sender: str, *, claim: bool = True
    ) -> None:
        """Ensure a row exists for *session_id*, binding it to channel/sender.

        Identity is never re-bound: an existing row whose channel/sender differ
        raises rather than being overwritten.

        ``claim=False`` is for callers that need the row to exist but do not
        know the binding — a spawned sub-agent runs on a session ``fork()``
        already created, carrying the parent's channel and sender, and the
        run-once entry point has only placeholder defaults to offer. Asserting
        those would claim a binding the caller does not hold, and the raise
        above would fire on every sub-agent spawned from a cloud conversation.
        A non-claiming call leaves an existing binding exactly as it is; the
        arguments are used only when the row has to be created.
        """
        created_at: str | None = None
        async with self._transaction() as conn:
            cursor = await conn.execute(
                "SELECT channel, sender FROM sessions WHERE id = ?", (session_id,)
            )
            existing = await cursor.fetchone()
            if existing is not None:
                if claim and (existing["channel"] != channel or existing["sender"] != sender):
                    raise ValueError(
                        f"Session {session_id} already belongs to "
                        f"channel={existing['channel']!r}, sender={existing['sender']!r}"
                    )
            else:
                created_at = _now()
                await conn.execute(
                    "INSERT INTO sessions (id, channel, sender, created_at, updated_at) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (session_id, channel, sender, created_at, created_at),
                )
        async with self._session_guard(session_id):
            await asyncio.to_thread(
                self._transcripts.ensure_file,
                session_id,
                created_at=created_at,
            )

    async def session_exists(self, session_id: str) -> bool:
        row = await self._fetchone(
            "SELECT 1 FROM sessions WHERE id = ? LIMIT 1",
            (session_id,),
        )
        return row is not None

    async def child_session_ids(self, session_id: str) -> list[str]:
        """Recent direct children linked by runtime fork provenance."""
        rows = await self._fetchall(
            "SELECT id FROM sessions WHERE parent_session_id = ? ORDER BY updated_at DESC LIMIT 100",
            (session_id,),
        )
        return [row["id"] for row in rows]

    async def get_session_sender(self, session_id: str) -> str | None:
        """Return the ``sender`` recorded for *session_id*, or ``None``.

        Used as the durable per-user key for cross-session counters (e.g. the
        adaptive promotion-receipt ramp) — the ``sender`` column is the stable
        user identity regardless of the session id's internal format.
        """
        row = await self._fetchone(
            "SELECT sender FROM sessions WHERE id = ?",
            (session_id,),
        )
        return row["sender"] if row else None

    async def increment_counter(self, key: str) -> int:
        """Atomically increment the integer counter *key* by 1 and return it.

        Backed by the ``counters`` KV table. The counter starts at 0; the
        first call returns 1. Durable across restarts so cross-session,
        per-user ramps (e.g. the adaptive promotion receipt) survive a daemon
        bounce instead of resetting to the verbose default.

        Uses an UPSERT followed by a read-back ``SELECT`` rather than the
        ``RETURNING`` clause, which requires SQLite >= 3.35 — older system
        SQLite builds (e.g. on some Linux distros) would fail at runtime.
        UPSERT (``ON CONFLICT``) is supported since SQLite 3.24.
        """
        async with self._transaction() as conn:
            await conn.execute(
                "INSERT INTO counters(key, value) VALUES(?, 1) "
                "ON CONFLICT(key) DO UPDATE SET value = value + 1",
                (key,),
            )
            cursor = await conn.execute("SELECT value FROM counters WHERE key = ?", (key,))
            row = await cursor.fetchone()
            return int(row["value"]) if row else 1

    async def add_message(
        self,
        session_id: str,
        message_dict: dict,
        *,
        created_at: str | None = None,
    ) -> int:
        """Append one canonical message event.

        ``created_at`` defaults to ``_now()``. Callers that need to preserve
        a pre-existing timestamp (typically when re-inserting messages via
        :meth:`replace_messages` after compaction/trim) can pass it
        explicitly so the replacement checkpoint does not collapse every event's
        ``created_at`` to the bulk-insert moment, which destroys forensic
        timelines (issue #345).
        """
        return await self._complete_mutation(
            self._add_message(session_id, message_dict, created_at=created_at)
        )

    async def _add_message(
        self,
        session_id: str,
        message_dict: dict,
        *,
        created_at: str | None,
    ) -> int:
        now = _now()
        timestamp = _normalize_ts(created_at, fallback=now) if created_at else now
        async with self._session_guard(session_id):
            async with self._transaction() as conn:
                await self._require_session(conn, session_id)
                rowid = await asyncio.to_thread(
                    self._transcripts.append_message,
                    session_id,
                    message_dict,
                    created_at=timestamp,
                )
                await conn.execute(
                    "UPDATE sessions SET updated_at = ?, message_count = message_count + 1 "
                    "WHERE id = ?",
                    (now, session_id),
                )
                return rowid

    @staticmethod
    async def _require_session(conn: aiosqlite.Connection, session_id: str) -> None:
        cursor = await conn.execute("SELECT 1 FROM sessions WHERE id = ?", (session_id,))
        if await cursor.fetchone() is None:
            raise SessionNotFoundError(f"Session {session_id} not found")

    async def get_messages(self, session_id: str, *, limit: int | None = None) -> list[dict]:
        if not await self.session_exists(session_id):
            return []
        if not self._transcripts.path_for(session_id).exists():
            async with self._session_guard(session_id):
                # A same-process delete may have won the guard after the
                # optimistic metadata/path checks above.
                if not await self.session_exists(session_id):
                    return []
                await asyncio.to_thread(self._transcripts.ensure_file, session_id)
        records = await self._read_transcript(session_id, "replay")
        messages = [dict(record.message) for record in records]
        return messages[-limit:] if limit else messages

    async def get_messages_by_rowids(
        self, session_id: str, rowids: list[int]
    ) -> list[tuple[int, dict, str | None]]:
        """Return ``(rowid, message_dict, created_at)`` for each requested id.

        Ordered by ``id ASC`` so the original turn order is preserved on
        replay. Rowids belonging to other sessions are silently filtered out
        because each transcript is session-scoped. Used by the event-loop
        promotion path to capture a snapshot of the in-flight tool events
        before pruning, so that a later ``adopt()`` cap-race
        rejection can re-insert the same content back into MAIN and keep
        the durable history intact.

        Empty ``rowids`` returns an empty list without reading the transcript.
        """
        if not rowids:
            self._check_owner()
            return []
        if not await self.session_exists(session_id):
            return []
        rows = await self._read_transcript(session_id, "message_rows", rowids)
        return [(rowid, message, created_at) for rowid, message, created_at in rows]

    async def get_message_records(
        self, session_id: str
    ) -> list[tuple[int | None, dict[str, Any], str]]:
        """Return the current replay view with durable ids and timestamps."""
        if not await self.session_exists(session_id):
            return []
        records = await self._read_transcript(session_id, "replay")
        return [(record.event_id, dict(record.message), record.created_at) for record in records]

    async def get_assistant_rows_with_timestamps(self, session_id: str) -> list[tuple[str, str]]:
        """Return assistant content and timestamps without exposing a connection."""
        if not await self.session_exists(session_id):
            return []
        records = await self._read_transcript(session_id, "replay")
        return [
            (str(record.message.get("content") or ""), record.created_at)
            for record in records
            if record.message.get("role") == "assistant"
        ]

    async def replace_messages(
        self,
        session_id: str,
        messages: list[dict],
        *,
        reason: str = "replace",
    ) -> None:
        """Publish a replacement-history checkpoint for ``session_id``.

        Each ``msg`` may carry a ``"_created_at"`` key (leading underscore
        marks it as non-LLM metadata). When present, that timestamp is
        preserved in the replacement checkpoint instead of stamping every
        message with the checkpoint time. Callers that don't care can simply
        omit the key. Caller-owned dictionaries are not mutated.
        """
        await self._complete_mutation(self._replace_messages(session_id, messages, reason=reason))

    async def _replace_messages(
        self,
        session_id: str,
        messages: list[dict],
        *,
        reason: str,
    ) -> None:
        now = _now()
        normalized: list[dict] = []
        for msg in messages:
            item = dict(msg)
            raw = item.get("_created_at")
            if isinstance(raw, str):
                item["_created_at"] = _normalize_ts(raw, fallback=now)
            elif "_created_at" in item:
                item["_created_at"] = now
            normalized.append(item)
        async with self._session_guard(session_id):
            async with self._transaction() as conn:
                await self._require_session(conn, session_id)
                await asyncio.to_thread(
                    self._transcripts.append_checkpoint,
                    session_id,
                    normalized,
                    reason=reason,
                    created_at=now,
                )
                await conn.execute(
                    "UPDATE sessions SET updated_at = ?, message_count = ? WHERE id = ?",
                    (now, len(messages), session_id),
                )

    async def delete_messages(self, session_id: str, rowids: list[int]) -> int:
        """Append a tombstone event for a subset of message ids.

        Returns the number of live messages removed from the replay view.
        An empty ``rowids`` list is a no-op. Ids absent from this session's
        transcript are silently ignored.

        Implementation notes:

        - The tombstone and derived SQLite metadata update complete as one
          cancellation-shielded mutation.
        - A no-op for unknown ids does not change ``updated_at``.
        """
        if not rowids:
            self._check_owner()
            return 0
        return await self._complete_mutation(self._delete_messages(session_id, rowids))

    async def _delete_messages(self, session_id: str, rowids: list[int]) -> int:
        now = _now()
        async with self._session_guard(session_id):
            async with self._transaction() as conn:
                await self._require_session(conn, session_id)
                deleted = await asyncio.to_thread(
                    self._transcripts.delete_messages,
                    session_id,
                    rowids,
                    created_at=now,
                )
                if deleted:
                    await conn.execute(
                        "UPDATE sessions SET updated_at = ?, "
                        "message_count = MAX(message_count - ?, 0) WHERE id = ?",
                        (now, deleted, session_id),
                    )
                return deleted

    async def fork(self, session_id: str) -> str:
        async with self._transaction() as conn:
            cursor = await conn.execute(
                "SELECT channel, sender FROM sessions WHERE id = ?", (session_id,)
            )
            row = await cursor.fetchone()
            if row is None:
                raise SessionNotFoundError(f"Session {session_id} not found")
            child_id = str(uuid.uuid4())
            now = _now()
            await conn.execute(
                "INSERT INTO sessions "
                "(id, channel, sender, parent_session_id, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (child_id, row["channel"], row["sender"], session_id, now, now),
            )
        async with self._session_guard(child_id):
            await asyncio.to_thread(
                self._transcripts.ensure_file,
                child_id,
                created_at=now,
            )
        return child_id

    async def list_main_sessions(self, *, limit: int = 100) -> list[str]:
        """Return ids of recent main (non-worker) sessions, newest first.

        ``parent_session_id IS NULL`` filters out worker sessions created by
        :meth:`fork`. Used by ``BackgroundTaskManager.reap_orphan_acks`` at
        startup to find main sessions that may carry leftover ``[BG task=…]``
        ack rows whose tasks died with the previous process. Read-only; no
        schema change.
        """
        rows = await self._fetchall(
            "SELECT id FROM sessions WHERE parent_session_id IS NULL "
            "ORDER BY updated_at DESC LIMIT ?",
            (limit,),
        )
        return [r["id"] for r in rows]

    async def search(
        self, query: str, *, session_id: str | None = None, limit: int = 20
    ) -> list[dict]:
        if session_id:
            session_ids = [session_id] if await self.session_exists(session_id) else []
        else:
            rows = await self._fetchall("SELECT id FROM sessions ORDER BY updated_at DESC")
            session_ids = [str(row["id"]) for row in rows]
        results: list[dict] = []
        for current_session_id in session_ids:
            matches = await self._read_transcript(
                current_session_id,
                "search_session",
                query,
                limit=limit - len(results),
            )
            results.extend(matches)
            if len(results) >= limit:
                break
        return results

    async def find_session_for_approval_request(self, request_id: str) -> str | None:
        """Find the session containing a persisted approval request.

        Approval resolution events arrive with a request id but no session id.
        Scan canonical transcripts for candidates, then parse the approval
        payload so substring matches cannot produce false positives.
        """
        rows = await self.search(request_id, limit=50)
        for row in reversed(rows):
            if row.get("role") != "approval_request":
                continue
            try:
                payload = json.loads(row.get("content") or "{}")
            except (TypeError, json.JSONDecodeError):
                continue
            if isinstance(payload, dict) and payload.get("request_id") == request_id:
                return str(row["session_id"])
        return None

    async def stats(self) -> dict[str, int]:
        """Return lightweight canonical session-database counts."""
        row = await self._fetchone(
            "SELECT "
            "(SELECT COUNT(*) FROM sessions) AS session_count, "
            "(SELECT COALESCE(SUM(message_count), 0) FROM sessions) AS message_count"
        )
        return {
            "session_count": int(row["session_count"]) if row else 0,
            "message_count": int(row["message_count"]) if row else 0,
        }

    async def update_usage(
        self, session_id: str, prompt_tokens: int, completion_tokens: int, cost: float
    ) -> None:
        async with self._transaction() as conn:
            cursor = await conn.execute(
                "UPDATE sessions SET prompt_tokens = prompt_tokens + ?, "
                "completion_tokens = completion_tokens + ?, cost = cost + ?, "
                "updated_at = ? WHERE id = ?",
                (prompt_tokens, completion_tokens, cost, _now(), session_id),
            )
            if cursor.rowcount != 1:
                raise SessionNotFoundError(f"Session {session_id} not found")

    async def smart_load(self, session_id: str, token_budget: int) -> list[dict]:
        rows = await self.get_messages(session_id)
        result: list[dict] = []
        total = 0
        for row in reversed(rows):
            content = row.get("content")
            if isinstance(content, str):
                tokens = count_tokens(content)
            else:
                tokens = count_tokens(json.dumps(content, ensure_ascii=False)) if content else 0
            if total + tokens > token_budget and result:
                break
            result.append(row)
            total += tokens
        result.reverse()
        return result

    async def list_sessions(
        self, *, channel: str | None = None, limit: int | None = 200
    ) -> list[dict]:
        # Include message_count via LEFT JOIN; alias `id` to `session_id` so
        # the API surface matches the single-session endpoint.
        base = "SELECT s.*, s.id AS session_id FROM sessions s"
        rows: list[dict]
        if channel:
            query = f"{base} WHERE s.channel = ? ORDER BY s.updated_at DESC"
            params: tuple[object, ...]
            if limit is None:
                params = (channel,)
            else:
                query += " LIMIT ?"
                params = (channel, limit)
            rows = [dict(r) for r in await self._fetchall(query, params)]
        else:
            if limit is None:
                rows = [dict(r) for r in await self._fetchall(f"{base} ORDER BY s.updated_at DESC")]
            else:
                rows = []
                for where_clause in (
                    _INTERACTIVE_SESSION_SQL,
                    f"NOT {_INTERACTIVE_SESSION_SQL}",
                ):
                    query_rows = await self._fetchall(
                        f"{base} WHERE {where_clause} ORDER BY s.updated_at DESC LIMIT ?",
                        (limit,),
                    )
                    rows.extend(dict(r) for r in query_rows)
                    if len(rows) >= limit:
                        break

        if channel:
            for r in rows:
                r["group"] = _group_for_row(
                    r.get("session_id") or r.get("id") or "", r.get("channel")
                )
            return rows if limit is None else rows[:limit]
        for r in rows:
            r["group"] = _group_for_row(r.get("session_id") or r.get("id") or "", r.get("channel"))
        rows.sort(key=lambda r: r.get("updated_at") or "", reverse=True)
        if limit is None:
            return rows
        interactive = [r for r in rows if r.get("group") in ("web", "teams")]
        secondary = [r for r in rows if r.get("group") not in ("web", "teams")]
        return (interactive + secondary)[:limit]

    async def delete_session(self, session_id: str) -> None:
        await self._complete_mutation(self._delete_session(session_id))

    async def _delete_session(self, session_id: str) -> None:
        async with self._session_guard(session_id):
            async with self._transaction() as conn:
                await conn.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
            await asyncio.to_thread(self._transcripts.remove_file, session_id)
