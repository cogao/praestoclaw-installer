"""
LLM provider abstraction — defines the interface for all LLM backends.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ToolCallRequest:
    """A tool call requested by the LLM."""

    id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class LLMResponse:
    """Unified response from any LLM provider."""

    content: str = ""
    tool_calls: list[ToolCallRequest] = field(default_factory=list)
    finish_reason: str = "stop"
    model: str = ""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    duration_ms: float = 0
    reasoning_content: str | None = None  # gpt-5.4, DeepSeek-R1, Kimi etc.

    @property
    def has_tool_calls(self) -> bool:
        """True if the response contains any tool calls."""
        return len(self.tool_calls) > 0


@dataclass
class LLMChunk:
    """A single chunk from a streaming LLM response."""

    content: str = ""
    tool_calls: list[ToolCallRequest] = field(default_factory=list)
    finish_reason: str | None = None
    model: str = ""


class LLMProvider:
    """
    Abstract LLM provider interface.

    All providers implement `complete()` which takes OpenAI-compatible
    messages + tools and returns a unified LLMResponse.

    Providers may also implement `stream()` to yield incremental chunks
    for real-time token delivery.

    Capability properties describe what features the backend supports.
    """

    @property
    def supports_cache_control(self) -> bool:
        """Whether this provider supports prompt cache control (e.g. Anthropic)."""
        return False

    @property
    def supports_thinking(self) -> bool:
        """Whether this provider supports extended thinking / reasoning."""
        return False

    @property
    def api_mode(self) -> str:
        """API wire format: chat_completions, anthropic_messages, responses, etc."""
        return "chat_completions"

    async def aclose(self) -> None:
        """Release provider-owned resources."""

    async def complete(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> LLMResponse:
        raise NotImplementedError

    async def stream(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> AsyncIterator[LLMChunk]:
        """Yield response chunks for streaming. Default: fall back to complete()."""
        response = await self.complete(
            model=model,
            messages=messages,
            tools=tools,
            max_tokens=max_tokens,
            reasoning_effort=reasoning_effort,
        )
        yield LLMChunk(
            content=response.content,
            tool_calls=response.tool_calls,
            finish_reason=response.finish_reason,
            model=response.model,
        )
