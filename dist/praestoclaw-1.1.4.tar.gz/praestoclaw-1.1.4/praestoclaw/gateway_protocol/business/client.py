"""Business protocol client that sits on top of the transport client."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator, Mapping
from dataclasses import dataclass, field
from typing import Any

from loguru import logger

from praestoclaw.gateway_protocol.business.data import SessionHello
from praestoclaw.gateway_protocol.business.debug_log import log_business_envelope_debug
from praestoclaw.gateway_protocol.business.dispatcher import Dispatcher, RequestContext
from praestoclaw.gateway_protocol.business.envelope import (
    BusinessError,
    BusinessProtocolError,
    Envelope,
)
from praestoclaw.gateway_protocol.business.outbound import Outbound


@dataclass
class BusinessClientConfig:
    """Client-side business handshake configuration."""

    client_version: str
    agent_id: str
    user_id: str
    framework_version: int = 1
    min_framework_version: int | None = None
    features: tuple[str, ...] = ("conversation", "file_stream")
    handshake_timeout_s: float = 30.0
    metadata: dict[str, Any] = field(default_factory=dict)


class BusinessProtocolClient:
    """Standalone business protocol framework client.

    The transport is expected to expose ``start()``, ``wait_connected()``,
    ``send(payload)``, ``recv()``, ``events()``, ``session_id`` and
    ``connection_epoch``. Runtime channel integration remains out of scope.
    """

    def __init__(
        self,
        transport: Any,
        config: BusinessClientConfig,
        *,
        dispatcher: Dispatcher | None = None,
    ) -> None:
        self.transport = transport
        self.config = config
        self.dispatcher = dispatcher or Dispatcher()
        self.outbound = Outbound(transport)
        self.negotiated_features: frozenset[str] = frozenset()
        self.server_info: dict[str, Any] = {}
        self.principal: Any | None = None
        self._recv_task: asyncio.Task[None] | None = None
        self._event_task: asyncio.Task[None] | None = None
        self._started = False
        self._handshake_complete = False
        self._handshake_lock = asyncio.Lock()

    async def start(self) -> None:
        """Start transport, receive pump, event pump, and business handshake."""

        if self._started:
            return
        await self.transport.start()
        self._recv_task = asyncio.create_task(self._recv_loop(), name="gateway-business-client")
        self._event_task = asyncio.create_task(
            self._event_loop(),
            name="gateway-business-events",
        )
        await self.transport.wait_connected(timeout=self.config.handshake_timeout_s)
        await self._ensure_handshake()
        self._started = True

    async def stop(self) -> None:
        """Stop receive/event pumps. The transport close is owned by the caller."""

        for task in (self._recv_task, self._event_task):
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        self._started = False

    async def send_event(
        self,
        topic: str,
        body: Mapping[str, Any],
        *,
        headers: Mapping[str, Any] | None = None,
    ) -> None:
        await self._ensure_handshake()
        await self.outbound.send_event(topic, body, headers=headers)

    async def request(
        self,
        topic: str,
        body: Mapping[str, Any],
        *,
        headers: Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        await self._ensure_handshake()
        return await self.outbound.request(topic, body, headers=headers, timeout=timeout)

    async def stream(
        self,
        topic: str,
        body: Mapping[str, Any],
        *,
        headers: Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        await self._ensure_handshake()
        async for item in self.outbound.stream(topic, body, headers=headers, timeout=timeout):
            yield item

    async def cancel(self, correlation_id: str, *, reason: str | None = None) -> None:
        await self.outbound.cancel(correlation_id, reason=reason)

    async def handshake(self) -> dict[str, Any]:
        """Perform the ``_session.hello`` business handshake if needed."""

        async with self._handshake_lock:
            if self._handshake_complete:
                return self.server_info
            return await self._perform_handshake()

    async def _ensure_handshake(self) -> None:
        if self._handshake_complete:
            return
        async with self._handshake_lock:
            if self._handshake_complete:
                return
            await self._perform_handshake()

    async def _perform_handshake(self) -> dict[str, Any]:
        hello = SessionHello(
            client_version=self.config.client_version,
            framework_version=self.config.framework_version,
            min_framework_version=self.config.min_framework_version,
            features=self.config.features,
            agent_id=self.config.agent_id,
            user_id=self.config.user_id,
        )
        response = await self.outbound.request(
            "_session.hello",
            hello.to_dict(),
            timeout=self.config.handshake_timeout_s,
        )
        server_features = response.get("features", [])
        if not isinstance(server_features, list):
            server_features = []
        self.negotiated_features = frozenset(
            set(self.config.features).intersection(
                item for item in server_features if isinstance(item, str)
            )
        )
        session = response.get("session", {})
        if isinstance(session, Mapping):
            self.principal = session.get("principal_id", self.config.user_id)
        else:
            self.principal = self.config.user_id
        self.server_info = response
        self._handshake_complete = True
        return response

    async def _recv_loop(self) -> None:
        async for payload in self.transport.recv():
            try:
                envelope = Envelope.parse(payload)
            except BusinessProtocolError as exc:
                await self._reply_invalid_envelope(payload, exc)
                continue

            log_business_envelope_debug("rx", envelope)
            ctx = RequestContext(
                principal=self.principal or self.config.user_id,
                session_id=getattr(self.transport, "session_id", None),
                connection_epoch=getattr(self.transport, "connection_epoch", None),
                features=self.negotiated_features,
                metadata=dict(self.config.metadata),
            )
            await self.dispatcher.dispatch(envelope, ctx, self.outbound)

    async def _event_loop(self) -> None:
        async for event in self.transport.events():
            payload = {
                "session_id": event.session_id,
                "prior_session_id": event.prior_session_id,
                "connection_epoch": event.connection_epoch,
                "principal": self.principal or self.config.user_id,
                "reason": event.reason,
                "resumed": event.resumed,
            }

            if event.kind == "resume_failed":
                self._handshake_complete = False
                self.negotiated_features = frozenset()
                await self.outbound.fail_pending(
                    BusinessError(
                        "transport.resume_failed",
                        "transport resume failed before reply",
                        retryable=True,
                        details={"reason": event.reason},
                    )
                )
                await self._ensure_handshake()
            elif event.kind == "connected":
                await self._ensure_handshake()
            elif event.kind == "closed":
                await self.outbound.fail_pending(
                    BusinessError(
                        "transport.closed",
                        "transport closed before reply",
                        retryable=False,
                        details={"reason": event.reason},
                    )
                )

            await self.dispatcher.emit_session_event(event.kind, payload)

    async def _reply_invalid_envelope(self, payload: Any, exc: BusinessProtocolError) -> None:
        if not isinstance(payload, Mapping):
            logger.warning("Dropping non-object business payload: {}", exc)
            return
        kind = payload.get("kind")
        envelope_id = payload.get("id")
        if kind == "request" and isinstance(envelope_id, str) and envelope_id:
            await self.outbound.send_error(
                envelope_id,
                BusinessError("invalid_envelope", str(exc), retryable=False),
            )
            return
        logger.warning("Dropping invalid business envelope: {}", exc)
