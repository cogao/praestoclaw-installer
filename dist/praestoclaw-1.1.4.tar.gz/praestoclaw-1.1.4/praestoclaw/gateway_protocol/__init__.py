"""Client-side Agent-Gateway protocol implementation.

This package is intentionally standalone. It implements the new transport and
business protocol layers without wiring them into the existing channel/runtime
code paths yet.
"""

from praestoclaw.gateway_protocol.transport import (
    CloseCode,
    GatewayTransportClient,
    TransportClientConfig,
    TransportDisconnectedBackpressureError,
    TransportError,
    TransportEvent,
    TransportState,
)

__all__ = [
    "CloseCode",
    "GatewayTransportClient",
    "TransportClientConfig",
    "TransportDisconnectedBackpressureError",
    "TransportError",
    "TransportEvent",
    "TransportState",
]
