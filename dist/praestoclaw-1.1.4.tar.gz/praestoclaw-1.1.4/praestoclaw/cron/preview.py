"""Cron schedule preview: validation + human description + next-N fire times.

Single source of truth for the `POST /api/cron/preview` endpoint and any future
CLI `--dry-run`. Imports `croniter`, `cron_descriptor`, and APScheduler's
`CronTrigger.from_crontab` only here — every other caller goes through
`preview_schedule()`.

Cross-validation contract (BACK-06): a cron expression is `valid` only when
both `croniter` AND `apscheduler.triggers.cron.CronTrigger.from_crontab`
accept it. Either failure → `valid=False` with a unified `error` string.

Weekday normalisation: croniter / cron_descriptor use POSIX numbering
(0=Sun, 1=Mon) but APScheduler's `from_crontab` numeric weekday is 0=Mon —
these libraries silently disagree on `* * * * 1`. To prevent the preview
from showing Monday while the scheduler fires on Tuesday (and vice versa),
we keep the user-facing convention as POSIX (the universal cron baseline)
and rewrite numeric weekday tokens to APScheduler's accepted day names
(MON/TUE/...) before constructing CronTrigger. cron_descriptor is fed
the user's original POSIX expression so its English description matches
what the user typed.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime, timedelta
from typing import Any

from apscheduler.triggers.cron import CronTrigger
from cron_descriptor import ExpressionDescriptor, Options
from croniter import croniter

try:
    from tzlocal import get_localzone
except ImportError:  # tzlocal is a transitive dep via APScheduler; fall back to UTC
    get_localzone = None  # type: ignore[assignment]

from praestoclaw.cron.job import detect_trigger_type

_MAX_COUNT = 20

# POSIX weekday names. Index = POSIX numeric value (0=Sun, ..., 6=Sat). 7 also = Sun.
_POSIX_WEEKDAY_NAMES = ("SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT")


def normalize_cron_for_apscheduler(expr: str) -> str:
    """Rewrite numeric weekday tokens to day names so APScheduler matches POSIX.

    Operates only on the day-of-week field (5th field). Replaces standalone
    digits 0-7 with their POSIX names. Preserves ranges (`1-5` → `MON-FRI`),
    lists (`1,3,5` → `MON,WED,FRI`), steps (`*/2`), and wildcards (`*`).
    Pass-through for non-5-field expressions.
    """
    parts = expr.split()
    if len(parts) != 5:
        return expr

    def _repl(match: re.Match[str]) -> str:
        n = int(match.group())
        if 0 <= n <= 7:
            return _POSIX_WEEKDAY_NAMES[n % 7]
        return match.group()

    parts[4] = re.sub(r"\b[0-7]\b", _repl, parts[4])
    return " ".join(parts)


def preview_schedule(
    schedule: str | int,
    *,
    count: int = 5,
    tz: str | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Return a JSON-shaped preview of a cron / interval / event / at schedule.

    `tz` is an IANA name (e.g. "Asia/Shanghai"). Cron expressions are evaluated
    in that timezone — `0 9 * * *` with tz="Asia/Shanghai" means 9:00 Beijing.
    Returned `next_runs` are still ISO8601 with timezone offset; the client
    can render them in any locale.

    Returns:
        {
          "trigger_type": "cron" | "interval" | "event" | "at" | "unknown",
          "valid": bool,
          "human": str | None,        # English description for valid cron/interval
          "next_runs": list[str],     # ISO8601 with tz; empty for invalid or non-time types
          "tz": str | None,           # echo of the tz used (None for tz-less interval)
          "error": str | None,
        }
    """
    count = max(1, min(int(count) if isinstance(count, int) else 5, _MAX_COUNT))

    tzinfo: Any = None
    if tz:
        try:
            from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

            tzinfo = ZoneInfo(tz)
        except ZoneInfoNotFoundError:
            return _invalid("unknown", f"Unknown timezone: {tz!r}", tz)

    # Match APScheduler.from_crontab's runtime default (tzlocal) so the preview
    # never disagrees with the scheduler when the caller omits tz.
    if tzinfo is None:
        tzinfo = get_localzone() if get_localzone is not None else UTC

    base_now = now if now is not None else datetime.now(tzinfo)
    if base_now.tzinfo is None:
        base_now = base_now.replace(tzinfo=tzinfo)
    else:
        base_now = base_now.astimezone(tzinfo)

    try:
        trigger_type = detect_trigger_type(schedule)
    except Exception as exc:  # noqa: BLE001 — defensive, detect_trigger_type is total today
        return _invalid("unknown", f"Unrecognized schedule format: {exc}", tz)

    if trigger_type == "cron":
        return _preview_cron(str(schedule), count, base_now, tz)
    if trigger_type == "interval":
        return _preview_interval(schedule, count, base_now, tz)
    if trigger_type in ("event", "at"):
        # No preview semantics in v1 — UI hides the preview block for these.
        return {
            "trigger_type": trigger_type,
            "valid": True,
            "human": None,
            "next_runs": [],
            "tz": tz,
            "error": None,
        }
    return _invalid("unknown", "Unrecognized schedule format", tz)


def _preview_cron(expr: str, count: int, base_now: datetime, tz: str | None) -> dict[str, Any]:
    # Cross-validation contract (BACK-06): both libraries must accept.
    try:
        croniter(expr, base_now)
    except Exception as exc:  # noqa: BLE001 — croniter raises a variety of types
        return _invalid("cron", f"Invalid cron expression: {exc}", tz)
    try:
        if base_now.tzinfo is not None and tz:
            ap_trigger = CronTrigger.from_crontab(
                normalize_cron_for_apscheduler(expr), timezone=base_now.tzinfo
            )
        else:
            ap_trigger = CronTrigger.from_crontab(normalize_cron_for_apscheduler(expr))
    except Exception as exc:  # noqa: BLE001 — APScheduler raises ValueError variants
        return _invalid("cron", f"Invalid cron expression: {exc}", tz)

    options = Options()
    options.locale_code = "en"
    try:
        human = ExpressionDescriptor(expr, options=options).get_description()
    except Exception as exc:  # noqa: BLE001 — descriptor failure is non-fatal
        human = None
        _human_error = str(exc)  # noqa: F841 — kept for future logging hook
    # Source next_runs from the same trigger that fires at runtime — guarantees
    # the preview cannot disagree with the scheduler on weekday encoding.
    next_runs: list[str] = []
    cursor = base_now
    for _ in range(count):
        nxt = ap_trigger.get_next_fire_time(None, cursor)
        if nxt is None:
            break
        next_runs.append(nxt.isoformat())
        cursor = nxt + timedelta(microseconds=1)
    return {
        "trigger_type": "cron",
        "valid": True,
        "human": human,
        "next_runs": next_runs,
        "tz": tz,
        "error": None,
    }


def _preview_interval(
    schedule: str | int, count: int, base_now: datetime, tz: str | None
) -> dict[str, Any]:
    try:
        seconds = int(schedule)
    except (TypeError, ValueError) as exc:
        return _invalid("interval", f"Invalid interval: {exc}", tz)
    if seconds <= 0:
        return _invalid("interval", "Interval must be a positive integer of seconds", tz)
    human = _humanize_interval(seconds)
    next_runs = [
        (base_now + timedelta(seconds=seconds * (i + 1))).isoformat() for i in range(count)
    ]
    return {
        "trigger_type": "interval",
        "valid": True,
        "human": human,
        "next_runs": next_runs,
        "tz": tz,
        "error": None,
    }


def _humanize_interval(seconds: int) -> str:
    if seconds % 3600 == 0 and seconds >= 3600:
        h = seconds // 3600
        return f"Every {h} hour" + ("s" if h != 1 else "")
    if seconds % 60 == 0 and seconds >= 60:
        m = seconds // 60
        return f"Every {m} minute" + ("s" if m != 1 else "")
    return f"Every {seconds} second" + ("s" if seconds != 1 else "")


def _invalid(trigger_type: str, error: str, tz: str | None = None) -> dict[str, Any]:
    return {
        "trigger_type": trigger_type,
        "valid": False,
        "human": None,
        "next_runs": [],
        "tz": tz,
        "error": error,
    }
