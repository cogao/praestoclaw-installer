"""
A2A Runtime — async envelope orchestrator.

Replaces the prior synchronous task-RPC model. Responsibilities:

* Outbound: build text envelopes, register pending entries, push them through
  the configured frame sender, await an inline ``a2a_dispatch`` correlated by
  ``message_id`` (short timeout), return ack/text replies later via the bus
  as injected ``InboundMessage`` notifications.
* Inbound: route ``a2a_message`` frames into three branches:
    - new TEXT request → send ack frame, run agent loop, send text reply.
    - reply (TEXT with ``parent_id`` / ACK / ERROR) → look up the originating
      pending entry and inject a friendly system notification back to the
      original user channel.
* Discovery, listing, and routing are Gateway-internal business-protocol
  concerns; this runtime never fetches public agent-card JSON.

P3 deliberately leaves all wiring (cloud channel routing, runtime construction,
``a2a`` tool simplification) for P4. Method names ``set_process_fn`` and
``set_frame_sender`` are preserved so the existing imports in
``praestoclaw/runtime.py`` keep working.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from loguru import logger

from praestoclaw.a2a.models import A2AEnvelope, A2AMessageType, A2AParty
from praestoclaw.bus.events import InboundMessage, OutboundMessage
from praestoclaw.bus.queue import MessageBus
from praestoclaw.config.schema import ChannelType

ProcessFn = Callable[..., Awaitable[str]]
SendFrameFn = (
    Callable[[dict[str, Any]], Awaitable[bool]] | Callable[[dict[str, Any]], Awaitable[None]]
)
DiscoverFn = Callable[[str], Awaitable[dict[str, Any]]]
A2AListFn = Callable[[str], Awaitable[dict[str, Any]]]

DISPATCH_TIMEOUT = 10.0  # seconds to wait for inline a2a_dispatch
SWEEP_INTERVAL = 60.0  # seconds between TTL sweeps


@dataclass
class _PendingOut:
    """An outbound a2a text envelope awaiting dispatch ack and/or reply."""

    message_id: str
    channel: Any  # ChannelType | str — stored as-is for re-injection
    channel_id: str
    session_id: str
    target_label: str  # display label for the receiver (id or name)
    sender_label: str  # display label for the local sender (id or name)
    created_at: float = field(default_factory=time.time)
    future: asyncio.Future[dict[str, Any]] | None = None


class A2ARuntime:
    """Orchestrates async agent-to-agent envelopes."""

    def __init__(
        self,
        local_party: A2AParty,
        *,
        pending_ttl: float = 600.0,
    ) -> None:
        self._local_party = local_party
        self._pending_ttl = pending_ttl
        self._pending: dict[str, _PendingOut] = {}
        self._inflight_inbound: set[asyncio.Task[None]] = set()

        self._bus: MessageBus | None = None
        self._send_frame_fn: SendFrameFn | None = None
        self._discover_fn: DiscoverFn | None = None
        self._list_fn: A2AListFn | None = None
        self._process_fn: ProcessFn | None = None
        # Resolver maps a ChannelType (the value injected into tool kwargs as
        # ``_channel``) to the actual Channel instance. Needed so the A2A
        # notify path can read CloudChannel._teams_routed_channel_ids.
        self._channel_resolver: Callable[[Any], Any] | None = None

        self._sweeper_task: asyncio.Task[None] | None = None
        self._closed = False

    # ── Wiring ─────────────────────────────────────────────────────────

    def set_bus(self, bus: MessageBus) -> None:
        self._bus = bus

    def set_process_fn(self, fn: ProcessFn) -> None:
        self._process_fn = fn

    def set_frame_sender(self, fn: SendFrameFn) -> None:
        self._send_frame_fn = fn

    def set_discovery_sender(self, fn: DiscoverFn) -> None:
        self._discover_fn = fn

    def set_list_sender(self, fn: A2AListFn) -> None:
        self._list_fn = fn

    def set_channel_resolver(self, fn: Callable[[Any], Any]) -> None:
        """Inject a ChannelType -> Channel instance lookup."""
        self._channel_resolver = fn

    @property
    def local_party(self) -> A2AParty:
        return self._local_party

    def update_local_party(
        self,
        user_id: str,
        *,
        display_name: str | None = None,
        agent_id: str | None = None,
    ) -> A2AParty:
        """Update the local sender identity after late auth resolution."""

        next_id = user_id.strip()
        if not next_id:
            raise ValueError("A2A local party user_id must not be empty")

        current = self._local_party
        next_name = display_name if display_name is not None else current.name
        if not next_name or next_name == current.id:
            next_name = next_id
        next_agent_id = agent_id if agent_id is not None else current.agent_id
        self._local_party = A2AParty(id=next_id, name=next_name, agent_id=next_agent_id)
        return self._local_party

    async def discover(self, target_user_id: str) -> dict[str, Any]:
        """Query Gateway-internal A2A discovery over the native business protocol."""
        if self._discover_fn is None:
            return {"error": True, "detail": "A2A discovery is not configured"}
        return await self._discover_fn(target_user_id)

    async def list_agents(self, scope: str = "mine") -> dict[str, Any]:
        """List A2A agents via the Gateway-internal semantic listing extension."""
        if self._list_fn is None:
            return {"error": True, "detail": "A2A listing is not configured"}
        return await self._list_fn(scope)

    # ── Outbound ───────────────────────────────────────────────────────

    async def send_async(
        self,
        target: str,
        content: str,
        *,
        channel: Any,
        channel_id: str,
        session_id: str,
        target_name: str = "",
        target_agent_id: str = "",
    ) -> dict[str, Any]:
        """Send a text envelope to *target*; await the inline dispatch result.

        Returns:
            ``{"ok": True, "message_id": <id>}`` on success, or
            ``{"ok": False, "error_code": str, "error_message": str,
              "message_id": <id>}`` on dispatch error / timeout.
        """
        self._ensure_sweeper()

        target_id = (target or "").strip()
        if not target_id:
            return {
                "ok": False,
                "error_code": "invalid_target",
                "error_message": "target is empty",
                "message_id": "",
            }

        receiver = A2AParty(
            id=target_id,
            name=target_name or "",
            agent_id=(target_agent_id or "").strip(),
        )
        envelope = A2AEnvelope.new_text(
            sender=self._local_party,
            receiver=receiver,
            content=content,
        )

        loop = asyncio.get_running_loop()
        future: asyncio.Future[dict[str, Any]] = loop.create_future()
        entry = _PendingOut(
            message_id=envelope.id,
            channel=channel,
            channel_id=channel_id,
            session_id=session_id,
            target_label=target_name or target_id,
            sender_label=self._local_party.name or self._local_party.id,
            future=future,
        )
        self._pending[envelope.id] = entry

        frame: dict[str, Any] = {
            "type": "a2a_message",
            "envelope": envelope.to_dict(),
        }

        if self._send_frame_fn is None:
            self._pending.pop(envelope.id, None)
            return {
                "ok": False,
                "error_code": "no_transport",
                "error_message": "frame sender not configured",
                "message_id": envelope.id,
            }

        try:
            await self._send_frame_fn(frame)  # type: ignore[misc]
        except Exception as exc:
            self._pending.pop(envelope.id, None)
            logger.error("A2A send_async transport error: {}", exc)
            return {
                "ok": False,
                "error_code": "transport_error",
                "error_message": str(exc),
                "message_id": envelope.id,
            }

        try:
            result = await asyncio.wait_for(future, timeout=DISPATCH_TIMEOUT)
        except TimeoutError:
            self._pending.pop(envelope.id, None)
            logger.warning("A2A dispatch timeout for message_id={}", envelope.id)
            return {
                "ok": False,
                "error_code": "dispatch_timeout",
                "error_message": (f"no a2a_dispatch received within {DISPATCH_TIMEOUT}s"),
                "message_id": envelope.id,
            }
        finally:
            # Future is consumed; clear it so the entry only carries
            # correlation metadata for the eventual ack/reply.
            entry.future = None

        # Surface the dispatch outcome.
        result.setdefault("message_id", envelope.id)
        return result

    # ── Inbound: a2a_message ───────────────────────────────────────────

    async def handle_a2a_message(self, frame_data: dict[str, Any]) -> None:
        """Route an inbound ``a2a_message`` frame to the correct branch."""
        env_dict = frame_data.get("envelope")
        if not isinstance(env_dict, dict):
            logger.warning("handle_a2a_message: missing envelope field")
            return

        try:
            envelope = A2AEnvelope.from_dict(env_dict)
        except Exception as exc:
            logger.warning("handle_a2a_message: invalid envelope: {}", exc)
            return

        branch = (
            "request"
            if envelope.type is A2AMessageType.TEXT and not envelope.parent_id
            else "reply"
        )
        logger.info(
            "[A2A] runtime RX a2a_message: id={} type={} parent={} sender={} receiver={} -> {}",
            envelope.id,
            envelope.type.value,
            envelope.parent_id or "-",
            envelope.sender.id,
            envelope.receiver.id,
            branch,
        )

        if envelope.type is A2AMessageType.TEXT and not envelope.parent_id:
            await self._handle_inbound_request(envelope)
            return

        # Reply branch — ack, error, or text-with-parent_id.
        await self._handle_inbound_reply(envelope)

    async def _handle_inbound_request(self, envelope: A2AEnvelope) -> None:
        """A new TEXT request from a remote agent."""
        # 1. Send ack immediately so the remote sender's send_async resolves
        #    on the eventual text reply rather than waiting silently.
        ack = A2AEnvelope.new_ack(
            sender=self._local_party,
            receiver=envelope.sender,
            parent_id=envelope.id,
        )
        await self._send_envelope(ack)

        # 2. Notify the local user (push to webchat/teams) — without this they
        #    have no idea another agent contacted them.
        await self._notify_local_user_of_inbound(envelope)

        # 3. Spawn the agent loop in the background.
        task = asyncio.create_task(
            self._execute_inbound(envelope),
            name=f"a2a-inbound-{envelope.id}",
        )
        self._inflight_inbound.add(task)
        task.add_done_callback(self._inflight_inbound.discard)

    @staticmethod
    def _party_label(party: A2AParty) -> str:
        """Render a party as ``id`` or ``id (name)`` for user-facing notifications.

        The id is the canonical addressable identity (e.g. ``alice@contoso.com``);
        the name is decorative. Always show id; append name only when distinct
        and non-empty.
        """
        ident = party.id or "unknown"
        name = (party.name or "").strip()
        if name and name != ident:
            return f"{ident} ({name})"
        return ident

    async def _notify_local_user_of_inbound(self, envelope: A2AEnvelope) -> None:
        """Push a heads-up to the local user so they know an agent contacted them.

        Goes out as a non-routable cloud push (no agent loop involved) — the
        gateway fan-outs the push to the user's connected webchat/Teams clients.
        """
        if self._bus is None:
            return
        text = (
            f"[A2A] 收到来自 {self._party_label(envelope.sender)} 的请求 "
            f"(msg_id={envelope.id})：\n\n{envelope.text}\n\n"
            f"我会立刻处理并把回复发回去。"
        )
        try:
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=ChannelType.CLOUD,
                    channel_id=f"a2a:incoming:{envelope.id}",
                    content=text,
                )
            )
        except Exception as exc:  # noqa: BLE001 — best-effort notification
            logger.warning("A2A local notify failed: {}", exc)

    async def _notify_local_user_of_outbound_reply(
        self, request: A2AEnvelope, reply_text: str
    ) -> None:
        """Push a copy of the reply we sent so the local user knows what we said."""
        if self._bus is None:
            return
        text = (
            f"[A2A] 已回复 {self._party_label(request.sender)} "
            f"(re: {request.id})：\n\n{reply_text or '(空回复)'}"
        )
        try:
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=ChannelType.CLOUD,
                    channel_id=f"a2a:replied:{request.id}",
                    content=text,
                )
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("A2A local outbound-reply notify failed: {}", exc)

    async def _notify_local_user_of_outbound_error(
        self, request: A2AEnvelope, code: str, reason: str
    ) -> None:
        """Push an error notice so the local user knows we failed to handle the request."""
        if self._bus is None:
            return
        text = (
            f"[A2A] 处理 {self._party_label(request.sender)} 的请求时出错 "
            f"(msg_id={request.id})：{code} — {reason}"
        )
        try:
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=ChannelType.CLOUD,
                    channel_id=f"a2a:replied:{request.id}",
                    content=text,
                )
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("A2A local outbound-error notify failed: {}", exc)

    async def _execute_inbound(self, envelope: A2AEnvelope) -> None:
        if self._process_fn is None:
            logger.error("A2A inbound dropped — process_fn not configured")
            err = A2AEnvelope.new_error(
                sender=self._local_party,
                receiver=envelope.sender,
                code="no_process_fn",
                reason="agent loop not configured",
                parent_id=envelope.id,
            )
            await self._send_envelope(err)
            return

        sender_key = envelope.sender.id or "unknown"
        session_id = f"a2a:{sender_key}"
        channel_id = f"a2a:{sender_key}"

        try:
            result_text = await self._process_fn(
                envelope.text,
                session_id=session_id,
                channel_id=channel_id,
                metadata={
                    "source": "a2a",
                    "sender_id": envelope.sender.id,
                    "sender_name": envelope.sender.name,
                    "parent_id": envelope.id,
                },
                exclude_tools=["notify", "cron", "spawn", "a2a"],
            )
        except Exception as exc:
            logger.error("A2A inbound process_fn failed: {}", exc)
            err = A2AEnvelope.new_error(
                sender=self._local_party,
                receiver=envelope.sender,
                code="execution_error",
                reason=str(exc)[:120],
                detail=str(exc),
                parent_id=envelope.id,
            )
            await self._send_envelope(err)
            await self._notify_local_user_of_outbound_error(
                envelope, "execution_error", str(exc)[:120]
            )
            return

        reply = A2AEnvelope.new_text(
            sender=self._local_party,
            receiver=envelope.sender,
            content=result_text or "",
            parent_id=envelope.id,
        )
        await self._send_envelope(reply)
        await self._notify_local_user_of_outbound_reply(envelope, result_text or "")

    async def _handle_inbound_reply(self, envelope: A2AEnvelope) -> None:
        """An ack / text-reply / error correlated to one of our sends."""
        parent_id = envelope.parent_id or ""
        if not parent_id:
            logger.warning(
                "A2A inbound {} without parent_id — dropping",
                envelope.type.value,
            )
            return

        entry = self._pending.get(parent_id)
        if entry is None:
            logger.warning(
                "A2A orphan reply (type={}, parent_id={}) — no pending entry",
                envelope.type.value,
                parent_id,
            )
            return

        # Prefer the canonical id (e.g. ``bob@contoso.com``) over a decorative
        # display name; fall back to the originally-targeted label if the reply
        # envelope arrives without sender info.
        target_label = (
            self._party_label(envelope.sender)
            if envelope.sender.id
            else (entry.target_label or "unknown")
        )

        if envelope.type is A2AMessageType.ACK:
            notification = f"[A2A] {target_label} 已确认收到你发出的消息 (msg_id={parent_id})"
            kind = "ack"
            terminal = False
        elif envelope.type is A2AMessageType.TEXT:
            notification = f"[A2A] {target_label} 回复了你 (re: {parent_id})：\n\n{envelope.text}"
            kind = "text"
            terminal = True
        elif envelope.type is A2AMessageType.ERROR:
            payload = envelope.payload or {}
            code = str(payload.get("code", "unknown"))
            reason = str(payload.get("reason", ""))
            detail = str(payload.get("detail", ""))
            notification = (
                f"[A2A] {target_label} 处理你的消息时出错 "
                f"(msg_id={parent_id})：{code} — {reason}\n{detail}"
            )
            kind = "error"
            terminal = True
        else:  # pragma: no cover — exhaustive enum
            logger.warning("A2A unknown reply type: {}", envelope.type)
            return

        await self._publish_notification(
            entry=entry,
            content=notification,
            kind=kind,
            parent_id=parent_id,
            target_id=entry.target_label,
        )

        if terminal:
            self._pending.pop(parent_id, None)

    async def _publish_notification(
        self,
        *,
        entry: _PendingOut,
        content: str,
        kind: str,
        parent_id: str,
        target_id: str,
    ) -> None:
        if self._bus is None:
            logger.warning("A2A notification dropped — bus not configured")
            return
        # Use a non-routable channel_id so the agent's response is sent as a
        # `push` frame (fan-out to the user's connected webchat/teams clients)
        # instead of trying to reuse the original request's reply_context which
        # has already been consumed by the agent's first response.
        notify_channel_id = f"a2a:notify:{parent_id}"

        # Propagate Teams routing: when the original user was on Teams, the
        # cloud channel tracked their channel_id so follow-up sends use
        # ``push_target="teams"`` (not the default ``webchat``, which the
        # gateway would silently drop). Our new ``a2a:notify:...`` channel_id
        # is *not* in that set yet — and the cloud channel won't see this
        # InboundMessage through ``_on_message`` because we publish directly
        # to the bus. Hop the routing across explicitly via the channel's
        # public Teams-routing API so the agent's eventual reply to this
        # notification reaches the Teams chat that started the A2A flow.
        #
        # ``entry.channel`` is the ChannelType *enum* (the value injected as
        # ``_channel`` by ToolRegistry.execute), not the Channel instance.
        # Resolve to the actual channel via the configured resolver.
        resolved_channel: Any = entry.channel
        if self._channel_resolver is not None:
            try:
                resolved = self._channel_resolver(entry.channel)
            except Exception as exc:  # noqa: BLE001
                resolved = None
                logger.trace("[a2a-route] channel_resolver raised: {}", exc)
            if resolved is not None:
                resolved_channel = resolved

        is_teams_routed_fn = getattr(resolved_channel, "is_teams_routed", None)
        remember_route_fn = getattr(resolved_channel, "remember_teams_route", None)
        propagated = False
        if callable(is_teams_routed_fn) and callable(remember_route_fn):
            try:
                if is_teams_routed_fn(entry.channel_id):
                    remember_route_fn(notify_channel_id)
                    propagated = True
            except Exception as exc:  # noqa: BLE001
                logger.trace("[a2a-route] teams routing propagation raised: {}", exc)

        if propagated:
            logger.debug(
                "[a2a-route] notify propagated teams routing: origin={} -> notify={}",
                entry.channel_id,
                notify_channel_id,
            )
        else:
            logger.trace(
                "[a2a-route] notify origin_channel_id={} notify_channel_id={} "
                "channel_type={} resolved_channel={} routing_api_present={}",
                entry.channel_id,
                notify_channel_id,
                type(entry.channel).__name__,
                type(resolved_channel).__name__,
                callable(is_teams_routed_fn) and callable(remember_route_fn),
            )
        msg = InboundMessage(
            channel=entry.channel,
            channel_id=notify_channel_id,
            sender_id="a2a-system",
            sender_name="A2A",
            content=content,
            session_key=entry.session_id,
            metadata={
                "source": "a2a_notify",
                "kind": kind,
                "parent_id": parent_id,
                "target_id": target_id,
                "origin_channel_id": entry.channel_id,
            },
        )
        await self._bus.publish_inbound(msg)

    # ── Inbound: a2a_dispatch ──────────────────────────────────────────

    async def handle_a2a_dispatch(self, frame_data: dict[str, Any]) -> None:
        """Resolve the pending future for a previously-sent envelope."""
        message_id = str(frame_data.get("message_id", ""))
        if not message_id:
            logger.warning("handle_a2a_dispatch: missing message_id")
            return

        entry = self._pending.get(message_id)
        if entry is None or entry.future is None or entry.future.done():
            logger.debug(
                "handle_a2a_dispatch: no waiter for message_id={}",
                message_id,
            )
            # Still drop the entry on terminal error — no reply will arrive.
            if entry is not None and frame_data.get("status") == "error":
                self._pending.pop(message_id, None)
            return

        status = str(frame_data.get("status", ""))
        code = frame_data.get("code")
        message = frame_data.get("message")

        result: dict[str, Any]
        if status == "dispatched":
            result = {"ok": True, "message_id": message_id}
        else:
            result = {
                "ok": False,
                "error_code": str(code) if code is not None else status or "dispatch_failed",
                "error_message": str(message) if message is not None else "",
                "message_id": message_id,
            }

        entry.future.set_result(result)

        if status != "dispatched":
            # Terminal — no ack/reply will follow.
            self._pending.pop(message_id, None)

    # ── Frame helpers ──────────────────────────────────────────────────

    async def _send_envelope(self, envelope: A2AEnvelope) -> None:
        if self._send_frame_fn is None:
            logger.warning(
                "A2A envelope dropped — frame sender not configured (type={})",
                envelope.type.value,
            )
            return
        frame = {"type": "a2a_message", "envelope": envelope.to_dict()}
        logger.info(
            "[A2A] runtime TX a2a_message: id={} type={} parent={} sender={} receiver={}",
            envelope.id,
            envelope.type.value,
            envelope.parent_id or "-",
            envelope.sender.id,
            envelope.receiver.id,
        )
        try:
            await self._send_frame_fn(frame)  # type: ignore[misc]
        except Exception as exc:
            logger.error(
                "A2A failed to send envelope (type={}): {}",
                envelope.type.value,
                exc,
            )

    # ── Sweeper / lifecycle ────────────────────────────────────────────

    def _ensure_sweeper(self) -> None:
        if self._closed:
            return
        if self._sweeper_task is not None and not self._sweeper_task.done():
            return
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        self._sweeper_task = loop.create_task(self._sweep_loop(), name="a2a-pending-sweeper")

    async def _sweep_loop(self) -> None:
        try:
            while not self._closed:
                await asyncio.sleep(SWEEP_INTERVAL)
                self._sweep_once()
        except asyncio.CancelledError:
            pass

    def _sweep_once(self) -> None:
        now = time.time()
        stale = [
            mid
            for mid, entry in self._pending.items()
            if (now - entry.created_at) > self._pending_ttl
            and (entry.future is None or entry.future.done())
        ]
        for mid in stale:
            self._pending.pop(mid, None)
            logger.debug("A2A pending entry expired: {}", mid)

    async def close(self) -> None:
        self._closed = True
        if self._sweeper_task is not None:
            self._sweeper_task.cancel()
            try:
                await self._sweeper_task
            except (asyncio.CancelledError, Exception):
                pass
            self._sweeper_task = None

        for task in list(self._inflight_inbound):
            task.cancel()
        self._inflight_inbound.clear()

        for entry in list(self._pending.values()):
            if entry.future is not None and not entry.future.done():
                entry.future.set_exception(ConnectionError("A2A runtime closed"))
        self._pending.clear()
