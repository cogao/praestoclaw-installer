"""Compatibility re-exports for shared A2A v1 wire models."""

from praesto_shared.a2a.v1.models import A2AEnvelope, A2AMessageType, A2AParty

__all__ = [
    "A2AEnvelope",
    "A2AMessageType",
    "A2AParty",
]
