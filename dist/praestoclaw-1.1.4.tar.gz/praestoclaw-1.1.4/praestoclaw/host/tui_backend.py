from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Protocol
from uuid import uuid4

from praestoclaw.channels.local_interactive import (
    LocalInteractiveAdapter,
    LocalInteractiveInbound,
    LocalInteractiveSurface,
)
from praestoclaw.channels.turn.kernel import ChannelTurnKernel, DefaultSessionResolver


@dataclass(frozen=True, slots=True)
class TuiChatResult:
    content: str
    session_key: str


class TuiBackend(Protocol):
    @property
    def connection_label(self) -> str: ...

    async def start(self) -> None: ...

    async def stop(self) -> None: ...

    async def send_chat(self, *, conversation_id: str, content: str) -> TuiChatResult: ...


class HostBackedTuiBackend:
    """Local TUI backend that enters through Agent Host channel dispatch."""

    def __init__(
        self,
        *,
        kernel: ChannelTurnKernel,
        ensure_session: Callable[[str, str, str], Awaitable[None]] | None = None,
        sender_id: str = "local",
        connection_id: str | None = None,
    ) -> None:
        self._kernel = kernel
        self._ensure_session = ensure_session
        self._sender_id = sender_id
        self._connection_id = connection_id or f"local-tui-{uuid4().hex[:12]}"
        self._adapter = LocalInteractiveAdapter(LocalInteractiveSurface.TUI)
        self._session_resolver = DefaultSessionResolver()

    @property
    def connection_label(self) -> str:
        return "local agent host"

    async def start(self) -> None:
        return None

    async def stop(self) -> None:
        return None

    async def send_chat(self, *, conversation_id: str, content: str) -> TuiChatResult:
        envelope = await self._adapter.ingest(
            LocalInteractiveInbound(
                connection_id=self._connection_id,
                conversation_id=conversation_id,
                message_id=uuid4().hex,
                sender_id=self._sender_id,
                content=content,
                surface=LocalInteractiveSurface.TUI.value,
            )
        )
        session_key = self._session_resolver.resolve_session_key(envelope)
        if self._ensure_session is not None:
            await self._ensure_session(session_key, envelope.logical_channel, envelope.sender_id)

        result = await self._kernel.process(envelope)
        if result.runtime_result is not None:
            return TuiChatResult(result.runtime_result.content, session_key)
        if result.admission.synthetic_reply is not None:
            return TuiChatResult(str(result.admission.synthetic_reply), session_key)
        return TuiChatResult("", session_key)
