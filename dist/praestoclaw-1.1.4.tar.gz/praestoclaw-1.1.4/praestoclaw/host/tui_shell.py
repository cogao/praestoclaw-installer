"""Interactive terminal TUI shell."""

from __future__ import annotations

import asyncio
import os
from collections.abc import Awaitable, Callable

from rich.console import Console
from rich.markdown import Markdown

from praestoclaw.host.tui_backend import TuiBackend
from praestoclaw.utils.helpers import get_data_dir

console = Console()


class TuiShell:
    def __init__(
        self,
        *,
        backend: TuiBackend,
        session_id_factory: Callable[[], Awaitable[str]],
        prompt: str = "you> ",
    ) -> None:
        self._backend = backend
        self._session_id_factory = session_id_factory
        self._prompt = prompt
        self._session_id: str | None = None

    async def run(self) -> None:
        console.print(
            f"[dim]TUI local mode connected to {self._backend.connection_label}. "
            "Type /exit to quit, /new to start a new session.[/dim]\n"
        )
        get_input = self._build_input_reader()

        await self._backend.start()
        try:
            while True:
                try:
                    prompt = await asyncio.get_running_loop().run_in_executor(None, get_input)
                except (EOFError, KeyboardInterrupt):
                    break

                prompt = prompt.strip()
                if not prompt:
                    continue
                if prompt == "/exit":
                    break
                if prompt == "/new":
                    self._session_id = None
                    console.print("[dim]Started a new TUI local session.[/dim]")
                    continue
                if prompt == "/help":
                    console.print("[dim]Commands: /new, /exit[/dim]")
                    continue

                if self._session_id is None:
                    self._session_id = await self._session_id_factory()

                result = await self._backend.send_chat(
                    conversation_id=self._session_id,
                    content=prompt,
                )
                console.print(Markdown(result.content))
        finally:
            await self._backend.stop()

    def _build_input_reader(self) -> Callable[[], str]:
        try:
            from prompt_toolkit import PromptSession
            from prompt_toolkit.completion import Completer, Completion
            from prompt_toolkit.history import FileHistory

            class SlashCompleter(Completer):
                def get_completions(self, document, complete_event):  # noqa: ANN001
                    text = document.text_before_cursor
                    if not text.startswith("/"):
                        return
                    for command in ("/exit", "/new", "/help"):
                        if command.startswith(text):
                            yield Completion(command, start_position=-len(text))

            history_path = get_data_dir() / "cli_history"
            if os.name == "posix":
                try:
                    if not history_path.exists():
                        fd = os.open(history_path, os.O_CREAT | os.O_WRONLY, 0o600)
                        os.close(fd)
                    else:
                        os.chmod(history_path, 0o600)
                except OSError:
                    pass
            session: PromptSession[str] = PromptSession(
                self._prompt,
                completer=SlashCompleter(),
                complete_while_typing=True,
                history=FileHistory(str(history_path)),
            )
            return session.prompt
        except ImportError:
            console.print("[dim](basic input mode - autocomplete/history unavailable)[/dim]")
            return lambda: input(self._prompt)
