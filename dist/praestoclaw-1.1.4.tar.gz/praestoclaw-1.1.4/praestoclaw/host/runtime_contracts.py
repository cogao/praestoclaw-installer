"""Runtime contracts used by the new Agent Host skeleton.

The concrete AgentRuntime implementation will move into ``praestoclaw.runtime``
after the legacy ``praestoclaw/runtime.py`` module is removed.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

from praesto_shared.agent_link.v1 import InitiatedBy


@dataclass(frozen=True, slots=True)
class TurnProvenanceSummary:
    initiated_by: InitiatedBy
    human_initiated: bool
    logical_channel: str
    trust_boundary: str
    supervision_required: bool
    reply_constraints: dict[str, Any]


@dataclass(frozen=True, slots=True)
class AgentRuntimeRequest:
    agent_id: str
    session_id: str
    user_content: str
    attachments: tuple[Any, ...] = ()
    runtime_policy: dict[str, Any] = field(default_factory=dict)
    tool_policy: dict[str, Any] = field(default_factory=dict)
    turn_provenance: TurnProvenanceSummary | None = None
    supervision_policy: dict[str, Any] = field(default_factory=dict)
    memory_context: dict[str, Any] = field(default_factory=dict)
    cancellation_token: Any | None = None
    stream_sink: Any | None = None


@dataclass(frozen=True, slots=True)
class AgentRuntimeResult:
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)


class AgentRuntimeProtocol(Protocol):
    async def run_once(self, request: AgentRuntimeRequest) -> AgentRuntimeResult: ...
