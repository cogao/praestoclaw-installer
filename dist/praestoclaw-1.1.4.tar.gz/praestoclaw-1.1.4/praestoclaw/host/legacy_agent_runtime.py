"""Adapter from the new runtime contract to the existing AgentLoopV2.

This is a cutover aid for the TUI direct path. It does not expose channel
semantics to the TUI and should disappear when AgentRuntime is extracted from
``agent.loop_v2``.
"""

from __future__ import annotations

from typing import Any

from praestoclaw.agent.loop_v2 import AgentLoopV2
from praestoclaw.host.runtime_contracts import AgentRuntimeRequest, AgentRuntimeResult


class AgentLoopRuntimeAdapter:
    def __init__(self, agent_loop: AgentLoopV2) -> None:
        self._agent_loop = agent_loop

    async def run_once(self, request: AgentRuntimeRequest) -> AgentRuntimeResult:
        metadata: dict[str, Any] = {}
        if request.turn_provenance is not None:
            metadata["turn_provenance"] = {
                "initiated_by": request.turn_provenance.initiated_by.value,
                "human_initiated": request.turn_provenance.human_initiated,
                "logical_channel": request.turn_provenance.logical_channel,
                "trust_boundary": request.turn_provenance.trust_boundary,
                "supervision_required": request.turn_provenance.supervision_required,
            }
        response = await self._agent_loop.run_once(
            request.user_content,
            request.session_id,
            metadata=metadata,
        )
        return AgentRuntimeResult(content=response)
