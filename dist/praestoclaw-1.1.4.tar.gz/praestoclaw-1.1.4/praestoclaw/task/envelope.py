"""Builders for task-bearing carrier bodies and ``task.control`` bodies.

These are pure functions — they do not touch the network. They produce
the ``body`` dictionaries fed into ``business.outbound.request(...)``
so the Gateway sees byte-identical envelopes to the ones documented in
``PraestoClawGateway/scripts/task_protocol_smoke.py``.
"""

from __future__ import annotations

import time
import uuid
from datetime import UTC, datetime
from typing import Any

from praesto_shared.gateway_protocol.v1.task import (
    CONTENT_TYPE_TASK_REQUEST,
    TaskDeadlines,
    TaskIntent,
    TaskRequest,
)

# The full set of control actions the client may issue. ``approve`` /
# ``deny`` are issued by the *receiver* of a task; ``cancel`` by the
# *sender*; ``interrupt`` by either side; ``undo`` by the receiver
# after the task is ``done``.
TASK_CONTROL_ACTIONS: frozenset[str] = frozenset(
    {"approve", "deny", "cancel", "interrupt", "undo"}
)


def new_task_id() -> str:
    """Sender-assigned, stable across the task's lifetime (see spec §3.1)."""

    return f"task-{uuid.uuid4()}"


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def build_task_request_body(
    *,
    sender_user_id: str,
    sender_agent_id: str,
    recipient_user_id: str,
    recipient_agent_id: str | None = None,
    conversation_id: str | None = None,
    task_id: str | None = None,
    summary: str,
    action: str | None = None,
    hint_risk: str | None = None,
    undoable: bool = False,
    args: dict[str, Any] | None = None,
    soft_ms: int | None = None,
    hard_ms: int | None = None,
    sender_display_name: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the ``body`` of a task-bearing ``a2a.message.send`` request.

    Matches scenarios 2/3/6 of ``task_protocol_smoke.py`` byte-for-byte
    on ``content.content_type`` and ``content.task`` field names.

    ``undoable`` is honoured exactly as passed; it never silently flips.
    """

    if not summary or not summary.strip():
        raise ValueError("task intent.summary must not be empty")
    if not sender_user_id or not sender_user_id.strip():
        raise ValueError("sender_user_id must not be empty")
    if not recipient_user_id or not recipient_user_id.strip():
        raise ValueError("recipient_user_id must not be empty")

    tid = task_id or new_task_id()
    conv_id = conversation_id or f"a2a:task:{sender_user_id}:{tid}"

    intent = TaskIntent(
        summary=summary,
        action=action,
        hint_risk=hint_risk,  # type: ignore[arg-type]
        undoable=bool(undoable),
        args=dict(args or {}),
    )
    deadlines = TaskDeadlines(soft_ms=soft_ms, hard_ms=hard_ms)
    task = TaskRequest(task_id=tid, intent=intent, deadlines=deadlines)

    return {
        "context": {
            "conversation_id": conv_id,
            "task_id": None,
            "parent_envelope_id": None,
        },
        "sender": {
            "kind": "agent",
            "id": sender_agent_id,
            "user_id": sender_user_id,
            "agent_id": sender_agent_id,
            "display_name": sender_display_name or sender_agent_id,
        },
        "recipient": {
            "kind": "agent",
            "user_id": recipient_user_id,
            "agent_id": recipient_agent_id or recipient_user_id,
        },
        "content": {
            "content_type": CONTENT_TYPE_TASK_REQUEST,
            "task": task.model_dump(mode="json"),
        },
        "timestamp": _now_iso(),
        "metadata": dict(metadata or {}),
    }


def build_task_control_body(
    *,
    task_id: str,
    action: str,
    reason: str | None = None,
    by_user_id: str | None = None,
) -> dict[str, Any]:
    """Build the ``body`` of a ``task.control`` request envelope.

    See ``task_protocol_smoke.py`` scenarios 3/5/6 for the exact shape
    the Gateway expects.
    """

    if not task_id or not task_id.strip():
        raise ValueError("task_id must not be empty")
    if action not in TASK_CONTROL_ACTIONS:
        raise ValueError(
            f"unknown task.control action: {action!r} "
            f"(expected one of {sorted(TASK_CONTROL_ACTIONS)})"
        )

    body: dict[str, Any] = {"task_id": task_id, "action": action}
    if reason is not None:
        body["reason"] = reason
    if by_user_id is not None:
        body["by_user_id"] = by_user_id
    return body


# Used by some tests to assert wall-clock fields don't drift.
_get_monotonic_seconds = time.monotonic
