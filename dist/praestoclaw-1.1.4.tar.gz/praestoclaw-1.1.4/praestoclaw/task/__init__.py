"""Compatibility re-exports for shared Task v1 wire types.

Mirrors the pattern used by ``praestoclaw.a2a.models`` — anything the
client code needs from the task protocol should be imported from here so
the wire-level contract has a single authoritative source
(``praesto_shared.gateway_protocol.v1.task``).
"""

from praesto_shared.gateway_protocol.v1.task import (
    CONTENT_TYPE_TASK_CONTROL,
    CONTENT_TYPE_TASK_PROGRESS,
    CONTENT_TYPE_TASK_REQUEST,
    EXECUTING_DEFAULT_DEADLINE_MS,
    TASK_CONTROL_TOPIC,
    TASK_HARD_CAP_MS,
    TASK_PROGRESS_TOPIC,
    TERMINAL_STAGES,
    WAITING_APPROVAL_L2_DEADLINE_MS,
    WAITING_APPROVAL_L3_DEADLINE_MS,
    TaskDeadlines,
    TaskIntent,
    TaskRequest,
    TaskStage,
    extract_task_request,
)

from praestoclaw.task.envelope import (
    TASK_CONTROL_ACTIONS,
    new_task_id,
    build_task_control_body,
    build_task_request_body,
)
from praestoclaw.task.inbound import (
    format_progress_notification,
    handle_task_control_request,
    register_task_handlers,
)

__all__ = [
    # Wire-type re-exports (authoritative in PraestoShared).
    "CONTENT_TYPE_TASK_CONTROL",
    "CONTENT_TYPE_TASK_PROGRESS",
    "CONTENT_TYPE_TASK_REQUEST",
    "EXECUTING_DEFAULT_DEADLINE_MS",
    "TASK_CONTROL_TOPIC",
    "TASK_HARD_CAP_MS",
    "TASK_PROGRESS_TOPIC",
    "TERMINAL_STAGES",
    "WAITING_APPROVAL_L2_DEADLINE_MS",
    "WAITING_APPROVAL_L3_DEADLINE_MS",
    "TaskDeadlines",
    "TaskIntent",
    "TaskRequest",
    "TaskStage",
    "extract_task_request",
    # Client-side helpers.
    "TASK_CONTROL_ACTIONS",
    "build_task_control_body",
    "build_task_request_body",
    "new_task_id",
    "format_progress_notification",
    "handle_task_control_request",
    "register_task_handlers",
]
