"""Inbound dispatchers for ``task.progress`` events and ``task.control`` requests.

Phase 1 client semantics:

* ``task.progress`` events are rendered as user-visible status lines
  pushed through the existing system-notification path (the same one
  the legacy A2A runtime uses for ACK / ERROR replies).
* ``task.control`` requests forwarded by the Gateway have action
  ``undo`` (per spec §7 and ``task_protocol_smoke.py`` scenario 6).
  The client has no real undo capability in Phase 1 — it replies with
  ``error{code:"task.undo_unsupported"}`` per spec §9, raised as a
  ``BusinessError`` so the dispatcher turns it into a wire-level
  ``error`` envelope on the original correlation id.

These handlers are intentionally tiny / pure-ish so they unit-test
without booting a Gateway or a real CloudChannel.
"""

from __future__ import annotations

from typing import Any

from loguru import logger

from praesto_shared.gateway_protocol.v1.task import (
    TASK_CONTROL_TOPIC,
    TASK_PROGRESS_TOPIC,
    TERMINAL_STAGES,
)
from praestoclaw.bus.events import InboundMessage
from praestoclaw.bus.queue import MessageBus
from praestoclaw.config.schema import ChannelType
from praestoclaw.gateway_protocol.business.dispatcher import Dispatcher
from praestoclaw.gateway_protocol.business.envelope import BusinessError

_STAGE_BADGE = {
    "queued": "⏳",
    "gating": "🔎",
    "waiting_approval": "🛂",
    "executing": "⚙️",
    "done": "✅",
    "declined": "🚫",
    "interrupted": "✋",
    "timed_out": "⌛",
}


def format_progress_notification(body: dict[str, Any]) -> str:
    """Render a ``task.progress`` body as a short user-facing status line.

    The Gateway is the producer; we just summarize what it sent.
    """

    task_id = str(body.get("task_id") or "(unknown)")
    stage = str(body.get("stage") or "unknown")
    summary = str(body.get("summary") or "").strip()
    tier = body.get("tier")
    elapsed_ms = body.get("elapsed_ms")
    badge = _STAGE_BADGE.get(stage, "•")

    pieces: list[str] = [f"{badge} [task {task_id}] stage={stage}"]
    if tier:
        pieces.append(f"tier={tier}")
    if isinstance(elapsed_ms, int) and elapsed_ms >= 0:
        pieces.append(f"elapsed={elapsed_ms}ms")
    head = " ".join(pieces)

    if summary:
        return f"{head} — {summary}"
    return head


def _channel_id_for_task(task_id: str) -> str:
    return f"task:progress:{task_id or 'unknown'}"


async def publish_progress_notification(
    bus: MessageBus,  # noqa: ARG001 — kept for API compatibility
    body: dict[str, Any],
    *,
    channel: ChannelType | str = ChannelType.CLOUD,  # noqa: ARG001
) -> None:
    """Surface a ``task.progress`` body as a status notification.

    Phase 1 deliberately does NOT push these through ``bus.publish_inbound``:
    the inbound queue feeds the agent chat loop, and the executor (or any
    non-originator) would respond to the progress event as if it were a
    user message. Instead we log a one-line summary.
    """

    text = format_progress_notification(body)
    stage = str(body.get("stage") or "")
    terminal = stage in TERMINAL_STAGES
    logger.info("task.progress: {} terminal={}", text, terminal)


def handle_task_control_request(body: dict[str, Any]) -> dict[str, Any]:
    """Handle a ``task.control`` request forwarded by the Gateway.

    Phase 1: the only action the Gateway forwards to clients is
    ``undo`` (the others are interpreted by the coordinator itself).
    The client has no real undo capability — reply with
    ``task.undo_unsupported`` per spec §9, which surfaces as a wire
    ``error`` envelope on the correlation_id.

    Returning a normal mapping would produce a ``response`` envelope
    (i.e. silently ack the undo) — that is exactly what the spec
    forbids, so we always raise.

    A non-``undo`` action arriving here is unexpected (the coordinator
    consumes them); we still refuse so we never silently swallow it.
    """

    action = str(body.get("action") or "")
    task_id = str(body.get("task_id") or "")

    if action == "undo":
        logger.info(
            "task.control(undo) received task_id={} by_user_id={} — replying "
            "task.undo_unsupported (Phase 1 client has no undo capability)",
            task_id or "(unknown)",
            body.get("by_user_id") or "",
        )
        raise BusinessError(
            "task.undo_unsupported",
            "this agent cannot compensate the requested task",
            retryable=False,
            details={"task_id": task_id},
        )

    # Defensive: surface any other forwarded action loudly rather than
    # accidentally acknowledging it.
    logger.warning(
        "task.control received unexpected action={!r} task_id={} — refusing",
        action,
        task_id,
    )
    raise BusinessError(
        "task.unsupported_action",
        f"client does not handle task.control action={action!r}",
        retryable=False,
        details={"task_id": task_id, "action": action},
    )


def register_task_handlers(
    dispatcher: Dispatcher,
    bus: MessageBus,
    *,
    channel: ChannelType | str = ChannelType.CLOUD,
) -> None:
    """Wire the two Phase-1 task topics into *dispatcher*.

    Called by ``CloudChannel._register_dispatcher`` alongside the other
    on_event / on_request hookups.
    """

    @dispatcher.on_event(TASK_PROGRESS_TOPIC)
    async def _on_progress(body: dict[str, Any], _ctx: Any) -> None:
        await publish_progress_notification(bus, body, channel=channel)

    @dispatcher.on_request(TASK_CONTROL_TOPIC)
    async def _on_control(body: dict[str, Any], _ctx: Any) -> dict[str, Any]:
        # Sync helper; surface its BusinessError unchanged so the
        # dispatcher converts it to an error envelope.
        return handle_task_control_request(body)
