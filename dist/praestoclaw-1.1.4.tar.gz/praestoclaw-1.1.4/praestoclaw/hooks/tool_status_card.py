"""Tool-status Adaptive Card — animated "agent is thinking" indicator for Teams.

Web Chat shows tool calls inline as the agent works through a turn, but
Teams just sits silent until the final answer lands — making long
multi-tool turns feel frozen. This hook fills that gap by maintaining a
single Adaptive Card per user turn that accumulates one row per tool
call: ``pre_tool_use`` adds a "🔧 正在调用…" row, ``post_tool_use``
flips it to "✓ 已完成" (or "✗ 失败"), and the entire card is republished
via the bridge's ``update_key`` mechanism so subsequent tools update the
*same* Teams activity rather than stacking new cards.

The final agent reply is unchanged — it still lands as a separate
message via the synchronous ``/chatng`` path. After this hook runs the
last surviving status card shows the full tool-call history of the
turn, click-to-expand for each row's arguments, mirroring Web Chat's
collapsed tool-call summary.

Design notes
~~~~~~~~~~~~
* Only emits on Teams-originated turns (``metadata.source`` ∈
  ``cloud_teams`` / ``teams_bridge``). Web Chat already streams tool
  calls inline, CLI prints them inline, so this hook is a no-op there.
* Skips ``plan`` because :class:`PlanTool` already drives its own
  progress card on a different ``update_key`` and we don't want the two
  to fight.
* Registered at ``pre_tool_use`` priority 15 — *ahead* of ApprovalGate
  (20) — so the status card shows ``🔧 正在调用 …`` before any approval
  prompt fires. If ApprovalGate then rejects/times out, the row stays
  at ``🔧`` because ``post_tool_use`` never runs; users learn the
  outcome from the approval card itself. Accepted as a minor cosmetic
  edge-case in exchange for the much better "happy path" UX.
* State is held in memory per ``ToolStatusCard`` instance keyed by
  per-turn ``request_id`` and bounded by an LRU cap. Across-process
  restart loses state, which is fine — the worst case is one stale
  unfinished card stuck at "正在调用…" until the user starts a new turn.
  Args / error values are scrubbed *before* they enter the cache so
  the in-memory window never retains raw credentials.
* Emits go through :meth:`MessageBus.dispatch_outbound` (direct
  handler dispatch, **not** :meth:`publish_outbound`) so a burst of
  status cards can't backpressure the bounded outbound queue and
  stall the tool execution loop. Status cards are ephemeral progress
  signals — they don't need queue durability.
* All emits are best-effort: any exception is swallowed so a card push
  failure can never break tool execution.
"""

from __future__ import annotations

import json
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from loguru import logger

from praestoclaw.channels import teams_cards
from praestoclaw.config.schema import ChannelType
from praestoclaw.hooks.manager import (
    HookResult,
    PostToolHookContext,
    PreToolHookContext,
)
from praestoclaw.security.leak import redact_credentials
from praestoclaw.security.sanitizer import Sanitizer

if TYPE_CHECKING:
    from praestoclaw.bus.queue import MessageBus


# Tools that render their own progress UI — skip to avoid double-cards.
# We deliberately do NOT skip ``tools`` (the MCP-enabling meta-tool):
# it almost always fires first in a turn and isn't approval-gated, so
# keeping it visible lets the status card appear *before* any approval
# card for a later, risk-flagged tool. That gives the user an early
# "agent is working" cue instead of an unexplained approval prompt.
_SKIP_TOOLS: frozenset[str] = frozenset({"plan"})

# Sources that route through the Teams bridge. Other inbound surfaces
# (web, CLI, A2A) get nothing from this hook.
_TEAMS_SOURCES: frozenset[str] = frozenset({"cloud_teams", "teams_bridge"})

# Cap the rendered ``Arguments`` JSON per row. Adaptive Cards have an
# effective ~25 KB body limit on Teams; arg dicts are usually small but
# a few MCP tools pass big payloads (e.g. file contents). 800 chars per
# row keeps even a 20-tool turn well inside the limit.
_MAX_ARGS_CHARS = 800

# Cap the inline error preview rendered under a failed row. Long
# tracebacks get clipped; the user can still scroll the audit log /
# server log for the full stack.
_MAX_ERROR_CHARS = 200
_MAX_ERROR_LINES = 3

# Cap the inline progress line rendered under a running row. Each
# tool_progress chunk overwrites the previous one (single-line UX),
# so a tight cap is fine — long shell stdout lines, multi-line scraper
# debug, etc. still surface their key info in the first ~120 chars.
_MAX_PROGRESS_CHARS = 120

# Sensitive-key heuristic. ``redact_credentials`` only catches
# *known-shape* tokens (JWT / AWS / OpenAI / …). Free-form Bearer
# tokens, short custom API keys, or plain-text passwords never match
# any pattern. But tool args are key/value-structured — if the *key*
# name looks dangerous we can redact the value wholesale regardless of
# its shape. Lower-cased for case-insensitive match.
_SENSITIVE_KEY_EXACT: frozenset[str] = frozenset(
    {
        "authorization",
        "auth",
        "proxy-authorization",
        "cookie",
        "set-cookie",
        "password",
        "passwd",
        "pwd",
        "secret",
        "token",
        "credentials",
        "credential",
        "apikey",
        "api-key",
        "x-api-key",
        "x-auth-token",
        "x-csrf-token",
        "x-amz-security-token",
    }
)

# Suffixes that almost always indicate the value is a secret. Catches
# ``access_token``, ``client_secret``, ``private_key``, etc. without
# enumerating every framework-specific variant.
_SENSITIVE_KEY_SUFFIXES: tuple[str, ...] = (
    "_token",
    "-token",
    "_key",
    "-key",
    "_secret",
    "-secret",
    "_password",
    "-password",
    "_credentials",
    "-credentials",
    "_pwd",
)

# Cap the number of distinct active turn states kept in memory. Each
# turn maps to a list of ``_ToolEntry`` rows. Once the cap is reached,
# oldest turns get evicted. Realistic chat workloads stay well below
# this; the bound is purely a memory-leak guard.
_MAX_TURN_STATES = 64


@dataclass
class _ToolEntry:
    """One row in the per-turn tool-status card."""

    tool_call_id: str
    tool_name: str
    status: str  # "running" | "done" | "error"
    args: dict[str, Any] = field(default_factory=dict)
    duration_ms: float | None = None
    # Raw tool result captured on the post hook. Only rendered on the
    # card when the call failed (truncated, monospace) so the user can
    # see *why* without opening server logs.
    result: str = ""
    # Most recent tool_progress chunk text. Set by ToolStatusCard.on_progress
    # while ``status == "running"`` and rendered as a small subtle line
    # under the 🔧 row so the user sees live progress (e.g. "Downloaded
    # 393 KB from …"). Cleared automatically once the post hook flips
    # the row to done/error — completed rows don't need the noise.
    progress: str = ""


# ── helpers ────────────────────────────────────────────────────────────────


def _turn_key(session_id: str, metadata: dict[str, Any]) -> str:
    """Derive a stable per-turn identifier.

    Prefers the gateway's per-conversation ``request_id`` (envelope id)
    which changes on every user turn. Falls back to ``messageId`` then
    ``session_id`` for older transports / cron-driven turns.
    """
    turn_id = ""
    if isinstance(metadata, dict):
        candidate = metadata.get("request_id") or metadata.get("messageId")
        if isinstance(candidate, str):
            turn_id = candidate.strip()
    if not turn_id:
        turn_id = session_id or "default"
    return turn_id


def _is_sensitive_key(name: object) -> bool:
    """Return ``True`` when *name* looks like a header/field that should
    never carry a plain value into a user-visible card.

    Compares case-insensitively against a small exact-match set plus a
    suffix list. Tolerant of underscore / hyphen separators.
    """
    s = str(name).lower()
    if s in _SENSITIVE_KEY_EXACT:
        return True
    return s.endswith(_SENSITIVE_KEY_SUFFIXES)


def _redact_sensitive_keys(obj: Any) -> Any:
    """Recursively replace values whose KEY name matches
    :func:`_is_sensitive_key` with a redaction marker. Defense in depth
    against opaque tokens that ``redact_credentials`` doesn't recognise
    (custom Bearer tokens, short API keys, plain-text passwords).

    Returns a new structure; the original ``args`` dict in
    ``_ToolEntry`` is left untouched (other hooks like Auditor still
    see the raw value).
    """
    if isinstance(obj, dict):
        return {
            k: ("[REDACTED:sensitive-key]" if _is_sensitive_key(k) else _redact_sensitive_keys(v))
            for k, v in obj.items()
        }
    if isinstance(obj, list):
        return [_redact_sensitive_keys(item) for item in obj]
    if isinstance(obj, tuple):
        return tuple(_redact_sensitive_keys(item) for item in obj)
    return obj


def _scrub(text: str) -> str:
    """Strip credentials / env-style secrets from card-bound text.

    ``bus.publish_outbound`` skips the ``on_message_sent`` hook chain
    (that runs only on the final assistant reply via the agent loop),
    so anything this hook publishes never sees ``OutboundLeakScanner``.
    We replicate the same two-stage scrub here: regex-based credential
    patterns (JWT / AWS / GitHub PAT / OpenAI / Slack / Stripe / private
    keys / Azure / high-entropy hex) plus env-value redaction. Cheap;
    runs once per published card.
    """
    if not text:
        return text
    cleaned = redact_credentials(text)
    cleaned = Sanitizer.redact_env_values(cleaned)
    return cleaned


def _scrub_leaves(obj: Any) -> Any:
    """Recursively apply :func:`_scrub` to every string leaf in *obj*.

    Pairs with :func:`_redact_sensitive_keys` to cover both axes of
    leakage before args land in the in-memory ``_turns`` cache:

    * ``_redact_sensitive_keys`` catches values whose KEY names a
      secret (``Authorization``, ``password`` …).
    * ``_scrub_leaves`` catches secrets that hide under benign keys
      (``{"note": "my AWS key is AKIA…"}``) by running the regex /
      env-value scrub on each string in place.

    Returns a new structure; the caller's original is untouched so
    other hooks (Auditor, etc.) still see the raw value.
    """
    if isinstance(obj, str):
        return _scrub(obj)
    if isinstance(obj, dict):
        return {k: _scrub_leaves(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_scrub_leaves(item) for item in obj]
    if isinstance(obj, tuple):
        return tuple(_scrub_leaves(item) for item in obj)
    return obj


def _format_error(result: str) -> str:
    """Trim a tool's error string for inline display under a failed row.

    Strips the canonical ``Error:`` prefix added by the agent loop,
    redacts any embedded credentials, keeps at most
    :data:`_MAX_ERROR_LINES` lines, and caps total length at
    :data:`_MAX_ERROR_CHARS` characters with an ellipsis.
    """
    if not isinstance(result, str) or not result.strip():
        return ""
    text = result.strip()
    if text.lower().startswith("error:"):
        text = text[len("error:") :].lstrip()
    if not text:
        return ""
    # Scrub *before* truncation so a credential that straddles the
    # truncation point doesn't leak its tail half onto the card.
    text = _scrub(text)
    lines = text.splitlines()
    if len(lines) > _MAX_ERROR_LINES:
        lines = lines[:_MAX_ERROR_LINES]
        lines[-1] = lines[-1].rstrip() + " \u2026"
    text = "\n".join(lines)
    if len(text) > _MAX_ERROR_CHARS:
        text = text[:_MAX_ERROR_CHARS].rstrip() + "\u2026"
    return text


def _format_args(args: dict[str, Any]) -> str:
    """Render the public tool arguments as pretty JSON for the details panel.

    Three-layer redaction before the JSON ever lands on the card:

    1. Strip framework-injected ``_*`` keys.
    2. Walk the structure and blank out values for any key that *names*
       a secret (Authorization, password, ``*_token``, …).
    3. Run the regex / env-value scrub on the serialised string, which
       also catches credentials that hide in benign-looking keys.

    Truncation happens **after** all three so a credential that spans
    the truncation point can't leak its head half.
    """
    if not isinstance(args, dict) or not args:
        return ""
    public = {k: v for k, v in args.items() if not str(k).startswith("_")}
    if not public:
        return ""
    public = _redact_sensitive_keys(public)
    try:
        text = json.dumps(public, indent=2, ensure_ascii=False, default=str)
    except Exception:  # noqa: BLE001
        return ""
    # Scrub before truncation — see ``_format_error`` for the rationale.
    text = _scrub(text)
    if len(text) > _MAX_ARGS_CHARS:
        text = text[:_MAX_ARGS_CHARS] + "\n\u2026"  # ellipsis
    return text


def _status_row_text(entry: _ToolEntry) -> tuple[str, bool, str]:
    """Return ``(text, is_subtle, color)`` for a single entry's status line.

    ``color`` is an Adaptive Card colour name — only failures get a
    colour (``"Attention"``, red) so the eye lands on what went wrong.
    Running and done rows use the renderer's default colour and rely on
    the leading icon (🔧 / ✓) plus subtlety to signal state.
    """
    if entry.status == "running":
        # 🔧 正在调用 `tool_name`…
        return (
            f"\U0001f527 \u6b63\u5728\u8c03\u7528 `{entry.tool_name}`\u2026",
            False,
            "",
        )
    if entry.status == "done":
        suffix = ""
        if entry.duration_ms is not None and entry.duration_ms > 0:
            suffix = f" \u00b7 {entry.duration_ms:.0f} ms"
        # ✓ `tool_name` 已完成 — kept subtle so completed rows recede.
        return (
            f"\u2713 `{entry.tool_name}` \u5df2\u5b8c\u6210{suffix}",
            True,
            "",
        )
    if entry.status == "error":
        suffix = ""
        if entry.duration_ms is not None and entry.duration_ms > 0:
            suffix = f" \u00b7 {entry.duration_ms:.0f} ms"
        # ✗ `tool_name` 失败 — bold + red so failures pop.
        return (
            f"\u2717 `{entry.tool_name}` \u5931\u8d25{suffix}",
            False,
            "Attention",
        )
    return (f"`{entry.tool_name}`", True, "")  # pragma: no cover — defensive


def _build_row(entry: _ToolEntry, *, first: bool) -> list[dict[str, Any]]:
    """Build the AdaptiveCard elements for one tool entry.

    Returns a 1- or 2-element list:

    * One ``TextBlock`` when there are no public args (no expand panel).
    * One ``Container`` (clickable status row) + one hidden details
      ``Container`` (Arguments panel) otherwise.

    A failed entry additionally produces an inline error ``TextBlock``
    rendered immediately under the status row (never hidden behind the
    expand affordance) so users see the failure reason at a glance.
    """
    text, is_subtle, color = _status_row_text(entry)
    spacing = "Default" if not first else "None"

    status_block: dict[str, Any] = {
        "type": "TextBlock",
        "text": text,
        "wrap": True,
        "isSubtle": is_subtle,
        "size": "Small",
    }
    if color:
        status_block["color"] = color

    error_text = _format_error(entry.result) if entry.status == "error" else ""
    error_block: dict[str, Any] | None = None
    if error_text:
        error_block = {
            "type": "TextBlock",
            "text": error_text,
            "wrap": True,
            "fontType": "Monospace",
            "size": "Small",
            "color": "Attention",
            "isSubtle": True,
            "spacing": "None",
        }

    # Live progress chip — only while the tool is still running and a
    # progress chunk has arrived. Kept subtle/small + leading "·" so it
    # reads as a status hint, not a separate row. Cleared automatically
    # when the post hook flips ``status`` to done/error.
    progress_block: dict[str, Any] | None = None
    if entry.status == "running" and entry.progress:
        progress_block = {
            "type": "TextBlock",
            "text": f"\u00b7 {entry.progress}",
            "wrap": True,
            "isSubtle": True,
            "size": "Small",
            "spacing": "None",
        }

    args_text = _format_args(entry.args)
    if not args_text:
        status_block["spacing"] = spacing
        blocks: list[dict[str, Any]] = [status_block]
        if progress_block is not None:
            blocks.append(progress_block)
        if error_block is not None:
            blocks.append(error_block)
        return blocks

    # Stable element id; only needs to be unique within this card.
    details_id = f"details-{(entry.tool_call_id or entry.tool_name).replace(':', '_')}"
    row_container: dict[str, Any] = {
        "type": "Container",
        "spacing": spacing,
        "selectAction": {
            "type": "Action.ToggleVisibility",
            "title": "\u5c55\u5f00 / \u6536\u8d77",  # 展开 / 收起
            "targetElements": [details_id],
        },
        "items": [status_block],
    }
    details_container: dict[str, Any] = {
        "type": "Container",
        "id": details_id,
        "isVisible": False,
        "spacing": "Small",
        "separator": True,
        "items": [
            {
                "type": "TextBlock",
                "text": "Arguments",
                "size": "Small",
                "weight": "Bolder",
                "isSubtle": True,
                "spacing": "None",
            },
            {
                "type": "TextBlock",
                "text": args_text,
                "wrap": True,
                "fontType": "Monospace",
                "size": "Small",
                "spacing": "Small",
            },
        ],
    }
    blocks = [row_container]
    if progress_block is not None:
        blocks.append(progress_block)
    if error_block is not None:
        blocks.append(error_block)
    blocks.append(details_container)
    return blocks


def build_tool_status_card(entries: list[_ToolEntry]) -> dict[str, Any]:
    """Render the full per-turn Adaptive Card from a list of entries.

    Each entry produces one user-visible row (status text + optional
    click-to-expand Arguments panel). The order of *entries* is
    preserved as-is, matching the LLM-driven order of ``pre_tool_use``
    invocations.
    """
    body: list[dict[str, Any]] = []
    for idx, entry in enumerate(entries):
        body.extend(_build_row(entry, first=idx == 0))

    if not body:  # pragma: no cover — defensive
        body = [
            {
                "type": "TextBlock",
                "text": "\u2026",
                "wrap": True,
                "isSubtle": True,
                "size": "Small",
            }
        ]

    return {
        "type": "AdaptiveCard",
        "$schema": teams_cards.ADAPTIVE_CARD_SCHEMA,
        "version": teams_cards.ADAPTIVE_CARD_VERSION,
        "body": body,
    }


class ToolStatusCard:
    """Pre/post tool hooks that animate a per-turn Teams Adaptive Card.

    Two callables are exposed (``pre`` and ``post``) to be registered on
    the ``pre_tool_use`` and ``post_tool_use`` phases respectively. The
    instance maintains per-turn state so successive tools within the
    same turn accumulate into one card rather than stacking new ones.
    """

    def __init__(self, message_bus: MessageBus | None = None) -> None:
        self._bus = message_bus
        # turn_key -> ordered dict of tool_call_id -> entry. We rely on
        # Python's insertion-ordered dicts (3.7+) so iteration order
        # matches the LLM's tool-call sequence.
        self._turns: OrderedDict[str, OrderedDict[str, _ToolEntry]] = OrderedDict()

    # ── Public hook entry points ────────────────────────────────────────

    async def pre(self, ctx: PreToolHookContext) -> HookResult:
        await self._record_and_emit(
            tool_name=ctx.tool_name,
            status="running",
            session_id=ctx.session_id,
            channel=ctx.channel,
            channel_id=ctx.channel_id,
            metadata=ctx.metadata,
            duration_ms=None,
            args=ctx.args,
            tool_call_id=ctx.tool_call_id,
        )
        return HookResult.allow()

    async def post(self, ctx: PostToolHookContext) -> HookResult:
        await self._record_and_emit(
            tool_name=ctx.tool_name,
            status="done" if ctx.success else "error",
            session_id=ctx.session_id,
            channel=ctx.channel,
            channel_id=ctx.channel_id,
            metadata=ctx.metadata,
            duration_ms=ctx.duration_ms,
            args=ctx.args,
            tool_call_id=ctx.tool_call_id,
            result=ctx.result if not ctx.success else "",
        )
        return HookResult.allow()

    # ── Internals ───────────────────────────────────────────────────────

    def _entry_id(self, tool_call_id: str, tool_name: str) -> str:
        """Stable per-row id; synthesised when the LLM omits a call id.

        Must produce the **same** id for the matching ``pre``/``post``
        pair, otherwise ``post`` would mint a fresh row instead of
        updating the running one (Copilot review #154). A previous
        version included the current ``len(state)`` as a positional
        suffix, which broke that invariant: at ``pre`` the entry didn't
        yet exist (``len=0``) but at ``post`` it did (``len=1``), so
        the suffix differed.

        Trade-off: two parallel calls of the *same* tool without ids
        now collapse into one row. Acceptable — modern providers always
        emit ids; the no-id path is only hit by internal heartbeat /
        cron tools where the status card never fires anyway.
        """
        tid = (tool_call_id or "").strip()
        return tid or f"_{tool_name}"

    def _turn_state(self, turn_key: str) -> OrderedDict[str, _ToolEntry]:
        state = self._turns.get(turn_key)
        if state is None:
            state = OrderedDict()
            self._turns[turn_key] = state
            # Evict the oldest turn if we're past the cap.
            while len(self._turns) > _MAX_TURN_STATES:
                evicted_key, _ = self._turns.popitem(last=False)
                logger.debug(
                    "ToolStatusCard evicted turn state {} (cap={})",
                    evicted_key,
                    _MAX_TURN_STATES,
                )
        else:
            # Touch — keeps active turns "hot" against the LRU cap.
            self._turns.move_to_end(turn_key)
        return state

    async def _record_and_emit(
        self,
        *,
        tool_name: str,
        status: str,
        session_id: str,
        channel: ChannelType | None,
        channel_id: str,
        metadata: dict[str, Any],
        duration_ms: float | None,
        args: dict[str, Any] | None,
        tool_call_id: str,
        result: str = "",
    ) -> None:
        if self._bus is None:
            return
        if not self._should_emit(
            tool_name=tool_name, channel=channel, channel_id=channel_id, metadata=metadata
        ):
            return

        turn = _turn_key(session_id, metadata)
        state = self._turn_state(turn)
        row_id = self._entry_id(tool_call_id, tool_name)
        # Pre-scrub before storing. Two motivations (Copilot review #154):
        # 1. Secrets must never sit in the in-memory ``_turns`` cache
        #    (up to 64 turns) — audit logs and session.messages persist
        #    those separately, but this hook should not add a third
        #    retention path.
        # 2. Render time stays cheap: ``_format_args`` / ``_format_error``
        #    re-apply the same scrubs (idempotent), but the heavy lifting
        #    has already happened here at storage time.
        #
        # Two-axis scrub so neither side leaks:
        # * ``_redact_sensitive_keys`` — values whose KEY names a secret.
        # * ``_scrub_leaves`` — secrets hidden under benign keys, e.g.
        #   ``{"note": "my AWS key is AKIA…"}`` (Copilot follow-up).
        scrubbed_args = _scrub_leaves(_redact_sensitive_keys(args or {})) if args else {}
        scrubbed_result = _scrub(result) if result else ""
        existing = state.get(row_id)
        if existing is None:
            state[row_id] = _ToolEntry(
                tool_call_id=row_id,
                tool_name=tool_name,
                status=status,
                args=scrubbed_args if isinstance(scrubbed_args, dict) else {},
                duration_ms=duration_ms,
                result=scrubbed_result,
            )
        else:
            existing.status = status
            if duration_ms is not None:
                existing.duration_ms = duration_ms
            if args and isinstance(scrubbed_args, dict):
                # Refresh args if post supplies them (pre usually does).
                existing.args = scrubbed_args
            if scrubbed_result:
                existing.result = scrubbed_result

        await self._publish_card(
            channel=channel,
            channel_id=channel_id,
            turn=turn,
            state=state,
            tool_name=tool_name,
            status=status,
        )

    async def on_progress(self, event_type: Any, payload: dict[str, Any]) -> None:
        """Handle a ``EventType.TOOL_PROGRESS`` event from the tool registry.

        Updates the matching ``running`` row's progress line and
        re-emits the per-turn card. No-op when:

        * no ``MessageBus`` was supplied to this instance (smoke tests);
        * the channel / source doesn't qualify for the Teams card path
          (``_should_emit`` mirrors the pre/post hook gate);
        * no row exists for this ``(turn, tool_call_id)`` pair yet
          (progress arrived before ``pre_tool_use``, which is racy but
          rare — the next pre hook will paint a fresh row anyway);
        * the row already finished — late progress chunks must not
          revert a ✓ or ✗ row back into a 🔧 running look.

        The event-bus dispatch is fire-and-forget; any exception here
        is swallowed so a card render failure can never break the
        outbound stream chunk that travelled the same path.
        """
        if self._bus is None:
            return
        try:
            tool_call_id = str(payload.get("tool_call_id") or "")
            tool_name = str(payload.get("tool_name") or "")
            text = str(payload.get("text") or "").strip()
            session_id = str(payload.get("session_id") or "")
            channel = payload.get("channel")
            channel_id = str(payload.get("channel_id") or "")
            metadata = payload.get("metadata") or {}

            if not text or not tool_name or not channel_id:
                return
            if not self._should_emit(
                tool_name=tool_name,
                channel=channel if isinstance(channel, ChannelType) else None,
                channel_id=channel_id,
                metadata=metadata if isinstance(metadata, dict) else {},
            ):
                return

            turn = _turn_key(session_id, metadata if isinstance(metadata, dict) else {})
            state = self._turns.get(turn)
            if state is None:
                return  # pre hook hasn't fired yet — drop silently
            row_id = self._entry_id(tool_call_id, tool_name)
            entry = state.get(row_id)
            if entry is None or entry.status != "running":
                return

            # One-line UX: most recent line wins. Strip newlines (shell
            # tools emit one decoded chunk per stdout line) and clip.
            collapsed = " ".join(text.split())
            scrubbed = _scrub(collapsed)
            if len(scrubbed) > _MAX_PROGRESS_CHARS:
                scrubbed = scrubbed[:_MAX_PROGRESS_CHARS].rstrip() + "\u2026"
            if scrubbed == entry.progress:
                # Identical to the last chunk — skip re-render. Saves a
                # round-trip for shell tools that re-emit the same line.
                return
            entry.progress = scrubbed

            await self._publish_card(
                channel=channel if isinstance(channel, ChannelType) else None,
                channel_id=channel_id,
                turn=turn,
                state=state,
                tool_name=tool_name,
                status="progress",
            )
        except Exception as exc:  # noqa: BLE001
            logger.debug("ToolStatusCard on_progress failed: {}", exc)

    async def _publish_card(
        self,
        *,
        channel: ChannelType | None,
        channel_id: str,
        turn: str,
        state: OrderedDict[str, _ToolEntry],
        tool_name: str,
        status: str,
    ) -> None:
        """Render and dispatch the per-turn status card.

        Shared by ``_record_and_emit`` (pre/post hooks) and
        ``on_progress`` (TOOL_PROGRESS event) so both paths use the
        identical ``update_key`` and metadata, ensuring the bridge
        animates a single Teams activity rather than stacking new
        cards across hook + progress emits.
        """
        if self._bus is None:
            return
        try:
            from praestoclaw.bus.events import OutboundMessage

            card = build_tool_status_card(list(state.values()))
            activity = teams_cards.wrap_for_teams(card)
            payload = json.dumps(activity, ensure_ascii=False)

            await self._bus.dispatch_outbound(
                OutboundMessage(
                    channel=channel or ChannelType.CLOUD,
                    channel_id=channel_id,
                    content=payload,
                    metadata={
                        # keep_context=True keeps the gateway's reply
                        # binding alive so the eventual /chatng answer
                        # still resolves the original sync waiter.
                        "keep_context": True,
                        "push_target": "teams",
                        "update_key": f"tool_status:{turn}",
                    },
                )
            )
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "ToolStatusCard emit failed (tool={}, status={}): {}",
                tool_name,
                status,
                exc,
            )

    @staticmethod
    def _should_emit(
        *,
        tool_name: str,
        channel: ChannelType | None,
        channel_id: str,
        metadata: dict[str, Any],
    ) -> bool:
        if not channel_id:
            return False
        if channel is not None and channel != ChannelType.CLOUD:
            return False
        if tool_name in _SKIP_TOOLS:
            return False
        source = ""
        if isinstance(metadata, dict):
            source = str(metadata.get("source", ""))
        return source in _TEAMS_SOURCES
