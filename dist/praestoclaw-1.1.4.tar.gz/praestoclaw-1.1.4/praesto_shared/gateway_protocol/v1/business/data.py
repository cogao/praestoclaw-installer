"""Typed helpers for the Agent-Gateway business data contract."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any

from praesto_shared.gateway_protocol.v1.business.envelope import BusinessProtocolError

TEXT_FORMATS = frozenset({"text", "markdown", "html"})
CONTENT_TYPES = frozenset({"text", "file_chunk"})


def _require_mapping(value: Any, field_name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise BusinessProtocolError(f"{field_name} must be an object")
    return value


def _require_string(value: Any, field_name: str) -> str:
    if not isinstance(value, str) or not value:
        raise BusinessProtocolError(f"{field_name} must be a non-empty string")
    return value


def _optional_string(value: Any, field_name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise BusinessProtocolError(f"{field_name} must be a string or null")
    return value


@dataclass(frozen=True)
class ConversationContext:
    """The ``body.context`` object shared by conversation, U2U, and A2A messages."""

    conversation_id: str
    task_id: str | None = None
    parent_envelope_id: str | None = None
    upstream: dict[str, Any] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def parse(cls, value: Mapping[str, Any]) -> ConversationContext:
        conversation_id = _require_string(value.get("conversation_id"), "context.conversation_id")
        task_id = _optional_string(value.get("task_id"), "context.task_id")
        parent_envelope_id = _optional_string(
            value.get("parent_envelope_id"),
            "context.parent_envelope_id",
        )
        upstream_value = value.get("upstream")
        upstream = None
        if upstream_value is not None:
            upstream = dict(_require_mapping(upstream_value, "context.upstream"))
        known = {"conversation_id", "task_id", "parent_envelope_id", "upstream"}
        extra = {str(key): item for key, item in value.items() if key not in known}
        return cls(
            conversation_id=conversation_id,
            task_id=task_id,
            parent_envelope_id=parent_envelope_id,
            upstream=upstream,
            extra=extra,
        )

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "conversation_id": self.conversation_id,
            "task_id": self.task_id,
        }
        if self.parent_envelope_id is not None:
            result["parent_envelope_id"] = self.parent_envelope_id
        if self.upstream is not None:
            result["upstream"] = dict(self.upstream)
        result.update(self.extra)
        return result


@dataclass(frozen=True)
class Sender:
    """Conversation sender claim. Authorization still comes from the Gateway principal."""

    kind: str
    id: str
    user_id: str | None = None
    display_name: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def parse(cls, value: Mapping[str, Any]) -> Sender:
        kind = _require_string(value.get("kind"), "sender.kind")
        if kind not in {"human", "agent", "gateway"}:
            raise BusinessProtocolError("sender.kind is invalid")
        sender_id = _require_string(value.get("id"), "sender.id")
        user_id = _optional_string(value.get("user_id"), "sender.user_id")
        if kind == "agent" and not user_id:
            raise BusinessProtocolError("sender.user_id is required for agent senders")
        display_name = _optional_string(value.get("display_name"), "sender.display_name")
        known = {"kind", "id", "user_id", "display_name"}
        extra = {str(key): item for key, item in value.items() if key not in known}
        return cls(
            kind=kind,
            id=sender_id,
            user_id=user_id,
            display_name=display_name,
            extra=extra,
        )

    def to_dict(self) -> dict[str, Any]:
        result = {"kind": self.kind, "id": self.id}
        if self.user_id is not None:
            result["user_id"] = self.user_id
        if self.display_name is not None:
            result["display_name"] = self.display_name
        result.update(self.extra)
        return result


@dataclass(frozen=True)
class Recipient:
    """Conversation recipient routing claim."""

    kind: str
    user_id: str | None = None
    agent_id: str | None = None
    id: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def parse(cls, value: Mapping[str, Any]) -> Recipient:
        kind = _require_string(value.get("kind"), "recipient.kind")
        if kind not in {"agent", "gateway", "user"}:
            raise BusinessProtocolError("recipient.kind is invalid")
        user_id = _optional_string(value.get("user_id"), "recipient.user_id")
        agent_id = _optional_string(value.get("agent_id"), "recipient.agent_id")
        recipient_id = _optional_string(value.get("id"), "recipient.id")
        if kind == "agent" and (not user_id or not agent_id):
            raise BusinessProtocolError(
                "recipient.user_id and recipient.agent_id are required for agent recipients"
            )
        if kind == "gateway" and not recipient_id:
            raise BusinessProtocolError("recipient.id is required for gateway recipients")
        if kind == "user" and not user_id:
            raise BusinessProtocolError("recipient.user_id is required for user recipients")
        known = {"kind", "user_id", "agent_id", "id"}
        extra = {str(key): item for key, item in value.items() if key not in known}
        return cls(kind=kind, user_id=user_id, agent_id=agent_id, id=recipient_id, extra=extra)

    def to_dict(self) -> dict[str, Any]:
        result = {"kind": self.kind}
        if self.user_id is not None:
            result["user_id"] = self.user_id
        if self.agent_id is not None:
            result["agent_id"] = self.agent_id
        if self.id is not None:
            result["id"] = self.id
        result.update(self.extra)
        return result


@dataclass(frozen=True)
class TextContent:
    """Text conversation content."""

    text: str
    format: str = "text"

    @classmethod
    def parse(cls, value: Mapping[str, Any]) -> TextContent:
        text = value.get("text")
        if not isinstance(text, str):
            raise BusinessProtocolError("content.text must be a string")
        content_format = value.get("format", "text")
        if not isinstance(content_format, str):
            raise BusinessProtocolError("content.format must be a string")
        if content_format not in TEXT_FORMATS:
            content_format = "text"
        return cls(text=text, format=content_format)

    def to_dict(self) -> dict[str, Any]:
        return {"content_type": "text", "text": self.text, "format": self.format}


@dataclass(frozen=True)
class FileChunkContent:
    """Base64-encoded file chunk content."""

    file_id: str
    offset: int
    data_base64: str
    is_last: bool
    filename: str | None = None
    media_type: str | None = None

    @classmethod
    def parse(cls, value: Mapping[str, Any]) -> FileChunkContent:
        file_id = _require_string(value.get("file_id"), "content.file_id")
        offset = value.get("offset")
        if not isinstance(offset, int) or isinstance(offset, bool) or offset < 0:
            raise BusinessProtocolError("content.offset must be a non-negative integer")
        data_base64 = value.get("data_base64")
        if not isinstance(data_base64, str):
            raise BusinessProtocolError("content.data_base64 must be a string")
        is_last = value.get("is_last")
        if not isinstance(is_last, bool):
            raise BusinessProtocolError("content.is_last must be a boolean")
        if not data_base64 and not is_last:
            raise BusinessProtocolError("empty file chunk data is only allowed on the final chunk")
        return cls(
            file_id=file_id,
            filename=_optional_string(value.get("filename"), "content.filename"),
            media_type=_optional_string(value.get("media_type"), "content.media_type"),
            offset=offset,
            data_base64=data_base64,
            is_last=is_last,
        )

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "content_type": "file_chunk",
            "file_id": self.file_id,
            "offset": self.offset,
            "data_base64": self.data_base64,
            "is_last": self.is_last,
        }
        if self.filename is not None:
            result["filename"] = self.filename
        if self.media_type is not None:
            result["media_type"] = self.media_type
        return result


Content = TextContent | FileChunkContent


def parse_content(value: Mapping[str, Any]) -> Content:
    content_type = _require_string(value.get("content_type"), "content.content_type")
    if content_type == "text":
        return TextContent.parse(value)
    if content_type == "file_chunk":
        return FileChunkContent.parse(value)
    raise BusinessProtocolError("content.content_type is invalid")


@dataclass(frozen=True)
class ConversationBody:
    """Common conversation body used by ``conversation.message.*`` topics."""

    context: ConversationContext
    sender: Sender
    recipient: Recipient
    content: Content
    timestamp: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def parse(cls, value: Mapping[str, Any]) -> ConversationBody:
        context = ConversationContext.parse(_require_mapping(value.get("context"), "context"))
        sender = Sender.parse(_require_mapping(value.get("sender"), "sender"))
        recipient = Recipient.parse(_require_mapping(value.get("recipient"), "recipient"))
        content = parse_content(_require_mapping(value.get("content"), "content"))
        timestamp = _optional_string(value.get("timestamp"), "timestamp")
        metadata = dict(_require_mapping(value.get("metadata", {}), "metadata"))
        return cls(
            context=context,
            sender=sender,
            recipient=recipient,
            content=content,
            timestamp=timestamp,
            metadata=metadata,
        )

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "context": self.context.to_dict(),
            "sender": self.sender.to_dict(),
            "recipient": self.recipient.to_dict(),
            "content": self.content.to_dict(),
            "metadata": dict(self.metadata),
        }
        if self.timestamp is not None:
            result["timestamp"] = self.timestamp
        return result


@dataclass(frozen=True)
class SessionHello:
    """``_session.hello`` request body."""

    client_version: str
    framework_version: int
    features: tuple[str, ...]
    agent_id: str
    user_id: str
    min_framework_version: int | None = None

    def to_dict(self) -> dict[str, Any]:
        body: dict[str, Any] = {
            "client_version": self.client_version,
            "framework_version": self.framework_version,
            "features": list(self.features),
            "identity": {
                "agent_id": self.agent_id,
                "user_id": self.user_id,
            },
        }
        if self.min_framework_version is not None:
            body["min_framework_version"] = self.min_framework_version
        return body


def validate_conversation_body(body: Mapping[str, Any]) -> ConversationBody:
    """Parse and validate a common conversation body."""

    return ConversationBody.parse(body)
