"""Business-layer envelope model for ``t.data.payload``."""

from __future__ import annotations

import json
import re
import secrets
import threading
import time
from collections.abc import Mapping
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

TOPIC_RE = re.compile(r"^_?[a-z0-9_]+(\.[a-z0-9_]+)*$")
HEADER_KEY_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9_-]*$")
SERVER_FEATURES = frozenset({"conversation", "file_stream", "a2a", "u2u"})
FRAMEWORK_VERSION = 1

MAX_HEADERS = 32
MAX_HEADER_COUNT = MAX_HEADERS
MAX_HEADER_VALUE_BYTES = 8 * 1024
MAX_HEADERS_BYTES = 64 * 1024
MAX_BODY_DEPTH = 16

_ULID_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
_ULID_LOCK = threading.Lock()
_LAST_ULID_MS = -1
_LAST_ULID_RANDOM = 0


class EnvelopeKind(StrEnum):
    """Business interaction kinds."""

    EVENT = "event"
    REQUEST = "request"
    RESPONSE = "response"
    STREAM_ITEM = "stream_item"
    STREAM_END = "stream_end"
    ERROR = "error"
    CANCEL = "cancel"


class BusinessProtocolError(Exception):
    """Raised when a business envelope is malformed."""


class BusinessError(Exception):
    """Business-level terminal error for a request or stream."""

    def __init__(
        self,
        code: str,
        message: str,
        *,
        retryable: bool = False,
        details: Mapping[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.retryable = retryable
        self.details = dict(details or {})

    def to_body(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "retryable": self.retryable,
            "details": dict(self.details),
        }

    @classmethod
    def from_body(cls, body: Mapping[str, Any]) -> BusinessError:
        code = body.get("code", "internal")
        message = body.get("message", "")
        retryable = body.get("retryable", False)
        details = body.get("details", {})
        return cls(
            str(code),
            str(message),
            retryable=bool(retryable),
            details=details if isinstance(details, Mapping) else {},
        )


def is_valid_topic(topic: str) -> bool:
    """Return whether a topic follows the public dotted-lowercase convention."""

    return bool(TOPIC_RE.fullmatch(topic)) and not topic.startswith("_")


def is_valid_reserved_topic(topic: str) -> bool:
    """Return whether a topic is a framework-reserved topic currently supported."""

    return topic == "_session.hello"


def validate_headers(headers: Mapping[str, Any]) -> dict[str, str | int | bool]:
    """Validate framework header limits from the business protocol."""

    if len(headers) > MAX_HEADERS:
        raise BusinessProtocolError("too many headers")

    validated: dict[str, str | int | bool] = {}
    total_size = 0
    for key, value in headers.items():
        if not isinstance(key, str) or not HEADER_KEY_RE.fullmatch(key):
            raise BusinessProtocolError("invalid header key")
        if not isinstance(value, (str, int, bool)):
            raise BusinessProtocolError("invalid header value")
        encoded_value = json_size(value)
        if encoded_value > MAX_HEADER_VALUE_BYTES:
            raise BusinessProtocolError("header value too large")
        total_size += len(key.encode("utf-8")) + encoded_value
        validated[key] = value

    if total_size > MAX_HEADERS_BYTES:
        raise BusinessProtocolError("headers too large")
    return validated


def validate_body_depth(body: Mapping[str, Any]) -> None:
    """Reject body objects deeper than the v1 nesting limit."""

    if json_depth(body) > MAX_BODY_DEPTH:
        raise BusinessProtocolError("body nesting too deep")


def json_size(value: Any) -> int:
    """Return compact JSON UTF-8 size for protocol limit checks."""

    return len(json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))


def json_depth(value: Any) -> int:
    """Return JSON container nesting depth, counting objects and arrays."""

    if isinstance(value, Mapping):
        if not value:
            return 1
        return 1 + max(json_depth(item) for item in value.values())
    if isinstance(value, list):
        if not value:
            return 1
        return 1 + max(json_depth(item) for item in value)
    return 0


def new_envelope_id() -> str:
    """Generate a monotonic ULID envelope identifier."""

    global _LAST_ULID_MS, _LAST_ULID_RANDOM

    now_ms = int(time.time() * 1000)
    with _ULID_LOCK:
        if now_ms == _LAST_ULID_MS:
            _LAST_ULID_RANDOM = (_LAST_ULID_RANDOM + 1) & ((1 << 80) - 1)
        else:
            _LAST_ULID_MS = now_ms
            _LAST_ULID_RANDOM = secrets.randbits(80)
        value = (now_ms << 80) | _LAST_ULID_RANDOM

    chars = []
    for _ in range(26):
        chars.append(_ULID_ALPHABET[value & 0b11111])
        value >>= 5
    return "".join(reversed(chars))

class Envelope(BaseModel):
    """Business envelope carried inside ``t.data.payload``."""

    model_config = ConfigDict(extra="ignore")

    kind: EnvelopeKind
    id: str
    body: dict[str, Any] = Field(default_factory=dict)
    correlation_id: str | None = None
    topic: str | None = None
    headers: dict[str, Any] = Field(default_factory=dict)

    @field_validator("headers", mode="before")
    @classmethod
    def _coerce_headers(cls, value: Any) -> Any:
        return {} if value is None else value

    @model_validator(mode="after")
    def validate_shape(self) -> Envelope:
        if not self.id:
            raise ValueError("id is required")
        validate_headers(self.headers)
        validate_body_depth(self.body)
        if self.kind in {EnvelopeKind.EVENT, EnvelopeKind.REQUEST}:
            if not self.topic:
                raise ValueError("event/request requires topic")
            if self.correlation_id is not None:
                raise ValueError("event/request correlation_id must be null")
        else:
            if self.topic is not None:
                raise ValueError("reply/control topic must be null")
            if not self.correlation_id:
                raise ValueError("reply/control requires correlation_id")
        return self

    @property
    def is_terminal(self) -> bool:
        return self.kind in {
            EnvelopeKind.RESPONSE,
            EnvelopeKind.STREAM_END,
            EnvelopeKind.ERROR,
        }

    @classmethod
    def event(
        cls,
        topic: str,
        body: Mapping[str, Any],
        *,
        headers: Mapping[str, Any] | None = None,
        envelope_id: str | None = None,
    ) -> Envelope:
        return cls(
            kind=EnvelopeKind.EVENT,
            id=envelope_id or new_envelope_id(),
            topic=topic,
            headers=dict(headers or {}),
            body=dict(body),
        )

    @classmethod
    def request(
        cls,
        topic: str,
        body: Mapping[str, Any],
        *,
        headers: Mapping[str, Any] | None = None,
        envelope_id: str | None = None,
    ) -> Envelope:
        return cls(
            kind=EnvelopeKind.REQUEST,
            id=envelope_id or new_envelope_id(),
            topic=topic,
            headers=dict(headers or {}),
            body=dict(body),
        )

    @classmethod
    def response(
        cls,
        correlation_id: str,
        body: Mapping[str, Any],
        *,
        envelope_id: str | None = None,
    ) -> Envelope:
        return cls(
            kind=EnvelopeKind.RESPONSE,
            id=envelope_id or new_envelope_id(),
            correlation_id=correlation_id,
            body=dict(body),
        )

    @classmethod
    def stream_item(
        cls,
        correlation_id: str,
        body: Mapping[str, Any],
        *,
        envelope_id: str | None = None,
    ) -> Envelope:
        return cls(
            kind=EnvelopeKind.STREAM_ITEM,
            id=envelope_id or new_envelope_id(),
            correlation_id=correlation_id,
            body=dict(body),
        )

    @classmethod
    def stream_end(
        cls,
        correlation_id: str,
        body: Mapping[str, Any] | None = None,
        *,
        envelope_id: str | None = None,
    ) -> Envelope:
        return cls(
            kind=EnvelopeKind.STREAM_END,
            id=envelope_id or new_envelope_id(),
            correlation_id=correlation_id,
            body=dict(body or {"reason": "complete"}),
        )

    @classmethod
    def error(
        cls,
        correlation_id: str,
        error: BusinessError,
        *,
        envelope_id: str | None = None,
    ) -> Envelope:
        return cls(
            kind=EnvelopeKind.ERROR,
            id=envelope_id or new_envelope_id(),
            correlation_id=correlation_id,
            body=error.to_body(),
        )

    @classmethod
    def cancel(
        cls,
        correlation_id: str,
        *,
        reason: str | None = None,
        envelope_id: str | None = None,
    ) -> Envelope:
        return cls(
            kind=EnvelopeKind.CANCEL,
            id=envelope_id or new_envelope_id(),
            correlation_id=correlation_id,
            body={"reason": reason or "caller_cancelled"},
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind.value,
            "id": self.id,
            "correlation_id": self.correlation_id,
            "topic": self.topic,
            "headers": dict(self.headers),
            "body": dict(self.body),
        }

    @classmethod
    def parse(cls, payload: Mapping[str, Any]) -> Envelope:
        """Parse and validate a business envelope from a transport payload."""

        if not isinstance(payload, Mapping):
            raise BusinessProtocolError("envelope must be an object")
        try:
            return cls.model_validate(payload)
        except (ValidationError, ValueError) as exc:
            raise BusinessProtocolError(str(exc)) from exc


def error_envelope(
    correlation_id: str,
    *,
    code: str,
    message: str,
    retryable: bool = False,
    details: Mapping[str, Any] | None = None,
) -> Envelope:
    return Envelope(
        kind=EnvelopeKind.ERROR,
        id=new_envelope_id(),
        correlation_id=correlation_id,
        body=BusinessError(
            code,
            message,
            retryable=retryable,
            details=details,
        ).to_body(),
    )
