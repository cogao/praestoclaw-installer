"""Task protocol v1 wire types and content-type discriminators."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

CONTENT_TYPE_TASK_REQUEST = "application/vnd.praestoclaw.task+json"
CONTENT_TYPE_TASK_PROGRESS = "application/vnd.praestoclaw.task.progress+json"
CONTENT_TYPE_TASK_CONTROL = "application/vnd.praestoclaw.task.control+json"

TASK_PROGRESS_TOPIC = "task.progress"
TASK_CONTROL_TOPIC = "task.control"

WAITING_APPROVAL_L2_DEADLINE_MS = 180_000
WAITING_APPROVAL_L3_DEADLINE_MS = 300_000
EXECUTING_DEFAULT_DEADLINE_MS = 5 * 60 * 1000
TASK_HARD_CAP_MS = 2 * 60 * 60 * 1000

TaskStage = Literal[
    "queued",
    "gating",
    "waiting_approval",
    "executing",
    "done",
    "declined",
    "interrupted",
    "timed_out",
]

TERMINAL_STAGES: frozenset[TaskStage] = frozenset(
    {"done", "declined", "interrupted", "timed_out"}
)


class TaskIntent(BaseModel):
    """Sender's description of what the task is asking for."""

    model_config = ConfigDict(extra="ignore")

    summary: str
    action: str | None = None
    hint_risk: Literal["read", "write", "external"] | None = None
    undoable: bool = False
    args: dict[str, Any] = Field(default_factory=dict)


class TaskDeadlines(BaseModel):
    model_config = ConfigDict(extra="ignore")

    soft_ms: int | None = None
    hard_ms: int | None = None


class TaskRequest(BaseModel):
    """The ``content.task`` body of a task-bearing carrier envelope."""

    model_config = ConfigDict(extra="ignore")

    task_id: str
    intent: TaskIntent
    deadlines: TaskDeadlines = Field(default_factory=TaskDeadlines)


def extract_task_request(carrier_body: dict[str, Any]) -> TaskRequest | None:
    """Return a :class:`TaskRequest` if the carrier body is a task."""

    content = carrier_body.get("content")
    if not isinstance(content, dict):
        return None
    if content.get("content_type") != CONTENT_TYPE_TASK_REQUEST:
        return None
    task = content.get("task")
    if not isinstance(task, dict):
        return None
    try:
        return TaskRequest.model_validate(task)
    except Exception:
        return None
