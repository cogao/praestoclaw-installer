from __future__ import annotations

from collections.abc import Mapping
from typing import Annotated, Any

from pydantic import Field, TypeAdapter

from praesto_shared.agent_link.v1.frames import (
    ChannelInboundFrame,
    ChannelOutboundFrame,
    ControlFrame,
)

AgentLinkFrame = Annotated[
    ChannelInboundFrame | ChannelOutboundFrame | ControlFrame,
    Field(discriminator="frame_type"),
]

_FRAME_ADAPTER = TypeAdapter(AgentLinkFrame)


def parse_agent_link_frame(raw: Mapping[str, Any]) -> AgentLinkFrame:
    return _FRAME_ADAPTER.validate_python(raw)
