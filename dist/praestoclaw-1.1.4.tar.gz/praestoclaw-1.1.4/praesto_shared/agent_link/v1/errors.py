from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import Field

from praesto_shared.agent_link.v1._base import AgentLinkModel


class AgentLinkErrorCode(StrEnum):
    INVALID_FRAME = "invalid_frame"
    UNSUPPORTED_SCHEMA = "unsupported_schema"
    UNAUTHORIZED = "unauthorized"
    ROUTE_NOT_FOUND = "route_not_found"
    DELIVERY_FAILED = "delivery_failed"
    BACKPRESSURE = "backpressure"
    INTERNAL_ERROR = "internal_error"


class AgentLinkErrorDetails(AgentLinkModel):
    code: AgentLinkErrorCode
    message: str
    retryable: bool = False
    details: dict[str, Any] = Field(default_factory=dict)
