"""Event-name constants. All emit() call sites must reference ``Events.XXX``.

A lint rule (added in a follow-up PR) will reject string literals in ``emit()``
to force every event through this registry — that way a new event always lands
in code review with the EVENTS.md update side-by-side.
"""

from __future__ import annotations


class Events:
    """Registered event names. Keep names lowercase_snake_case."""

    # === Gateway-side ===
    AGENT_CONNECTED = "agent_connected"
    AGENT_DISCONNECTED = "agent_disconnected"
    GATEWAY_REQUEST = "gateway_request"
    A2A_MESSAGE_DELIVERED = "a2a_message_delivered"  # Gateway perspective
    A2A_MESSAGE_FAILED = "a2a_message_failed"  # Gateway perspective

    # === Client-agent-side ===
    CLIENT_STARTUP = "client_startup"
    TOOL_INVOKED = "tool_invoked"
    TASK_COMPLETED = "task_completed"
    MCP_SERVER_CONNECTED = "mcp_server_connected"
    TOKEN_FETCHED = "token_fetched"
    AUTH_SUCCEEDED = "auth_succeeded"
    AUTH_FAILED = "auth_failed"

    # === Client A2A (sender side) ===
    A2A_MESSAGE_SENT = "a2a_message_sent"  # Outbound dispatch result from client
