"""App-type constants. Pin every ``init(..., app_type=AppType.XXX)`` to one of
these so dashboards can filter by app class without dealing with free-form
strings.
"""

from __future__ import annotations


class AppType:
    """Stable identifiers for the kind of Praesto app emitting telemetry."""

    CLIENT_AGENT = "client_agent"  # apps/client_agent (Python CLI / serve)
    CLIENT_GUI = "client_gui"  # apps/client_gui (Electron desktop)
    CLOUD_GATEWAY = "cloud_gateway"  # apps/cloud_gateway (Python relay on Azure)
    TEAMS_BOT = "teams_bot"  # apps/teams_bot (.NET Bot Framework)
    WEBSITE = "website"  # apps/website (static landing site)
