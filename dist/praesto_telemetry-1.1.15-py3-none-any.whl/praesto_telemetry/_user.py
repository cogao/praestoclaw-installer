"""Authenticated user id management.

The user id is a **caller-chosen stable opaque identifier** persisted at
``<data_dir>/telemetry/user_id`` so subsequent app launches report it
before the next login completes. The package does not prescribe the
value's encoding — each host app decides.

Examples of what hosts pass:

- ``client_agent`` (PraestoClaw CLI) sends ``SHA256(upn.lower())[:32]``.
  UPN is EUII; the hash is an opaque stable id. No salt — the same UPN
  produces the same id across Praesto apps so Gateway / Bot / Client
  events join cleanly on the standard ``user_AuthenticatedId`` column.
- A backend service that already has the AAD ``oid`` available from a
  trusted token claim (e.g. Societas backend) can send the raw oid
  directly — the oid is a GUID, opaque on its own, and
  ``user_AuthenticatedId`` is the App Insights schema's purpose-built
  slot for that value.

**Forbidden:** UPN / email / display name / any other EUII in plain
text — surface those through a one-way hash instead. The package's
``_filters`` redact obvious EUII shapes defensively but the contract
is on the caller.

Whatever value the caller passes is surfaced through OpenTelemetry's
``enduser.id`` semantic-convention attribute. The Azure Monitor
exporter maps that onto the App Insights ``ai.user.authUserId``
envelope tag, which Log Analytics exposes as ``user_AuthenticatedId``.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

logger = logging.getLogger(__name__)

_ENV_OVERRIDE = "PRAESTO_USER_ID"
_DEFAULT_DIR = Path.home() / ".praesto" / "telemetry"


def _user_id_path(data_dir: Path | None = None) -> Path:
    base = data_dir / "telemetry" if data_dir else _DEFAULT_DIR
    return base / "user_id"


def load_persisted_user_id(data_dir: Path | None = None) -> str | None:
    """Return the previously-persisted user id, or ``None`` if none recorded.

    ``PRAESTO_USER_ID`` env var takes precedence — useful for tests and ops.
    """
    if override := os.environ.get(_ENV_OVERRIDE):
        override = override.strip()
        if override:
            return override

    path = _user_id_path(data_dir)
    try:
        if path.exists():
            existing = path.read_text(encoding="utf-8").strip()
            if existing:
                return existing
    except OSError as exc:
        logger.warning("[telemetry] could not read user id (%s)", exc)
    return None


def persist_user_id(user_id: str, data_dir: Path | None = None) -> None:
    """Write ``user_id`` to disk so it survives across app restarts."""
    path = _user_id_path(data_dir)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(user_id, encoding="utf-8")
    except OSError as exc:
        logger.warning("[telemetry] could not persist user id (%s)", exc)


def clear_persisted_user_id(data_dir: Path | None = None) -> None:
    """Remove the persisted user id (call on logout / account switch)."""
    path = _user_id_path(data_dir)
    try:
        path.unlink(missing_ok=True)
    except OSError as exc:
        logger.warning("[telemetry] could not clear user id (%s)", exc)
