"""Application Insights client singleton.

Public surface is ``init`` / ``emit`` / ``flush`` / ``shutdown`` — see
``praesto_telemetry.__init__`` for the only imports business code should use.

Design notes:

- A single module-level :class:`_Client` instance keeps the SDK state, so apps
  can import ``emit`` anywhere without threading a context object around.
- ``emit`` is safe to call before ``init``: events are queued in memory and
  replayed once initialisation succeeds. This matters because the first events
  an app cares about (``CLIENT_STARTUP`` etc.) tend to fire during early
  bootstrap before logging is fully wired.
- Global properties (``appName``, ``appVersion``, ``deviceId``, …) are merged
  into every event so dashboards can filter by app without business code
  passing them every time.
- We never raise from ``emit`` / ``flush`` / ``shutdown`` — telemetry must
  never break the host app.
"""

from __future__ import annotations

import logging
import os
import platform
import threading
from pathlib import Path
from typing import Any

from ._connection import resolve_connection_string
from ._filters import sanitize
from ._identity import get_or_create_device_id, get_os_details
from ._user import clear_persisted_user_id, load_persisted_user_id, persist_user_id

logger = logging.getLogger(__name__)

# Max events buffered while waiting for init(). After this, oldest events are
# dropped — under normal startup the queue stays in the single digits, so a
# four-figure cap is generous and bounds memory if init() never runs.
_PENDING_QUEUE_MAX = 1024


class _Client:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._initialized = False
        self._disabled = False  # True after shutdown(); further emits are no-ops.
        self._tracer: Any = None
        self._global_props: dict[str, Any] = {}
        self._pending: list[tuple[str, dict[str, Any]]] = []
        self._data_dir: Path | None = None
        self._user_id: str | None = None

    # --- public API (called via module-level wrappers below) ----------------

    def init(
        self,
        app_name: str,
        app_version: str,
        app_type: str = "unknown",
        data_dir: Path | None = None,
    ) -> None:
        with self._lock:
            if self._initialized or self._disabled:
                return

            conn_str = resolve_connection_string()
            if not conn_str:
                # Disabled by env / CI / missing prod string. Still flip
                # ``_initialized`` so we stop queuing events forever.
                self._initialized = True
                self._drop_pending("telemetry disabled, dropping queued events")
                return

            try:
                # Imported lazily so unit tests can exercise queue / sanitiser
                # behaviour without the heavy SDK on the import path.
                from azure.monitor.opentelemetry import configure_azure_monitor
                from opentelemetry import trace

                # configure_azure_monitor reads service.name / service.version
                # from OTEL_* env vars at SDK init time; the resource_attributes
                # kwarg is unreliable across versions, so set the env directly.
                os.environ.setdefault("OTEL_SERVICE_NAME", app_name)
                os.environ.setdefault(
                    "OTEL_RESOURCE_ATTRIBUTES",
                    f"service.version={app_version}",
                )
                # Disable Azure Monitor's RateLimitedSampler — our event volume
                # is low and aggregated (DAU / counts), every drop is a loss.
                # AZURE_TRACES_SAMPLER_ARG=1.0 = sample 100% of spans.
                os.environ.setdefault("OTEL_TRACES_SAMPLER", "parentbased_always_on")
                configure_azure_monitor(
                    connection_string=conn_str,
                    disable_offline_storage=False,
                )
                self._tracer = trace.get_tracer("praesto.telemetry")
            except Exception as exc:  # pragma: no cover - SDK errors are environment-specific
                logger.warning("[telemetry] SDK init failed (%s); telemetry disabled", exc)
                self._initialized = True
                self._drop_pending("SDK init failed, dropping queued events")
                return

            os_info = get_os_details()
            self._data_dir = data_dir
            self._global_props = {
                "appName": app_name,
                "appType": app_type,
                "appVersion": app_version,
                "deviceId": get_or_create_device_id(data_dir),
                "os": os_info["os"],
                "osVersion": os_info["osVersion"],
                "platform": platform.system().lower(),
                "arch": platform.machine(),
            }
            # User id resolution:
            #   - if set_user_id() was called before init(), that pre-init
            #     value wins and gets persisted to the resolved data_dir;
            #   - otherwise load whatever was previously persisted on disk.
            if self._user_id:
                persist_user_id(self._user_id, data_dir)
            else:
                self._user_id = load_persisted_user_id(data_dir)
            self._initialized = True
            logger.info(
                "[telemetry] initialised (app=%s, type=%s, version=%s, user=%s)",
                app_name,
                app_type,
                app_version,
                "set" if self._user_id else "anonymous",
            )

            self._drain_pending()

    def emit(self, event_name: str, **properties: Any) -> None:
        if self._disabled:
            return

        with self._lock:
            if not self._initialized:
                if len(self._pending) >= _PENDING_QUEUE_MAX:
                    self._pending.pop(0)
                self._pending.append((event_name, properties))
                return
            if self._tracer is None:
                # init() ran but the SDK was disabled — nothing to do.
                return

        # Send outside the lock; OpenTelemetry's BatchSpanProcessor is
        # thread-safe and we don't want emit() callers blocking each other.
        self._send(event_name, properties)

    def flush(self, timeout_seconds: float = 5.0) -> None:
        if not self._initialized or self._tracer is None:
            return
        try:
            from opentelemetry import trace

            provider = trace.get_tracer_provider()
            force_flush = getattr(provider, "force_flush", None)
            if force_flush is not None:
                force_flush(int(timeout_seconds * 1000))
        except Exception as exc:  # pragma: no cover
            logger.warning("[telemetry] flush failed: %s", exc)

    def shutdown(self) -> None:
        self.flush()
        with self._lock:
            self._disabled = True
            self._pending.clear()

    def set_user_id(self, user_id: str | None) -> None:
        """Set (or clear) the authenticated user id for subsequent events.

        Pass a **caller-chosen stable opaque identifier** for the
        authenticated user. The package does not prescribe the value;
        ``client_agent`` for example sends ``SHA256(upn)[:32]`` so the same
        user produces the same id across Praesto apps. Do not pass raw UPN /
        email — those are EUII; pass a hashed or otherwise opaque id.

        The value is persisted under ``<data_dir>/telemetry/user_id`` so it
        survives restarts, then attached to every subsequent span via the
        OpenTelemetry ``enduser.id`` semantic-convention attribute. The
        Azure Monitor exporter maps ``enduser.id`` onto the App Insights
        ``ai.user.authUserId`` envelope tag, exposed as the
        ``user_AuthenticatedId`` column in Log Analytics — the standard
        Users / Retention / Funnel workbooks pick it up automatically.

        Pass ``None`` on logout to clear the persisted value; subsequent
        events emit anonymously again.

        Safe to call before :func:`init`: the value is buffered in memory
        until init runs, then takes precedence over any previously-persisted
        id and is itself persisted to the data dir resolved by init.
        """
        if user_id:
            user_id = user_id.strip() or None
        with self._lock:
            self._user_id = user_id
            if not self._initialized:
                # data_dir is not known yet — defer disk write to init(),
                # which will pick up self._user_id and persist it then.
                return
            data_dir = self._data_dir

        # Write outside the lock — disk I/O can be slow.
        if user_id:
            persist_user_id(user_id, data_dir)
        else:
            clear_persisted_user_id(data_dir)

    # --- internals ----------------------------------------------------------

    def _send(self, event_name: str, properties: dict[str, Any]) -> None:
        try:
            merged = sanitize({**self._global_props, **properties})
            with self._tracer.start_as_current_span(event_name) as span:
                for key, value in merged.items():
                    span.set_attribute(key, _coerce_attribute_value(value))
                # OpenTelemetry semantic convention: enduser.id → Azure
                # Monitor exporter maps to ai.user.authUserId envelope tag.
                if self._user_id:
                    span.set_attribute("enduser.id", self._user_id)
        except Exception as exc:  # pragma: no cover - never let telemetry break the host
            logger.warning("[telemetry] emit(%s) failed: %s", event_name, exc)

    def _drain_pending(self) -> None:
        if not self._pending or self._tracer is None:
            self._pending.clear()
            return
        # Snapshot under the lock (which the caller already holds) and send
        # outside so we don't block other emit() callers on the SDK.
        pending, self._pending = self._pending, []

        def _drain() -> None:
            for name, props in pending:
                self._send(name, props)

        # Fire-and-forget on a worker thread so init() returns quickly.
        threading.Thread(target=_drain, name="praesto-telemetry-drain", daemon=True).start()

    def _drop_pending(self, reason: str) -> None:
        if not self._pending:
            return
        logger.info("[telemetry] %s (dropped=%d)", reason, len(self._pending))
        self._pending.clear()


_singleton = _Client()


def _coerce_attribute_value(value: Any) -> Any:
    # OpenTelemetry attribute values must be primitives or sequences of
    # primitives; anything else gets stringified so dashboards don't break.
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (list, tuple)) and all(
        isinstance(v, (str, int, float, bool)) for v in value
    ):
        return list(value)
    return str(value)


def init(
    app_name: str,
    app_version: str,
    app_type: str = "unknown",
    data_dir: Path | None = None,
) -> None:
    """Initialise the SDK. Safe to call multiple times — subsequent calls no-op.

    ``app_type`` should be one of :class:`praesto_telemetry.AppType` so
    dashboards can filter / group consistently across apps.

    ``data_dir`` is the host app's data directory (e.g.
    ``Path("~/.praestoclaw").expanduser()``). When provided, telemetry state
    files (device id, user id) live under ``<data_dir>/telemetry/`` so each
    app's state sits next to its other state. Defaults to ``~/.praesto/``.
    """
    _singleton.init(app_name, app_version, app_type, data_dir)


def set_user_id(user_id: str | None) -> None:
    """Record the authenticated user (AAD ``oid``). Pass ``None`` to clear."""
    _singleton.set_user_id(user_id)


def emit(event_name: str, **properties: Any) -> None:
    """Emit a custom event. Safe to call before ``init`` (events are queued)."""
    _singleton.emit(event_name, **properties)


def flush(timeout_seconds: float = 5.0) -> None:
    """Block until pending events are sent, up to ``timeout_seconds``."""
    _singleton.flush(timeout_seconds)


def shutdown() -> None:
    """Flush and disable further emits. Idempotent; pair with ``atexit.register``."""
    _singleton.shutdown()


def _reset_for_tests() -> None:
    """Reset the singleton — tests only."""
    global _singleton
    _singleton = _Client()
