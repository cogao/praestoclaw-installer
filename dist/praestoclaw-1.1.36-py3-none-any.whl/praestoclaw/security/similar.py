"""Versioned, deterministic approval scopes; unrecognized calls stay exact.

The MCP registry uses exact adapter names (MCP_{server}_{raw_tool_name}),
not risk-policy regexes or server-provided descriptions. It is intentionally
partial. New operations and unfamiliar argument shapes need explicit review.
Shell parsing accepts a common literal subset, not general shell programs.
This is an approval matcher, not a replacement for executable trust or sandboxing.
"""

from __future__ import annotations

import configparser
import hashlib
import json
import os
import re
import shlex
import shutil
from pathlib import Path
from typing import Any, cast
from urllib.parse import parse_qsl, urlsplit

from praestoclaw.security.url_classify import has_credential_leak

SIMILAR_KEY = "__praesto_similar_v1__"

_FILE_READ_TYPES = {
    "read_file": {"path": str, "offset": int, "limit": int},
    "list_dir": {"path": str, "recursive": bool},
    "search_files": {
        "pattern": str,
        "path": str,
        "mode": str,
        "file_pattern": str,
        "max_results": int,
    },
}

_READ_FIELDS = {
    **{tool: set(fields) for tool, fields in _FILE_READ_TYPES.items()},
    "web_fetch": {"url", "selector", "max_chars"},
    "web_search": {"query", "count"},
}

_MCP_READS = frozenset(
    {
        "MCP_teams_ListChats",
        "MCP_teams_GetChat",
        "MCP_teams_ListChatMembers",
        "MCP_teams_ListTeams",
        "MCP_teams_ListChannels",
        "MCP_teams_GetChannel",
        "MCP_teams_ListChatMessages",
        "MCP_teams_ListChannelMessages",
        "MCP_teams_GetChatMessage",
        "MCP_teams_SearchTeamsMessages",
        "MCP_ado_ListPushes",
        "MCP_ado_wit_get_work_item",
        "MCP_ado_wit_get_work_items_batch",
        "MCP_ado_repo_get_pull_request_by_id",
        "MCP_ado_repo_list_pull_requests_by_repo_or_project",
        "MCP_sharepoint_getList",
        "MCP_sharepoint_getListItem",
        "MCP_sharepoint_listLists",
        "MCP_sharepoint_listListItems",
        "MCP_onedrive_getFileOrFolderMetadata",
        "MCP_onedrive_getFileOrFolderMetadataByUrl",
        "MCP_onedrive_findFileOrFolder",
        "MCP_onedrive_findSite",
        "MCP_onedrive_getDefaultDocumentLibraryInSite",
        "MCP_onedrive_getFolderChildren",
        "MCP_onedrive_listDocumentLibrariesInSite",
        "MCP_onedrive_readSmallTextFile",
        "MCP_onedrive_readSmallBinaryFile",
        "MCP_mail_GetMessage",
        "MCP_mail_SearchMessages",
        "MCP_calendar_ListCalendarView",
    }
)

_MCP_QUERY_FIELDS = frozenset(
    {
        "chatId",
        "chat_id",
        "conversationId",
        "teamId",
        "channelId",
        "messageId",
        "organization",
        "project",
        "repositoryId",
        "repoId",
        "workItemId",
        "id",
        "ids",
        "pullRequestId",
        "siteId",
        "driveId",
        "listId",
        "itemId",
        "folderId",
        "path",
        "url",
        "fileUrl",
        "siteUrl",
        "query",
        "search",
        "message",
        "filter",
        "select",
        "expand",
        "top",
        "skip",
        "limit",
        "maxResults",
        "pageSize",
        "fetchAllPages",
        "nextLink",
        "continuationToken",
        "startDateTime",
        "endDateTime",
        "fromDate",
        "toDate",
        "searchCriteria",
        "includeLinks",
        "includeWorkItemRefs",
        "asOf",
        "fields",
    }
)

_TEAMS_WRITES = {
    "MCP_teams_PostMessage": ("chatId",),
    "MCP_teams_SendMessageToChat": ("chatId",),
    "MCP_teams_UpdateChatMessage": ("chatId",),
    "MCP_teams_PostChannelMessage": ("teamId", "channelId"),
    "MCP_teams_ReplyToChannelMessage": ("teamId", "channelId"),
}


def _json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _fingerprint(value: Any) -> str:
    return hashlib.sha256(_json(value).encode("utf-8")).hexdigest()


def _directory(args: dict[str, Any], workspace: str | Path | None) -> str:
    base = Path(workspace or Path.cwd()).expanduser().resolve()
    directory = args.get("directory") or "."
    if not isinstance(directory, str):
        raise ValueError("Directory must be a string")
    if directory.strip().lower() == "workspace":
        directory = "."
    return os.path.normcase(str((base / Path(directory).expanduser()).resolve()))


def _tokens(command: Any, shell: str = "auto") -> list[str] | None:
    if not isinstance(command, str) or re.search(r"[;|&$`<>\r\n\\*?\[\]{}%!~^()\x00]", command):
        return None
    uses_cmd = shell == "cmd" or (shell == "auto" and os.name == "nt")
    if os.name == "nt" and shell == "bash" and not shutil.which("bash"):
        uses_cmd = True
    if (
        os.name == "nt"
        and shell == "powershell"
        and not (shutil.which("pwsh") or shutil.which("powershell"))
    ):
        uses_cmd = True
    if uses_cmd:
        if "'" in command:
            return None
    word = r"""(?:[A-Za-z0-9_./:@=,+-]+|(?:--[a-z-]+=)?"[^"\x00-\x1f]*"|(?:--[a-z-]+=)?'[^'\x00-\x1f]*')"""
    if not re.fullmatch(rf"\s*{word}(?:[ \t]+{word})*\s*", command):
        return None
    try:
        return shlex.split(command, posix=True)
    except ValueError:
        return None


def _options(
    tokens: list[str], switches: set[str], values: set[str]
) -> tuple[list[str], dict[str, str]] | None:
    positionals: list[str] = []
    options: dict[str, str] = {}
    index = 0
    while index < len(tokens):
        token = tokens[index]
        if token.startswith("-"):
            name, separator, value = token.partition("=")
            if name in switches and not separator:
                options[name] = ""
            elif name in values:
                if not separator:
                    index += 1
                    if index == len(tokens):
                        return None
                    value = tokens[index]
                if not value or value.startswith("-") or name in options:
                    return None
                options[name] = value
            else:
                return None
        else:
            if not token:
                return None
            positionals.append(token)
        index += 1
    return positionals, options


def _repo_name(value: str, host: str | None = None) -> str | None:
    if value.startswith("https://"):
        url = urlsplit(value)
        if url.username or url.password or url.query or url.fragment or url.port:
            return None
        value = f"{url.hostname}/{url.path.strip('/')}"
    parts = value.split("/")
    if len(parts) == 2:
        parts.insert(0, host or os.environ.get("GH_HOST") or "github.com")
    if len(parts) != 3 or any(
        not re.fullmatch(r"[A-Za-z0-9_.-]+", part) or part in {".", ".."} for part in parts
    ):
        return None
    return "/".join(parts).removesuffix(".git").lower()


def _git_repo(directory: str) -> tuple[Path, Path, configparser.RawConfigParser] | None:
    current = Path(directory).resolve()
    for root in (current, *current.parents):
        marker = root / ".git"
        if not marker.exists():
            continue
        gitdir = marker
        if marker.is_file():
            text = marker.read_text(encoding="utf-8").strip()
            if not text.startswith("gitdir: "):
                return None
            gitdir = (root / text[8:]).resolve()
        common = gitdir / "commondir"
        if common.is_file():
            gitdir = (gitdir / common.read_text(encoding="utf-8").strip()).resolve()
        config = configparser.RawConfigParser(strict=True, interpolation=None)
        config.read(gitdir / "config", encoding="utf-8")
        if any(
            section.strip().lower().startswith(("include", "url ", "url."))
            for section in config.sections()
        ):
            return None
        if config.has_option("core", "worktree") or config.has_option(
            "extensions", "worktreeconfig"
        ):
            return None
        return root, gitdir.resolve(), config
    return None


def _inherited_git_config_paths(*, read_scope: bool = False) -> list[Path]:
    home = Path(os.environ.get("HOME") or Path.home()) if read_scope else Path.home()
    xdg = os.environ.get("XDG_CONFIG_HOME", str(home / ".config"))
    if read_scope and not xdg:
        xdg = str(home / ".config")
    paths = [
        home / ".gitconfig",
        Path(xdg) / "git" / "config",
        Path("/etc/gitconfig").resolve() if read_scope else Path("/etc/gitconfig"),
    ]
    executable = shutil.which("git")
    if executable:
        for install in list(Path(executable).resolve().parents)[:3]:
            paths.extend([install / "etc" / "gitconfig", install / "mingw64" / "etc" / "gitconfig"])
            if read_scope:
                paths.append(install / "mingw32" / "etc" / "gitconfig")
    if os.name == "nt" and os.environ.get("PROGRAMDATA"):
        paths.append(Path(os.environ["PROGRAMDATA"]) / "Git" / "config")
    if read_scope and os.name == "nt" and not os.environ.get("HOME"):
        drive, homepath = os.environ.get("HOMEDRIVE"), os.environ.get("HOMEPATH")
        if drive and homepath:
            alternate_home = Path(drive + homepath)
            paths.append(alternate_home / ".gitconfig")
            if not os.environ.get("XDG_CONFIG_HOME"):
                paths.append(alternate_home / ".config" / "git" / "config")
    return paths


def _inherited_git_config_safe() -> bool:
    """Decline remote scoping when inherited config could rewrite a destination."""
    paths = _inherited_git_config_paths()
    for path in paths:
        config = configparser.RawConfigParser(strict=False, interpolation=None, allow_no_value=True)
        config.read(path, encoding="utf-8")
        if any(
            section.strip().lower().startswith(("include", "url ", "url.", "remote ", "remote."))
            for section in config.sections()
        ):
            return False
    return True


def _git_read_config_safe(path: Path, *, required: bool = False) -> bool:
    """Accept only an unambiguous, single-line subset of Git configuration.

    Callback key presence is unsafe even for false/empty values. ConfigParser
    alone is insufficient: Git sections are case-insensitive and its syntax
    differs (notably continuations, duplicate keys and implicit booleans).
    """
    try:
        text = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return not required and not path.is_symlink()
    if "\x00" in text:
        return False
    section = ""
    sections: set[str] = set()
    keys: set[str] = set()
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith(("#", ";")):
            continue
        header = re.fullmatch(r'\[([A-Za-z][A-Za-z0-9-]*)(?:\s+"[^"\\]+")?\]', line)
        if header:
            section = header[1].lower()
            normalized = line.lower()
            if normalized in sections or section in {"include", "includeif", "extensions", "url"}:
                return False
            sections.add(normalized)
            keys = set()
            continue
        option = re.fullmatch(r"([A-Za-z][A-Za-z0-9-]*)\s*=\s*(.*)", line)
        if not section or option is None or "\\" in line or '"' in option[2]:
            return False
        key = option[1].lower()
        if key in keys:
            return False
        keys.add(key)
        if (
            (section == "core" and key in {"fsmonitor", "pager", "worktree"})
            or (section == "diff" and key in {"external", "textconv", "command"})
            or (section == "filter" and key in {"clean", "smudge", "process"})
            or (section == "log" and key == "showsignature")
            or (section == "gpg" and key == "program")
            or section == "pager"
        ):
            return False
    return True


def _git_read_safe(directory: str) -> bool:
    """Recheck config on every proposal/match, without invoking Git.

    Indirection (gitfiles, linked worktrees, includes and bare discovery) stays
    exact. This gates broad READ grants, not execution or exact approvals; it
    cannot eliminate configuration races or establish executable trust.
    """
    if any(key.upper().startswith("GIT_") or key.upper() == "PAGER" for key in os.environ):
        return False
    if os.environ.get("HOME") == "" or (os.name == "nt" and not os.environ.get("PROGRAMDATA")):
        return False
    try:
        if any(
            os.environ.get(key) and not Path(os.environ[key]).is_absolute()
            for key in ("HOME", "XDG_CONFIG_HOME", "PROGRAMDATA")
        ):
            return False
        if not shutil.which("git"):
            return False
        paths = _inherited_git_config_paths(read_scope=True)
        if not all(path.is_absolute() and _git_read_config_safe(path) for path in paths):
            return False
        current = Path(directory).resolve()
        for root in (current, *current.parents):
            marker = root / ".git"
            try:
                marker.lstat()
            except FileNotFoundError:
                try:
                    (root / "HEAD").lstat()
                except FileNotFoundError:
                    continue
                return False
            if marker.is_symlink() or not marker.is_dir():
                return False
            for indirect in ("commondir", "config.worktree"):
                try:
                    (marker / indirect).lstat()
                except FileNotFoundError:
                    continue
                return False
            if not _git_read_config_safe(marker / "config", required=True):
                return False
            return _git_repo(directory) is not None
        return True
    except (OSError, ValueError, configparser.Error):
        return False


def _remote(
    repo: tuple[Path, Path, configparser.RawConfigParser], name: str, *, push: bool
) -> str | None:
    if not _inherited_git_config_safe():
        return None
    config = repo[2]
    section = f'remote "{name}"'
    if push and any(config.has_option(section, key) for key in ("mirror", "receivepack", "vcs")):
        return None
    key = "pushurl" if push and config.has_option(section, "pushurl") else "url"
    value = config.get(section, key, fallback="")
    if not value or "\n" in value:
        return None
    if value.startswith("git@"):
        matched = re.fullmatch(r"git@([A-Za-z0-9.-]+):([A-Za-z0-9_./-]+)", value)
        return _repo_name(f"{matched[1]}/{matched[2]}") if matched else None
    if value.startswith("ssh://git@"):
        url = urlsplit(value)
        if url.port or url.query or url.fragment:
            return None
        return _repo_name(f"{url.hostname}/{url.path.strip('/')}")
    return _repo_name(value) if value.startswith("https://") else None


def _git_scope(tokens: list[str], directory: str) -> dict[str, Any] | None:
    if not tokens:
        return None
    if tokens[0] == "--no-pager":
        tokens = tokens[1:]
    if len(tokens) > 2 and tokens[0] == "-C":
        directory = str((Path(directory) / tokens[1]).resolve())
        tokens = tokens[2:]
    if not tokens:
        return None
    action, tail = tokens[0], tokens[1:]
    read_switches = {
        "log": {
            "--oneline",
            "--stat",
            "--name-only",
            "--name-status",
            "--all",
            "--graph",
            "--reverse",
            "--no-merges",
            "--first-parent",
            "--no-decorate",
            "--decorate",
            "--no-ext-diff",
            "--no-textconv",
        },
        "status": {
            "--short",
            "-s",
            "--porcelain",
            "--branch",
            "-b",
            "--untracked-files",
            "--ignored",
        },
        "diff": {
            "--stat",
            "--name-only",
            "--name-status",
            "--cached",
            "--staged",
            "--shortstat",
            "--numstat",
            "--check",
            "--no-ext-diff",
            "--no-textconv",
        },
        "show": {
            "--oneline",
            "--stat",
            "--name-only",
            "--name-status",
            "--no-patch",
            "-s",
            "--no-ext-diff",
            "--no-textconv",
        },
    }
    if action in read_switches:
        tail = [
            "--max-count=" + token[1:] if re.fullmatch(r"-\d+", token) else token for token in tail
        ]
        values = (
            {
                "-n",
                "--max-count",
                "--since",
                "--until",
                "--author",
                "--grep",
                "--format",
                "--pretty",
            }
            if action in {"log", "show"}
            else set()
        )
        if "--" in tail:
            boundary = tail.index("--")
            paths = tail[boundary + 1 :]
            if any(
                not re.fullmatch(r"[A-Za-z0-9_./-]+", path) or path.startswith("-")
                for path in paths
            ):
                return None
            tail = tail[:boundary]
        parsed = _options(tail, read_switches[action], values)
        if parsed is None:
            return None
        positionals, options = parsed
        if any(not re.fullmatch(r"[A-Za-z0-9_./:@+-]+", value) for value in positionals):
            return None
        if any(
            not value.isdigit() for key, value in options.items() if key in {"-n", "--max-count"}
        ):
            return None
        if not _git_read_safe(directory):
            return None
        return {"kind": "read", "action": "git " + action}
    if action not in {"add", "commit", "push"} or any(
        key.startswith("GIT_CONFIG")
        or key
        in {
            "GIT_DIR",
            "GIT_WORK_TREE",
            "GIT_COMMON_DIR",
            "GIT_INDEX_FILE",
            "GIT_OBJECT_DIRECTORY",
            "GIT_ALTERNATE_OBJECT_DIRECTORIES",
            "GIT_CEILING_DIRECTORIES",
            "GIT_DISCOVERY_ACROSS_FILESYSTEM",
        }
        for key in os.environ
    ):
        return None
    repo = _git_repo(directory)
    if repo is None:
        return None
    if action == "push":
        parsed = _options(tail, {"--tags", "--dry-run", "--set-upstream", "-u"}, set())
        if parsed is None or not parsed[0]:
            return None
        positionals, options = parsed
        if any(not re.fullmatch(r"[A-Za-z0-9_./-]+", value) for value in positionals):
            return None
        target = _remote(repo, positionals[0], push=True)
        if target is None:
            return None
        return {
            "kind": "write",
            "action": "git push",
            "container": target,
            "local_repo": str(repo[1]),
            "options": options,
        }
    parsed = _options(
        tail,
        {"-a", "--all"} if action == "commit" else {"-A", "--all", "-u", "--update"},
        {"-m", "--message"} if action == "commit" else set(),
    )
    if parsed is None:
        return None
    if action == "commit" and not ({"-m", "--message"} & parsed[1].keys()):
        return None
    for path in parsed[0]:
        target_path = (Path(directory) / path).resolve()
        if not target_path.is_relative_to(repo[0]):
            return None
    return {
        "kind": "write",
        "action": "git " + action,
        "container": str(repo[1]),
        "options": sorted(key for key in parsed[1] if key not in {"-m", "--message"}),
    }


def _implicit_gh_repo(directory: str) -> str | None:
    if "GH_REPO" in os.environ or not _git_read_safe(directory):
        return None
    repo = _git_repo(directory)
    if repo is None:
        return None
    config = repo[2]
    remotes = [section for section in config.sections() if section.lower().startswith("remote ")]
    if remotes != ['remote "origin"']:
        return None
    if config.get(remotes[0], "gh-resolved", fallback="") not in {"", "base"}:
        return None
    target = _remote(repo, "origin", push=False)
    if not target or (
        os.environ.get("GH_HOST") and target.split("/")[0] != os.environ["GH_HOST"].lower()
    ):
        return None
    if config.has_option(remotes[0], "pushurl") and _remote(repo, "origin", push=True) != target:
        return None
    return target


def _gh_scope(tokens: list[str], directory: str) -> dict[str, Any] | None:
    repo_prefix: list[str] = []
    if tokens and tokens[0] in {"-R", "--repo"} and len(tokens) >= 2:
        repo_prefix, tokens = tokens[:2], tokens[2:]
    elif tokens and tokens[0].startswith(("-R=", "--repo=")):
        repo_prefix, tokens = tokens[:1], tokens[1:]
    if len(tokens) < 2 or tokens[0] not in {"issue", "pr"}:
        return None
    noun, action, *tail = tokens
    tail = [*repo_prefix, *tail]
    read = action in {"list", "view", "status"}
    if not read and action not in {"create", "edit"}:
        return None
    values = {"--repo", "-R"}
    switches: set[str] = set()
    if read:
        values |= {
            "--json",
            "--limit",
            "-L",
            "--state",
            "-s",
            "--search",
            "-S",
            "--label",
            "-l",
            "--author",
            "--assignee",
            "--base",
            "--head",
        }
        switches |= {"--comments", "-c"}
    else:
        values |= {"--title", "-t", "--body", "-b"}
        if action == "create":
            values |= {"--label", "-l", "--assignee", "-a", "--milestone", "-m"}
            if noun == "pr":
                values |= {"--reviewer", "-r"}
                switches |= {"--draft", "-d", "--no-maintainer-edit"}
        else:
            values |= {
                "--add-label",
                "--remove-label",
                "--add-assignee",
                "--remove-assignee",
                "--milestone",
                "-m",
            }
            switches |= {"--remove-milestone"}
            if noun == "pr":
                values |= {"--add-reviewer", "--remove-reviewer"}
        if noun == "pr":
            values |= {"--base", "--head"} if action == "create" else {"--base"}
    parsed = _options(tail, switches, values)
    if parsed is None:
        return None
    positionals, options = parsed
    if "--repo" in options and "-R" in options:
        return None
    if len(positionals) > (1 if action in {"view", "edit"} else 0):
        return None
    repo_value = options.get("--repo", options.get("-R", ""))
    repository = _repo_name(repo_value) if repo_value else None
    if repo_value and not repository:
        return None
    if positionals:
        target = positionals[0]
        if not target.isdigit():
            url = urlsplit(target)
            parts = url.path.strip("/").split("/")
            if (
                url.scheme != "https"
                or url.username
                or url.port
                or url.query
                or url.fragment
                or len(parts) != 4
                or parts[2] != ("issues" if noun == "issue" else "pull")
                or not parts[3].isdigit()
            ):
                return None
            repository = _repo_name(f"https://{url.netloc}/{parts[0]}/{parts[1]}")
    if action == "edit" and not positionals:
        return None
    if repository is None:
        if noun == "pr" and action == "create":
            return None
        repository = _implicit_gh_repo(directory)
        if repository is None:
            return None
    if read:
        return {"kind": "read", "action": f"gh {noun} {action}", "host": repository.split("/")[0]}
    if noun == "pr" and action == "create" and "--head" not in options:
        return None
    scope: dict[str, Any] = {
        "kind": "write",
        "action": f"gh {noun} {action}",
        "container": repository,
    }
    effects = sorted({"--draft" if key == "-d" else key for key in options if key in switches})
    if effects:
        scope["options"] = effects
    return scope


_LITERAL_READ_OPTIONS: dict[str, tuple[set[str], set[str]]] = {
    "rg": (
        {
            "-n",
            "--line-number",
            "-i",
            "--ignore-case",
            "-s",
            "--case-sensitive",
            "-F",
            "--fixed-strings",
            "-w",
            "--word-regexp",
            "-l",
            "--files-with-matches",
            "-c",
            "--count",
            "--files",
            "--hidden",
            "--no-ignore",
            "--no-heading",
            "--heading",
            "--no-config",
        },
        {
            "-e",
            "--regexp",
            "-g",
            "--glob",
            "-t",
            "--type",
            "--type-not",
            "-m",
            "--max-count",
            "-A",
            "--after-context",
            "-B",
            "--before-context",
            "-C",
            "--context",
            "--max-depth",
            "--color",
        },
    ),
    "grep": (
        {
            "-n",
            "--line-number",
            "-i",
            "--ignore-case",
            "-F",
            "--fixed-strings",
            "-E",
            "--extended-regexp",
            "-w",
            "--word-regexp",
            "-v",
            "--invert-match",
            "-l",
            "--files-with-matches",
            "-c",
            "--count",
            "-r",
            "--recursive",
            "-H",
            "--with-filename",
            "-h",
            "--no-filename",
        },
        {
            "-e",
            "--regexp",
            "-m",
            "--max-count",
            "-A",
            "--after-context",
            "-B",
            "--before-context",
            "-C",
            "--context",
        },
    ),
    "ls": (
        {
            "-l",
            "-a",
            "--all",
            "-A",
            "--almost-all",
            "-h",
            "--human-readable",
            "-R",
            "--recursive",
            "-d",
            "--directory",
            "-t",
            "-r",
            "-1",
        },
        set(),
    ),
    "cat": (
        {"-n", "--number", "-b", "--number-nonblank", "-s", "--squeeze-blank", "-A", "--show-all"},
        set(),
    ),
    "head": ({"-q", "--quiet", "-v", "--verbose"}, {"-n", "--lines", "-c", "--bytes"}),
    "tail": ({"-q", "--quiet", "-v", "--verbose"}, {"-n", "--lines", "-c", "--bytes"}),
    "wc": (
        {
            "-l",
            "--lines",
            "-w",
            "--words",
            "-c",
            "--bytes",
            "-m",
            "--chars",
            "-L",
            "--max-line-length",
        },
        set(),
    ),
}

_POWERSHELL_OPTIONS: dict[str, tuple[set[str], set[str], tuple[str, ...]]] = {
    "get-content": (
        {"-raw"},
        {"-path", "-literalpath", "-totalcount", "-tail", "-encoding"},
        ("-path",),
    ),
    "get-childitem": (
        {"-file", "-directory", "-recurse", "-force", "-name"},
        {"-path", "-literalpath", "-filter", "-depth"},
        ("-path",),
    ),
    "select-string": (
        {"-simplematch", "-casesensitive", "-list", "-quiet", "-notmatch", "-allmatches"},
        {"-path", "-literalpath", "-pattern", "-encoding"},
        ("-pattern", "-path"),
    ),
    "new-item": (set(), {"-path", "-itemtype", "-value"}, ("-path",)),
    "set-content": (
        {"-nonewline"},
        {"-path", "-literalpath", "-value", "-encoding"},
        ("-path", "-value"),
    ),
    "add-content": (
        {"-nonewline"},
        {"-path", "-literalpath", "-value", "-encoding"},
        ("-path", "-value"),
    ),
    "copy-item": (set(), {"-path", "-literalpath", "-destination"}, ("-path", "-destination")),
    "move-item": (set(), {"-path", "-literalpath", "-destination"}, ("-path", "-destination")),
}


def _powershell_options(action: str, tail: list[str]) -> dict[str, str] | None:
    if any("," in token or token.startswith("@") for token in tail):
        return None
    switches, values, positional_names = _POWERSHELL_OPTIONS[action]
    parsed = _options(
        [token.lower() if token.startswith("-") else token for token in tail], switches, values
    )
    if parsed is None:
        return None
    positionals, options = parsed
    if "-path" in options and "-literalpath" in options:
        return None
    if "-literalpath" in options:
        options["-path"] = options.pop("-literalpath")
    if len(positionals) > len(positional_names):
        return None
    for name, value in zip(positional_names, positionals):
        if name in options:
            return None
        options[name] = value
    return options


def _literal_path(value: str, directory: str) -> Path | None:
    if not value or not re.fullmatch(r"(?:[A-Za-z]:/)?[A-Za-z0-9_./ -]+", value):
        return None
    if value.startswith(("-", "//")):
        return None
    if (os.name == "nt" and value.startswith("/")) or (os.name != "nt" and ":" in value):
        return None
    path = Path(directory) / value
    is_reserved = getattr(os.path, "isreserved", None)
    if os.name == "nt" and any(
        is_reserved(part) if is_reserved else Path(part).is_reserved() for part in path.parts
    ):
        return None
    if any(
        part.is_symlink() or (hasattr(part, "is_junction") and part.is_junction())
        for part in (path, *path.parents)
    ):
        return None
    return path.resolve()


def _literal_write_scope(
    action: str, source: str | None, destination: str, directory: str, options: dict[str, str]
) -> dict[str, Any] | None:
    target = _literal_path(destination, directory)
    if target is None:
        return None
    origin = _literal_path(source, directory) if source is not None else None
    if source is not None:
        if origin is None or (origin.exists() and not origin.is_file()):
            return None
        if target.is_dir():
            target = _literal_path((Path(destination) / origin.name).as_posix(), directory)
            if target is None:
                return None
    if target.exists() and not target.is_file():
        if action != "mkdir" and not (
            action == "new-item" and options.get("-itemtype") == "directory"
        ):
            return None
    if target.is_file() and target.stat().st_nlink > 1:
        return None
    scope: dict[str, Any] = {
        "kind": "write",
        "action": action,
        "container": _file_container(target),
    }
    if action in {"mv", "move-item"} and origin is not None:
        scope["source_container"] = _file_container(origin)
    if options:
        scope["options"] = options
    return scope


def _literal_command_scope(tokens: list[str], directory: str, shell: str) -> dict[str, Any] | None:
    action, *tail = tokens
    if action.lower() in _POWERSHELL_OPTIONS:
        if shell != "powershell" or not (shutil.which("pwsh") or shutil.which("powershell")):
            return None
        action = action.lower()
        options = _powershell_options(action, tail)
        if options is None:
            return None
        path = options.pop("-path", "." if action == "get-childitem" else "")
        if _literal_path(path, directory) is None:
            return None
        if action in {"get-content", "get-childitem", "select-string"}:
            if action == "select-string" and "-pattern" not in options:
                return None
            return {"kind": "read", "action": action}
        if action in {"set-content", "add-content"}:
            if "-value" not in options:
                return None
            options.pop("-value")
        elif action == "new-item":
            itemtype = options.get("-itemtype", "").lower()
            if itemtype not in {"file", "directory"} or (
                itemtype == "directory" and "-value" in options
            ):
                return None
            options["-itemtype"] = itemtype
            options.pop("-value", None)
        else:
            destination = options.pop("-destination", "")
            return _literal_write_scope(action, path, destination, directory, options)
        return _literal_write_scope(action, None, path, directory, options)
    if shell == "powershell":
        return None
    if action in _LITERAL_READ_OPTIONS:
        if action == "rg" and os.environ.get("RIPGREP_CONFIG_PATH"):
            return None
        if action == "grep" and os.environ.get("GREP_OPTIONS"):
            return None
        parsed = _options(tail, *_LITERAL_READ_OPTIONS[action])
        return {"kind": "read", "action": action} if parsed is not None else None
    if action not in {"cp", "mv", "mkdir"}:
        return None
    parsed = _options(tail, {"-v", "--verbose"} if action != "mkdir" else set(), set())
    if parsed is None or len(parsed[0]) != (1 if action == "mkdir" else 2):
        return None
    paths = parsed[0]
    return _literal_write_scope(
        action, paths[0] if action != "mkdir" else None, paths[-1], directory, {}
    )


def _command_scope(tokens: list[str], directory: str, shell: str = "auto") -> dict[str, Any] | None:
    if any(key in {"BASH_ENV", "ENV"} or key.startswith("BASH_FUNC_") for key in os.environ):
        return None
    if any(
        (Path(directory) / (tokens[0] + suffix)).exists()
        for suffix in ("", ".exe", ".cmd", ".bat", ".com", ".ps1")
    ):
        return None
    if tokens[0] == "git":
        scope = _git_scope(tokens[1:], directory)
    elif tokens[0] == "gh":
        scope = _gh_scope(tokens[1:], directory)
    else:
        scope = _literal_command_scope(tokens, directory, shell)
    if scope:
        scope["executable"] = (
            shutil.which("pwsh") or shutil.which("powershell")
            if tokens[0].lower() in _POWERSHELL_OPTIONS
            else shutil.which(tokens[0])
        )
    return scope


def _has_credential_query(query: str) -> bool:
    return any(
        re.sub(r"[^a-z]", "", key.lower())
        in {
            "token",
            "accesstoken",
            "refreshtoken",
            "idtoken",
            "apikey",
            "key",
            "secret",
            "clientsecret",
            "password",
            "authorization",
            "auth",
            "signature",
            "sig",
            "xamzsignature",
            "xamzcredential",
            "xamzsecuritytoken",
            "xgoogsignature",
            "xgoogcredential",
        }
        for key, _ in parse_qsl(query, keep_blank_values=True)
    )


def _http_scope(args: dict[str, Any]) -> dict[str, Any] | None:
    if set(args) - {"url", "method", "headers", "body"} or not isinstance(args.get("url"), str):
        return None
    url = urlsplit(args["url"])
    if (
        url.scheme not in {"http", "https"}
        or not url.hostname
        or url.username
        or url.password
        or url.fragment
    ):
        return None
    method = args.get("method", "GET")
    headers = args.get("headers", {})
    if not isinstance(method, str) or not isinstance(headers, dict):
        return None
    if any(
        not isinstance(key, str) or not isinstance(value, str) for key, value in headers.items()
    ):
        return None
    safe_headers = {
        "accept",
        "accept-language",
        "authorization",
        "user-agent",
        "content-type",
        "if-none-match",
        "if-modified-since",
    }
    if any(key.lower() not in safe_headers for key in headers):
        return None
    if any(
        re.sub(r"[^a-z]", "", key.lower())
        in {
            "method",
            "httpmethod",
            "methodoverride",
            "httpmethodoverride",
            "xhttpmethodoverride",
            "xmethodoverride",
        }
        for key, _ in parse_qsl(url.query)
    ):
        return None
    method = method.upper()
    if method in {"GET", "HEAD"}:
        if any(key.lower() == "authorization" for key in headers):
            return None
        if _has_credential_query(url.query):
            return None
        return (
            {"kind": "read", "action": "HTTP " + method} if args.get("body") in (None, "") else None
        )
    if method not in {"POST", "PUT", "PATCH", "DELETE"}:
        return None
    origin = f"{url.scheme}://{url.hostname}:{url.port or (443 if url.scheme == 'https' else 80)}"
    return {
        "kind": "write",
        "action": "HTTP " + method,
        "container": origin + (url.path or "/"),
        "query_sha256": _fingerprint(url.query),
        "headers_sha256": _fingerprint(headers),
    }


def _file_scope(
    tool: str, args: dict[str, Any], workspace: str | Path | None
) -> dict[str, Any] | None:
    fields = (
        {"path", "content"}
        if tool == "write_file"
        else {"path", "old_string", "new_string", "replace_all"}
    )
    if set(args) - fields or not isinstance(args.get("path"), str) or not args["path"]:
        return None
    path = (Path(_directory({}, workspace)) / Path(args["path"]).expanduser()).resolve()
    return {"kind": "write", "action": tool, "container": _file_container(path)}


def _file_container(path: Path) -> str:
    root = path.parent
    for parent in (root, *root.parents):
        if (parent / ".git").exists() or any(
            (parent / marker).is_file()
            for marker in ("pyproject.toml", "package.json", "Cargo.toml", "go.mod")
        ):
            root = parent
            break
    return os.path.normcase(str(root))


def _mcp_scope(tool: str, args: dict[str, Any]) -> dict[str, Any] | None:
    if tool in _MCP_READS and set(args) <= _MCP_QUERY_FIELDS:
        return {"kind": "read", "action": tool}
    keys = _TEAMS_WRITES.get(tool)
    if tool == "MCP_teams_PostMessage":
        targets = [key for key in ("chatId", "conversationId") if key in args]
        keys = tuple(targets) if len(targets) == 1 else None
    if keys and all(isinstance(args.get(key), str) and args[key] for key in keys):
        allowed = {
            *keys,
            "messageId",
            "replyToId",
            "content",
            "contentType",
            "message",
            "body",
            "text",
            "subject",
            "requestId",
        }
        if set(args) <= allowed:
            return {
                "kind": "write",
                "action": tool,
                "container": _json({key: args[key] for key in keys}),
            }
    return None


def _descriptor(tool: str, args: dict[str, Any], workspace: str | Path | None) -> dict[str, Any]:
    if SIMILAR_KEY in args:
        raise ValueError("Reserved similar-rule key is not a tool argument")
    if tool in _READ_FIELDS and set(args) <= _READ_FIELDS[tool]:
        required = {
            "web_fetch": "url",
            "read_file": "path",
            "search_files": "pattern",
            "web_search": "query",
        }.get(tool)
        if required and not isinstance(args.get(required), str):
            return {"kind": "exact", "args": args}
        if tool == "web_fetch":
            url = urlsplit(args["url"])
            if (
                url.scheme not in {"http", "https"}
                or not url.hostname
                or url.port == 0
                or url.username is not None
                or url.password is not None
                or _has_credential_query(url.query)
            ):
                return {"kind": "exact", "args": args}
        if tool == "web_search" and has_credential_leak(args["query"]):
            return {"kind": "exact", "args": args}
        if tool in _FILE_READ_TYPES:
            if any(type(value) is not _FILE_READ_TYPES[tool][key] for key, value in args.items()):
                return {"kind": "exact", "args": args}
            if tool == "search_files" and args.get("mode", "content") not in {"content", "name"}:
                return {"kind": "exact", "args": args}
        return {"kind": "read", "action": tool}
    if tool == "http_request":
        scope = _http_scope(args)
        if scope:
            return scope
    if tool in {"write_file", "edit_file"}:
        scope = _file_scope(tool, args, workspace)
        if scope:
            return scope
    scope = _mcp_scope(tool, args)
    if scope:
        return scope
    if tool == "git" and set(args) == {"args"}:
        tokens = _tokens(args["args"])
        if tokens and tokens == args["args"].split():
            scope = _git_scope(tokens, _directory({}, workspace))
            if scope:
                return {**scope, "executable": shutil.which("git")}
    if (
        tool == "shell"
        and set(args) <= {"command", "directory", "shell", "timeout"}
        and args.get("shell", "auto") in {"auto", "bash", "cmd", "powershell"}
    ):
        tokens = _tokens(args.get("command"), args.get("shell", "auto"))
        scope = (
            _command_scope(tokens, _directory(args, workspace), args.get("shell", "auto"))
            if tokens
            else None
        )
        if scope:
            return {**scope, "shell": args.get("shell", "auto")}
    exact: dict[str, Any] = {"kind": "exact", "args": args}
    if tool in {"shell", "git", "write_file", "edit_file"}:
        exact["directory"] = _directory(args, workspace)
    return exact


def propose_similar(
    tool: str, args: dict[str, Any], workspace: str | Path | None = None
) -> dict[str, Any]:
    """Return a JSON-safe snapshot: ``tool``, persisted ``match``, and ``scope``."""
    if SIMILAR_KEY in args:
        raise ValueError("Reserved similar-rule key is not a tool argument")
    try:
        descriptor = {"version": 1, "tool": tool, **_descriptor(tool, args, workspace)}
    except (OSError, ValueError, TypeError, RuntimeError, configparser.Error):
        descriptor = {"version": 1, "tool": tool, "kind": "exact", "args": args}
        if tool in {"shell", "git", "write_file", "edit_file"}:
            descriptor["directory"] = _directory({}, workspace)
    kind = descriptor["kind"]
    if kind == "exact":
        descriptor["args_sha256"] = _fingerprint(descriptor.pop("args"))
    if kind == "read":
        scope = f"Read/query: {descriptor['action']} across targets"
        if "host" in descriptor:
            scope += f" on {descriptor['host']}"
    elif kind == "write":
        scope = f"{descriptor['action']} in {descriptor['container']}"
        if tool == "http_request":
            scope += " (same path, query, and headers)"
        if "local_repo" in descriptor:
            scope += f" from {descriptor['local_repo']}"
        if "source_container" in descriptor:
            scope += f" (source container: {descriptor['source_container']})"
        if descriptor.get("options"):
            options = descriptor["options"]
            labels = (
                [f"{name}={value}" if value else name for name, value in options.items()]
                if isinstance(options, dict)
                else options
            )
            scope += " (fixed options: " + ", ".join(labels) + ")"
    else:
        scope = "Exact arguments only"
        if "directory" in descriptor:
            scope += f" in {descriptor['directory']}"
    return {"tool": tool, "match": {SIMILAR_KEY: _json(descriptor)}, "scope": scope}


def similar_scope(tool: str, args: dict[str, Any], workspace: str | Path | None = None) -> str:
    """Describe exactly the scope proposed for a call."""
    return cast(str, propose_similar(tool, args, workspace)["scope"])


def matches_similar(
    match: dict[str, str], tool: str, args: dict[str, Any], workspace: str | Path | None = None
) -> bool:
    if set(match) != {SIMILAR_KEY} or SIMILAR_KEY in args:
        return False
    try:
        proposed = propose_similar(tool, args, workspace)
        return match[SIMILAR_KEY] == cast(str, proposed["match"][SIMILAR_KEY])
    except (TypeError, ValueError, OSError, RuntimeError):
        return False
