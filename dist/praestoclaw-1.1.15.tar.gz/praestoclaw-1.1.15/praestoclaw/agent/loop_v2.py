"""AgentLoopV2 — Hermes-style run_conversation agent loop.

Replaces the nanobot-derived v1 loop with Hermes-style iteration budget,
multi-pass compression, intelligent parallel tool execution, and
provider failover — while preserving v1's hooks, approval routing,
slash commands, typing indicators, and audit logging.
"""

from __future__ import annotations

import asyncio
import json
import re
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from loguru import logger

from praestoclaw.agent.attachments.preprocessor import AttachmentResolver as _AttachmentResolver
from praestoclaw.agent.attachments.preprocessor import (
    has_pending_attachments as _has_pending_attachments,
)
from praestoclaw.agent.budget import IterationBudget
from praestoclaw.agent.compaction import (
    estimate_tokens,
    is_injected_runtime_context,
    strip_injected_context,
)
from praestoclaw.agent.compressor import ContextCompressor
from praestoclaw.agent.loop_detect import LoopDetector
from praestoclaw.agent.parallel import ToolParallelizer
from praestoclaw.agent.prompt_builder import PromptBuilder
from praestoclaw.agent.prompt_cache import apply_cache_breakpoints
from praestoclaw.agent.task_planning_preflight import (
    TaskPlanningPreflight,
    insert_task_planning_preflight_context,
    render_task_planning_preflight_context,
    run_task_planning_preflight,
    should_run_task_planning_preflight,
)
from praestoclaw.agent.tool_sanitizer import (
    is_provider_safe_tool_name,
    sanitize_tool_messages,
)
from praestoclaw.agent.truncation import truncate_tool_output
from praestoclaw.bus.events import EventType, InboundMessage
from praestoclaw.bus.queue import MessageBus
from praestoclaw.channels.reply_dispatcher import ReplyDispatcher
from praestoclaw.config.schema import AgentConfig, ChannelType, ExecutionConfig
from praestoclaw.hooks.manager import (
    HookVerdict,
    MessageHookContext,
    PostToolHookContext,
    PreToolHookContext,
)
from praestoclaw.host.execution_chains import (
    ExecutionChainCancelledError,
    ExecutionChainQueueFullError,
    ExecutionChainRunner,
    ExecutionChainStoppedError,
    ExecutionLane,
)
from praestoclaw.host.resource_locks import tool_resource_lock
from praestoclaw.providers.base import LLMProvider, LLMResponse, ToolCallRequest
from praestoclaw.providers.failover import CompressNeededError
from praestoclaw.security.leak import redact_credentials
from praestoclaw.security.sanitizer import Sanitizer
from praestoclaw.utils.helpers import (
    REPLY_QUOTE_SNIPPET_MAX,
    contains_cjk,
    truncate_ellipsis,
)

if TYPE_CHECKING:
    from praestoclaw.host.background_tasks import BackgroundTaskManager, BackgroundTaskSnapshot
    from praestoclaw.security.allowlist import AllowlistManager
    from praestoclaw.security.approval import ApprovalManager
    from praestoclaw.security.audit import AuditLogger

_DEFAULT_CONTEXT_LIMIT = 128_000
_SYSTEM_LANE_SOURCES: frozenset[str] = frozenset(
    {"a2a", "a2a_notify", "a2a_task", "cron", "heartbeat", "scheduler", "u2u_receipt"}
)
# Exact phrases (after strip/lower/trailing-punctuation) that count as a
# "how's it going?" status check. Matched exactly — NOT as substrings — so a
# real question like "天气怎么样" is never swallowed. Only consulted while a turn
# is already running on the session lane.
_STATUS_QUERY_PHRASES: frozenset[str] = frozenset(
    {
        # zh
        "进度",
        "进度呢",
        "进度如何",
        "进度怎么样",
        "进展如何",
        "有进展吗",
        "有进度吗",
        "怎么样了",
        "怎样了",
        "好了吗",
        "好了没",
        "完成了吗",
        "完成了没",
        "跑完了吗",
        "还在吗",
        "还在跑吗",
        "到哪了",
        "到哪步了",
        "查到没",
        "查到了吗",
        # en
        "status",
        "progress",
        "any update",
        "any progress",
        "any news",
        "done yet",
        "are you done",
        "how's it going",
        "how is it going",
        "still there",
    }
)
_EMPTY_FINAL_RESPONSE_PROMPT = (
    "Your previous response contained no user-visible content. Do not end the turn "
    "silently. Continue the task if work remains; otherwise provide a concise final "
    "status for the user."
)
_EMPTY_FINAL_RESPONSE_FALLBACK = (
    "I couldn't produce a final response before this turn ended. The task may be "
    "incomplete; please ask me to continue if you want me to keep working."
)
# Sentinel returned from ``_drive_turn`` when the turn was promoted to a
# detached worker session. The caller surfaces it as the carrier-visible
# receipt: a placeholder string is emitted into the channel reply path (see
# ``_render_promoted_receipt`` below), but the row is NEVER persisted into
# the main session (D-receipt — the eventual fold-back is the sole assistant
# answer to the user's question in durable history).
_PROMOTED_RECEIPT = "__event_loop_promoted__"
# Receipt copy delivered to the carrier when a turn is promoted to a worker.
# UX contract (matches the IM mental model):
#   1. Make the handoff explicit — "moved to background", not "still working".
#      The latter sounds like the assistant is locked up; the former tells the
#      user the work is queued and they're free to do anything.
#   2. Invite continued chat — say "we can chat about anything else". Without
#      this, users default to "代理在忙，先别打扰" and stop using the channel
#      until they see a fold-back.
#   3. Promise proactive delivery — "I'll send the result here when it's done".
# The text is **not** persisted to durable history (D-receipt). The
# orphan-prevention ack row (``[BG task=…]``, see
# ``_PROMOTION_ACK_TEMPLATE_*`` below) is a separate, machine-readable line
# for the LLM; this string is for the human reading the chat window.
_PROMOTED_RECEIPT_ZH = "📥 这个任务我放到后台跑了，结果会发到这里来。我们可以接着聊别的，不耽误你。"
_PROMOTED_RECEIPT_EN = (
    "📥 Got it — I've moved this to the background. I'll post the result here "
    "when it's done; feel free to keep chatting about anything else in the meantime."
)
# Terse one-liner used when ``ExecutionConfig.background_task_receipt ==
# "minimal"`` — enough to signal the handoff to power users who already know
# the pattern, without the full educational copy on every promotion.
_PROMOTED_RECEIPT_MINIMAL_ZH = "⏳ 后台处理中…"
_PROMOTED_RECEIPT_MINIMAL_EN = "⏳ Working on it in the background…"
# Adaptive ramp (``background_task_receipt == "adaptive"``, the no-explicit-
# config default): the first ``_ADAPTIVE_FULL_LIMIT`` promotions a user sees
# render the full educational copy; the next batch up to
# ``_ADAPTIVE_MINIMAL_LIMIT`` (cumulative) render the minimal one-liner; every
# promotion after that is silent. The per-user count is durable (SessionStore
# ``counters`` table) so the ramp survives restarts.
_ADAPTIVE_FULL_LIMIT = 3
_ADAPTIVE_MINIMAL_LIMIT = 6

# ── Promotion ack-row sentinel (Plan A: orphan-prevention) ───────────────────
# When ``_promote_turn_to_worker`` finishes prune+adopt it appends ONE
# ``role=assistant`` row to the main session whose content begins with this
# sentinel. The sentinel is a stable, machine-readable marker meaning
# "this user request was handed off to a background worker — do not continue
# it on the next turn". The line is read by:
#   • the LLM (via system-prompt rule in defaults/AGENTS.md) — orphan-prevention
#   • the compactor (``_persist_compacted``) — preserves task=… reference
#   • a future startup reaper — finds active acks whose tasks died at restart
# Format: ``[BG task=<task_id>] <localized one-line ack>\n[Q] <snippet>``
# The sentinel itself MUST stay literal so a simple ``startswith`` (and the
# regex ``\[BG task=([0-9a-f]{6,})\]``) can identify the row anywhere it is
# read — durable history, in-memory prompt, compaction summary input.
_PROMOTION_ACK_SENTINEL_PREFIX = "[BG task="
_PROMOTION_ACK_TEMPLATE_ZH = (
    "{sentinel}{task_id}] 已收到，正在后台处理；完成后会自动以 ↩️ 形式回到这里。\n[Q] {snippet}"
)
_PROMOTION_ACK_TEMPLATE_EN = (
    "{sentinel}{task_id}] Acknowledged — handed off to a background worker; "
    "I'll post the answer back here as a ↩️ quote when it finishes.\n[Q] {snippet}"
)


# Inverse of ``_build_promotion_ack_row``: extract ``(task_id, question_snippet)``
# from a persisted ack row's content. Used by the startup reaper
# (``BackgroundTaskManager.reap_orphan_acks``) to recover the bookkeeping it
# needs to write a ``(failed: lost-on-restart) [Re: …]`` replacement when a
# worker died with the previous process. The pattern matches both zh and en
# templates because everything between ``[BG task=…]`` and ``\n[Q] …`` is
# fixed copy that we can match non-greedily.
_PROMOTION_ACK_PARSE_RE = re.compile(
    r"^\[BG task=([0-9a-f]+)\][^\n]*\n\[Q\] (.*)$",
    re.DOTALL,
)


def _emit_tool_invoked(
    tool_name: str,
    duration_ms: int,
    success: bool,
    blocked_by: str | None = None,
    turn_id: str | None = None,
    session_id: str | None = None,
) -> None:
    """Fire-and-forget telemetry. Defensive — never raises into the agent loop."""
    try:
        from praesto_telemetry import Events, emit

        props: dict[str, object] = {
            "tool_name": tool_name,
            "duration_ms": duration_ms,
            "success": success,
        }
        if blocked_by:
            props["blocked_by"] = blocked_by
        if turn_id:
            props["turn_id"] = turn_id
        if session_id:
            props["session_id"] = session_id
        emit(Events.TOOL_INVOKED, **props)
    except Exception:  # pragma: no cover - telemetry must never break the host
        pass


def _is_tool_error_result(result: str | None) -> bool:
    """Return True for both direct tool errors and registry-wrapped failures."""
    return isinstance(result, str) and result.startswith(("Error:", "Error executing "))


def parse_promotion_ack(content: str) -> tuple[str, str] | None:
    """Parse a persisted ack row's ``content`` into ``(task_id, snippet)``.

    Returns ``None`` if *content* is not a well-formed ack row (does not
    begin with the sentinel, missing the ``[Q] …`` tail, or task_id contains
    non-hex). Designed to be defensive: a malformed row in the wild should
    be skipped, not raise.
    """
    if not isinstance(content, str) or not content.startswith(_PROMOTION_ACK_SENTINEL_PREFIX):
        return None
    match = _PROMOTION_ACK_PARSE_RE.match(content)
    if match is None:
        return None
    return match.group(1), match.group(2)


@dataclass(frozen=True)
class OwnerSessionTarget:
    """Pointer to the owner's most recent human, interactive session.

    Captured on every human MAIN-lane turn so receiver-side a2a handling can
    persist an informational context note into the session the owner is
    actually sitting in (e.g. their Teams chat), enabling a later human
    confirmation to be understood and relayed back to the remote sender.
    """

    session_key: str
    channel: str
    sender_id: str
    # Normalized user-facing surface (e.g. "teams", "cloud_tui", "webchat").
    # Lets receiver-side a2a inject context into the SAME surface the owner's
    # heads-up notification targets, rather than whichever surface the owner
    # happened to type in most recently across all of them.
    surface: str = ""


@dataclass
class _TurnState:
    """Mutable per-turn state shared between ``_begin_turn`` and ``_drive_turn``.

    The event-loop refactor (see ``docs/design/core/event-loop/02-architecture.md``
    §2.2) splits the legacy monolithic ``_run_conversation_impl`` into a setup
    phase (``_begin_turn``) and a re-entrant loop phase (``_drive_turn``). They
    share *everything* the loop needs through this object, so ``_drive_turn``
    can be re-entered against any ``session_id`` (the future promotion path
    swaps ``state.session_id`` to a worker session) without re-plumbing every
    callsite.

    ``turn_rowids`` accumulates the rowid of every assistant / tool message
    persisted **inside** the loop body. The user row is captured separately as
    ``user_rowid`` because it is already written by ``_begin_turn`` and the
    promotion step keeps the user row on the main session while pruning only
    the in-flight tool pairs.
    """

    messages: list[dict[str, Any]]
    session_id: str
    # Canonical session that owns the visible plan card. Promotion swaps
    # ``session_id`` to a worker, but plan updates must keep targeting the
    # originating conversation's plan so the Teams card updates in place.
    plan_session_id: str
    budget: IterationBudget
    loop_detector: LoopDetector
    tool_batches: int = 0
    turn_rowids: list[int] = field(default_factory=list)
    user_rowid: int | None = None
    channel: Any = None
    channel_id: str | None = None
    thread_id: str | None = None
    route_hint: str | None = None
    user_message: str = ""
    metadata: dict[str, Any] | None = None
    exclude_tools: list[str] | None = None
    streamed: bool = False
    # Set by the future promotion step (D) so a re-entered ``_drive_turn``
    # against a worker session does not promote again. Safe to default off.
    promoted: bool = False
    # Carrier-visible receipt resolved at promotion time (before the worker is
    # adopted) so the only awaits on the promotion path happen pre-adopt — this
    # keeps ``_run_conversation``'s return synchronous w.r.t. worker scheduling.
    # Empty for non-promoted turns and for ``silent`` mode.
    promoted_receipt: str = ""
    # Monotonic wall-clock when ``_begin_turn`` finished assembling this state.
    # Read by the event-loop ``T-time`` trigger ("promote after N seconds of
    # elapsed turn time"). ``time.monotonic`` because it never goes backwards
    # under NTP / DST adjustments. ``None`` for legacy paths that never set it.
    started_monotonic: float | None = None


class AgentLoopV2:
    """Hermes-style agent loop with streaming, parallel tools, and loop detection.

    Supports all v1 capabilities: hooks, approval routing, slash commands,
    typing indicators, audit logging.
    """

    def __init__(
        self,
        *,
        config: AgentConfig,
        provider: LLMProvider,
        tool_registry: Any,
        bus: MessageBus,
        session_store: Any,
        workspace: Path,
        audit: Any = None,
        hooks: Any = None,
        available_agents: dict[str, Any] | None = None,
        prompt_mode: Literal["full", "subagent", "minimal"] = "full",
        skill_loader: Any = None,
        skills_config: Any = None,
        approval_manager: ApprovalManager | None = None,
        allowlist: AllowlistManager | None = None,
        mcp_configs: Any = None,
        memory: Any = None,
        execution_runner: ExecutionChainRunner | None = None,
        execution_config: ExecutionConfig | None = None,
    ) -> None:
        self._config = config
        self._provider = provider
        self._tool_registry = tool_registry
        self._bus = bus
        self._session_store = session_store
        self._workspace = workspace
        self._audit: AuditLogger | None = audit
        self._hooks = hooks
        self._available_agents = available_agents or {}
        self._prompt_mode = prompt_mode
        self._skill_loader = skill_loader
        self._skills_config = skills_config
        self._approval_manager = approval_manager
        self._allowlist = allowlist
        self._mcp_configs = mcp_configs
        self._memory = memory
        self._running = False
        exec_cfg = execution_config or ExecutionConfig()
        self._execution_runner = execution_runner or ExecutionChainRunner(
            main_max_concurrent=exec_cfg.main_max_concurrent,
            system_max_concurrent=exec_cfg.system_max_concurrent,
            subagent_max_concurrent=exec_cfg.subagent_max_concurrent,
            pending_per_session=exec_cfg.pending_per_session,
        )
        # Event-loop execution model knobs (see ``docs/design/core/event-loop/``).
        # Promotion fires at the post-persist tool-batch boundary on Teams
        # sources (``event_loop_promotion_channels``). The legacy ``Plan C``
        # carrier-detach path was removed once the event-loop model became the
        # only execution model — keeping both gated by a runtime flag created
        # an unreachable / silently-broken kill-switch.
        self._main_turn_tool_budget = exec_cfg.main_turn_tool_budget
        self._wall_clock_promote_s = exec_cfg.wall_clock_promote_s
        self._event_loop_promotion_channels = frozenset(exec_cfg.event_loop_promotion_channels)
        # Verbosity of the synchronous promotion receipt: full | minimal |
        # silent (see ``ExecutionConfig.background_task_receipt`` and
        # ``_render_promoted_receipt``). Only governs the human-visible
        # handoff message; the ack row and fold-back are mode-independent.
        self._background_task_receipt = exec_cfg.background_task_receipt
        # Channel_ids (== carrier request_id) whose current turn emitted a
        # promotion receipt. Recorded at promotion time and consulted (then
        # discarded) at the publish boundary to set ``is_promotion_receipt``
        # WITHOUT depending on the receipt's exact text — minimal/silent
        # receipts would otherwise fail a string-equality match and lose the
        # flag that protects the fold-back's stash + Teams route.
        self._promotion_receipt_routes: set[str] = set()
        # Injected by the runtime after ``BackgroundTaskManager`` is built
        # (circular wiring: the agent needs the manager for promotion, the
        # manager needs the agent's spawn function for ``start``). Optional —
        # ``None`` means promotion always degrades inline.
        self._bg_task_manager: BackgroundTaskManager | None = None
        # Resolver from ``ChannelType`` to the actual channel instance.
        # ``_TurnState.channel`` carries the enum (it's all the agent loop
        # itself needs); promotion-time stash/quote bookkeeping needs the
        # real instance to call methods like ``_remember_timeout_quote``.
        # Injected by the runtime as ``channel_manager.get``; falls back to
        # ``None`` in CLI / unit-test setups (stash silently no-ops then).
        self._channel_resolver: Callable[[ChannelType], Any] | None = None
        self._turn_tasks: set[asyncio.Task[None]] = set()
        self._pending_turn_interrupts: dict[tuple[str, str], str] = {}
        self._reply_dispatcher = ReplyDispatcher(bus)
        # Last human, interactive (MAIN-lane) session — the surface the owner
        # is actually sitting in. Used by receiver-side a2a handling to inject
        # context so a later confirmation can be relayed. See OwnerSessionTarget.
        self._last_owner_session: OwnerSessionTarget | None = None
        # Same as above, but keyed by user-facing surface so the injector can
        # pick the owner's latest *teams* session even when their most recent
        # turn overall was on another surface (e.g. cloud_tui).
        self._owner_sessions_by_surface: dict[str, OwnerSessionTarget] = {}

        # Sub-components
        self._prompt_builder = PromptBuilder(
            config,
            workspace,
            tool_registry=tool_registry,
            available_agents=self._available_agents,
            mcp_configs=mcp_configs,
            memory=memory,
            skill_loader=skill_loader,
            skills_config=skills_config,
        )
        # Learning loop counters (Hermes-style)
        self._turns_since_memory = 0
        self._memory_nudge_interval = config.memory_nudge_interval or 10
        self._compressor = ContextCompressor(
            provider,
            protect_first_n=config.compaction_v2.protect_first_n,
            protect_last_n=config.compaction_v2.protect_last_n,
            post_threshold=config.compaction_v2.post_threshold,
            pre_threshold=config.compaction_v2.pre_threshold,
            anti_thrashing_min_savings=config.compaction_v2.anti_thrashing_min_savings,
        )
        self._parallelizer = ToolParallelizer()

    # ── Public API ───────────────────────────────────────────────────────

    async def start(self) -> None:
        """Consume inbound messages from the bus."""
        self._running = True
        logger.info("AgentLoopV2 started: {}", self._config.name)

        try:
            while self._running:
                try:
                    msg = await asyncio.wait_for(self._bus.get_inbound(), timeout=1.0)
                except asyncio.CancelledError:
                    break
                except TimeoutError:
                    continue
                await self._schedule_inbound(msg)
        finally:
            await self._execution_runner.stop()
            await self._await_turn_tasks(cancel=True)

    async def stop(self) -> None:
        """Signal the loop to stop."""
        self._running = False
        await self._execution_runner.stop()
        await self._await_turn_tasks(cancel=True)

    def interrupt(self) -> None:
        """Interrupt every active execution chain without stopping the loop."""
        self._execution_runner.interrupt_all("agent loop interrupt requested")

    def interrupt_session(
        self,
        session_key: str,
        reason: str = "agent loop interrupt",
        *,
        turn_id: str | None = None,
    ) -> bool:
        """Interrupt one execution-chain session."""
        interrupted = self._execution_runner.interrupt(session_key, reason)
        if interrupted:
            return True
        if turn_id:
            self._pending_turn_interrupts[(session_key, turn_id)] = reason
            return True
        return False

    @property
    def execution_runner(self) -> ExecutionChainRunner:
        return self._execution_runner

    def set_background_task_manager(self, manager: BackgroundTaskManager | None) -> None:
        """Wire the runtime's :class:`BackgroundTaskManager` after construction.

        ``AgentLoopV2`` and ``BackgroundTaskManager`` have a circular dependency
        (the agent needs the manager to adopt promotions; the manager needs the
        agent's spawn function to start sub-agents), so the runtime instantiates
        the agent first, then the manager, then injects the manager here.
        Calling with ``None`` disables event-loop promotion (it will always
        degrade inline) — useful in tests that exercise the legacy path.
        """
        self._bg_task_manager = manager

    def set_channel_resolver(self, resolver: Callable[[ChannelType], Any] | None) -> None:
        """Inject a ``ChannelType -> Channel | None`` resolver.

        Promotion needs the actual channel instance (not just the enum) to call
        ``_remember_timeout_quote`` for the ↩️ late-reply quote path. The
        runtime wires this with ``channel_manager.get`` immediately after
        ``self.channel_manager`` and the agent are both built. ``None``
        disables the lookup (CLI / unit-test setups), in which case the stash
        silently no-ops and the ↩️ envelope is skipped (acceptable for those
        environments — they don't have a Teams carrier to attribute back to).
        """
        self._channel_resolver = resolver

    async def _schedule_inbound(self, msg: InboundMessage) -> None:
        session_key = self._resolve_agent_session_key(msg)
        if await self._try_route_approval(msg):
            return

        inline_active = self._execution_runner.has_session_work(session_key)
        worker_snaps = self._list_workers_for_session(session_key)
        any_active = inline_active or bool(worker_snaps)

        # Interrupt fast-path: a ``/stop <id>`` targets a single worker; the
        # bare interrupt phrases cancel all of this conversation's work
        # (inline turn + every promoted worker).
        single_target = self._parse_stop_target(msg.content)
        if single_target is not None:
            await self._handle_single_worker_stop(msg, session_key, single_target)
            return
        if self._is_interrupt_metadata(msg.metadata) or self._is_interrupt_command(
            msg.content, active=any_active
        ):
            cancelled_workers = self._cancel_workers_for_session(session_key)
            if inline_active:
                self._execution_runner.interrupt(session_key, "user interrupt command")
            await self._publish_interrupt_command_ack(
                msg, active=any_active or cancelled_workers > 0
            )
            return

        # Status fast-path: while ANY work for this session is in flight
        # (inline turn OR promoted workers), a "how's it going?" check must
        # be answered from state (a canned ack) rather than enqueued behind
        # the very work it asks about — otherwise it would wait for that
        # work to finish (same serial lane) and could itself trigger another
        # auto-detach. Tight exact-phrase match so real questions
        # (e.g. "天气怎么样") still reach the agent.
        if any_active and self._is_status_query(msg.content):
            await self._publish_status_ack(msg, snapshot=worker_snaps)
            return

        turn_id = msg.turn_id or msg.delivery_route_id or session_key
        pending_interrupt = self._pending_turn_interrupts.pop((session_key, turn_id), None)
        if pending_interrupt:
            logger.info(
                "Dropping inbound turn cancelled before registration session={} turn_id={} reason={}",
                session_key,
                turn_id,
                pending_interrupt,
            )
            return

        task = asyncio.create_task(
            self._run_message_via_chain(msg, session_key=session_key),
            name=f"agent-chain-submit:{msg.turn_id or msg.delivery_route_id or session_key}",
        )
        self._turn_tasks.add(task)
        task.add_done_callback(self._on_turn_task_done)
        await asyncio.sleep(0)

    def _list_workers_for_session(self, session_key: str) -> list[BackgroundTaskSnapshot]:
        """Snapshot active workers owned by *session_key* (empty when manager absent).

        Wraps the registry call so callers don't have to guard
        ``self._bg_task_manager is None`` themselves and so future managers
        with cheaper-than-O(n) lookups can be slotted in without touching the
        schedule path.
        """
        manager = self._bg_task_manager
        if manager is None:
            return []
        return manager.list_for_owner(session_key)

    def _cancel_workers_for_session(self, session_key: str) -> int:
        """Cancel every promoted worker owned by *session_key*.

        Returns 0 when no manager is wired (legacy / tests that exercise the
        non-event-loop path) so the caller can still surface the correct
        "no active task" ack.
        """
        manager = self._bg_task_manager
        if manager is None:
            return 0
        return manager.cancel_by_owner(session_key)

    async def _handle_single_worker_stop(
        self,
        msg: InboundMessage,
        session_key: str,
        target_task_id: str,
    ) -> None:
        """Cancel one promoted worker by id; leave inline turn / other workers alone.

        Uses :meth:`BackgroundTaskManager.cancel` with the originating session
        as ``owner`` so a foreign conversation cannot reach across and stop
        another user's task. The ack copy echoes the result string the
        manager returns (already localized to "Unknown task X." / "Task X
        already finished." / "Cancellation requested for task X.") so the
        user knows whether the id matched something they own.
        """
        manager = self._bg_task_manager
        if manager is None:
            await self._publish_reply_for_inbound(msg, f"Unknown task {target_task_id}.")
            return
        ack = await manager.cancel(target_task_id, owner=session_key)
        await self._publish_reply_for_inbound(msg, ack)

    def _on_turn_task_done(self, task: asyncio.Task[None]) -> None:
        self._turn_tasks.discard(task)
        try:
            exc = task.exception()
        except asyncio.CancelledError:
            return
        if exc is not None:
            logger.opt(exception=exc).error("Agent scheduled turn failed")

    async def _await_turn_tasks(self, *, cancel: bool) -> None:
        current = asyncio.current_task()
        tasks = [task for task in self._turn_tasks if task is not current and not task.done()]
        if cancel:
            for task in tasks:
                task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _run_message_via_chain(self, msg: InboundMessage, *, session_key: str) -> None:
        try:
            await self._execution_runner.run(
                session_key=session_key,
                turn_id=msg.turn_id or msg.delivery_route_id or session_key,
                lane=self._lane_for_message(msg),
                execute=lambda: self._run_message_task(msg),
            )
        except ExecutionChainQueueFullError:
            await self._publish_queue_full(msg)
        except ExecutionChainCancelledError:
            logger.info("Queued agent turn cancelled session={}", session_key)
            await self._publish_interrupted(msg)
        except ExecutionChainStoppedError:
            logger.debug("Dropped inbound because execution runner is stopping")
        except asyncio.CancelledError:
            logger.info("Agent chain submit task cancelled session={}", session_key)
        except Exception as exc:  # noqa: BLE001 — keep loop alive
            logger.error("Agent loop error: {}", exc)

    async def _run_message_task(self, msg: InboundMessage) -> None:
        try:
            await self._process_message(msg)
        except asyncio.CancelledError:
            await self._publish_interrupted(msg)
            raise
        except Exception as exc:  # noqa: BLE001 — keep loop alive
            logger.error("Agent loop error: {}", exc)

    @staticmethod
    def _is_interrupt_command(content: str, *, active: bool) -> bool:
        text = content.strip().lower()
        slash_commands = {"/stop", "/cancel", "/interrupt"}
        if text in slash_commands:
            return True
        if not active:
            return False
        # ``停`` is the bare-verb form used in the event-loop interrupt spec
        # (see 04-runtime-behavior.md §4.3 + 06-test-plan.md T13). It is
        # safe to include because this branch only fires while work is
        # actually in flight — no risk of intercepting a casual "停" in a
        # back-and-forth conversation.
        return text in {
            "stop",
            "cancel",
            "interrupt",
            "停",
            "停止",
            "取消",
            "打断",
            "停一下",
            "先停",
        }

    @staticmethod
    def _is_interrupt_metadata(metadata: dict[str, Any] | None) -> bool:
        if not metadata:
            return False
        value = metadata.get("interrupt")
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.strip().lower() in {
                "1",
                "true",
                "yes",
                "y",
                "stop",
                "cancel",
                "interrupt",
            }
        return False

    async def _publish_reply_for_inbound(self, msg: InboundMessage, content: str) -> None:
        await self._reply_dispatcher.publish_final(
            channel=ChannelType.of(msg.logical_channel),
            channel_id=msg.delivery_route_id,
            content=content,
            thread_id=msg.conversation_id or msg.delivery_route_id,
            route_hint=msg.route_hint,
            dedupe=False,
        )

    async def _publish_interrupt_command_ack(self, msg: InboundMessage, *, active: bool) -> None:
        content = "已打断当前任务。" if active else "当前没有正在执行的任务。"
        await self._publish_reply_for_inbound(msg, content)

    @staticmethod
    def _is_status_query(content: str) -> bool:
        """Whether *content* is a bare "how's it going?" status check.

        Exact-phrase match (after strip/lower/trailing punctuation) so a real
        question that merely contains a status word (e.g. "天气怎么样") is not
        swallowed. Only meaningful while a turn is already running.
        """
        text = content.strip().lower().rstrip("?？!！。.~〜 ").strip()
        return text in _STATUS_QUERY_PHRASES

    @staticmethod
    def _parse_stop_target(content: str) -> str | None:
        """Extract a task id from ``/stop <id>`` (also /cancel /interrupt).

        Returns ``None`` for plain ``/stop`` (the "stop everything" form) or
        any non-slash interrupt phrase. A non-None return tells the inbound
        scheduler to cancel one specific promoted worker by id and leave the
        rest of the conversation (inline turn + other workers) untouched
        (see ``docs/design/core/event-loop/04-runtime-behavior.md`` §4.3 and
        06-test-plan.md T14).
        """
        text = content.strip()
        if not text.startswith("/"):
            return None
        parts = text.split(maxsplit=1)
        if len(parts) != 2:
            return None
        verb = parts[0].lower()
        if verb not in {"/stop", "/cancel", "/interrupt"}:
            return None
        target = parts[1].strip()
        return target or None

    async def _publish_status_ack(
        self,
        msg: InboundMessage,
        *,
        snapshot: list[BackgroundTaskSnapshot] | None = None,
    ) -> None:
        """Reply to a status check from live state without enqueuing work.

        ``snapshot`` (when provided) lists the caller's currently-running
        promoted workers from :meth:`BackgroundTaskManager.list_for_owner`.
        Its length is included in the user-visible copy so they know how
        many parallel lookups are still in flight. An empty / missing
        snapshot falls back to the legacy single-flight copy — the inline
        turn is the only active work.
        """
        zh = contains_cjk(msg.content)
        count = len(snapshot) if snapshot else 0
        if count > 0:
            content = (
                f"⏳ 还在处理你之前的请求（{count} 项进行中），完成后会把结果发到这里。"
                if zh
                else (
                    f"⏳ Still working on your earlier requests ({count} in progress) — "
                    "I'll post results here when they're done."
                )
            )
        else:
            content = (
                "⏳ 还在处理你之前的请求，完成后会把结果发到这里。"
                if zh
                else "⏳ Still working on your earlier request — I'll post the result here when it's done."
            )
        await self._publish_reply_for_inbound(msg, content)

    async def _publish_interrupted(self, msg: InboundMessage) -> None:
        await self._publish_reply_for_inbound(msg, "(interrupted)")

    async def _publish_queue_full(self, msg: InboundMessage) -> None:
        await self._publish_reply_for_inbound(
            msg,
            "This conversation already has too many pending messages."
            " Please wait for the current work to finish or send /stop.",
        )

    def _resolve_agent_session_key(self, msg: InboundMessage) -> str:
        channel = ChannelType.of(msg.logical_channel)
        delivery_route_id = msg.delivery_route_id
        conversation_id = msg.conversation_id or delivery_route_id
        sender_for_session = msg.sender_id or conversation_id or delivery_route_id or "anonymous"
        return msg.agent_session_key or (
            f"{channel}:{sender_for_session}:{conversation_id or delivery_route_id}"
        )

    def _maybe_capture_owner_session(
        self,
        msg: InboundMessage,
        agent_session_key: str,
        channel: ChannelType,
        sender_for_session: str,
    ) -> None:
        """Remember the owner's most recent human, interactive session.

        Only genuine human MAIN-lane turns qualify. a2a / a2a_task / cron /
        notify traffic runs in the SYSTEM lane (and is flagged
        ``initiated_by != human``), so it is excluded — we never want to point
        the owner-context injector at an isolated remote-sender session.
        """
        if self._lane_for_message(msg) != ExecutionLane.MAIN:
            return
        initiated_by = str((msg.metadata or {}).get("initiated_by") or "human").strip().lower()
        if initiated_by != "human":
            return
        surface = self._surface_for_message(msg)
        target = OwnerSessionTarget(
            session_key=agent_session_key,
            channel=str(channel),
            sender_id=sender_for_session,
            surface=surface,
        )
        self._last_owner_session = target
        if surface:
            self._owner_sessions_by_surface[surface] = target

    @staticmethod
    def _surface_for_message(msg: InboundMessage) -> str:
        """Normalize an inbound message to a user-facing surface label.

        Mirrors the vocabulary used by ``cloud._send_notify``'s ``push_target``
        (e.g. ``"teams"`` / ``"cloud_tui"``) so the owner-context injector can
        target the same surface a heads-up notification would reach. Prefers the
        granular ``turn_provenance.logical_channel`` (already normalized to
        ``LogicalChannel`` values like ``teams`` / ``cloud_tui``), falling back
        to the raw ``source`` / ``physical_ingress`` hint.
        """
        meta = msg.metadata or {}
        provenance = meta.get("turn_provenance")
        surface = ""
        if isinstance(provenance, dict):
            surface = str(provenance.get("logical_channel") or "").strip().lower()
        if not surface:
            surface = str(meta.get("source") or msg.physical_ingress or "").strip().lower()
        if surface in {"teams_bridge", "cloud_teams"}:
            return "teams"
        return surface

    def get_last_owner_session(self) -> OwnerSessionTarget | None:
        """Return the owner's most recent human interactive session, if known."""
        return self._last_owner_session

    def get_owner_session_for_surface(self, surface: str) -> OwnerSessionTarget | None:
        """Return the owner's latest human session on a specific surface."""
        return self._owner_sessions_by_surface.get(surface)

    @staticmethod
    def _resolve_lane(
        metadata: dict[str, Any] | None,
        *,
        fallback_source: str | None = None,
    ) -> ExecutionLane:
        meta = metadata or {}
        explicit = str(meta.get("execution_lane") or "").strip().lower()
        if explicit == ExecutionLane.SUBAGENT.value:
            return ExecutionLane.SUBAGENT
        if explicit == ExecutionLane.SYSTEM.value:
            return ExecutionLane.SYSTEM
        source = str(meta.get("source") or fallback_source or "").strip().lower()
        if source in _SYSTEM_LANE_SOURCES:
            return ExecutionLane.SYSTEM
        return ExecutionLane.MAIN

    @staticmethod
    def _lane_for_message(msg: InboundMessage) -> ExecutionLane:
        return AgentLoopV2._resolve_lane(msg.metadata, fallback_source=msg.physical_ingress)

    @staticmethod
    def _lane_for_run_once(metadata: dict[str, Any] | None) -> ExecutionLane:
        return AgentLoopV2._resolve_lane(metadata)

    @staticmethod
    def _conversation_metadata_for_message(msg: InboundMessage) -> dict[str, Any]:
        """Return turn metadata with normalized ingress preserved for legacy paths."""

        metadata = dict(msg.metadata or {})
        physical_ingress = str(msg.physical_ingress or "").strip()
        if physical_ingress:
            # ``InboundMessage.physical_ingress`` is the sanitized routing fact;
            # metadata can be stale or peer-supplied after compatibility rewrites.
            metadata["physical_ingress"] = physical_ingress
        return metadata

    async def run_once(
        self,
        prompt: str,
        session_id: str | None = None,
        *,
        channel: Any = None,
        channel_id: Any = None,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        exclude_tools: list[str] | None = None,
    ) -> str:
        """Run a single turn: prompt → response."""
        sid = session_id or await self._session_store.get_or_create_session(
            str(channel or "cli"),
            channel_id or "run_once",
        )

        async def _execute() -> str:
            history = await self._session_store.get_messages(sid)
            response_text, _ = await self._run_conversation(
                prompt,
                history,
                sid,
                channel=channel,
                channel_id=channel_id,
                thread_id=thread_id,
                metadata=metadata,
                exclude_tools=exclude_tools,
            )
            return response_text

        return await self._execution_runner.run(
            session_key=sid,
            turn_id=str((metadata or {}).get("turn_id") or thread_id or channel_id or sid),
            lane=self._lane_for_run_once(metadata),
            execute=_execute,
        )

    # ── Typing indicators ───────────────────────────────────────────────

    def _start_typing(
        self,
        channel: Any,
        channel_id: str | None,
        metadata: dict[str, Any] | None = None,
    ) -> asyncio.Task[None] | None:
        """Start a periodic typing indicator task. Returns the task (or None for CLI)."""
        if not channel or not channel_id or channel == ChannelType.CLI:
            return None

        payload = {"channel": channel, "channel_id": channel_id, "metadata": metadata or {}}
        self._bus.events.emit(EventType.TYPING_STARTED, payload)

        async def _typing_loop() -> None:
            try:
                while True:
                    await asyncio.sleep(3.0)
                    self._bus.events.emit(EventType.TYPING_STARTED, payload)
            except asyncio.CancelledError:
                pass

        return asyncio.create_task(_typing_loop(), name="typing-indicator")

    def _stop_typing(
        self,
        task: asyncio.Task[None] | None,
        channel: Any = None,
        channel_id: str | None = None,
    ) -> None:
        """Cancel the typing indicator task and emit TYPING_STOPPED."""
        if task and not task.done():
            task.cancel()
        if channel and channel_id and channel != ChannelType.CLI:
            self._bus.events.emit(
                EventType.TYPING_STOPPED,
                {"channel": channel, "channel_id": channel_id},
            )

    # ── Slash commands ──────────────────────────────────────────────────

    async def _handle_slash(self, cmd: str, session_id: str, msg: InboundMessage) -> str | None:
        """Handle REPL slash commands. Returns reply string or None if not known."""
        parts = cmd.split(maxsplit=1)
        verb = parts[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ""

        if verb == "/new":
            await self._session_store.replace_messages(session_id, [])
            try:
                from praestoclaw.agent.tools.plan import get_plan_store

                get_plan_store().delete(session_id)
            except Exception as exc:  # noqa: BLE001
                logger.debug("Plan cleanup after /new failed session={} error={}", session_id, exc)
            return "Session cleared. Starting fresh."

        if verb == "/compact":
            history = await self._session_store.get_messages(session_id)
            if len(history) < 10:
                return "Not enough messages to compact."
            result = await self._compressor.compress(history)
            await self._persist_compacted(session_id, result.messages)
            return (
                f"Compacted: {result.tokens_before}→{result.tokens_after} tokens "
                f"({result.savings_percent:.0f}% saved, method: {result.method})"
            )

        if verb == "/status":
            budget_info = f"Budget: {self._config.budget.max_iterations} max"
            model_info = f"Model: `{self._config.model}`"
            core_info = "Agent core: v2 (Hermes-style)"
            return f"{core_info}\n{model_info}\n{budget_info}"

        if verb == "/memory":
            if self._memory:
                content = self._memory.read() if hasattr(self._memory, "read") else ""
                return content if content and content.strip() else "_MEMORY.md is empty._"
            return "_No memory configured._"

        if verb == "/tools":
            schemas = self._tool_registry.get_schemas(self._config.tools or None)
            if not schemas:
                return "_No tools available._"
            lines = ["**Available tools:**"]
            for s in schemas:
                name = s.get("function", {}).get("name", "?")
                desc = s.get("function", {}).get("description", "")[:60]
                lines.append(f"- `{name}` — {desc}")
            return "\n".join(lines)

        if verb == "/model":
            if not arg:
                return f"Current model: `{self._config.model}`"
            old_model = self._config.model
            self._config.model = arg.strip()
            return f"Model switched: `{old_model}` → `{self._config.model}`"

        if verb == "/estop":
            reason = arg or "Manual E-stop via slash command"
            self._bus.events.emit(
                EventType.SECURITY_ESTOP,
                {"reason": reason, "actor": f"user:{msg.sender_id or 'unknown'}"},
            )
            return "**E-STOP ACTIVATED.** All agent activity halted."

        if verb == "/help":
            return (
                "**Available commands:**\n"
                "- `/new` — clear session\n"
                "- `/compact` — compress history\n"
                "- `/status` — show config\n"
                "- `/memory` — show MEMORY.md\n"
                "- `/tools` — list available tools\n"
                "- `/model [name]` — show/switch model\n"
                "- `/estop` — emergency stop\n"
            )

        # Unknown slash command — let it go to the agent
        return None

    # ── Approval routing ────────────────────────────────────────────────

    async def _try_route_approval(self, msg: InboundMessage) -> bool:
        """Intercept /approve, /deny, /always commands. Returns True if consumed."""
        if self._approval_manager is None:
            return False

        mgr = self._approval_manager
        content = msg.content.strip()
        content_lower = content.lower()
        action: str | None = None
        request_id: str | None = None

        # Check metadata first (Teams Adaptive Card / Cloud structured response)
        meta = msg.metadata if hasattr(msg, "metadata") and msg.metadata else {}
        if meta.get("approval_action"):
            action = meta["approval_action"]
            request_id = meta.get("approval_request_id")

        # Slash commands: /approve <id>, /deny <id>, /always <id>
        elif content.startswith("/approve "):
            action, request_id = "approve", content.split(maxsplit=1)[1].strip()
        elif content.startswith("/deny "):
            action, request_id = "deny", content.split(maxsplit=1)[1].strip()
        elif content.startswith("/always "):
            action, request_id = "always", content.split(maxsplit=1)[1].strip()

        # Simple keywords — resolve against the single pending request
        else:
            pending = mgr.get_pending()
            if len(pending) == 1:
                sole = pending[0]
                if content_lower in ("yes", "y", "approve", "/approve"):
                    action, request_id = "approve", sole.id
                elif content_lower in ("no", "n", "deny", "/deny"):
                    action, request_id = "deny", sole.id
                elif content_lower in ("always", "a", "/always"):
                    action, request_id = "always", sole.id

        if not action or not request_id:
            return False

        try:
            approved = action in ("approve", "always")
            mgr.resolve(
                request_id, approved=approved, resolver=msg.sender_id or "user", action=action
            )

            if action == "always" and self._allowlist is not None:
                resolved_req = mgr.get_request(request_id)
                if resolved_req:
                    self._allowlist.add(
                        resolved_req.tool_name,
                        resolved_req.args if hasattr(resolved_req, "args") else None,
                        added_by=msg.sender_id or "user",
                    )

            status = "approved" if approved else "denied"
            logger.info("Approval {} for request {}", status, request_id)
        except Exception as exc:
            logger.error("Approval routing error: {}", exc)

        return True

    # ── Core conversation loop ───────────────────────────────────────────

    async def _run_conversation(
        self,
        *args: Any,
        **kwargs: Any,
    ) -> tuple[str, bool]:
        """Run the agentic conversation loop."""
        return await self._run_conversation_impl(*args, **kwargs)

    async def _run_conversation_impl(
        self,
        user_message: str,
        history: list[dict[str, Any]],
        session_id: str,
        *,
        channel: Any = None,
        channel_id: str | None = None,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        exclude_tools: list[str] | None = None,
        route_hint: str | None = None,
    ) -> tuple[str, bool]:
        """Run the agentic conversation loop. Returns (response_text, streamed).

        Splits into a setup phase (:meth:`_begin_turn`) that prepares a
        :class:`_TurnState`, and a reentrant loop phase (:meth:`_drive_turn`)
        that consumes it. The split is byte-for-byte equivalent to the legacy
        monolithic implementation when the event-loop flag is OFF
        (locked by ``test_loop_v2.py::test_drive_turn_inline_equivalence``).
        See ``docs/design/core/event-loop/02-architecture.md`` §2.2.
        """
        state = await self._begin_turn(
            user_message,
            history,
            session_id,
            channel=channel,
            channel_id=channel_id,
            thread_id=thread_id,
            metadata=metadata,
            exclude_tools=exclude_tools,
            route_hint=route_hint,
        )
        return await self._drive_turn(state)

    async def _begin_turn(
        self,
        user_message: str,
        history: list[dict[str, Any]],
        session_id: str,
        *,
        channel: Any = None,
        channel_id: str | None = None,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        exclude_tools: list[str] | None = None,
        route_hint: str | None = None,
    ) -> _TurnState:
        """Setup phase: provider restore → budget → system prompt → skill match
        → attachment block → persist USER row → enriched messages → plan block
        → preflight compression. Returns a fully-prepared :class:`_TurnState`
        ready to be consumed by :meth:`_drive_turn`.
        """
        # 1. Restore primary provider if failover was active
        if hasattr(self._provider, "restore_primary"):
            self._provider.restore_primary()  # type: ignore[attr-defined]

        # 2. Create budget + fresh loop detector per conversation
        budget = IterationBudget(max_total=self._config.budget.max_iterations)
        loop_detector = LoopDetector()
        self._turns_since_memory += 1

        # 3. Build system prompt
        system_prompt = self._build_system_prompt()

        # 4. Auto-match skills for injection
        injected_skills = None
        if self._skill_loader and hasattr(self._skill_loader, "match"):
            skills_config = self._skills_config
            threshold = getattr(skills_config, "inject_threshold", 20) if skills_config else 20
            max_inject = getattr(skills_config, "max_inject", 1) if skills_config else 1
            if max_inject > 0:
                injected_skills = (
                    self._skill_loader.match(
                        user_message, threshold=threshold, max_results=max_inject
                    )
                    or None
                )

        # 5. Build enriched user message (runtime context + skills injection).
        # Surface lightweight metadata only. Image URLs remain visible for URL
        # passthrough workflows (e.g. feedback); signed file download URLs stay
        # hidden and are only resolved by attachment_process.
        attachment_block = self._build_attachment_context(metadata)
        if attachment_block:
            user_message = f"{attachment_block}\n\n{user_message}"

        # ``user_message`` is now the durable user text (raw user input +
        # any prepended ``[attachments: ...]`` context that must survive
        # across turns). The enriched form below adds *ephemeral* per-turn
        # context (Runtime Context block + matched skill <context> blocks)
        # that must only reach the LLM for this turn. Persisting the
        # enriched form would poison future turns with a frozen
        # "Current Time: <past>" and stale one-shot skill injections
        # (issue #345 root cause). Store ``user_message``; build the
        # enriched form separately for the LLM-bound message list.
        enriched_content = self._prompt_builder.build_user_message(
            user_message,
            channel=channel,
            channel_id=channel_id,
            injected_skills=injected_skills,
            conversation_name=str((metadata or {}).get("conversation_name") or "") or None,
        )
        user_rowid = await self._session_store.add_message(
            session_id,
            {"role": "user", "content": user_message},
        )
        user_msg = {"role": "user", "content": enriched_content}

        # 5a. Wire plan tool's session resolver + read active plan (pinned block).
        # The active-plan block is re-assembled every turn from the on-disk
        # snapshot, so compaction can never make the agent "forget" its plan.
        plan_block = ""
        active_plan_lookup: Callable[[str], str] | None = None
        plan_tool: Any | None = None
        try:
            from praestoclaw.agent.tools.plan import active_plan_block

            active_plan_lookup = active_plan_block
            plan_tool = (
                self._tool_registry.get("plan") if hasattr(self._tool_registry, "get") else None
            )
            if plan_tool and hasattr(plan_tool, "set_session_resolver"):
                plan_tool.set_session_resolver(lambda sid=session_id: sid)
            plan_block = active_plan_lookup(session_id)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Active plan block lookup failed: {}", exc)

        planning_preflight: TaskPlanningPreflight | None = None
        preflight_plan_created = False
        preflight_allowed_tools = self._resolve_allowed_tools(exclude_tools)
        plan_tool_available = plan_tool is not None and (
            preflight_allowed_tools is None or "plan" in preflight_allowed_tools
        )
        if should_run_task_planning_preflight(
            channel=channel,
            channel_id=channel_id,
            metadata=metadata,
            plan_block=plan_block,
            plan_tool_available=plan_tool_available,
        ):
            planning_preflight = await run_task_planning_preflight(
                self._provider,
                model=self._config.model,
                user_message=user_message,
                session_id=session_id,
                metadata=metadata,
            )
            preflight_plan_created = await self._maybe_create_task_preflight_plan(
                planning_preflight,
                session_id=session_id,
                channel=channel,
                channel_id=channel_id,
                thread_id=thread_id,
                metadata=metadata,
                exclude_tools=exclude_tools,
                user_message=user_message,
            )
            if preflight_plan_created and active_plan_lookup is not None:
                try:
                    plan_block = active_plan_lookup(session_id)
                except Exception as exc:  # noqa: BLE001
                    logger.debug("Active plan block refresh after preflight failed: {}", exc)

        # 5. Assemble messages
        messages = self._assemble_messages(system_prompt, history, user_msg)
        if plan_block:
            # Insert immediately after the system prompt so it survives
            # compaction (compaction preserves leading system messages).
            messages.insert(1, {"role": "system", "content": plan_block})

        # 6. Preflight compression
        context_limit = self._resolve_context_limit()
        history_tokens = estimate_tokens(messages)
        if self._compressor.should_preflight_compress(history_tokens, context_limit):
            result = await self._compressor.compress(messages, current_tokens=history_tokens)
            messages = result.messages
            await self._persist_compacted(session_id, messages)
            logger.info(
                "Preflight compression: {}→{} tokens", result.tokens_before, result.tokens_after
            )

        planning_context = render_task_planning_preflight_context(
            planning_preflight,
            visible_plan_created=preflight_plan_created,
        )
        if planning_context:
            insert_task_planning_preflight_context(
                messages, planning_context, after_plan_block=bool(plan_block)
            )

        return _TurnState(
            messages=messages,
            session_id=session_id,
            plan_session_id=session_id,
            budget=budget,
            loop_detector=loop_detector,
            user_rowid=user_rowid if isinstance(user_rowid, int) else None,
            channel=channel,
            channel_id=channel_id,
            thread_id=thread_id,
            route_hint=route_hint,
            user_message=user_message,
            metadata=metadata,
            exclude_tools=exclude_tools,
            started_monotonic=time.monotonic(),
        )

    async def _maybe_create_task_preflight_plan(
        self,
        preflight: TaskPlanningPreflight | None,
        *,
        session_id: str,
        channel: Any,
        channel_id: str | None,
        thread_id: str | None,
        metadata: dict[str, Any] | None,
        exclude_tools: list[str] | None,
        user_message: str,
    ) -> bool:
        if preflight is None or not preflight.should_create_visible_plan:
            return False
        # Plan-tool availability is already proven by the preflight gate
        # (``should_run_task_planning_preflight`` returns False without it).
        if not hasattr(self._tool_registry, "execute"):
            logger.debug("event_loop.task_preflight.plan_create skipped reason=no_registry_execute")
            return False
        channel_type = ChannelType.of(channel, default=None)
        if channel_type == ChannelType.CLI or not channel_id:
            logger.debug(
                "event_loop.task_preflight.plan_create skipped reason=no_push_channel channel={}",
                channel,
            )
            return False

        args = {
            "action": "create",
            "workflow": "task-preflight",
            "items": [{"title": step} for step in preflight.steps],
        }
        tool_metadata = dict(self._metadata_for_tool("plan", metadata) or {})
        tool_metadata["internal_task_preflight"] = True
        tool_call = ToolCallRequest(
            id="task-preflight-plan-create",
            name="plan",
            arguments=args,
        )
        try:
            result = await self._execute_internal_tool_call(
                tool_call,
                session_id=session_id,
                channel=channel_type,
                channel_id=channel_id,
                thread_id=thread_id,
                metadata=tool_metadata,
                exclude_tools=exclude_tools,
                user_message=user_message,
            )
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "event_loop.task_preflight.plan_create error session={} error={}",
                session_id,
                exc,
            )
            return False

        # Reject both failure shapes: PlanTool's own ``"Error: ..."`` validation
        # messages AND ToolRegistry's wrapped ``"Error executing plan: ..."`` (no
        # colon after "Error") returned when the tool raises. Matching only
        # ``"Error:"`` would mistake a registry exception for success and then
        # falsely tell the agent a visible plan card exists.
        success = isinstance(result, str) and not _is_tool_error_result(result)
        logger.debug(
            "event_loop.task_preflight.plan_create session={} success={} items_n={} result={}",
            session_id,
            success,
            len(preflight.steps),
            truncate_ellipsis(str(result), 300),
        )
        return success

    async def _drive_turn(self, state: _TurnState) -> tuple[str, bool]:
        """Reentrant loop phase: call LLM → execute tools → persist → compact
        → final persist → memory consolidate. Reads/writes through *state* so
        a future promotion can swap ``state.session_id`` to a worker session
        and resume the same chain.

        Every persisted row inside the loop body appends its ``lastrowid`` to
        ``state.turn_rowids``. Promotion (step D) prunes exactly that set from
        the originating session.
        """
        budget = state.budget
        grace_enabled = self._config.budget.grace_call
        loop_detector = state.loop_detector
        messages = state.messages
        metadata = state.metadata
        exclude_tools = state.exclude_tools
        channel = state.channel
        channel_id = state.channel_id
        thread_id = state.thread_id
        route_hint = state.route_hint
        user_message = state.user_message

        context_limit = self._resolve_context_limit()

        # 8. Main loop
        response_text = ""
        streamed = False
        empty_final_retries = 0
        iteration = 0

        while budget.remaining > 0 or (grace_enabled and budget.grace_available):
            # b/c. Consume budget or grace; determine if tools are allowed
            current_tools = self._get_tool_schemas(exclude_tools, metadata=metadata)
            if budget.remaining > 0:
                budget.consume()
                # When grace is disabled and we just consumed the last iteration,
                # force text-only so the model wraps up with text.
                if budget.remaining == 0 and not grace_enabled:
                    current_tools = None
            elif budget.grace_available:
                budget.consume_grace()
                current_tools = None  # force text-only on grace
            else:
                break

            # d. Graceful termination nudge
            if budget.remaining == 1 and current_tools is not None:
                messages.append(
                    {
                        "role": "system",
                        "content": "You are running low on iterations. Please wrap up your current task and provide a final response.",
                    }
                )

            # d2. Memory/skill nudge (Hermes-style learning loop)
            if (
                budget.remaining <= 2
                and current_tools is not None
                and self._turns_since_memory >= self._memory_nudge_interval
            ):
                messages.append(
                    {
                        "role": "system",
                        "content": (
                            "Consider saving important findings to memory "
                            "(user preferences, environment details, lessons learned) "
                            "or as a skill (reusable workflows) before wrapping up."
                        ),
                    }
                )
                self._turns_since_memory = 0

            # e. Cache breakpoints
            cached_messages = apply_cache_breakpoints(messages, self._provider)

            # f. Call LLM
            try:
                llm_response, final_delivered = await self._call_llm(
                    self._config.model,
                    cached_messages,
                    current_tools,
                    channel=channel,
                    channel_id=channel_id,
                )
            except CompressNeededError:
                result = await self._compressor.compress(messages)
                messages = result.messages
                state.messages = messages
                await self._persist_compacted(state.session_id, messages)
                # ``_persist_compacted`` calls ``replace_messages`` which is
                # DELETE-then-INSERT, so every rowid in MAIN is re-issued. The
                # ids already accumulated in ``state.turn_rowids`` from earlier
                # tool batches in this turn now point at rows that no longer
                # exist; a subsequent ``_promote_turn_to_worker`` cap-race
                # rollback (which reads ``state.turn_rowids`` to restore the
                # pre-prune snapshot) would otherwise see an empty list and
                # silently lose the post-compaction tool trajectory. Reset
                # here so the next batch accumulates fresh, valid rowids.
                state.turn_rowids = []
                logger.info("Mid-loop compression: saved {:.0f}%", result.savings_percent)
                continue

            if llm_response.tool_calls:
                safe_tool_calls = [
                    tc for tc in llm_response.tool_calls if is_provider_safe_tool_name(tc.name)
                ]
                if len(safe_tool_calls) != len(llm_response.tool_calls):
                    dropped = [
                        tc.name
                        for tc in llm_response.tool_calls
                        if not is_provider_safe_tool_name(tc.name)
                    ]
                    logger.warning(
                        "Dropped provider-unsafe tool_call name(s) from LLM response: {}",
                        dropped,
                    )
                    llm_response.tool_calls = safe_tool_calls

            # h. Track usage
            await self._session_store.update_usage(
                state.session_id,
                prompt_tokens=llm_response.prompt_tokens,
                completion_tokens=llm_response.completion_tokens,
                cost=0.0,
            )

            # i. Tool calls
            if llm_response.has_tool_calls:
                # Track tool-batch count; the post-persist boundary below
                # decides whether to promote this turn to a worker session
                # (event-loop execution model).
                state.tool_batches += 1
                assistant_msg = self._response_to_message(llm_response)
                rowid = await self._session_store.add_message(state.session_id, assistant_msg)
                if isinstance(rowid, int):
                    state.turn_rowids.append(rowid)
                messages.append(assistant_msg)

                # Push the model's preamble text (e.g. "Let me look that
                # up…") to channels BEFORE executing tools. The tools
                # branch above calls ``provider.complete()`` (non-stream),
                # so the streaming chunk path in ``_call_llm`` is skipped
                # — meaning the only place this content currently lands
                # is ``session_store.add_message`` above. That suffices
                # for surfaces that re-read session history (Web UI
                # polls ``/api/sessions/...``), but push-only channels
                # like Teams never see it and jump straight to the
                # tool-progress card. Emit it as an intermediate
                # OutboundMessage so cloud.py routes it via
                # ``_send_notify`` (``keep_context=True`` keeps the
                # ``/chatng`` sync waiter open for the eventual final
                # reply after tool results). Skip on CLI (no push
                # surface) and when there's no channel context (e.g.
                # ``run_once`` callers).
                # ``route_hint`` is forwarded from the inbound so cloud
                # channel routing for synthetic channel_ids (e.g.
                # ``a2a:notify:*``) lands on the right connection
                # instead of broadcasting. ``.strip()`` guards against
                # whitespace-only content (e.g. ``"\n"``) which would
                # otherwise render as an empty bubble on push channels.
                preamble = (llm_response.content or "").strip()
                if preamble and channel and channel_id and channel != ChannelType.CLI:
                    try:
                        await self._reply_dispatcher.publish_intermediate(
                            channel=channel,
                            channel_id=channel_id,
                            content=preamble,
                            thread_id=thread_id,
                            route_hint=route_hint,
                            metadata={"keep_context": True},
                        )
                    except Exception as exc:  # noqa: BLE001
                        logger.warning(
                            "Preamble outbound failed (channel={} channel_id={}): {}",
                            channel,
                            channel_id,
                            exc,
                        )

                results = await self._execute_tools(
                    llm_response.tool_calls,
                    session_id=state.session_id,
                    plan_session_id=state.plan_session_id,
                    channel=channel,
                    channel_id=channel_id,
                    thread_id=thread_id,
                    metadata=metadata,
                    exclude_tools=exclude_tools,
                    user_message=user_message,
                )

                for tc, result_str in results:
                    is_error = _is_tool_error_result(result_str)
                    tool_msg: dict[str, Any] = {
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": result_str,
                    }
                    if is_error:
                        tool_msg["is_error"] = True
                    rowid = await self._session_store.add_message(state.session_id, tool_msg)
                    if isinstance(rowid, int):
                        state.turn_rowids.append(rowid)
                    messages.append(tool_msg)

                    # Reset learning loop counter when memory/skill tools are used
                    if tc.name in ("memory", "skill_manage"):
                        self._turns_since_memory = 0

                # Event-loop promotion check — post-persist tool-batch boundary.
                # At this point ``state.turn_rowids`` holds the full set of
                # ``tool_use`` + ``tool_result`` rows for this batch (complete
                # pairs only, see ``docs/design/core/event-loop/02-architecture.md``
                # §2.3). If promotion fires it returns ``_PROMOTED_RECEIPT`` via
                # an early-return so the loop's final-persist step is bypassed
                # (D-receipt — the channel receipt is never persisted to main).
                if await self._maybe_promote_turn(state, llm_response):
                    # Record the carrier route as receipt-bearing so the
                    # publish boundary can flag ``is_promotion_receipt`` without
                    # string-matching the (possibly minimal/empty) receipt text.
                    # The receipt itself was resolved inside
                    # ``_promote_turn_to_worker`` (pre-adopt) and stashed on the
                    # state, so this return path stays await-free.
                    if state.channel_id:
                        self._promotion_receipt_routes.add(state.channel_id)
                    return state.promoted_receipt, state.streamed

                # Loop detection
                for tc, _ in results:
                    warning, should_terminate = loop_detector.check(tc.name, tc.arguments)
                    if should_terminate:
                        response_text = warning or "Loop detected — stopping."
                        break
                    if warning:
                        messages.append({"role": "system", "content": warning})
                else:
                    # Post-iteration compression
                    iteration += 1
                    msg_tokens = estimate_tokens(messages)
                    if self._compressor.should_compress(msg_tokens, context_limit):
                        # Pre-compression memory flush (Hermes-style)
                        await self._flush_memories_before_compression(
                            messages,
                            state.session_id,
                            channel=channel,
                            channel_id=channel_id,
                        )
                        cr = await self._compressor.compress(messages, current_tokens=msg_tokens)
                        messages = cr.messages
                        state.messages = messages
                        await self._persist_compacted(state.session_id, messages)
                        # See mid-loop branch above: rowids accumulated before
                        # this compaction now refer to rows that have been
                        # DELETE-then-INSERT'd. Reset so cap-race rollback /
                        # success-path prune use only post-compaction ids.
                        state.turn_rowids = []
                    continue

                break  # loop terminated
            else:
                # j. Text response → done
                response_text = llm_response.content or ""
                # streamed = final delivery confirmed (all chunks + done marker sent OK)
                streamed = final_delivered
                if not response_text.strip():
                    empty_final_retries += 1
                    can_retry_empty_final = empty_final_retries == 1 and (
                        budget.remaining > 0 or (grace_enabled and budget.grace_available)
                    )
                    if can_retry_empty_final:
                        logger.warning(
                            "Agent produced empty final response; requesting explicit "
                            "continuation/wrap-up session_id={} budget_remaining={} grace_available={}",
                            state.session_id,
                            budget.remaining,
                            budget.grace_available,
                        )
                        messages.append({"role": "system", "content": _EMPTY_FINAL_RESPONSE_PROMPT})
                        continue
                    logger.warning(
                        "Agent produced empty final response and cannot retry; returning "
                        "incomplete status session_id={} budget_remaining={} grace_available={}",
                        state.session_id,
                        budget.remaining,
                        budget.grace_available,
                    )
                    response_text = _EMPTY_FINAL_RESPONSE_FALLBACK
                    streamed = False
                break

        # 9. Persist final response
        if response_text:
            rowid = await self._session_store.add_message(
                state.session_id,
                {"role": "assistant", "content": response_text},
            )
            if isinstance(rowid, int):
                state.turn_rowids.append(rowid)

        # 10. Fire-and-forget memory consolidation
        if self._memory and response_text:
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(self._async_consolidate(messages, state.session_id))
            except RuntimeError:
                pass

        state.streamed = streamed
        return response_text, streamed

    # ── Event-loop promotion (Step D, see docs/design/core/event-loop/) ──

    async def _maybe_promote_turn(self, state: _TurnState, llm_response: LLMResponse) -> bool:
        """Promote *state* to a detached worker session when eligible.

        Called from ``_drive_turn`` at the post-persist tool-batch boundary
        (after the assistant ``tool_use`` row AND every ``tool_result`` row
        for the batch have been written, see
        ``docs/design/core/event-loop/02-architecture.md`` §2.3). Returns
        ``True`` when the turn was promoted, so the caller can short-circuit
        with the receipt sentinel and skip the loop's final-persist step.

        Eligibility (D-trigger × D-channel × D-cap):

        * ``metadata.source`` is in ``event_loop_promotion_channels``
        * a manager exists and a worker slot is free (cap pre-check is
          intentionally cheap and side-effect free — see invariant in
          §02 §2.3: "no corruption path on cap-full")
        * not already promoted
        * a trigger fired: ``tool_batches >= main_turn_tool_budget`` (T-count)
          OR ``elapsed >= wall_clock_promote_s`` (T-time)
        """
        if state.promoted:
            return False

        source = str((state.metadata or {}).get("source") or "").strip().lower()
        physical_ingress = str((state.metadata or {}).get("physical_ingress") or "").strip().lower()
        if "a2a_task" in {source, physical_ingress}:
            # A2A task carriers already have their own long-running protocol:
            # the executor keeps the carrier open with task.progress heartbeats,
            # and the final carrier response is what the Gateway converts into
            # task.progress(done). Promoting here would resolve the carrier with
            # the background-task receipt and strand the real result locally.
            logger.debug(
                "event_loop.degrade_inline reason=a2a_task_protocol main={} tool_batches={}",
                state.session_id,
                state.tool_batches,
            )
            return False
        if source not in self._event_loop_promotion_channels:
            return False

        # Trigger evaluation (logical OR). 0 disables a trigger entirely.
        count_fired = (
            self._main_turn_tool_budget > 0 and state.tool_batches >= self._main_turn_tool_budget
        )
        elapsed = 0.0
        if state.started_monotonic is not None:
            elapsed = max(0.0, time.monotonic() - state.started_monotonic)
        time_fired = self._wall_clock_promote_s > 0 and elapsed >= self._wall_clock_promote_s
        if not (count_fired or time_fired):
            return False

        manager = self._bg_task_manager
        if manager is None:
            # Promotion configured but runtime never wired the manager; legacy
            # inline path is the only safe choice.
            logger.warning(
                "event_loop.degrade_inline reason={} main={} tool_batches={}",
                "no_manager",
                state.session_id,
                state.tool_batches,
            )
            return False

        # Cap pre-check BEFORE any mutation of the main session (D-cap: "no
        # corruption path"). ``adopt`` repeats the check internally for thread
        # safety, but checking first means a refused promotion leaves no
        # side-effect on main.
        if manager.pending_count >= manager._max_tasks:
            logger.warning(
                "event_loop.degrade_inline reason={} main={} pending={} cap={}",
                "worker_cap",
                state.session_id,
                manager.pending_count,
                manager._max_tasks,
            )
            return False

        trigger = "count" if count_fired else "time"
        return await self._promote_turn_to_worker(state, manager, trigger=trigger, elapsed=elapsed)

    async def _promote_turn_to_worker(
        self,
        state: _TurnState,
        manager: BackgroundTaskManager,
        *,
        trigger: str,
        elapsed: float,
    ) -> bool:
        """Execute the 9-step promotion (see §02 §2.3).

        Returns ``True`` on success (caller should early-return with the
        receipt sentinel), ``False`` when the underlying ``adopt`` refused
        (e.g. the manager closed between pre-check and call) — in which case
        any main-session pruning has been REVERTED and the loop continues
        inline as if no promotion was attempted.
        """
        main_session = state.session_id  # keep BEFORE swap — needed for logs / owner / fold-back
        pruned_rowids = list(state.turn_rowids)  # snapshot; turn_rowids will be reset below

        try:
            # 2. fork → worker session row (parent_session_id FK keeps lineage).
            worker = await self._session_store.fork(main_session)
            # 3. seed worker from MAIN's durable rows (already #394-clean).
            snapshot = await self._session_store.get_messages(main_session)
            await self._session_store.replace_messages(worker, snapshot)
            # 4. capture the in-flight rows BEFORE pruning — needed only on
            #    the cap-race rollback path below. ``adopt()`` is in-process,
            #    so the window between this capture and the eventual restore
            #    is microseconds; we never see stale content here.
            pruned_messages: list[tuple[int, dict[str, Any], str | None]] = (
                await self._session_store.get_messages_by_rowids(main_session, pruned_rowids)
                if pruned_rowids
                else []
            )
            # 5. prune in-flight tool pairs from MAIN (delete_messages is the
            #    new primitive from Step B; an empty rowid list is a no-op).
            pruned_n = 0
            if pruned_rowids:
                pruned_n = await self._session_store.delete_messages(main_session, pruned_rowids)
        except Exception as exc:  # noqa: BLE001 — promotion is best-effort
            logger.error(
                "event_loop.promote_failed main={} reason={}",
                main_session,
                exc,
            )
            return False

        # 5/6. Defer the state mutations (``state.session_id = worker`` etc.)
        # to AFTER ``adopt()`` succeeds. The pre-fix code mutated state before
        # adopt and relied on the cap-race rollback path to put it back, but
        # that left two failure modes uncovered:
        #   • ``CancelledError`` mid-rollback leaks past ``except Exception``
        #     (Python 3.11+ has it as a ``BaseException`` subclass) so state
        #     could end up permanently swapped to the worker session.
        #   • A partial rollback (one ``add_message`` raised) wrote a partial
        #     ``restored_rowids`` into ``state.turn_rowids`` even though we
        #     had set ``state.turn_rowids = []`` upfront — losing the
        #     un-restored portion silently.
        # By only swapping state once adopt has actually accepted the worker,
        # the rollback path is a pure cleanup of MAIN sqlite rows and any
        # cancellation in the meantime leaves the in-memory turn state on
        # MAIN as if no promotion was attempted.

        # 7. adopt the continuation into the background lifecycle (timeout,
        # done-callback, proactive delivery). Cap pre-check above keeps us
        # from the rare "pruned but no slot" hazard.
        from praestoclaw.host.background_tasks import BackgroundOrigin

        origin = BackgroundOrigin(
            channel=ChannelType.of(str(state.channel)) if state.channel else ChannelType.CLI,
            channel_id=state.channel_id or main_session,
            thread_id=state.thread_id,
            route_hint=state.route_hint,
            # Freeze the originating Teams conversation id so the fold-back
            # lands in the originating chat even after the route is forgotten
            # (issue #473). Present only for Teams turns; None elsewhere.
            # Strip so a whitespace-only cid coerces to None rather than a
            # truthy blank delivery key.
            teams_conversation_id=str((state.metadata or {}).get("cid") or "").strip() or None,
        )

        # ``_drive_turn`` returns ``(response_text, streamed)``; ``adopt``'s
        # coro_factory is typed as ``Callable[[], Awaitable[str]]`` because
        # ``BackgroundTask.result`` is the human-readable text that the
        # delivery / fold-back paths consume. The ``streamed`` flag is
        # turn-internal and not interesting once the worker is detached
        # (its eventual output is delivered proactively, never streamed),
        # so we strip it here. The closure captures ``state`` by reference;
        # we set ``state.session_id = worker`` AFTER ``adopt()`` returns
        # non-None but BEFORE the next ``await`` yield point, which is the
        # earliest moment ``_worker_run`` could be scheduled to run — so the
        # worker always sees ``session_id == worker`` when it re-enters
        # ``_drive_turn``.
        async def _worker_run(s: _TurnState = state) -> str:
            response_text, _streamed = await self._drive_turn(s)
            return response_text

        # Resolve the carrier receipt (and advance the adaptive ramp counter)
        # BEFORE ``adopt`` so every await on the promotion path runs pre-adopt.
        # ``adopt`` itself is synchronous and the caller does not await again
        # before inspecting worker state, so the worker is not scheduled until
        # then — tests (and the #181 carrier contract) rely on this ordering.
        # On the rare cap-race rollback below (``task_id is None``) the receipt
        # is simply unused; the ramp counter may advance by one, which is
        # harmless for a best-effort UX ramp.
        state.promoted_receipt = await self._render_promoted_receipt(state)

        task_id = manager.adopt(
            coro_factory=_worker_run,
            origin=origin,
            owner=main_session,
            question=state.user_message,
            label="promoted",
        )
        if task_id is None:
            # Race: cap filled between pre-check and adopt. MAIN was already
            # mutated by the pre-adopt snapshot/prune block above; we MUST
            # roll the prune back, otherwise the inline final-persist below
            # leaves a hole in durable history (the LLM sees its own answer
            # land on a session whose tool_use/tool_result rows have just
            # been deleted, and the assistant can't reason about a chain it
            # no longer sees). Reinsert each captured row in original order;
            # the `created_at` is preserved so forensic timelines stay intact
            # (matches the `replace_messages` pattern). New rowids are written
            # back into ``state.turn_rowids`` so any subsequent ``state``
            # mutation (e.g. final-persist appending its own rowid) treats
            # this turn as fully owned by MAIN again.
            #
            # On per-row failure, ``continue`` (not ``break``) so we attempt
            # every remaining row — losing 1 row to a transient store error
            # is better than losing 1 + everything that came after.
            restored_rowids: list[int] = []
            for _orig_rowid, msg, created_at in pruned_messages:
                try:
                    new_rowid = await self._session_store.add_message(
                        main_session, msg, created_at=created_at
                    )
                except Exception as exc:  # noqa: BLE001 — best-effort, but log loudly
                    logger.error(
                        "event_loop.cap_race_restore_failed main={} reason={}",
                        main_session,
                        exc,
                    )
                    continue
                if isinstance(new_rowid, int):
                    restored_rowids.append(new_rowid)
            if len(restored_rowids) < len(pruned_messages):
                # Partial restore is a serious operational signal — the
                # store rejected at least one row mid-rollback, leaving
                # MAIN with a hole the operator should investigate.
                logger.error(
                    "event_loop.cap_race_restore_partial main={} expected={} restored={}",
                    main_session,
                    len(pruned_messages),
                    len(restored_rowids),
                )
            logger.warning(
                "event_loop.degrade_inline reason={} main={} worker={} "
                "pruned_n={} restored_n={} "
                "note=cap_filled_between_precheck_and_adopt",
                "worker_cap_race",
                main_session,
                worker,
                pruned_n,
                len(restored_rowids),
            )
            # State was never swapped to the worker (we deferred the swap
            # until after ``adopt()`` succeeded). The caller continues inline
            # on MAIN with ``state.turn_rowids`` rebuilt from whatever rows
            # we successfully re-inserted. The worker session is left behind
            # as a benign forked row.
            state.turn_rowids = restored_rowids
            return False

        # adopt succeeded — NOW swap the state to the worker session.
        state.session_id = worker
        state.promoted = True
        state.turn_rowids = []

        # 8. stash the channel's ↩️ quote (fold-back path consumes it).
        self._stash_promotion_quote(state)

        # 9. Plan A — orphan-prevention ack row.
        # Promotion's load-bearing invariant ("main only contains complete
        # turns") used to be violated for the model's view of the world: a
        # promoted turn left main ending on an answer-less ``user-A`` row,
        # and the LLM on the next turn read that as "I still owe an answer
        # to A" → it kept running A's tool chain. The prod incident
        # (2026-06-14 11:21–11:28) showed this as 3 workers redoing the
        # same ADO query.
        #
        # Plan A fixes it by appending ONE ``role=assistant`` row whose
        # content begins with ``[BG task=<id>]`` — a stable, machine-
        # readable sentinel telling the model "this user request was
        # handed off; do NOT continue it". Properties:
        #   • role=assistant, no tool_calls → no #345 anti-pattern
        #   • carries the real ``task_id`` so future compaction / startup-
        #     reaper logic can correlate the row with a (live | dead) task
        #   • UX text on the carrier (``_pick_long_task_placeholder`` +
        #     ↩️ quote) is unchanged — the ack row is for the LLM's view
        #     of durable history, the placeholder is for the human's view
        #     of the conversation
        # Append AFTER ``adopt`` so the row is only written once a worker
        # genuinely owns the task. If the row write itself fails we log
        # and continue — the worker is already adopted, the channel
        # delivery still works, the only loss is orphan-prevention on
        # this one turn.
        try:
            ack_row = self._build_promotion_ack_row(state, task_id)
            await self._session_store.add_message(main_session, ack_row)
        except Exception as exc:  # noqa: BLE001 — ack write is best-effort
            logger.warning(
                "event_loop.ack_write_failed main={} task_id={} reason={}",
                main_session,
                task_id,
                exc,
            )

        logger.info(
            "event_loop.promote main={} worker={} task_id={} trigger={} "
            "tool_batches={} pruned_rowids_n={} elapsed_s={:.2f}",
            main_session,
            worker,
            task_id,
            trigger,
            state.tool_batches,
            pruned_n,
            elapsed,
        )
        logger.info(
            "event_loop.adopt task_id={} owner={} lane=subagent",
            task_id,
            main_session,
        )
        return True

    def _stash_promotion_quote(self, state: _TurnState) -> None:
        """Best-effort stash of the user's question into the channel quote map.

        The cloud channel's ``_remember_timeout_quote`` maps a request_id →
        original user text; when a late proactive reply is sent, ``send()``
        pops the entry and prefixes the answer with ``↩️ Re your earlier
        question "…"``. Step F wires the fold-back path through this map; we
        seed it here at promotion so the bookkeeping is done while the
        question is still in hand.

        Resolution order:
          1. ``self._channel_resolver(state.channel)`` — runtime-injected
             ``channel_manager.get``. This is the production path: it returns
             the real ``CloudChannel`` instance whose
             ``_remember_timeout_quote`` actually accepts the entry.
          2. ``state.channel`` directly — only useful when callers pass a
             channel *instance* (legacy / some tests). When ``state.channel``
             is a ``ChannelType`` enum (the typical case), ``getattr`` returns
             ``None`` and the stash silently no-ops, which is exactly the prod
             2026-06-14 13:07 regression — the helper looked plausible but
             never reached the channel and every fold-back lost its ↩️
             envelope. Keep the fallback for legacy callers but rely on the
             resolver for production correctness.
        """
        channel_id = state.channel_id
        if not channel_id:
            return
        target: Any = None
        if self._channel_resolver is not None and state.channel is not None:
            try:
                target = self._channel_resolver(state.channel)
            except Exception as exc:  # noqa: BLE001 — resolver lookup is non-essential
                logger.debug("event_loop.channel_resolver_failed: {}", exc)
                target = None
        if target is None:
            target = state.channel
        if target is None:
            return
        helper = getattr(target, "_remember_timeout_quote", None)
        if helper is None:
            return
        try:
            helper(channel_id, state.user_message)
        except Exception as exc:  # noqa: BLE001 — quote stash is non-essential
            logger.debug("event_loop.quote_stash_failed: {}", exc)

    async def _render_promoted_receipt(self, state: _TurnState) -> str:
        """Build the carrier-visible "I'm working on it" placeholder.

        Verbosity follows ``ExecutionConfig.background_task_receipt``:

        * ``"adaptive"`` (default) — ramp down per user: full for the first
          ``_ADAPTIVE_FULL_LIMIT`` promotions, minimal up to
          ``_ADAPTIVE_MINIMAL_LIMIT`` (cumulative), then silent. The count is
          durable per user (``SessionStore`` ``counters``).
        * ``"full"`` — always the complete educational handoff copy.
        * ``"minimal"`` — always a terse one-liner.
        * ``"silent"`` — empty string; no visible receipt is posted (the
          carrier reply is empty, which the Teams bridge renders as
          "nothing to post"). The user only sees the eventual fold-back.

        Bilingual (zh / en) heuristic mirrors the cloud channel's
        ``_pick_long_task_placeholder`` so the user sees a consistent voice
        whether the receipt is rendered here (promotion) or there (legacy
        carrier timeout). Returned to the caller as the receipt; it is NEVER
        persisted to the main session (D-receipt).

        NOTE: the returned text is intentionally NOT the signal used to set
        ``is_promotion_receipt`` downstream — that flag is keyed on
        ``_promotion_receipt_routes`` so it survives the empty ``"silent"``
        body and any future copy change. Called once per promotion ATTEMPT,
        BEFORE ``adopt()`` (the call site resolves the receipt pre-adopt so
        every await on the promotion path runs before the worker is
        scheduled). On the rare cap-race rollback (``adopt`` returns ``None``)
        the rendered receipt goes unused and the adaptive ramp counter may
        advance by one — an accepted, harmless over-count for a best-effort
        UX ramp.
        """
        mode: str = self._background_task_receipt
        if mode == "adaptive":
            mode = await self._resolve_adaptive_receipt_mode(state)
        if mode == "silent":
            return ""
        is_zh = contains_cjk(state.user_message or "")
        if mode == "minimal":
            return _PROMOTED_RECEIPT_MINIMAL_ZH if is_zh else _PROMOTED_RECEIPT_MINIMAL_EN
        return _PROMOTED_RECEIPT_ZH if is_zh else _PROMOTED_RECEIPT_EN

    async def _resolve_adaptive_receipt_mode(self, state: _TurnState) -> str:
        """Resolve the adaptive ramp to a concrete mode for THIS promotion.

        Increments a durable per-user counter and maps it:
        ``1..N`` → full, ``N+1..M`` → minimal, ``>M`` → silent (N/M are
        ``_ADAPTIVE_FULL_LIMIT`` / ``_ADAPTIVE_MINIMAL_LIMIT``). The user key is
        the session's ``sender`` (stable identity); if it can't be resolved or
        the store errors, we fail safe to ``"full"`` (the most informative copy)
        rather than silently dropping the receipt.
        """
        try:
            sender = await self._session_store.get_session_sender(state.session_id)
            user_key = sender or state.session_id
            count = await self._session_store.increment_counter(f"promotion_receipt:{user_key}")
        except Exception as exc:  # noqa: BLE001 — adaptive ramp is best-effort
            logger.debug("event_loop.adaptive_receipt_count_failed: {}", exc)
            return "full"
        if count <= _ADAPTIVE_FULL_LIMIT:
            return "full"
        if count <= _ADAPTIVE_MINIMAL_LIMIT:
            return "minimal"
        return "silent"

    @staticmethod
    def _build_promotion_ack_row(state: _TurnState, task_id: str) -> dict[str, Any]:
        """Build the orphan-prevention ack row appended to main at promotion.

        See ``_PROMOTION_ACK_SENTINEL_PREFIX`` for the contract: the row's
        ``content`` begins with ``[BG task=<task_id>]`` so the LLM (and
        downstream sanitizers / compactors) can identify it. zh/en branch
        is keyed by the question's CJK content (mirrors
        ``_render_promoted_receipt`` and ``_prefix_reply_quote``).
        """
        question = state.user_message or ""
        snippet = truncate_ellipsis(question.strip(), REPLY_QUOTE_SNIPPET_MAX)
        is_zh = contains_cjk(question)
        template = _PROMOTION_ACK_TEMPLATE_ZH if is_zh else _PROMOTION_ACK_TEMPLATE_EN
        content = template.format(
            sentinel=_PROMOTION_ACK_SENTINEL_PREFIX,
            task_id=task_id,
            snippet=snippet,
        )
        return {"role": "assistant", "content": content}

    # ── Helpers ──────────────────────────────────────────────────────────

    async def _call_llm(
        self,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None,
        *,
        channel: Any = None,
        channel_id: str | None = None,
    ) -> tuple[LLMResponse, bool]:
        """Call provider — complete() when tools enabled, stream() for text-only.

        Returns (LLMResponse, final_delivered) where final_delivered is True
        only when ALL streaming chunks AND the done=True marker were successfully
        dispatched to a non-CLI channel. If any dispatch fails or if the stream
        errors mid-way, final_delivered is False and the caller should send a
        full OutboundMessage as fallback.

        The done marker is always sent in a finally block.
        """
        # Forward the agent's configured reasoning_effort (e.g. "high" thinking)
        # to the provider. Providers/models that don't support it ignore the value.
        reasoning_effort = getattr(self._config, "reasoning_effort", None)
        if tools:
            return await self._provider.complete(
                model=model,
                messages=messages,
                tools=tools,
                reasoning_effort=reasoning_effort,
            ), False

        # Streaming for text-only responses
        content_parts: list[str] = []
        finish_reason = "stop"
        any_chunk_sent = False
        any_dispatch_failed = False
        done_dispatched = False
        stream_error = False

        try:
            async for chunk in self._provider.stream(
                model=model,
                messages=messages,
                tools=None,
                reasoning_effort=reasoning_effort,
            ):
                if chunk.content:
                    content_parts.append(chunk.content)
                    if channel and channel_id and channel != ChannelType.CLI:
                        try:
                            delivered = await self._reply_dispatcher.publish_stream_chunk(
                                channel=channel,
                                channel_id=channel_id or "",
                                content=chunk.content,
                                done=False,
                            )
                            if delivered:
                                any_chunk_sent = True
                            else:
                                any_dispatch_failed = True
                        except Exception:
                            any_dispatch_failed = True
                if chunk.finish_reason:
                    finish_reason = chunk.finish_reason
        except Exception:
            stream_error = True
            raise
        finally:
            if any_chunk_sent:
                try:
                    done_dispatched = await self._reply_dispatcher.publish_stream_chunk(
                        channel=channel,
                        channel_id=channel_id or "",
                        content="",
                        done=True,
                    )
                    if not done_dispatched:
                        any_dispatch_failed = True
                except Exception:
                    any_dispatch_failed = True

        # final_delivered = all chunks sent successfully + done marker sent + no errors
        response_content = "".join(content_parts)
        final_delivered = (
            any_chunk_sent
            and done_dispatched
            and bool(response_content.strip())
            and not any_dispatch_failed
            and not stream_error
        )

        return LLMResponse(
            content=response_content,
            finish_reason=finish_reason,
            model=model,
        ), final_delivered

    # ── Context assembly ──────────────────────────────────────────────────
    #
    # Delegates to PromptBuilder (praestoclaw/agent/prompt_builder.py).
    # See that module's docstring for the full build order.
    #

    def _build_system_prompt(self) -> str:
        """Assemble the system prompt via PromptBuilder."""
        return self._prompt_builder.build_system_prompt(mode=self._prompt_mode)

    def _build_attachment_context(self, metadata: dict[str, Any] | None) -> str:
        if not _has_pending_attachments(metadata):
            return ""
        refs = _AttachmentResolver().list_current(metadata)
        if not refs:
            return ""

        pending_images = (metadata or {}).get("pending_images") or {}
        errors = pending_images.get("errors") if isinstance(pending_images, dict) else []
        image_urls = pending_images.get("urls") if isinstance(pending_images, dict) else []
        prompt_safe_image_urls: set[str] = (
            {url.strip() for url in image_urls if isinstance(url, str) and url.strip()}
            if isinstance(image_urls, list)
            else set()
        )
        has_successful_image_url = bool(prompt_safe_image_urls)
        err_note = (
            f" ({len(errors)} image upload(s) failed)"
            if errors and not has_successful_image_url
            else ""
        )
        lines = [
            f"[attachments: {len(refs)} file(s)/image(s) attached by user; "
            f"use attachment_process if attachment content is needed{err_note}]"
        ]
        for ref in refs:
            bits = [f"{ref.index}. {ref.kind}"]
            if ref.name:
                bits.append(f"name={ref.name}")
            if ref.file_type:
                bits.append(f"file_type={ref.file_type}")
            if ref.content_type:
                bits.append(f"content_type={ref.content_type}")
            # Only surface URLs that were republished via the public image host
            # (i.e. present in pending_images.urls). Raw Teams/SharePoint signed
            # URLs stay hidden — the model can still read content via
            # attachment_process. See PR #325 review comment.
            if ref.kind == "image" and not ref.requires_auth and ref.url in prompt_safe_image_urls:
                bits.append(f"url={ref.url}")
            else:
                bits.append("url=hidden; available via attachment_process")
            lines.append("  - " + "; ".join(bits))
        return "\n".join(lines)

    def _assemble_messages(
        self,
        system: str,
        history: list[dict[str, Any]],
        user_msg: dict[str, Any],
    ) -> list[dict[str, Any]]:
        # Filter session history to LLM-acceptable roles only. Non-LLM
        # records (``approval_request`` / ``approval_resolved`` and other
        # UI-only metadata) live in the session JSONL so the Web UI can
        # render them, but they MUST NOT be sent to the model:
        #
        #   - OpenAI/compatible providers reject unknown roles outright.
        #   - Other SDKs silently coerce unknown roles to "user", which
        #     plants the raw approval JSON (including ``resolved_card``,
        #     adaptive-card body, agent reasoning) into the model's
        #     context. The model then echoes / paraphrases that JSON in
        #     its next reply, which surfaces in Teams as a ~2 KB blob of
        #     plain text alongside the resolved card. See issue #84.
        #
        # ``is_error`` is dropped only for ``role == "user"`` (UI-only
        # echoes of failed user messages). Tool error results are kept:
        # the model needs to see prior tool failures to recover.
        from praestoclaw.session.manager import SessionManager

        history = [
            m
            for m in history
            if m.get("role") in SessionManager.LLM_ROLES
            and not (m.get("role") == "user" and m.get("is_error"))
        ]
        messages = [{"role": "system", "content": system}, *history, user_msg]
        return sanitize_tool_messages(messages)

    def _get_tool_schemas(
        self,
        exclude_tools: list[str] | None = None,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]] | None:
        allowed = self._config.tools or None
        # Per-agent memory_writable enforcement
        exclude = list(exclude_tools or [])
        if not getattr(self._config, "memory_writable", True):
            exclude.append("memory")
        if not _has_pending_attachments(metadata):
            exclude.append("attachment_process")
        exact_exclude = [name for name in exclude if not name.endswith("*")]
        schemas = self._tool_registry.get_schemas(allowed, exclude=exact_exclude or None)
        schemas = [
            schema
            for schema in schemas
            if not self._tool_excluded(
                str(schema.get("function", {}).get("name", "")),
                exclude,
            )
        ]
        if not schemas:
            return None
        return list(schemas)

    @staticmethod
    def _metadata_for_tool(
        tool_name: str,
        metadata: dict[str, Any] | None,
    ) -> dict[str, Any] | None:
        """Return the tool-visible metadata view for one tool call.

        Attachment URLs are runtime-private adapter data. Only
        ``attachment_process`` receives them; other tools receive provenance
        and control metadata without current-turn attachment URL payloads.
        """
        if metadata is None:
            return None
        if tool_name == "attachment_process":
            return metadata
        return {
            key: value
            for key, value in metadata.items()
            if key not in {"pending_images", "pending_attachments"}
        }

    @staticmethod
    def _tool_excluded(name: str, exclude_tools: list[str] | None) -> bool:
        for pattern in exclude_tools or []:
            if pattern.endswith("*") and name.startswith(pattern[:-1]):
                return True
            if name == pattern:
                return True
        return False

    def _resolve_context_limit(self) -> int:
        return self._config.context_limit or _DEFAULT_CONTEXT_LIMIT

    def _response_to_message(self, response: LLMResponse) -> dict[str, Any]:
        msg: dict[str, Any] = {"role": "assistant"}
        if response.content:
            msg["content"] = response.content
        if response.tool_calls:
            msg["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.name,
                        "arguments": json.dumps(tc.arguments, ensure_ascii=False)
                        if isinstance(tc.arguments, dict)
                        else tc.arguments,
                    },
                }
                for tc in response.tool_calls
            ]
        return msg

    async def _preflight_tool_call(
        self,
        tc: ToolCallRequest,
        *,
        session_id: str | None,
        channel: Any,
        channel_id: str | None,
        metadata: dict[str, Any] | None,
        exclude_tools: list[str] | None,
        user_message: str = "",
    ) -> tuple[str | None, str | None]:
        """Shared execution gate for model and runtime-initiated tool calls."""
        allowed_tools = self._resolve_allowed_tools(exclude_tools)

        if allowed_tools is not None and tc.name not in allowed_tools:
            logger.warning("Tool '{}' blocked by allowlist at execution time", tc.name)
            if self._audit:
                self._audit.log_security(
                    event="tool_blocked_by_allowlist",
                    details={"tool": tc.name, "session_id": session_id},
                    severity="warning",
                )
            return (
                "allowlist",
                f"Tool '{tc.name}' is not available for this agent. Do NOT retry this tool.",
            )

        if tc.name == "memory" and not getattr(self._config, "memory_writable", True):
            logger.warning("Memory tool blocked: memory_writable=false")
            return (
                "memory_writable",
                "Memory writes are disabled for this agent (memory_writable=false).",
            )

        if self._hooks:
            _tool = (
                self._tool_registry.get(tc.name) if hasattr(self._tool_registry, "get") else None
            )
            _user_msgs: list[str] = [user_message] if user_message else []
            if not _user_msgs and session_id:
                try:
                    _all = await self._session_store.get_messages(session_id)
                    _user_msgs = [
                        m["content"] for m in _all if m.get("role") == "user" and m.get("content")
                    ][-3:]
                except Exception:
                    pass
            _user_msgs = [redact_credentials(m) for m in _user_msgs]

            tool_metadata = self._metadata_for_tool(tc.name, metadata)
            pre_ctx = PreToolHookContext(
                tool_name=tc.name,
                args=tc.arguments,
                agent_name=self._config.name,
                session_id=session_id or "",
                tool_call_id=tc.id,
                tool_ref=_tool,
                channel=channel if isinstance(channel, ChannelType) else None,
                channel_id=str(channel_id or ""),
                user_messages=_user_msgs,
                metadata=tool_metadata or {},
            )
            pre_result = await self._hooks.dispatch_checked("pre_tool_use", pre_ctx)
            if pre_result.verdict == HookVerdict.REJECT:
                logger.warning("Tool '{}' blocked by hook: {}", tc.name, pre_result.reason)
                return (
                    "hook_reject",
                    f"Tool '{tc.name}' blocked by security policy: {pre_result.reason}\n"
                    "Do NOT retry this tool. Inform the user it was blocked.",
                )

        return None, None

    async def _execute_internal_tool_call(
        self,
        tc: ToolCallRequest,
        *,
        session_id: str | None = None,
        plan_session_id: str | None = None,
        channel: Any = None,
        channel_id: str | None = None,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        exclude_tools: list[str] | None = None,
        user_message: str = "",
    ) -> str | None:
        """Execute a runtime-created tool call after the normal safety gates."""
        blocked_by, block_message = await self._preflight_tool_call(
            tc,
            session_id=session_id,
            channel=channel,
            channel_id=channel_id,
            metadata=metadata,
            exclude_tools=exclude_tools,
            user_message=user_message,
        )
        if blocked_by is not None:
            logger.debug(
                "event_loop.internal_tool skipped tool={} reason={} message={}",
                tc.name,
                blocked_by,
                truncate_ellipsis(block_message or "", 200),
            )
            return None

        exec_args = dict(tc.arguments)
        async with tool_resource_lock(tc.name, exec_args, workspace=self._workspace):
            result: str = await self._tool_registry.execute(
                tc.name,
                exec_args,
                actor="agent",
                session_id=session_id,
                plan_session_id=plan_session_id,
                bus=self._bus,
                channel=channel,
                channel_id=channel_id,
                thread_id=thread_id,
                metadata=self._metadata_for_tool(tc.name, metadata),
                tool_call_id=tc.id,
            )
        return result

    async def _execute_tools(
        self,
        tool_calls: list[ToolCallRequest],
        *,
        session_id: str | None = None,
        plan_session_id: str | None = None,
        channel: Any = None,
        channel_id: str | None = None,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        exclude_tools: list[str] | None = None,
        user_message: str = "",
    ) -> list[tuple[ToolCallRequest, str]]:
        """IronClaw 3-phase tool execution pipeline.

        Phase 1 (Preflight, sequential): allowlist enforcement + pre_tool_use hooks
        Phase 2 (Execute, parallel when safe): actual tool invocation
        Phase 3 (Postflight, sequential): post_tool_use hooks → redaction → truncation
        """
        import time

        # Telemetry ids set by ChannelTurnKernel and threaded through metadata.
        _telemetry_turn_id: str | None = None
        _telemetry_session_id: str | None = None
        if isinstance(metadata, dict):
            _val = metadata.get("telemetry_turn_id")
            if isinstance(_val, str) and _val:
                _telemetry_turn_id = _val
            _val = metadata.get("telemetry_session_id")
            if isinstance(_val, str) and _val:
                _telemetry_session_id = _val

        # Phase 1: Preflight — enforce allowlist + pre_tool_use hooks (sequential)
        approved: list[tuple[ToolCallRequest, str | None]] = []  # (tc, blocked_by or None)
        preflight_results: dict[str, str] = {}  # tc.id → error msg for blocked tools

        for tc in tool_calls:
            logger.info("Tool call: {}({})", tc.name, list(tc.arguments.keys()))
            blocked_by, block_message = await self._preflight_tool_call(
                tc,
                session_id=session_id,
                channel=channel,
                channel_id=channel_id,
                metadata=metadata,
                exclude_tools=exclude_tools,
                user_message=user_message,
            )
            if blocked_by is not None and block_message is not None:
                preflight_results[tc.id] = block_message
            approved.append((tc, blocked_by))

        # Phase 2: Execute — parallel for independent tools
        async def _exec_one(tc: ToolCallRequest) -> str:
            tool_start = time.monotonic()
            try:
                # Copy args to prevent ToolRegistry.execute() from mutating
                # the original tc.arguments (it injects _channel, _metadata etc.)
                # which would pollute loop detection arg comparison and tracing.
                exec_args = dict(tc.arguments)
                if tc.name == "attachment_process":
                    exec_args["_user_message"] = user_message
                    exec_args["_model"] = self._config.model
                async with tool_resource_lock(tc.name, exec_args, workspace=self._workspace):
                    result: str = await self._tool_registry.execute(
                        tc.name,
                        exec_args,
                        actor="agent",
                        session_id=session_id,
                        plan_session_id=plan_session_id,
                        bus=self._bus,
                        channel=channel,
                        channel_id=channel_id,
                        thread_id=thread_id,
                        metadata=self._metadata_for_tool(tc.name, metadata),
                        tool_call_id=tc.id,
                    )
                _emit_tool_invoked(
                    tool_name=tc.name,
                    duration_ms=int((time.monotonic() - tool_start) * 1000),
                    success=not _is_tool_error_result(result),
                    turn_id=_telemetry_turn_id,
                    session_id=_telemetry_session_id,
                )
                return result
            except Exception as e:
                logger.error("Tool {} failed: {}", tc.name, e)
                _emit_tool_invoked(
                    tool_name=tc.name,
                    duration_ms=int((time.monotonic() - tool_start) * 1000),
                    success=False,
                    turn_id=_telemetry_turn_id,
                    session_id=_telemetry_session_id,
                )
                return f"Error: {e}"

        runnable = [tc for tc, blocked_by in approved if blocked_by is None]
        # Emit a tool_invoked row for every preflight-blocked tool so the
        # blocked_by dimension shows up in dashboards (success=false implicit).
        for tc, blocked_by in approved:
            if blocked_by is not None:
                _emit_tool_invoked(
                    tool_name=tc.name,
                    duration_ms=0,
                    success=False,
                    blocked_by=blocked_by,
                    turn_id=_telemetry_turn_id,
                    session_id=_telemetry_session_id,
                )
        exec_results: dict[str, tuple[str, float]] = {}  # tc.id → (result, duration_ms)

        if runnable:
            exec_start = time.monotonic()
            raw_results = await self._parallelizer.execute_batch(runnable, _exec_one)
            duration = (time.monotonic() - exec_start) * 1000
            per_tool_ms = duration / len(runnable) if runnable else 0
            for tc_id, result_str in raw_results:
                exec_results[tc_id] = (result_str, per_tool_ms)

        # Phase 3: Postflight — post_tool_use hooks → redaction → truncation (sequential)
        final_results: list[tuple[ToolCallRequest, str]] = []

        for tc, blocked_by in approved:
            if blocked_by is not None:
                final_results.append(
                    (tc, preflight_results.get(tc.id, f"Tool '{tc.name}' blocked."))
                )
                continue

            result, duration_ms = exec_results.get(tc.id, ("", 0.0))

            # post_tool_use hook BEFORE redaction (leak scanner needs raw output)
            if self._hooks:
                post_ctx = PostToolHookContext(
                    tool_name=tc.name,
                    args=tc.arguments,
                    result=result,
                    success=not _is_tool_error_result(result),
                    agent_name=self._config.name,
                    session_id=session_id or "",
                    tool_call_id=tc.id,
                    duration_ms=duration_ms,
                    channel=channel if isinstance(channel, ChannelType) else None,
                    channel_id=str(channel_id or ""),
                    metadata=metadata or {},
                )
                hook_result = await self._hooks.dispatch_checked("post_tool_use", post_ctx)
                if hook_result.data and isinstance(hook_result.data, PostToolHookContext):
                    result = hook_result.data.result

            # Redact secrets AFTER hooks inspected raw output
            result = Sanitizer.redact_env_values(result)

            # Unified truncation
            tool_obj = (
                self._tool_registry.get(tc.name) if hasattr(self._tool_registry, "get") else None
            )
            tool_max = getattr(getattr(tool_obj, "metadata", None), "max_output_chars", 0)
            output_cfg = (
                self._tool_registry.output_config
                if hasattr(self._tool_registry, "output_config")
                else None
            )
            max_chars = tool_max if tool_max > 0 else (getattr(output_cfg, "max_chars", 50_000))
            llm_enabled = (
                getattr(output_cfg, "llm_compression_enabled", True) if output_cfg else True
            )
            result = await truncate_tool_output(
                content=result,
                tool_name=tc.name,
                max_chars=max_chars,
                provider=self._provider,
                llm_enabled=llm_enabled,
                tool_args=tc.arguments,
            )

            final_results.append((tc, result))

        return final_results

    def _resolve_allowed_tools(self, exclude_tools: list[str] | None = None) -> set[str] | None:
        """Build the effective allowed tool set for runtime enforcement.

        Returns None if all tools are allowed, otherwise a set of allowed names.
        """
        # Start with agent config allowlist
        config_tools = self._config.tools
        if config_tools is None or (isinstance(config_tools, list) and not config_tools):
            # None or empty list = all tools allowed
            allowed: set[str] | None = None
        else:
            allowed = set(config_tools)

        # Apply exclude_tools
        if exclude_tools and allowed is not None:
            allowed = {name for name in allowed if not self._tool_excluded(name, exclude_tools)}
        elif exclude_tools and allowed is None:
            # All tools minus excluded — get full list from registry
            schemas = self._tool_registry.get_schemas()
            all_names = {s.get("function", {}).get("name", "") for s in schemas}
            allowed = {name for name in all_names if not self._tool_excluded(name, exclude_tools)}

        return allowed

    async def _flush_memories_before_compression(
        self,
        messages: list[dict[str, Any]],
        session_id: str,
        *,
        channel: Any = None,
        channel_id: str | None = None,
    ) -> None:
        """Pre-compression memory flush (Hermes-style).

        Give the agent one LLM call with only the memory tool to save
        important findings before context is compressed and older messages
        are lost. Only fires if the conversation has enough user turns
        to have generated meaningful content.
        """
        if not self._memory:
            return
        # Only flush if there's been meaningful conversation (>= 6 user turns)
        user_turns = sum(1 for m in messages if m.get("role") == "user")
        if user_turns < 6:
            return

        flush_msg = {
            "role": "system",
            "content": (
                "[System: The session context is being compressed. "
                "Save anything worth remembering — prioritize user preferences, "
                "corrections, and recurring patterns over task-specific details.]"
            ),
        }
        try:
            # Build a minimal message list with only memory tool
            flush_messages = messages + [flush_msg]
            memory_schema = self._tool_registry.get_schemas(["memory"])
            if not memory_schema:
                return
            response, _ = await self._call_llm(
                self._config.model,
                flush_messages,
                list(memory_schema),
                channel=channel,
                channel_id=channel_id,
            )
            # Execute any memory tool calls from the flush response
            if response.tool_calls:
                results = await self._execute_tools(
                    response.tool_calls,
                    session_id=session_id,
                    channel=channel,
                    channel_id=channel_id,
                )
                logger.info(
                    "Pre-compression flush: {} memory tool call(s)",
                    len(results),
                )
            # Don't append flush artifacts to the conversation —
            # they would be compressed away immediately anyway
        except Exception as exc:
            logger.debug("Pre-compression flush failed: {}", exc)

    async def _persist_compacted(self, session_id: str, messages: list[dict[str, Any]]) -> None:
        """Persist compacted messages.

        Strips ephemeral system messages (the base prompt is rebuilt by
        :meth:`_assemble_messages` on every turn, so persisting it would
        duplicate the row on next assemble) but preserves compaction
        summary rows (identified by :func:`is_compaction_summary`). The
        summary carries cross-turn memory of the older history, so dropping
        it on persist would force every future compaction to start from
        the truncated tail and steadily lose context.

        For ``role=user`` rows, strips any ephemeral Runtime Context /
        injected skill blocks that the LLM-bound message list carries.
        Without this, the bulk ``replace_messages`` call would overwrite
        the raw user row written by ``_run_conversation_impl`` with the
        enriched form, reintroducing the frozen ``Current Time:`` / skill
        context into durable history (issue #345 regression vector for
        long sessions that hit compaction).
        """
        from praestoclaw.agent.compressor import is_compaction_summary

        keep: list[dict[str, Any]] = []
        for m in messages:
            role = m.get("role")
            if role == "system" and not is_compaction_summary(m):
                continue
            if role == "user" and is_injected_runtime_context(m.get("content", "")):
                stripped = strip_injected_context(m["content"])
                if stripped != m["content"]:
                    m = {**m, "content": stripped}
            keep.append(m)
        await self._session_store.replace_messages(session_id, keep)

    async def _process_message(self, msg: InboundMessage) -> None:
        """Process a single inbound message through the full agent pipeline.

        Matches v1's _process_message: audit → approval routing → slash commands
        → hooks (on_message_received) → typing → agent loop → hooks
        (on_message_sent) → outbound.
        """
        channel = ChannelType.of(msg.logical_channel)
        delivery_route_id = msg.delivery_route_id
        conversation_id = msg.conversation_id or delivery_route_id
        sender_for_session = msg.sender_id or conversation_id or delivery_route_id or "anonymous"
        agent_session_key = self._resolve_agent_session_key(msg)
        await self._session_store.ensure_session(
            agent_session_key,
            str(channel),
            sender_for_session,
        )
        self._maybe_capture_owner_session(msg, agent_session_key, channel, sender_for_session)

        # ── Audit: inbound ──
        if self._audit:
            self._audit.log_message(
                channel=str(channel),
                direction="inbound",
                actor=msg.sender_id or "unknown",
                session_id=agent_session_key,
            )

        # ── Approval routing ──
        if await self._try_route_approval(msg):
            return

        # ── Slash commands ──
        content = msg.content.strip()
        if content.startswith("/"):
            reply = await self._handle_slash(content, agent_session_key, msg)
            if reply is not None:
                await self._reply_dispatcher.publish_final(
                    channel=channel,
                    channel_id=delivery_route_id,
                    content=reply,
                    thread_id=conversation_id,
                    route_hint=msg.route_hint,
                    dedupe=False,
                )
                return

        # ── Hook: on_message_received ──
        if self._hooks:
            hook_ctx = MessageHookContext(
                content=msg.content,
                channel=channel if isinstance(channel, ChannelType) else ChannelType.CLI,
                sender_id=msg.sender_id or "",
                session_id=agent_session_key,
            )
            result = await self._hooks.dispatch_checked("on_message_received", hook_ctx)
            if result.verdict == HookVerdict.REJECT:
                logger.warning("Message rejected by hook: {}", result.reason)
                await self._reply_dispatcher.publish_final(
                    channel=channel,
                    channel_id=delivery_route_id,
                    content=f"Message blocked: {result.reason}",
                    thread_id=conversation_id,
                    route_hint=msg.route_hint,
                    dedupe=False,
                )
                return
        else:
            # Fallback: inline prompt injection check when no hooks configured
            findings = Sanitizer.check_prompt_injection(msg.content)
            if findings:
                if self._audit:
                    self._audit.log_security(
                        event="prompt_injection_detected",
                        details={"findings": findings, "sender": msg.sender_id},
                        severity="warning",
                    )
                logger.warning("Prompt injection detected from {}: {}", msg.sender_id, findings)

        # ── Typing indicator ──
        typing_task = self._start_typing(channel, delivery_route_id, metadata=msg.metadata)

        # ── Task heartbeat (issue #181) ──
        # If the inbound carrier was a task-bearing a2a envelope, the
        # cloud channel stashed a private ``_task_progress_sender`` in
        # metadata. Pop it out (we never want the callable to leak into
        # the LLM/tool layer) and wrap the agent turn in a heartbeat
        # emitter so the original sender sees periodic ``executing``
        # progress events and the Gateway extends the executing-stage
        # soft deadline. No-op when the carrier was not a task.
        heartbeat = self._build_task_heartbeat(msg.metadata)

        # Source-driven tool exclusions. Inbound carriers (notably
        # ``source="a2a_task"`` from ``CloudProtocolChannel``) stamp an
        # ``exclude_tools`` list into ``metadata`` to keep the executor
        # turn from re-invoking ``a2a`` (infinite hop) or ``cron`` /
        # ``spawn`` (privilege escalation by a remote peer). ``notify``
        # is deliberately *not* excluded for a2a_task so the executor
        # can still push a final summary to its own owner — see the
        # corresponding NOTE in ``CloudChannel._handle_conversation_request``.
        raw_exclude = (msg.metadata or {}).get("exclude_tools")
        exclude_tools = (
            [str(t) for t in raw_exclude if isinstance(t, str)]
            if isinstance(raw_exclude, list)
            else None
        )
        turn_metadata = self._conversation_metadata_for_message(msg)

        try:
            history = await self._session_store.get_messages(agent_session_key)
            if heartbeat is not None:
                async with heartbeat:
                    response, streamed = await self._run_conversation(
                        msg.content,
                        history,
                        agent_session_key,
                        channel=channel,
                        channel_id=delivery_route_id,
                        thread_id=conversation_id,
                        metadata=turn_metadata,
                        exclude_tools=exclude_tools,
                        route_hint=msg.route_hint,
                    )
            else:
                response, streamed = await self._run_conversation(
                    msg.content,
                    history,
                    agent_session_key,
                    channel=channel,
                    channel_id=delivery_route_id,
                    thread_id=conversation_id,
                    metadata=turn_metadata,
                    exclude_tools=exclude_tools,
                    route_hint=msg.route_hint,
                )
        except Exception as exc:
            logger.error("Agent loop error: {}", exc)
            await self._reply_dispatcher.publish_final(
                channel=channel,
                channel_id=delivery_route_id,
                content="Sorry, an internal error occurred. Please try again.",
                thread_id=conversation_id,
                route_hint=msg.route_hint,
                dedupe=False,
            )
            return
        finally:
            self._stop_typing(typing_task, channel, delivery_route_id)

        # Is this emission the synchronous promotion receipt for a turn that
        # was just handed off to a background worker? Keyed on the carrier
        # route (recorded at promotion time) rather than the receipt TEXT, so
        # the flag survives a "minimal" one-liner, an empty "silent" body, and
        # any future copy change. Popped here so it can't leak to a later turn
        # that reuses the route id.
        is_promotion_receipt = delivery_route_id in self._promotion_receipt_routes
        self._promotion_receipt_routes.discard(delivery_route_id)

        # Empty/whitespace-only non-streamed turns have no user-visible outbound message.
        # Suppress them before outbound hooks/audit so hooks only observe
        # content that was streamed or is about to be published.
        #
        # EXCEPTION: a "silent"-mode promotion receipt is an empty body that
        # MUST still be published — the carrier /chatng waiter is resolved by
        # the channel send, so suppressing it here would hang the carrier until
        # it times out. The empty body renders as "nothing to post" on the
        # Teams bridge, so the user sees no receipt while the fold-back still
        # arrives later. The ``is_promotion_receipt`` flag also keeps the cloud
        # channel from popping the fold-back's stash + Teams route.
        if not streamed and not response.strip() and not is_promotion_receipt:
            logger.info(
                "Agent produced no final response; suppressing empty outbound "
                "channel={} channel_id={} session_id={}",
                channel,
                delivery_route_id,
                agent_session_key,
            )
            return

        # ── Hook: on_message_sent — runs on delivered/publishable content ──
        # For streamed responses, the hook runs on the full accumulated text
        # (same as v1's _stream_response which ran the hook after streaming).
        # If the hook rejects, we still send a replacement OutboundMessage
        # even if chunks were already streamed (best-effort correction).
        hook_blocked = False
        if self._hooks:
            out_ctx = MessageHookContext(
                content=response,
                channel=channel if isinstance(channel, ChannelType) else ChannelType.CLI,
                session_id=agent_session_key,
            )
            result = await self._hooks.dispatch_checked("on_message_sent", out_ctx)
            if result.verdict == HookVerdict.REJECT:
                logger.warning("Outbound message blocked by hook: {}", result.reason)
                response = "[Message blocked by security policy]"
                hook_blocked = True
            elif result.data and isinstance(result.data, MessageHookContext):
                response = result.data.content

        # ── Outbound: send full message only when NOT already delivered ──
        # If streaming delivered the final response AND hook didn't block,
        # skip the full OutboundMessage (channels already have the content).
        # If hook blocked a streamed response, send the replacement text.
        if not streamed or hook_blocked:
            # Mark the promotion-receipt emission so the cloud channel can
            # tell it apart from a normal final reply or a fold-back late
            # reply. Receipts are synchronous answers to the just-sent
            # message — they don't need the ↩️ envelope and they MUST NOT
            # consume the stash + Teams route that the eventual fold-back
            # will need (prod 2026-06-14 13:35–37). ``is_promotion_receipt``
            # was resolved above from ``_promotion_receipt_routes`` (route
            # identity), so it is correct regardless of the receipt copy
            # ("full" / "minimal" / empty "silent").
            metadata = {"is_promotion_receipt": True} if is_promotion_receipt else None
            await self._reply_dispatcher.publish_final(
                channel=channel,
                channel_id=delivery_route_id,
                content=response,
                thread_id=conversation_id,
                route_hint=msg.route_hint,
                metadata=metadata,
                dedupe=False,
            )

        # ── Audit: outbound ──
        if self._audit:
            self._audit.log_message(
                channel=str(channel),
                direction="outbound",
                actor="agent",
                session_id=agent_session_key,
            )

    def _build_task_heartbeat(self, metadata: dict[str, Any] | None) -> Any:
        """Construct a :class:`TaskHeartbeatEmitter` for task-bearing inbounds.

        Returns ``None`` when *metadata* does not describe a task carrier
        (the common case — plain chat / a2a messages get no heartbeat).
        The ``_task_progress_sender`` callable is popped out so it never
        reaches the LLM/tool serialization layer; cloud.py owns the
        contract that this private key carries the outbound handle.
        """

        if not metadata:
            return None
        sender = metadata.pop("_task_progress_sender", None)
        task_id = metadata.get("task_id")
        if sender is None or not isinstance(task_id, str) or not task_id:
            return None
        summary = ""
        raw_summary = metadata.get("task_summary")
        if isinstance(raw_summary, str):
            summary = raw_summary
        try:
            from praestoclaw.task.heartbeat import TaskHeartbeatEmitter  # noqa: PLC0415

            return TaskHeartbeatEmitter(
                sender,
                task_id=task_id,
                summary=summary,
            )
        except Exception as exc:  # noqa: BLE001
            # Heartbeat is best-effort: a misconfigured emitter must not
            # block the actual agent turn. Log and run without it.
            logger.warning("task heartbeat emitter init failed: {}", exc)
            return None

    async def _async_consolidate(
        self,
        messages: list[dict[str, Any]],
        session_id: str,
    ) -> None:
        """Fire-and-forget memory consolidation."""
        try:
            if hasattr(self._memory, "consolidate"):
                await self._memory.consolidate(messages, session_id)
        except Exception:
            logger.exception("Memory consolidation failed")
