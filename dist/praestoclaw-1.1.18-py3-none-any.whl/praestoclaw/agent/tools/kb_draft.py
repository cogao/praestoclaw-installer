"""Turn captured evidence into a reviewable set of knowledge-base changes.

This is the middle of the two-stage flow and it exists to make the two group
confirmations possible:

1. ``units`` + ``select`` — *what* should become team knowledge. The model
   extracts units from a capture; the group narrows them down.
2. ``stage`` + ``diff`` — *how* the chosen knowledge lands in this repository,
   rendered as a real git diff the group can approve or reject.

Nothing here writes to the checkout. Staged content lives in the task file
until ``kb_publish`` applies it, so a draft that is never approved leaves no
trace in a shared repository.

The tool does not decide what counts as a decision, where a document belongs,
or which convention applies — those come from ``kb_inspect(action="rules")``
and the model's reading of them. Encoding them here would freeze one snapshot
of a knowledge base that is expected to keep changing.
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.agent.tools.kb_base import KbToolBase
from praestoclaw.kb import captures_dir
from praestoclaw.kb.draft import (
    BLOCKER_OVERRIDDEN,
    BLOCKER_RESOLVED,
    DECISION_APPROVED,
    DECISION_DIFF,
    DECISION_SCOPE,
    DECISION_STAGES,
    DECISIONS,
    MAX_CHANGES,
    STATUS_AWAITING_DIFF,
    STATUS_AWAITING_SCOPE,
    STATUS_CANCELLED,
    STATUS_DRAFTING,
    CurationTask,
    CurationTaskStore,
    GroupDecision,
    KnowledgeUnit,
    RuleBlocker,
    StagedChange,
    commit_message_for,
    machine_authored_quote,
    preview_branch_name,
    validate_change,
)
from praestoclaw.kb.repo import KbPathError, KbRepo, KbRepoError
from praestoclaw.security.praesto_tag_exp import praesto_tag_exp_is_active
from praestoclaw.security.risk import RiskAssessment, RiskScore

_ACTIONS = (
    "start",
    "units",
    "select",
    "blockers",
    "resolve_blocker",
    "stage",
    "diff",
    "approve",
    "show",
    "list",
    "cancel",
)
_UNIT_TYPES = ("fact", "decision", "action", "risk", "question", "background", "status")


def _turn_id(kwargs: dict[str, Any]) -> str:
    """Identity of the inbound turn this call belongs to.

    Any of the three is fine — they are all stamped per inbound message by the
    cloud channel — but one of them has to be present for the same-turn check to
    mean anything.
    """
    metadata = kwargs.get("_metadata") or {}
    for key in ("turn_id", "message_id", "request_id"):
        value = str(metadata.get(key) or "").strip()
        if value:
            return value
    return ""


_MAX_UNITS = 100
_MAX_DIFF_CHARS = 12_000


class KbDraftTool(KbToolBase, Tool):
    """Assemble and revise a proposed knowledge-base change set."""

    risk_range = (3, 4)

    @property
    def name(self) -> str:
        return "kb_draft"

    @property
    def description(self) -> str:
        return (
            "Build a reviewable knowledge-base change set from a capture. "
            "Actions: 'start' opens a task against a capture snapshot and a "
            "repository; 'units' records the knowledge you extracted (facts, "
            "decisions, actions, risks, questions) with evidence pointers; "
            "'select' narrows to what the group agreed to keep; 'blockers' "
            "records rules this material appears to violate — record them BEFORE "
            "staging, because an open blocker stops staging until the group "
            "answers it; 'resolve_blocker' records that answer (the draft "
            "changed, or the group knowingly overrode the rule); 'stage' proposes "
            "the full new content of each document; 'diff' renders the staged "
            "changes as a git diff for the group to approve; 'approve' records "
            "what the group replied in chat to either question (scope or diff) — "
            "publishing is refused until an approval for the current diff is on "
            "record; 'show' resumes a task; 'list' shows this conversation's "
            "tasks; 'cancel' abandons one. "
            "Nothing reaches the repository until kb_publish."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=120, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        if str(args.get("action") or "") == "stage":
            # Staging now pushes the proposal to a scratch branch so the group
            # can read a real commit. That is a write to a shared repository —
            # namespaced, disposable and never the default branch, but a write.
            return RiskScore(4, reason="Push a disposable review branch to the knowledge base")
        return RiskScore(3, reason="Draft knowledge-base changes; nothing is committed")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": list(_ACTIONS)},
                "task_id": {
                    "type": "string",
                    "description": "Which task; defaults to this conversation's active one.",
                },
                "capture": {
                    "type": "string",
                    "description": (
                        "For 'start': the capture snapshot filename saved by "
                        "team_knowledge_capture. Omit to use the newest one."
                    ),
                },
                "repo": {
                    "type": "string",
                    "description": "For 'start': target repository, as 'owner/name'.",
                },
                "user_request": {
                    "type": "string",
                    "description": "For 'start': what the group asked for, in their words.",
                },
                "units": {
                    "type": "array",
                    "description": (
                        "For 'units': the knowledge you extracted. Each item needs "
                        "type, title, content and evidence pointing back to the "
                        "capture record and original source URL."
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "type": {"type": "string", "enum": list(_UNIT_TYPES)},
                            "title": {"type": "string"},
                            "content": {"type": "string"},
                            "confidence": {"type": "string"},
                            "evidence": {
                                "type": "array",
                                "items": {"type": "object", "additionalProperties": True},
                            },
                        },
                        "required": ["type", "title"],
                    },
                },
                "unit_ids": {
                    "type": "array",
                    "description": "For 'select': the unit ids the group kept.",
                    "items": {"type": "string"},
                },
                "all": {
                    "type": "boolean",
                    "description": "For 'select': keep every unit.",
                },
                "blockers": {
                    "type": "array",
                    "description": (
                        "For 'blockers': rules this material appears to violate. "
                        "Quote the rule and name the document it came from, so the "
                        "group can judge it without re-reading the repository."
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "rule_source": {
                                "type": "string",
                                "description": "Path of the rule document, e.g. "
                                "'context/sources.md'.",
                            },
                            "rule": {
                                "type": "string",
                                "description": "The rule, quoted.",
                            },
                            "conflict": {
                                "type": "string",
                                "description": "How this material conflicts with it.",
                            },
                        },
                        "required": ["rule_source", "rule", "conflict"],
                    },
                },
                "blocker_id": {
                    "type": "string",
                    "description": "For 'resolve_blocker': which blocker.",
                },
                "resolution": {
                    "type": "string",
                    "enum": [BLOCKER_RESOLVED, BLOCKER_OVERRIDDEN],
                    "description": (
                        "For 'resolve_blocker': 'resolved' = the draft changed so the "
                        "conflict is gone; 'overridden' = the group chose to proceed "
                        "anyway, which is recorded in the commit message."
                    ),
                },
                "note": {
                    "type": "string",
                    "description": "For 'resolve_blocker': what the group decided and why.",
                },
                "decided_by": {
                    "type": "string",
                    "description": "For 'resolve_blocker': who in the group decided.",
                },
                "stage": {
                    "type": "string",
                    "enum": list(DECISION_STAGES),
                    "description": (
                        "For 'approve': which question they answered — 'scope' (which "
                        "units belong in the KB) or 'diff' (the rendered change set)."
                    ),
                },
                "decision": {
                    "type": "string",
                    "enum": list(DECISIONS),
                    "description": (
                        "For 'approve': how you read their reply. 'approved' only for "
                        "a clear yes; use 'changes_requested' when they want edits and "
                        "'rejected' when they refuse. If the reply is ambiguous, do not "
                        "guess — ask them to confirm."
                    ),
                },
                "quote": {
                    "type": "string",
                    "description": (
                        "For 'approve': the group's own words, verbatim. Required — it "
                        "is what makes a chat-read decision auditable. Must come from a "
                        "message a person sent; tool output and checkpoint verdicts are "
                        "rejected."
                    ),
                },
                "by": {
                    "type": "string",
                    "description": "For 'approve': who answered. Defaults to the sender.",
                },
                "message": {
                    "type": "string",
                    "description": (
                        "For 'stage': the commit message, in the repository's own style "
                        "(conventional commits). The group reviews the real commit, so "
                        "this is part of what they approve — changing it later voids "
                        "their approval."
                    ),
                },
                "changes": {
                    "type": "array",
                    "description": (
                        "For 'stage': the proposed documents. Provide the COMPLETE "
                        "new content of each file, not a patch."
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "path": {"type": "string"},
                            "operation": {"type": "string", "enum": ["create", "update"]},
                            "content": {"type": "string"},
                            "rationale": {"type": "string"},
                            "units": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["path", "operation", "content"],
                    },
                },
            },
            "required": ["action"],
        }

    # ── execution ────────────────────────────────────────────────────────

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata") or {}
        if not praesto_tag_exp_is_active(metadata):
            return "kb_draft is only available in a praesto tag exp group session."
        if not self._enabled():
            return "Knowledge-base curation is disabled in this PraestoClaw config."

        cid = str(metadata.get("cid") or "")
        if not cid:
            return "Error: kb_draft needs a Teams conversation id on this turn."

        action = str(kwargs.get("action") or "").strip()
        if action not in _ACTIONS:
            return f"Error: action must be one of {', '.join(_ACTIONS)}."

        store = CurationTaskStore(cid)
        try:
            if action == "start":
                return await self._action_start(store, metadata, kwargs)
            if action == "list":
                return self._dump({"tasks": [task.summary() for task in store.all_tasks()[:20]]})

            task = store.resolve(str(kwargs.get("task_id") or ""))
            if task is None:
                return (
                    "No curation task found for this conversation. "
                    "Run kb_draft(action='start') first."
                )
            if action == "show":
                return await self._action_show(store, task)
            if not task.is_active:
                return (
                    f"Task {task.task_id} is {task.status} and cannot be modified. "
                    "Start a new task instead."
                )
            if action == "units":
                return self._action_units(store, task, kwargs)
            if action == "select":
                return self._action_select(store, task, kwargs)
            if action == "blockers":
                return self._action_blockers(store, task, kwargs)
            if action == "resolve_blocker":
                return self._action_resolve_blocker(store, task, kwargs)
            if action == "stage":
                return await self._action_stage(store, task, kwargs)
            if action == "diff":
                return await self._action_diff(task)
            if action == "approve":
                return self._action_approve(store, task, kwargs, metadata)
            return await self._action_cancel(store, task)
        except KbPathError as exc:
            return f"Refused: {exc}"
        except KbRepoError as exc:
            return f"Knowledge base unavailable: {exc}"

    # ── actions ──────────────────────────────────────────────────────────

    def _resolve_capture(self, requested: str) -> Path | str:
        """Find the capture snapshot to curate, newest-first by default."""
        root = captures_dir()
        available = sorted(root.glob("*.json")) if root.is_dir() else []
        if not available:
            return (
                "No capture snapshot exists yet. Collect the material first — load "
                "tools(name='team-knowledge-capture', action='skill') and follow it, "
                "then run kb_draft(action='start') again."
            )
        wanted = (requested or "").strip()
        if not wanted:
            return available[-1]
        for candidate in reversed(available):
            if wanted in (candidate.name, candidate.stem) or wanted in candidate.name:
                return candidate
        names = ", ".join(path.name for path in available[-5:])
        return f"No capture matches '{wanted}'. Recent captures: {names}"

    @staticmethod
    def _capture_inventory(path: Path) -> dict[str, Any]:
        """Summarise a capture so the group can frame the scope from it.

        Deliberately a summary: the snapshot embeds whole transcripts, and
        returning those verbatim would spend the turn's context on material the
        model is about to read selectively anyway.
        """
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            return {"error": f"Capture {path.name} is unreadable: {exc}"}
        records = payload.get("records") or []
        inventory: list[dict[str, Any]] = []
        for index, record in enumerate(records):
            kind = str(record.get("type") or "unknown")
            entry: dict[str, Any] = {"record": index, "type": kind}
            if kind == "chat_messages":
                entry.update(
                    {
                        "provenance": record.get("provenance"),
                        "count": record.get("count"),
                        "covered_from": record.get("covered_from"),
                        "covered_to": record.get("covered_to"),
                    }
                )
            elif kind == "meeting_transcript":
                pointer = record.get("pointer") or {}
                entry.update(
                    {
                        "provenance": record.get("provenance"),
                        "speaker_attribution": record.get("speaker_attribution"),
                        "title": pointer.get("title"),
                        "arrival_time": pointer.get("arrival_time"),
                        "vtt_chars": len(str(record.get("vtt") or "")),
                    }
                )
            elif kind == "source_gap":
                entry.update(
                    {
                        "source": record.get("source"),
                        "status": record.get("status"),
                        "reason": record.get("reason"),
                    }
                )
            inventory.append(entry)
        return {
            "captured_at": payload.get("captured_at"),
            "user_request": (payload.get("request_context") or {}).get("user_request"),
            "records": inventory,
        }

    async def _action_start(
        self, store: CurationTaskStore, metadata: dict[str, Any], kwargs: dict[str, Any]
    ) -> str:
        existing = store.active()
        if existing is not None:
            return self._dump(
                {
                    "refused": "A curation task is already open in this conversation.",
                    "guidance": (
                        "Finish or cancel it before starting another — "
                        "kb_draft(action='show') to resume, "
                        "kb_draft(action='cancel') to abandon."
                    ),
                    "active_task": existing.summary(),
                }
            )

        capture = self._resolve_capture(str(kwargs.get("capture") or ""))
        if isinstance(capture, str):
            return capture
        resolved = self._repo_for_group(store.cid, str(kwargs.get("repo") or ""))
        if isinstance(resolved, str):
            return resolved
        repo = resolved
        scope = self._scope(store.cid)
        subfolder = scope.subfolder if scope else ""

        status = await asyncio.to_thread(repo.sync, timeout=self._sync_timeout())
        task = CurationTask(
            task_id=store.new_task_id(),
            cid=store.cid,
            status=STATUS_DRAFTING,
            conversation_name=str(metadata.get("conversation_name") or ""),
            started_by=str(metadata.get("sender_name") or ""),
            user_request=str(kwargs.get("user_request") or ""),
            capture_path=str(capture),
            repo=repo.remote_url,
            base_head=status.head,
        )
        store.save(task)
        payload: dict[str, Any] = {
            "task": task.summary(),
            "capture": self._capture_inventory(capture),
            "next": (
                "Read the repository's own rules with kb_inspect(action='rules') "
                "before extracting anything, then record units with "
                "kb_draft(action='units')."
            ),
        }
        if subfolder:
            payload["preferred_subfolder"] = subfolder
            payload["subfolder_note"] = (
                f"This group keeps its knowledge in '{subfolder}'. Read that folder's "
                "rules first and draft there by default. It is a preference, not a "
                "limit — if the repository's own conventions place this material "
                "elsewhere, follow them and say why."
            )
        return self._dump(payload)

    def _action_units(
        self, store: CurationTaskStore, task: CurationTask, kwargs: dict[str, Any]
    ) -> str:
        incoming = kwargs.get("units")
        if not isinstance(incoming, list) or not incoming:
            return "Error: units needs a non-empty array."
        if len(task.units) + len(incoming) > _MAX_UNITS:
            return f"Error: a task holds at most {_MAX_UNITS} knowledge units."

        added: list[dict[str, Any]] = []
        for item in incoming:
            if not isinstance(item, dict):
                return "Error: every unit must be an object."
            unit_type = str(item.get("type") or "").strip()
            title = str(item.get("title") or "").strip()
            if unit_type not in _UNIT_TYPES:
                return f"Error: unit type must be one of {', '.join(_UNIT_TYPES)}."
            if not title:
                return "Error: every unit needs a title."
            unit = KnowledgeUnit(
                id=task.next_unit_id(),
                type=unit_type,
                title=title,
                content=str(item.get("content") or ""),
                evidence=list(item.get("evidence") or []),
                confidence=str(item.get("confidence") or ""),
            )
            task.units.append(unit)
            added.append({"id": unit.id, "type": unit.type, "title": unit.title})

        task.status = STATUS_AWAITING_SCOPE
        task.scope_presented_turn = _turn_id(kwargs)
        store.save(task)
        return self._dump(
            {
                "task_id": task.task_id,
                "status": task.status,
                "added": added,
                "unit_count": len(task.units),
                "next": (
                    "Post these to the group as an ordinary message, numbered, and ask "
                    "which belong in the KB. Then END YOUR TURN and wait — their reply "
                    "arrives as the next message. On that turn record what they said "
                    "with kb_draft(action='approve', stage='scope', ...) and narrow the "
                    "list with kb_draft(action='select')."
                ),
            }
        )

    def _action_select(
        self, store: CurationTaskStore, task: CurationTask, kwargs: dict[str, Any]
    ) -> str:
        if not task.units:
            return "Error: nothing to select — record units first."
        if kwargs.get("all"):
            chosen = [unit.id for unit in task.units]
        else:
            raw = kwargs.get("unit_ids")
            if not isinstance(raw, list) or not raw:
                return "Error: select needs unit_ids, or all=true."
            chosen = [str(item).strip() for item in raw if str(item).strip()]
            unknown = [uid for uid in chosen if task.unit(uid) is None]
            if unknown:
                return f"Error: unknown unit id(s): {', '.join(unknown)}."

        for unit in task.units:
            unit.selected = unit.id in chosen
        task.status = STATUS_AWAITING_SCOPE
        store.save(task)
        return self._dump(
            {
                "task_id": task.task_id,
                "selected": chosen,
                "dropped": [unit.id for unit in task.units if not unit.selected],
                "next": (
                    "Now read the rules governing the area you intend to write to — "
                    "kb_inspect(action='rules') — and check this material against them "
                    "BEFORE drafting. Record any conflict with kb_draft(action="
                    "'blockers'); then draft the documents and stage them."
                ),
            }
        )

    def _action_blockers(
        self, store: CurationTaskStore, task: CurationTask, kwargs: dict[str, Any]
    ) -> str:
        incoming = kwargs.get("blockers")
        if not isinstance(incoming, list) or not incoming:
            return "Error: blockers needs a non-empty array."

        added: list[dict[str, Any]] = []
        for item in incoming:
            if not isinstance(item, dict):
                return "Error: every blocker must be an object."
            rule_source = str(item.get("rule_source") or "").strip()
            rule = str(item.get("rule") or "").strip()
            conflict = str(item.get("conflict") or "").strip()
            if not (rule_source and rule and conflict):
                return "Error: every blocker needs rule_source, rule and conflict."
            blocker = RuleBlocker(
                id=task.next_blocker_id(),
                rule_source=rule_source,
                rule=rule,
                conflict=conflict,
            )
            task.blockers.append(blocker)
            added.append(blocker.to_dict())

        store.save(task)
        return self._dump(
            {
                "task_id": task.task_id,
                "recorded": added,
                "open_blockers": len(task.open_blockers),
                "next": (
                    "Staging is blocked until the group answers these. Put each rule "
                    "and the conflict in front of them, then record their decision "
                    "with kb_draft(action='resolve_blocker'). Do not quietly draft "
                    "around a rule."
                ),
            }
        )

    def _action_resolve_blocker(
        self, store: CurationTaskStore, task: CurationTask, kwargs: dict[str, Any]
    ) -> str:
        blocker_id = str(kwargs.get("blocker_id") or "").strip()
        resolution = str(kwargs.get("resolution") or "").strip()
        blocker = task.blocker(blocker_id)
        if blocker is None:
            return f"Error: unknown blocker id '{blocker_id}'."
        if resolution not in (BLOCKER_RESOLVED, BLOCKER_OVERRIDDEN):
            return f"Error: resolution must be '{BLOCKER_RESOLVED}' or '{BLOCKER_OVERRIDDEN}'."
        note = str(kwargs.get("note") or "").strip()
        if resolution == BLOCKER_OVERRIDDEN and not note:
            return (
                "Error: an override needs a note. It goes into the commit message, so "
                "the reason a stated rule was broken lives in the repository's history."
            )

        blocker.status = resolution
        blocker.resolution = note
        blocker.decided_by = str(kwargs.get("decided_by") or "").strip()
        store.save(task)
        return self._dump(
            {
                "task_id": task.task_id,
                "blocker": blocker.to_dict(),
                "open_blockers": len(task.open_blockers),
                "note": (
                    "This override will be recorded in the commit message."
                    if resolution == BLOCKER_OVERRIDDEN
                    else "Conflict resolved by changing the draft."
                ),
            }
        )

    async def _action_stage(
        self, store: CurationTaskStore, task: CurationTask, kwargs: dict[str, Any]
    ) -> str:
        incoming = kwargs.get("changes")
        if not isinstance(incoming, list) or not incoming:
            return "Error: stage needs a non-empty changes array."
        message = str(kwargs.get("message") or "").strip()
        if not message:
            return (
                "Error: message is required — the group reviews the real commit, so its "
                "subject is part of what they approve. Write it in the repository's own "
                "style (conventional commits)."
            )
        if len(incoming) > MAX_CHANGES:
            return f"Error: at most {MAX_CHANGES} documents per task."
        if not task.selected_units and task.units:
            return (
                "Error: the group has not confirmed the scope yet. "
                "Run kb_draft(action='select') first."
            )
        # First confirmation, enforced rather than merely instructed. Scope is
        # what the group agreed *belongs* in the knowledge base; drafting past
        # it produces a diff that looks reviewed and never was.
        if task.units and not task.scope_approved:
            return self._dump(
                {
                    "refused": "The group has not agreed the scope yet.",
                    "next": (
                        "Post the units to the group, end your turn, and record their "
                        "answer with kb_draft(action='approve', stage='scope', "
                        "decision='approved', quote='<their words>') when it arrives."
                    ),
                }
            )
        # An open rule conflict stops here rather than at publish. Staging is
        # where the group is shown a finished-looking diff, and a diff that has
        # silently walked past a rule is exactly the artefact that gets approved
        # by mistake.
        if task.open_blockers:
            return self._dump(
                {
                    "refused": "This draft conflicts with rules the knowledge base states.",
                    "open_blockers": [item.to_dict() for item in task.open_blockers],
                    "next": (
                        "Show each rule and conflict to the group and ask how to "
                        "proceed. Either change the draft so the conflict disappears "
                        "and record kb_draft(action='resolve_blocker', "
                        f"resolution='{BLOCKER_RESOLVED}'), or — if they explicitly "
                        "decide to proceed anyway — record "
                        f"resolution='{BLOCKER_OVERRIDDEN}' with their reason, which "
                        "will appear in the commit message."
                    ),
                }
            )

        resolved = self._repo_for_task(task.repo)
        if isinstance(resolved, str):
            return resolved
        repo = resolved

        staged: list[StagedChange] = []
        for item in incoming:
            if not isinstance(item, dict):
                return "Error: every change must be an object."
            path = str(item.get("path") or "").strip()
            operation = str(item.get("operation") or "").strip()
            content = str(item.get("content") or "")
            problem = validate_change(path, operation, content)
            if problem:
                return f"Error: {problem}"
            # Path safety first: resolve_within raises for anything outside the
            # checkout. Existence is then judged against HEAD, not the working
            # tree, so an untracked leftover cannot be mistaken for KB content.
            repo.resolve_within(path)
            tracked = repo.file_at_head(path) is not None
            if operation == "create" and tracked:
                return (
                    f"'{path}' already exists — use operation='update' and supply the "
                    "complete new content."
                )
            if operation == "update" and not tracked:
                return f"'{path}' does not exist — use operation='create'."
            staged.append(
                StagedChange(
                    path=path,
                    operation=operation,
                    content=content,
                    rationale=str(item.get("rationale") or ""),
                    units=[str(u) for u in (item.get("units") or [])],
                )
            )

        task.changes = staged
        task.commit_message = commit_message_for(message, task)
        task.status = STATUS_AWAITING_DIFF
        task.diff_presented_turn = _turn_id(kwargs)
        await self._refresh_preview(task, repo)
        store.save(task)
        return await self._action_diff(task)

    async def _refresh_preview(self, task: CurationTask, repo: KbRepo) -> None:
        """Commit the proposal to a scratch branch and publish it for review.

        A diff pasted into a chat is a poor thing to read, so the proposal is
        put where reviewing is comfortable. The branch is cut from the very
        commit the approval is pinned to, which means the commit the group opens
        is byte-for-byte the one that later lands on the real branch — there is
        no second version, and nothing to re-check between reading and
        publishing.

        Best-effort by design. A repository that refuses branch creation still
        has to be usable, so a failure here is recorded and the flow falls back
        to the inline diff and the ordinary publish path.
        """
        branch = preview_branch_name(task.task_id)
        home = await asyncio.to_thread(repo.branch)
        base = task.base_head or await asyncio.to_thread(repo.head)
        task.preview_error = ""
        try:
            await asyncio.to_thread(repo.start_branch, branch, base)
            try:
                for change in task.changes:
                    target = repo.resolve_within(change.path)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_text(change.content, encoding="utf-8", newline="\n")
                sha = await asyncio.to_thread(
                    repo.commit, [change.path for change in task.changes], task.commit_message
                )
                await asyncio.to_thread(
                    repo.push_ref, sha, branch, force=True, timeout=self._sync_timeout()
                )
            finally:
                # Back to the real branch whatever happened, so the checkout is
                # never left sitting on a scratch branch for the next action.
                await asyncio.to_thread(repo.checkout, home)
        except (KbRepoError, OSError) as exc:
            task.preview_branch = ""
            task.preview_sha = ""
            task.preview_url = ""
            task.preview_error = str(exc)
            await asyncio.to_thread(repo.delete_local_branch, branch)
            logger.warning("kb_draft: review branch unavailable for {} — {}", task.task_id, exc)
            return

        task.preview_branch = branch
        task.preview_sha = sha
        task.preview_url = repo.commit_url(sha)
        logger.info("kb_draft: review commit {} on {}", sha[:8], branch)

    async def _action_diff(self, task: CurationTask) -> str:
        if not task.changes:
            return "Nothing staged yet — run kb_draft(action='stage') first."
        resolved = self._repo_for_task(task.repo)
        if isinstance(resolved, str):
            return resolved
        repo = resolved

        diffs: list[dict[str, Any]] = []
        for change in task.changes:
            text = await asyncio.to_thread(repo.diff_text, change.path, change.content)
            truncated = len(text) > _MAX_DIFF_CHARS
            diffs.append(
                {
                    "path": change.path,
                    "operation": change.operation,
                    "rationale": change.rationale,
                    "units": change.units,
                    "unchanged": not text.strip(),
                    "truncated": truncated,
                    "diff": text[:_MAX_DIFF_CHARS],
                }
            )
        payload: dict[str, Any] = {
            "task_id": task.task_id,
            "status": task.status,
            "repo": task.repo,
            "base_head": task.base_head,
            "commit_message": task.commit_message,
            "diffs": diffs,
        }
        if task.preview_sha:
            payload["review_branch"] = task.preview_branch
            payload["review_sha"] = task.preview_sha
            if task.preview_url:
                payload["review_url"] = task.preview_url
                payload["next"] = (
                    "Give the group the review_url — it is the real commit, on a scratch "
                    "branch, and reads far better than a pasted diff. Say briefly what "
                    "it changes, ask them to approve, then END YOUR TURN and wait. When "
                    "they answer, record it with kb_draft(action='approve', "
                    "stage='diff', ...). Approving publishes exactly this commit onto "
                    "the knowledge base and removes the scratch branch."
                )
            else:
                # The commit exists but this host has no web view we can name.
                payload["next"] = (
                    "The proposal is committed on a review branch, but no web link "
                    "could be derived for this host — post the diff itself instead. "
                    "Ask the group to approve, END YOUR TURN, and record their reply "
                    "with kb_draft(action='approve', stage='diff', ...)."
                )
        else:
            payload["review_unavailable"] = (
                task.preview_error or "the review branch could not be pushed"
            )
            payload["next"] = (
                "No review branch could be created, so post the diff itself to the "
                "group as an ordinary message. Ask them to approve, END YOUR TURN, and "
                "record their reply with kb_draft(action='approve', stage='diff', ...)."
            )
        return self._dump(payload)

    def _action_approve(
        self,
        store: CurationTaskStore,
        task: CurationTask,
        kwargs: dict[str, Any],
        metadata: dict[str, Any],
    ) -> str:
        """Record what the group answered, in their words.

        The two confirmations used to be Adaptive Cards that blocked the turn,
        so a resolved card *was* the proof. Answers now arrive as ordinary chat
        messages and are read by a model, which means the proof has to be built
        deliberately: the decision is written down with the group's own wording,
        tied to the turn it arrived on, and — for a diff — to the exact content
        that was on screen.
        """
        stage = str(kwargs.get("stage") or "").strip()
        if stage not in DECISION_STAGES:
            return f"Error: stage must be one of {', '.join(DECISION_STAGES)}."
        decision = str(kwargs.get("decision") or "").strip()
        if decision not in DECISIONS:
            return f"Error: decision must be one of {', '.join(DECISIONS)}."
        quote = str(kwargs.get("quote") or "").strip()
        if not quote:
            return (
                "Error: quote is required — paste the group's own words. A decision "
                "read out of chat is only auditable if what was read is recorded."
            )
        laundered = machine_authored_quote(quote)
        if laundered:
            return f"Error: {laundered}"

        if stage == DECISION_SCOPE and not task.units:
            return "Error: nothing has been put to the group yet — record units first."
        if stage == DECISION_DIFF and not task.changes:
            return (
                "Error: no diff has been staged, so there is nothing for the group to "
                "have approved. Run kb_draft(action='stage') first."
            )

        presented = (
            task.scope_presented_turn if stage == DECISION_SCOPE else task.diff_presented_turn
        )
        turn = _turn_id(kwargs)
        # An answer cannot arrive on the same inbound turn that produced the
        # question. Without this the model could propose, "approve" and publish
        # in one breath, having shown the group nothing.
        if turn and presented and turn == presented:
            return (
                "Error: this is the same turn the material was put to the group on, so "
                "no one can have answered yet. Post it, end your turn, and record their "
                "reply when it arrives."
            )
        if not turn or not presented:
            logger.warning(
                "kb_draft.approve: no turn identity (turn={!r} presented={!r}) — "
                "recording without the same-turn check",
                turn,
                presented,
            )

        record = GroupDecision(
            stage=stage,
            decision=decision,
            by=str(kwargs.get("by") or metadata.get("sender_name") or "").strip(),
            quote=quote,
            turn_id=turn,
            fingerprint=task.change_fingerprint() if stage == DECISION_DIFF else "",
        )
        task.decisions.append(record)
        store.save(task)

        payload: dict[str, Any] = {
            "task_id": task.task_id,
            "recorded": record.to_dict(),
        }
        if decision != DECISION_APPROVED:
            payload["next"] = (
                "Not an approval. Do not proceed: make the change they asked for and "
                "put it to them again, or cancel with kb_draft(action='cancel')."
            )
        elif stage == DECISION_SCOPE:
            payload["next"] = (
                "Scope agreed. Narrow the units with kb_draft(action='select'), read "
                "the target area's rules, then draft and stage."
            )
        else:
            payload["next"] = (
                "Diff approved. kb_publish will now accept this exact content — if you "
                "restage anything, the approval no longer applies and you need a fresh "
                "one."
            )
        return self._dump(payload)

    async def _action_show(self, store: CurationTaskStore, task: CurationTask) -> str:
        payload: dict[str, Any] = {
            "task": task.summary(),
            "user_request": task.user_request,
            "units": [unit.to_dict() for unit in task.units],
            "blockers": [item.to_dict() for item in task.blockers],
        }
        resolved = self._repo_for_task(task.repo)
        if isinstance(resolved, KbRepo) and resolved.is_cloned:
            current = await asyncio.to_thread(resolved.head)
            payload["repo_moved"] = bool(task.base_head and current != task.base_head)
            payload["current_head"] = current
        return self._dump(payload)

    async def _action_cancel(self, store: CurationTaskStore, task: CurationTask) -> str:
        # An abandoned proposal leaves a branch behind on a shared repository,
        # which is somebody else's confusion later. Best-effort: the task is
        # cancelled either way.
        discarded = await self._discard_preview(task)
        task.status = STATUS_CANCELLED
        store.save(task)
        return self._dump(
            {
                "task_id": task.task_id,
                "status": task.status,
                "review_branch_removed": discarded,
            }
        )

    async def _discard_preview(self, task: CurationTask) -> bool:
        """Delete the review branch locally and on the remote, if there is one."""
        branch = task.preview_branch
        if not branch:
            return False
        resolved = self._repo_for_task(task.repo)
        if not isinstance(resolved, KbRepo) or not resolved.is_cloned:
            return False
        try:
            await asyncio.to_thread(resolved.delete_local_branch, branch)
            await asyncio.to_thread(
                resolved.delete_remote_branch, branch, timeout=self._sync_timeout()
            )
        except KbRepoError as exc:
            logger.info("kb_draft: could not remove review branch {} — {}", branch, exc)
            return False
        task.preview_branch = ""
        task.preview_sha = ""
        task.preview_url = ""
        return True

    @staticmethod
    def _dump(payload: dict[str, Any]) -> str:
        return json.dumps(payload, ensure_ascii=False, indent=2)
