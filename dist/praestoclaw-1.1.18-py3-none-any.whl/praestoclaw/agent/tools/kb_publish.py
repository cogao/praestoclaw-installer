"""Apply an approved knowledge-base change set.

This is the only tool in the group session that writes to a shared repository,
so it is deliberately narrow: it publishes what ``kb_draft`` staged, and takes
no content of its own. There is no path argument, no message-only mode and no
way to reach a repository the operator did not configure.

Two safeguards matter more than the rest:

* **A recorded approval.** The group answers in ordinary chat, and a model reads
  that answer, so agreement is not self-evident — it has to be written down.
  ``kb_draft(action="approve")`` records their words, and this refuses without a
  decision that covers exactly what is staged now.
* **Revalidation.** The group approved a diff against a specific commit. If the
  knowledge base moved while they were reading it, the approval no longer
  describes what would be written — so the publish stops and asks for a fresh
  diff rather than silently committing against a changed base.
* **Named paths only.** Only the staged files are added to the commit, so an
  unrelated file that happens to be sitting in the checkout can never ride
  along into a shared repository.

Approval itself lives in the conversation: the group confirms the diff before
this is called. That is the agreed model — publishing does not re-prompt the
lending employee in a DM, because the people who own the knowledge are the ones
in the chat.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.agent.tools.kb_base import KbToolBase
from praestoclaw.kb.draft import (
    DECISION_APPROVED,
    DECISION_DIFF,
    STATUS_AWAITING_DIFF,
    STATUS_PUBLISHED,
    CurationTask,
    CurationTaskStore,
    commit_message_for,
)
from praestoclaw.kb.repo import KbAuthRequiredError, KbPathError, KbRepo, KbRepoError
from praestoclaw.security.praesto_tag_exp import praesto_tag_exp_is_active
from praestoclaw.security.risk import RiskAssessment, RiskScore


class KbPublishTool(KbToolBase, Tool):
    """Commit and push an approved change set to the knowledge base."""

    risk_range = (6, 6)

    @property
    def name(self) -> str:
        return "kb_publish"

    @property
    def description(self) -> str:
        return (
            "Publish the change set staged by kb_draft: revalidate that the "
            "knowledge base has not moved since the group saw the diff, write the "
            "staged documents, commit exactly those paths and push. Call this ONLY "
            "after the group has approved the diff. If the repository moved, this "
            "refuses and asks for a fresh diff instead of committing against a "
            "different base."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=300, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(6, reason="Commit and push to the shared team knowledge base")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "Which task; defaults to this conversation's active one.",
                },
                "message": {
                    "type": "string",
                    "description": (
                        "Optional. The commit message is fixed when the change set is "
                        "staged, because that is the commit the group reviewed. Pass it "
                        "only to confirm the same text; a different one is refused."
                    ),
                },
                "approved_by": {
                    "type": "string",
                    "description": "Who in the group approved the diff.",
                },
            },
            "required": [],
        }

    # ── execution ────────────────────────────────────────────────────────

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata") or {}
        if not praesto_tag_exp_is_active(metadata):
            return "kb_publish is only available in a praesto tag exp group session."
        if not self._enabled():
            return "Knowledge-base curation is disabled in this PraestoClaw config."

        cid = str(metadata.get("cid") or "")
        if not cid:
            return "Error: kb_publish needs a Teams conversation id on this turn."
        message = str(kwargs.get("message") or "").strip()

        store = CurationTaskStore(cid)
        task = store.resolve(str(kwargs.get("task_id") or ""))
        if task is None:
            return "No curation task found for this conversation."
        if task.status == STATUS_PUBLISHED:
            return self._dump(
                {
                    "already_published": task.published,
                    "task_id": task.task_id,
                }
            )
        if not task.is_active:
            return f"Task {task.task_id} is {task.status} and cannot be published."
        if task.status != STATUS_AWAITING_DIFF or not task.changes:
            return (
                "Nothing approved to publish. Stage the documents with "
                "kb_draft(action='stage') and show the group the diff first."
            )
        # The approval gate. It used to be an Adaptive Card that blocked the
        # turn, so a resolved card was the proof; with answers arriving as chat
        # text the proof is the recorded decision, and it has to match the
        # content that was on screen when they gave it.
        refusal = self._approval_refusal(task)
        if refusal:
            return refusal
        # Belt and braces: staging already refuses on an open blocker, but a
        # blocker can also be raised after a diff was rendered. Publishing past
        # an unanswered rule conflict is the one outcome this whole mechanism
        # exists to prevent.
        if task.open_blockers:
            return self._dump(
                {
                    "refused": "Unanswered rule conflicts — this cannot be published.",
                    "open_blockers": [item.to_dict() for item in task.open_blockers],
                    "next": (
                        "Put each rule in front of the group and record their decision "
                        "with kb_draft(action='resolve_blocker')."
                    ),
                }
            )
        # The subject was settled when the group reviewed the commit. Rewriting
        # it here would publish something they never read — and, on the review
        # path, would not even be the commit they opened.
        if (
            message
            and task.commit_message
            and commit_message_for(message, task) != task.commit_message
        ):
            return self._dump(
                {
                    "refused": "That commit message is not the one the group reviewed.",
                    "they_reviewed": task.commit_message.splitlines()[0],
                    "you_passed": message,
                    "next": (
                        "Publish without a message to use the reviewed one, or restage "
                        "with the new message and get a fresh approval."
                    ),
                }
            )

        resolved = self._repo_for_task(task.repo)
        if isinstance(resolved, str):
            return resolved
        repo = resolved

        try:
            return await self._publish(store, task, repo, message, kwargs)
        except KbAuthRequiredError as exc:
            return f"Publish blocked — {exc}"
        except KbPathError as exc:
            return f"Refused: {exc}"
        except KbRepoError as exc:
            return f"Publish failed: {exc}"

    def _approval_refusal(self, task: CurationTask) -> str:
        """Empty when the group's standing approval covers what is staged now.

        The three failures are kept apart because the fix differs: nobody has
        answered, they answered no, or they answered about different content.
        Collapsing them into "not approved" would send the model back to the
        group with the wrong question.
        """
        decision = task.latest_decision(DECISION_DIFF)
        if decision is None:
            return self._dump(
                {
                    "refused": "The group has not approved this diff.",
                    "next": (
                        "Post the diff, end your turn, and record their reply with "
                        "kb_draft(action='approve', stage='diff', decision='approved', "
                        "quote='<their words>'). Nothing is published on your reading "
                        "of the conversation alone."
                    ),
                }
            )
        if decision.decision != DECISION_APPROVED:
            return self._dump(
                {
                    "refused": f"The group answered '{decision.decision}', not an approval.",
                    "they_said": decision.quote,
                    "next": (
                        "Make the change they asked for, stage it again, and put the "
                        "new diff to them. Do not publish the version they turned down."
                    ),
                }
            )
        if decision.fingerprint != task.change_fingerprint():
            return self._dump(
                {
                    "refused": "The staged content changed after the group approved it.",
                    "they_approved": decision.fingerprint[:12],
                    "staged_now": task.change_fingerprint()[:12],
                    "next": (
                        "Render the current diff with kb_draft(action='diff'), show it "
                        "to the group, and record a fresh approval."
                    ),
                }
            )
        return ""

    async def _publish_reviewed_commit(
        self,
        store: CurationTaskStore,
        task: CurationTask,
        repo: KbRepo,
        commit_message: str,
        kwargs: dict[str, Any],
    ) -> str:
        """Move the commit the group read onto the real branch, unchanged.

        The review branch was cut from ``base_head`` and the publish above has
        already refused if the knowledge base moved, so this is a fast-forward:
        the sha in the link the group opened is the sha that lands. No
        cherry-pick, which would have produced a *different* commit than the one
        that was approved and quietly broken that correspondence.

        The push is deliberately not forced. If the real branch turns out to
        have moved after all, this fails rather than overwriting whoever moved
        it.
        """
        branch = await asyncio.to_thread(repo.branch)
        sha = task.preview_sha
        await asyncio.to_thread(repo.push_ref, sha, branch, timeout=self._sync_timeout())

        # Only now is the scratch branch redundant. Deleting it earlier would
        # leave nothing to retry from if the push above had failed.
        removed = True
        try:
            await asyncio.to_thread(
                repo.delete_remote_branch, task.preview_branch, timeout=self._sync_timeout()
            )
            await asyncio.to_thread(repo.delete_local_branch, task.preview_branch)
        except KbRepoError as exc:
            removed = False
            logger.info("kb_publish: review branch {} left behind — {}", task.preview_branch, exc)
        await asyncio.to_thread(repo.sync, timeout=self._sync_timeout())

        task.status = STATUS_PUBLISHED
        approval = task.diff_approval()
        task.published = {
            "commit": sha,
            "branch": branch,
            "url": repo.commit_url(sha),
            "paths": [change.path for change in task.changes],
            "message": commit_message,
            "overrode_rules": [item.to_dict() for item in task.overridden_blockers],
            "approved_by": str(kwargs.get("approved_by") or "")
            or (approval.by if approval else ""),
            "approval_quote": approval.quote if approval else "",
            "reviewed_as": task.preview_url,
            "review_branch_removed": removed,
        }
        reviewed_branch = task.preview_branch
        task.preview_branch = ""
        store.save(task)
        logger.info(
            "kb_publish: task={} commit={} (reviewed on {}) -> {}",
            task.task_id,
            sha[:8],
            reviewed_branch,
            branch,
        )
        return self._dump({"published": task.published, "task_id": task.task_id})

    async def _publish(
        self,
        store: CurationTaskStore,
        task: CurationTask,
        repo: KbRepo,
        message: str,
        kwargs: dict[str, Any],
    ) -> str:
        # Revalidate: the approval describes a diff against ``base_head``.
        status = await asyncio.to_thread(repo.sync, timeout=self._sync_timeout())
        if task.base_head and status.head != task.base_head:
            approved_against = task.base_head
            task.base_head = status.head
            store.save(task)
            return self._dump(
                {
                    "refused": "The knowledge base moved while the diff was under review.",
                    "approved_against": approved_against,
                    "current_head": status.head,
                    "next": (
                        "The staged content is unchanged. Re-render it with "
                        "kb_draft(action='diff') against the new base, show the group "
                        "the updated diff, and publish once they confirm again."
                    ),
                }
            )

        written: list[str] = []
        base_sha = status.head
        commit_message = task.commit_message or commit_message_for(message, task)

        if task.preview_sha:
            return await self._publish_reviewed_commit(store, task, repo, commit_message, kwargs)

        try:
            for change in task.changes:
                target = repo.resolve_within(change.path)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(change.content, encoding="utf-8", newline="\n")
                written.append(change.path)

            sha = await asyncio.to_thread(repo.commit, written, commit_message)
            branch = await asyncio.to_thread(repo.push, timeout=self._sync_timeout())
        except Exception:
            # Undo everything, including a commit that succeeded before the push
            # failed. A half-published state fails *silently* on the retry: the
            # local commit makes it look like there is nothing left to do, and
            # the written files make the next diff look empty.
            await asyncio.to_thread(repo.rollback, base_sha, written)
            raise

        task.status = STATUS_PUBLISHED
        approval = task.diff_approval()
        task.published = {
            "commit": sha,
            "branch": branch,
            "url": repo.commit_url(sha),
            "paths": written,
            "message": commit_message,
            "overrode_rules": [item.to_dict() for item in task.overridden_blockers],
            "approved_by": str(kwargs.get("approved_by") or "")
            or (approval.by if approval else ""),
            "approval_quote": approval.quote if approval else "",
        }
        store.save(task)
        logger.info(
            "kb_publish: task={} commit={} paths={}",
            task.task_id,
            sha,
            ", ".join(written),
        )
        return self._dump({"published": task.published, "task_id": task.task_id})

    @staticmethod
    def _dump(payload: dict[str, Any]) -> str:
        return json.dumps(payload, ensure_ascii=False, indent=2)
