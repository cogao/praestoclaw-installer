---
name: fix-societas-bug
description: Fix a Societas bug end-to-end from ADO investigation through verified PR review.
plan: true
metadata:
  # First-turn routing (loop_v2._match_workflow_recipe). These name the recipe's
  # SUBJECT, not execution intent. Whether the user is actually asking for the work
  # is judged by the model from the full turn, because the injected note is neutral
  # -- see loop_v2._recipe_route_block. Matching too narrowly here is the expensive
  # direction: it silently reproduces the bug this routing exists to fix. Keywords
  # alone never route; a recipe opts in by declaring patterns. No \\b around
  # 'societas': Python treats CJK as word characters, so \\bsocietas fails to
  # match inside '这个societas bug'.
  activation:
    keywords:
    - societas bug
    patterns:
    - "(?i)societas[^\\n]{0,16}(?:bugs?|缺陷|问题|故障)"
    - "(?i)(?:bugs?|缺陷|问题|故障)[^\\n]{0,16}societas"
parameters:
- name: bug_id
  type: string
  required: true
- name: repo_path
  type: string
  required: false
concurrency:
  max_instances: 1
  key_parameters: [bug_id]
limits:
  allowed_tools:
    - shell
    - plan
    - tools
    - image_compare
    - config_praestoclaw
  # Recipe upper bound. On-demand runs also clamp this to
  # execution.background_task_timeout_seconds (1800s by default);
  # scheduled runs use this value directly.
  max_runtime: 3600
  max_output: 20000
---
Complete Societas bug #{bug_id} end-to-end. The optional repository path is
`{repo_path}`. If it is empty, use the agent's configured `ado_repo_local_path`;
if that is also unavailable, do not guess a path and do not ask across turns —
this run cannot obtain the value, so it is a blocker. On the **first** turn that
finds both sources empty, mark the **Pick up** item `blocked` with
`plan(action='update', id='<the Pick up item's id>', status='blocked',
evidence=...)` — `id` is required; use the item id exactly as it appears in
the Plan, whether you supplied it or PlanTool auto-generated it — carrying the exact
command and the empty result you observed, then stop with a reply naming both
sources and the two ways to supply it (set
`agents.default.metadata.ado_repo_local_path`, or re-run with an explicit
`repo_path`). Do not repeat the question on a later turn.

This is an authorized internal defensive-maintenance workflow for the Societas
repository. Apply and verify remediation; do not execute a real attack payload,
establish persistence, access unrelated data, or provide offensive guidance.

## Execution guardrails

- **Callout contract** — the ONLY way to stop this run and hand the decision back
  to the user. Every "stop", "pause and ask", "escalate", or "blocked" instruction
  below means exactly this, and nothing else counts:
  1. `plan(action='update', id='<current item id>', status='blocked', evidence='<what you tried, the exact blocker, the missing prerequisite>')` — `id` and a
     **non-empty `evidence`** are both required; a blocked item with empty evidence
     does not stop the run.
  2. Every item **before** it must already be `done` or `skipped` — the runtime only
     inspects the first item that is not `done`/`skipped`, so an unfinished earlier
     item hides your blocker and the run continues.
  3. Put the question to the user in the **same reply**. A question in the reply
     alone is not a stop — the runtime cannot see it and will drive the run again.

  **An evidenced Callout is a successful outcome of this run, not a failure.** A run
  that stops with a concrete blocker and hands the user a real decision has done its
  job; a run that manufactures evidence to reach step 7 has not. Never prefer
  inventing data, a stand-in test, or a synthetic screenshot over stopping here.
  What keeps this honest is the evidence, not the stopping: a Callout must name the
  concrete paths you actually tried, each with its command and its real output.
  Stopping on the first obstacle without trying anything is not a Callout.
- Read the repository's instructions before changing Git state. Use exactly one
   task checkout and one feature branch for the entire run. Reuse an existing
   task-specific checkout/branch when it already contains valid work; never create
   `v2`/`v3` clones or another worktree merely to obtain a globally clean status.
- Record the initial `git status --short`. Treat unrelated pre-existing changes,
   generated files, and Git LFS materialization noise as user-owned state: do not
   reset, restore, clean, stage, or delete them. Judge this task with path-scoped
   status/diffs for files the task actually changes. If a target file was already
   modified before the task, stop via the Callout contract instead of overwriting it.
- Inspect a linked prior PR/commit once and either reuse it or reject it with a
   concrete reason. Do not keep producing alternative implementations to escape
   repository hygiene noise.
- Every Plan item is a hard gate. Try at most two materially different approaches
  to the same obstacle. After any phase-specific retries or those approaches are
  exhausted, if the item's acceptance/check is still unmet, mark that item `blocked`
  via the Callout contract with the attempts, exact blocker, and missing prerequisite;
  call out the blocker to the user in the same reply and stop the run. Do not start or
  complete any later item.
  Keep discovery bounded: prefer one targeted search or command over broad scans.
- Update the plan immediately when its real artifact exists: a committed fix
   completes **Fix** even if unrelated files remain dirty; passing the selected
   checks plus a recorded product-proof state completes **Verify**. Do not postpone
   plan progress for cosmetic cleanup.
- Keep each phase bounded. Unless concrete new evidence requires one more call,
   **Pick up** gets about 12 non-plan tool calls, **Root cause** about 15, and
   **Repro** about 40 — selecting the verification level and reading the
   applicable repository instruction file count toward that budget, so do them in
   one batched command. Repro's larger budget covers the
   fetch-sample → run → render → attest cycle a real reproduction needs; it is not
   licence to browse. Budgets are per
   `verification_decision`: a work item with two target boundaries needs two
   samples and two failing cases. These are **guides for pacing, not gates**: going
   over costs a one-line note in the plan item saying what needed the extra calls,
   and **running out of budget is never a reason to mark an item `blocked`, to skip
   the reproduction, or to skip capturing evidence**. Parallelize independent reads
   in one shell command.
   Do not spend calls narrating, describing active tools, or reloading overlapping
   skills.
- The task repository can be outside PraestoClaw's workspace boundary. Perform
   repository reads, searches, edits, and Git operations through `shell` commands
   rooted in `<repo_path>`; do not probe it with workspace-scoped `read_file`,
   `search_files`, `list_dir`, or `edit_file` and then retry via shell.
- Use syntax native to the current shell. On Windows PowerShell, root commands with
   `Set-Location -LiteralPath '<repo_path>'; ...`, use `$null` instead of
   `/dev/null`, and use `Get-Content -Tail <n>` instead of `tail`. On POSIX, use
   `cd -- '<repo_path>' && ...`. Never send bash-only syntax to PowerShell.
- In PowerShell interpolated strings, delimit a variable before `:` or a URL query
   as `${path}:...` or `${buildId}?api-version=...`. PowerShell does not use
   Bash/C-style `\"` to escape double quotes; use single quotes, a single-quoted
   here-string, or structured JSON serialization instead.
- Omit shell's `directory` argument. `directory="workspace"` is a shorthand for
   PraestoClaw's OWN workspace root — not this task's repo, which is outside it — so
   it never targets the right place here; use `cd -- '<repo_path>' && ...` instead.
- Load at most one phase-specific skill at a time. During pickup, load only
   `azure-cli-check`. After the router returns a `verification_decision`, load only
   a skill named by that router-selected surface's instructions, if any. Evidence
   capture follows the owning verification surface and must not trigger a separate
   debugging skill. Load `pr-workflow` only after Verify passes.
   Do not load `ado` or `bug-investigate`: this recipe already owns those phases.

## Fast path

Before broad investigation, inspect task-specific branches/worktrees and linked
PR/commit metadata once. If an interrupted attempt already produced a relevant
commit, reuse that checkout and verify the commit instead of redoing discovery,
reproduction, or implementation. Record the reused evidence in the plan and move
directly to the first genuinely unfinished phase. Include task-named directories
under `<repo_path>/.worktrees/` even when they are independent clones and therefore
absent from `git worktree list`. Enumerate local and remote refs matching
`*{bug_id}*` plus `git worktree list --porcelain`; a remote-only task branch with
a relevant commit is reusable, so create a local tracking branch instead of a
new `v2`/`v3` branch. When candidates conflict, prefer the committed branch whose
diff matches the bug over a partially edited checkout; preserve the partial
checkout rather than layering another attempt onto it.

If the primary checkout already has only the bug's target paths staged from an
interrupted run, compare the index against the linked fix commit once. When the
trees match and the linked commit descends from the configured target branch,
restore/create the task feature branch at that commit and continue at **Verify**;
do not re-investigate the root cause. Reproduction is **not** waived — the fast path
saves discovery, never evidence, so still revert the fix, capture and attest the RED,
and restore. Never include unrelated
unstaged paths in the commit.

Create this seven-item plan at the start and update each item as work progresses.
Do not reuse a stale plan from another task.

1. **Pick up**: Resolve the repository without searching the filesystem. Prefer
   the explicit `repo_path`; otherwise directly read
   `agents.default.metadata.ado_repo_local_path`: enable the tool once with
   `tools(name="config_praestoclaw")` if needed, then call
   `config_praestoclaw(action="show", path="agents.default.metadata")`. Do not
   grep config files, logs, or `sessions.db` for this value. Note
   `config_praestoclaw` is **hard-blocked in a scheduled/cron run** (an unattended
   run must not reconfigure the agent), so a **scheduled invocation MUST pass an
   explicit `repo_path`**; the `config_praestoclaw` fallback is for interactive
   (on-demand) runs only. Read repo `AGENTS.md`/`CLAUDE.md` from that path with one
   bounded shell command.
   In that same command, list task-named branches/directories and their HEAD
   commits so the fast path is decided before fetching broad context.
   Check Azure CLI auth, then fetch the bug once with
   `az boards work-item show --id {bug_id} --detect true --expand all -o json`
   from the repo. That response is the source for fields and relations. Query
   comments/attachments separately only when the bug explicitly says they carry
   missing reproduction evidence. Do not inspect PR policies during pickup.
2. **Root cause**: Use one targeted code search, read only the directly implicated
   files, and inspect relevant git history/blame once. A linked prior fix may be
   inspected once and then either reused or rejected with a concrete reason.
   Stop when one falsifiable root cause explains the reported behavior; do not
   map the surrounding subsystem for completeness.
3. **Repro**: Read `test/AGENTS.md` in the repo first — it is the verification-level
   router. When it exists it is authoritative: it selects L1/L2/L3 and names the test
   surface that owns the samples, fixtures, and commands, so follow it there instead
   of re-deciding any of that here. Only when it is absent, select the level yourself
   from the root cause and read the closest **existing** `AGENTS.md` / `CLAUDE.md`
   that governs the implicated production path and its test directory; do not block
   merely because a guessed instruction path is absent. Either way, each target
   boundary lands on one of these levels:
   - **L1 — focused unit/function boundary**: the behavior is deterministic inside
     one function/module and external dependencies can be mocked. Prefer the nearest
     existing unit test and exercise the real production function.
   - **L2 — component/API integration boundary**: the failure depends on routing,
     persistence, middleware, or interaction across modules but can run locally.
     Prefer the nearest existing integration/API test and its fixtures.
   - **L3 — product/e2e boundary**: the symptom inherently depends on a real browser,
     service process, authentication flow, or deployed integration that L1/L2 cannot
     faithfully reach. Use managed local services only here, plus any skill the
     selected surface's own instructions name.
   Record every `verification_decision` in this plan item as
   `<L1|L2|L3> — <target boundary> — <reason> — <owning instruction/test path>`;
   a work item can carry more than one. When the router returns
   `NEEDS_MORE_EVIDENCE`, or the bug report and root-cause evidence do not identify a
   target boundary, record `NEEDS_MORE_EVIDENCE` and stop via the Callout contract
   instead of guessing. Reproduce on the selected surface, following its existing
   repository instructions.
   **Reading the surface's instructions is not the same as obeying them, and Repro
   cannot be marked done until this plan item records both:**
   - **Sample source** — the real input the bug report points at. Record the exact
     command that fetched it together with its real output, so a reviewer can re-run
     that command and land on the same input. When you instead reuse a fixture already
     in the repo, name the property of the reported case it corresponds to (same chart
     type, same config shape) — a bare path does not establish that it reproduces
     *this* bug. Data you composed yourself is **not** a reproduction: it proves your
     understanding of the defect, not the defect. When the sample cannot be obtained
     (Societas' presentation surface calls this `BLOCKED`), that is a terminal state
     and an expected outcome — stop via the Callout contract and ask the user for it,
     listing the places you looked: the work item's relations, comments and
     attachments, any linked PR's test data, and the repository's fixture directory.
     Never substitute invented data to keep the run moving.
   - **Production entry point** — the fixture, harness, or pipeline named by the
     surface's own instructions, plus any flag it mandates. Importing an inner module
     directly bypasses the routing that decides which implementation branch the real
     input takes, so a test written that way can pass while the reported bug is
     untouched. If the surface prescribes an exploratory run before writing
     assertions, do that run and record what the real artifact actually contained.
   Prefer an existing focused test or a
   minimal harness around the real production function. Do not bootstrap the
   entire application environment when import stubs or an existing unit-test
   fixture can reach the real path. Capture the reproduction **failing first** —
   run it and record the actual failing output / non-zero exit **before** any fix
   exists; a check that only passes post-fix is NOT a reproduction. A non-zero exit
   alone is not a reproduction either: the case must reach the decision's declared
   target boundary and fail there for the reported reason. If it stops short, that
   is `NOT_REACHED` — fix the case or its prerequisites and retry; say so in the
   plan item rather than collapsing it to `blocked`. If the fast
   path reuses a linked fix commit (the tree already contains the fix), demonstrate
   the repro anyway by reverting the fix (`git stash` or checkout the pre-fix file),
   showing the test fails, then restoring it. One deterministic failing reproduction
   is sufficient; mark **Repro** done only after pasting that failing evidence. Do
   not touch
   unrelated Git LFS files during reproduction. Record every process, port, and
   command started for local testing. Prefer running services under one managed foreground
   shell command that `wait`s for them, so ShellTool keeps the whole process group
   and kills it if the run is cancelled. For a service that must outlive a single
   step, use `shell(timeout=0, ...)` background mode — ShellTool tracks its PID and
   reaps it on session end or E-stop — and stop it explicitly in the Cleanup step.
   Avoid `nohup`, launchd, or other out-of-band detached mechanisms ShellTool
   cannot track.
  Visual evidence is required whenever the bug report describes something a person
  looks at — a slide, chart, table, icon, layout, style, export, download, or
  anything "displayed"/"shown"/"missing"/"wrong" on a rendered surface. Read that
  off the **report's own words**; the verification level is irrelevant to it
  (L1/L2/L3 only identifies the functional regression boundary, and a visible
  export defect still needs RED/GREEN rendered evidence when its regression is L1).
  **Marking Repro done requires exactly one product-proof state:**
   - `Captured — <attest token>` — the RED artifact exists and is registered.
     Copy the RED into a unique run-scoped directory under the OS temp directory
     (`image_compare` only reads there), then call
     `image_compare(action='attest', image_path=<red>)` and put the returned token
     in this plan item. Attesting now is what makes the later pair provable: a RED
     first produced after the fix exists cannot show the pre-fix state, and step 5's
     comparison will report it as `NOT ATTESTED`.
   - `Blocked — <what is missing, and what you tried>` — you could not capture it.
     This is a **terminal state and an expected outcome**, not a failure: stop via
     the Callout contract and hand the decision to the user. It must carry the
     concrete paths you tried, each with its command and real output — the surface's
     instructions and repository render helper, an installed renderer, and (for a
     missing sample) the work item's relations/comments/attachments and the repo's
     fixture directory. Prefer the product-native renderer when the report depends on
     product-specific rendering; a fallback renderer does not prove capture is
     impossible, and never infer that a renderer is absent without running it.
  There is no third state. "The test environment cannot render it", "the target
  boundary is the XML rather than an image", and "I would have to build a fixture"
  are all `Blocked`, not reasons to proceed without evidence. Never invent input
  data to manufacture a renderable artifact.
  Retain the real surface's RED artifact from the same failing run; visual evidence
  never replaces the functional reproduction.
   - **L1 document/presentation** — render the affected page or slide from the actual
     generated output, never a synthetic recreation.
   - **L3 / Playwright** — reuse its native screenshot or recording. Choose the video
     pair **only when the surface natively records one**; do not switch to video to
     avoid capturing screenshots. For a video-only run, keep the complete video and do
     not extract frames or call `image_compare` — frame extraction cannot reliably land
     on the frame where the defect appears, so a video pair is judged by the user, not
     by a model. On that path say plainly, in both the checkpoint summary and the PR,
     that you assessed only whether the **code change** addresses the root cause and
     that the visual conclusion is pending human confirmation.
   Record the surface, scenario, sanitized data, artifact type/path, and rendering
   inputs needed to repeat the same capture after the fix — step 5 must be able to
   re-run the identical render command against the identical sample.
4. **Fix**: Choose the smallest correct fix from the root cause, code structure,
   and repository rules. This recipe does not prescribe a code solution.
5. **Verify**: Stay on the level recorded in step 3. Promote the
   reproduction case itself into the regression — same case, same inputs, same
   preconditions, same target boundary, same assertions — so the repo keeps a test
   that would catch this bug again; do not re-decide whether a test is warranted.
   One regression case per `verification_decision`, each with its own RED and
   GREEN — merging boundaries into one test function hides which one was red.
   Exception: when the reproduction depends on an external service, a real
   environment, or non-deterministic timing, narrow the regression to the nearest
   deterministic boundary — inject the failure mode the reproduction exposed at the
   external dependency — provided it still exercises the real production error path
   and is red before the fix, green after. Say what moved and why in the evidence,
   and do not commit a case that needs a live external service to CI.
   Exercise the real production path; do not present a
   temporary script that duplicates the implementation as proof of correctness.
   Prove the fix with a **before/after** check: show the regression test FAILS
   without the fix and PASSES with it (e.g. stash/revert the fix → run → fails →
   restore → passes), and record the pytest **exit code**. When the check goes
   through a running service, restart that service after each stash/restore —
   the backend does not hot-reload, so a run against a stale process proves
   nothing. Build the additional local-check list only from commands the repository
   actually configures in its dependency manifest, scripts, checker config, or CI.
   Run applicable configured lint/type/test checks for the changed paths. If a check
   category is requested by prose but no runnable command/checker is configured for
   that code surface, record `<category>: NOT_CONFIGURED` with the manifests/configs
   inspected and continue; this is not a failed check. Do not install or inject a new
   checker to manufacture a command (including `uv run --with ...`, `pip install`, or
   package-manager add), and do not run a checker borrowed from an unrelated
   subproject. Mark **Verify** done
   only after pasting the passing output (exit 0); if any **configured** check is red,
   or the real
   path could not be run, stop via the Callout contract on **Verify** rather than
   marking it done — never report a step as done on unverified or failing output.
   When an L3 decision is
   `BLOCKED / NOT_RUN` because the bug is only observable in an environment you
   cannot reach, do not substitute a stand-in test that skirts the target boundary.
   Stop via the Callout contract with the fix, the static evidence for it, and the
   exact missing prerequisite, and let the user decide whether it goes out
   unverified — do not open the PR yourself on this path.
   When you run the before-fix (failing) and after-fix (passing) checks, **capture
   both outputs** — test id, command, trimmed output, and pytest **exit codes** —
   into a **unique** run-scoped temp file. On POSIX use
   `redgreen=$(mktemp "${TMPDIR:-/tmp}/redgreen-XXXXXX")`; on PowerShell use
   `$redgreen = Join-Path ([IO.Path]::GetTempPath()) ("redgreen-" + [guid]::NewGuid().ToString("N") + ".txt")` followed by
   `New-Item -ItemType File -LiteralPath $redgreen -ErrorAction Stop`. Do not put
   `{bug_id}` or another substituted parameter in the filename. Record the exact
   path in the Verify evidence so step 6 embeds that file's contents into the PR
   description's `### Red→Green proof` block without re-running tests. Remove that
   exact path in Cleanup.
   For visual evidence, produce GREEN by re-running **step 3's exact render command
   against the exact same sample** — only the code state may differ — and keep the
   pair in a unique run-scoped directory under the OS temp directory:
   - **Screenshot pair** — enable the tool with `tools(name="image_compare")` and
     compare both images against the expected correction, passing step 3's attested
     RED as `red_path`. `image_compare` applies only to screenshot pairs; mark them
     captured only when its assessment says `Verdict: CONFIRMED` and `Privacy: SAFE`
     **and its provenance line says the RED was `ATTESTED`**. `NOT ATTESTED` means
     this RED is not the file step 3 registered — a RED rebuilt after the fix cannot
     show the pre-fix state, so do not re-render it here to make the pair match; go
     back and capture it properly. `NOT CONFIRMED` means the capture failed: use its
     observations to correct the fixture or renderer and retry the capture once.
   - **Video pair** — keep the two complete native recordings. Confirm both are
     non-empty outputs from the same scenario; do not extract frames or run an LLM
     comparison. A video pair is judged by the user, not by a model — say plainly
     that you assessed only whether the code change addresses the root cause.
   Use sanitized test data and never publish sensitive content or half a pair. Record
   exactly one state: `Captured — screenshot pair`, `Captured — video pair`, or
  `Blocked — <what is missing, and what you tried>` with manual validation steps.
  For a reported visual symptom, a missing or rejected pair after its retry blocks
  **Verify**: stop via the Callout contract on **Verify**, naming the evidence gap,
  and do not open a PR. A functional GREEN does not override this product-evidence
  gate, and neither does a passing check list — an item is not done until its
  product-proof state is recorded.
6. **PR**: Before committing, verify the checkout is not on `dev` or `main`; create
   a feature branch that follows Societas conventions when needed. Commit and push
   the **feature** branch (never the target branch). Then, **before opening the PR,
   call `plan(action='checkpoint', ask_user=true, summary=…)` and wait for the
   user's approval**; the summary must state the product-proof state (`Captured` with
   its attest token, or `Blocked` with what is missing). When that state is **not**
   `Captured`, the summary must not bury it in a list: lead with the claim as its own
   question — quote the reported symptom, state that you are shipping without a visual
   pair, and ask the user to confirm that judgement — so approving the PR is also an
   explicit approval of the missing visual proof. On the video path, say in the same
   place that the visual conclusion is pending their confirmation because a video pair
   is not model-reviewed. Only after they approve, open a **draft**
   ADO PR
   (`az repos pr create … --draft`) to the target branch and link the bug.
   Build the `--description` from the **PR description template** in the section below,
   embedding the red→green outputs and product-proof state captured in step 5. Keep the final description at
   or below 3900 characters because ADO rejects descriptions over 4000. Two things
   ADO drafts get wrong by default — handle both:
   - **Product evidence**: when the state is `Captured`, after approval and before
     building the final description, upload both files to the access-controlled ADO WIT
     Attachments API. Reuse the ADO token described below without printing it. POST each
     binary with `Content-Type: application/octet-stream` to
     `<ado_org_url>/<url-encoded-project>/_apis/wit/attachments?fileName=<url-encoded-file-name>&api-version=7.1`
     and use the returned JSON `url`. A failed upload or missing URL makes the pair
     `Blocked`; do not publish a half-pair. Use the template's exact screenshot or
     video labels, then re-read the PR description and confirm both returned URLs before
     claiming the evidence is attached.
   - **Description newlines**: build `--description` with REAL newlines, not a literal
     `\n`. A bash double-quoted `"…\n…"` stores backslash-n verbatim and ADO renders it
     as the text `\n`; use `$'line1\n\nline2'`, a heredoc into a variable, or
     `--description "$(printf '%s\n\n%s' "$summary" "$details")"` on POSIX. On
     Windows, never pass a multiline value through `az.cmd`; embedded newlines can
     terminate the wrapper command and drop later arguments such as `--draft`. Create
     the draft with all critical flags and a short single-line description, then PATCH
     the full description as a JSON body with `Invoke-RestMethod`. Obtain an ADO token
     without printing it: on PowerShell use `$token = az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798 --query accessToken -o tsv`; on POSIX use `token="$(az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798 --query accessToken -o tsv)"`. Use the created PR's repository id in the REST URL and never print the token. Build Markdown with a single-quoted here-string plus
     placeholder replacement; PowerShell double-quoted here-strings interpret Markdown
   backticks as escapes. After assigning that Markdown to `$description`, substitute
   the four `<...>` values and run this exact PowerShell PATCH on one physical line:
   `$descriptionBody = @{ description = $description } | ConvertTo-Json -Compress; $prUrl = '<ado_org_url>'.TrimEnd('/') + '/' + [uri]::EscapeDataString('<ado_project>') + '/_apis/git/repositories/<repository_id>/pullrequests/<pr_id>?api-version=7.1'; Invoke-RestMethod -Uri $prUrl -Method Patch -Headers @{ Authorization = "Bearer $token" } -ContentType 'application/json' -Body $descriptionBody | Out-Null`.
   - **CI on a draft**: do not assume draft policies auto-run or that there is only one
     validation build. List all enabled blocking Build policies with this exact nested
     query (substitute only the PR id and organization):
     `az repos pr policy list --id <pr_id> --organization <ado_org_url> --query "[?configuration.type.displayName=='Build' && configuration.isEnabled && configuration.isBlocking].{policyConfigurationId:configuration.id,evaluationId:evaluationId,status:status,buildRunId:context.buildId,buildIsNotCurrent:context.buildIsNotCurrent,lastMergeSourceCommitId:context.lastMergeSourceCommitId}" -o json`.
     Do not query top-level `type`, `buildId`, `buildIsNotCurrent`, or `artifactId`;
     those paths produce a false empty mapping. Reuse every current build. For a Build
     policy with no current build, queue its evaluation with
     `az repos pr policy queue --id <pr_id> --evaluation-id <evaluation_id>`, then
     refresh the mapping and capture the resulting build id. Only when no applicable
     Build policy exists may `az pipelines run` be used as a fallback; capture that
     fallback run id with `--query id -o tsv`. Carry the full policy/build-id mapping
       into step 7 and never queue duplicate runs. A policy is **current** only when
       `buildIsNotCurrent` is exactly `false` and its `lastMergeSourceCommitId` exactly
       equals the PR's current `lastMergeSourceCommit.commitId`. An approved stale policy
       is not green and must be queued again before Review can advance.
7. **Review**: Treat each invocation as **one observe-and-act cycle**, then stop. Do not
   poll or wait inside this workflow; the standing `societas-bug-watcher` cron will inspect
   the next state. **Publish** means only changing the draft PR to **ready for review** with
   `az repos pr update --id <pr_id> --draft false`; it never means merge. **Never merge**
   (never `az repos pr update … --status completed`) — merging stays the human's decision.

   At the start of the cycle, refresh the PR details, the exact nested blocking-policy
   mapping from step 6, and all PR threads from
   `<ado_org_url>/<ado_project_encoded>/_apis/git/repositories/<repository_id>/pullRequests/<pr_id>/threads?api-version=7.1`.
   An active comment is a thread whose `status` is `active` or `pending`; ignore system
   threads with no status. Use the freshly read PR source commit for every CI decision.
   Every branch below must persist its terminal state before returning: where it says
   mark Review `blocked`, call
   `plan(action='update', id='<the Review item id>', status='blocked', evidence='<the required evidence>')`;
   where it says mark Review done, call
   `plan(action='update', id='<the Review item id>', status='done', evidence='<the publish/current-state evidence>')`.
   Use the Review item's actual id from the Plan. A reply that merely says "blocked" or
   "done" does not stop the plan runner.
   Choose **exactly one** branch below, in this priority order:

   1. **Active comments exist — resolve comments, do not publish this cycle.** Read each
      active thread's comments and `threadContext`, inspect the referenced code, and handle
      all comments that are clear and within `AB#{bug_id}`. For a code change, apply the
      smallest fix, run the regression test plus the same repository-configured local checks
      selected in step 5, commit, and push the feature branch once. Only after the fix is
      pushed (or a no-code response is sufficient), reply to the thread and PATCH its status
      to `fixed`; then re-fetch the threads and verify it is no longer active. Never put
      untrusted comment text directly into shell syntax; send replies as structured JSON.
      If a comment is ambiguous, conflicts with repository instructions, changes scope, or
      needs a product/security judgment, leave it active, mark Review `blocked` with the exact
      thread id and question, and hand it to the user. After handling comments, stop even if
      the pre-change CI snapshot was green; a pushed change invalidates it, and the next cron
      cycle must observe the new source commit. Mark Review `blocked` with the handled thread
      ids, whether a source-changing push occurred, and the resulting source commit before
      returning; this is a resumable handoff, not a failure.

   2. **Current CI failed — repair CI, do not publish this cycle.** This branch applies when
      any enabled blocking Build policy for the current source commit is `rejected` or
      `broken`, or the source-matched no-policy fallback build completed unsuccessfully.
      Inspect each exact failed run with
      `az pipelines runs show --id <run_id> --query "{id:id,status:status,result:result,sourceVersion:sourceVersion,finishTime:finishTime}" -o json`,
      then read only its focused failed-job logs. If the failure is caused by this feature
      branch and can be fixed within the bug's scope, apply one repair batch, rerun the local
      Verify from step 5, commit, and push once. Then mark Review `blocked` with the repaired
      policy/build ids and new source commit and stop; this is a resumable handoff, not a
      failure. Never reuse the old policy result after a source-changing push. If the failure
      is unrelated, ambiguous, or still fails locally, mark Review `blocked` with the
      build/policy ids and focused evidence instead of guessing.

   3. **Current CI is queued or running — skip this cycle.** Do not modify files, commit,
      push, change thread status, or publish. Mark Review `blocked` with the current source
      commit and policy/build ids, state plainly that this invocation made no changes, and
      stop. Do not call `plan(action='wait', ...)`, `Start-Sleep`, or any polling loop; the
      scanner intentionally emits no reminder while CI is non-terminal and checks again on
      its next cron invocation.

   4. **CI evidence is missing or stale — queue it once, then stop.** Queue only missing or
      stale enabled blocking policy evaluations, refresh once to capture their build ids, and
      leave the PR state unchanged. Do not modify code or publish. Mark Review `blocked` with
      the source commit plus queued policy/build ids and return; the next cron invocation
      observes the resulting queued/running/terminal state.

   5. **CI is green and no active comments exist — publish.** Immediately before publishing,
      re-read the PR source commit, blocking-policy mapping, and threads. Publish only when
      there are still no `active`/`pending` threads and every enabled blocking Build policy is
      `approved`, has `buildIsNotCurrent=false`, and has `lastMergeSourceCommitId` equal to
      that source commit. Only when no applicable policy exists may a recorded fallback run
      authorize publishing, and only when it is `completed`, has `result=succeeded`, and its
      `sourceVersion` equals the same source commit. If any value changed, do not publish;
      stop and let the next cron cycle classify the new state. If the PR is still a draft,
      run `az repos pr update --id <pr_id> --draft false`; if it is already ready, make no
      state change. Mark Review done and hand the ready PR to the human for final review and
      merge.

## PR description template

Fill `--description` with this structure (real newlines via the shell-native methods
above; trim long test output with PowerShell `Get-Content -Tail <n>` or POSIX
`tail -n <n>`; do **not** use `<details>` — ADO's collapsible rendering is unreliable).
For `### Product verification`, emit exactly one of the captured pair or the two
fallback forms; trim test output further when needed rather than dropping the visual
proof state.

### Summary
<root cause, one line> — <fix, one line>. Fixes AB#{bug_id}.

### Red→Green proof
Verification level: `<L1|L2|L3>` — <why that level, one clause>

Test: `<test id / command>`
<!-- multiple issues: one Test: line and one before/after pair per issue,
     each prefixed `issue1 · <symptom>`; trim output harder to stay under 3900 chars -->

**Before fix — FAILS (exit <code>):**
```
<trimmed failing output>
```
**After fix — PASSES (exit 0):**
```
<trimmed passing output>
```

### Self-review
- Root cause: …
- Fix rationale (smallest correct fix): …
- Files changed (N): …
- Blast radius (callers / scope): …
- Sensitive paths: none / <flag>
- Reversibility: …
- Test coverage: regression test added / existing …

### Risk
<level + why: safety, sensitive-path touch, rollback>

### Product verification (Test SOP)
Surface: `<L1|L2|L3 + owning test/artifact>`
Scenario: `<case + inputs/actions>` · Rendering: `<viewport or page/slide/render size>` · Data: `<sanitized fixture/account>`
Evidence type: `Screenshot pair`
LLM visual verdict: `CONFIRMED` — `<RED observation; GREEN observation; why the reported symptom is visibly gone>`

| RED — before fix | GREEN — after fix |
|---|---|
| ![RED — before fix](<ADO attachment URL>) | ![GREEN — after fix](<ADO attachment URL>) |

<!-- For video evidence, replace Evidence type/verdict/table above with exactly: -->
Evidence type: `Video pair — visual result pending human confirmation`
The code change was assessed against the root cause; the recordings were not
model-reviewed. Please confirm the visual result before merging.
- [RED — before fix video](<ADO attachment URL>)
- [GREEN — after fix video](<ADO attachment URL>)

<!-- When no valid pair exists, replace the Surface/Scenario/evidence block above
  with exactly this line — there is no "not visually observable" option: -->
Blocked — <what is missing and the prerequisite it needs>. Attempted: <each path
tried, with its command and result>. Manual validation: <exact steps>.

## Bug Fix guardrails

- **Bounded root cause**: try at most two materially different root-cause theories.
  If both fail to produce a working fix, stop via the Callout contract, preserve
  evidence, and record it as a **fix failure** — do not keep looping on the same bug.
- **Stay in scope**: apply the smallest fix for this bug only. Do not expand the fix
  **beyond the scope** of `AB#{bug_id}` (unrelated refactors, drive-by cleanups)
  without asking the user first.
- **Re-reproduce after fixing**: after applying the fix, **reproduce it again** with
  the same case. If it **still reproduces**, the fix is wrong — return to Root cause
  instead of opening a PR.
- **Escalate, don't guess**: if the bug cannot be reproduced, required information is
  missing, or a regression test cannot be added, **pause and ask the user** rather
  than proceeding on unverified assumptions — expressed through the **Callout
  contract** above.

Launching this workflow authorizes autonomous use of its declared tools
(`shell`, `plan`, `tools`, `image_compare`, `config_praestoclaw`): within that scope — investigate,
reproduce, fix, verify, commit to a task feature branch, and push that **feature**
branch — run without stopping for per-action approval. Use the Societas
repository's own instructions and skills for debugging, commits, and PRs instead
of duplicating those changing details in this recipe.

The one irreversible outward step needs an explicit human sign-off: **before
opening the ADO PR** (step 6) — which targets the shared branch and links the bug
— call `plan(action='checkpoint', ask_user=true, summary=<the branch, target, and
bug it will open a PR for>)` and wait for the user's approval, which reaches them
in their chat. Open the PR only after they approve. That approval also covers step 7's
autonomous drive to green and the draft→ready flip (in-scope, no second checkpoint);
**merging stays the human's decision**. Do NOT add extra checkpoints for the in-scope steps.

## Cleanup

On success, failure, or cancellation, release resources created by this run:

- Stop backend/frontend servers, browsers, debuggers, watchers, and other local
  processes started by this run, then confirm their ports are free.
- Remove artifacts created by this run, including the exact Red→Green file and visual
  proof directory, after upload or immediately if the PR flow aborts; never glob.
- Clean up a temporary worktree or branch only after confirming it has no
  uncommitted work. Never remove the user's pre-existing worktrees, branches,
  stashes, or uncommitted files.
- Do not rewrite the user's primary checkout or leave a stale plan/checkpoint.
- List released resources in the final response. If something cannot be released
  safely, report its path, PID or port, and the reason.
