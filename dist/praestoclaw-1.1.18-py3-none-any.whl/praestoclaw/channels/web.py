"""
Web channel — HTTP/SSE/WebSocket channel via self-hosted web server.

Routes messages through the message bus using per-request asyncio.Queue
for bridging synchronous HTTP request-response with async bus messaging.
"""

from __future__ import annotations

import asyncio
import uuid
from typing import Any

from loguru import logger

from praestoclaw.bus.events import EventType, StreamingChunk
from praestoclaw.bus.queue import MessageBus
from praestoclaw.channels.base import BaseChannel
from praestoclaw.config.schema import ChannelType


class WebChannel(BaseChannel):
    """HTTP/SSE/WebSocket channel via self-hosted web server."""

    def __init__(self, bus: MessageBus, allow_from: list[str] | None = None) -> None:
        super().__init__(bus, allow_from)
        # Per-request response routing: channel_id -> asyncio.Queue[str | None]
        self._response_queues: dict[str, asyncio.Queue[str | None]] = {}
        # Per-request streaming routing: channel_id -> asyncio.Queue[StreamingChunk | None]
        self._stream_queues: dict[str, asyncio.Queue[StreamingChunk | None]] = {}
        # Push notification queues for connected WebSocket clients (scheduler/background jobs)
        self._push_queues: dict[str, asyncio.Queue[str | None]] = {}
        self._running = False

    @property
    def name(self) -> str:
        return ChannelType.WEB

    @property
    def is_connected(self) -> bool:
        """True when at least one WebSocket client is connected."""
        return bool(self._push_queues)

    async def start(self) -> None:
        self._running = True
        logger.info("Web channel started")

    async def stop(self) -> None:
        self._running = False
        # Signal all waiting queues to terminate
        for rq in self._response_queues.values():
            try:
                rq.put_nowait(None)
            except asyncio.QueueFull:
                pass
        for sq in self._stream_queues.values():
            try:
                sq.put_nowait(None)
            except asyncio.QueueFull:
                pass
        for pq in self._push_queues.values():
            try:
                pq.put_nowait(None)
            except asyncio.QueueFull:
                pass
        self._response_queues.clear()
        self._stream_queues.clear()
        self._push_queues.clear()
        logger.info("Web channel stopped")

    async def send(self, channel_id: str, content: str, **kwargs: Any) -> bool:
        """Route outbound messages to the correct per-request queue.

        Returns ``True`` when the payload reached a listener and ``False`` when it
        was dropped at tier 5. This distinction is not cosmetic: an approval card
        pushed to a disconnected client used to be indistinguishable from a
        delivered one, so ``plan.py`` persisted the row and blocked for the whole
        checkpoint timeout on a card nobody could ever see.

        Routing tiers (first match wins):

        1. Per-request response queue keyed on ``channel_id`` (HTTP/SSE
           submit-and-wait).
        2. Push queue keyed on ``route_hint`` from kwargs (precise push
           for unsolicited replies whose synthetic ``channel_id`` —
           e.g. ``a2a:notify:<pid>`` — does not itself identify a
           connection, but whose ``route_hint`` carries the originating
           connection's session_key alias).
        3. Push queue keyed on ``channel_id`` (precise push when the
           channel_id is itself the connection's session_key).
        4. Broadcast across every push subscriber (scheduler / notify
           tool / background tasks with no specific destination).
        5. Drop with a warning (no listeners at all — request likely
           timed out or user disconnected).
        """
        q = self._response_queues.get(channel_id)
        if q is not None:
            try:
                q.put_nowait(content)
            except asyncio.QueueFull:
                # Full queue means this payload was DROPPED. Reporting delivery
                # here would recreate the very bug this return value exists to
                # prevent, just on a different branch.
                logger.warning(f"Response queue full for {channel_id}")
                return False
            return True

        # Precise push via route_hint — agent-loop-forwarded from the
        # originating InboundMessage (e.g. a2a runtime publishes a notify
        # with route_hint=session_key so the reply lands on the exact WS
        # that started the A2A flow rather than fan-out).
        route_hint = kwargs.get("route_hint")
        precise: asyncio.Queue[str | None] | None = None
        if isinstance(route_hint, str) and route_hint:
            precise = self._push_queues.get(route_hint)
        if precise is None:
            precise = self._push_queues.get(channel_id)
        if precise is not None:
            try:
                precise.put_nowait(content)
            except asyncio.QueueFull:
                logger.warning(f"Push queue full for {route_hint or channel_id}")
                return False
            return True

        if self._push_queues:
            # Broadcast notifications (scheduler, notify tool, background tasks) to WS clients
            any_delivered = False
            for pid, pq in list(self._push_queues.items()):
                try:
                    pq.put_nowait(content)
                    any_delivered = True
                except asyncio.QueueFull:
                    logger.warning(f"Push queue full for {pid}")
            # One saturated subscriber must not mask a fan-out that reached the
            # others; only report failure when nobody took it.
            return any_delivered

        logger.warning(
            f"Response dropped: no queue for channel_id={channel_id} "
            f"route_hint={route_hint or '-'} (request may have timed out)"
        )
        return False

    async def send_streaming(self, channel_id: str, chunk: StreamingChunk) -> bool:
        """Route streaming chunks to the correct per-request queue."""
        q = self._stream_queues.get(channel_id)
        if q is not None:
            try:
                q.put_nowait(chunk)
                return True
            except asyncio.QueueFull:
                logger.warning(f"Stream queue full for {channel_id}")
                return False
        return False

    def register_request(self, channel_id: str) -> asyncio.Queue[str | None]:
        """Register a per-request response queue. Returns the queue to await."""
        q: asyncio.Queue[str | None] = asyncio.Queue(maxsize=1)
        self._response_queues[channel_id] = q
        return q

    def unregister_request(self, channel_id: str) -> None:
        """Clean up queues after request completes."""
        self._response_queues.pop(channel_id, None)
        self._stream_queues.pop(channel_id, None)

    def register_stream(self, channel_id: str) -> asyncio.Queue[StreamingChunk | None]:
        """Register a streaming queue for SSE/WS. Returns queue to iterate."""
        q: asyncio.Queue[StreamingChunk | None] = asyncio.Queue(maxsize=100)
        self._stream_queues[channel_id] = q
        return q

    def register_push(
        self,
        connection_id: str,
        *,
        aliases: tuple[str, ...] | list[str] = (),
    ) -> asyncio.Queue[str | None]:
        """Register a push notification queue for a persistent connection.

        Push queues receive unsolicited messages (scheduler notifications,
        a2a inbound / reply notifications, background job results) that
        don't match any per-request response queue.

        ``aliases`` lets the caller pre-register additional channel_ids
        that should resolve to the same queue. The standard pattern is
        for a long-lived channel (WebSocket, IDE plugin, etc.) to alias
        its connection under the agent-loop ``session_key`` so the a2a
        runtime / scheduler / any other unsolicited push source can
        publish to the bus with ``channel_id == session_key`` and have
        :meth:`send` route precisely back to the originating connection
        instead of falling back to a fan-out broadcast.

        Aliases can also be added later via :meth:`alias_push` — useful
        when the session_key is only known after the first inbound
        message is parsed (which is the case for the local-webchat WS
        path: ``session_key`` is derived from the inbound envelope's
        sender_id + conversation_id).
        """
        was_empty = not self._push_queues
        q: asyncio.Queue[str | None] = asyncio.Queue(maxsize=50)
        self._push_queues[connection_id] = q
        for alias in aliases:
            self.alias_push(alias, connection_id)
        # First WebSocket client → channel is now connected
        if was_empty:
            self._bus.events.emit(EventType.CHANNEL_CONNECTED, {"channel": self.name})
        return q

    def unregister_push(self, connection_id: str) -> None:
        """Remove a push notification queue when a connection closes.

        Also drops any aliases that point to the same queue (registered via
        :meth:`alias_push` or the ``aliases`` arg of :meth:`register_push`)
        so a closed connection doesn't leave dangling precise-routing
        entries behind that would otherwise mis-route to a stale queue.
        """
        target = self._push_queues.pop(connection_id, None)
        if target is None:
            return
        for key in [k for k, q in self._push_queues.items() if q is target]:
            self._push_queues.pop(key, None)

    def alias_push(self, alias: str, connection_id: str) -> None:
        """Map *alias* to the existing push queue for *connection_id*.

        Standard pattern: a long-lived channel (WebSocket, etc.) ingests
        its first message, derives an agent-loop ``session_key`` from the
        envelope, and aliases the connection under that key so any future
        push routed by ``send(channel_id=session_key, ...)`` lands
        precisely on this connection. Idempotent.
        """
        existing = self._push_queues.get(connection_id)
        if existing is None or not alias or alias == connection_id:
            return
        # Don't clobber an unrelated queue already living under this alias
        # (e.g. a different connection that also picked the same alias).
        if alias in self._push_queues and self._push_queues[alias] is not existing:
            return
        self._push_queues[alias] = existing

    @staticmethod
    def make_channel_id(prefix: str = "web-req") -> str:
        """Generate a unique channel_id for a request."""
        return f"{prefix}-{uuid.uuid4().hex[:12]}"

    async def submit_and_wait(
        self,
        *,
        channel_id: str,
        sender_id: str,
        content: str,
        timeout: float = 300,
    ) -> str:
        """Submit a message through the bus and wait for the response.

        Creates a response queue, publishes via _handle_message, and awaits
        the agent's response with a timeout.
        """
        response_queue = self.register_request(channel_id)
        try:
            await self._handle_message(
                channel_id=channel_id,
                sender_id=sender_id,
                sender_name=sender_id,
                content=content,
            )
            result = await asyncio.wait_for(response_queue.get(), timeout=timeout)
            if result is None:
                raise TimeoutError("Channel shutting down")
            return result
        finally:
            self.unregister_request(channel_id)
