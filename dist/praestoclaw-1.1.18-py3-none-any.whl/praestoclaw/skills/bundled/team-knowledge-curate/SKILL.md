---
name: team-knowledge-curate
description: Turn a saved capture into knowledge-base changes the group confirms twice — once on scope, once on the diff — then publish.
metadata:
  activation:
    praesto-tag-exp-only: true
    keywords:
      - 知识库
      - 团队知识库
      - 整理到知识库
      - 更新知识库
      - 更新到kb
      - 写入知识库
      - 沉淀到知识库
      - 配置知识库
      - 知识库配置
      - 知识库仓库
      - knowledge base
      - team kb
      - curate knowledge
      - publish to kb
      - configure knowledge base
    patterns:
      - "(?i)(整理|沉淀|归档|写入|录入|更新|同步|补充|发布).{0,24}(知识库|kb|team knowledge)"
      - "(?i)(知识库|team kb).{0,24}(整理|沉淀|归档|写入|录入|更新|同步|补充)"
      - "(?i)(配置|设置|绑定|指定|换|改).{0,16}(知识库|kb)"
      - "(?i)(知识库|kb).{0,12}(配置|设置|绑定|指定)"
      - "(?i)(知识库|kb).{0,12}(仓库|repo|目录|文件夹|路径)"
      - "(?i)(update|curate|publish|write|add).{0,24}(knowledge base|team kb|\\bkb\\b)"
      - "(?i)(knowledge base|team kb).{0,24}(update|curate|publish|write|add)"
      - "(?i)(configure|set up|bind|point).{0,24}(knowledge base|team kb|\\bkb\\b)"
      - "(?i)(把|将).{0,32}(整理|沉淀).{0,16}(进|到).{0,8}(知识库|kb)"
  requires:
    tools: [kb_scope, kb_inspect, kb_draft, kb_publish]
  os: [win32]
---

# Team Knowledge Curation

Second stage of the two-stage flow. Collection normally happened already:
verbatim Teams material is cached and folded into a capture snapshot. Your job
is to turn that evidence into changes **this** knowledge base will accept, get
the group to confirm them twice, and publish. If no snapshot exists yet, step 1
tells you how to collect one first.

You never invent the destination. Every repository states its own rules and
those rules change; read them each time.

## Hard rules

1. **The repository's rules win.** Read `kb_inspect(action="rules")` for the
   area you intend to touch before drafting anything. Rules cascade: the root
   states general ones, each folder narrows them, and a rule may **delegate**
   to another document ("only use the sources listed in sources.md"). Follow
   the delegation — `rules` returns those documents marked `delegated_from`,
   and a constraint you did not open still binds you.
2. **A conflict is reported, never drafted around.** If the material breaks a
   stated rule — the wrong source, verbatim content where the repository asks
   for summaries, the wrong location — record it with
   `kb_draft(action="blockers")`. Staging refuses while a blocker is open. The
   group decides: change the draft, or knowingly override. An override is
   written into the commit message.
3. **Two confirmations, both in the group, in plain language.** Scope first,
   diff second. Ask as an ordinary chat message, **end your turn**, and read
   their reply when it arrives on the next one. Any group member may answer.
   Record every answer with `kb_draft(action="approve")`, quoting their words.
   These two are the *only* gates. Do not invent a third out of the plan tool's
   checkpoint: in a group session nothing pauses for a button, and asking the
   same question a second way makes a click look like an answer nobody spoke.
4. **Only a clear yes is an approval.** You are reading intent out of chat, so
   read it conservatively. "可以 / 就这样 / 发吧 / ok, go ahead" is approval;
   "改一下 / 再看看 / 等等" is `changes_requested`; "不行 / 算了" is `rejected`.
   Silence, a question, a partial answer or an emoji is **none of them** — ask
   again rather than deciding for them. An answer about something else entirely
   is not an answer to this. The `quote` must be a message a **person** sent:
   tool output describing a decision is not a person agreeing to one, and is
   refused.
5. **Never publish what the group has not seen.** `kb_publish` runs only after
   an approval for **this exact diff** is on record. Restaging voids it: the
   content changed, so what they agreed to no longer exists.
6. **The review branch is disposable and yours.** Staging pushes the proposal
   to `praesto/review-*` so the group can read a real commit. It is deleted
   when the task is published or cancelled. Never point it at anything else,
   and never leave it behind on purpose.
7. **Provenance survives.** Every drafted statement traces back to a capture
   record and, where one exists, the original Teams deep link. A claim you
   cannot source does not enter the knowledge base.
8. **Say what you left out.** Gaps in the capture (`source_gap`) and units the
   group dropped are reported, not quietly discarded.
9. **One task at a time.** If a curation task is already open in this
   conversation, resume or cancel it — do not start a second.
10. **Do not touch the evidence.** The capture snapshot is append-only input.
11. **Your own messages are not evidence.** The capture contains this chat's
    whole history, and a large part of it is you — `PraestoClaw` in production,
    `PraestoClawStaging` in staging, named in the turn's `Your identity` line.
    The knowledge base records what the *team* worked out, never what you
    previously told them. A statement whose only source is a message you sent
    is unsourced by rule 7: drop it, or find the human message it actually came
    from. Where the group confirmed something you proposed, the evidence is
    *their* confirmation, not your proposal.
12. **The group chooses its knowledge base; you never do.** Which repository
    and folder this conversation writes to comes from `kb_scope`, set from what
    the group actually said — asked now, or said earlier in this chat. Saving it
    announces itself to the group so a wrong reading gets corrected. A
    repository outside the allowed list cannot be reached by asking again — it
    takes a config change by the person the refusal names.

## Workflow

### 1. Resume, or make sure this group has a knowledge base

`kb_draft(action="show")` first. If a task is already open, continue from its
status instead of starting over.

Otherwise check where this group's knowledge goes:

```
kb_scope(action="show")
```

**If it is not configured, configure it before anything else.** Prefer asking
the group, in one message, which repository to use and — optionally — which
folder inside it. When they have already said it earlier in the conversation,
you may take it from there instead of asking again. What you must never do is
choose a repository or folder nobody named.

```
kb_scope(action="set", repo="<what they said>", subfolder="<what they said>")
```

Saving it posts a short message to the group naming what was recorded, so they
can correct it — that is why taking the answer from earlier chat is acceptable.
The reply's `announced_to_group` says whether that message went out; when it is
`false` the announcement is yours to make. Either way do not repeat it back a
second time.

Never substitute a similar-looking name from the list. `show` returns the
repositories that may be chosen — offer them rather than guessing. Two refusals
are possible and they are not the same thing:

- **Not an allowed repository.** Only the person named in the reply can widen
  that list, in the config on the machine running this agent. Relay it, and stop
  — configure again after they confirm it is done.
- **The folder does not exist.** Ask the group again with the folders the reply
  lists. Do not invent a path, and do not quietly drop the folder they asked for
  and bind the whole repository instead.

The subfolder is where this group's knowledge *prefers* to live, not a fence:
read its rules first and draft there by default, but follow the repository's own
conventions when they point elsewhere.

Once a binding exists:

```
kb_draft(action="start", user_request="<what the group asked, verbatim>")
```

This picks the newest capture, syncs the knowledge base, pins the commit the
work is based on, and returns an inventory of what was captured — counts, time
ranges, transcript sizes and any gaps. That inventory is your menu; the
snapshot itself stays on disk.

**If `start` reports that no capture snapshot exists**, the material has simply
not been collected yet — the group asked for the destination without the
collection step. Collect it first, in this same turn:

```
tools(name="team-knowledge-capture", action="skill")
```

Follow those instructions to produce a snapshot, then come back here and run
`kb_draft(action="start")` again. Never draft from your memory of the chat: by
rule 5 every statement you publish must trace back to a capture record, and a
recollected message is not one. If that skill comes back unavailable, say so
and stop rather than reconstructing the discussion yourself.

### 2. Learn this repository's rules

```
kb_inspect(action="rules", path="<the area you think this belongs in>")
kb_inspect(action="tree", path="<that area>")
kb_inspect(action="read", path="<a neighbouring document>")
```

Read every returned rule document, including the ones marked `delegated_from`
— those were pulled in because another rule pointed at them, and they carry
constraints the pointing document only alludes to.

Ask specifically:

- **May this material be used at all?** Some repositories restrict which
  sources feed the knowledge base. Being asked in a chat is not the same as
  that chat being an accepted source.
- **May it be stored in this form?** A repository that keeps structured
  summaries and source links does not accept a verbatim chat copy, however
  convenient that would be.
- **Does this folder narrow the rule further?** A folder may accept material
  the repository generally refuses, or the reverse.

Read a real neighbouring document too. Matching the shape of what is already
there does more for acceptance than any general instruction about good writing.

If nothing in the repository fits the material, say so and propose a new area
with reasoning — do not force knowledge into an unsuitable place.

### 3. Record any conflict before drafting

Every rule you find that this material appears to break becomes a blocker:

```
kb_draft(action="blockers", blockers=[
  {"rule_source": "context/sources.md",
   "rule": "<the rule, quoted>",
   "conflict": "<how this material breaks it>"}
])
```

Do this **before** staging. `stage` refuses while a blocker is open, and that
is deliberate: a finished-looking diff that quietly walked past a rule is
exactly the artefact a group approves by mistake.

### 4. Extract knowledge units

Read the capture and record what you found:

```
kb_draft(action="units", units=[
  {"type": "decision", "title": "...", "content": "...",
   "evidence": [{"capture_record": 0, "message_id": "...", "url": "https://teams..."}]}
])
```

Types: `fact`, `decision`, `action`, `risk`, `question`, `background`, `status`.
Separate what was *decided* from what was merely *discussed*; mark anything
unconfirmed as such in `confidence`.

Skip your own messages while you read (rule 11). Your earlier answers, summaries
and status reports look exactly like well-formed knowledge units, which is the
trap: publishing them launders your own output back in as a team fact, and the
next capture re-reads it as evidence. Attribute by the sender's display name,
not by how authoritative the text sounds. A question you answered contributes
at most the *question* — the answer needs a human source or a group
confirmation before it counts.

### 5. First confirmation — scope, and any rule conflict

Post the units in the group as an ordinary message, grouped and numbered, and
ask which belong in the knowledge base. **If you recorded blockers, put them in
the same message** — quote the rule, name the document, and say plainly what it
means. For example: "这个群不在 `context/sources.md` 的白名单里，按 KB 的规则它
的内容不能直接进 Context。要改成只写有 GitHub 证据的部分，还是你们决定破例？"

Say plainly what you need back, then **end your turn**. There is no button; you
are waiting for someone to type. Do not call `select`, `stage` or anything else
in this turn — nothing has been agreed yet.

Their reply arrives as the next message. Read it, then record it:

```
kb_draft(action="approve", stage="scope",
         decision="approved|changes_requested|rejected",
         quote="<their exact words>", by="<who answered>")
kb_draft(action="select", unit_ids=[...])
```

The quote is required, and `approve` refuses on the same turn the question was
asked — the record has to be a real reply, not your own summary of one.

If the reply is anything short of a clear yes, do not round it up. "都行" or a
thumbs-up is not "approved"; ask which ones they mean. Answers that pick a
subset ("只要第 1、3 条") are an approval of *that* subset — record the quote and
pass exactly those ids to `select`.

Record what they decided about each blocker:

```
kb_draft(action="resolve_blocker", blocker_id="b1",
         resolution="resolved|overridden", note="<their reasoning>", decided_by="<who>")
```

`resolved` means you changed the plan so the conflict is gone. `overridden`
means the group knowingly proceeded anyway — it requires a reason and is
written into the commit message, so the decision survives the chat.

### 6. Record any conflict you find later

If drafting surfaces a further conflict, record it with
`kb_draft(action="blockers")` and take it back to the group. Staging and
publishing both refuse while a blocker is open.

### 7. Draft the documents

Stage the **complete new content** of each file — not a patch — together with
the commit message:

```
kb_draft(action="stage",
         message="<conventional-commit subject, in the repo's own style>",
         changes=[
  {"path": "...", "operation": "create|update", "content": "<full document>",
   "rationale": "<why here, citing the rule>", "units": ["u1", "u3"]}
])
```

This commits the proposal to a disposable review branch and pushes it, so the
group can read a real commit instead of a diff pasted into chat. The message is
part of what they review, which is why it is fixed here rather than at publish
time — changing it later voids their approval like any other edit.

### 8. Second confirmation — the diff

Give the group the `review_url`. Say briefly, in the chat, what the commit
changes and which units it covers, so nobody has to open a link to know what
they are being asked about — then ask them to approve, **end your turn** and
wait.

If `stage` came back with `review_unavailable` instead, this repository would
not take the branch: post the diff itself as an ordinary message and carry on
the same way.

When they answer, record it:

```
kb_draft(action="approve", stage="diff",
         decision="approved|changes_requested|rejected",
         quote="<their exact words>", by="<who answered>")
```

`kb_publish` refuses until an `approved` decision exists **for this exact
diff** — so this is not bookkeeping, it is the gate. Three things it will not
accept, each with a different fix:

- nothing recorded → they have not answered; ask again;
- `changes_requested` / `rejected` → make the change and put the new diff to
  them; never publish the version they turned down;
- recorded but the content moved → you restaged after the approval, so show the
  current diff and get a fresh one.

If they want changes, restage — the review branch is rewritten in place — and
give them the new link. Rejection ends the task (`kb_draft(action="cancel")`),
which also removes the branch.

### 9. Publish

```
kb_publish(approved_by="<who approved>")
```

The commit they reviewed is moved onto the knowledge base unchanged — same sha,
so the link they read and the history agree — and the review branch is deleted
locally and on the remote. Do not pass a `message`: it was settled at staging.

Publishing revalidates that the knowledge base has not moved since the diff was
approved. If it has, it refuses: restage against the new base, give the group
the new link, and get a fresh confirmation.

Report back the commit link, which documents changed, and anything you
deliberately left out — including any rule the group chose to override, which
is now recorded in the commit message as a `KB-Rule-Override` trailer.

## When this does not apply

- "What does the KB say about X?" — that is a question, not a curation task.
- "Summarise this discussion" — summarising in chat writes nothing.
- Collection only ("收集一下这两周的群消息") — that is the capture skill's job
  and it ends at the saved snapshot. Curation starts only when the group asks
  for the knowledge base itself to change.
