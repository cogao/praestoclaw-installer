"""Durable state for a knowledge-base curation task.

A curation task outlives a single turn. The group is asked twice — once to
agree on *what* gets written, once to approve the *diff* — and between those
answers the agent may be restarted, the user may go to lunch, and the KB may
move underneath the draft. So the task lives on disk, keyed by the conversation
that owns it.

Two deliberate omissions:

* **No locking.** One group maps to one agent and one session; a second
  concurrent curation task in the same chat is something the model can see and
  decline. A lock file here would add failure modes (staleness, orphaned locks)
  to prevent a situation the conversation already prevents.
* **No knowledge extraction.** The tool stores whatever units the model
  produced. Which sentence is a decision and which is an aside depends on the
  KB's own conventions, and those change; a deterministic extractor would
  freeze one repository's shape into the code that is supposed to adapt to it.

Staged content is kept *here*, not written into the checkout, so an abandoned
draft leaves no debris in a real git working tree.
"""

from __future__ import annotations

import hashlib
import json
import re
import uuid
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from praestoclaw.kb import kb_root

STATUS_DRAFTING = "drafting"
STATUS_AWAITING_SCOPE = "awaiting_scope"
STATUS_AWAITING_DIFF = "awaiting_diff"
STATUS_PUBLISHED = "published"
STATUS_CANCELLED = "cancelled"

ACTIVE_STATUSES = (STATUS_DRAFTING, STATUS_AWAITING_SCOPE, STATUS_AWAITING_DIFF)
TERMINAL_STATUSES = (STATUS_PUBLISHED, STATUS_CANCELLED)

# A rule conflict is open until the group answers it: either the draft changes
# so the conflict goes away (``resolved``), or the group knowingly proceeds
# anyway (``overridden``) — which is then recorded in the commit message.
BLOCKER_OPEN = "open"
BLOCKER_RESOLVED = "resolved"
BLOCKER_OVERRIDDEN = "overridden"
BLOCKER_STATUSES = (BLOCKER_OPEN, BLOCKER_RESOLVED, BLOCKER_OVERRIDDEN)

OPERATIONS = ("create", "update")

_DEFAULT_MESSAGE_PREFIX = "docs(kb): "
_CONVENTIONAL = re.compile(r"^(docs|feat|fix|chore|refactor|style|test)(\([^)]*\))?!?: ")

# Trailer carrying a knowingly-broken rule into the repository's own history.
OVERRIDE_TRAILER = "KB-Rule-Override"

# What the group answered, and to which of the two questions. Approval used to
# be an Adaptive Card that blocked the turn, so "the group agreed" was implied
# by the card having been resolved. Answers now arrive as ordinary chat
# messages, which means agreement has to become a *record* — otherwise the only
# thing standing between a draft and a push is the model's own account of what
# the group said.
DECISION_SCOPE = "scope"
DECISION_DIFF = "diff"
DECISION_STAGES = (DECISION_SCOPE, DECISION_DIFF)

DECISION_APPROVED = "approved"
DECISION_REJECTED = "rejected"
DECISION_CHANGES_REQUESTED = "changes_requested"
DECISIONS = (DECISION_APPROVED, DECISION_REJECTED, DECISION_CHANGES_REQUESTED)

# Text the runtime writes and hands to the model, which must never be laundered
# back as a human's quote (see ``machine_authored_quote``). Lower-cased; each
# is a fragment the machine emits verbatim and a person would not type.
#   * ``plan``'s checkpoint verdicts and the note that precedes them —
#     ``agent/tools/plan.py:_await_user_approval`` / ``_checkpoint``;
#   * this tool's own instructions, echoed out of a previous result.
_MACHINE_QUOTE_PHRASES: tuple[str, ...] = (
    "user approved this checkpoint",
    "user rejected this checkpoint",
    "checkpoint approval expired",
    "checkpoint approval timed out",
    "checkpoint (waiting for user)",
    "stop and ask the user before proceeding",
    "end your turn",
    "no approval button",
)

_SLUG_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")
_MAX_CONTENT_BYTES = 400_000
_MAX_CHANGES = 20


def _now() -> str:
    return datetime.now(UTC).isoformat()


def tasks_dir() -> Path:
    """``<data_dir>/kb/tasks`` — one directory per conversation."""
    return kb_root() / "tasks"


def conversation_slug(cid: str) -> str:
    value = (cid or "").strip()
    if not value:
        raise ValueError("cid is required")
    return _SLUG_UNSAFE.sub("_", value).strip("_.")[:96] or "conversation"


@dataclass
class KnowledgeUnit:
    """One piece of knowledge the model lifted out of the captured evidence."""

    id: str
    type: str
    title: str
    content: str = ""
    evidence: list[dict[str, Any]] = field(default_factory=list)
    confidence: str = ""
    selected: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class RuleBlocker:
    """A rule this material appears to violate, and what happened about it.

    Modelled explicitly because the failure it prevents is silent. A knowledge
    base states constraints in prose — which sources may be used, what may be
    stored verbatim, what belongs in which folder — and a draft that ignores
    one still produces a clean, plausible diff. The group approves what looks
    right, the rule is broken, and nobody is told.

    So a conflict becomes a thing with a status. It blocks staging until the
    group answers it, and an override is carried into the commit message: the
    decision to break a stated rule belongs in the repository's own history,
    not just in a chat nobody will re-read.
    """

    id: str
    rule_source: str
    rule: str
    conflict: str
    status: str = BLOCKER_OPEN
    resolution: str = ""
    decided_by: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class GroupDecision:
    """One answer the group gave, in their own words.

    ``quote`` is not decoration. The decision is read out of ordinary chat text
    by a model, so the record has to carry what was actually said — otherwise a
    misreading becomes indistinguishable from an agreement, and nothing in the
    repository's history shows which it was.

    ``turn_id`` is the inbound turn the answer arrived on. It is compared
    against the turn the material was shown on, which is what keeps "the group
    approved" from being something the model can produce on its own in the same
    breath as the proposal.

    ``fingerprint`` binds a ``diff`` decision to the exact content that was
    approved, so restaging silently invalidates it.
    """

    stage: str
    decision: str
    by: str = ""
    quote: str = ""
    at: str = field(default_factory=_now)
    turn_id: str = ""
    fingerprint: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class StagedChange:
    """A proposed edit to one document, not yet written to the checkout."""

    path: str
    operation: str
    content: str
    rationale: str = ""
    units: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class CurationTask:
    """Everything needed to resume a curation task in a later turn."""

    task_id: str
    cid: str
    status: str = STATUS_DRAFTING
    created_at: str = field(default_factory=_now)
    updated_at: str = field(default_factory=_now)
    conversation_name: str = ""
    started_by: str = ""
    user_request: str = ""
    capture_path: str = ""
    repo: str = ""
    base_head: str = ""
    units: list[KnowledgeUnit] = field(default_factory=list)
    blockers: list[RuleBlocker] = field(default_factory=list)
    changes: list[StagedChange] = field(default_factory=list)
    decisions: list[GroupDecision] = field(default_factory=list)
    # Fixed when the change set is staged, because the group reviews the commit
    # itself — subject, trailers and all — not just the file contents.
    commit_message: str = ""
    # The scratch branch carrying the proposal for review, and where to read it.
    preview_branch: str = ""
    preview_sha: str = ""
    preview_url: str = ""
    preview_error: str = ""
    # Inbound turn on which each question's material was last put to the group.
    # An answer recorded on the same turn cannot be a reply to it.
    scope_presented_turn: str = ""
    diff_presented_turn: str = ""
    published: dict[str, Any] = field(default_factory=dict)

    # ── derived views ───────────────────────────────────────────────────

    def change_fingerprint(self) -> str:
        """Stable digest of what a diff approval would be approving.

        Covers the base commit and the commit message as well as the content:
        the same documents proposed against a moved knowledge base, or under a
        different subject line, are a different commit — and the group only ever
        read one of them.
        """
        payload = json.dumps(
            {
                "base_head": self.base_head,
                "message": self.commit_message,
                "changes": sorted(
                    [
                        {
                            "path": change.path,
                            "operation": change.operation,
                            "content": change.content,
                        }
                        for change in self.changes
                    ],
                    key=lambda item: item["path"],
                ),
            },
            ensure_ascii=False,
            sort_keys=True,
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def latest_decision(self, stage: str) -> GroupDecision | None:
        for item in reversed(self.decisions):
            if item.stage == stage:
                return item
        return None

    @property
    def scope_approved(self) -> bool:
        decision = self.latest_decision(DECISION_SCOPE)
        return bool(decision and decision.decision == DECISION_APPROVED)

    def diff_approval(self) -> GroupDecision | None:
        """The standing approval for exactly what is staged now, if any."""
        decision = self.latest_decision(DECISION_DIFF)
        if decision is None or decision.decision != DECISION_APPROVED:
            return None
        if decision.fingerprint != self.change_fingerprint():
            return None
        return decision

    @property
    def is_active(self) -> bool:
        return self.status in ACTIVE_STATUSES

    @property
    def selected_units(self) -> list[KnowledgeUnit]:
        return [unit for unit in self.units if unit.selected]

    @property
    def open_blockers(self) -> list[RuleBlocker]:
        return [item for item in self.blockers if item.status == BLOCKER_OPEN]

    @property
    def overridden_blockers(self) -> list[RuleBlocker]:
        return [item for item in self.blockers if item.status == BLOCKER_OVERRIDDEN]

    def unit(self, unit_id: str) -> KnowledgeUnit | None:
        return next((unit for unit in self.units if unit.id == unit_id), None)

    def blocker(self, blocker_id: str) -> RuleBlocker | None:
        return next((item for item in self.blockers if item.id == blocker_id), None)

    def next_unit_id(self) -> str:
        return f"u{len(self.units) + 1}"

    def next_blocker_id(self) -> str:
        return f"b{len(self.blockers) + 1}"

    # ── serialisation ───────────────────────────────────────────────────

    def to_dict(self) -> dict[str, Any]:
        return {
            "task_id": self.task_id,
            "cid": self.cid,
            "status": self.status,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "conversation_name": self.conversation_name,
            "started_by": self.started_by,
            "user_request": self.user_request,
            "capture_path": self.capture_path,
            "repo": self.repo,
            "base_head": self.base_head,
            "units": [unit.to_dict() for unit in self.units],
            "blockers": [item.to_dict() for item in self.blockers],
            "changes": [change.to_dict() for change in self.changes],
            "decisions": [item.to_dict() for item in self.decisions],
            "commit_message": self.commit_message,
            "preview_branch": self.preview_branch,
            "preview_sha": self.preview_sha,
            "preview_url": self.preview_url,
            "preview_error": self.preview_error,
            "scope_presented_turn": self.scope_presented_turn,
            "diff_presented_turn": self.diff_presented_turn,
            "published": self.published,
        }

    def summary(self) -> dict[str, Any]:
        """A compact view — the full staged content would swamp a turn."""
        return {
            "task_id": self.task_id,
            "status": self.status,
            "repo": self.repo,
            "base_head": self.base_head,
            "capture_path": self.capture_path,
            "unit_count": len(self.units),
            "selected_count": len(self.selected_units),
            "open_blockers": [item.to_dict() for item in self.open_blockers],
            "overridden_blockers": [item.to_dict() for item in self.overridden_blockers],
            "scope_approved": self.scope_approved,
            "diff_approved": self.diff_approval() is not None,
            "commit_message": self.commit_message,
            "review_url": self.preview_url,
            "preview_branch": self.preview_branch,
            "preview_sha": self.preview_sha,
            "decisions": [item.to_dict() for item in self.decisions],
            "changes": [
                {
                    "path": change.path,
                    "operation": change.operation,
                    "bytes": len(change.content.encode("utf-8")),
                    "units": change.units,
                }
                for change in self.changes
            ],
            "published": self.published or None,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CurationTask:
        return cls(
            task_id=str(data.get("task_id") or ""),
            cid=str(data.get("cid") or ""),
            status=str(data.get("status") or STATUS_DRAFTING),
            created_at=str(data.get("created_at") or _now()),
            updated_at=str(data.get("updated_at") or _now()),
            conversation_name=str(data.get("conversation_name") or ""),
            started_by=str(data.get("started_by") or ""),
            user_request=str(data.get("user_request") or ""),
            capture_path=str(data.get("capture_path") or ""),
            repo=str(data.get("repo") or ""),
            base_head=str(data.get("base_head") or ""),
            units=[
                KnowledgeUnit(
                    id=str(item.get("id") or ""),
                    type=str(item.get("type") or ""),
                    title=str(item.get("title") or ""),
                    content=str(item.get("content") or ""),
                    evidence=list(item.get("evidence") or []),
                    confidence=str(item.get("confidence") or ""),
                    selected=bool(item.get("selected")),
                )
                for item in (data.get("units") or [])
            ],
            changes=[
                StagedChange(
                    path=str(item.get("path") or ""),
                    operation=str(item.get("operation") or "update"),
                    content=str(item.get("content") or ""),
                    rationale=str(item.get("rationale") or ""),
                    units=list(item.get("units") or []),
                )
                for item in (data.get("changes") or [])
            ],
            blockers=[
                RuleBlocker(
                    id=str(item.get("id") or ""),
                    rule_source=str(item.get("rule_source") or ""),
                    rule=str(item.get("rule") or ""),
                    conflict=str(item.get("conflict") or ""),
                    status=str(item.get("status") or BLOCKER_OPEN),
                    resolution=str(item.get("resolution") or ""),
                    decided_by=str(item.get("decided_by") or ""),
                )
                for item in (data.get("blockers") or [])
            ],
            published=dict(data.get("published") or {}),
            decisions=[
                GroupDecision(
                    stage=str(item.get("stage") or ""),
                    decision=str(item.get("decision") or ""),
                    by=str(item.get("by") or ""),
                    quote=str(item.get("quote") or ""),
                    at=str(item.get("at") or _now()),
                    turn_id=str(item.get("turn_id") or ""),
                    fingerprint=str(item.get("fingerprint") or ""),
                )
                for item in (data.get("decisions") or [])
            ],
            scope_presented_turn=str(data.get("scope_presented_turn") or ""),
            diff_presented_turn=str(data.get("diff_presented_turn") or ""),
            commit_message=str(data.get("commit_message") or ""),
            preview_branch=str(data.get("preview_branch") or ""),
            preview_sha=str(data.get("preview_sha") or ""),
            preview_url=str(data.get("preview_url") or ""),
            preview_error=str(data.get("preview_error") or ""),
        )


class CurationTaskStore:
    """Curation tasks for one conversation, on disk under the profile."""

    def __init__(self, cid: str, *, root: Path | None = None) -> None:
        self.cid = cid
        self.dir = (root or tasks_dir()) / conversation_slug(cid)

    def _path(self, task_id: str) -> Path:
        return self.dir / f"{_SLUG_UNSAFE.sub('_', task_id)}.json"

    def new_task_id(self) -> str:
        stamp = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
        return f"kb-{stamp}-{uuid.uuid4().hex[:4]}"

    def save(self, task: CurationTask) -> None:
        task.updated_at = _now()
        self.dir.mkdir(parents=True, exist_ok=True)
        path = self._path(task.task_id)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(
            json.dumps(task.to_dict(), ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
            newline="\n",
        )
        tmp.replace(path)

    def load(self, task_id: str) -> CurationTask | None:
        path = self._path(task_id)
        if not path.is_file():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        task = CurationTask.from_dict(data)
        return task if task.task_id else None

    def all_tasks(self) -> list[CurationTask]:
        if not self.dir.is_dir():
            return []
        tasks = [
            task
            for path in sorted(self.dir.glob("*.json"))
            if (task := self.load(path.stem)) is not None
        ]
        return sorted(tasks, key=lambda t: t.created_at, reverse=True)

    def active(self) -> CurationTask | None:
        """The newest task still in flight, if any."""
        return next((task for task in self.all_tasks() if task.is_active), None)

    def resolve(self, task_id: str = "") -> CurationTask | None:
        """A named task, the conversation's active one, or its most recent.

        The fall-through to a finished task matters: after a successful publish
        there is no active task, and a repeated ``kb_publish`` (a double-tapped
        card, a retried turn) must be able to answer "already published" rather
        than "no such task", which reads like the work was lost.
        """
        if task_id.strip():
            return self.load(task_id)
        active = self.active()
        if active is not None:
            return active
        return next(iter(self.all_tasks()), None)


def commit_message_for(message: str, task: CurationTask | None = None) -> str:
    """Keep a conventional-commit subject as written; label anything else.

    The repositories in play use conventional commits, so an unprefixed
    sentence would stand out in their history for no reason.

    An overridden rule is appended as a trailer. A group deciding to write
    something a repository's own rules discourage is a real decision, and it
    has to survive the chat it was made in — six months later the commit is the
    only thing anyone will find.

    Built when the change set is staged rather than at publish time, because
    the group now reviews the real commit: the subject and these trailers are
    part of what they are agreeing to.
    """
    text = (message or "").strip()
    subject = text if _CONVENTIONAL.match(text) else f"{_DEFAULT_MESSAGE_PREFIX}{text}"
    overrides = task.overridden_blockers if task else []
    if not overrides:
        return subject
    lines = [subject, ""]
    for blocker in overrides:
        detail = f"{blocker.rule_source}: {blocker.rule}"
        if blocker.resolution:
            detail = f"{detail} — {blocker.resolution}"
        if blocker.decided_by:
            detail = f"{detail} (decided by {blocker.decided_by})"
        lines.append(f"{OVERRIDE_TRAILER}: {detail}")
    return "\n".join(lines)


def preview_branch_name(task_id: str) -> str:
    """Scratch branch carrying a proposal for review.

    Namespaced so it is obvious in a branch list who created it and that it is
    disposable, and derived from the task so a restage rewrites the same branch
    instead of littering the repository with one branch per attempt. Kept to a
    single slash: a ref name becomes a directory path under ``.git/refs/heads``,
    and a deeper one can exhaust the path limit on Windows for a repository
    that is nested at all deeply.
    """
    slug = _SLUG_UNSAFE.sub("-", task_id).strip("-") or "task"
    return f"praesto/review-{slug}"


def validate_change(path: str, operation: str, content: str) -> str:
    """Return an error message for an unusable change, or ``""``."""
    if not path.strip():
        return "Every change needs a path."
    if operation not in OPERATIONS:
        return f"operation must be one of {', '.join(OPERATIONS)}."
    if not content.strip():
        return f"Change to '{path}' has no content."
    if len(content.encode("utf-8")) > _MAX_CONTENT_BYTES:
        return (
            f"Change to '{path}' is larger than {_MAX_CONTENT_BYTES:,} bytes. "
            "Split it across documents."
        )
    return ""


def machine_authored_quote(quote: str) -> str:
    """Return a reason to refuse *quote* as the group's words, or ``""``.

    A ``quote`` is the only evidence that a human agreed, so it has to come
    from a human. The tempting substitute is text the runtime itself wrote and
    handed back to the model: a plan checkpoint's verdict line
    (``✅ User APPROVED this checkpoint``), the checkpoint note that preceded
    it, or this tool's own guidance. Those describe a decision without
    containing one — a click, a timeout, or nothing at all can produce them —
    so recording one as the quote fabricates a consenting group.

    Matching is on the distinctive machine phrasing, not on any word a person
    might plausibly type: someone answering "approved" or "go ahead" is
    unaffected.
    """
    text = quote.strip()
    if not text:
        return ""
    lowered = text.lower()
    for phrase in _MACHINE_QUOTE_PHRASES:
        if phrase in lowered:
            return (
                f"That quote is the runtime's own wording ({phrase!r}), not the group's. "
                "It records that something was decided without carrying what anyone "
                "said — a button click, a timeout, or a tool note reads the same way. "
                "Quote the message a person actually sent, or ask them again."
            )
    return ""


__all__ = [
    "ACTIVE_STATUSES",
    "BLOCKER_OPEN",
    "BLOCKER_OVERRIDDEN",
    "BLOCKER_RESOLVED",
    "BLOCKER_STATUSES",
    "MAX_CHANGES",
    "OPERATIONS",
    "STATUS_AWAITING_DIFF",
    "STATUS_AWAITING_SCOPE",
    "STATUS_CANCELLED",
    "STATUS_DRAFTING",
    "STATUS_PUBLISHED",
    "TERMINAL_STATUSES",
    "CurationTask",
    "CurationTaskStore",
    "KnowledgeUnit",
    "RuleBlocker",
    "StagedChange",
    "conversation_slug",
    "machine_authored_quote",
    "tasks_dir",
    "validate_change",
]

MAX_CHANGES = _MAX_CHANGES
