# Existing feedback and repair routing

Use after lightweight lookup finds candidates, fails or leaves incomplete coverage,
or a repair/version/recurrence question arises. The common feedback workflow still
requires independent investigation, parent review, scoped evidence and cancellation.
These rules apply in personal and shared conversations. Read this resource from the selected feedback package;
loading it does not grant generic GitHub, shell or cloud access to a shared session.

## Establish the same failure

Read candidate issue bodies and existing comments, and relevant PR bodies/state.
Follow returned pagination when omitted content could change the match or whether
there is new evidence. `partial`, truncation, a failed read or a query returning zero
matches is not proof that no corresponding issue exists. Try focused alternative
terms/known IDs within useful bounds; no exhaustive repository survey is required.

Give candidates, source URLs and coverage to the independent investigator along with
the original complaint. Parent verifies its judgment against decisive evidence.
An issue reference or closing PR is a lead, not proof the PR fixes this incident.
Similar titles, generic HTTP 500, nearby dates or a closed issue do not establish
identity. Identify the trigger, expected/actual result and mechanism shared by the
reports; preserve contradictory evidence. Unconfirmed candidates must not suppress
reporting of a distinct failure.

## Choose the outcome

- Confirmed matching repair PR open: say repair is in progress, link the PR and state
  whether it is a draft or ready for review. Do not claim it has merged or shipped.
  This status answer requires zero issue writes and no unnecessary cloud/JIT query.
- Closed PR without merge: not an available repair; investigate and use the issue
  supplement/create route. Closed issue state alone is likewise not a repair.
- Merged PR: call `feedback_lookup(action="release_status", number=<PR>, channel=...)`
  using the known affected client channel. Report the evidence it returns. If a
  current channel's available artifact is confirmed not to contain the merge, name
  that version and suggest waiting for a subsequent release containing the fix.
  This does not establish that no historical/cherry-picked repair was ever published.
  If publication cannot be established because the lookup failed or lacks evidence,
  explicitly say publication/deployment status is unknown, not definitely unreleased.
- Available client artifact proven to contain the fix and affected build proven not
  to contain it: name that available version. Do not compare version strings or use
  latest-version ranking as proof the user's build lacks a fix.
- Affected build already contains the fix, but evidence confirms the same bug:
  supplement the original issue with **suspected recurrence**, supporting evidence
  and affected-build provenance. Do not create a regression issue or reopen by default.
- Affected target version/build unknown: do not ask a version question. State the
  confirmed available fixed version, if any, and explicitly say target version or
  build inclusion is unknown. Do not claim the user needs an upgrade on this evidence.
- Confirmed same-bug issue needing useful evidence: reread its body and comments,
  compare with the final investigation and comment only the additions. Include exact
  evidence and limitations needed to understand the addition; do not repost the full
  old report. If there is nothing new, return the existing URL with zero comments.
- No confirmed same-bug issue: create once with the investigation. A matching PR can
  answer repair status even without an issue; if an unresolved/recurring bug needs a
  report and no original issue exists, create and reference that PR.
- Lookup failed or cannot determine whether an existing issue matches: the user has
  chosen to file anyway. Include **查重失败，可能重复** (translate if appropriate), actual
  failed/limited lookup coverage, candidate links if relevant and all valid evidence.
  Never turn failure into a successful "no matches" claim or drop investigation results.
- A same-bug issue is already confirmed: later PR/release lookup failure leaves repair
  status unknown; reuse that issue. Comment failure must be reported without a new issue.

## Version and publication evidence

Snapshot running version, disk-installed version and channel describe the execution
host only. Establish that the complaint targets this instance before comparing them;
a borrowed shared host, sender device, another agent and a server are different targets.
Running and installed versions can differ after an update; if evidence establishes the
installed build contains the fix but the process still runs an affected build, suggest
restarting. Never infer affected version from where investigation happened.

`release_status` binds channel-specific installer latest.txt, available wheel, mirror
commit/tag and recorded source SHA, then checks whether source contains the PR's merge
(or squash) SHA. A GitHub Release, date ordering, PR head SHA or newer version alone
is insufficient. It reads only current/latest and relevant version records, not a
historical first-fixed-version index. Returned version records describe published
artifacts, not automatically the user's installed build: same-version artifacts can
be rebuilt, overwritten or mapped to multiple source commits. Supply `current_source_sha`
only from verified affected-build evidence. A normal supported mirror installation
can instead use `current_build="published"` with known target version and channel:
confirm the target is this instance, the installed release is standard/supported,
and no evidence identifies a custom or untracked development build or conflicting origin. An official
installer URL in metadata is useful supporting evidence, not mandatory; missing
`direct_url.json` or build SHA alone must not force unknown. The
version's uniquely consistent tag/artifact/source record then supports inclusion;
a build SHA is not required. Custom or untracked development builds, an unidentified affected target/version, conflicting channel or
same-version artifact/source conflicts remain unknown. Official releases may use PEP 440 dev/pre/post versions (the staging mirror does).
A normal installed release with a consistent channel tag/artifact/source record is
supported by this same mapping; the suffix alone does not make it unknown. An untracked development build remains unknown. Do not set published merely
because a version string resembles a release. Cherry-pick inclusion remains unknown. Preserve returned partial/error evidence.

Client release evidence cannot establish Cloud Gateway or Teams Service deployment.
For a server defect without deployment proof, say the PR merged but deployment is
unconfirmed; do not advise upgrading the client or add cloud/JIT queries just to check
publication. Existing evidence scope and cloud rules remain unchanged.

## Existing-issue write boundary

`feedback_lookup(read_issue)` must successfully read the real fixed-repository issue
and comments in this trusted conversation before it grants comment permission. This
receipt is separate from issues created by `feedback_submit`: it does not grant edit
ownership, survive restart or transfer to another conversation. Reread after restart.
Only the parent writes, via `feedback_submit(action="comment")`; it rereads the target
before append. Assignment keeps its existing explicit-issue contract.
