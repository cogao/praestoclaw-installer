"""Async SQLite session store with FTS5 full-text search."""

from __future__ import annotations

import json
import uuid
from datetime import UTC, datetime
from pathlib import Path

import aiosqlite

from praestoclaw.agent.compaction import count_tokens
from praestoclaw.utils.helpers import get_data_dir

_SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    channel TEXT NOT NULL,
    sender TEXT NOT NULL,
    model TEXT,
    parent_session_id TEXT,
    prompt_tokens INTEGER DEFAULT 0,
    completion_tokens INTEGER DEFAULT 0,
    cost REAL DEFAULT 0.0,
    title TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL REFERENCES sessions(id),
    role TEXT NOT NULL,
    content TEXT,
    tool_calls TEXT,
    tool_call_id TEXT,
    tokens INTEGER DEFAULT 0,
    created_at TEXT NOT NULL
);

CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5(
    content,
    content=messages,
    content_rowid=id
);

CREATE TRIGGER IF NOT EXISTS messages_ai AFTER INSERT ON messages BEGIN
    INSERT INTO messages_fts(rowid, content) VALUES (new.id, new.content);
END;

CREATE TRIGGER IF NOT EXISTS messages_ad AFTER DELETE ON messages BEGIN
    INSERT INTO messages_fts(messages_fts, rowid, content) VALUES ('delete', old.id, old.content);
END;

CREATE TRIGGER IF NOT EXISTS messages_au AFTER UPDATE ON messages BEGIN
    INSERT INTO messages_fts(messages_fts, rowid, content) VALUES ('delete', old.id, old.content);
    INSERT INTO messages_fts(rowid, content) VALUES (new.id, new.content);
END;

CREATE TABLE IF NOT EXISTS counters (
    key TEXT PRIMARY KEY,
    value INTEGER NOT NULL DEFAULT 0
);
"""


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _normalize_ts(ts: object, *, fallback: str | None = None) -> str:
    """Normalize a caller-supplied timestamp to the canonical ``_now()`` form.

    All timestamps in ``messages.created_at`` are sorted/compared as strings
    (e.g. ``SessionStore.list_sessions`` orphan handling) and parsed via
    ``datetime.fromisoformat`` elsewhere. ``_now()`` emits UTC ``...+00:00``,
    so caller input must converge on the same shape. We:

    1. Reject non-string input by falling back to ``fallback`` (or, if
       unset, ``_now()``). The parameter is typed ``object`` because the
       defensive check is part of the contract, not just a belt-and-braces
       guard.
    2. Substitute trailing ``Z`` with ``+00:00`` so callers using the
       compact UTC spelling are accepted regardless of which ISO 8601
       sub-format their source emits.
    3. Parse, then force to UTC: naive inputs are assumed UTC; aware
       offsets are converted. This guarantees every stored value is a
       UTC ``...+00:00`` string regardless of caller spelling.
    4. Re-emit via ``datetime.isoformat`` to converge on one shape.

    Unparseable input falls back to ``fallback`` (or ``_now()``) rather
    than poisoning the column with arbitrary strings. Callers that have
    already captured a ``now`` should pass it as ``fallback`` so a malformed
    override does not drift ``messages.created_at`` past the matching
    ``sessions.updated_at`` written in the same transaction.
    """
    if not isinstance(ts, str):
        return fallback if fallback is not None else _now()
    try:
        cleaned = ts[:-1] + "+00:00" if ts.endswith("Z") else ts
        parsed = datetime.fromisoformat(cleaned)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=UTC)
        else:
            parsed = parsed.astimezone(UTC)
        return parsed.isoformat()
    except (TypeError, ValueError):
        return fallback if fallback is not None else _now()


# Maps a session id prefix or legacy stored channel value to a UI group.
# Single source of truth — chat.js trusts the `group` field on each row.
_CHANNEL_PREFIXES: tuple[tuple[tuple[str, ...], str], ...] = (
    (("teams:", "cloud_teams"), "teams"),
    (("webchat:", "cloud_web", "cloud_webchat"), "web"),
    (("scheduler",), "scheduler"),
    (("a2a:", "u2u:"), "a2a"),
)

# Direct channel -> UI group mapping. Aliases collapse here (e.g. local_webchat -> web).
_CHANNEL_TO_GROUP: dict[str, str] = {
    "web": "web",
    "local_webchat": "web",
    "teams": "teams",
    "scheduler": "scheduler",
    "a2a": "a2a",
}


def _infer_channel_from_id(session_id: str) -> str:
    sid = (session_id or "").lower()
    for prefixes, channel in _CHANNEL_PREFIXES:
        if sid.startswith(prefixes):
            return channel
    return "cloud"


def _group_for_row(session_id: str, channel: str | None) -> str:
    ch = (channel or "").lower()
    if ch in _CHANNEL_TO_GROUP:
        return _CHANNEL_TO_GROUP[ch]
    return _infer_channel_from_id(session_id)


def _row_to_message(row: aiosqlite.Row) -> dict:
    """Convert a database row to a message dict."""
    msg: dict = {"role": row["role"]}
    # Only include content if non-empty, or if the role requires it.
    # Assistant messages with tool_calls may have content=None; sending
    # content="" to some providers triggers rejection.
    content = row["content"]
    if row["tool_calls"]:
        msg["tool_calls"] = json.loads(row["tool_calls"])
        if content:  # only set content when it's non-empty
            msg["content"] = content
    else:
        msg["content"] = content or ""
    if row["tool_call_id"]:
        msg["tool_call_id"] = row["tool_call_id"]
    return msg


class SessionStore:
    """Async SQLite session store with FTS5 search."""

    def __init__(self, db_path: Path | None = None) -> None:
        self._db_path = db_path or (get_data_dir() / "sessions.db")
        self._db: aiosqlite.Connection | None = None

    async def initialize(self) -> None:
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._db = await aiosqlite.connect(str(self._db_path))
        self._db.row_factory = aiosqlite.Row
        await self._db.execute("PRAGMA journal_mode=WAL")
        await self._db.executescript(_SCHEMA)
        await self._db.commit()

    async def close(self) -> None:
        if self._db:
            await self._db.close()
            self._db = None

    @property
    def _conn(self) -> aiosqlite.Connection:
        assert self._db is not None, "Store not initialized"
        return self._db

    async def get_or_create_session(self, channel: str, sender: str) -> str:
        existing = await self.find_session(channel, sender)
        if existing is not None:
            return existing
        sid = str(uuid.uuid4())
        now = _now()
        await self._conn.execute(
            "INSERT INTO sessions (id, channel, sender, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
            (sid, channel, sender, now, now),
        )
        await self._conn.commit()
        return sid

    async def find_session(self, channel: str, sender: str) -> str | None:
        cursor = await self._conn.execute(
            "SELECT id FROM sessions WHERE channel = ? AND sender = ? ORDER BY updated_at DESC LIMIT 1",
            (channel, sender),
        )
        row = await cursor.fetchone()
        return str(row["id"]) if row else None

    async def ensure_session(self, session_id: str, channel: str, sender: str) -> None:
        now = _now()
        await self._conn.execute(
            "INSERT OR IGNORE INTO sessions (id, channel, sender, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (session_id, channel, sender, now, now),
        )
        await self._conn.commit()

    async def session_exists(self, session_id: str) -> bool:
        # Messages-without-row covers legacy orphans surfaced by list_sessions;
        # treating them as existing keeps stale-link 404 detection honest.
        cursor = await self._conn.execute(
            "SELECT 1 FROM sessions WHERE id = ? "
            "UNION ALL SELECT 1 FROM messages WHERE session_id = ? LIMIT 1",
            (session_id, session_id),
        )
        return await cursor.fetchone() is not None

    async def get_session_sender(self, session_id: str) -> str | None:
        """Return the ``sender`` recorded for *session_id*, or ``None``.

        Used as the durable per-user key for cross-session counters (e.g. the
        adaptive promotion-receipt ramp) — the ``sender`` column is the stable
        user identity regardless of the session id's internal format.
        """
        cursor = await self._conn.execute(
            "SELECT sender FROM sessions WHERE id = ?",
            (session_id,),
        )
        row = await cursor.fetchone()
        return row["sender"] if row else None

    async def increment_counter(self, key: str) -> int:
        """Atomically increment the integer counter *key* by 1 and return it.

        Backed by the ``counters`` KV table. The counter starts at 0; the
        first call returns 1. Durable across restarts so cross-session,
        per-user ramps (e.g. the adaptive promotion receipt) survive a daemon
        bounce instead of resetting to the verbose default.

        Uses an UPSERT followed by a read-back ``SELECT`` rather than the
        ``RETURNING`` clause, which requires SQLite >= 3.35 — older system
        SQLite builds (e.g. on some Linux distros) would fail at runtime.
        UPSERT (``ON CONFLICT``) is supported since SQLite 3.24.
        """
        await self._conn.execute(
            "INSERT INTO counters(key, value) VALUES(?, 1) "
            "ON CONFLICT(key) DO UPDATE SET value = value + 1",
            (key,),
        )
        cursor = await self._conn.execute(
            "SELECT value FROM counters WHERE key = ?",
            (key,),
        )
        row = await cursor.fetchone()
        await self._conn.commit()
        return int(row["value"]) if row else 1

    async def add_message(
        self,
        session_id: str,
        message_dict: dict,
        *,
        created_at: str | None = None,
    ) -> int:
        """Insert one message row.

        ``created_at`` defaults to ``_now()``. Callers that need to preserve
        a pre-existing timestamp (typically when re-inserting messages via
        :meth:`replace_messages` after compaction/trim) can pass it
        explicitly so the bulk re-insert does not collapse every row's
        ``created_at`` to the bulk-insert moment, which destroys forensic
        timelines (issue #345).
        """
        now = _now()
        ts = _normalize_ts(created_at, fallback=now) if created_at else now
        content = message_dict.get("content") or ""
        tokens = count_tokens(content)
        tool_calls = (
            json.dumps(message_dict["tool_calls"]) if "tool_calls" in message_dict else None
        )
        tool_call_id = message_dict.get("tool_call_id")
        cursor = await self._conn.execute(
            "INSERT INTO messages (session_id, role, content, tool_calls, tool_call_id, tokens, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (session_id, message_dict["role"], content, tool_calls, tool_call_id, tokens, ts),
        )
        await self._conn.execute(
            "UPDATE sessions SET updated_at = ? WHERE id = ?", (now, session_id)
        )
        await self._conn.commit()
        return cursor.lastrowid  # type: ignore[return-value]

    async def get_messages(self, session_id: str, *, limit: int | None = None) -> list[dict]:
        if limit:
            cursor = await self._conn.execute(
                "SELECT * FROM (SELECT * FROM messages WHERE session_id = ? ORDER BY id DESC LIMIT ?) ORDER BY id ASC",
                (session_id, limit),
            )
        else:
            cursor = await self._conn.execute(
                "SELECT * FROM messages WHERE session_id = ? ORDER BY id ASC",
                (session_id,),
            )
        return [_row_to_message(r) for r in await cursor.fetchall()]

    async def get_messages_by_rowids(
        self, session_id: str, rowids: list[int]
    ) -> list[tuple[int, dict, str | None]]:
        """Return ``(rowid, message_dict, created_at)`` for each requested id.

        Ordered by ``id ASC`` so the original turn order is preserved on
        replay. Rowids belonging to other sessions are silently filtered out
        (the ``WHERE session_id = ?`` clause scopes the read). Used by the
        event-loop promotion path to capture a snapshot of the in-flight
        tool rows BEFORE pruning, so that a later ``adopt()`` cap-race
        rejection can re-insert the same content back into MAIN and keep
        the durable history intact.

        Empty ``rowids`` returns an empty list (no DB round-trip).
        """
        if not rowids:
            return []
        placeholders = ",".join("?" for _ in rowids)
        cursor = await self._conn.execute(
            f"SELECT * FROM messages WHERE session_id = ? AND id IN ({placeholders}) "  # noqa: S608
            "ORDER BY id ASC",
            (session_id, *rowids),
        )
        return [(r["id"], _row_to_message(r), r["created_at"]) for r in await cursor.fetchall()]

    async def replace_messages(self, session_id: str, messages: list[dict]) -> None:
        """Replace the entire message log for ``session_id``.

        Each ``msg`` may carry a ``"_created_at"`` key (leading underscore
        marks it as non-LLM metadata). When present, that timestamp is
        forwarded to :meth:`add_message` so the bulk re-insert preserves
        the row's original ``created_at`` instead of stamping every row
        with the bulk-write moment. Callers that don't care can simply
        omit the key (legacy behaviour). The key is stripped from a
        shallow copy of ``msg`` before insert (caller-owned dicts are
        not mutated) and never persisted to the row.
        """
        await self._conn.execute("DELETE FROM messages WHERE session_id = ?", (session_id,))
        if messages:
            for msg in messages:
                preserved: str | None = None
                insert_msg = msg
                if isinstance(msg, dict) and "_created_at" in msg:
                    raw = msg.get("_created_at")
                    # Honor add_message's ``created_at: str | None`` contract
                    # at the boundary: non-string overrides are treated as
                    # 'no override' rather than relying on _normalize_ts'
                    # defensive fallback. This keeps the type contract local
                    # to one layer.
                    preserved = raw if isinstance(raw, str) else None
                    # Copy so we don't mutate caller-owned dicts (which may
                    # still be referenced on an in-memory LLM-bound list).
                    insert_msg = {k: v for k, v in msg.items() if k != "_created_at"}
                await self.add_message(session_id, insert_msg, created_at=preserved)
        else:
            # add_message commits per call; when messages is empty the
            # DELETE must still be committed (e.g. /new clear session).
            await self._conn.commit()

    async def delete_messages(self, session_id: str, rowids: list[int]) -> int:
        """Delete a subset of messages by rowid in a single transaction.

        Returns the number of rows actually deleted. An empty ``rowids`` list
        is a no-op (no DB mutation, returns 0). Rowids belonging to other
        sessions are silently ignored: the ``WHERE session_id = ?`` clause
        scopes the delete, so cross-session rowids match nothing and the
        rowcount reflects only the session's actual deletions. The FTS5
        mirror is kept consistent via the existing ``messages_ad`` AFTER
        DELETE trigger declared in ``_SCHEMA``.

        Implementation notes:

        - All ids are passed as bound parameters (``?, ?, …``) — never
          string-concatenated into the SQL — so this primitive is injection-
          safe for arbitrarily-sourced rowid lists.
        - The DELETE and the ``sessions.updated_at`` bump share one
          transaction (single ``commit``), matching :meth:`add_message` and
          :meth:`replace_messages`. If the DELETE deletes zero rows we still
          bump ``updated_at`` only when at least one row was deleted: a
          true no-op on a foreign-session rowid list should not silently
          touch the row's freshness clock.
        """
        if not rowids:
            return 0
        placeholders = ",".join("?" for _ in rowids)
        # SQLite's parameter binding has no array placeholder; the f-string
        # only inserts a fixed pattern of "?" characters whose count matches
        # ``len(rowids)``. Every rowid is bound via ``execute``'s second
        # argument — the SQL cannot carry user data. Same pattern as
        # ``agent/history.py``'s LIKE-fallback queries.
        cursor = await self._conn.execute(
            f"DELETE FROM messages WHERE session_id = ? AND id IN ({placeholders})",  # noqa: S608
            (session_id, *rowids),
        )
        deleted = cursor.rowcount or 0
        if deleted:
            await self._conn.execute(
                "UPDATE sessions SET updated_at = ? WHERE id = ?",
                (_now(), session_id),
            )
        await self._conn.commit()
        return deleted

    async def fork(self, session_id: str) -> str:
        # Get parent session info
        cursor = await self._conn.execute(
            "SELECT channel, sender FROM sessions WHERE id = ?", (session_id,)
        )
        row = await cursor.fetchone()
        assert row, f"Session {session_id} not found"
        child_id = str(uuid.uuid4())
        now = _now()
        await self._conn.execute(
            "INSERT INTO sessions (id, channel, sender, parent_session_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
            (child_id, row["channel"], row["sender"], session_id, now, now),
        )
        await self._conn.commit()
        return child_id

    async def list_main_sessions(self, *, limit: int = 100) -> list[str]:
        """Return ids of recent main (non-worker) sessions, newest first.

        ``parent_session_id IS NULL`` filters out worker sessions created by
        :meth:`fork`. Used by ``BackgroundTaskManager.reap_orphan_acks`` at
        startup to find main sessions that may carry leftover ``[BG task=…]``
        ack rows whose tasks died with the previous process. Read-only; no
        schema change.
        """
        cursor = await self._conn.execute(
            "SELECT id FROM sessions WHERE parent_session_id IS NULL "
            "ORDER BY updated_at DESC LIMIT ?",
            (limit,),
        )
        rows = await cursor.fetchall()
        return [r["id"] for r in rows]

    async def search(
        self, query: str, *, session_id: str | None = None, limit: int = 20
    ) -> list[dict]:
        if session_id:
            cursor = await self._conn.execute(
                "SELECT m.* FROM messages m JOIN messages_fts f ON m.id = f.rowid WHERE f.content MATCH ? AND m.session_id = ? LIMIT ?",
                (query, session_id, limit),
            )
        else:
            cursor = await self._conn.execute(
                "SELECT m.* FROM messages m JOIN messages_fts f ON m.id = f.rowid WHERE f.content MATCH ? LIMIT ?",
                (query, limit),
            )
        return [_row_to_message(r) for r in await cursor.fetchall()]

    async def update_usage(
        self, session_id: str, prompt_tokens: int, completion_tokens: int, cost: float
    ) -> None:
        await self._conn.execute(
            "UPDATE sessions SET prompt_tokens = prompt_tokens + ?, completion_tokens = completion_tokens + ?, cost = cost + ?, updated_at = ? WHERE id = ?",
            (prompt_tokens, completion_tokens, cost, _now(), session_id),
        )
        await self._conn.commit()

    async def smart_load(self, session_id: str, token_budget: int) -> list[dict]:
        cursor = await self._conn.execute(
            "SELECT * FROM messages WHERE session_id = ? ORDER BY id DESC",
            (session_id,),
        )
        rows = await cursor.fetchall()
        result: list[dict] = []
        total = 0
        for row in rows:
            tokens = row["tokens"] or 0
            if total + tokens > token_budget and result:
                break
            result.append(_row_to_message(row))
            total += tokens
        result.reverse()
        return result

    async def list_sessions(self, *, channel: str | None = None, limit: int = 50) -> list[dict]:
        # Include message_count via LEFT JOIN; alias `id` to `session_id` so
        # the API surface matches the single-session endpoint.
        base = (
            "SELECT s.*, s.id AS session_id, "
            "COALESCE((SELECT COUNT(*) FROM messages m WHERE m.session_id = s.id), 0) "
            "AS message_count FROM sessions s"
        )
        if channel:
            cursor = await self._conn.execute(
                f"{base} WHERE s.channel = ? ORDER BY s.updated_at DESC LIMIT ?",
                (channel, limit),
            )
        else:
            cursor = await self._conn.execute(
                f"{base} ORDER BY s.updated_at DESC LIMIT ?", (limit,)
            )
        rows = [dict(r) for r in await cursor.fetchall()]

        if channel:
            for r in rows:
                r["group"] = _group_for_row(
                    r.get("session_id") or r.get("id") or "", r.get("channel")
                )
            return rows
        known_ids = {r.get("id") for r in rows}
        cursor = await self._conn.execute(
            "SELECT m.session_id AS session_id, COUNT(*) AS message_count, "
            "MAX(m.created_at) AS updated_at "
            "FROM messages m LEFT JOIN sessions s ON s.id = m.session_id "
            "WHERE s.id IS NULL "
            "GROUP BY m.session_id ORDER BY updated_at DESC LIMIT ?",
            (limit,),
        )
        for orow in await cursor.fetchall():
            sid = orow["session_id"]
            if not sid or sid in known_ids:
                continue
            rows.append(
                {
                    "id": sid,
                    "session_id": sid,
                    "channel": _infer_channel_from_id(sid),
                    "sender": "",
                    "message_count": orow["message_count"],
                    "updated_at": orow["updated_at"],
                    "orphan": True,
                }
            )
        for r in rows:
            r["group"] = _group_for_row(r.get("session_id") or r.get("id") or "", r.get("channel"))
        rows.sort(key=lambda r: r.get("updated_at") or "", reverse=True)
        return rows[:limit]

    async def delete_session(self, session_id: str) -> None:
        await self._conn.execute("DELETE FROM messages WHERE session_id = ?", (session_id,))
        await self._conn.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
        await self._conn.commit()
