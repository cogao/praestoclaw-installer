"""
CLI commands — Typer-based entry points for PraestoClaw.

Bare command:
  praestoclaw                        — smart start: guided init + server launch

Top-level commands (defined here):
praestoclaw status — runtime status overview
praestoclaw logs — show recent log output
praestoclaw version — print version string
praestoclaw cloud — connect to Cloud Gateway
praestoclaw hibernation-delay-agent — bootstrap Dev Box hibernation delay

Separate modules (praestoclaw/cli/):
  chat.py      — praestoclaw chat (REPL + web server attach + auth)
  serve.py     — praestoclaw serve (web server + PID helpers)
  doctor.py    — praestoclaw doctor (health diagnostics)
  init.py      — praestoclaw init (--quick, env detection, Agency MCP)
  update.py    — praestoclaw update / upgrade
  mcp.py       — praestoclaw mcp list | add | remove | setup
  agents.py    — praestoclaw agents list | add
  tools.py     — praestoclaw tools list
  sessions.py  — praestoclaw sessions list | show
  security.py  — praestoclaw security audit | credentials | roles
  skills.py    — praestoclaw skills list
  cron.py      — praestoclaw cron list | add
  memory.py    — praestoclaw memory show | search | clear | stats
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import Any

import typer
from loguru import logger
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from praestoclaw import __version__
from praestoclaw.config.loader import load_config
from praestoclaw.config.schema import AppConfig
from praestoclaw.runtime import Runtime

# ── Console ─────────────────────────────────────────────────────────────────

# Windows cp1252 stdout can't encode Unicode symbols (✓, …, etc.)
# Reconfigure to UTF-8 so Rich output works on all Windows terminals.
if sys.platform == "win32":
    for _stream in (sys.stdout, sys.stderr):
        if hasattr(_stream, "reconfigure"):
            try:
                _stream.reconfigure(encoding="utf-8")
            except Exception:
                pass

console = Console()

# Set default log level to INFO before Runtime._setup_logging() takes over.
# Without this, loguru's default DEBUG handler shows debug output during
# early CLI flows (e.g. GitHub login in `praestoclaw init`).
logger.remove()
logger.add(sys.stderr, level="INFO")

# ── Telemetry ───────────────────────────────────────────────────────────────
# Init at module load so every entry path (console script, `python -m`,
# in-process tests) reports startup. ``init`` is a no-op when telemetry is
# disabled via DISABLE_TELEMETRY / CI env, and emit() never raises — so this
# block cannot break the CLI.
try:
    import atexit as _atexit
    import os as _os
    import sys as _sys

    from praesto_telemetry import AppType as _TelemetryAppType
    from praesto_telemetry import Events as _TelemetryEvents
    from praesto_telemetry import emit as _telemetry_emit
    from praesto_telemetry import init as _telemetry_init
    from praesto_telemetry import set_user_id as _telemetry_set_user_id
    from praesto_telemetry import shutdown as _telemetry_shutdown

    from praestoclaw.utils.helpers import get_data_dir as _get_data_dir

    # Decide the telemetry environment automatically:
    #   - explicit PRAESTO_ENV in the user's shell wins
    #   - dev/local builds (version contains '.post' — date-stamped, not a
    #     released semver) → staging
    #   - `pc-staging` / `praestoclaw-staging` console scripts → staging
    #   - everything else → production
    if not _os.environ.get("PRAESTO_ENV"):
        _entry = _os.path.basename(_sys.argv[0] if _sys.argv else "")
        _is_staging_cli = _entry in {"pc-staging", "praestoclaw-staging"}
        _is_dev_build = ".post" in __version__
        _os.environ["PRAESTO_ENV"] = (
            "staging" if (_is_staging_cli or _is_dev_build) else "production"
        )

    _telemetry_init(
        app_name="praestoclaw",
        app_version=__version__,
        app_type=_TelemetryAppType.CLIENT_AGENT,
        data_dir=_get_data_dir(),
    )

    # If the user finished `pc init`, their UPN is in fre_state. Hash it and
    # surface as the authenticated user id so Workbook user-level panels work.
    # We hash (SHA256, no salt) because UPN is EUII whereas the hash is a
    # stable opaque id; no salt so the same UPN produces the same id across
    # Praesto apps (Gateway / Bot) for cross-app join.
    try:
        import hashlib as _hashlib

        from praestoclaw.utils.fre_state import load_fre_state as _load_fre_state

        _fre_user = _load_fre_state().get("user") or {}
        _upn = (_fre_user.get("upn") if isinstance(_fre_user, dict) else None) or ""
        _upn = _upn.strip().lower()
        if _upn:
            _user_hash = _hashlib.sha256(_upn.encode("utf-8")).hexdigest()[:32]
            _telemetry_set_user_id(_user_hash)
    except Exception as _user_exc:  # pragma: no cover - defensive
        logger.debug("Telemetry user id skipped: {}", _user_exc)

    _telemetry_emit(_TelemetryEvents.CLIENT_STARTUP)
    _atexit.register(_telemetry_shutdown)
except Exception as _telemetry_exc:  # pragma: no cover - defensive
    logger.debug("Telemetry init skipped: {}", _telemetry_exc)

# ── Helpers ─────────────────────────────────────────────────────────────────


def _get_runtime(
    config_path: str = ".",
    profile: str | None = None,
) -> Runtime:
    """Load config and construct a Runtime instance."""
    config = load_config(config_path, profile)
    resolved = resolve_config_path(config_path)
    local_path: Path | None = resolve_local_config_path(resolved)
    return Runtime(config, config_local_path=local_path)


def _load_config_safe(
    config_path: str = ".",
    profile: str | None = None,
) -> AppConfig:
    """Load and validate configuration, exiting on failure."""
    try:
        return load_config(config_path, profile)
    except Exception as exc:
        console.print(f"[red]Config error:[/red] {exc}")
        raise typer.Exit(1)


def resolve_config_path(config: str) -> Path:
    """Resolve praestoclaw.yaml path from a file or directory argument.

    Search order when a directory is given:
      1. The specified directory
      2. ~/.praestoclaw/  (default location after ``praestoclaw init``)

    ``praestoclaw init`` only creates ``praestoclaw.local.yaml``.  When only
    the local override exists (no base yaml), the derived base path is
    returned even though the file does not exist — callers load config via
    ``_load_config_safe(parent_dir)`` which falls back to bundled defaults,
    and all writes target ``praestoclaw.local.yaml`` anyway.

    Raises ``typer.Exit(1)`` with a helpful message if not found.
    """
    config_path = Path(config)
    if config_path.is_dir():
        search_dirs = [config_path]
        from praestoclaw.utils.helpers import get_data_dir

        user_dir = get_data_dir()
        if config_path.resolve() != user_dir.resolve() and user_dir.is_dir():
            search_dirs.append(user_dir)
        for search_dir in search_dirs:
            # Prefer base yaml; fall back to deriving the path from .local.yaml
            for candidate in ("praestoclaw.yaml", "praestoclaw.yml"):
                p = search_dir / candidate
                if p.exists():
                    return p
            for local_candidate in ("praestoclaw.local.yaml", "praestoclaw.local.yml"):
                lp = search_dir / local_candidate
                if lp.exists():
                    # Return the derived base path (may not exist); callers
                    # use _load_config_safe(parent) and write to .local.yaml
                    stem = local_candidate.replace(".local", "")
                    return search_dir / stem
        console.print(
            "[red]No praestoclaw.yaml found.[/red]\n"
            "  Run [bold]pc init[/bold] to create one, or use "
            "[bold]--config <path>[/bold] to specify its location."
        )
        raise typer.Exit(1)
    if not config_path.is_file():
        console.print(f"[red]Config file not found:[/red] {config_path}")
        raise typer.Exit(1)
    return config_path


def resolve_local_config_path(config_path: Path) -> Path:
    """Derive the .local.yaml sibling of a config file.

    praestoclaw.yaml  -> praestoclaw.local.yaml
    praestoclaw.yml   -> praestoclaw.local.yml
    """
    return config_path.parent / f"{config_path.stem}.local{config_path.suffix}"


# ── Sub-apps ────────────────────────────────────────────────────────────────

_ctx = {"help_option_names": ["-h", "--help"]}

agents_app = typer.Typer(name="agents", help="Manage configured agents", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
tools_app = typer.Typer(name="tools", help="Tool management", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
mcp_app = typer.Typer(name="mcp", help="MCP server management", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
sessions_app = typer.Typer(name="sessions", help="Session management", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
security_app = typer.Typer(name="security", help="Security and compliance", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
skills_app = typer.Typer(name="skills", help="Skill management", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
cron_app = typer.Typer(name="cron", help="Cron job management", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
memory_app = typer.Typer(name="memory", help="Memory management", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
plans_app: typer.Typer = typer.Typer(name="plans", help="Task plan management", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
secrets_app = typer.Typer(name="secrets", help="Secrets management", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
teams_app = typer.Typer(name="teams", help="Teams app sideload management", context_settings=_ctx, invoke_without_command=True)  # fmt: skip

# ── Main app ────────────────────────────────────────────────────────────────

app = typer.Typer(
    name="praestoclaw",
    help="PraestoClaw — enterprise AI assistant for development and office productivity",
    add_completion=False,
    invoke_without_command=True,
    context_settings=_ctx,
)


@app.callback()
def _main_callback(
    ctx: typer.Context,
    port: int | None = typer.Option(None, "--port", help="Override bind port"),
    data_dir: str | None = typer.Option(
        None,
        "--data-dir",
        help=(
            "Override data directory (default: ~/.praestoclaw/ or "
            "$PRAESTOCLAW_DATA_DIR). Use a unique path per instance for "
            "multi-instance testing."
        ),
    ),
) -> None:
    """Smart entry point when no subcommand is given."""
    if ctx.invoked_subcommand is not None:
        return

    # Apply data-dir override before any code that touches ~/.praestoclaw.
    from praestoclaw.utils.helpers import set_data_dir

    set_data_dir(data_dir)

    console.print(
        Panel(
            f"[bold]PraestoClaw[/bold]  v{__version__}\n\n"
            "  pc init         — setup / reconfigure\n"
            "  pc s            — start web UI + cloud\n"
            "  pc chat         — start chatting in the terminal\n"
            "  pc --help       — all commands\n\n"
            "  [dim]docs: https://aka.ms/praestoclaw/docs[/dim]",
            border_style="blue",
        )
    )

    # If no config, offer to run init first
    from praestoclaw.utils.helpers import get_data_dir as _gdd0

    local_yaml = _gdd0() / "praestoclaw.local.yaml"
    if not local_yaml.exists():
        console.print("[yellow]No configuration found.[/yellow]\n")
        from praestoclaw.cli.init import _select

        choice = _select(
            [
                ("Run initial setup", "configure PraestoClaw"),
                ("Exit", ""),
            ],
            default=1,
        )
        if choice == 1:
            from praestoclaw.cli.init import init as _init_cmd

            ctx.invoke(_init_cmd, directory=None, name=None, quick=False)
            console.print()
        else:
            return

    # Best-effort Teams pre-check (uses load_config directly to avoid
    # duplicate error output — serve() will report config errors itself)
    try:
        from praestoclaw.utils.helpers import get_data_dir as _gdd

        cfg = load_config(str(_gdd()))
        if cfg.channels.cloud.enabled and cfg.channels.cloud.teams_startup_check:
            _check_teams_before_cloud()
    except Exception as exc:
        logger.debug("Skipping Teams pre-check: {}", exc)

    # Start the server (use data dir as config dir to pick up init's output)
    from praestoclaw.utils.helpers import get_data_dir as _gdd2

    ctx.invoke(
        serve,
        config=str(_gdd2()),
        profile=None,
        host=None,
        port=port,
        instance_id=None,
        cloud_url=None,
        a2a_enabled=None,
        a2a_user_id=None,
        data_dir=data_dir,
    )


# ═══════════════════════════════════════════════════════════════════════════
# Top-level commands
# ═══════════════════════════════════════════════════════════════════════════


def _check_teams_before_cloud() -> None:
    """Check Teams app installation before cloud connect; prompt install with 10s timeout."""
    from praestoclaw.cli.teams import is_teams_installed

    if is_teams_installed():
        logger.debug("Teams app already installed (local data found)")
        return

    try:
        is_tty = sys.stdin.isatty() and sys.stdout.isatty()
    except Exception:
        is_tty = False

    if not is_tty:
        logger.debug("Teams app not found locally (non-TTY, skipping prompt)")
        return

    console.print(
        "  [yellow]Teams app not found locally.[/yellow]\n"
        "  [dim]The Teams app lets you chat with PraestoClaw directly in Microsoft Teams.\n"
        "  Check and install to enable the Teams channel for Cloud Gateway.[/dim]"
    )

    # Arrow-key selector with 10s auto-skip timeout (no network on timeout)
    _TEAMS_OPTS: list[tuple[str, str]] = [
        ("Check & install", "sign in to M365 and verify or install"),
        ("Skip", "install later with pc teams install"),
    ]

    choice = 2  # fallback: skip
    try:
        choice = _select_with_timeout(_TEAMS_OPTS, default=0, timeout=10, timeout_choice=1) + 1
    except Exception:
        choice = 2

    if choice == 1:
        try:
            from praestoclaw.cli.teams import teams_install as _teams_install

            _teams_install(package=None)
        except KeyboardInterrupt:
            console.print("  [dim]Teams install skipped by user.[/dim]")
        except typer.Exit as exc:
            if getattr(exc, "exit_code", 1) == 0:
                console.print("  [dim]Teams install skipped.[/dim]")
            else:
                console.print(
                    "  [red]Teams install failed.[/red]"
                    " [dim]Run [cyan]pc teams install[/cyan] for details.[/dim]"
                )
    else:
        console.print("  [dim]Skipped. Run [cyan]pc teams install[/cyan] later.[/dim]")
    console.print()


def _select_with_timeout(
    options: list[tuple[str, str]],
    *,
    default: int = 0,
    timeout: int = 10,
    timeout_choice: int | None = None,
) -> int:
    """Arrow-key radio selector with countdown auto-select.

    Like ``_select_arrows`` in init.py but auto-confirms after *timeout* seconds.
    *default* is the initially highlighted option (0-based).
    *timeout_choice* is the option returned on timeout (0-based); defaults to *default*.
    Returns 0-based index.
    """
    import time as _time

    if timeout_choice is None:
        timeout_choice = default
    if timeout <= 0:
        return timeout_choice
    cur = default
    n = len(options)
    max_label = max(len(label) for label, _ in options)
    # lines: blank + n options + blank + hint = n + 3
    total_lines = n + 3
    remaining_sec = timeout

    def _render(first: bool = False) -> None:
        out = sys.stdout
        if not first:
            out.write(f"\033[{total_lines}A")
        out.write("\n")
        for i, (label, desc) in enumerate(options):
            pad = label.ljust(max_label)
            if i == cur:
                line = f"  \033[36m*\033[0m \033[1m{pad}\033[0m"
            else:
                line = f"  \033[90mo {pad}\033[0m"
            if desc:
                line += f"  \033[90m\u2014 {desc}\033[0m"
            out.write(f"\033[2K{line}\n")
        timeout_label = options[timeout_choice][0] if 0 <= timeout_choice < len(options) else ""
        hint = f"Up/Down switch  Enter confirm  {timeout_label} in {remaining_sec}s"
        out.write(f"\n\033[2K  \033[2;90m{hint}\033[0m\n")
        out.flush()

    def _erase() -> None:
        out = sys.stdout
        out.write(f"\033[{total_lines}A")
        for _ in range(total_lines):
            out.write("\033[2K\n")
        out.write(f"\033[{total_lines}A")
        out.flush()

    sys.stdout.write("\033[?25l")  # hide cursor
    try:
        _render(first=True)

        if sys.platform == "win32":
            import msvcrt

            deadline = _time.monotonic() + timeout
            while _time.monotonic() < deadline:
                new_sec = max(0, int(deadline - _time.monotonic()))
                if new_sec != remaining_sec:
                    remaining_sec = new_sec
                    _render()
                if msvcrt.kbhit():
                    ch = msvcrt.getwch()
                    # Decode special keys
                    if ch in ("\x00", "\xe0"):
                        ch2 = msvcrt.getwch()
                        key = {"H": "up", "P": "down"}.get(ch2, "")
                    elif ch == "\r":
                        key = "enter"
                    elif ch == "\x03":
                        raise KeyboardInterrupt
                    else:
                        key = ch

                    if key in ("up", "k"):
                        cur = (cur - 1) % n
                        _render()
                    elif key in ("down", "j"):
                        cur = (cur + 1) % n
                        _render()
                    elif key == "enter":
                        _erase()
                        return cur
                    elif key.isdigit():
                        idx = int(key) - 1
                        if 0 <= idx < n:
                            cur = idx
                            _render()
                else:
                    _time.sleep(0.1)
        else:
            import select
            import termios
            import tty

            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            try:
                # Use cbreak (not raw) so OPOST stays enabled — \n keeps its
                # automatic CR translation; otherwise renders drift right.
                tty.setcbreak(fd)
                deadline = _time.monotonic() + timeout
                while _time.monotonic() < deadline:
                    new_sec = max(0, int(deadline - _time.monotonic()))
                    if new_sec != remaining_sec:
                        remaining_sec = new_sec
                        _render()
                    wait = min(0.1, max(0, deadline - _time.monotonic()))
                    rlist, _, _ = select.select([sys.stdin], [], [], wait)
                    if rlist:
                        ch = sys.stdin.read(1)
                        if ch == "\x1b":
                            # Non-blocking: only read extra bytes if available
                            key = ""
                            r2, _, _ = select.select([sys.stdin], [], [], 0)
                            if r2:
                                ch2 = sys.stdin.read(1)
                                if ch2 == "[":
                                    r3, _, _ = select.select([sys.stdin], [], [], 0)
                                    if r3:
                                        ch3 = sys.stdin.read(1)
                                        key = {"A": "up", "B": "down"}.get(ch3, "")
                        elif ch in ("\r", "\n"):
                            key = "enter"
                        elif ch == "\x03":
                            raise KeyboardInterrupt
                        else:
                            key = ch

                        if key in ("up", "k"):
                            cur = (cur - 1) % n
                            _render()
                        elif key in ("down", "j"):
                            cur = (cur + 1) % n
                            _render()
                        elif key == "enter":
                            _erase()
                            return cur
                        elif key.isdigit():
                            idx = int(key) - 1
                            if 0 <= idx < n:
                                cur = idx
                                _render()
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

        # Timeout — return timeout_choice
        _erase()
        return timeout_choice
    finally:
        sys.stdout.write("\033[?25h\033[0m")  # show cursor, reset attrs
        sys.stdout.flush()


def cloud(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
    url: str | None = typer.Option(None, "--url", help="Override Cloud Gateway URL"),
    scope: str | None = typer.Option(None, "--scope", help="Override Entra ID scope"),
    login_method: str | None = typer.Option(
        None,
        "--login",
        help="Login method: auto (default), browser (PKCE popup), device (code at URL)",
    ),
    instance_id: str | None = typer.Option(
        None,
        "--instance-id",
        help=(
            "Local dev only: use this string verbatim as agent_id (bypassing "
            "the normal {instance_id}@{run_id} composition). Also sets "
            "bypass_token to 'dev-<instance-id>'."
        ),
    ),
) -> None:
    """Connect to PraestoClaw Cloud Gateway (remote relay mode).

    Authenticates with Entra ID, then maintains a persistent WebSocket to
    the Cloud Gateway. Messages from Teams and Web Chat are relayed to the
    local agent; responses are sent back.

    Login methods:
      auto    — try browser popup, fall back to device code (default)
      browser — open browser for PKCE sign-in (http://localhost callback)
      device  — device code flow (URL + code; works without a browser)
    """
    cfg = _load_config_safe(config, profile)
    cloud_cfg = cfg.channels.cloud

    # Apply CLI overrides
    if url:
        cloud_cfg.url = url
        if cloud_cfg.transport_mode == "awps":
            from praestoclaw.gateway_protocol.v2.awps import negotiate_url_from_connect_url

            cloud_cfg.negotiate_url = negotiate_url_from_connect_url(url)
    if scope:
        cloud_cfg.scope = scope
    if login_method:
        cloud_cfg.login_method = login_method  # type: ignore[assignment]

    if instance_id:
        from praestoclaw.cli.dev_overrides import apply_local_dev_cloud_overrides

        apply_local_dev_cloud_overrides(cfg, instance_id=instance_id, log_prefix="cloud")

    if not cloud_cfg.url or not cloud_cfg.client_id or not cloud_cfg.tenant_id:
        console.print(
            "[red]Cloud channel not configured.[/red]\n"
            "Set url, client_id, and tenant_id under channels.cloud in your config\n"
            "(e.g., ~/.praestoclaw/praestoclaw.local.yaml)."
        )
        raise typer.Exit(1)
    if not cloud_cfg.scope:
        cloud_cfg.scope = f"{cloud_cfg.client_id}/.default"
    method_label = {
        "auto": "browser -> device code fallback",
        "browser": "browser popup (PKCE)",
        "device": "device code (URL + code)",
    }.get(cloud_cfg.login_method, cloud_cfg.login_method)
    if cloud_cfg.transport_mode == "awps":
        from praestoclaw.gateway_protocol.v2.awps import negotiate_url_from_connect_url

        transport_label = "Gateway v2 AWPS"
        gateway_endpoint = cloud_cfg.negotiate_url or negotiate_url_from_connect_url(cloud_cfg.url)
    else:
        transport_label = "Gateway v1 direct WebSocket"
        gateway_endpoint = cloud_cfg.url

    console.print(
        Panel(
            f"[bold]PraestoClaw Cloud[/bold]  v{__version__}\n\n"
            f"Gateway : [cyan]{gateway_endpoint}[/cyan]\n"
            f"Transport: [cyan]{transport_label}[/cyan]\n"
            f"Tenant  : [dim]{cloud_cfg.tenant_id}[/dim]\n"
            f"Client  : [dim]{cloud_cfg.client_id}[/dim]\n"
            f"Login   : [yellow]{method_label}[/yellow]\n\n"
            f"Sign in with your Entra ID account to continue.\n"
            f"Press [bold]Ctrl+C[/bold] to disconnect.",
            title="Cloud Gateway",
            border_style="blue",
        )
    )

    # Check Teams app installation — prompt to install if missing
    if cloud_cfg.teams_startup_check:
        _check_teams_before_cloud()

    # If serve is running, check its cloud channel status instead of starting a new Runtime
    running = _check_web_running()
    if running:
        _, port = running
        try:
            import httpx as _httpx

            r = _httpx.get(f"http://localhost:{port}/api/status", timeout=3)
            status = r.json()
            channels = status.get("channels", [])
            cloud_ch = next((c for c in channels if "cloud" in c.get("name", "").lower()), None)
            connected = cloud_ch.get("connected", False) if cloud_ch else False
            if connected and cloud_ch is not None:
                console.print(
                    Panel(
                        f"[green]Cloud Gateway already connected[/green] via running serve (port {port}).\n\n"
                        f"Channel : {cloud_ch.get('name', 'Cloud')}\n"
                        f"URL     : {cloud_ch.get('url') or 'n/a'}\n\n"
                        f"No action needed — serve is handling cloud relay.",
                        title="Cloud Status",
                        border_style="green",
                    )
                )
                return
            else:
                console.print(
                    f"[yellow]Web server is running (port {port}) but cloud channel is not connected.\n"
                    f"Ensure [bold]channels.cloud[/bold] is configured in praestoclaw.yaml "
                    f"and restart [bold]pc serve[/bold].[/yellow]"
                )
                raise typer.Exit(1)
        except Exception as exc:
            console.print(
                f"[yellow]Could not query running web server: {exc}. Starting standalone cloud.[/yellow]"
            )

    try:
        asyncio.run(_run_cloud(cfg, cloud_cfg))
    except KeyboardInterrupt:
        console.print("\n[yellow]Disconnected from Cloud Gateway.[/yellow]")
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)


async def _run_cloud(cfg: AppConfig, cloud_cfg: Any) -> None:
    """Async entry point: wire up the cloud channel and run the agent loop."""
    from praestoclaw.channels.cloud import CloudChannel

    rt = Runtime(cfg)
    ch = CloudChannel(
        rt.bus,
        url=cloud_cfg.url,
        tenant_id=cloud_cfg.tenant_id,
        client_id=cloud_cfg.client_id,
        scope=cloud_cfg.scope,
        transport_mode=cloud_cfg.transport_mode,
        negotiate_url=cloud_cfg.negotiate_url,
        negotiate_timeout_s=cloud_cfg.negotiate_timeout_s,
        client_url_refresh_skew_s=cloud_cfg.client_url_refresh_skew_s,
        login_method=cloud_cfg.login_method,
        login_port=cloud_cfg.login_port,
        allow_from=cloud_cfg.allow_from or None,
        auto_reconnect=cloud_cfg.auto_reconnect,
        reconnect_max=cloud_cfg.reconnect_max,
        bypass_token=cloud_cfg.bypass_token,
        open_browser_on_connect=True,
        a2a_enabled=cfg.channels.a2a.enabled,
        a2a_instance_id=rt._a2a_instance_id,
        a2a_user_id=cfg.channels.a2a.user_id or cloud_cfg.a2a_user_id,
        a2a_is_active_instance=cfg.channels.a2a.is_active_instance,
        a2a_protocol_version=cfg.channels.a2a.protocol_version,
        a2a_executor_notify_filter=list(cfg.channels.a2a.executor_notify_filter or []),
        a2a_card_seed=rt._generate_a2a_card_seed(),
    )
    from praestoclaw.auth.factory import build_auth_provider as _build_auth

    ch._auth = _build_auth(cloud_cfg, channel=ch)
    ch.set_runtime(rt)  # allow admin relay to query Runtime APIs
    rt.channel_manager.add(ch)
    await ch.start()
    # Keep the agent loop running — messages arrive via the cloud channel
    await rt.run_cloud()


def status(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """Show runtime configuration status."""
    cfg = _load_config_safe(config, profile)

    console.print(
        Panel(
            f"[bold]{cfg.name}[/bold]  v{__version__}\n"
            f"Security profile: [cyan]{cfg.security.profile.value}[/cyan]  |  "
            f"Entrypoint: [cyan]{cfg.entrypoint}[/cyan]",
            title="PraestoClaw Status",
            border_style="blue",
        )
    )

    # Agents table
    agents_table = Table(title="Agents")
    agents_table.add_column("Name", style="bold")
    agents_table.add_column("Model")
    agents_table.add_column("Max Iter")
    agents_table.add_column("Tools")

    entry = cfg.entrypoint
    agents_table.add_row(
        "default" + (" *" if entry == "default" else ""),
        cfg.agents.default.model,
        str(cfg.agents.default.max_iterations),
        "(all)" if cfg.agents.default.tools is None else str(len(cfg.agents.default.tools)),
    )
    for name, ag in cfg.agents.agents.items():
        agents_table.add_row(
            name + (" *" if entry == name else ""),
            ag.model,
            str(ag.max_iterations),
            "(all)" if ag.tools is None else str(len(ag.tools)),
        )
    console.print(agents_table)

    # Channels
    channels_table = Table(title="Channels")
    channels_table.add_column("Channel", style="bold")
    channels_table.add_column("Enabled")
    channels_table.add_row("CLI", "[green]yes[/green]" if cfg.channels.cli.enabled else "no")
    web_cfg = cfg.channels.web
    web_status = (
        f"[green]yes[/green]  [dim]http://{web_cfg.host}:{web_cfg.port}[/dim]"
        if web_cfg.enabled
        else "no"
    )
    channels_table.add_row("Web", web_status)
    cloud_cfg = cfg.channels.cloud
    if not cloud_cfg.enabled:
        cloud_status = "no"
    elif not cloud_cfg.url:
        cloud_status = "[yellow]url not set[/yellow]"
    else:
        cloud_status = f"[green]yes[/green]  [dim]{cloud_cfg.url}[/dim]"
    channels_table.add_row("Web Chat (Cloud)", cloud_status)
    if cloud_cfg.enabled and cloud_cfg.teams_bot_url:
        channels_table.add_row(
            "Teams (Cloud)", f"[green]yes[/green]  [dim]{cloud_cfg.teams_bot_url}[/dim]"
        )
    elif cloud_cfg.enabled:
        channels_table.add_row("Teams (Cloud)", "[yellow]teams_bot_url not set[/yellow]")
    console.print(channels_table)

    # Security
    sec_table = Table(title="Security")
    sec_table.add_column("Setting", style="bold")
    sec_table.add_column("Value")
    sec_table.add_row("Profile", cfg.security.profile.value)
    sec_table.add_row(
        "Audit",
        "[green]enabled[/green]" if cfg.security.audit.enabled else "[dim]disabled[/dim]",
    )
    sec_table.add_row("RBAC roles", str(len(cfg.security.roles)))
    sec_table.add_row("Workspace", str(cfg.workspace))
    allowed_cfg = cfg.security.allowed_paths
    sec_table.add_row(
        "Allowed paths",
        "(profile default)"
        if not allowed_cfg
        else ("*" if "*" in allowed_cfg else str(len(allowed_cfg))),
    )
    sec_table.add_row("Shell deny patterns", str(len(cfg.tools.shell.deny_patterns)))
    console.print(sec_table)

    # Features
    def _on_off(enabled: bool) -> str:
        return "[green]enabled[/green]" if enabled else "[dim]disabled[/dim]"

    feat_table = Table(title="Features")
    feat_table.add_column("Feature", style="bold")
    feat_table.add_column("Status")
    feat_table.add_row("Web Server", _on_off(cfg.channels.web.enabled))
    feat_table.add_row("Cron", _on_off(cfg.cron.enabled))
    feat_table.add_row("Browser", _on_off(cfg.tools.browser.enabled))
    feat_table.add_row("MCP servers", str(len(cfg.tools.mcp_servers)))
    for srv_name, srv in cfg.tools.mcp_servers.items():
        transport = "stdio" if srv.command else "http"
        feat_table.add_row(f"  {srv_name}", f"[dim]{transport}[/dim]")
    console.print(feat_table)

    console.print()


def logs(
    lines: int = typer.Option(50, "--lines", "-n", help="Number of lines to show"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show recent log output."""
    cfg = _load_config_safe(config)

    log_file = cfg.logging.file
    if not log_file:
        console.print("[yellow]No log file configured.[/yellow]  Logs go to stderr by default.")
        console.print("  Set [bold]logging.file[/bold] in praestoclaw.yaml to enable file logging.")
        return

    log_path = Path(log_file)
    if not log_path.exists():
        console.print(f"[yellow]Log file not found:[/yellow] {log_path}")
        return

    try:
        all_lines = log_path.read_text(encoding="utf-8").splitlines()
        tail = all_lines[-lines:] if len(all_lines) > lines else all_lines
        for line in tail:
            console.print(line)
    except Exception as exc:
        console.print(f"[red]Error reading log file:[/red] {exc}")
        raise typer.Exit(1)


def version() -> None:
    """Show PraestoClaw version."""
    from praestoclaw.utils.channel import get_channel

    channel = get_channel()
    suffix = " (staging)" if channel == "staging" else ""
    console.print(f"PraestoClaw v{__version__}{suffix}")


# ═══════════════════════════════════════════════════════════════════════════
# Sub-app modules — populate sub-app Typers (no effect on main app order)
# ═══════════════════════════════════════════════════════════════════════════

import praestoclaw.cli.agents as _agents  # noqa: F401, E402
import praestoclaw.cli.cron as _cron  # noqa: F401, E402
import praestoclaw.cli.mcp as _mcp  # noqa: F401, E402
import praestoclaw.cli.memory as _memory  # noqa: F401, E402
import praestoclaw.cli.plans as _plans  # noqa: F401, E402
import praestoclaw.cli.security as _security  # noqa: F401, E402
import praestoclaw.cli.sessions as _sessions  # noqa: F401, E402
import praestoclaw.cli.skills as _skills  # noqa: F401, E402
import praestoclaw.cli.teams as _teams  # noqa: F401, E402
import praestoclaw.cli.tools as _tools  # noqa: F401, E402
from praestoclaw.cli.chat import chat  # noqa: E402
from praestoclaw.cli.doctor import doctor  # noqa: E402

# serve lives in its own module; import public symbols into this namespace
# so _main_callback and other functions can reference them.
from praestoclaw.cli.serve import _check_web_running, serve  # noqa: E402

_check_gateway_running = _check_web_running  # backward compat alias

# ═══════════════════════════════════════════════════════════════════════════
# Command registration — ordered by usage frequency / logical grouping
# ═══════════════════════════════════════════════════════════════════════════

# ── Primary ──────────────────────────────────────────────────────────────
app.command()(chat)
app.command()(serve)
app.command("s", hidden=True)(serve)
app.command()(cloud)

# init, update, autostart, and hibernation self-register via @app.command()
# in their own modules
import praestoclaw.cli.autostart as _autostart  # noqa: F401, E402
import praestoclaw.cli.hibernation as _hibernation  # noqa: F401, E402
import praestoclaw.cli.init as _init  # noqa: F401, E402
import praestoclaw.cli.task as _task  # noqa: F401, E402
import praestoclaw.cli.update as _update  # noqa: F401, E402

# ── Management ───────────────────────────────────────────────────────────
app.add_typer(agents_app, name="agents")
app.add_typer(tools_app, name="tools")
app.add_typer(mcp_app, name="mcp")
app.add_typer(sessions_app, name="sessions")
app.add_typer(skills_app, name="skills")
app.add_typer(memory_app, name="memory")
app.add_typer(plans_app, name="plans")
# Top-level resume command lives in the plans module
from praestoclaw.cli.plans import resume as _resume  # noqa: E402

app.command("resume")(_resume)
app.add_typer(cron_app, name="cron")
app.add_typer(secrets_app, name="secrets")
app.add_typer(teams_app, name="teams")

# ── Diagnostics / info ────────────────────────────────────────────────────
app.command()(status)
app.command()(doctor)
app.command()(logs)
app.add_typer(security_app, name="security")
app.command()(version)

# ── Hidden aliases ────────────────────────────────────────────────────────
app.command("server", hidden=True)(serve)
app.command("start", hidden=True)(serve)
app.command("agent", hidden=True)(chat)
app.command("gateway", hidden=True)(serve)
# onboard alias registered in praestoclaw.cli.init


def app_staging() -> None:
    """Entry-point for the ``pc-staging`` / ``praestoclaw-staging`` console scripts.

    Flips the channel singleton to ``staging`` before delegating to the
    shared Typer app — so data dir routing and cloud URL overlay activate.
    """
    from praestoclaw.utils.channel import set_channel

    set_channel("staging")
    app()
