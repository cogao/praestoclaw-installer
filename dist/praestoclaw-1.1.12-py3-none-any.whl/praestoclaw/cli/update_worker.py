"""Background update worker for PraestoClaw — cross-platform.

On Windows this module waits for the locked entry-point exe to exit before
running pip (which would otherwise fail with a file-lock error). On all
platforms it also handles the daemon self-update path (``--reexec-update``):
kill the running daemon, then re-run ``pc update`` from a clean process.
"""

from __future__ import annotations

import argparse
import ctypes
import os
import subprocess
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

# ── Diagnostic log ────────────────────────────────────────────────────────────
# The whole detached self-update path runs with stdin/stdout/stderr=DEVNULL
# (see ``_schedule_self_update_detached`` in cli/update.py) and loguru is not
# initialised in this process, so without this file-handle log there is
# literally zero observability if the worker dies. Keep this dirt-simple:
# raw ``open(..., "a")`` with ``flush()`` after every write, never throws.

_DIAG_LOG_PATH: Path | None = None


def _diag_log_path() -> Path:
    """Resolve the diagnostic log file path. Memoised.

    Prefers ``~/.praestoclaw/logs/update-YYYYMMDD.log``. Falls back
    to ``%TEMP%`` if home is unwritable. The filename is intentionally
    date-only (not per-run) so concurrent or sequential update attempts
    on the same day all append to one file — the PID stamp on every line
    keeps them separable.
    """
    global _DIAG_LOG_PATH
    if _DIAG_LOG_PATH is not None:
        return _DIAG_LOG_PATH
    today = datetime.now().strftime("%Y%m%d")
    name = f"update-{today}.log"
    candidates: list[Path | None] = [
        Path.home() / ".praestoclaw" / "logs",
        Path(os.environ.get("TEMP", "")) if os.environ.get("TEMP") else None,
    ]
    # ``Path.cwd()`` can raise FileNotFoundError when the working
    # directory has been deleted out from under the detached worker.
    # Resolve it lazily so HOME/TEMP fallbacks still apply.
    try:
        candidates.append(Path.cwd())
    except OSError:
        pass
    for base in candidates:
        if base is None:
            continue
        try:
            base.mkdir(parents=True, exist_ok=True)
            _DIAG_LOG_PATH = base / name
            return _DIAG_LOG_PATH
        except OSError:
            continue
    # Last-resort fallback — should never happen.
    _DIAG_LOG_PATH = Path(name)
    return _DIAG_LOG_PATH


def _diag(msg: str, *, exc: BaseException | None = None) -> None:
    """Append a timestamped line to the worker diagnostic log. Never raises."""
    try:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        # ``[worker]`` tag mirrors the ``[spawner]`` tag in ``cli/update.py``
        # so the two processes can be told apart in the shared daily log file.
        line = f"{ts} pid={os.getpid()} [worker] {msg}\n"
        if exc is not None:
            line += "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        with open(_diag_log_path(), "a", encoding="utf-8") as f:
            f.write(line)
            f.flush()
    except Exception:  # noqa: BLE001 — diagnostics must never crash the worker
        pass


_SIGNAL_LOGGER_INSTALLED = False


def _install_signal_logger() -> None:
    """Log every signal the worker receives, then re-dispatch via the prior handler.

    Saves the original handler at install time and restores it before
    re-sending the signal, so Python's default semantics still apply
    (SIGINT raises ``KeyboardInterrupt`` via ``default_int_handler``
    rather than hard-terminating through ``SIG_DFL``).
    """
    global _SIGNAL_LOGGER_INSTALLED
    if _SIGNAL_LOGGER_INSTALLED:
        return
    _SIGNAL_LOGGER_INSTALLED = True
    import signal as _signal

    previous: dict[int, object] = {}

    def _handler(signum: int, frame: object) -> None:
        try:
            name = _signal.Signals(signum).name
        except (ValueError, AttributeError):
            name = str(signum)
        _diag(f"!! WORKER SIGNAL RECEIVED {name} ({signum})")
        prev = previous.get(signum, _signal.SIG_DFL)
        try:
            _signal.signal(signum, prev)  # type: ignore[arg-type]
        except (ValueError, OSError, TypeError) as exc:
            _diag(f"worker signal restore failed for {name}", exc=exc)
            prev = _signal.SIG_DFL
            try:
                _signal.signal(signum, _signal.SIG_DFL)
            except (ValueError, OSError):
                pass
        if callable(prev):
            try:
                prev(signum, frame)
                return
            except BaseException:
                raise
        try:
            os.kill(os.getpid(), signum)
        except Exception as exc:  # noqa: BLE001
            _diag(f"worker signal re-raise failed for {name}", exc=exc)

    for n in ("SIGINT", "SIGTERM", "SIGBREAK", "SIGHUP"):
        sig = getattr(_signal, n, None)
        if sig is None:
            continue
        try:
            previous[sig] = _signal.getsignal(sig)
            _signal.signal(sig, _handler)
        except (ValueError, OSError) as exc:
            _diag(f"worker: could not install handler for {n}", exc=exc)


# Flags whose values may embed credentials (e.g. URLs with tokens). When echoing
# argv for diagnostics, we substitute "<redacted>" for the value of any of these.
_SENSITIVE_FLAGS = frozenset(
    {
        "--package",
        "--mirror",
        "--index-url",
        "--extra-index-url",
        "-i",
    }
)


def _redact_argv(argv: list[str]) -> list[str]:
    """Return a copy of ``argv`` with values of sensitive flags redacted.

    Handles both ``--flag value`` and ``--flag=value`` forms.
    """
    out: list[str] = []
    i = 0
    while i < len(argv):
        token = argv[i]
        if "=" in token:
            flag, _, _value = token.partition("=")
            if flag in _SENSITIVE_FLAGS:
                out.append(f"{flag}=<redacted>")
                i += 1
                continue
        if token in _SENSITIVE_FLAGS and i + 1 < len(argv):
            out.append(token)
            out.append("<redacted>")
            i += 2
            continue
        out.append(token)
        i += 1
    return out


def _wait_for_process_exit(pid: int, timeout_seconds: float | None = None) -> None:
    """Wait for a process to exit. Best-effort on POSIX; uses WaitForSingleObject on Windows."""
    _diag(f"_wait_for_process_exit: entry pid={pid} timeout={timeout_seconds}")
    if sys.platform != "win32":
        # POSIX: poll with kill(0)
        deadline = (time.time() + timeout_seconds) if timeout_seconds else None
        while True:
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                return
            except OSError:
                # Permission denied — process exists but in another user's
                # namespace; treat as alive for waiting purposes.
                pass
            if deadline is not None and time.time() >= deadline:
                return
            time.sleep(0.5)
        return

    synchronize = 0x00100000
    infinite = 0xFFFFFFFF
    kernel32 = ctypes.windll.kernel32
    handle = kernel32.OpenProcess(synchronize, False, pid)
    if not handle:
        return
    try:
        wait_ms = int(timeout_seconds * 1000) if timeout_seconds else infinite
        kernel32.WaitForSingleObject(handle, wait_ms)
    finally:
        kernel32.CloseHandle(handle)


def _kill_process(pid: int) -> None:
    """Terminate a process. Best-effort — no exception on failure."""
    _diag(f"_kill_process: entry pid={pid}")
    if pid < 1:
        _diag("_kill_process: pid<1, skipping")
        return
    if sys.platform == "win32":
        try:
            _diag(f"_kill_process: running taskkill /PID {pid} /T /F (timeout=20)")
            r = subprocess.run(
                ["taskkill", "/PID", str(pid), "/T", "/F"],
                capture_output=True,
                timeout=20,
            )
            _diag(
                f"_kill_process: taskkill returncode={r.returncode} "
                f"stdout={r.stdout!r} stderr={r.stderr!r}"
            )
        except Exception as exc:  # noqa: BLE001
            _diag("_kill_process: taskkill raised", exc=exc)
        return
    import signal

    for sig in (signal.SIGTERM, signal.SIGKILL):
        try:
            os.kill(pid, sig)
        except ProcessLookupError:
            return
        except OSError:
            return
        time.sleep(1)


def _reexec_pc_update(original_args: list[str]) -> int:
    """Re-run ``pc update`` after the daemon is gone. Returns the exit code."""
    # Prefer the entry-point script so the user-visible command matches what
    # they would type manually. Fall back to ``python -m`` if the script is
    # not on PATH (e.g. a virtualenv without ``Scripts``/``bin`` activated).
    import shutil

    pc_path = shutil.which("praestoclaw") or shutil.which("pc")
    if pc_path:
        cmd = [pc_path, "update", *original_args]
    else:
        cmd = [sys.executable, "-m", "praestoclaw", "update", *original_args]
    print("Re-running:", " ".join(_redact_argv(cmd)), flush=True)
    _diag(f"reexec: about to run {' '.join(_redact_argv(cmd))}")
    try:
        result = subprocess.run(cmd)
    except OSError as exc:
        print(f"Failed to re-run pc update: {exc}", file=sys.stderr)
        _diag("reexec: subprocess.run raised OSError", exc=exc)
        return 1
    _diag(f"reexec: subprocess.run returned exit={result.returncode}")
    return result.returncode


def main() -> int:
    parser = argparse.ArgumentParser(description="PraestoClaw self-update background worker")
    parser.add_argument("--parent-pid", type=int, required=True)
    parser.add_argument("--cwd", default=None)
    parser.add_argument(
        "--start-praestoclaw",
        action="store_true",
        help="Start PraestoClaw after a successful update.",
    )
    parser.add_argument(
        "--reexec-update",
        action="store_true",
        help=(
            "Daemon self-update mode: kill --parent-pid then re-run "
            "`pc update` with the trailing argv. Used when the bot "
            "invokes pc update against its own process tree."
        ),
    )
    parser.add_argument("pip_args", nargs=argparse.REMAINDER)
    args = parser.parse_args()

    pip_args = list(args.pip_args)
    if pip_args and pip_args[0] == "--":
        pip_args = pip_args[1:]

    _install_signal_logger()
    _diag(
        f"worker started: reexec_update={args.reexec_update} "
        f"parent_pid={args.parent_pid} start_praestoclaw={args.start_praestoclaw} "
        f"pip_args={_redact_argv(pip_args)} cwd={args.cwd!r} "
        f"executable={sys.executable!r} argv={_redact_argv(sys.argv)} "
        f"pid={os.getpid()} ppid={os.getppid()}"
    )

    if args.reexec_update:
        # Give the daemon a moment to flush before we kill it.
        _diag("reexec: sleeping 2s before kill")
        time.sleep(2)
        print(f"Stopping daemon PID {args.parent_pid}...", flush=True)
        _diag(f"reexec: killing daemon PID {args.parent_pid}")
        _kill_process(args.parent_pid)
        _diag(f"reexec: kill returned, waiting for PID {args.parent_pid} to exit (timeout=30s)")
        _wait_for_process_exit(args.parent_pid, timeout_seconds=30)
        _diag("reexec: daemon exited (or wait timed out), proceeding to _reexec_pc_update")
        try:
            rc = _reexec_pc_update(pip_args)
        except BaseException as exc:  # noqa: BLE001 — capture *any* exit reason
            _diag("reexec: _reexec_pc_update raised", exc=exc)
            raise
        _diag(f"worker exiting: rc={rc}")
        return rc

    if not pip_args:
        print("No pip arguments provided.", file=sys.stderr)
        _diag("worker exiting: no pip_args (rc=1)")
        return 1

    _diag(f"pip-defer: waiting for parent PID {args.parent_pid} to exit")
    _wait_for_process_exit(args.parent_pid)
    _diag("pip-defer: parent exited")

    cwd = Path(args.cwd) if args.cwd else None
    cmd = [sys.executable, "-m", "pip", *pip_args]
    print("Running:", " ".join(_redact_argv(cmd)), flush=True)
    _diag(f"pip-defer: running {_redact_argv(cmd)}")
    result = subprocess.run(cmd, cwd=cwd)
    _diag(f"pip-defer: pip returned exit={result.returncode}")
    if result.returncode == 0:
        print("PraestoClaw update complete.", flush=True)
        if args.start_praestoclaw:
            print("Running post-update startup sequence...", flush=True)
            _diag("pip-defer: running praestoclaw init --quick")
            try:
                step_result = subprocess.run(
                    ["praestoclaw", "init", "--quick"], cwd=cwd, timeout=300
                )
                _diag(f"pip-defer: init --quick returned exit={step_result.returncode}")
                if step_result.returncode != 0:
                    print(
                        f"Command failed ({step_result.returncode}): praestoclaw init --quick",
                        file=sys.stderr,
                    )
            except subprocess.TimeoutExpired:
                print("praestoclaw init --quick timed out (300s)", file=sys.stderr)
                _diag("pip-defer: init --quick TIMED OUT after 300s")
            except OSError as exc:
                print(f"Failed to run praestoclaw init --quick: {exc}", file=sys.stderr)
                _diag("pip-defer: init --quick OSError", exc=exc)

            print("Starting PraestoClaw server...", flush=True)
            _diag("pip-defer: spawning `praestoclaw s`")
            try:
                proc = subprocess.Popen(["praestoclaw", "s"], cwd=cwd)
                _diag(f"pip-defer: spawned `praestoclaw s` pid={proc.pid}")
            except OSError as exc:
                print(f"Failed to start PraestoClaw: {exc}", file=sys.stderr)
                _diag("pip-defer: spawn `praestoclaw s` OSError", exc=exc)
    else:
        print(f"PraestoClaw update failed with exit code {result.returncode}.", file=sys.stderr)
    _diag(f"worker exiting: rc={result.returncode}")
    return result.returncode


if __name__ == "__main__":
    try:
        _rc = main()
    except BaseException as _exc:  # noqa: BLE001 — diagnose silent worker exits
        _diag("main() raised — worker terminating abnormally", exc=_exc)
        raise
    raise SystemExit(_rc)
