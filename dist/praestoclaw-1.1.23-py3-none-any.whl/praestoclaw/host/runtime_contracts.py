"""Runtime contracts used by the new Agent Host skeleton.

The concrete AgentRuntime implementation will move into ``praestoclaw.runtime``
after the legacy ``praestoclaw/runtime.py`` module is removed.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

from agent_gateway_protocol.agent_link.v1 import InitiatedBy

WORKFLOW_RUNTIME_METADATA_KEYS = (
    "workflow",
    "workflow_allowed_tools",
    # A denial list can only ever narrow what a run may do, so carrying it across
    # the ingress boundary cannot widen authority. Omitting it silently disarms
    # hooks.WorkflowCommandDenylist: the producer (_normalize_limits) and the
    # consumer (the hook) both looked correct in isolation while the key was
    # dropped in transit, and every unit test built its context by hand and so
    # never crossed this seam.
    "workflow_denied_commands",
    "workflow_owner",
    "workflow_params",
    "workflow_supersede_prev",
)


def is_runtime_background_task_id(value: object) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 12
        and all(char in "0123456789abcdef" for char in value)
    )


def is_trusted_workflow_run(metadata: object) -> bool:
    if not isinstance(metadata, dict):
        return False

    background_task_id = metadata.get("background_task_id")
    if metadata.get("physical_ingress") == "internal_api" and is_runtime_background_task_id(
        background_task_id
    ):
        return True

    source = metadata.get("source")
    provenance = metadata.get("turn_provenance")
    return (
        isinstance(source, str)
        and source in {"cron", "heartbeat"}
        and metadata.get("physical_ingress") == "local_scheduler"
        and isinstance(provenance, dict)
        and provenance.get("initiated_by") == "scheduler"
        and provenance.get("human_initiated") is False
        and provenance.get("logical_channel") == "scheduler_local"
        and provenance.get("trust_boundary") == "system"
    )


@dataclass(frozen=True, slots=True)
class TurnProvenanceSummary:
    initiated_by: InitiatedBy
    human_initiated: bool
    logical_channel: str
    trust_boundary: str
    supervision_required: bool
    reply_constraints: dict[str, Any]


@dataclass(frozen=True, slots=True)
class AgentRuntimeRequest:
    agent_id: str
    session_id: str
    user_content: str
    turn_id: str = ""
    attachments: tuple[Any, ...] = ()
    runtime_policy: dict[str, Any] = field(default_factory=dict)
    tool_policy: dict[str, Any] = field(default_factory=dict)
    turn_provenance: TurnProvenanceSummary | None = None
    supervision_policy: dict[str, Any] = field(default_factory=dict)
    memory_context: dict[str, Any] = field(default_factory=dict)
    cancellation_token: Any | None = None
    stream_sink: Any | None = None


@dataclass(frozen=True, slots=True)
class AgentRuntimeResult:
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)


class AgentRuntimeProtocol(Protocol):
    async def run_once(self, request: AgentRuntimeRequest) -> AgentRuntimeResult: ...
