"""
A2A Runtime — async envelope orchestrator.

Replaces the prior synchronous task-RPC model. Responsibilities:

* Outbound: build text envelopes, register pending entries, push them through
  the configured frame sender, await an inline ``a2a_dispatch`` correlated by
  ``message_id`` (short timeout), return ack/text replies later via the bus
  as injected ``InboundMessage`` notifications.
* Inbound: route ``a2a_message`` frames into three branches:
    - new TEXT request → send ack frame, run agent loop, send text reply.
    - reply (TEXT with ``parent_id`` / ACK / ERROR) → look up the originating
      pending entry and inject a friendly system notification back to the
      original user channel.
* Discovery, listing, and routing are Gateway-internal business-protocol
  concerns; this runtime never fetches public agent-card JSON.

P3 deliberately leaves all wiring (cloud channel routing, runtime construction,
``a2a`` tool simplification) for P4. Method names ``set_process_fn`` and
``set_frame_sender`` are preserved so the existing imports in
``praestoclaw/runtime.py`` keep working.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from loguru import logger

from praestoclaw.a2a.models import A2AEnvelope, A2AMessageType, A2AParty
from praestoclaw.bus.events import OutboundMessage
from praestoclaw.bus.queue import MessageBus
from praestoclaw.config.schema import ChannelType
from praestoclaw.task import TASK_HARD_CAP_MS

ProcessFn = Callable[..., Awaitable[str]]
SendFrameFn = (
    Callable[[dict[str, Any]], Awaitable[bool]] | Callable[[dict[str, Any]], Awaitable[None]]
)
DiscoverFn = Callable[[str], Awaitable[dict[str, Any]]]
A2AListFn = Callable[[str], Awaitable[dict[str, Any]]]
# Persist-only recorder for owner-session context injection. Keyword args:
#   sender_id, sender_name, inbound_text, reply_text (None for task carriers),
#   kind ("message" | "task"), origin_message_id (the sender's original a2a id,
#   when known, so the note can ask the owner to cite it when relaying a reply).
#   Implementations must be best-effort and must never raise into the reply path.
OwnerContextRecorder = Callable[..., Awaitable[None]]
SessionEventRecorder = Callable[..., Awaitable[None]]

DISPATCH_TIMEOUT = 10.0  # seconds to wait for inline a2a_dispatch
SWEEP_INTERVAL = 60.0  # seconds between TTL sweeps
_TASK_TTL_GRACE_S = 300.0  # drain window after the task hard cap
TASK_PENDING_TTL = (TASK_HARD_CAP_MS / 1000.0) + _TASK_TTL_GRACE_S


@dataclass
class _PendingOut:
    """An outbound a2a text envelope awaiting dispatch ack and/or reply."""

    message_id: str
    channel: Any  # ChannelType | str — stored as-is for re-injection
    channel_id: str
    session_id: str
    target_label: str  # display label for the receiver (id or name)
    sender_label: str  # display label for the local sender (id or name)
    created_at: float = field(default_factory=time.time)
    future: asyncio.Future[dict[str, Any]] | None = None
    # Set after handle_a2a_dispatch confirms the cloud translator
    # upgraded this carrier to a task. task/inbound.py uses this so
    # the terminal-stage progress event can find the originating
    # envelope (and thus the originating session/channel) and surface
    # the result as a real InboundMessage instead of a fire-and-forget
    # OutboundMessage bubble that the LLM never sees.
    task_id: str = ""


class A2ARuntime:
    """Orchestrates async agent-to-agent envelopes."""

    def __init__(
        self,
        local_party: A2AParty,
        *,
        pending_ttl: float = 600.0,
        gateway_url: str | None = None,
    ) -> None:
        self._local_party = local_party
        self._pending_ttl = pending_ttl
        self._pending: dict[str, _PendingOut] = {}
        self._inflight_inbound: set[asyncio.Task[None]] = set()

        from praestoclaw.a2a._telemetry import infer_gateway_env

        self._gateway_env = infer_gateway_env(gateway_url)

        self._bus: MessageBus | None = None
        self._send_frame_fn: SendFrameFn | None = None
        self._discover_fn: DiscoverFn | None = None
        self._list_fn: A2AListFn | None = None
        self._process_fn: ProcessFn | None = None
        # Resolver maps a ChannelType (the value injected into tool kwargs as
        # ``_channel``) to the actual Channel instance. Needed so the A2A
        # notify path can read CloudChannel._teams_routed_channel_ids.
        self._channel_resolver: Callable[[Any], Any] | None = None
        # Picker that selects which channel(s) should carry user-facing A2A
        # notifications (inbound heads-up, outbound reply mirror, error
        # notice). Returns a list so the runtime can broadcast across every
        # surface where the local user might be looking. When unset we fall
        # back to ``[ChannelType.CLOUD]`` which matches the original prod
        # assumption that the local user is always reachable via the gateway.
        self._notify_channels_picker: Callable[[], list[Any]] | None = None

        # Persist-only recorder that injects an informational note about an
        # inbound a2a request into the owner's interactive session (so a later
        # human confirmation can be relayed). Distinct from the UI heads-up
        # (``_publish_user_notify``) and the isolated auto-reply
        # (``_run_inbound_agent``): it writes directly to the session store and
        # does NOT trigger an agent turn.
        self._owner_context_recorder: OwnerContextRecorder | None = None
        self._session_event_recorder: SessionEventRecorder | None = None

        self._sweeper_task: asyncio.Task[None] | None = None
        self._closed = False

    # ── Telemetry ──────────────────────────────────────────────────────

    def _emit_a2a_sent(
        self,
        *,
        start_ts: float,
        message_id: str,
        receiver: A2AParty,
        result: dict[str, Any],
        has_task: bool,
    ) -> None:
        """Fire-and-forget emit for an outbound A2A dispatch outcome.

        Captures every send path — happy + the four early-return failure
        modes — so client-side A2A success rate can be computed without
        Gateway-side correlation.
        """
        try:
            import time as _time

            from praesto_telemetry import Events, emit

            ok = bool(result.get("ok"))
            emit(
                Events.A2A_MESSAGE_SENT,
                message_id=message_id or "",
                peer_agent_id=(receiver.agent_id or receiver.id or ""),
                success=ok,
                error_code=(result.get("error_code") or ""),
                has_task=has_task,
                duration_ms=int((_time.monotonic() - start_ts) * 1000),
                gateway_env=self._gateway_env,
            )
        except Exception:  # pragma: no cover - never let telemetry break A2A
            pass

    # ── Wiring ─────────────────────────────────────────────────────────

    def set_bus(self, bus: MessageBus) -> None:
        self._bus = bus

    def set_process_fn(self, fn: ProcessFn) -> None:
        self._process_fn = fn

    def set_frame_sender(self, fn: SendFrameFn) -> None:
        self._send_frame_fn = fn

    def set_discovery_sender(self, fn: DiscoverFn) -> None:
        self._discover_fn = fn

    def set_list_sender(self, fn: A2AListFn) -> None:
        self._list_fn = fn

    def set_channel_resolver(self, fn: Callable[[Any], Any]) -> None:
        """Inject a ChannelType -> Channel instance lookup."""
        self._channel_resolver = fn

    def set_notify_channel_picker(self, fn: Callable[[], list[Any]]) -> None:
        """Inject a callable returning the channels to publish notifications on.

        The picker is invoked once per notification publish so its choice
        reflects the current connection state of each channel. Returning an
        empty list means "no channel is active" — the runtime then falls back
        to ``[ChannelType.CLOUD]`` so the message at least surfaces in logs.
        """
        self._notify_channels_picker = fn

    def set_owner_context_recorder(self, fn: OwnerContextRecorder) -> None:
        """Inject a persist-only owner-session context recorder.

        The recorder writes an informational note about an inbound a2a request
        into the owner's interactive session (without triggering an agent
        turn), so a later human confirmation can be understood and relayed back
        to the remote sender.
        """
        self._owner_context_recorder = fn

    def set_session_event_recorder(self, fn: SessionEventRecorder) -> None:
        """Inject the host-owned recorder for non-LLM session events."""
        self._session_event_recorder = fn

    async def record_owner_context(
        self,
        *,
        sender_id: str,
        sender_name: str | None,
        inbound_text: str,
        reply_text: str | None = None,
        kind: str = "message",
        origin_message_id: str | None = None,
    ) -> None:
        """Best-effort: inject inbound-a2a context into the owner's session.

        ``origin_message_id`` is the *sender's* original a2a message id (when
        known) so the note can ask the owner's agent to cite it when relaying a
        reply — letting the far sender's agent thread the follow-up back to the
        message it actually sent.

        No-op when no recorder is wired. Never raises into the caller — owner
        context is a convenience, not part of the reply contract.
        """
        if self._owner_context_recorder is None:
            return
        try:
            await self._owner_context_recorder(
                sender_id=sender_id,
                sender_name=sender_name,
                inbound_text=inbound_text,
                reply_text=reply_text,
                kind=kind,
                origin_message_id=origin_message_id,
            )
        except Exception as exc:  # noqa: BLE001 — best-effort; never block reply
            logger.warning("A2A owner-context record failed: {}", exc)

    def _resolve_notify_channels(self) -> list[ChannelType]:
        if self._notify_channels_picker is None:
            return [ChannelType.CLOUD]
        try:
            picked = self._notify_channels_picker()
        except Exception as exc:  # noqa: BLE001 — best-effort; never block notify
            logger.warning("A2A notify picker raised: {}", exc)
            return [ChannelType.CLOUD]
        if not picked:
            return [ChannelType.CLOUD]
        return list(picked)

    async def _publish_user_notify(self, *, content: str, channel_id: str) -> None:
        """Fan out an A2A user-facing notification to every picked channel.

        The resolver may return more than one ChannelType (e.g. when cloud is
        offline, the runtime broadcasts to every locally-connected surface so
        the user sees the heads-up wherever they are sitting). Each publish
        is independent: a failure on one surface is logged but does not stop
        the others.
        """
        if self._bus is None:
            return
        channels = self._resolve_notify_channels()
        logger.info(
            "[a2a-notify] publish channel_id={} picked_channels={}",
            channel_id,
            [str(c) for c in channels],
        )
        for channel in channels:
            try:
                await self._bus.publish_outbound(
                    OutboundMessage(
                        channel=channel,
                        channel_id=channel_id,
                        content=content,
                    )
                )
            except Exception as exc:  # noqa: BLE001 — independent best-effort per surface
                logger.warning("A2A notify publish failed on channel={}: {}", channel, exc)

    @property
    def local_party(self) -> A2AParty:
        return self._local_party

    def update_local_party(
        self,
        user_id: str,
        *,
        display_name: str | None = None,
        agent_id: str | None = None,
    ) -> A2AParty:
        """Update the local sender identity after late auth resolution."""

        next_id = user_id.strip()
        if not next_id:
            raise ValueError("A2A local party user_id must not be empty")

        current = self._local_party
        next_name = display_name if display_name is not None else current.name
        if not next_name or next_name == current.id:
            next_name = next_id
        next_agent_id = agent_id if agent_id is not None else current.agent_id
        self._local_party = A2AParty(id=next_id, name=next_name, agent_id=next_agent_id)
        return self._local_party

    async def discover(self, target_user_id: str) -> dict[str, Any]:
        """Query Gateway-internal A2A discovery over the native business protocol."""
        if self._discover_fn is None:
            return {"error": True, "detail": "A2A discovery is not configured"}
        return await self._discover_fn(target_user_id)

    async def list_agents(self, scope: str = "mine") -> dict[str, Any]:
        """List A2A agents via the Gateway-internal semantic listing extension."""
        if self._list_fn is None:
            return {"error": True, "detail": "A2A listing is not configured"}
        return await self._list_fn(scope)

    # ── Outbound ───────────────────────────────────────────────────────

    async def send_async(
        self,
        target: str,
        content: str,
        *,
        channel: Any,
        channel_id: str,
        session_id: str,
        target_name: str = "",
        target_agent_id: str = "",
        task: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send a text envelope to *target*; await the inline dispatch result.

        When ``task`` is provided, the outbound carrier is upgraded to a
        task-bearing ``a2a.message.send`` (PraestoClaw Gateway v1 task
        protocol). The dict shape mirrors :class:`TaskRequest` fields —
        recognised keys are ``task_id`` (auto-generated when absent),
        ``summary`` (required), ``action``, ``hint_risk``, ``undoable``,
        ``args``, ``soft_ms``, ``hard_ms``. The cloud channel translates
        the frame into a task carrier so the executor's
        ``TaskHeartbeatEmitter`` (issue #181) actually fires.

        Returns:
            ``{"ok": True, "message_id": <id>, "task_id": <id>?}`` on
            success, or ``{"ok": False, "error_code": str,
            "error_message": str, "message_id": <id>}`` on dispatch
            error / timeout.
        """
        self._ensure_sweeper()
        import time as _time

        start_ts = _time.monotonic()

        target_id = (target or "").strip()
        if not target_id:
            result = {
                "ok": False,
                "error_code": "invalid_target",
                "error_message": "target is empty",
                "message_id": "",
            }
            self._emit_a2a_sent(
                start_ts=start_ts,
                message_id="",
                receiver=A2AParty(id="", name=target_name, agent_id=target_agent_id),
                result=result,
                has_task=task is not None,
            )
            return result

        receiver = A2AParty(
            id=target_id,
            name=target_name or "",
            agent_id=(target_agent_id or "").strip(),
        )
        envelope = A2AEnvelope.new_text(
            sender=self._local_party,
            receiver=receiver,
            content=content,
        )

        loop = asyncio.get_running_loop()
        future: asyncio.Future[dict[str, Any]] = loop.create_future()
        entry = _PendingOut(
            message_id=envelope.id,
            channel=channel,
            channel_id=channel_id,
            session_id=session_id,
            target_label=target_name or target_id,
            sender_label=self._local_party.name or self._local_party.id,
            future=future,
        )
        self._pending[envelope.id] = entry

        frame: dict[str, Any] = {
            "type": "a2a_message",
            "envelope": envelope.to_dict(),
        }

        # Task-mode upgrade: opt-in by passing a ``task`` dict. The
        # frame translator in cloud.py owns the contract that this key
        # exists *only* when the caller deliberately requested task
        # semantics — never set it on a plain text send.
        if task is not None:
            frame["task"] = dict(task)

        if self._send_frame_fn is None:
            self._pending.pop(envelope.id, None)
            result = {
                "ok": False,
                "error_code": "no_transport",
                "error_message": "frame sender not configured",
                "message_id": envelope.id,
            }
            self._emit_a2a_sent(
                start_ts=start_ts,
                message_id=envelope.id,
                receiver=receiver,
                result=result,
                has_task=task is not None,
            )
            return result

        try:
            await self._send_frame_fn(frame)  # type: ignore[misc]
        except Exception as exc:
            self._pending.pop(envelope.id, None)
            logger.error("A2A send_async transport error: {}", exc)
            result = {
                "ok": False,
                "error_code": "transport_error",
                "error_message": str(exc),
                "message_id": envelope.id,
            }
            self._emit_a2a_sent(
                start_ts=start_ts,
                message_id=envelope.id,
                receiver=receiver,
                result=result,
                has_task=task is not None,
            )
            return result

        try:
            result = await asyncio.wait_for(future, timeout=DISPATCH_TIMEOUT)
        except TimeoutError:
            self._pending.pop(envelope.id, None)
            logger.warning("A2A dispatch timeout for message_id={}", envelope.id)
            result = {
                "ok": False,
                "error_code": "dispatch_timeout",
                "error_message": (f"no a2a_dispatch received within {DISPATCH_TIMEOUT}s"),
                "message_id": envelope.id,
            }
            self._emit_a2a_sent(
                start_ts=start_ts,
                message_id=envelope.id,
                receiver=receiver,
                result=result,
                has_task=task is not None,
            )
            return result
        finally:
            # Future is consumed; clear it so the entry only carries
            # correlation metadata for the eventual ack/reply.
            entry.future = None

        # Surface the dispatch outcome.
        result.setdefault("message_id", envelope.id)
        if task is not None:
            # task_id may have been auto-generated downstream; the
            # caller (LLM-facing tool) needs it to issue task.control
            # later (cancel / interrupt). Surface whatever the cloud
            # translator settled on, falling back to whatever the
            # caller passed in.
            tid = result.get("task_id") or task.get("task_id")
            if tid:
                result["task_id"] = tid
        self._emit_a2a_sent(
            start_ts=start_ts,
            message_id=envelope.id,
            receiver=receiver,
            result=result,
            has_task=task is not None,
        )
        return result

    # ── Inbound: a2a_message ───────────────────────────────────────────

    async def handle_a2a_message(self, frame_data: dict[str, Any]) -> None:
        """Route an inbound ``a2a_message`` frame to the correct branch."""
        env_dict = frame_data.get("envelope")
        if not isinstance(env_dict, dict):
            logger.warning("handle_a2a_message: missing envelope field")
            return

        try:
            envelope = A2AEnvelope.from_dict(env_dict)
        except Exception as exc:
            logger.warning("handle_a2a_message: invalid envelope: {}", exc)
            return

        branch = (
            "request"
            if envelope.type is A2AMessageType.TEXT and not envelope.parent_id
            else "reply"
        )
        logger.info(
            "[A2A] runtime RX a2a_message: id={} type={} parent={} sender={} receiver={} -> {}",
            envelope.id,
            envelope.type.value,
            envelope.parent_id or "-",
            envelope.sender.id,
            envelope.receiver.id,
            branch,
        )

        if envelope.type is A2AMessageType.TEXT and not envelope.parent_id:
            await self._handle_inbound_request(envelope)
            return

        # Reply branch — ack, error, or text-with-parent_id.
        await self._handle_inbound_reply(envelope)

    async def _handle_inbound_request(self, envelope: A2AEnvelope) -> None:
        """A new TEXT request from a remote agent."""
        # 1. Send ack immediately so the remote sender's send_async resolves
        #    on the eventual text reply rather than waiting silently.
        ack = A2AEnvelope.new_ack(
            sender=self._local_party,
            receiver=envelope.sender,
            parent_id=envelope.id,
        )
        await self._send_envelope(ack)

        # 2. Notify the local user (push to webchat/teams) — without this they
        #    have no idea another agent contacted them.
        await self._notify_local_user_of_inbound(envelope)

        # 3. Spawn the agent loop in the background.
        task = asyncio.create_task(
            self._execute_inbound(envelope),
            name=f"a2a-inbound-{envelope.id}",
        )
        self._inflight_inbound.add(task)
        task.add_done_callback(self._inflight_inbound.discard)

    @staticmethod
    def _party_label(party: A2AParty) -> str:
        """Render a party as ``id`` or ``id (name)`` for user-facing notifications.

        The id is the canonical addressable identity (e.g. ``alice@contoso.com``);
        the name is decorative. Always show id; append name only when distinct
        and non-empty.
        """
        ident = party.id or "unknown"
        name = (party.name or "").strip()
        if name and name != ident:
            return f"{ident} ({name})"
        return ident

    async def _notify_local_user_of_inbound(self, envelope: A2AEnvelope) -> None:
        """Push a heads-up to the local user so they know an agent contacted them.

        Goes out as a non-routable cloud push (no agent loop involved) — the
        gateway fan-outs the push to the user's connected webchat/Teams clients.
        """
        if self._bus is None:
            return
        text = (
            f"[A2A] 收到来自 {self._party_label(envelope.sender)} 的请求 "
            f"(msg_id={envelope.id})：\n\n{envelope.text}\n\n"
            f"如果这需要你本人回应，请在会话里回复，我会代为转达；"
            f"若是我作为 agent 能直接处理的，我会自行处理。"
        )
        try:
            await self._publish_user_notify(
                content=text,
                channel_id=f"a2a:incoming:{envelope.id}",
            )
        except Exception as exc:  # noqa: BLE001 — best-effort notification
            logger.warning("A2A local notify failed: {}", exc)

    async def _notify_local_user_of_outbound_reply(
        self, request: A2AEnvelope, reply_text: str
    ) -> None:
        """Push a copy of the reply we sent so the local user knows what we said."""
        if self._bus is None:
            return
        text = (
            f"[A2A] 已回复 {self._party_label(request.sender)} "
            f"(re: {request.id})：\n\n{reply_text or '(空回复)'}"
        )
        try:
            await self._publish_user_notify(
                content=text,
                channel_id=f"a2a:replied:{request.id}",
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("A2A local outbound-reply notify failed: {}", exc)

    async def _notify_local_user_of_outbound_error(
        self, request: A2AEnvelope, code: str, reason: str
    ) -> None:
        """Push an error notice so the local user knows we failed to handle the request."""
        if self._bus is None:
            return
        text = (
            f"[A2A] 处理 {self._party_label(request.sender)} 的请求时出错 "
            f"(msg_id={request.id})：{code} — {reason}"
        )
        try:
            await self._publish_user_notify(
                content=text,
                channel_id=f"a2a:replied:{request.id}",
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("A2A local outbound-error notify failed: {}", exc)

    async def _execute_inbound(self, envelope: A2AEnvelope) -> None:
        if self._process_fn is None:
            logger.error("A2A inbound dropped — process_fn not configured")
            err = A2AEnvelope.new_error(
                sender=self._local_party,
                receiver=envelope.sender,
                code="no_process_fn",
                reason="agent loop not configured",
                parent_id=envelope.id,
            )
            await self._send_envelope(err)
            return

        try:
            result_text = await self._run_inbound_agent(envelope)
        except Exception as exc:
            logger.error("A2A inbound process_fn failed: {}", exc)
            err = A2AEnvelope.new_error(
                sender=self._local_party,
                receiver=envelope.sender,
                code="execution_error",
                reason=str(exc)[:120],
                detail=str(exc),
                parent_id=envelope.id,
            )
            await self._send_envelope(err)
            await self._notify_local_user_of_outbound_error(
                envelope, "execution_error", str(exc)[:120]
            )
            return

        reply = A2AEnvelope.new_text(
            sender=self._local_party,
            receiver=envelope.sender,
            content=result_text or "",
            parent_id=envelope.id,
        )
        await self._send_envelope(reply)
        await self._notify_local_user_of_outbound_reply(envelope, result_text or "")
        await self.record_owner_context(
            sender_id=envelope.sender.id,
            sender_name=envelope.sender.name,
            inbound_text=envelope.text,
            reply_text=result_text or "",
            kind="message",
            # Legacy wire-frame path: the inbound envelope id IS the sender's
            # original a2a id (no business-layer id substitution here).
            origin_message_id=envelope.id or None,
        )

    async def _run_inbound_agent(self, envelope: A2AEnvelope) -> str:
        """Execute the local agent loop for a remote A2A request.

        Sessions are partitioned by sender id so the inbound conversation is
        isolated from the local owner's session — the agent does not inherit
        prior owner-context (and therefore does not greet the wrong person).
        Tools that could trigger an outbound A2A loop or scheduled job are
        excluded.
        """
        if self._process_fn is None:
            raise RuntimeError("a2a process_fn not configured")
        sender_key = envelope.sender.id or "unknown"
        sender_label = envelope.sender.name or envelope.sender.id or "unknown"
        # Prefix the message with sender context so the local agent does not
        # mistake the request for one from its owner (and therefore avoids
        # greeting the wrong person, e.g. "Hi <owner>!").
        prompt = (
            f"[A2A inbound] You are the RECEIVER AGENT. An external agent "
            f"(id={envelope.sender.id}, name={sender_label}) sent the message "
            f"below on behalf of its own user (the sender's owner).\n\n"
            f"First decide who the message is really for:\n"
            f"- If it is a peer-agent task you can complete yourself (look "
            f"something up, run an analysis, report your own status, etc.), "
            f"handle it and reply directly to the sending agent.\n"
            f"- If it asks YOUR human owner (the person, your user) to respond, "
            f"confirm, decide, or do something only the person can do (e.g. "
            f'"ask her to reply hi", "请她确认一下", "让他本人回个话"), you '
            f"MUST NOT answer on the human's behalf and MUST NOT invent or "
            f"guess their reply. Briefly acknowledge to the sender that the "
            f"request has been received and is being surfaced to your owner, "
            f"who will reply separately — then stop. Do NOT claim you "
            f"personally notified them and do NOT promise when/whether they "
            f"will reply. The system surfaces the message to your owner; their "
            f"later reply comes back to the sender as a new a2a message.\n"
            f"Default rule: if the message does NOT reference a human / person "
            f"/ owner / user and is within your own agent capabilities, treat "
            f"it as a peer-agent task and just do it — do not over-suppress.\n"
            f"Either way reply as a peer agent — do not address your local "
            f"user in this reply.\n\n"
            f"{envelope.text}"
        )
        return (
            await self._process_fn(
                prompt,
                session_id=f"a2a:{sender_key}",
                channel_id=f"a2a:{sender_key}",
                metadata={
                    "source": "a2a",
                    "sender_id": envelope.sender.id,
                    "sender_name": envelope.sender.name,
                    "parent_id": envelope.id,
                },
                exclude_tools=["notify", "cron", "spawn", "a2a"],
            )
            or ""
        )

    async def process_business_request(self, envelope: A2AEnvelope) -> str:
        """Handle an inbound a2a.message.send carried by the v1 wire RPC.

        The cloud channel's ``a2a.message.send`` dispatcher delegates here so
        the request runs in the isolated A2A session (notify the local user,
        run the agent loop with ``source=a2a`` metadata) and returns the reply
        text synchronously — the gateway carries it back to the sender as the
        RPC response, so we do not emit a separate reply envelope.

        Approval / risk gating hooks belong in front of ``_run_inbound_agent``.
        """
        await self._notify_local_user_of_inbound(envelope)
        try:
            reply_text = await self._run_inbound_agent(envelope)
        except Exception as exc:
            logger.exception("A2A inbound execution failed: {}", exc)
            await self._notify_local_user_of_outbound_error(
                envelope, "execution_error", str(exc)[:120]
            )
            raise
        await self._notify_local_user_of_outbound_reply(envelope, reply_text)
        await self.record_owner_context(
            sender_id=envelope.sender.id,
            sender_name=envelope.sender.name,
            inbound_text=envelope.text,
            reply_text=reply_text,
            kind="message",
            # Cite the same id the inbound heads-up shows the user
            # (``envelope.id`` == the wire request id), so the relayed reply's
            # "in reply to <id>" matches what the user saw on the message.
            origin_message_id=(envelope.id or None),
        )
        return reply_text

    async def _handle_inbound_reply(self, envelope: A2AEnvelope) -> None:
        """An ack / text-reply / error correlated to one of our sends."""
        parent_id = envelope.parent_id or ""
        if not parent_id:
            logger.warning(
                "A2A inbound {} without parent_id — dropping",
                envelope.type.value,
            )
            return

        entry = self._pending.get(parent_id)
        if entry is None:
            logger.warning(
                "A2A orphan reply (type={}, parent_id={}) — no pending entry",
                envelope.type.value,
                parent_id,
            )
            return

        # Prefer the canonical id (e.g. ``bob@contoso.com``) over a decorative
        # display name; fall back to the originally-targeted label if the reply
        # envelope arrives without sender info.
        target_label = (
            self._party_label(envelope.sender)
            if envelope.sender.id
            else (entry.target_label or "unknown")
        )

        if envelope.type is A2AMessageType.ACK:
            notification = f"[A2A] {target_label} 已确认收到你发出的消息 (msg_id={parent_id})"
            kind = "ack"
            terminal = False
        elif envelope.type is A2AMessageType.TEXT:
            notification = f"[A2A] {target_label} 回复了你 (re: {parent_id})：\n\n{envelope.text}"
            kind = "text"
            terminal = True
        elif envelope.type is A2AMessageType.ERROR:
            payload = envelope.payload or {}
            code = str(payload.get("code", "unknown"))
            reason = str(payload.get("reason", ""))
            detail = str(payload.get("detail", ""))
            notification = (
                f"[A2A] {target_label} 处理你的消息时出错 "
                f"(msg_id={parent_id})：{code} — {reason}\n{detail}"
            )
            kind = "error"
            terminal = True
        else:  # pragma: no cover — exhaustive enum
            logger.warning("A2A unknown reply type: {}", envelope.type)
            return

        await self._publish_notification(
            entry=entry,
            content=notification,
            kind=kind,
            parent_id=parent_id,
            target_id=entry.target_label,
        )

        if terminal:
            self._pending.pop(parent_id, None)

    async def _publish_notification(
        self,
        *,
        entry: _PendingOut,
        content: str,
        kind: str,
        parent_id: str,
        target_id: str,
    ) -> None:
        if self._bus is None:
            logger.warning("A2A notification dropped — bus not configured")
            return
        # Use a synthetic channel_id so channel-side code branching on
        # ``a2a:notify:<pid>`` (cloud's teams-routing eviction, etc.) keeps
        # working, and so we don't collide with the original request's
        # per-request queue. Precise per-connection routing happens via
        # ``route_hint`` (the agent loop forwards this onto OutboundMessage
        # and the channel layer prefers it over ``channel_id`` when picking
        # a destination, falling back to broadcast / drop normally).
        notify_channel_id = f"a2a:notify:{parent_id}"

        # Propagate Teams routing on the cloud side: when the original user
        # was on Teams, ``CloudChannel`` tracked their channel_id so
        # follow-up sends use ``push_target="teams"``. Hop the flag across
        # to ``notify_channel_id`` so the cloud send() promotion path keeps
        # working (cloud doesn't consult ``route_hint``; its routing is
        # keyed on ``channel_id``).
        resolved_channel: Any = entry.channel
        if self._channel_resolver is not None:
            try:
                resolved = self._channel_resolver(entry.channel)
            except Exception as exc:  # noqa: BLE001
                resolved = None
                logger.trace("[a2a-route] channel_resolver raised: {}", exc)
            if resolved is not None:
                resolved_channel = resolved
        is_teams_routed_fn = getattr(resolved_channel, "is_teams_routed", None)
        remember_route_fn = getattr(resolved_channel, "remember_teams_route", None)
        if callable(is_teams_routed_fn) and callable(remember_route_fn):
            try:
                if is_teams_routed_fn(entry.channel_id):
                    remember_route_fn(notify_channel_id)
                    logger.debug(
                        "[a2a-route] notify propagated teams routing: origin={} -> notify={}",
                        entry.channel_id,
                        notify_channel_id,
                    )
            except Exception as exc:  # noqa: BLE001
                logger.trace("[a2a-route] teams routing propagation raised: {}", exc)

        metadata = {
            "source": "a2a_notify",
            "kind": kind,
            "parent_id": parent_id,
            "target_id": target_id,
            "origin_channel_id": entry.channel_id,
        }
        if self._session_event_recorder is not None:
            await self._session_event_recorder(
                session_id=entry.session_id,
                channel=str(entry.channel),
                sender="a2a-system",
                content=content,
                metadata=metadata,
            )
        await self._bus.publish_outbound(
            OutboundMessage(
                channel=ChannelType.of(entry.channel, default=ChannelType.CLOUD),
                channel_id=notify_channel_id,
                content=content,
                route_hint=entry.channel_id,
                metadata=metadata,
            )
        )

    async def notify_task_terminal(
        self,
        task_id: str,
        content: str,
        *,
        kind: str = "task_result",
    ) -> bool:
        """Inject a terminal-stage task result into the sender's session.

        Used by ``task/inbound.py`` when a ``task.progress`` event for a
        sender-side, a2a-bound task reaches a TERMINAL_STAGE. We look up
        the originating ``_PendingOut`` (stamped with ``task_id`` at
        dispatch time) so the result rides on a real ``InboundMessage``
        targeted at the sender's *original* session/channel/channel_id —
        which means the agent loop persists it into the session's
        ``messages`` table and the LLM actually sees on the next turn
        that the task finished. Without this hop the user only sees the
        completion as a fire-and-forget UI bubble and the LLM keeps
        believing the remote task is still running.

        Returns True when a matching pending entry was found (and
        consumed); False when no such task is on file (already cleaned
        up, or arrived after TTL — caller may fall back to a
        UI-only emit in that case).
        """
        if not task_id:
            return False
        entry: _PendingOut | None = None
        match_id = ""
        for mid, candidate in self._pending.items():
            if candidate.task_id == task_id:
                entry = candidate
                match_id = mid
                break
        if entry is None:
            return False
        await self._publish_notification(
            entry=entry,
            content=content,
            kind=kind,
            parent_id=entry.message_id,
            target_id=entry.target_label or "",
        )
        # Task is terminal — drop the entry so a duplicate / replayed
        # event can't double-notify and so TTL sweep stays predictable.
        self._pending.pop(match_id, None)
        return True

    # ── Inbound: a2a_dispatch ──────────────────────────────────────────

    async def handle_a2a_dispatch(self, frame_data: dict[str, Any]) -> None:
        """Resolve the pending future for a previously-sent envelope."""
        message_id = str(frame_data.get("message_id", ""))
        if not message_id:
            logger.warning("handle_a2a_dispatch: missing message_id")
            return

        entry = self._pending.get(message_id)
        if entry is None or entry.future is None or entry.future.done():
            logger.debug(
                "handle_a2a_dispatch: no waiter for message_id={}",
                message_id,
            )
            # Still drop the entry on terminal error — no reply will arrive.
            if entry is not None and frame_data.get("status") == "error":
                self._pending.pop(message_id, None)
            return

        status = str(frame_data.get("status", ""))
        code = frame_data.get("code")
        message = frame_data.get("message")

        result: dict[str, Any]
        if status == "dispatched":
            result = {"ok": True, "message_id": message_id}
            # Surface task_id when the cloud translator upgraded this
            # envelope to a task carrier (issue #181 originator path),
            # so the LLM-facing tool can report it and later issue
            # task.control if needed.
            tid = frame_data.get("task_id")
            if isinstance(tid, str) and tid:
                result["task_id"] = tid
                # Stamp the entry too so a later terminal task.progress
                # event can correlate back to this envelope (and thus
                # the originating session/channel) via
                # :meth:`notify_task_terminal`.
                entry.task_id = tid
        else:
            result = {
                "ok": False,
                "error_code": str(code) if code is not None else status or "dispatch_failed",
                "error_message": str(message) if message is not None else "",
                "message_id": message_id,
            }

        entry.future.set_result(result)

        if status != "dispatched":
            # Terminal — no ack/reply will follow.
            self._pending.pop(message_id, None)

    # ── Frame helpers ──────────────────────────────────────────────────

    async def _send_envelope(self, envelope: A2AEnvelope) -> None:
        if self._send_frame_fn is None:
            logger.warning(
                "A2A envelope dropped — frame sender not configured (type={})",
                envelope.type.value,
            )
            return
        frame = {"type": "a2a_message", "envelope": envelope.to_dict()}
        logger.info(
            "[A2A] runtime TX a2a_message: id={} type={} parent={} sender={} receiver={}",
            envelope.id,
            envelope.type.value,
            envelope.parent_id or "-",
            envelope.sender.id,
            envelope.receiver.id,
        )
        try:
            await self._send_frame_fn(frame)  # type: ignore[misc]
        except Exception as exc:
            logger.error(
                "A2A failed to send envelope (type={}): {}",
                envelope.type.value,
                exc,
            )

    # ── Sweeper / lifecycle ────────────────────────────────────────────

    def _ensure_sweeper(self) -> None:
        if self._closed:
            return
        if self._sweeper_task is not None and not self._sweeper_task.done():
            return
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        self._sweeper_task = loop.create_task(self._sweep_loop(), name="a2a-pending-sweeper")

    async def _sweep_loop(self) -> None:
        try:
            while not self._closed:
                await asyncio.sleep(SWEEP_INTERVAL)
                self._sweep_once()
        except asyncio.CancelledError:
            pass

    def _sweep_once(self) -> None:
        now = time.time()
        stale = []
        for mid, entry in self._pending.items():
            ttl = TASK_PENDING_TTL if entry.task_id else self._pending_ttl
            if (now - entry.created_at) > ttl and (entry.future is None or entry.future.done()):
                stale.append(mid)
        for mid in stale:
            self._pending.pop(mid, None)
            logger.debug("A2A pending entry expired: {}", mid)

    async def close(self) -> None:
        self._closed = True
        if self._sweeper_task is not None:
            self._sweeper_task.cancel()
            try:
                await self._sweeper_task
            except (asyncio.CancelledError, Exception):
                pass
            self._sweeper_task = None

        for task in list(self._inflight_inbound):
            task.cancel()
        self._inflight_inbound.clear()

        for entry in list(self._pending.values()):
            if entry.future is not None and not entry.future.done():
                entry.future.set_exception(ConnectionError("A2A runtime closed"))
        self._pending.clear()
