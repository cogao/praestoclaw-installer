---
name: feedback
description: File a GitHub issue against gim-home/PraestoClaw with sanitized environment and conversation context when the user reports a problem with PraestoClaw itself
metadata:
  activation:
    keywords: [feedback, 反馈, report bug, 报告问题, file issue, 提 issue, /feedback, praestoclaw bug]
    patterns:
      - "(?i)^/feedback\\b"
      - "(?i)\\b(file|report|submit|open)\\s+(a\\s+)?(bug|issue|feedback)\\b"
      - "(?i)(报告|反馈|提交|提个).*?(问题|bug|issue)"
  requires:
    tools: [feedback_submit]
---

# Feedback Assistant

File a GitHub issue against `gim-home/PraestoClaw` when the user reports a bug
or rough edge in PraestoClaw itself.

Do not use this for bugs in the user's code, third-party tools, or generic
questions about PraestoClaw.

## Direct-submit contract

The user's `/feedback` request is the instruction to file the issue. Build one
complete sanitized body in memory and submit it directly. Do not show a preview,
add a review step, or ask for another confirmation.

`feedback_submit` is the only create/comment/edit path. It fixes the repository
to `gim-home/PraestoClaw`, fixes the label for create to `bug`, and streams the
body to `gh` over stdin. Its protected, session-bound operations run without
another approval in both personal and shared conversations. Do not call `shell`,
`write_file`, or any GitHub MCP tool for these operations.

## Workflow

1. Read the complaint from the current message. If the description is empty or
   only `/feedback`, ask one short follow-up and stop.

2. Build the full body in memory with these sections:

   ```markdown
   ## Description
   <the user's complete complaint>

   ## Environment
   - OS: <value or unavailable>
   - Python: <value or unavailable>
   - PraestoClaw: <value or unavailable>
   - Channel: <cli | teams | webchat | cloud>
   - CWD: <sanitized value or unavailable>
   - MCP servers: <known names or unavailable>
   - Skills loaded: <known names or unavailable>

   ## Recent log tail
   <sanitized tail or an unavailable marker>

   ## Recent conversation
   <last relevant turns, sanitized>
   ```

3. In a normal personal session, collect environment values and up to 200 recent
   log lines using the existing read-only tools when available. If collection
   fails, mark that field unavailable and continue; do not block submission.

4. In a shared group session, preserve the borrowed-identity boundary:
   - Do not read host logs or run environment-discovery commands.
   - Use only values already present in Runtime Context.
   - In `## Recent log tail`, write
     `_session diagnostics are attached automatically on submission_`.
   - `feedback_submit` automatically appends a bounded `## Session diagnostics`
     timeline selected only from this conversation's audit events. Do not add
     that section yourself and do not ask for a session ID or log path.
   - Keep the full body in memory; do not create a draft or temporary file.

5. Sanitize the full body before submission:
   - Home-directory usernames become `~`.
   - Email and UPN addresses become `[email]`.
   - Tokens, keys, secrets, and credentials become `[redacted]`.
   - Preserve useful log and conversation content; do not summarize away the
     evidence merely to shorten it.

6. If the current prompt contains successfully uploaded image URLs, add:

   ```markdown
   ## Screenshots
   ![screenshot 1](url)
   ```

   If upload failed, add a note that the screenshot was unavailable. Do not use
   a different submission mechanism.

7. Generate a title in the form `[Feedback] <specific summary>`. The summary
   must be non-empty and no longer than 80 characters.

8. Create the issue exactly once:

   ```text
   feedback_submit(action="create", title="[Feedback] <summary>", body="<full sanitized body>")
   ```

   Do not retry automatically on failure. Report the returned error so the user
   can decide what to do next.

9. On success, the tool returns structured `issue_number` and `url` fields.
   Return the URL and retain the issue number in conversation context for
   follow-ups in the same session.

## Follow-ups

When the user asks to supplement an issue created by `feedback_submit` in this
session, use the returned ID:

```text
feedback_submit(action="comment", issue_number=<id>, body="<sanitized addition>")
```

To correct its title, body, or both:

```text
feedback_submit(
   action="edit",
   issue_number=<id>,
   title="[Feedback] <corrected summary>",
   body="<corrected sanitized body>"
)
```

The tool refuses an ID not created in the same trusted session. Do not use a
different GitHub tool as a workaround. Comment/edit follow-ups use the same
protected path without another approval in personal and shared conversations.

## Safety boundaries

- Never include unsanitized home paths, emails, credentials, or secrets.
- Never accept or invent another repository, label, assignee, project, or
  milestone.
- Never use `shell`, `write_file`, a heredoc, or `--body` for feedback changes.
- Never submit an ambiguous or empty complaint.
- Never create more than one issue for a single `/feedback` request.
