"""Workflow tool — run a reusable single-agent recipe in an isolated session.

A workflow recipe is a Markdown file with YAML frontmatter, parsed with the
skill loader. **Honored frontmatter fields:** ``name``, ``description``, the
Markdown body (``content``), and the opt-in ``plan: true`` flag (run-as-Plan —
when set, ``run`` prepends a plan-driving preamble so the recipe executes as a
tracked, ``PlanStore``-persisted Plan; see ``_plan_preamble``). All other skill
frontmatter (``safe_tools``, ``keywords``, ``requires_*``, ``patterns``,
``workflow`` …) is IGNORED — in particular ``safe_tools`` is NOT applied, so a
recipe cannot grant itself approval-free tools; the spawned agent's shell/check
still go through the normal ApprovalGate.

Recipes live in the data dir's ``workflows/`` (default ``~/.praestoclaw/
workflows/*.md``, overridable via ``PRAESTOCLAW_DATA_DIR`` and different on
staging) plus a bundled dir shipped with the package (user recipes override
bundled by name). ``run`` executes the recipe body as a single ``default``
agent in a fresh isolated background session (reusing ``BackgroundTaskManager``);
the result is delivered back to the originating channel when it finishes.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import subprocess
import tempfile
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any, NamedTuple

import yaml
from loguru import logger

from praestoclaw.agent.tools import workflow_profile
from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.agent.tools.github_pr_scanner import (
    REQUIRED_ARGS as _PR_SCANNER_REQUIRED_ARGS,
)
from praestoclaw.agent.tools.github_pr_scanner import (
    SCHEMA_VERSION as _PR_SCANNER_SCHEMA,
)
from praestoclaw.agent.tools.github_pr_scanner import (
    TOOL_NAME as _PR_SCANNER_TOOL_NAME,
)
from praestoclaw.agent.tools.societas_scanner import (
    SCHEMA_VERSION as _SCANNER_PROMPT_SCHEMA,
)
from praestoclaw.agent.tools.societas_scanner import (
    TOOL_NAME as _SCANNER_TOOL_NAME,
)
from praestoclaw.agent.tools.workflow_runs import plan_waiting_for_approval
from praestoclaw.agent.workflow_protocol import SCANNER_SETUP_COMMAND
from praestoclaw.host.background_tasks import is_instance_limit_message, origin_from_kwargs
from praestoclaw.skills.loader import Skill, parse_skill_file
from praestoclaw.utils.limits import positive_int
from praestoclaw.utils.text import MAX_NAME_LEN as _MAX_NAME_LEN
from praestoclaw.utils.text import as_bool as _as_bool
from praestoclaw.utils.text import slugify as _slugify

_BUNDLED_DIR = Path(__file__).parent / "bundled_workflows"

_MAX_DESC_LEN = 500
_MAX_BODY_LEN = 20000
_MAX_PARAMS = 30
_MAX_PARAM_NAME_LEN = 64
_MAX_PARAM_VALUE_LEN = 512
# A parameter name is interpolated as a ``{name}`` placeholder in the body and
# matched by the substitution regex, so it must be identifier-safe.
_PARAM_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# ── First-use opt-in: offer to set up the always-on Societas scanner cron ──────
# The bundled bug-fix workflow, on its very FIRST run, offers to create the
# always-on Societas scanner cron (post-flip 托底 net). Detection is deterministic
# (empty durable run history = first run; and the scanner cron not already
# present); the offer + creation is consented + agent-driven (an imBack card the
# user must click). No user config is touched here.
_SCANNER_ONBOARDING_RECIPE = "fix-societas-bug"
_SCANNER_CRON_NAME = "societas-bug-watcher"
_SCANNER_CRON_SCHEDULE = "*/30 * * * *"
# The scanner schema is encoded in the deterministic tool name. Keep the legacy
# prompt-stamp parser below only so old prompt-mode installs can be identified
# and migrated rather than silently accepted.
# Anchored: the stamp must BE the first non-empty line, not merely appear somewhere
# (a comment or a retained template header would otherwise pass as current).
_SCANNER_SCHEMA_RE = re.compile(r"^\s*societas-scanner-schema:\s*(\d+)\s*$")
_SCANNER_REQUIRED_ARGS = (
    "bug_query_source",
    "org_url",
    "project",
    "repository",
    "assigned_to",
    "repo_path",
)
# Job names seen in the wild from a mis-followed onboarding. Used only to notice
# that *something* was installed for this purpose under the wrong name.
_SCANNER_LEGACY_NAMES = ("societas-scan", "wf-societas-scan")


class _WatcherSpec(NamedTuple):
    """What a correctly installed deterministic watcher looks like.

    Two workflows now ship one. The detection below used to read module constants
    directly, so a second watcher could be installed wrong and nothing would
    notice — which is the exact failure this machinery exists to catch, one level
    up. Passing the spec in makes the check reusable without duplicating it.

    ``spec`` is keyword-only with a Societas default so the existing call sites and
    their tests keep working unchanged; a new watcher must pass its own.
    """

    cron_name: str
    schedule: str
    tool_name: str
    schema_version: int
    required_args: tuple[str, ...]
    legacy_names: tuple[str, ...]


_SOCIETAS_WATCHER = _WatcherSpec(
    cron_name=_SCANNER_CRON_NAME,
    schedule=_SCANNER_CRON_SCHEDULE,
    tool_name=_SCANNER_TOOL_NAME,
    schema_version=_SCANNER_PROMPT_SCHEMA,
    required_args=_SCANNER_REQUIRED_ARGS,
    legacy_names=_SCANNER_LEGACY_NAMES,
)

# The PraestoClaw PR watcher. `*/10` rather than `*/30`: a Copilot review lands in
# 1m54s–6m01s, so a half-hour tick would spend most of its life looking at a state
# that has already moved on.
_PRAESTOCLAW_WATCHER_RECIPE = "fix-praestoclaw-bug"
_PRAESTOCLAW_WATCHER = _WatcherSpec(
    cron_name="praestoclaw-pr-watcher",
    schedule="*/10 * * * *",
    tool_name=_PR_SCANNER_TOOL_NAME,
    schema_version=_PR_SCANNER_SCHEMA,
    required_args=_PR_SCANNER_REQUIRED_ARGS,
    # No legacy names: this watcher has never shipped under another one. An empty
    # tuple makes `str.startswith` match nothing, which is the correct answer.
    legacy_names=(),
)


def _possible_stray_watchers(
    jobs: list[dict[str, Any]], *, spec: _WatcherSpec = _SOCIETAS_WATCHER
) -> list[dict[str, Any]]:
    """Jobs that MIGHT be a mis-installed watcher — candidates, never targets.

    A mis-followed onboarding produced `societas-scan` / `wf-societas-scan`. But a
    user may legitimately keep a separate triage or report cron under such a name,
    so this only *surfaces* candidates: the directive asks before anything is
    removed. Deleting on a name heuristic would be a destructive migration decided
    by guesswork.

    Each candidate carries ``name``, ``schedule`` and ``schema_version``. A current
    deterministic tool gets the current version; a legacy prompt job gets the stamp
    from its first non-empty line (or ``0``). A stamped legacy job is NOT skipped:
    the stamp proves it is an old watcher install under the wrong name, which makes
    migration safe after the canonical tool-mode job verifies.

    Callers must only consult this when the canonical watcher is absent or broken;
    a healthy canonical watcher's status does not depend on unrelated jobs.
    """
    out: list[dict[str, Any]] = []
    for job in jobs:
        name = str(job.get("name") or "").strip()
        if not name or name == spec.cron_name:
            continue
        if not spec.legacy_names or not name.lower().startswith(spec.legacy_names):
            continue
        prompt = str(job.get("prompt") or "")
        first_line = next((ln for ln in prompt.splitlines() if ln.strip()), "")
        stamp = _SCANNER_SCHEMA_RE.match(first_line)
        if str(job.get("tool") or "") == spec.tool_name:
            schema_version = spec.schema_version
        else:
            schema_version = int(stamp.group(1)) if stamp else 0
        out.append(
            {
                "name": name,
                "schedule": str(job.get("schedule") or job.get("cron") or "").strip(),
                "schema_version": schema_version,
            }
        )
    return out


def _scanner_job_problem(job: dict[str, Any], *, spec: _WatcherSpec = _SOCIETAS_WATCHER) -> str:
    """Why *job* is not a correctly installed, up-to-date watcher, or "".

    Observed live: onboarding asked for `societas-bug-watcher` at */30 running the
    bundled template, and what got created was a daily read-only triage job under a
    different name. Nothing noticed, and the first-run offer never fires twice — so
    the machine kept a watcher that could not do the job it existed for.
    """
    schedule = " ".join(str(job.get("schedule") or "").split())
    if schedule != spec.schedule:
        return f"schedule 是 {schedule or '(空)'}，应为 {spec.schedule}"
    if str(job.get("mode") or "") != "tool" or str(job.get("tool") or "") != spec.tool_name:
        # Wording is pinned by tests and deliberately left as-is: it names the
        # concrete failure a prompt-mode watcher produces, and rewording it to
        # sound generic bought nothing and broke two guards.
        return (
            f"任务不是确定性的 `{spec.tool_name}` tool-mode job；旧 prompt-mode "
            "scanner 会让 LLM 临场编脚本、触发审批或在 bug 查询失败时漏掉 PR"
        )
    arguments = job.get("arguments")
    if not isinstance(arguments, dict):
        return "tool arguments 缺失"
    missing = [key for key in spec.required_args if not str(arguments.get(key) or "").strip()]
    if missing:
        return f"tool arguments 缺少 {', '.join(missing)}"
    if job.get("enabled") is False:
        return "任务处于 disabled 状态"
    return ""


def _scanner_repair_directive(problem: str, *, strays: list[dict[str, Any]] | None = None) -> str:
    """Directive shown when the watcher is missing, stale, or misconfigured.

    *strays* are candidates from :func:`_possible_stray_watchers`. One carrying the
    current tool/schema identity is a watcher install under the wrong name; that is
    worth saying because it settles WHOSE job it is (a mis-followed onboarding, not
    the user's own triage cron), so removing it after the canonical one verifies is
    safe rather than a guess. The rest stay a question the user has to answer.
    """
    stray_step = ""
    if strays:
        renames = [s for s in strays if s["schema_version"] == _SCANNER_PROMPT_SCHEMA]
        others = [s for s in strays if s["schema_version"] != _SCANNER_PROMPT_SCHEMA]
        parts = []
        if renames:
            joined = "、".join(
                f"`{s['name']}`（{s['schedule'] or 'schedule 未知'}）" for s in renames
            )
            parts.append(
                f"{joined} 带有当前 watcher 的 schema/tool 标识 "
                f"`{_SCANNER_PROMPT_SCHEMA}`，说明它**是旧安装或 tool job 名字不对**"
                f"（不是用户自己另建的 triage 任务）。照下面步骤用 `{_SCANNER_CRON_NAME}` "
                f"这个名字建成确定性 tool-mode job、自检通过之后，再 "
                f"`cron(action='remove', job_id=<旧名字>)` 删掉它。"
                f"**不要试图把旧 prompt 抄过来** —— 新任务不运行 prompt。"
            )
        if others:
            joined = "、".join(
                f"`{s['name']}`（{s['schedule'] or 'schedule 未知'}）" for s in others
            )
            parts.append(
                f"{joined} 名字像是照这份 onboarding 装歪的，但也可能是用户自己另建的 "
                f"triage / 周报任务。**不要自己删** —— 列出它们的 schedule 和用途，问一句"
                f"「这些是之前装歪的吗？要我删掉吗？」，用户明确说删了才 "
                f"`cron(action='remove', job_id=<名字>)`。"
            )
        stray_step = "\n0. **先问用户**：" + " ".join(parts)
    return f"""

---
【扫描 cron 需要修】{problem}

它做不到该做的事（每 30 分钟扫新 bug + 盯 draft/active PR 的 CI / comment / 「绿了但还没 flip」）。请在**这一轮**修好：{stray_step}
1. `cron(action='info', job_id='{_SCANNER_CRON_NAME}')` 看看现在是什么（不存在就跳过）。
2. 用 `config_praestoclaw` 读 `agents.default.metadata` 的 `ado_bug_query` / `ado_org_url` / `ado_project`。org / project 缺了就问用户；`ado_bug_query` 缺了就问用户要提供 saved-query URL/GUID 或 WIQL，还是明确选择内置「当前 project、assigned-to-me、非终态 Bug」基线。
3. 把 query 规范化成 `<BUG_SOURCE>`：saved-query URL/GUID → `saved:<GUID>`；原始 WIQL → `wiql:<原文>`；用户明确选择内置基线 → `builtin`。`<ASSIGNED_TO>` 取 `az account show --query user.name -o tsv`。
4. 从 `agents.default.metadata.ado_repo_local_path` 读取 `<REPO_PATH>`；缺失时按 Societas repo setup 流程让用户确认一次并持久化，不能创建一个以后还会反复问路径的 watcher。
5. 存在就先 `cron(action='remove', job_id='{_SCANNER_CRON_NAME}')`，再执行 `cron(action='add', job_id='{_SCANNER_CRON_NAME}', schedule='{_SCANNER_CRON_SCHEDULE}', tool='{_SCANNER_TOOL_NAME}', tool_args={{'bug_query_source':'<BUG_SOURCE>','org_url':'<ORG_URL>','project':'<PROJECT>','repository':'Societas','assigned_to':'<ASSIGNED_TO>','repo_path':'<REPO_PATH>'}}, notify_channels=['cloud'])`。
6. **建完自检（必做，别跳）**：`cron(action='info', job_id='{_SCANNER_CRON_NAME}')` 读回来，核对名字、`{_SCANNER_CRON_SCHEDULE}` schedule、Mode 是 `tool`、Tool 是 `{_SCANNER_TOOL_NAME}`，且 Arguments 六项都与第 5 步一致。任一项对不上就删掉重来，核对通过后把实际值回给用户。
这条提示会一直出现，直到系统真的看到一个合规的 watcher 为止。
---"""


def _pr_watcher_repair_directive(problem: str) -> str:
    """Directive shown when the PraestoClaw PR watcher is missing or misconfigured.

    Deliberately NOT an onboarding offer. The Societas recipe asks first with an
    imBack card because its user may not know a watcher exists; this workflow's
    user is the person who wrote it, and installing a cron is one sentence. What
    carries over is only the half that does not depend on who the user is: a
    watcher installed WRONG is invisible — it exists, it runs, and it silently
    cannot do its job, which is how one machine kept a daily read-only triage cron
    where a */30 deterministic job was supposed to be.
    """
    spec = _PRAESTOCLAW_WATCHER
    args = ", ".join(f"'{key}':'<{key.upper()}>'" for key in spec.required_args)
    return f"""

---
【PR watcher 需要修】{problem}

没有它，这条 workflow 开出的 PR 不会有人盯：CI 红了、Copilot 留了 comment，都要等你自己想起来看。请在**这一轮**修好：
1. `cron(action='info', job_id='{spec.cron_name}')` 看看现在是什么（不存在就跳过）。
2. `<REPO_SLUG>` 用 `gim-home/PraestoClaw`；`<AUTHOR>` 取 `gh api user --jq .login`；`<BRANCH_PREFIX>` 是这条 workflow 建分支用的前缀（`user/<用户名>/`）；`<WORKFLOW_NAME>` 是 `{_PRAESTOCLAW_WATCHER_RECIPE}`。
3. 存在就先 `cron(action='remove', job_id='{spec.cron_name}')`，再执行 `cron(action='add', job_id='{spec.cron_name}', schedule='{spec.schedule}', tool='{spec.tool_name}', tool_args={{{args}}})`。这是确定性 tool-mode job，不运行 LLM prompt。
4. **建完自检（必做，别跳）**：`cron(action='info', job_id='{spec.cron_name}')` 读回来，核对名字、`{spec.schedule}` schedule、Mode 是 `tool`、Tool 是 `{spec.tool_name}`，且 Arguments 四项都与第 3 步一致。任一项对不上就删掉重来，核对通过后把实际值回给用户。
这条提示会一直出现，直到系统真的看到一个合规的 watcher 为止。
---"""


_SOCIETAS_REPO_PATH_KEY = "ado_repo_local_path"
_SOCIETAS_SETUP_DIRECTIVE = """▶ 没有启动 —— 这台机器还没配 Societas 仓库路径。

---
【一次性设置】`fix-societas-bug` 需要本地 Societas 检出的绝对路径。本次调用没传 `repo_path`，`agents.default.metadata.ado_repo_local_path` 也是空的，所以**没有启动后台任务**（启动了也会在第 1 步停住）。请在**这一轮**处理，然后重跑 workflow：

1. **先搜**：用一条 `shell` 命令做**有界**搜索（深度 ≤3，别全盘扫）。**先判断当前 shell**，用对应那条：
   - POSIX：`find ~ ~/src ~/repos ~/code ~/edge ~/work -maxdepth 3 -type d -iname '*societas*' -not -path '*/node_modules/*' 2>/dev/null | head -20`（`find` 本来就收多个根，不存在的根由 `2>/dev/null` 吞掉，所以不需要 `for` 循环——少两个语句分隔符）
   - PowerShell：`Get-ChildItem -Path "$HOME","$HOME\\src","$HOME\\repos","$HOME\\code","$HOME\\edge","$HOME\\work" -Directory -Recurse -Depth 3 -Filter '*societas*' -ErrorAction SilentlyContinue | Where-Object { $_.FullName -notmatch 'node_modules' } | Select-Object -First 20 -ExpandProperty FullName`（`-ErrorAction SilentlyContinue` 已经处理不存在的根，所以不需要先做一次 `$roots` 赋值——少一个语句分隔符）
2. **必须校验，不能猜**：对每个候选跑 `git -C "<候选>" remote get-url origin`。只保留**确实是 git 仓库、且 remote 指向 ADO**（含 `dev.azure.com` 或 `visualstudio.com`）的。这个 workflow 会 commit / push / 开 PR，**选错仓库后果严重**，所以宁可问用户也不要猜。
3. **恰好 1 个**命中 → 用 `notify` 发一张 imBack 卡片请用户确认：`content` 里写出**完整路径和它的 remote URL**，`action_label`=`✅ 就是它`，`action_value`=`确认用 "<完整路径>" 修 Societas bug "<原来的 bug_id>"`。（`notify` 只支持**一个**按钮；用户也可以直接回一个别的路径。）按钮值必须保持这条请求自包含：点击会开启一个新的聊天 turn，所以要同时带上路径、Societas bug 主题和 bug id。
4. **0 个或多个**命中 → 直接问用户要路径（把找到的候选列出来供参考），别自己挑。
5. **拿到用户确认的路径后**：再跑一次第 2 步的校验，然后
   `config_praestoclaw(action='patch', path='agents.default.metadata.ado_repo_local_path', value='<绝对路径>')` 存下来（用户**不需要**手动改任何 yml）。
6. 顺带把 remote URL 解析出的 org / project 一并存进 `ado_org_url` / `ado_project`（能解析出来就存，解析不出别硬凑）。
7. **重跑时必须显式带上路径**：
   `workflow(action='run', name='fix-societas-bug', params={'bug_id': '<原来的 bug_id>', 'repo_path': '<绝对路径>'})`
   —— 第 5 步的 `patch` 只写进 yml，**要下次重启才会进内存**，所以本次重跑不带 `repo_path` 会再次撞到这条提示。存配置是为了以后不用再问，本次靠显式参数。
---"""


_SCANNER_SETUP_DIRECTIVE = f"""

---
【Societas scanner 安装】用户已经点了【帮我建】并同意创建常驻扫描 cron。按以下步骤安装，不要再发确认卡，也不要启动 `fix-societas-bug` workflow：
1. 用 `config_praestoclaw` 读 `agents.default.metadata` 的 `ado_bug_query` / `ado_org_url` / `ado_project`（org / project 缺了就问用户，别猜）。`ado_bug_query` 优先让用户提供 ADO saved-query URL / GUID；若没配，明确问用户是要提供 query，还是使用内置的「当前项目、Assigned To = @Me、Bug、非终态」基线，别替用户静默选范围。
2. 把 query 规范化成 `<BUG_SOURCE>`：saved-query URL/GUID → `saved:<GUID>`，原始 WIQL → `wiql:<原文>`，用户明确选择内置基线 → `builtin`。`<ASSIGNED_TO>` 取 `az account show --query user.name -o tsv`。
3. 从 `agents.default.metadata.ado_repo_local_path` 读取 `<REPO_PATH>`；缺失就让用户确认并持久化一次。
4. `cron(action='add', job_id='{_SCANNER_CRON_NAME}', schedule='{_SCANNER_CRON_SCHEDULE}', tool='{_SCANNER_TOOL_NAME}', tool_args={{'bug_query_source':'<BUG_SOURCE>','org_url':'<ORG_URL>','project':'<PROJECT>','repository':'Societas','assigned_to':'<ASSIGNED_TO>','repo_path':'<REPO_PATH>'}}, notify_channels=['cloud'])` 建 cron（**是 `job_id` 不是 `name`**）。这是确定性 tool-mode job，不运行 LLM prompt。
5. **建完自检（必做，别跳）**：`cron(action='info', job_id='{_SCANNER_CRON_NAME}')` 读回来，逐项核对：名字是 `{_SCANNER_CRON_NAME}`、schedule 是 `{_SCANNER_CRON_SCHEDULE}`、Mode 是 `tool`、Tool 是 `{_SCANNER_TOOL_NAME}`，且 Arguments 六项与第 4 步一致。**任何一项对不上就 `cron(action='remove', ...)` 删掉重来**，别将就。核对通过后，把实际值一起回给用户再收尾。
用户回「不用」或忽略就什么都不建（这个提议只出现这一次，之后不会再问）。
---"""


_SCANNER_ONBOARDING_DIRECTIVE = (
    f"""

---
【首次使用 · 一次性提议】这是用户**第一次**跑 `fix-societas-bug`，且还没有 Societas 扫描 cron。请在你**这一轮回复**里用 `notify` 发一张 **imBack 卡片**征询是否帮建一个常驻扫描 cron（先别自己建，等用户点/回话）：
- `notify`：`content`=`🔭 要不要帮你建个常驻 cron？每 30 分钟扫你新增的 bug + 盯你开的 draft/active PR 的 CI/comment，卡住了提醒你一键迭代到 ready。不想建就忽略这条、或回一句「不用」。`，`action_label`=`🔭 帮我建`，`action_value`=`{SCANNER_SETUP_COMMAND}`。（`notify` 只支持**一个**按钮，所以「不用」不做按钮——忽略或回「不用」即可；反正这个提议只出现这一次。）发完本轮即止。

**用户点【帮我建】后**，新 turn 会通过 `workflow(action='setup', name='{_SCANNER_ONBOARDING_RECIPE}')` 重新取得确定性安装指令。
---
"""
    + _SCANNER_SETUP_DIRECTIVE
)


def _societas_setup_directive(bug_id: Any) -> str:
    """Render the setup handoff with the current run's bug id.

    The confirmation button starts a fresh Teams turn, so its human-readable
    message must carry the subject, bug id, and path without relying on the
    setup worker's unavailable context.
    """
    # Both replacements intentionally use a JSON (double-quoted) string literal.
    # Step 7 otherwise uses single quotes, but wrapping ``bug_id`` that way would
    # let an ID containing a quote escape the tool-call example. Do not "normalize"
    # this to an f-string; see test_setup_directive_quotes_bug_id_in_every_context.
    bug_id_literal = json.dumps(str(bug_id or ""), ensure_ascii=False)
    return _SOCIETAS_SETUP_DIRECTIVE.replace('"<原来的 bug_id>"', bug_id_literal).replace(
        "'<原来的 bug_id>'", bug_id_literal
    )


# Accepted parameter types (advisory + light run-time validation); anything else
# is normalized to "string" at save time.
_PARAM_TYPES = frozenset({"string", "integer", "int", "float", "number", "boolean", "select"})
# Aliases normalized to canonical types at save time so recipe files are
# consistent with the schema/docs ("integer"/"float", not "int"/"number").
_PARAM_TYPE_CANON = {"int": "integer", "number": "float"}

# Windows reserved device names — a file whose stem is one of these cannot be
# created on Windows (e.g. "con.md" fails / opens the console device). The slug
# is the filename stem, so guard against a user naming a workflow "con"/"nul"/
# "com1" etc. Compared case-insensitively.

BackgroundFn = Callable[..., Awaitable[tuple[str | None, str]]]

# Channel names accepted for a scheduled workflow's result delivery (ordered for
# display). The scheduler coerces unknown names via ChannelType.of(...), which
# silently maps a typo to the internal fallback — so validate here and reject unknowns before
# scheduling. Mirrors the ChannelType values the scheduler can deliver to.
_NOTIFY_CHANNELS = ("cloud", "web", "*")
_VALID_NOTIFY_CHANNELS = frozenset(_NOTIFY_CHANNELS)
_NOTIFY_CHANNELS_HELP = ", ".join(_NOTIFY_CHANNELS)


def _normalize_limits(raw: Any) -> dict[str, Any]:
    """Normalize a recipe's ``limits:`` mapping into ``workflow_*`` metadata keys.

    Drops anything invalid (non-positive/uncoercible ints, non-string tools, wrong
    types) — a dropped limit means "no cap for that dimension", never an error, and
    can never *widen* the harness/global caps. Returns only the keys that are set,
    so a recipe with no valid limits injects nothing. ``allowed_tools`` is an
    ALLOWLIST (intersected into the spawned run's tool palette / turned into the
    scheduler's exclude-list downstream, never a grant); the ``max_*`` caps are only
    ever tightened, never loosened, downstream.

    NOTE: ``max_iterations`` is intentionally NOT emitted here — bounding a run's
    iteration budget is the one cap that must touch the shared per-conversation loop
    (``_setup``'s ``IterationBudget``), so it's deferred to a follow-up to keep this
    change out of the core loop. It's still accepted in frontmatter (parsed into
    ``Skill.limits``) but currently unenforced.
    """
    out: dict[str, Any] = {}
    if not isinstance(raw, dict):
        return out
    tools = raw.get("allowed_tools")
    if isinstance(tools, list):
        cleaned = [s.strip() for s in tools if isinstance(s, str) and s.strip()]
        if cleaned:
            out["workflow_allowed_tools"] = cleaned
    # ``denied_commands`` is the argument-level counterpart to ``allowed_tools``:
    # regexes matched against a shell command inside this recipe's own runs, by
    # hooks/handlers.py::WorkflowCommandDenylist. Patterns are compiled HERE so an
    # unusable one is dropped like any other invalid limit, which in turn lets the
    # hook treat a re.error at match time as tampering and fail closed.
    denied = raw.get("denied_commands")
    if isinstance(denied, list):
        patterns: list[str] = []
        for entry in denied:
            if not isinstance(entry, str) or not entry.strip():
                continue
            candidate = entry.strip()
            try:
                re.compile(candidate)
            except re.error as exc:
                logger.warning(
                    "workflow limits.denied_commands: dropping unusable pattern {!r} ({})",
                    candidate,
                    exc,
                )
                continue
            patterns.append(candidate)
        if patterns:
            out["workflow_denied_commands"] = patterns
    for src, dst in (
        ("max_runtime", "workflow_max_runtime"),
        ("max_output", "workflow_max_output"),
    ):
        n = positive_int(raw.get(src))
        if n is not None:
            out[dst] = n
    return out


_warned_concurrency: set[str] = set()


def _warn_once(message: str) -> None:
    """Log a misconfiguration warning once per process.

    ``_normalize_concurrency`` runs on every run/resume, not at load time, so a
    bad recipe would otherwise re-log on each invocation.
    """
    if message in _warned_concurrency:
        return
    _warned_concurrency.add(message)
    logger.warning(message)


def _normalize_concurrency(
    raw: Any, parameter_specs: list[dict[str, Any]] | None, workflow: str = ""
) -> tuple[int, list[str]] | None:
    """Return a valid instance limit and its parameter grouping."""
    if not isinstance(raw, dict):
        return None
    # Same coercion the consumer (``BackgroundTaskManager.start``) applies, so a
    # recipe can't be accepted by one side and dropped by the other.
    raw_max = raw.get("max_instances")
    max_instances = positive_int(raw_max)
    if max_instances is None:
        # No usable ceiling → the gate stays inert. Say so when the recipe looks
        # like it meant to limit something, otherwise the misconfig is silent.
        if raw.get("key_parameters") or raw_max is not None:
            _warn_once(
                f"Workflow {workflow!r} declares concurrency without a valid positive integer "
                f"'max_instances' ({raw_max!r}); instance limiting is disabled."
            )
        return None
    declared = {
        str(spec.get("name") or "").strip()
        for spec in parameter_specs or []
        if isinstance(spec, dict) and str(spec.get("name") or "").strip()
    }
    raw_keys = raw.get("key_parameters")
    requested = (
        [key.strip() for key in raw_keys if isinstance(key, str) and key.strip()]
        if isinstance(raw_keys, list)
        else []
    )
    key_parameters = list(dict.fromkeys(key for key in requested if key in declared))
    ignored = sorted(set(requested) - declared)
    if ignored:
        _warn_once(
            f"Workflow {workflow!r}: ignoring undeclared concurrency key parameter(s): "
            f"{', '.join(ignored)}."
        )
    return max_instances, key_parameters


def _workflow_instance_key(workflow: str, params: dict[str, str], key_parameters: list[str]) -> str:
    if not key_parameters:
        return workflow
    # ``key_parameters`` is already deduped by _normalize_concurrency; sort_keys
    # is what makes the encoding order-independent.
    selected = {key: params[key] for key in key_parameters if key in params}
    return f"{workflow}\0{json.dumps(selected, ensure_ascii=False, sort_keys=True, separators=(',', ':'))}"


def _inject_concurrency_metadata(
    metadata: dict[str, Any], recipe: Skill, workflow: str, params: dict[str, str]
) -> None:
    """Set (or clear) the instance-limit gate keys from the recipe's own config.

    The pops matter: ``metadata`` may carry the *caller's* gate keys, and an
    inherited one would group this run with an unrelated workflow instance.
    """
    metadata.pop("workflow_max_instances", None)
    metadata.pop("workflow_instance_key", None)
    concurrency = _normalize_concurrency(recipe.concurrency, recipe.parameters, workflow)
    if concurrency is None:
        return
    max_instances, key_parameters = concurrency
    metadata["workflow_max_instances"] = max_instances
    metadata["workflow_instance_key"] = _workflow_instance_key(workflow, params, key_parameters)


def _start_failure(name: str, verb: str, message: str) -> str:
    """Render a ``start()`` refusal for ``run``/``resume``.

    Hitting the recipe's own instance limit is a neutral outcome — the message
    already names the running task_id, so pass it through. Every other refusal
    (shutdown / capacity) is an error: don't claim the workflow is running.
    """
    if is_instance_limit_message(message):
        return message
    return f"Workflow {name!r} could not {verb}: {message}"


def intersect_allowed_tools(scoped_tools: list[str], metadata: dict[str, Any] | None) -> list[str]:
    """Task 9: narrow a spawned run's tool list to a workflow recipe's allowlist.

    Returns ``scoped_tools`` intersected with ``metadata['workflow_allowed_tools']``
    when that (non-empty) allowlist is present, else ``scoped_tools`` unchanged
    (inert for every non-workflow spawn). Only ever REMOVES — never grants a tool
    the agent's palette doesn't already contain. Used by ``runtime._spawn_agent``.
    """
    allow = (metadata or {}).get("workflow_allowed_tools")
    if isinstance(allow, list) and allow:
        return [t for t in scoped_tools if t in allow]
    return scoped_tools


def _workflow_owner_session(kwargs: dict[str, Any]) -> str:
    """Return the concrete caller session used for task control and fallback Plan scope."""
    # Strip BEFORE the `or` fallthrough: a whitespace-only _plan_session_id is truthy
    # yet strips to "", so `(a or b).strip()` would wrongly drop a valid _session_id
    # and leave the run unowned (breaking status/resume scoping).
    plan_sid = str(kwargs.get("_plan_session_id") or "").strip()
    return plan_sid or str(kwargs.get("_session_id") or "").strip()


def _workflow_plan_owner(kwargs: dict[str, Any]) -> str:
    """Return the concrete caller session that owns workflow Plans."""
    return _workflow_owner_session(kwargs)


def _is_bundled(user_dir: Path, recipe: Any) -> bool:
    """Whether *recipe* was loaded from this package rather than *user_dir*.

    A user recipe may override a bundled one under the same name (``_load_recipes``:
    user overrides bundled), so the name alone cannot identify the bundled recipe.
    Neither can its parameter names — those describe inputs, not capabilities, so a
    remote-only override could legitimately declare ``repo_path`` as a report
    location. ``_load_recipes_with_source`` applies the same precedence and records
    which directory won, which is the only thing that actually answers this.

    Not ``Skill.source_path`` (only the SkillLoader populates it; ``parse_skill_file``
    leaves it "") and not ``Skill.source_tier`` (a plain default of "bundled", so a
    user override reports "bundled" too).

    Conservative on error: anything unreadable reads as "not bundled", so behaviour
    reserved for the shipped recipe is never applied to an unknown one.
    """
    name = str(getattr(recipe, "name", "") or "")
    if not name:
        return False
    try:
        entry = _load_recipes_with_source(user_dir).get(name)
    except Exception:  # noqa: BLE001 - identity check is best-effort
        return False
    return entry is not None and entry[1] == "bundled"


def _load_recipes(user_dir: Path) -> dict[str, Skill]:
    """Recipe name -> Skill, from bundled dir + user dir (user overrides bundled)."""
    recipes: dict[str, Skill] = {}
    for d in (_BUNDLED_DIR, user_dir):
        if not d.is_dir():
            continue
        for md in sorted(d.glob("*.md")):
            skill = parse_skill_file(md)
            if skill and skill.name:
                recipes[skill.name] = skill
    return recipes


def _load_recipes_with_source(user_dir: Path) -> dict[str, tuple[Skill, str]]:
    """Recipe name -> (Skill, source) where source is ``"bundled"`` or ``"user"``.

    Same precedence as :func:`_load_recipes` (user overrides bundled), recording
    which dir each surviving name came from so ``list`` can show provenance. One
    pass, so ``_list`` doesn't parse every recipe twice.
    """
    out: dict[str, tuple[Skill, str]] = {}
    for source, d in (("bundled", _BUNDLED_DIR), ("user", user_dir)):
        if not d.is_dir():
            continue
        for md in sorted(d.glob("*.md")):
            skill = parse_skill_file(md)
            if skill and skill.name:
                out[skill.name] = (skill, source)
    return out


def _make_cached_recipe_loader(workflow_dir: Path) -> Callable[[], dict[str, Skill]]:
    """A cached ``_load_recipes(workflow_dir)`` behind a cheap stat-only fingerprint
    (path + mtime + size of every recipe file). Re-parses only when a file is
    added / removed / edited, so recipe edits still take effect at the next call
    (freshness preserved) without paying the YAML-parse cost when nothing changed.
    Each caller gets its OWN cache — the body and limits scheduler resolvers build
    one each, so a fire re-parses at most once per resolver (not a single shared
    cache), which keeps steady-state fires parse-free.
    """
    cache: dict[str, Any] = {"fingerprint": None, "recipes": {}}

    def _fingerprint() -> tuple[tuple[str, int, int], ...]:
        entries: list[tuple[str, int, int]] = []
        for d in (_BUNDLED_DIR, workflow_dir):
            if not d.is_dir():
                continue
            for md in sorted(d.glob("*.md")):
                try:
                    st = md.stat()
                except OSError:
                    continue  # racing delete — treat as absent this fire
                entries.append((str(md), st.st_mtime_ns, st.st_size))
        return tuple(entries)

    def _load() -> dict[str, Skill]:
        fp = _fingerprint()
        if fp != cache["fingerprint"]:
            cache["recipes"] = _load_recipes(workflow_dir)
            cache["fingerprint"] = fp
        return cache["recipes"]  # type: ignore[no-any-return]

    return _load


def make_recipe_loader(workflow_dir: Path) -> Callable[[], dict[str, Skill]]:
    """Public factory: a cached ``{name: recipe}`` loader over ``workflow_dir``
    (user overrides bundled), refreshed on a cheap stat fingerprint. Used by the
    workflow auto-suggest hook so it re-parses recipes only when they change.
    Wraps the internal cached loader so callers don't depend on a private symbol.
    """
    return _make_cached_recipe_loader(workflow_dir)


def make_recipe_resolver(workflow_dir: Path) -> Callable[[str], str | None]:
    """Public factory: a resolver mapping a recipe name to its current body.

    The scheduler calls this at each fire so a scheduled workflow always runs the
    latest recipe. Returns ``None`` when the recipe no longer exists (the scheduler
    then raises → user notified, job auto-disables). Exposed so runtime wires the
    scheduler without reaching into a private helper.

    Resolves via ``_load_recipes`` (user-overrides-bundled, deduped by frontmatter
    name) and matches on the CANONICAL (whitespace-collapsed) id — schedule stores
    the canonical name and run/status/resume all key off it, so a recipe whose
    frontmatter name has irregular whitespace still fires. **Raises** ``ValueError``
    when 2+ distinct recipe names collapse to the same canonical id — same
    ambiguity refusal as run/resume/schedule, so a scheduled fire never silently
    runs the wrong body (the scheduler routes the raise to its error handler).

    Detecting ambiguity requires scanning ALL recipes (can't early-exit on the
    first match), so the parse is cached behind a stat fingerprint (see
    ``_make_cached_recipe_loader``) — no re-parse when nothing changed.
    """
    load = _make_cached_recipe_loader(workflow_dir)

    def _resolve(name: str) -> str | None:
        canonical = " ".join(str(name or "").split())
        matches = [s for k, s in load().items() if " ".join(k.split()) == canonical]
        if len(matches) > 1:
            raise ValueError(
                f"{len(matches)} recipes collapse to the canonical id {canonical!r} "
                "(whitespace-ambiguous) — rename them to distinct ids to disambiguate."
            )
        return matches[0].content if matches else None

    return _resolve


def make_limits_resolver(workflow_dir: Path) -> Callable[[str], dict[str, Any]]:
    """Public factory: resolve a recipe's normalized capability limits (Task 9).

    Returns the ``workflow_*`` metadata dict (allowed_tools / max_runtime /
    max_output — ``max_iterations`` is intentionally NOT emitted, see
    ``_normalize_limits``) for a recipe name, or ``{}`` when it declares none
    / doesn't exist / is whitespace-ambiguous. The scheduler consults this at each
    fire so a scheduled run is bounded by the recipe's *current* limits — the same
    caps an on-demand run gets. Matched on the canonical id like run/status/resume.
    Caches parsed recipes behind its own stat fingerprint (like the body resolver),
    so a steady-state fire re-parses nothing.
    """
    load = _make_cached_recipe_loader(workflow_dir)

    def _resolve(name: str) -> dict[str, Any]:
        canonical = " ".join(str(name or "").split())
        matches = [s for k, s in load().items() if " ".join(k.split()) == canonical]
        if len(matches) != 1:  # 0 = gone, 2+ = ambiguous (body resolver refuses too)
            return {}
        return _normalize_limits(getattr(matches[0], "limits", None))

    return _resolve


def _plan_preamble(name: str) -> str:
    """Preamble that makes a ``plan: true`` recipe run as a tracked Plan.

    Prepended to the recipe body at run time (see ``_run``). It steers the
    spawned single-agent run to create + drive a persisted plan (keyed to its
    own forked session id, ``workflow=<name>``) so the run has visible steps,
    per-step verification, optional HITL gates, and an audit file that survives
    restart — all through the existing ``plan`` tool, no new engine. Guidance,
    not enforcement: the agent still derives the concrete steps from the body.
    """
    # The recipe name is interpolated into the example call. Names are slugs in
    # practice (``add`` enforces ``[a-z0-9-]``) but a hand-authored recipe could
    # carry quotes/newlines, which would break a single-quoted literal. Use a
    # collapsed name for the bold header and a JSON literal (quote/newline-safe)
    # for the ``workflow=`` example value.
    display = " ".join(str(name).split()) or name
    workflow_lit = json.dumps(name)
    return (
        f"🧭 You are running the reusable workflow **{display}** as a tracked plan.\n\n"
        f"STEP 1 — Before doing any work, call "
        f"plan(action='create', workflow={workflow_lit}, items=[...]) to break the "
        "steps below into ordered items. Give each item a short `acceptance` "
        "(how you'll know it's done) and, where a step can be objectively "
        "verified, a `check` shell command.\n\n"
        "STEP 2 — Work through the plan one item at a time: call "
        "plan(action='update', id=<n>, status='in_progress') before starting an "
        "item, then after finishing it run its `check` (if any) and call "
        "plan(action='update', id=<n>, status='done', evidence=<result>). If an "
        "item needs the user's go-ahead before proceeding, use "
        "plan(action='checkpoint', ask_user=true).\n\n"
        "STEP 3 — When every item is done, give your final answer with the "
        "actual result the user asked for.\n\n"
        "--- workflow steps ---\n"
    )


def _resume_preamble(name: str, plan: Any, *, checkpoint_approved: bool = False) -> str:
    """Preamble for ``resume``: carry the interrupted plan's state + safety rules.

    A previous run-as-Plan run was interrupted (crash/restart) with its plan
    partly done. This tells the resuming agent what was already completed (so it
    does NOT redo it — the work + side effects already happened) and to plan +
    continue the remaining steps. An ``in_progress`` step gets an explicit
    idempotency warning (verify / checkpoint before redoing a side-effecting
    step) — resume never blindly re-runs.
    """
    try:
        done, total = plan.progress
    except Exception:  # noqa: BLE001
        done, total = 0, 0
    items = getattr(plan, "items", []) or []
    rows: list[str] = []
    has_in_progress = False
    for i, it in enumerate(items, 1):
        st = str(getattr(it, "status", "") or "")
        if st == "in_progress":
            has_in_progress = True
        mark = "✓" if st in ("done", "skipped") else ("▶" if st == "in_progress" else "☐")
        title = " ".join(str(getattr(it, "title", "")).split())[:120]
        rows.append(f"  {i}. [{mark}] {title}")
    rendered = "\n".join(rows) if rows else "  (no recorded steps)"
    display = " ".join(str(name).split()) or name
    wf_lit = json.dumps(name)
    warn = (
        "\n\n⚠️ A step above is [▶] in_progress — its **side effects may be PARTIAL** "
        "(e.g. an email or PR half-done). VERIFY the real state before redoing it, and "
        "use plan(action='checkpoint', ask_user=true) if you're unsure. Never blindly "
        "re-run a side-effecting step."
        if has_in_progress
        else ""
    )
    approval = (
        "\n\n✅ The user explicitly approved the latest waiting checkpoint when "
        "starting this resume. That approval applies only to the checkpoint's "
        "recorded next_step; verify current external state, then perform it without "
        "asking for the same approval again."
        if checkpoint_approved and plan_waiting_for_approval(plan)
        else ""
    )
    return (
        f"🔄 You are RESUMING the workflow **{display}** — a previous run was interrupted "
        f"(crash/restart) with {done}/{total} steps done:\n{rendered}\n\n"
        "Continue from the first UNFINISHED step. Do NOT redo any [✓] step — its work "
        f"already happened. Make a fresh plan(action='create', workflow={wf_lit}) for the "
        f"REMAINING steps only and work through them.{warn}{approval}\n\n"
        "--- workflow steps (for reference) ---\n"
    )


def _normalize_params(raw: Any) -> dict[str, str]:
    """Coerce resolved parameters into a bounded ``{name: value}`` for persistence.

    Used for the ``workflow_params`` metadata that ``run``/``resume`` carry into a
    background run (from which ``plan(create)`` persists it onto the Plan, so a
    later ``resume`` can restore it) and for reading those values back off an
    interrupted run's plan.

    Deliberately permissive about the VALUE: it only has to be a non-empty string,
    because the strict single-token rule belongs at command-RENDERING time, where
    ``background_tasks._workflow_command`` already applies it. Filtering here too
    would silently drop e.g. a Windows checkout path with a space from the
    persisted params — the very thing resume needs in order to restore the run.
    The NAME is still gated: it doubles as a ``{name}`` placeholder.
    """
    if not isinstance(raw, dict):
        return {}
    out: dict[str, str] = {}
    for key, value in raw.items():
        if len(out) >= _MAX_PARAMS:
            break
        name = str(key)
        if not _PARAM_NAME_RE.match(name) or value is None:
            continue
        text = str(value).strip()[:_MAX_PARAM_VALUE_LEN]
        if not text:
            continue
        out[name] = text
    return out


def _coerce_params_arg(provided: Any) -> dict[str, Any]:
    """Coerce a caller-supplied ``params`` argument into a plain dict.

    ``provided`` may be a dict or a JSON object string (LLMs sometimes stringify
    the arg). Anything else — including a JSON scalar/array — yields ``{}``.
    Split out of ``_resolve_params`` so ``resume`` can merge the persisted params
    underneath the caller's using the exact same decoding rules.
    """
    if isinstance(provided, str):
        try:
            provided = json.loads(provided)
        except (ValueError, TypeError):
            return {}
    return dict(provided) if isinstance(provided, dict) else {}


def _resolve_params(
    specs: list[dict[str, Any]] | None, provided: Any
) -> tuple[dict[str, str], list[str]]:
    """Resolve a recipe's declared parameters to string substitution values.

    Returns ``(name -> str value, errors)``. For each declared param the value
    is ``provided[name]`` if given (and non-null), else its ``default``, else
    "" for optional / an error for ``required``. Light validation: an
    ``integer``/``float`` value must coerce; a ``select`` value must be in
    ``options``. Values are stringified for **plain-text** substitution — there
    is no template engine (the Societas SSTI→RCE lesson, §1.8). ``provided`` may
    be a dict or a JSON object string (LLMs sometimes stringify the arg).
    """
    provided = _coerce_params_arg(provided)
    if not specs:
        # A recipe that declares nothing reads nothing, so anything supplied is
        # dropped. Returning silently is the same failure this function exists
        # to stop, one level up: the caller is told the run started and its
        # arguments were never seen.
        extra = sorted({str(k).strip() for k in provided} - {""})
        if extra:
            return {}, [
                f"this recipe declares no parameters, so {', '.join(repr(x) for x in extra)} "
                f"would be ignored -- drop them, or declare them in the recipe"
            ]
        return {}, []
    values: dict[str, str] = {}
    errors: list[str] = []
    declared = list(
        dict.fromkeys(d for d in (str(sp.get("name") or "").strip() for sp in specs) if d)
    )
    # Compare AND look up on the stripped key. Comparing stripped while reading
    # the raw key let `{"feature_id ": "7752874"}` pass the unknown check (it
    # strips to a declared name) and then miss the lookup, so the value vanished
    # exactly as an undeclared name used to -- and the group error then said
    # "none was supplied" about a call that had supplied one.
    normalized: dict[str, Any] = {}
    for key, val in provided.items():
        k = str(key).strip()
        if k in normalized and normalized[k] != val:
            errors.append(
                f"parameter {k!r} was given twice with different values -- "
                f"check for a stray space in one of the keys"
            )
            continue
        normalized[k] = val
    provided = normalized
    # A supplied name that matches nothing used to be dropped in silence: the
    # loop below reads ``provided[name]`` for each DECLARED name and never asks
    # what the caller actually sent. A run once received the work item it needed
    # under the key ``work_item``, resolved every declared param to "", reported
    # no errors, and told the user it had started -- the value was in the call
    # the whole time. Say what arrived and what this recipe reads.
    unknown = [k for k in provided if k not in declared]
    if unknown:
        import difflib

        for key in sorted(str(k) for k in unknown):
            close = difflib.get_close_matches(key, declared, n=1, cutoff=0.6)
            hint = f"; did you mean {close[0]!r}?" if close else ""
            names = ", ".join(repr(d) for d in sorted(declared))
            errors.append(f"unknown parameter {key!r} -- this recipe reads {names}{hint}")
    for spec in specs:
        name = str(spec.get("name") or "").strip()
        if not name:
            continue
        ptype = str(spec.get("type") or "string").strip().lower()
        if name in provided and provided[name] is not None:
            raw: Any = provided[name]
        elif spec.get("default") is not None:
            raw = spec.get("default")
        elif _as_bool(spec.get("required")):
            errors.append(f"missing required parameter {name!r}")
            continue
        else:
            raw = ""
        if ptype in ("integer", "int"):
            text = str(raw).strip()
            try:
                int(text)
            except (ValueError, TypeError):
                errors.append(f"parameter {name!r} must be an integer (got {raw!r})")
                continue
            raw = text  # substitute the validated (stripped) form, not the raw
        elif ptype in ("float", "number"):
            text = str(raw).strip()
            try:
                float(text)
            except (ValueError, TypeError):
                errors.append(f"parameter {name!r} must be a number (got {raw!r})")
                continue
            raw = text
        elif ptype == "select":
            raw_opts = spec.get("options")
            # Guard: only a list of options gates the value — a scalar/str
            # ``options`` must NOT be char-iterated into per-character choices.
            options = [str(o) for o in raw_opts] if isinstance(raw_opts, list) else []
            if options and str(raw) not in options:
                errors.append(f"parameter {name!r} must be one of {options} (got {raw!r})")
                continue
        values[name] = str(raw)
    # ``required_group``: at least one member must carry a value. The spec format
    # has no way to say "exactly one of these", so recipes said it in prose and
    # let step 1 refuse the run -- ninety seconds and one "started successfully"
    # after the call that could have been rejected. Members stay individually
    # optional; the group is what is required.
    groups: dict[str, list[str]] = {}
    for spec in specs:
        gname = str(spec.get("required_group") or "").strip()
        pname = str(spec.get("name") or "").strip()
        if gname and pname and pname not in groups.setdefault(gname, []):
            groups[gname].append(pname)
    for gname, members in groups.items():
        if not any(values.get(m, "").strip() for m in members):
            # Quoted and deduplicated for the same reason the unknown-parameter
            # message is: this is a list of names the caller has to act on, and
            # a repeat reads as two things sharing one spelling.
            names = ", ".join(repr(m) for m in sorted(members))
            errors.append(f"one of {names} is required ({gname}) -- none was supplied")
    return values, errors


def _declared_param_names(recipe: Any) -> set[str]:
    """Parameter names a recipe declares.

    Both harness fills key on a LITERAL name and both are inert for a recipe that
    does not declare it, so they share this one question.
    """
    return {
        str(spec.get("name"))
        for spec in (getattr(recipe, "parameters", None) or [])
        if isinstance(spec, dict)
    }


async def _fill_agent_repo_path(recipe: Any, values: dict[str, Any]) -> None:
    """Resolve ``agent_repo_path`` in-process, where the import cannot fail.

    A recipe that needs the checkout of the agent's own source tree used to make
    the run discover it with ``python -c 'import praestoclaw…'`` in a shell. That
    depends on PATH: on this machine both ``python`` and ``python3`` resolve to a
    Homebrew interpreter with no ``praestoclaw`` installed, while the service runs
    from a virtualenv that has it. A run duly reported all resolution sources
    exhausted and stopped at step 1 — correctly, by its own rules, on a question
    the harness could answer for free.

    Only recipes that declare ``agent_repo_path`` are touched. Deliberately NOT
    ``repo_path``: ``fix-societas-bug`` uses that name for a *different*
    repository, and defaulting it here would silently point that workflow at the
    wrong checkout.

    Runs ``git`` off the event loop. The synchronous form this replaces would
    block every other coroutine for the duration — the same shape as the
    ``/api/status`` freeze that starved the gateway WebSocket, so it is not worth
    reintroducing for a call that already has a 10-second timeout.
    """
    names = _declared_param_names(recipe)
    if "agent_repo_path" not in names or str(values.get("agent_repo_path") or "").strip():
        return
    try:
        import praestoclaw as _pkg

        pkg_dir = Path(_pkg.__file__).resolve().parent
        root = await asyncio.to_thread(
            subprocess.run,
            ["git", "-C", str(pkg_dir), "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        resolved = root.stdout.strip()
        if root.returncode == 0 and resolved:
            values["agent_repo_path"] = resolved
    except Exception:  # pragma: no cover - a wheel install has no worktree
        # Leave it empty; the recipe still describes its own fallbacks and will
        # report an honest blocker rather than guessing a path.
        return


def _substitute_params(body: str, values: dict[str, str]) -> str:
    """Replace ``{name}`` with ``values[name]`` for declared names only.

    Plain-text, **single-pass** (a value that itself contains ``{other}`` is NOT
    re-expanded), and unknown ``{…}`` tokens are left verbatim (recipe prose /
    code samples must not be mangled). No template engine — SSTI-safe.
    """
    if not values:
        return body
    pattern = re.compile(r"\{(" + "|".join(re.escape(k) for k in values) + r")\}")
    return pattern.sub(lambda m: values[m.group(1)], body)


def _normalize_param_specs(raw: Any) -> tuple[list[dict[str, Any]] | None, str | None]:
    """Validate + normalize an ``add`` ``parameters`` arg for frontmatter.

    Returns ``(specs, error)``. ``specs`` is None when no parameters were given
    (nothing to write) or on error; ``error`` is a user-facing message when the
    input is malformed. Authoring is strict (so the agent can correct): the input
    must be a list of dicts, each with a ``{placeholder}``-safe ``name``; names
    must be unique; unknown ``type`` normalizes to ``string``; count is capped.
    Only meaningful keys are emitted (``name``/``type`` always; ``required`` when
    true; ``default`` when provided; ``options`` for a select with a list).
    """
    if raw is None:
        return None, None
    if not isinstance(raw, list):
        return None, "'parameters' must be a list of {name, type, required, default} objects."
    if len(raw) > _MAX_PARAMS:
        return None, f"too many parameters (max {_MAX_PARAMS})."
    specs: list[dict[str, Any]] = []
    seen: set[str] = set()
    for entry in raw:
        if not isinstance(entry, dict):
            return None, "each parameter must be an object with a 'name'."
        name = str(entry.get("name") or "").strip()
        if not name:
            return None, "each parameter needs a non-empty 'name'."
        if len(name) > _MAX_PARAM_NAME_LEN:
            return None, f"parameter name {name[:20]!r}… is too long (max {_MAX_PARAM_NAME_LEN})."
        if not _PARAM_NAME_RE.match(name):
            return None, (
                f"parameter name {name!r} is not valid — it must start with a letter "
                "or underscore, then letters/digits/underscores only "
                "(it becomes a {name} placeholder)."
            )
        if name in seen:
            return None, f"duplicate parameter name {name!r}."
        seen.add(name)
        ptype = str(entry.get("type") or "string").strip().lower()
        if ptype not in _PARAM_TYPES:
            ptype = "string"
        ptype = _PARAM_TYPE_CANON.get(ptype, ptype)  # int→integer, number→float
        spec: dict[str, Any] = {"name": name, "type": ptype}
        group = str(entry.get("required_group") or "").strip()
        if group:
            spec["required_group"] = group
        if _as_bool(entry.get("required")):
            spec["required"] = True
        if "default" in entry and entry.get("default") is not None:
            spec["default"] = entry.get("default")
        if ptype == "select":
            opts = entry.get("options")
            # A select with no usable options can't gate anything — reject at
            # save time rather than persist an un-enforced select.
            if not (isinstance(opts, list) and opts):
                return None, f"select parameter {name!r} needs a non-empty 'options' list."
            options = [str(o) for o in opts]
            spec["options"] = options
            # A default that isn't one of the options would make every run (incl.
            # unattended/scheduled) fail _resolve_params — catch it at save time.
            if "default" in spec and str(spec["default"]) not in options:
                return None, (
                    f"select parameter {name!r} default {spec['default']!r} "
                    f"must be one of {options}."
                )
        specs.append(spec)
    return (specs or None), None


class WorkflowTool(Tool):
    """List and run reusable single-agent workflow recipes (opt-in, flag-gated)."""

    def __init__(
        self,
        workflow_dir: Path,
        background_fn: BackgroundFn,
        scheduler: Any = None,
        inflight_fn: Any = None,
        active_plans_fn: Any = None,
        run_history_fn: Any = None,
        agent_metadata_fn: Any = None,
    ) -> None:
        self._dir = workflow_dir
        # Cached recipe loader (stat-fingerprint) for the hot `description`
        # property — it is read on every prompt / tool-schema build, so globbing
        # and YAML-parsing every recipe each time would be wasteful. Re-parses
        # only when a recipe file is added / removed / edited.
        self._recipe_loader = make_recipe_loader(workflow_dir)
        # Guard so a persistently-broken recipe dir logs its traceback at most once
        # per instance instead of on every `description` read (a hot prompt path).
        self._catalog_error_logged = False
        self._background_fn = background_fn
        # SchedulerService handle (duck-typed: add_job / remove_job / list_jobs).
        # None when the cron subsystem is disabled — schedule/unschedule then
        # return a clear error instead of silently doing nothing.
        self._scheduler = scheduler
        # Callable(*, owner) -> list of active workflow runs (BackgroundTaskManager.
        # list_workflow_runs) for the status "running now" view. None = no on-demand
        # run visibility (e.g. in tests / if not wired).
        self._inflight_fn = inflight_fn
        # Callable() -> list of active plan-like objects (PlanStore.list_active).
        # Used to show a run-as-Plan run's live step (第 K/M 步) in status,
        # correlated by plan.origin_task == run.task_id (6d-1). None = no step
        # enrichment (runs still show name + elapsed).
        self._active_plans_fn = active_plans_fn
        # Callable(recipe, limit) -> durable on-demand run records
        # (WorkflowRunStore.get_history) for `status name=<recipe>`. None = no
        # on-demand history section.
        self._run_history_fn = run_history_fn
        # Callable() -> the default agent's ``metadata`` dict (runtime config).
        # Read only to decide whether the Societas bug-fix recipe can resolve a
        # target checkout before we spawn anything. None = gate stays inert.
        self._agent_metadata_fn = agent_metadata_fn
        # In-process latch for the first-use scanner-cron offer: durable run
        # history only records on completion, so several rapid starts of the
        # bug-fix workflow before the first finishes would all see empty history.
        # This flips true the first time the directive is emitted so the offer
        # goes out at most once per runtime (best-effort, resets on restart —
        # by then a completed first run has populated the history anyway).
        self._scanner_onboarding_offered = False

    @property
    def name(self) -> str:
        return "workflow"

    @property
    def description(self) -> str:
        base = (
            "Manage and run reusable single-agent workflow recipes. "
            "action='list' shows available recipes (⏰ marks scheduled ones); "
            "action='run' name=<recipe> runs one in a fresh isolated background "
            "session (result posted back when done); pass params={..} to fill a "
            "parameterized recipe's inputs; "
            "action='add' name=.. description=.. body=.. saves a new recipe "
            "(compose the body as the step-by-step instructions the agent will follow; "
            "optionally parameters=[{name,type,required,default,options}] to declare {name} "
            "inputs the body uses); "
            "action='setup' name='fix-societas-bug' returns the deterministic "
            "Societas scanner installation handoff after its onboarding button; "
            "action='schedule' name=<recipe> schedule='0 9 * * *' runs a recipe "
            "automatically on a cron/interval schedule (result delivered to your "
            "active channels); action='unschedule' name=<recipe> stops it; "
            "action='status' shows scheduled workflows and their last/next run "
            "(add name=<recipe> for that one's recent run history), plus any "
            "interrupted runs; action='resume' name=<recipe> resumes an interrupted "
            "run from where it stopped (never redoes completed steps; the original "
            "run's params are restored automatically — only pass params={..} to "
            "OVERRIDE one)."
        )
        # Build the recipe-discovery catalog defensively: this property is read on
        # every prompt / tool-schema build (workflow ships enabled by default), so a
        # single malformed recipe file must never break prompt assembly — fall back
        # to the base description on any load/parse error.
        try:
            catalog: list[str] = []
            for recipe in self._recipe_loader().values():
                description = " ".join(recipe.description.split()).replace(". ", "; ").rstrip(".")
                required = [
                    str(spec.get("name"))
                    for spec in (recipe.parameters or [])
                    if _as_bool(spec.get("required")) and spec.get("default") is None
                ]
                suffix = f" [required: {', '.join(required)}]" if required else ""
                catalog.append(f"{recipe.name} ({description[:160]}{suffix})")
            discovery = " | ".join(catalog)[:2000]
        except Exception:  # noqa: BLE001 - discovery is best-effort; degrade to base
            if not self._catalog_error_logged:
                logger.opt(exception=True).debug("workflow: recipe-discovery catalog skipped")
                self._catalog_error_logged = True
            discovery = ""
        if not discovery:
            return base
        return f"Available workflows — run one when the user's request matches: {discovery}. {base}"

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": [
                        "list",
                        "run",
                        "setup",
                        "add",
                        "init_project",
                        "schedule",
                        "unschedule",
                        "status",
                        "resume",
                    ],
                },
                "name": {
                    "type": "string",
                    "description": (
                        "Recipe name (for 'run' / 'add' / 'schedule' / 'unschedule'; "
                        "optional for 'status' to see one workflow's run history)."
                    ),
                },
                "task_id": {
                    "type": "string",
                    "description": (
                        "For 'status' or 'resume': select one exact on-demand run "
                        "when several runs use the same recipe name."
                    ),
                },
                "approve_checkpoint": {
                    "type": "boolean",
                    "description": (
                        "For 'resume' only: set true when the user explicitly approves "
                        "the selected run's latest waiting checkpoint. Required for a "
                        "run in waiting_approval state."
                    ),
                },
                "description": {
                    "type": "string",
                    "description": "Short one-line description (for 'add').",
                },
                **workflow_profile.SCHEMA_PROPERTIES,
                "params": {
                    "type": "object",
                    "description": (
                        "For 'run': values for a parameterized recipe's declared "
                        "parameters, e.g. {'pr_number': 566}. A missing value falls "
                        "back to that parameter's default; a required parameter with "
                        "no default errors (the run does not start). For 'resume' this "
                        "is optional and only OVERRIDES: the interrupted run's own "
                        "params are restored from its plan automatically."
                    ),
                },
                "parameters": {
                    "type": "array",
                    "description": (
                        "For 'add': declare typed inputs the recipe body references as "
                        "{name} placeholders. Each: {name (must start with a letter or "
                        "underscore, then letters/digits/underscores), type "
                        "(string|integer|float|boolean|select), required (bool), "
                        "default, options (for select)}. Give a `default` to any param "
                        "the recipe should be schedulable with (unattended runs supply "
                        "no values)."
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "type": {
                                "type": "string",
                                "description": (
                                    "One of string|integer|float|boolean|select "
                                    "(aliases int/number accepted; anything "
                                    "unrecognized is treated as string)."
                                ),
                            },
                            "required": {"type": "boolean"},
                            "default": {},
                            "options": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["name"],
                    },
                },
                "replace": {
                    "type": "boolean",
                    "description": (
                        "For 'add': overwrite an existing recipe of the same name. For "
                        "'init_project': update an existing configuration, keeping any "
                        "notes in the file body."
                    ),
                },
                "schedule": {
                    "type": "string",
                    "description": (
                        "For 'schedule': cron expression (e.g. '0 9 * * *'), interval "
                        "seconds (e.g. '3600'), or a one-shot ('at:+300' / 'at:<ISO>')."
                    ),
                },
                "notify_channels": {
                    "anyOf": [
                        {"type": "string", "enum": list(_NOTIFY_CHANNELS)},
                        {
                            "type": "array",
                            "items": {"type": "string", "enum": list(_NOTIFY_CHANNELS)},
                        },
                    ],
                    "description": (
                        "For 'schedule': where to deliver the result — a single channel "
                        "name or a list (defaults to all active channels). Use '*' alone "
                        "for all active; don't combine '*' with specific channels."
                    ),
                },
            },
            "required": ["action"],
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(tier="standard")

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "")
        if action == "list":
            return self._list()
        if action == "run":
            return await self._run(kwargs)
        if action == "setup":
            return self._setup(kwargs)
        if action == "add":
            return self._add(kwargs)
        if action == "init_project":
            return self._init_project(kwargs)
        if action == "schedule":
            return self._schedule(kwargs)
        if action == "unschedule":
            return self._unschedule(kwargs)
        if action == "status":
            return self._status(kwargs)
        if action == "resume":
            return await self._resume(kwargs)
        return (
            f"Unknown action: {action!r}. "
            "Use 'list', 'run', 'setup', 'add', 'init_project', 'schedule', "
            "'unschedule', 'status', or 'resume'."
        )

    def _setup(self, kwargs: dict[str, Any]) -> str:
        """Return a deterministic fresh-turn setup handoff for a bundled recipe."""
        name = " ".join(str(kwargs.get("name") or "").split())[:_MAX_NAME_LEN]
        if name != _SCANNER_ONBOARDING_RECIPE:
            return "Error: setup is only supported for 'fix-societas-bug'."
        recipe = _load_recipes(self._dir).get(name)
        if recipe is None or not _is_bundled(self._dir, recipe):
            return "Error: scanner setup requires the bundled 'fix-societas-bug' recipe."
        return _SCANNER_SETUP_DIRECTIVE

    def _list(self) -> str:
        recipes = _load_recipes_with_source(self._dir)
        if not recipes:
            return f"No workflow recipes found. Add one to {self._dir}/*.md"
        scheduled = self._scheduled_map()
        lines = []
        for r, source in recipes.values():
            # _scheduled_map is keyed by the CANONICAL workflow_recipe id, so look
            # up the collapsed form of the (possibly irregular-whitespace)
            # frontmatter name — else the ⏰ suffix would be dropped for such a
            # recipe. Collapse is a no-op for normal slug names.
            sched = scheduled.get(" ".join(r.name.split()))
            suffix = f"  ⏰ {sched}" if sched else ""
            lines.append(f"- {r.name} [{source}]: {r.description}{suffix}")
        return "Available workflows:\n" + "\n".join(lines)

    def _scheduled_map(self) -> dict[str, Any]:
        """Canonical recipe id -> its schedule, for workflow-backed cron jobs.

        Keyed off each job's structured ``workflow_recipe`` field — NOT the job
        name — so a plain cron job that merely happens to be named ``wf-…`` can't
        be mis-annotated as a scheduled workflow. ``schedule`` stores the CANONICAL
        (whitespace-collapsed) id there, so callers must look up the collapsed
        recipe name (see ``_list``).
        """
        if self._scheduler is None:
            return {}
        try:
            jobs = self._scheduler.list_jobs()
        except Exception:  # noqa: BLE001 - listing is best-effort UI sugar
            return {}
        out: dict[str, Any] = {}
        for j in jobs:
            recipe = j.get("workflow_recipe")
            if recipe:
                out[recipe] = j.get("schedule")
        return out

    def _status(self, kwargs: dict[str, Any]) -> str:
        # Normalize the name to the canonical workflow id (collapse whitespace,
        # cap) — the SAME as run / resume / plan storage — so a `status
        # name=<recipe>` query resolves scheduler entries + on-demand history that
        # were recorded under the collapsed id.
        name = " ".join(str(kwargs.get("name") or "").split())[:200]
        task_id = str(kwargs.get("task_id") or "").strip()[:64]
        # Scheduled workflows (needs the scheduler); in-flight on-demand runs
        # are scheduler-independent, so status still works with cron off.
        wf_jobs: list[dict[str, Any]] = []
        sched_read_failed = False
        if self._scheduler is not None:
            try:
                jobs = self._scheduler.list_jobs()
                wf_jobs = [j for j in jobs if j.get("workflow_recipe")]
            except Exception:  # noqa: BLE001 - degrade to "no scheduled"; the
                # in-flight on-demand runs section (scheduler-independent) must
                # still render even if reading scheduled jobs fails.
                sched_read_failed = True
        inflight = self._inflight_runs(kwargs)
        plan_owner = _workflow_plan_owner(kwargs)
        active_plans = self._active_plans() if (inflight or plan_owner) else []
        orphans = self._orphan_runs(active_plans, inflight, plan_owner)
        if name:
            # On-demand history is scheduler-independent (6d-2), so a name query
            # works with cron off / for a never-scheduled recipe. Assemble the
            # scheduled detail (if any) + the durable on-demand history.
            ondemand = self._ondemand_history(name, 50 if task_id else 5)
            if task_id:
                ondemand = [r for r in ondemand if str(r.get("task_id") or "") == task_id]
            job = None
            if self._scheduler is not None and not sched_read_failed:
                job = next((j for j in wf_jobs if j.get("workflow_recipe") == name), None)
            parts_detail: list[str] = []
            matching_orphans = [
                plan
                for plan in orphans
                if " ".join(str(getattr(plan, "workflow", "") or "").split()) == name
                and (not task_id or str(getattr(plan, "origin_task", "") or "") == task_id)
            ]
            if matching_orphans:
                parts_detail.append(
                    "Waiting / resumable runs:\n"
                    + "\n".join(self._orphan_status_line(plan) for plan in matching_orphans)
                )
            if job is not None:
                parts_detail.append(self._status_detail(job))
            if ondemand:
                parts_detail.append(self._ondemand_history_block(name, ondemand))
            if parts_detail:
                return "\n\n".join(parts_detail)
            if task_id:
                return f"No run {task_id!r} of workflow {name!r} is visible to this conversation."
            # Nothing scheduled and no on-demand history recorded.
            if sched_read_failed:
                # Don't claim "not scheduled" when we simply couldn't read it.
                return f"Error: could not read scheduler status for {name!r}; try again."
            if self._scheduler is None:
                return (
                    f"Workflow {name!r} has no recorded runs. (Scheduling needs "
                    "config.cron.enabled.)"
                )
            return (
                f"Workflow {name!r} is not scheduled and has no recorded runs. Use "
                "action='status' for all scheduled workflows, or action='schedule' to add one."
            )
        # Overview: scheduled workflows + on-demand runs in flight now.
        parts: list[str] = []
        if wf_jobs:
            parts.append(
                f"Scheduled workflows ({len(wf_jobs)}):\n"
                + "\n".join(self._status_line(j) for j in wf_jobs)
            )
        if inflight:
            run_lines = [
                f"- {' '.join(str(r.get('workflow') or '').split())} — ▶ running "
                f"{self._fmt_elapsed(r.get('elapsed_seconds', 0))}"
                f"{self._plan_step_suffix(str(r.get('task_id') or ''), active_plans)}"
                for r in inflight
            ]
            parts.append(f"Running now ({len(inflight)}):\n" + "\n".join(run_lines))
        # Interrupted runs (crashed / lost on restart) that can be resumed —
        # scoped to the caller's own runs (plan.owner == caller session).
        if orphans:
            olines = [self._orphan_status_line(plan) for plan in orphans]
            parts.append(f"Interrupted / 中断 (resumable) ({len(orphans)}):\n" + "\n".join(olines))
        if sched_read_failed:
            # Be honest that the scheduled list is missing, not empty — prepend a
            # note whether or not there are in-flight runs to show alongside.
            parts.insert(0, "⚠️ Could not read scheduled workflows (try again).")
        if parts:
            return "\n\n".join(parts)
        if self._scheduler is None:
            return "No workflows are scheduled and none are running. (Scheduling needs config.cron.enabled.)"
        return (
            "No workflows are scheduled. Schedule one with: "
            "workflow(action='schedule', name=<recipe>, schedule='0 9 * * *')."
        )

    def _inflight_runs(self, kwargs: dict[str, Any]) -> list[dict[str, Any]]:
        """Active on-demand workflow runs scoped to the caller's Plan owner.

        Returns [] when there is no Plan-owner scope: ``list_workflow_runs``
        treats ``owner=None`` as "no filter" and returns ALL sessions' runs, so an
        unscoped call would leak other sessions' in-flight workflow names into
        this caller's status / resume output. Never query without a Plan owner —
        consistent with orphan detection, which also refuses without one.
        """
        if self._inflight_fn is None:
            return []
        plan_owner = _workflow_plan_owner(kwargs)
        if not plan_owner:
            return []
        try:
            return self._inflight_fn(owner=plan_owner) or []
        except Exception:  # noqa: BLE001 - status is read-only best-effort
            return []

    def _ondemand_history(self, recipe: str, limit: int = 5) -> list[dict[str, Any]]:
        """Durable on-demand run history for a recipe (best-effort, read-only)."""
        if self._run_history_fn is None:
            return []
        try:
            return self._run_history_fn(recipe, limit) or []
        except Exception:  # noqa: BLE001 - status is read-only best-effort
            return []

    def _ondemand_history_block(self, recipe: str, runs: list[dict[str, Any]]) -> str:
        """Render the durable on-demand run history for `status name=<recipe>`."""
        lines = [f"On-demand runs of {recipe!r} (recent):"]
        for r in reversed(runs):  # newest first
            status = r.get("status")
            icon = (
                "✓"
                if status == "success"
                else (
                    "⏸"
                    if status == "waiting_approval"
                    else ("⚠" if status == "incomplete" else "✗")
                )
            )
            dur = r.get("duration_s")
            dur_s = f" ({dur}s)" if dur is not None else ""
            extra = f" {r['error_type']}" if r.get("error_type") else ""
            lines.append(
                f"  - {self._fmt_ts(r.get('triggered_at'))} {icon} {r.get('status')}{dur_s}{extra}"
            )
        return "\n".join(lines)

    @staticmethod
    def _orphan_status_line(plan: Any) -> str:
        try:
            done, total = plan.progress
        except Exception:  # noqa: BLE001
            done, total = 0, 0
        workflow = " ".join(str(getattr(plan, "workflow", "") or "").split())
        task_id = str(getattr(plan, "origin_task", "") or "")
        task_part = f" task={task_id}" if task_id else ""
        if plan_waiting_for_approval(plan):
            state = f"⏸ waiting for approval at {done}/{total} steps"
        else:
            state = f"⚠️ interrupted at {done}/{total} steps"
        resume_args = f"name={json.dumps(workflow)}"
        if task_id:
            resume_args += f", task_id={json.dumps(task_id)}"
        # Name the params the resume will restore on its own, so the hint is
        # copy-pasteable AS IS and nobody re-supplies them out of doubt. Keys
        # only — a value is free text and this line must stay single-line.
        carried = sorted(_normalize_params(getattr(plan, "params", None)))
        carried_note = f" (params restored: {', '.join(carried)})" if carried else ""
        return (
            f"- {workflow}{task_part} — {state} — resume: workflow(action='resume', "
            f"{resume_args}){carried_note}"
        )

    def _orphan_runs(
        self, plans: list[Any], inflight: list[dict[str, Any]], caller: str
    ) -> list[Any]:
        """Interrupted workflow runs owned by ``caller`` (crashed / lost on restart).

        Takes the already-fetched ``plans`` (``_active_plans``) and ``inflight``
        (``_inflight_runs``) so ``status`` scans the plan store once per render.
        A run-as-Plan run persists its plan (keyed to its forked session); if the
        run dies its in-memory task is gone but the plan stays active. An orphan =
        a plan with ``workflow`` + ``origin_task`` set, **owned by the caller**
        (``plan.owner == caller``), and NOT in the current in-flight set.

        Owner scoping is REQUIRED: ``_active_plans`` (PlanStore.list_active) returns
        plans for ALL sessions, so without it ``status`` would leak another
        session's workflow and ``resume`` could discard another session's plan.
        """
        # Owner scoping needs a caller session; without one we can't safely
        # attribute an interrupted run, so surface nothing (never guess).
        if not plans or not caller:
            return []
        inflight_tasks = {str(r.get("task_id") or "") for r in inflight}
        # Recipes with a live run (the original still running, or a resume in
        # progress) — suppress their orphan so we don't nag about (or let resume
        # double-drive) a run that's currently being handled. ``inflight`` is
        # already owner-scoped, so this is the caller's live recipes. Collapse
        # whitespace to match ``plan.workflow`` (normalized on create/load) so an
        # irregularly-spaced recipe name still suppresses its own live run.
        inflight_recipes = {" ".join(str(r.get("workflow") or "").split()) for r in inflight}
        orphans: list[Any] = []
        for p in plans:
            wf = " ".join(str(getattr(p, "workflow", "") or "").split())
            ot = str(getattr(p, "origin_task", "") or "")
            if not wf or not ot:
                continue  # not a workflow-recipe background run
            if str(getattr(p, "owner", "") or "") != caller:
                continue  # another session's run — never surface/resume it
            if ot in inflight_tasks or wf in inflight_recipes:
                continue  # still running / being resumed — not (yet) interrupted
            orphans.append(p)
        return orphans

    def _active_plans(self) -> list[Any]:
        """Fetch active plans **once** per status render (best-effort, read-only).

        Returns [] when there is no lister or on any read error — never breaks
        the render.
        """
        if self._active_plans_fn is None:
            return []
        try:
            return self._active_plans_fn() or []
        except Exception:  # noqa: BLE001 - status is read-only best-effort
            return []

    @staticmethod
    def _plan_step_suffix(task_id: str, plans: list[Any]) -> str:
        """Live step of a run-as-Plan run, e.g. ' · 第 2/3 步：summarize CI'.

        Correlates by the run's **background_task_id** (``plan.origin_task ==
        task_id``) — NOT by recipe name. Task ids are unique and the in-flight
        runs are already owner-scoped, so this can only surface the caller's own
        plan: no other session's step title can leak in. Returns "" when there is
        no task id, no matching plan, or a malformed plan (best-effort — never
        breaks the render).
        """
        if not task_id:
            return ""
        for plan in plans:
            if getattr(plan, "origin_task", "") != task_id:
                continue
            try:
                done, total = plan.progress
            except Exception:  # noqa: BLE001 - malformed plan → no enrichment
                return ""
            # A malformed/empty plan (total missing/non-int/<=0) would render a
            # confusing "N/0 步" — bail out (best-effort UI enrichment).
            if not isinstance(total, int) or total <= 0:
                return ""
            items = getattr(plan, "items", []) or []
            for i, it in enumerate(items, 1):
                if getattr(it, "status", "") == "in_progress":
                    # Collapse ALL whitespace (LLM titles can carry \n/\t) so the
                    # run line stays single-line, then cap.
                    title = " ".join(str(getattr(it, "title", "")).split())[:60]
                    return f" · 第 {i}/{total} 步：{title}"
            return f" · {done}/{total} 步完成"
        return ""

    @staticmethod
    def _fmt_elapsed(seconds: Any) -> str:
        """Compact elapsed like '45s' / '3m' / '1h05m' from a seconds count."""
        try:
            s = int(float(seconds))
        except (TypeError, ValueError):
            return "?"
        if s < 60:
            return f"{s}s"
        if s < 3600:
            return f"{s // 60}m"
        return f"{s // 3600}h{(s % 3600) // 60:02d}m"

    @staticmethod
    def _fmt_ts(iso: Any) -> str:
        """Compact 'YYYY-MM-DD HH:MM' from an ISO timestamp, or '—' if absent.

        String-sliced (not parsed) so it's deterministic and timezone-agnostic —
        good enough for a status glance and testable without a clock.
        """
        if not isinstance(iso, str) or len(iso) < 16:
            return "—"
        return iso[:16].replace("T", " ")

    @classmethod
    def _fmt_last(cls, job: dict[str, Any]) -> str:
        last_at = job.get("last_run_at")
        if not last_at:
            return "never run"
        status = job.get("last_status")
        if status == "success":
            return f"✓ ran {cls._fmt_ts(last_at)}"
        # last_status persists as "error"; render as "failed" to match the run
        # history vocabulary so a summary line and its detail don't disagree.
        if status == "error":
            return f"✗ failed {cls._fmt_ts(last_at)}"
        return f"ran {cls._fmt_ts(last_at)}"

    @classmethod
    def _fmt_state(cls, job: dict[str, Any]) -> str:
        """Current state for the status view: prefer 'running now' (from the
        scheduler's computed ``status``) over the stale last-run summary, so an
        in-progress run isn't shown as its previous outcome."""
        if job.get("status") == "running":
            return "▶ running now"
        return cls._fmt_last(job)

    def _status_line(self, job: dict[str, Any]) -> str:
        dis = "" if job.get("enabled", True) else " (disabled)"
        return (
            f"- {job.get('workflow_recipe')} — ⏰ {job.get('schedule')}{dis} — "
            f"{self._fmt_state(job)} — next {self._fmt_ts(job.get('next_run'))}"
        )

    def _status_detail(self, job: dict[str, Any]) -> str:
        dis = "" if job.get("enabled", True) else " (disabled)"
        out = [
            f"Workflow {job.get('workflow_recipe')!r} — ⏰ {job.get('schedule')}{dis}",
            f"  last: {self._fmt_state(job)} · next: {self._fmt_ts(job.get('next_run'))}",
        ]
        if job.get("last_error"):
            out.append(f"  last error: {job['last_error']}")
        try:
            runs = self._scheduler.get_history(job.get("name"), limit=5) or []
        except Exception:  # noqa: BLE001 - history is best-effort
            runs = []
        if runs:
            out.append("  recent runs:")
            for r in reversed(runs):  # newest first
                icon = "✓" if r.get("status") == "success" else "✗"
                dur = r.get("duration_s")
                dur_s = f" ({dur}s)" if dur is not None else ""
                extra = f" {r['error_type']}" if r.get("error_type") else ""
                out.append(
                    f"  - {self._fmt_ts(r.get('triggered_at'))} {icon} "
                    f"{r.get('status')}{dur_s}{extra}"
                )
        return "\n".join(out)

    def _resolve_recipe(
        self, name: str, recipes: dict[str, Skill]
    ) -> tuple[Skill | None, str | None]:
        """Resolve a (already whitespace-collapsed) recipe name to its Skill.

        Matches by whitespace-collapsed equivalence (so a recipe whose frontmatter
        name carries irregular internal whitespace still resolves). Returns
        ``(recipe, error)``: ``error`` is set when 2+ distinct recipe names collapse
        to the same canonical id — we refuse rather than pick one, EVEN IF one is an
        exact match. Silently preferring the exact name would make the other recipe
        unreachable (user input is normalized) and could run/resume the wrong recipe
        (side-effects risk). ``recipe`` is None (no error) when nothing matches.
        """
        matches = [r for k, r in recipes.items() if " ".join(k.split()) == name]
        if len(matches) > 1:
            return None, (
                f"Error: {len(matches)} recipes collapse to the name {name!r} "
                "(whitespace-ambiguous) — rename them to distinct ids to disambiguate."
            )
        return (matches[0] if matches else None), None

    async def _run(self, kwargs: dict[str, Any]) -> str:
        # Normalize the recipe name the SAME way plans store `workflow` and
        # `_resume` resolves it (collapse whitespace, cap), so run / status /
        # resume / plan storage all share one canonical workflow id — a
        # legacy/hand-edited recipe name with irregular whitespace can't fragment
        # the identifier across those surfaces.
        name = " ".join(str(kwargs.get("name") or "").split())[:200]
        if not name:
            return "Error: 'name' is required for run."
        recipe, ambiguous = self._resolve_recipe(name, _load_recipes(self._dir))
        if ambiguous:
            return ambiguous
        if recipe is None:
            return f"Error: workflow {name!r} not found. Use action='list' to see recipes."
        # Parameterization (5b): resolve declared params against the caller's
        # ``params`` (use the provided value, else the parameter's default;
        # required with neither errors), then substitute ``{name}`` into the
        # body. Plain-text, no template engine.
        param_values, param_errors = _resolve_params(
            getattr(recipe, "parameters", None), kwargs.get("params")
        )
        if param_errors:
            return f"Error: {'; '.join(param_errors)}."
        # Refuse to spawn a run whose required checkout cannot be resolved: it
        # would stop at step 1 anyway. Hand the CALLER (the conversation agent,
        # which has the user's ear) a setup directive instead of burning a
        # background task to report the same thing.
        # Channel first: without an origin NOTHING can run, so a missing checkout is
        # not yet the caller's problem. Reporting setup first sent them to configure a
        # path and re-run, only to hit this wall on the second attempt.
        # Shared public helper (also used by SpawnTool) — no private coupling.
        origin = origin_from_kwargs(kwargs)
        if origin is None:
            return (
                "Error: no originating channel; run a workflow from a chat / web / "
                "Teams context so its result can be delivered back."
            )
        setup_hint = self._societas_setup_hint(name, recipe, param_values)
        if setup_hint:
            return setup_hint
        # Forward the caller's session (so the background task is *owned* — an
        # unowned task is cancellable from any session) and the registry-injected
        # metadata (cron/heartbeat provenance the ApprovalGate keys off), mirroring
        # SpawnTool. Our workflow marker is merged on top.
        # Resolve the agent's OWN checkout for recipes that declare it. Done here,
        # before ``workflow_params`` is stashed, so the value is persisted onto the
        # Plan and restored by `resume` instead of being re-derived by a later run.
        await _fill_agent_repo_path(recipe, param_values)
        # One seam to the per-project configuration layer, and the only shape this
        # tool knows about it: it may refuse the run outright, and it may hand back
        # text to append to the prompt. WHAT it resolves and WHY is declared by the
        # recipe, because `workflow` runs any recipe and holds none of their policy.
        #
        # It runs before spawning, deliberately. A run that cannot resolve its
        # bindings would reach step 1 and stop, so a background task would only burn
        # wall clock to say so — and unlike the setup gate above it does NOT degrade
        # to "spawn anyway", because a run missing them falls back to the model's own
        # habits, which is the failure the layer exists to prevent.
        prepared = await workflow_profile.prepare_run(recipe, name, param_values, self._dir)
        if prepared.refusal:
            return prepared.refusal
        if prepared.log:
            logger.info(f"Workflow {name!r}: {prepared.log}")
        injected = kwargs.get("_metadata")
        metadata = dict(injected) if isinstance(injected, dict) else {}
        metadata.pop("workflow_plan_required", None)
        metadata["workflow"] = name
        if getattr(recipe, "plan_mode", False):
            metadata["workflow_plan_required"] = True
        # Resolved params, carried two ways: the BackgroundTaskManager stashes them
        # on the run record so a timeout/failure notification can offer an accurate
        # resume / re-run command (``resume workflow <name> bug_id=…``), and the run's
        # own plan(create) persists them onto its Plan so `resume` can restore them
        # after this process is gone. The substituted prompt that carried them is
        # discarded downstream, so this metadata is the only place they survive.
        _wf_params = _normalize_params(param_values)
        if _wf_params:
            metadata["workflow_params"] = _wf_params
            # Carried separately from workflow_params because SpawnTool strips
            # every `workflow*` key except the two it names — a child must not
            # inherit this run's identity. This one key survives so a spawned
            # reviewer can read the repository the run is working in; see
            # spawn._WORKFLOW_READ_ROOT.
            _repo = _wf_params.get("repo_path")
            if _repo:
                metadata["workflow_repo_path"] = _repo
        # The task remains owned by the concrete caller session, while workflow
        # Plans use a trusted stable scope so a local client restart can recover its
        # own Plan without scanning another principal's Plans.
        caller = _workflow_owner_session(kwargs)
        metadata["workflow_owner"] = _workflow_plan_owner(kwargs)
        # Capability caps (Task 9): inject the recipe's normalized limits as
        # workflow_* keys so the harness (max_runtime/max_output via
        # background_tasks.start) and the spawn palette scoping (allowed_tools via
        # runtime._spawn_agent) can enforce them — none of it touches the core loop.
        # Nothing injected when the recipe declares no valid limits (gates inert).
        metadata.update(_normalize_limits(getattr(recipe, "limits", None)))
        _inject_concurrency_metadata(metadata, recipe, name, _wf_params)
        # run-as-Plan: a recipe that opts in (`plan: true`) gets a plan-driving
        # preamble prepended so the spawned run creates + steps through a
        # persisted Plan keyed to its own session (its plan file is the audit +
        # progress source `status` reads back). Plain recipes are unchanged.
        prompt = _substitute_params(recipe.content, param_values) + prepared.prompt_suffix
        if getattr(recipe, "plan_mode", False):
            prompt = _plan_preamble(name) + prompt
        task_id, message = await self._background_fn(
            agent="default",
            prompt=prompt,
            origin=origin,
            metadata=metadata,
            parent_session=caller or None,
        )
        if task_id is None:
            return _start_failure(name, "start", message)
        started = f"▶ Workflow {name!r} started in an isolated background session.\n{message}"
        # First-use opt-in: on the very first run of the bundled bug-fix workflow,
        # append a one-time directive telling the agent to offer the always-on
        # Societas scanner cron. Empty string (the common case) → no-op.
        return started + self._scanner_onboarding_hint(name, recipe)

    def _societas_setup_hint(self, name: str, recipe: Any, param_values: dict[str, Any]) -> str:
        """Setup directive when the bug-fix recipe has no resolvable checkout.

        Returns the directive only when ALL hold: (a) the run targets the recipe
        name this directive is written for; (b) the resolved ``repo_path``
        parameter is empty; (c) the metadata handle is wired; (d)
        ``ado_repo_local_path`` is unset in the default agent's metadata; (e) the
        resolved recipe is the BUNDLED one, not a same-named user override. The
        caller refuses to spawn and returns this instead — a run that cannot
        resolve the checkout stops at step 1, so the background task would only
        burn wall-clock to say so.

        (e) is checked last on purpose: it re-reads the recipe directory, while
        (a)-(d) are dict lookups. Ordering it after them keeps the common case
        (already configured, or an explicit repo_path) free of a filesystem scan.

        Best-effort: any error degrades to an empty string (spawn as before),
        never breaking a run over a config read.
        """
        if name != _SCANNER_ONBOARDING_RECIPE:
            return ""
        if str(param_values.get("repo_path") or "").strip():
            return ""  # caller supplied the checkout explicitly — nothing to set up
        if self._agent_metadata_fn is None:
            return ""
        try:
            metadata = self._agent_metadata_fn() or {}
            if str(metadata.get(_SOCIETAS_REPO_PATH_KEY) or "").strip():
                return ""  # already configured
        except Exception:  # noqa: BLE001 - setup detection is best-effort
            return ""
        # Last: a user recipe may override the bundled one under the same name
        # (_load_recipes: user overrides bundled). Gate on the recipe's SOURCE, not
        # on its name and not on the parameter names it happens to declare — a
        # parameter called `repo_path` is not a capability declaration, and a
        # remote-only override could legitimately use one as a report-output
        # location. Only the recipe shipped in this package needs a local checkout,
        # and only it is described by _SOCIETAS_SETUP_DIRECTIVE.
        if not _is_bundled(self._dir, recipe):
            return ""
        return _societas_setup_directive(param_values.get("bug_id"))

    def _pr_watcher_hint(self, recipe: Any) -> str:
        """Repair directive for the PraestoClaw PR watcher, or ``""``.

        Detection only — no first-run offer. It fires whenever the watcher is
        absent or non-compliant, because "installed but wrong" is the state nobody
        notices: the job exists, `cron list` shows it, and it silently cannot do
        the one thing it is for.

        Gated on the recipe being the bundled one for the same reason the Societas
        path is: a same-named user override would otherwise be told to install a
        watcher for a workflow this machine does not have.

        Best-effort — a missing scheduler or any error degrades to no directive.
        """
        if self._scheduler is None:
            return ""
        spec = _PRAESTOCLAW_WATCHER
        try:
            jobs = list(self._scheduler.list_jobs() or [])
            watcher = next(
                (j for j in jobs if str(j.get("name") or "").strip() == spec.cron_name),
                None,
            )
            if watcher is not None:
                problem = _scanner_job_problem(watcher, spec=spec)
                if not problem:
                    return ""
                if not _is_bundled(self._dir, recipe):
                    return ""
                return _pr_watcher_repair_directive(f"`{spec.cron_name}` 存在，但**{problem}**。")
            if not _is_bundled(self._dir, recipe):
                return ""
            return _pr_watcher_repair_directive(f"这台机器上没有 `{spec.cron_name}`。")
        except Exception:  # noqa: BLE001 - watcher detection is best-effort
            return ""

    def _scanner_onboarding_hint(self, name: str, recipe: Any) -> str:
        """Directive to install, upgrade or repair the Societas scanner cron, or ``""``.

        NOT one-time — that is only half of it, and the docstring said so for a
        while after a merge kept this function's signature from one branch and its
        body from another. Two shapes:

        * **First-use offer** — nothing scanner-shaped is installed AND this is the
          first run (no durable history yet; the current run records on completion,
          not now). Latched via ``_scanner_onboarding_offered``, so it fires at most
          once per runtime and never again once history exists. No marker file.
        * **Repair** — the canonical watcher exists but cannot do its job (wrong
          schedule, a prompt whose first line lacks the current
          ``societas-scanner-schema`` stamp, disabled), or it is absent and only
          mis-named candidates exist. **Deliberately not latched**: the latch proves
          an offer was made, never that a repair happened, so this repeats every run
          until ``list_jobs()`` shows a compliant watcher.

        A compliant canonical watcher returns "" whatever else is installed —
        reporting an unrelated job the user chose to KEEP produced a warning that
        could never be dismissed, since it stays in ``list_jobs()`` forever.

        Every emission — repair as well as first-use — is gated on the recipe's
        SOURCE, not its name: a user recipe may override the bundled one
        (``_load_recipes``: user overrides bundled), and telling the caller to
        install or repair `societas-bug-watcher` after a remote-only override ran
        would arm a watcher for a workflow this machine does not have. Both
        onboarding paths in this class need that gate; the pre-spawn setup hint got
        it first and this one kept matching on the name alone.

        Best-effort: a missing scheduler or any error degrades to no directive,
        never breaking the run.
        """
        if name == _PRAESTOCLAW_WATCHER_RECIPE:
            return self._pr_watcher_hint(recipe)
        if name != _SCANNER_ONBOARDING_RECIPE:
            return ""
        if self._scheduler is None:
            return ""

        def _bundled() -> bool:
            # Called only on paths that are ABOUT to emit a directive. _is_bundled
            # re-reads the recipe directory, and the steady state — a compliant
            # canonical watcher, or a workflow that has run before — returns earlier
            # without ever needing it. Guarding every emission (repair as well as
            # first-use) matters because a same-named user override must not be told
            # to install or repair a watcher for a workflow this machine lacks.
            return _is_bundled(self._dir, recipe)

        try:
            jobs = list(self._scheduler.list_jobs() or [])
            watcher = next(
                (j for j in jobs if str(j.get("name") or "").strip() == _SCANNER_CRON_NAME),
                None,
            )
            if watcher is not None:
                problem = _scanner_job_problem(watcher)
                if not problem:
                    # A compliant canonical watcher is the whole contract. Other
                    # societas-shaped jobs are the user's business — reporting them
                    # here produced a warning that could never be dismissed, since
                    # a job the user chose to KEEP stays in list_jobs() forever.
                    return ""
                if not _bundled():
                    return ""
                return _scanner_repair_directive(
                    f"`{_SCANNER_CRON_NAME}` 存在，但**{problem}**。",
                    strays=_possible_stray_watchers(jobs),
                )
            strays = _possible_stray_watchers(jobs)
            if strays:
                if not _bundled():
                    return ""
                # The live failure: onboarding ran, produced the wrong jobs, and run
                # history then silenced the first-run offer forever.
                return _scanner_repair_directive(
                    f"这台机器上没有 `{_SCANNER_CRON_NAME}`，只有装歪的同类任务。",
                    strays=strays,
                )
            # Nothing installed at all → the one-time first-run offer.
            if self._scanner_onboarding_offered:
                return ""  # in-process latch — offered already this runtime
            if self._run_history_fn is None:
                return ""
            if self._run_history_fn(name, 1):
                return ""  # not the first run — history already has a record
        except Exception:  # noqa: BLE001 - onboarding is best-effort
            return ""
        if not _bundled():
            return ""
        self._scanner_onboarding_offered = True
        return _SCANNER_ONBOARDING_DIRECTIVE

    async def _resume(self, kwargs: dict[str, Any]) -> str:
        # Normalize the recipe name the SAME way plans store `workflow` (collapse
        # whitespace, cap) so the orphan match below (plan.workflow == name) is
        # exact even for the already-collapsed name the status hint suggests.
        name = " ".join(str(kwargs.get("name") or "").split())[:200]
        selected_task_id = str(kwargs.get("task_id") or "").strip()[:64]
        if not name:
            return "Error: 'name' (the recipe to resume) is required."
        recipe, ambiguous = self._resolve_recipe(name, _load_recipes(self._dir))
        if ambiguous:
            return ambiguous
        if recipe is None:
            return (
                f"Error: workflow {name!r} not found (its recipe may have been deleted); "
                "cannot resume."
            )
        caller = _workflow_owner_session(kwargs)
        checkpoint_approved = _as_bool(kwargs.get("approve_checkpoint"))
        if not caller:
            # No caller session → an interrupted run can't be attributed to this
            # caller (orphan detection refuses without one) and _inflight_runs is
            # empty too. Return early to skip a needless plan-store scan.
            return (
                f"No interrupted run of {name!r} to resume. Use action='status' to see "
                "interrupted runs."
            )
        inflight = self._inflight_runs(kwargs)
        plan_owner = _workflow_plan_owner(kwargs)
        mine = [
            p
            for p in self._orphan_runs(self._active_plans(), inflight, plan_owner)
            if " ".join(str(getattr(p, "workflow", "") or "").split()) == name
            and (
                not selected_task_id or str(getattr(p, "origin_task", "") or "") == selected_task_id
            )
        ]
        if not mine:
            # A live run of this recipe suppresses its orphan (see _orphan_runs),
            # so a bare "no interrupted run" would be misleading. Distinguish the
            # two: if the recipe is currently in-flight (owner-scoped), say it's
            # already running rather than implying there's nothing to resume.
            if any(" ".join(str(r.get("workflow") or "").split()) == name for r in inflight):
                return (
                    f"Workflow {name!r} is already running — wait for it to finish (see "
                    "action='status'); there's nothing to resume while it's in flight."
                )
            return (
                f"No interrupted run of {name!r} to resume. Use action='status' to see "
                "interrupted runs."
            )
        if len(mine) > 1:
            # Multiple interrupted runs of the same recipe — resuming would guess
            # which one (and could re-drive the wrong side effects). Refuse rather
            # than pick blindly; per-run selection is not yet supported.
            return (
                f"Error: {len(mine)} interrupted runs of {name!r} — provide task_id from "
                "workflow(action='status', name=...) to select one."
            )
        orphan = mine[0]
        if plan_waiting_for_approval(orphan) and not checkpoint_approved:
            origin_task = str(getattr(orphan, "origin_task", "") or "")
            task_ref = f" task {origin_task!r}" if origin_task else ""
            resume_args = f"name={json.dumps(name)}"
            if origin_task:
                resume_args += f", task_id={json.dumps(origin_task)}"
            return (
                f"Workflow {name!r}{task_ref} is waiting for explicit user "
                "approval. After the user approves, call workflow(action='resume', "
                f"{resume_args}, approve_checkpoint=true)."
            )
        origin = origin_from_kwargs(kwargs)
        if origin is None:
            return (
                "Error: no originating channel (need _channel + _channel_id) so the "
                "resumed run's result can be delivered back."
            )
        injected = kwargs.get("_metadata")
        metadata = dict(injected) if isinstance(injected, dict) else {}
        metadata.pop("workflow_plan_required", None)
        metadata["workflow"] = name
        if getattr(recipe, "plan_mode", False):
            metadata["workflow_plan_required"] = True
        # Preserve the trusted Plan-owner scope across the successor run. The
        # concrete caller session still owns task control via parent_session.
        metadata["workflow_owner"] = plan_owner
        # Capability caps (Task 9): same limit injection as `run` so a resumed run
        # is bounded identically to the original (limits re-resolve from the recipe,
        # which is the current source of truth). Inert when the recipe has none.
        metadata.update(_normalize_limits(getattr(recipe, "limits", None)))
        # Deferred supersede (6d-3): hand the interrupted plan's session id to the
        # resumed run so it retires the old plan ONLY AFTER it persists its own
        # successor plan (see PlanTool._create). Retiring here — before the run has
        # created anything — would hide the old plan if the resume crashed early,
        # leaving nothing resumable. Tying supersede to "the successor exists"
        # guarantees exactly one resumable orphan through a crash at any point.
        old_sid = str(getattr(orphan, "session_id", "") or "")
        if old_sid:
            metadata["workflow_supersede_prev"] = old_sid
        # Apply the same parameter resolution/substitution as `run` so a
        # parameterized recipe's `{param}`s are filled (not left raw). Three
        # tiers, highest priority first: the caller's `params` (an explicit
        # override), then the interrupted run's OWN params restored from its plan,
        # then each parameter's declared default. Without the restore tier a
        # required-with-no-default param (e.g. `bug_id`) made every resume of a
        # parameterized recipe fail with "missing required parameter", which read
        # as "this run is unresumable" and pushed users into a from-scratch re-run.
        restored = _normalize_params(
            getattr(orphan, "params", None) or getattr(orphan, "workflow_params", None)
        )
        # A null caller value means "not provided" (the same rule _resolve_params
        # applies just below), so it must NOT shadow the restored value — else a
        # model that emits `params={"bug_id": null}` on resume would discard the
        # restore and fail with "missing required parameter" all over again.
        override = {
            k: v for k, v in _coerce_params_arg(kwargs.get("params")).items() if v is not None
        }
        merged = {**restored, **override}
        param_values, param_errors = _resolve_params(getattr(recipe, "parameters", None), merged)
        if param_errors:
            return f"Error: {'; '.join(param_errors)}."
        # Same in-process resolution as `run`. The restore tier above normally
        # carries it, but a plan written before the recipe declared the parameter
        # (or one whose value was never resolved) would otherwise resume with an
        # empty checkout and re-derive it through the shell the helper exists to
        # avoid.
        await _fill_agent_repo_path(recipe, param_values)
        # Re-resolve, never restore. A resumed run is a FRESH isolated session
        # whose preamble carries item titles and nothing else, so without this it
        # would continue from `Fix` holding no provider bindings at all — and the
        # preamble explicitly tells it not to redo the step that would have found
        # them. Resolution is idempotent and read-only, so re-doing it is free.
        # One seam. This may refuse the run outright and may hand back text to
        # append to the prompt; what it resolves, and why, is the recipe's business.
        prepared = await workflow_profile.prepare_run(recipe, name, param_values, self._dir)
        if prepared.refusal:
            return prepared.refusal
        if prepared.log:
            logger.info(f"Workflow {name!r}: {prepared.log}")
        # Carry resolved params so a re-timeout of THIS resumed run can again
        # offer an accurate resume command, and so the successor plan persists them
        # for the NEXT resume (same threading as `run`).
        _wf_params = _normalize_params(param_values)
        if _wf_params:
            metadata["workflow_params"] = _wf_params
            # Mirror `run`. Without this a RESUMED run silently loses the child
            # read scope: SpawnTool keeps `workflow_repo_path` and nothing else
            # (spawn.py::_WORKFLOW_READ_ROOT), and runtime._grant_child_repo_reads
            # returns on a falsy value without logging — so a spawned reviewer
            # would read nothing and hand back an audit that looks clean.
            _repo = _wf_params.get("repo_path")
            if _repo:
                metadata["workflow_repo_path"] = _repo
        _inject_concurrency_metadata(metadata, recipe, name, _wf_params)
        # Re-drive: the resume preamble carries the interrupted plan's state (done
        # vs remaining + idempotency warning), then the substituted recipe body. A
        # fresh isolated run continues the remaining steps (no loop-level plan
        # takeover).
        prompt = (
            _resume_preamble(name, orphan, checkpoint_approved=checkpoint_approved)
            + _substitute_params(recipe.content, param_values)
            + prepared.prompt_suffix
        )
        task_id, message = await self._background_fn(
            agent="default",
            prompt=prompt,
            origin=origin,
            metadata=metadata,
            parent_session=caller or None,
        )
        if task_id is None:
            return _start_failure(name, "resume", message)
        # NOTE: the old interrupted plan is NOT retired here. The resumed run
        # retires it (via workflow_supersede_prev) only after it persists its own
        # successor plan — so a crash before that leaves the old plan resumable.
        try:
            done, total = orphan.progress
        except Exception:  # noqa: BLE001
            done, total = 0, 0
        # Name the params that came from the interrupted run rather than from this
        # call, so a restore is visible/auditable instead of silent. Keys only: a
        # value is free text and this string is user-facing.
        carried = sorted(k for k in restored if k not in override)
        restored_note = f" (params restored: {', '.join(carried)})" if carried else ""
        return (
            f"▶ Resuming workflow {name!r} from where it stopped ({done}/{total} steps were "
            f"done) in a fresh isolated background session{restored_note}.\n{message}"
        )

    def _add(self, kwargs: dict[str, Any]) -> str:
        # Strip first, then pre-cap the raw name before slugifying: stripping
        # first keeps leading whitespace from eating the cap budget (a name that
        # is 512 spaces + real text would otherwise slice down to all-whitespace
        # and be wrongly rejected), and the cap still bounds the regex work in
        # _slugify against a pathological megastring (the slug is capped again).
        slug = _slugify(str(kwargs.get("name") or "").strip()[:512])
        if not slug:
            return (
                "Error: 'name' is required and must contain letters or digits "
                "(it becomes the recipe id you run)."
            )
        # The shared skill parser strips the body on load (skills/loader.py), so
        # run receives a stripped prompt regardless of what we save — match that
        # here. Strip, then cap, then re-check non-empty so a body that is all
        # whitespace before the cap can't slip through.
        body = str(kwargs.get("body", "") or "").strip()[:_MAX_BODY_LEN]
        if not body:
            return "Error: 'body' is required — the step-by-step instructions the agent follows."
        # Collapse all whitespace to single spaces — description is one line (it
        # appears in the list output; a multi-line value would become a YAML
        # block scalar and break formatting).
        description = " ".join(str(kwargs.get("description", "") or "").split())[:_MAX_DESC_LEN]
        # Optional typed parameters (PR2): validated + normalized, then written
        # into the frontmatter so ``run`` can bind + substitute them.
        param_specs, param_err = _normalize_param_specs(kwargs.get("parameters"))
        if param_err:
            return f"Error: {param_err}"
        path = self._dir / f"{slug}.md"
        fm: dict[str, Any] = {"name": slug, "description": description}
        if param_specs:
            fm["parameters"] = param_specs
        # width=10**6 keeps the (single-line) description from being wrapped/
        # folded by the YAML dumper.
        frontmatter = yaml.safe_dump(
            fm,
            allow_unicode=True,
            sort_keys=False,
            width=10**6,
        ).strip()
        content = f"---\n{frontmatter}\n---\n{body}\n"
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            # e.g. a parent path component is a file — on Windows this surfaces
            # as FileExistsError, so keep it out of the write's collision branch.
            return f"Error: could not save workflow {slug!r}: {exc}"
        try:
            if _as_bool(kwargs.get("replace")):
                # Atomic durable overwrite: write to a securely-created unique
                # temp file in the same dir (NamedTemporaryFile owns the fd, so
                # it can't leak even if the write raises), then os.replace() it
                # into place. Cleanup is best-effort and can't mask the original
                # error.
                tmp: Path | None = None
                try:
                    with tempfile.NamedTemporaryFile(
                        dir=self._dir,
                        suffix=".md.tmp",
                        delete=False,
                        mode="w",
                        encoding="utf-8",
                    ) as fh:
                        tmp = Path(fh.name)
                        fh.write(content)
                    os.replace(tmp, path)
                finally:
                    if tmp is not None:
                        tmp.unlink(missing_ok=True)
            else:
                # Atomic exclusive create — no TOCTOU window vs a concurrent add.
                with open(path, "x", encoding="utf-8") as fh:
                    fh.write(content)
        except FileExistsError:
            return f"Error: workflow {slug!r} already exists. Pass replace=true to overwrite."
        except OSError as exc:
            return f"Error: could not save workflow {slug!r}: {exc}"
        if param_specs:
            pnames = ", ".join(str(p["name"]) for p in param_specs)
            return (
                f"✅ Saved workflow {slug!r} with parameters ({pnames}). Run it with: "
                f"workflow(action='run', name='{slug}', params={{…}})."
            )
        return f"✅ Saved workflow {slug!r}. Run it with: workflow(action='run', name='{slug}')."

    def _init_project(self, kwargs: dict[str, Any]) -> str:
        """Resolve the recipe, then hand the whole job to its configuration layer.

        This tool's only business here is turning a name into a recipe; what a
        configuration for that recipe contains is declared by the recipe itself.
        """
        name = " ".join(str(kwargs.get("name") or "").split())[:_MAX_NAME_LEN]
        if not name:
            return "Error: init_project needs the 'name' of the recipe the configuration is for."
        recipe, error = self._resolve_recipe(name, _load_recipes(self._dir))
        if error or recipe is None:
            return error or f"Error: unknown workflow {name!r}."
        return workflow_profile.init_project(kwargs, self._dir, recipe)

    def _schedule(self, kwargs: dict[str, Any]) -> str:
        if self._scheduler is None:
            return (
                "Error: scheduling needs the cron subsystem — enable config.cron.enabled "
                "and restart."
            )
        name = " ".join(str(kwargs.get("name") or "").split())[:200]
        if not name:
            return "Error: 'name' (the recipe to schedule) is required."
        schedule = str(kwargs.get("schedule", "")).strip()
        if not schedule:
            return (
                "Error: 'schedule' is required — a cron expression (e.g. '0 9 * * *'), "
                "interval seconds ('3600'), or a one-shot ('at:+300' or 'at:<ISO>')."
            )
        # Resolve the recipe the SAME way run/resume do (canonical id + ambiguity
        # refusal) so a recipe runnable via its canonical id is also schedulable.
        # The job stores the CANONICAL id (`name`, below), which the scheduler's
        # resolver collapse-matches at fire time — a consistent round-trip that
        # keeps schedule/status/unschedule on the one identifier.
        recipe, ambiguous = self._resolve_recipe(name, _load_recipes(self._dir))
        if ambiguous:
            return ambiguous
        if recipe is None:
            return f"Error: workflow {name!r} not found. Use action='list' to see recipes."
        # Unattended-run guard (5b): a scheduled run supplies no param values, so
        # a required param with no default could never resolve — refuse to
        # schedule it (clearer than a silent failure on every fire).
        needs_value = [
            str(p.get("name"))
            for p in (getattr(recipe, "parameters", None) or [])
            if _as_bool(p.get("required")) and p.get("default") is None
        ]
        if needs_value:
            return (
                f"Error: workflow {name!r} needs parameter(s) {needs_value} at run time, "
                "but scheduled runs are unattended. Give each a `default` in the recipe "
                "to schedule it."
            )
        # Normalize notify_channels: absent/None means "all active channels"; a
        # bare string (schema-violating but common from LLMs) becomes a 1-element
        # list. An *explicitly empty* value ("" / []) is rejected rather than
        # silently broadening delivery to all channels; other types error too.
        notify = kwargs.get("notify_channels")
        if notify is None:
            notify_channels = None
        elif isinstance(notify, str):
            if not notify.strip():
                return (
                    "Error: 'notify_channels' is empty — omit it for all active "
                    f"channels, or name specific ones ({_NOTIFY_CHANNELS_HELP})."
                )
            notify_channels = [notify]
        elif isinstance(notify, list):
            if not notify:
                return (
                    "Error: 'notify_channels' is empty — omit it for all active "
                    f"channels, or name specific ones ({_NOTIFY_CHANNELS_HELP})."
                )
            notify_channels = [str(c) for c in notify]
        else:
            return "Error: 'notify_channels' must be a string or a list of channel names."
        # Validate/normalize (strip + lower) each entry against the supported set
        # and reject unknowns clearly — otherwise the scheduler coerces a typo to
        # internal fallback and the scheduled result silently lands on the wrong channel.
        if notify_channels is not None:
            normalized: list[str] = []
            for c in notify_channels:
                cc = c.strip().lower()
                if cc not in _VALID_NOTIFY_CHANNELS:
                    return (
                        f"Error: unknown notify_channels value {c!r}. "
                        f"Valid values: {_NOTIFY_CHANNELS_HELP} ('*' = all active)."
                    )
                if cc not in normalized:  # de-dupe (avoids duplicate deliveries)
                    normalized.append(cc)
            if "*" in normalized and len(normalized) > 1:
                # '*' expands to all active channels, so it can't be meaningfully
                # combined with specific ones — the extras would be discarded.
                return (
                    "Error: notify_channels '*' (all active) can't be combined with "
                    "specific channels."
                )
            notify_channels = normalized or None
        try:
            # workflow_recipe (not a static prompt): the scheduler re-resolves the
            # recipe body fresh at each fire, so edits take effect without rescheduling.
            # Key the job off the CANONICAL id (`name`), not the raw frontmatter
            # `recipe.name`, so `status name=<recipe>` / unschedule-by-name and the
            # scheduler resolver all share the one identifier run/resume use.
            self._scheduler.add_job(
                name=f"wf-{name}",
                schedule=schedule,
                workflow_recipe=name,
                notify_channels=notify_channels,
                channel=kwargs.get("_channel"),
                channel_id=kwargs.get("_channel_id"),
                description=f"workflow: {name}",
            )
        except ValueError as exc:
            # Bad cron/interval expression, reserved name, etc.
            return f"Error: could not schedule {name!r}: {exc}"
        # Reflect the actual delivery target. '*' means all active channels —
        # spell that out rather than echo a bare "*".
        where = (
            ", ".join(notify_channels)
            if notify_channels and notify_channels != ["*"]
            else "your active channels"
        )
        return (
            f"✅ Scheduled workflow {name!r} ({schedule}). Its result posts to "
            f"{where} each run. Stop it with: "
            f"workflow(action='unschedule', name='{name}')."
        )

    def _unschedule(self, kwargs: dict[str, Any]) -> str:
        if self._scheduler is None:
            return "Error: scheduling needs the cron subsystem (config.cron.enabled)."
        # Canonicalize the same way schedule stores the job (wf-<canonical id>) so
        # unschedule by a whitespace-variant of the name still removes it. A raw
        # job id copied from `cron list` is already canonical (schedule stored it).
        name = " ".join(str(kwargs.get("name") or "").split())[:200]
        if not name:
            return "Error: 'name' (the recipe to unschedule) is required."
        # schedule() always registers the job as ``wf-<recipe>``, so try the
        # prefixed form first; also try the raw name so a job id copied from
        # `cron list` works. Prefixed-first correctly handles a recipe whose own
        # name starts with "wf-" (scheduled as wf-wf-<name>). Don't require the
        # recipe to still exist — allow clearing a dangling schedule.
        for job_name in (f"wf-{name}", name):
            try:
                self._scheduler.remove_job(job_name)
            except ValueError:
                continue
            return f"✅ Unscheduled workflow {name!r}."
        return f"Error: workflow {name!r} is not scheduled."


def maybe_register_workflow_tool(
    registry: Any,
    *,
    enabled: bool,
    workflow_dir: Path,
    background_fn: BackgroundFn,
    scheduler: Any = None,
    inflight_fn: Any = None,
    active_plans_fn: Any = None,
    run_history_fn: Any = None,
    agent_metadata_fn: Any = None,
) -> bool:
    """Register ``WorkflowTool`` iff ``enabled``. Returns whether it registered.

    Extracted from ``runtime`` so the feature-flag gate is behaviorally testable.
    ``scheduler`` (the SchedulerService, or None when cron is disabled) enables
    the ``schedule`` / ``unschedule`` actions. ``inflight_fn`` (BackgroundTaskManager.
    list_workflow_runs) surfaces in-flight on-demand runs in ``status``.
    ``active_plans_fn`` (PlanStore.list_active) shows a run-as-Plan run's live
    step (第 K/M 步), matched to the run by ``plan.origin_task``. ``run_history_fn``
    (WorkflowRunStore.get_history) shows a recipe's durable on-demand run history.
    ``agent_metadata_fn`` (() -> the default agent's ``metadata`` dict) lets the
    Societas bug-fix recipe refuse to spawn when it has no resolvable checkout.
    """
    if not enabled:
        return False
    registry.register(
        WorkflowTool(
            workflow_dir=workflow_dir,
            background_fn=background_fn,
            scheduler=scheduler,
            inflight_fn=inflight_fn,
            active_plans_fn=active_plans_fn,
            run_history_fn=run_history_fn,
            agent_metadata_fn=agent_metadata_fn,
        )
    )
    return True
