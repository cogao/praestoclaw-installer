"""Deterministic GitHub PR watcher used by cron tool mode.

Scope is deliberately narrower than ``societas_scanner``: this watches **only the
pull requests this workflow already opened**, and never scans for new bugs to
start. Starting a bug is an expensive, irreversible-ish action — it takes the
workflow's single global instance slot, creates a worktree in the agent's own
source tree, and opens a real PR — so it stays a human's decision. Pushing an
already-started PR toward green adds no new decision, which is what makes it safe
to run unattended.

Cron tool mode runs this with **no LLM in the loop**, so everything here is
deterministic: `gh` subprocesses, JSON parsing, and a state file. The tool cannot
call ``workflow(action='resume')`` itself — a tool returns text. What it returns
instead is an Adaptive Card whose imBack value IS the exact resume command, so a
click starts a turn in the conversation that owns the Plan. That ownership is not
incidental: ``cron.py`` overwrites a scanner job's owner with the originating
conversation precisely so the resume can find its orphan Plan.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.risk import RiskAssessment, RiskScore
from praestoclaw.utils.helpers import get_data_dir

SCHEMA_VERSION = 1
TOOL_NAME = f"github_pr_scanner_v{SCHEMA_VERSION}"

REQUIRED_ARGS = ("repo_slug", "author", "branch_prefix", "workflow_name")

# ``owner/repo``. Anything else is rejected rather than passed to `gh`, because
# these values arrive from a stored cron job's arguments.
_REPO_SLUG_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*/[A-Za-z0-9][A-Za-z0-9._-]*$")
_LOGIN_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,100}$")
_BRANCH_PREFIX_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._/-]{0,100}$")

_MAX_PRS = 25
_GH_TIMEOUT = 60.0

# One page of threads is 100; a PR with several review rounds can exceed that, and
# a missed page reads as "no unresolved comments" — the failure mode the
# babysit-pr skill flags as CRITICAL. Bound the walk anyway so a pathological PR
# cannot hang a cron tick.
_MAX_THREAD_PAGES = 10

_THREAD_QUERY = (
    "query($owner:String!,$name:String!,$number:Int!,$cursor:String){"
    "repository(owner:$owner,name:$name){pullRequest(number:$number){"
    "reviewThreads(first:100,after:$cursor){"
    "pageInfo{hasNextPage endCursor}"
    "nodes{id isResolved isOutdated path}}}}}"
)

GhRunner = Callable[[list[str]], Awaitable[str]]
PlansFn = Callable[[], list[Any]]


def _card(body_text: str, action_title: str, action_value: str) -> str:
    return json.dumps(
        {
            "type": "message",
            "attachments": [
                {
                    "contentType": "application/vnd.microsoft.card.adaptive",
                    "content": {
                        "type": "AdaptiveCard",
                        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                        "version": "1.4",
                        "body": [{"type": "TextBlock", "text": body_text, "wrap": True}],
                        "actions": [
                            {
                                "type": "Action.Submit",
                                "title": action_title,
                                "data": {"msteams": {"type": "imBack", "value": action_value}},
                            }
                        ],
                    },
                }
            ],
        },
        ensure_ascii=False,
        separators=(",", ":"),
    )


class GithubPrScannerTool(Tool):
    """Classify the workflow's own open PRs so a cron tick can hand one back."""

    risk_range = (3, 3)

    def __init__(
        self,
        data_dir: Path | None = None,
        *,
        gh_runner: GhRunner | None = None,
        plans_fn: PlansFn | None = None,
    ) -> None:
        self._data_dir = data_dir or get_data_dir()
        self._state_path = self._data_dir / "workspace" / ".praestoclaw-pr-watcher" / "state.json"
        self._gh_runner = gh_runner or self._run_gh
        if plans_fn is None:
            from praestoclaw.agent.tools.plan import PlanStore

            plans_fn = PlanStore(self._data_dir).list_active
        self._plans_fn = plans_fn
        self._state_lock = asyncio.Lock()

    @property
    def name(self) -> str:
        return TOOL_NAME

    @property
    def description(self) -> str:
        return "Deterministically classify this workflow's open GitHub PRs for a scheduled watcher."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "repo_slug": {"type": "string", "description": "owner/repo"},
                "author": {"type": "string", "description": "GitHub login that opened the PRs"},
                "branch_prefix": {
                    "type": "string",
                    "description": "Only PRs whose head branch starts with this are watched",
                },
                "workflow_name": {
                    "type": "string",
                    "description": "Recipe whose Plan a resume command should target",
                },
            },
            "required": list(REQUIRED_ARGS),
            "additionalProperties": False,
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=300, tier="hidden")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(3, reason="Read GitHub pull requests and update the watcher snapshot")

    def validate(self, args: dict[str, Any]) -> list[str]:
        errors: list[str] = []
        for key in REQUIRED_ARGS:
            if not str(args.get(key) or "").strip():
                errors.append(f"'{key}' is required")
        slug = str(args.get("repo_slug") or "").strip()
        if slug and not _REPO_SLUG_RE.match(slug):
            errors.append("'repo_slug' must look like owner/repo")
        author = str(args.get("author") or "").strip()
        if author and not _LOGIN_RE.match(author):
            errors.append("'author' must be a GitHub login")
        prefix = str(args.get("branch_prefix") or "").strip()
        if prefix and not _BRANCH_PREFIX_RE.match(prefix):
            errors.append("'branch_prefix' contains characters a branch name cannot hold")
        return errors

    # ── state ────────────────────────────────────────────────────────────────

    def _load_state(self) -> dict[str, Any]:
        try:
            loaded = json.loads(self._state_path.read_text(encoding="utf-8"))
        except Exception:
            return {}
        return loaded if isinstance(loaded, dict) else {}

    def _save_state(self, state: dict[str, Any]) -> None:
        try:
            self._state_path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self._state_path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, self._state_path)
        except Exception as exc:  # pragma: no cover - state is best effort
            logger.warning("github_pr_scanner: could not persist state: {}", exc)

    # ── gh ───────────────────────────────────────────────────────────────────

    async def _run_gh(self, args: list[str]) -> str:
        """Run `gh` with an argv list — never a shell string.

        ``GH_PROMPT_DISABLED`` keeps a credential prompt from hanging an
        unattended tick, mirroring ``feedback_submit``.
        """
        env = {**os.environ, "GH_PROMPT_DISABLED": "1"}
        proc = await asyncio.create_subprocess_exec(
            "gh",
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=_GH_TIMEOUT)
        except TimeoutError:
            proc.kill()
            await proc.wait()
            raise RuntimeError(f"gh {args[0] if args else ''} timed out") from None
        if proc.returncode != 0:
            detail = " ".join((stderr or b"").decode("utf-8", "replace").split())[:300]
            raise RuntimeError(f"gh exited {proc.returncode}: {detail}")
        return (stdout or b"").decode("utf-8", "replace")

    async def _gh_json(self, args: list[str]) -> Any:
        raw = await self._gh_runner(args)
        try:
            return json.loads(raw or "null")
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"gh returned non-JSON output: {exc}") from exc

    async def _unresolved_threads(self, slug: str, number: int) -> int:
        """Count unresolved, non-outdated review threads, walking every page.

        An outdated thread no longer points at live code and GitHub does not hold
        it against ``required_review_thread_resolution``, so counting it would send
        the workflow chasing a comment it cannot act on.
        """
        owner, _, name = slug.partition("/")
        cursor: str | None = None
        total = 0
        for _ in range(_MAX_THREAD_PAGES):
            args = [
                "api",
                "graphql",
                "-f",
                f"owner={owner}",
                "-f",
                f"name={name}",
                "-F",
                f"number={number}",
                "-f",
                f"query={_THREAD_QUERY}",
            ]
            if cursor:
                args += ["-f", f"cursor={cursor}"]
            payload = await self._gh_json(args)
            threads = (
                ((payload or {}).get("data") or {})
                .get("repository", {})
                .get("pullRequest", {})
                .get("reviewThreads", {})
            )
            for node in threads.get("nodes") or []:
                if not isinstance(node, dict):
                    continue
                if not node.get("isResolved") and not node.get("isOutdated"):
                    total += 1
            page = threads.get("pageInfo") or {}
            if not page.get("hasNextPage"):
                return total
            cursor = str(page.get("endCursor") or "") or None
            if not cursor:
                return total
        logger.warning(
            "github_pr_scanner: stopped paginating PR #{} after {} pages", number, _MAX_THREAD_PAGES
        )
        return total

    # ── classification ───────────────────────────────────────────────────────

    @staticmethod
    def _classify(*, is_draft: bool, checks: list[dict[str, Any]], unresolved: int) -> str:
        """One of ``needs_action`` / ``waiting`` / ``clean``.

        Only ``--required`` checks are passed in. ``copilot-review-gate`` and
        ``CodeQL`` run and report but are not in the ruleset's required contexts,
        so treating them as gates would stall every PR on advisory signal.
        """
        if is_draft:
            # A draft receives zero Copilot review while the gate reports success,
            # so it can sit indefinitely looking converged. Always actionable.
            return "needs_action"
        buckets = [str(c.get("bucket") or "").strip().casefold() for c in checks]
        if any(b == "fail" for b in buckets):
            return "needs_action"
        if unresolved > 0:
            return "needs_action"
        if not checks or any(b in {"pending", ""} for b in buckets):
            return "waiting"
        return "clean"

    @staticmethod
    def _safe_command_value(value: Any) -> str:
        text = str(value or "").strip()
        if not text:
            return ""
        if "=" in text or any(ch.isspace() for ch in text):
            # Keep the imBack payload one physical line. JSON quoting escapes
            # CR/LF and backslashes instead of letting a value smuggle extra
            # tokens into the command the click will run.
            return json.dumps(text, ensure_ascii=False)
        return text

    def _resume_command(
        self, *, workflow_name: str, pr_number: int, plans: list[Any], plan_owner: str
    ) -> str:
        """The exact ``resume workflow …`` command, or "" when none applies.

        Requires a Plan that is this workflow's, owned by this conversation, not
        superseded, whose **Review** item is `blocked` — i.e. a run that parked
        itself waiting for exactly this observation — and whose evidence names this
        PR. Anything looser would offer to resume an unrelated run.
        """
        for plan in plans:
            if str(getattr(plan, "workflow", "") or "") != workflow_name:
                continue
            if not plan_owner or str(getattr(plan, "owner", "") or "") != plan_owner:
                continue
            if bool(getattr(plan, "superseded", False)):
                continue
            task_id = self._safe_command_value(getattr(plan, "origin_task", ""))
            if not task_id:
                continue
            items = list(getattr(plan, "items", None) or [])
            if not any(
                str(getattr(item, "title", "") or "").strip().casefold() == "review"
                and str(getattr(item, "status", "") or "") == "blocked"
                for item in items
            ):
                continue
            evidence = " ".join(
                str(getattr(item, field, "") or "")
                for item in items
                for field in ("acceptance", "note", "evidence")
            )
            if str(pr_number) not in evidence:
                continue
            command = f"resume workflow {workflow_name} task_id={task_id}"
            params = getattr(plan, "params", None) or getattr(plan, "workflow_params", None)
            params = params if isinstance(params, dict) else {}
            for key in ("issue_query", "issue_number"):
                mapped = self._safe_command_value(params.get(key))
                if mapped:
                    command += f" {key}={mapped}"
            return command
        return ""

    # ── execute ──────────────────────────────────────────────────────────────

    async def execute(self, **kwargs: Any) -> str:
        async with self._state_lock:
            return await self._execute_locked(**kwargs)

    async def _execute_locked(self, **kwargs: Any) -> str:
        errors = self.validate(kwargs)
        if errors:
            return "Error: " + "; ".join(errors)
        slug = str(kwargs["repo_slug"]).strip()
        author = str(kwargs["author"]).strip()
        prefix = str(kwargs["branch_prefix"]).strip()
        workflow_name = str(kwargs["workflow_name"]).strip()

        metadata = kwargs.get("_metadata")
        plan_owner = (
            str(metadata.get("plan_owner") or "").strip()[:200]
            if isinstance(metadata, dict)
            else ""
        )
        try:
            plans = list(self._plans_fn() or []) if plan_owner else []
        except Exception:
            plans = []

        try:
            listed = await self._gh_json(
                [
                    "pr",
                    "list",
                    "--repo",
                    slug,
                    "--author",
                    author,
                    "--state",
                    "open",
                    "--limit",
                    str(_MAX_PRS),
                    "--json",
                    "number,title,url,headRefName,headRefOid,isDraft",
                ]
            )
        except Exception as exc:
            # A failed scan must not look like "nothing to do": say so, and leave
            # the previous snapshot alone so the next tick can still diff.
            return f"⚠️ PR watcher could not list pull requests: {' '.join(str(exc).split())[:300]}"

        watched = [
            pr
            for pr in (listed or [])
            if isinstance(pr, dict) and str(pr.get("headRefName") or "").startswith(prefix)
        ]
        if not watched:
            return ""

        state = self._load_state()
        seen: dict[str, str] = dict(state.get("seen") or {})
        fresh: dict[str, str] = {}
        actionable: list[tuple[dict[str, Any], str, int, list[str]]] = []
        problems: list[str] = []

        for pr in watched:
            number = int(pr.get("number") or 0)
            if number <= 0:
                continue
            head = str(pr.get("headRefOid") or "")
            is_draft = bool(pr.get("isDraft"))
            try:
                checks = await self._gh_json(
                    [
                        "pr",
                        "checks",
                        str(number),
                        "--repo",
                        slug,
                        "--required",
                        "--json",
                        "name,state,bucket",
                    ]
                )
                checks = [c for c in (checks or []) if isinstance(c, dict)]
            except Exception as exc:
                # `gh pr checks` exits non-zero when a check is failing, which is
                # information, not an error — but it also exits non-zero when no
                # checks exist yet. Either way the PR is not clean; treat it as
                # waiting rather than inventing a verdict.
                problems.append(
                    f"#{number}: checks unreadable ({' '.join(str(exc).split())[:120]})"
                )
                checks = []
            try:
                unresolved = await self._unresolved_threads(slug, number)
            except Exception as exc:
                problems.append(
                    f"#{number}: threads unreadable ({' '.join(str(exc).split())[:120]})"
                )
                unresolved = 0
            verdict = self._classify(is_draft=is_draft, checks=checks, unresolved=unresolved)
            # Signature includes the head commit, so a push re-opens a PR that had
            # already been reported: the previous verdict was about different code.
            signature = f"{head}:{verdict}:{unresolved}"
            fresh[str(number)] = signature
            if verdict != "needs_action" or seen.get(str(number)) == signature:
                continue
            failed = [
                str(c.get("name") or "")
                for c in checks
                if str(c.get("bucket") or "").strip().casefold() == "fail"
            ]
            actionable.append((pr, verdict, unresolved, failed))

        self._save_state({"seen": fresh})

        if not actionable:
            return ""

        # Oldest PR first: the one that has been waiting longest is the one whose
        # worktree and branch are most likely to be reused by something else.
        pr, _verdict, unresolved, failed = min(actionable, key=lambda item: int(item[0]["number"]))
        number = int(pr["number"])
        reasons: list[str] = []
        if bool(pr.get("isDraft")):
            reasons.append("still a draft (Copilot will not review it)")
        if failed:
            reasons.append("failed required checks: " + ", ".join(sorted(failed)[:5]))
        if unresolved:
            reasons.append(f"{unresolved} unresolved review thread(s)")
        body = (
            f"🔧 PR #{number} needs a cycle — {'; '.join(reasons) or 'needs attention'}.\n"
            f"{pr.get('title') or ''}\n{pr.get('url') or ''}"
        )
        command = self._resume_command(
            workflow_name=workflow_name, pr_number=number, plans=plans, plan_owner=plan_owner
        )
        if problems:
            body += "\n(partial scan: " + "; ".join(problems[:3]) + ")"
        if not command:
            # No resumable Plan — say what is wrong and let the human decide. Do
            # NOT offer a fresh `run`: that would restart a finished workflow at
            # Pick up and open a second PR for the same issue.
            return body + "\nNo resumable run found for this PR; drive it by hand."
        return _card(body, f"▶️ Continue PR #{number}", command)
