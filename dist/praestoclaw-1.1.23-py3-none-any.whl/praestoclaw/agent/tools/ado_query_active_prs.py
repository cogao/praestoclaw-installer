"""Read-only Azure DevOps query triage by linked active pull requests."""

from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import tempfile
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any
from urllib.parse import quote, unquote, urlsplit

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.risk import RiskAssessment, RiskScore

_SAVED_QUERY_RE = re.compile(r"^saved:([0-9a-fA-F-]{36})$")
_ADO_ORG_RE = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9-]{0,62}[A-Za-z0-9])?$")
_VSTFS_PR_RE = re.compile(
    r"^vstfs:///Git/PullRequestId/([^/]+)/([^/]+)/(\d+)$",
    re.IGNORECASE,
)
_WORK_ITEM_BATCH_SIZE = 200
_ACTIVE_PR_PAGE_SIZE = 1000
_DEFAULT_MAX_ITEMS = 1000
_MAX_ITEMS = 5000
_DEFAULT_RESULT_ITEM_LIMIT = 50
_MAX_RESULT_ITEM_LIMIT = 200
_ADO_RESOURCE = "499b84ac-1321-427f-aa17-267ca6975798"

AzRunner = Callable[[list[str]], Awaitable[str]]


@dataclass(frozen=True)
class _PullRequestRef:
    project: str
    repository: str
    pull_request_id: int


@dataclass(frozen=True)
class _ProjectRef:
    project_id: str
    name: str


def _compact_error(exc: Exception) -> str:
    text = " ".join(str(exc).split())
    return (text or type(exc).__name__)[:300]


def _normalize_organization(value: Any) -> str | None:
    text = str(value or "").strip()
    try:
        parsed = urlsplit(text)
        port = parsed.port
    except ValueError:
        return None
    if (
        parsed.scheme.casefold() != "https"
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or port is not None
        or parsed.query
        or parsed.fragment
    ):
        return None
    host = parsed.hostname.casefold()
    path = parsed.path.rstrip("/")
    if host == "dev.azure.com":
        match = re.fullmatch(r"/([^/]+)", path)
        if match is None or _ADO_ORG_RE.fullmatch(match.group(1)) is None:
            return None
        return f"https://dev.azure.com/{match.group(1)}"
    suffix = ".visualstudio.com"
    if not host.endswith(suffix) or path:
        return None
    organization = host.removesuffix(suffix)
    if _ADO_ORG_RE.fullmatch(organization) is None:
        return None
    return f"https://{organization}.visualstudio.com"


def _pull_request_ref(
    relation: dict[str, Any], *, organization: str, default_project: str
) -> _PullRequestRef | None:
    url = unquote(str(relation.get("url") or ""))
    match = _VSTFS_PR_RE.fullmatch(url)
    if match is not None:
        return _PullRequestRef(match.group(1), match.group(2), int(match.group(3)))
    try:
        parsed = urlsplit(url)
    except ValueError:
        return None
    if parsed.scheme.casefold() != "https" or not url.casefold().startswith(
        organization.rstrip("/").casefold() + "/"
    ):
        return None
    segments = [segment for segment in parsed.path.split("/") if segment]
    folded = [segment.casefold() for segment in segments]
    try:
        api_index = folded.index("_apis")
        repository_index = folded.index("repositories", api_index)
        pull_requests_index = folded.index("pullrequests", repository_index)
        repository = segments[repository_index + 1]
        pull_request_id = int(segments[pull_requests_index + 1])
    except (ValueError, IndexError):
        return None
    project = segments[api_index - 1] if api_index > 0 else default_project
    return _PullRequestRef(project, repository, pull_request_id)


def _looks_like_pull_request_relation(relation: dict[str, Any]) -> bool:
    attributes = relation.get("attributes")
    name = str(attributes.get("name") or "") if isinstance(attributes, dict) else ""
    return (
        str(relation.get("rel") or "").strip().casefold() == "artifactlink"
        and name.strip().casefold() == "pull request"
    )


def _compact_text(value: Any, limit: int = 300) -> str:
    return " ".join(str(value or "").split())[:limit]


class AdoQueryActivePrsTool(Tool):
    """Inspect an ordered ADO work-item query for linked active pull requests."""

    risk_range = (3, 3)

    def __init__(self, *, az_runner: AzRunner | None = None) -> None:
        self._az_runner = az_runner or self._run_az

    @property
    def name(self) -> str:
        return "ado_query_active_prs"

    @property
    def description(self) -> str:
        return (
            "Read an Azure DevOps saved query or WIQL in any project, preserve its work-item "
            "order, and identify items with or without linked active pull requests."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "organization": {"type": "string"},
                "project": {"type": "string"},
                "source": {
                    "type": "string",
                    "description": "saved:<GUID> or wiql:<query>",
                },
                "max_items": {"type": "integer", "minimum": 1, "maximum": _MAX_ITEMS},
                "result_item_limit": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": _MAX_RESULT_ITEM_LIMIT,
                    "description": "Maximum ordered item details returned; summary is unaffected.",
                },
                "stop_at_first_without_active_pr": {"type": "boolean"},
            },
            "required": ["organization", "project", "source"],
            "additionalProperties": False,
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=600)

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(3, reason="Read-only Azure DevOps work-item and pull-request queries")

    def validate(self, args: dict[str, Any]) -> list[str]:
        errors: list[str] = []
        organization = str(args.get("organization") or "").strip()
        if not organization:
            errors.append("organization is required")
        elif _normalize_organization(organization) is None:
            errors.append(
                "organization must be https://dev.azure.com/<org> or https://<org>.visualstudio.com"
            )
        if not str(args.get("project") or "").strip():
            errors.append("project is required")
        source = str(args.get("source") or "").strip()
        if not source:
            errors.append("source is required")
        elif source.startswith("wiql:"):
            if not source.removeprefix("wiql:").strip():
                errors.append("WIQL source must not be empty")
        elif _SAVED_QUERY_RE.fullmatch(source) is None:
            errors.append("source must be saved:<GUID> or wiql:<query>")
        max_items = args.get("max_items", _DEFAULT_MAX_ITEMS)
        if (
            isinstance(max_items, bool)
            or not isinstance(max_items, int)
            or not 1 <= max_items <= _MAX_ITEMS
        ):
            errors.append(f"max_items must be an integer between 1 and {_MAX_ITEMS}")
        result_item_limit = args.get("result_item_limit", _DEFAULT_RESULT_ITEM_LIMIT)
        if (
            isinstance(result_item_limit, bool)
            or not isinstance(result_item_limit, int)
            or not 0 <= result_item_limit <= _MAX_RESULT_ITEM_LIMIT
        ):
            errors.append(
                f"result_item_limit must be an integer between 0 and {_MAX_RESULT_ITEM_LIMIT}"
            )
        stop_early = args.get("stop_at_first_without_active_pr", True)
        if not isinstance(stop_early, bool):
            errors.append("stop_at_first_without_active_pr must be a boolean")
        return errors

    @staticmethod
    async def _run_az(args: list[str]) -> str:
        executable = shutil.which("az")
        if not executable:
            raise RuntimeError("Azure CLI 'az' was not found")
        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        process = await asyncio.create_subprocess_exec(
            executable,
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )
        try:
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=120)
        except TimeoutError:
            process.kill()
            await process.wait()
            raise RuntimeError(f"az {' '.join(args[:3])} timed out") from None
        except asyncio.CancelledError:
            try:
                process.kill()
            except ProcessLookupError:
                pass
            await process.wait()
            raise
        if process.returncode != 0:
            detail = (stderr or stdout).decode("utf-8", errors="replace").strip()
            raise RuntimeError(detail or f"az exited with {process.returncode}")
        return stdout.decode("utf-8-sig", errors="replace")

    async def _az_json(self, args: list[str]) -> Any:
        raw = await self._az_runner(args)
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Azure CLI returned invalid JSON: {exc.msg}") from exc

    async def _resolve_project(self, organization: str, project: str) -> _ProjectRef:
        payload = await self._az_json(
            [
                "devops",
                "project",
                "show",
                "--project",
                project,
                "--org",
                organization,
                "-o",
                "json",
                "--only-show-errors",
            ]
        )
        if not isinstance(payload, dict):
            raise RuntimeError("Azure DevOps project response is not an object")
        project_id = str(payload.get("id") or "").strip()
        name = str(payload.get("name") or "").strip()
        if not project_id or not name:
            raise RuntimeError("Azure DevOps project response is missing id or name")
        return _ProjectRef(project_id=project_id, name=name)

    async def _query_work_item_ids(
        self,
        source: str,
        *,
        organization: str,
        project: _ProjectRef,
        max_items: int,
    ) -> tuple[list[int], bool]:
        top = max_items + 1
        saved = _SAVED_QUERY_RE.fullmatch(source)
        if saved is not None:
            project_path = quote(project.project_id, safe="")
            query_id = quote(saved.group(1), safe="")
            payload = await self._az_json(
                [
                    "rest",
                    "--method",
                    "get",
                    "--resource",
                    _ADO_RESOURCE,
                    "--url",
                    (
                        f"{organization.rstrip('/')}/{project_path}/_apis/wit/wiql/"
                        f"{query_id}?$top={top}&api-version=7.1"
                    ),
                    "-o",
                    "json",
                    "--only-show-errors",
                ]
            )
        else:
            fd, request_path = tempfile.mkstemp(prefix="ado-wiql-", suffix=".json")
            try:
                with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
                    json.dump({"query": source.removeprefix("wiql:")}, stream)
                payload = await self._az_json(
                    [
                        "devops",
                        "invoke",
                        "--area",
                        "wit",
                        "--resource",
                        "wiql",
                        "--route-parameters",
                        f"project={project.project_id}",
                        "--query-parameters",
                        f"$top={top}",
                        "--http-method",
                        "POST",
                        "--in-file",
                        request_path,
                        "--api-version",
                        "7.1",
                        "--org",
                        organization,
                        "-o",
                        "json",
                        "--only-show-errors",
                    ]
                )
            finally:
                try:
                    os.unlink(request_path)
                except OSError:
                    pass
        rows = payload.get("workItems") if isinstance(payload, dict) else None
        if not isinstance(rows, list):
            if isinstance(payload, dict) and payload.get("workItemRelations") is not None:
                raise RuntimeError("Azure DevOps query must be a flat work-item query")
            raise RuntimeError("Azure DevOps query response has no workItems array")
        work_item_ids: list[int] = []
        seen: set[int] = set()
        for row in rows:
            if not isinstance(row, dict) or row.get("id") is None:
                raise RuntimeError("Azure DevOps query returned an item without an id")
            work_item_id = int(row["id"])
            if work_item_id not in seen:
                seen.add(work_item_id)
                work_item_ids.append(work_item_id)
        continuation = (
            bool(payload.get("continuation_token")) if isinstance(payload, dict) else False
        )
        return work_item_ids, continuation or len(work_item_ids) > max_items

    async def _hydrate_work_items(
        self,
        work_item_ids: list[int],
        *,
        organization: str,
        project: str,
    ) -> list[dict[str, Any]]:
        fd, request_path = tempfile.mkstemp(prefix="ado-workitems-", suffix=".json")
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
                json.dump({"ids": work_item_ids, "$expand": "All"}, stream)
            payload = await self._az_json(
                [
                    "devops",
                    "invoke",
                    "--area",
                    "wit",
                    "--resource",
                    "workitemsbatch",
                    "--route-parameters",
                    f"project={project}",
                    "--http-method",
                    "POST",
                    "--in-file",
                    request_path,
                    "--api-version",
                    "7.1",
                    "--org",
                    organization,
                    "-o",
                    "json",
                    "--only-show-errors",
                ]
            )
        finally:
            try:
                os.unlink(request_path)
            except OSError:
                pass
        rows = payload.get("value") if isinstance(payload, dict) else payload
        if not isinstance(rows, list):
            raise RuntimeError("Azure DevOps work-item batch response is not an array")
        by_id: dict[int, dict[str, Any]] = {}
        for row in rows:
            if not isinstance(row, dict) or row.get("id") is None:
                raise RuntimeError("Azure DevOps work-item batch returned an item without an id")
            work_item_id = int(row["id"])
            if work_item_id in by_id:
                raise RuntimeError(
                    f"Azure DevOps work-item batch returned duplicate id {work_item_id}"
                )
            by_id[work_item_id] = row
        missing = [work_item_id for work_item_id in work_item_ids if work_item_id not in by_id]
        if missing:
            joined = ", ".join(str(work_item_id) for work_item_id in missing[:10])
            raise RuntimeError(f"Azure DevOps work-item batch omitted id(s): {joined}")
        return [by_id[work_item_id] for work_item_id in work_item_ids]

    async def _list_active_pull_requests(
        self,
        *,
        organization: str,
        project: str,
        repository: str,
    ) -> dict[int, dict[str, Any]]:
        active: dict[int, dict[str, Any]] = {}
        skip = 0
        while True:
            rows = await self._az_json(
                [
                    "repos",
                    "pr",
                    "list",
                    "--org",
                    organization,
                    "--project",
                    project,
                    "--repository",
                    repository,
                    "--status",
                    "active",
                    "--top",
                    str(_ACTIVE_PR_PAGE_SIZE),
                    "--skip",
                    str(skip),
                    "-o",
                    "json",
                    "--only-show-errors",
                ]
            )
            if not isinstance(rows, list):
                raise RuntimeError(
                    f"active PR response for repository {repository} is not an array"
                )
            for row in rows:
                if not isinstance(row, dict) or row.get("pullRequestId") is None:
                    raise RuntimeError(
                        f"active PR response for repository {repository} has an invalid item"
                    )
                pull_request_id = int(row["pullRequestId"])
                status = str(row.get("status") or "active")
                if status.casefold() != "active":
                    continue
                active[pull_request_id] = {
                    "id": pull_request_id,
                    "status": "active",
                    "title": _compact_text(row.get("title")),
                    "project": project,
                    "repository": repository,
                }
            if len(rows) < _ACTIVE_PR_PAGE_SIZE:
                break
            skip += _ACTIVE_PR_PAGE_SIZE
        return active

    async def execute(self, **kwargs: Any) -> str:
        errors = self.validate(kwargs)
        if errors:
            return "Error: " + "; ".join(errors)
        organization = _normalize_organization(kwargs["organization"])
        if organization is None:
            return "Error: invalid organization"
        requested_project = str(kwargs["project"]).strip()
        source = str(kwargs["source"]).strip()
        max_items = int(kwargs.get("max_items", _DEFAULT_MAX_ITEMS))
        result_item_limit = int(kwargs.get("result_item_limit", _DEFAULT_RESULT_ITEM_LIMIT))
        stop_early = kwargs.get("stop_at_first_without_active_pr", True)
        try:
            project = await self._resolve_project(organization, requested_project)
            work_item_ids, query_truncated = await self._query_work_item_ids(
                source,
                organization=organization,
                project=project,
                max_items=max_items,
            )

            items: list[dict[str, Any]] = []
            first_without_active_pr: dict[str, Any] | None = None
            active_by_repo: dict[tuple[str, str], dict[int, dict[str, Any]]] = {}
            considered_ids = work_item_ids[:max_items]
            for offset in range(0, len(considered_ids), _WORK_ITEM_BATCH_SIZE):
                batch_ids = considered_ids[offset : offset + _WORK_ITEM_BATCH_SIZE]
                details_batch = await self._hydrate_work_items(
                    batch_ids,
                    organization=organization,
                    project=project.project_id,
                )
                for work_item_id, details in zip(batch_ids, details_batch, strict=True):
                    fields = details.get("fields")
                    fields = fields if isinstance(fields, dict) else {}
                    team_project = str(fields.get("System.TeamProject") or "").strip()
                    if team_project.casefold() != project.name.casefold():
                        raise RuntimeError(
                            f"work item {work_item_id} is outside requested project "
                            f"{project.name!r}: {team_project or '(missing)'}"
                        )
                    title = _compact_text(fields.get("System.Title"), 500)
                    relations = details.get("relations") or []
                    if not isinstance(relations, list):
                        raise RuntimeError(f"work item {work_item_id} relations are not an array")
                    pull_request_refs: list[_PullRequestRef] = []
                    seen_pull_requests: set[_PullRequestRef] = set()
                    for relation in relations:
                        if not isinstance(relation, dict) or not _looks_like_pull_request_relation(
                            relation
                        ):
                            continue
                        pull_request_ref = _pull_request_ref(
                            relation,
                            organization=organization,
                            default_project=project.project_id,
                        )
                        if pull_request_ref is None:
                            raise RuntimeError(
                                f"work item {work_item_id} has an unrecognized "
                                "pull-request relation"
                            )
                        if pull_request_ref not in seen_pull_requests:
                            seen_pull_requests.add(pull_request_ref)
                            pull_request_refs.append(pull_request_ref)

                    active_pull_requests: list[dict[str, Any]] = []
                    for pull_request_ref in pull_request_refs:
                        repo_key = (pull_request_ref.project, pull_request_ref.repository)
                        if repo_key not in active_by_repo:
                            active_by_repo[repo_key] = await self._list_active_pull_requests(
                                organization=organization,
                                project=pull_request_ref.project,
                                repository=pull_request_ref.repository,
                            )
                        active = active_by_repo[repo_key].get(pull_request_ref.pull_request_id)
                        if active is not None:
                            active_pull_requests.append(active)

                    item = {
                        "id": work_item_id,
                        "title": title,
                        "linked_pull_requests": [
                            {
                                "id": pull_request_ref.pull_request_id,
                                "project": pull_request_ref.project,
                                "repository": pull_request_ref.repository,
                            }
                            for pull_request_ref in pull_request_refs
                        ],
                        "active_pull_requests": active_pull_requests,
                    }
                    items.append(item)
                    if not active_pull_requests and first_without_active_pr is None:
                        first_without_active_pr = {"id": work_item_id, "title": title}
                        if stop_early:
                            break
                if stop_early and first_without_active_pr is not None:
                    break

            inspected_count = len(items)
            considered_count = min(len(work_item_ids), max_items)
            # Measured against what the scan was allowed to inspect
            # (`work_item_ids[:max_items]`), not the full query: a candidate on the
            # last considered item did not stop anything early, it ran out of
            # window. `truncated` carries the "there are more rows" signal.
            stopped_early = bool(
                stop_early
                and first_without_active_pr is not None
                and inspected_count < considered_count
            )
            truncated = query_truncated or (
                len(work_item_ids) > max_items and inspected_count >= considered_count
            )
            returned_items = items[:result_item_limit]
            payload = {
                "first_without_active_pr": first_without_active_pr,
                "organization": organization,
                "project": project.name,
                "project_id": project.project_id,
                "source": source,
                "query_count": len(work_item_ids),
                "query_count_is_lower_bound": query_truncated,
                "inspected_count": inspected_count,
                "complete": not stopped_early and not truncated,
                "stopped_early": stopped_early,
                "truncated": truncated,
                "returned_item_count": len(returned_items),
                "items_omitted": inspected_count - len(returned_items),
                "items": returned_items,
            }
            return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        except Exception as exc:
            return "Error: Azure DevOps active-PR query failed: " + _compact_error(exc)
