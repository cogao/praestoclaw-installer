"""Fixed, read-only approval recovery operation on the existing agent link."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

APPROVAL_STATUS_TOPIC = "approval.status"


class ApprovalStatusRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    request_id: str = Field(min_length=1, max_length=256)


class ApprovalStatusResponse(ApprovalStatusRequest):
    status: Literal[
        "unknown",
        "pending",
        "approved",
        "approved_once",
        "approved_always",
        "denied",
        "timeout",
        "expired",
    ]
    allowlist_saved: bool | None = None
    resolver: str | None = None
    action: Literal["approve", "deny", "always"] | None = None

    @model_validator(mode="after")
    def validate_saved_outcome(self) -> "ApprovalStatusResponse":
        if self.status == "approved_always" and self.allowlist_saved is not True:
            raise ValueError("approved_always requires confirmed persistence")
        if self.status == "approved_once" and self.allowlist_saved is not False:
            raise ValueError("approved_once requires a confirmed save failure")
        if self.status in {"approved_always", "approved_once"}:
            if self.action != "always":
                raise ValueError("persistence outcomes require the always action")
        elif self.allowlist_saved is not None:
            raise ValueError("persistence requires a persistence-specific status")
        allowed_actions: dict[str, set[str | None]] = {
            "unknown": {None},
            "pending": {None, "always"},
            "approved": {None, "approve"},
            "denied": {None, "deny"},
            "timeout": {None},
            "expired": {None},
        }
        if self.status in allowed_actions and self.action not in allowed_actions[self.status]:
            raise ValueError("action contradicts the approval status")
        return self
