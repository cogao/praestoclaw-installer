"""
Tool base class — ABC with JSON Schema validation (inspired by HKUDS/nanobot).

Each tool defines:
- name, description, parameters (JSON Schema)
- metadata (isolation, timeout, streaming, tier)
- assess_risk(args) → RiskAssessment (v2 scoring)
- validate(args) → list of errors
- execute(**kwargs) → str
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

from praestoclaw.security.risk import RiskAssessment, RiskPrompt

# Type alias for progress callbacks — tools call this to emit incremental updates.
ProgressCallback = Callable[[str], Awaitable[None]]


@dataclass
class ToolMetadata:
    """Static properties for tool classification."""

    isolation: str = "process"  # process | container
    category: str = "builtin"  # builtin | mcp | subagent | custom
    timeout: int = 600  # Config default (seconds)
    streaming: bool = False
    tier: str = "core"  # core = always in schema, standard = on-demand activation
    max_output_chars: int = 0  # 0 = use global default from ToolOutputConfig


class Tool(ABC):
    """Abstract tool that can be called by the agent."""

    _progress: ProgressCallback | None = None

    def set_progress_callback(self, cb: ProgressCallback | None) -> None:
        """Inject an async progress callback. Called by the registry before execution."""
        self._progress = cb

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique tool name."""

    @property
    @abstractmethod
    def description(self) -> str:
        """Human-readable description shown to the LLM."""

    @property
    @abstractmethod
    def parameters(self) -> dict[str, Any]:
        """JSON Schema for the tool's input parameters."""

    @property
    def metadata(self) -> ToolMetadata:
        """Tool metadata for classification. Override in subclass."""
        return ToolMetadata()

    risk_range: tuple[int, int] = (0, 10)
    """(min, max) possible risk scores — portal display hint.
    Default (0, 10). Override per tool class attribute for accurate bounds.
    When min == max the tool has a fixed score; otherwise dynamic.
    """

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        """Assess the risk of a tool call with the given arguments.

        Override in subclass for deterministic scoring (return RiskScore).
        Default returns RiskPrompt — delegates to LLM scorer.

        Returns RiskScore for known-safe/known-dangerous patterns,
        RiskPrompt for ambiguous cases that need LLM evaluation.
        """
        return RiskPrompt(
            context=f"Tool: {self.name}. No assess_risk override — LLM fallback.",
            range=(3, 8),
            factors=(
                "3: Read-only query or search with no side effects",
                "4: Local state read with limited scope",
                "5: Create or modify a local resource",
                "6: Action visible to others or with external side effects",
                "7: Execute arbitrary code/query or broad-scope write",
                "8: Delete, revoke, or irreversible destructive operation",
            ),
        )

    def validate(self, args: dict[str, Any]) -> list[str]:
        """Validate args. Return list of error strings (empty = valid)."""
        return []

    def audit_args(self, args: dict[str, Any]) -> dict[str, Any]:
        """Return the argument projection safe to persist in the audit log."""
        return args

    @abstractmethod
    async def execute(self, **kwargs: Any) -> str:
        """Execute the tool and return a text result."""

    def to_openai_schema(self) -> dict[str, Any]:
        """Convert to OpenAI function-calling tool format."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }
