"""Launch Edge with a persistent profile, navigate to Teams Web, extract
``localStorage`` and return the parsed RT records.

Implementation notes from validation (``/tmp/full_e2e.py``, 2026-04-28)
and from porting Kosmos's ``BrowserSessionResolver``:

* Edge is required — bundled chromium loses the enterprise SSO cookies
  that let Teams login complete silently.
* On managed Windows machines, Playwright's own ``launch_persistent_context``
  triggers EDR / Defender for Endpoint to kill Edge's child processes
  (likely keyed on ``--enable-automation`` plus the ``playwright_driver``
  process tree). We avoid that by starting Edge with ``subprocess.Popen``
  ourselves and attaching via ``chromium.connect_over_cdp`` — the process
  tree then looks like a normal user-launched browser. Validated by
  ``/tmp/edge_subprocess_e2e.py`` on a managed Windows box.
* Teams Web's bootstrap navigates several times during SSO (302 →
  ``teams.cloud.microsoft`` → ``/v2/``). Each navigation destroys the
  current execution context, so ``page.evaluate`` may raise mid-flight.
  We tolerate that and retry until either the wait condition is met or
  the budget expires.
* **The MSAL RefreshToken lands in localStorage *before* AAD's backend
  session is fully registered.** If we send that RT to /token immediately
  we get ``invalid_grant``. Mirroring Kosmos's ``getSnapshotTokenPresence``
  check (BrowserSessionResolver.ts:128, .ts:547), we only return once an
  ``AccessToken`` entry is also present — that signals the session is
  live and any subsequent RT refresh will succeed.
* The persistent profile dir is owned by PraestoClaw (under ``data_dir``),
  separate from the user's main Edge profile. This avoids both lock
  contention with a running Edge instance and unintended access to the
  user's cookies / history / extensions.
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path

from loguru import logger

from praestoclaw.auth.m365.extractor import (
    RefreshTokenRecord,
    extract_refresh_tokens,
)

TEAMS_URL = "https://teams.microsoft.com/v2/"
DEFAULT_LOGIN_TIMEOUT_S = 120
DEFAULT_POLL_INTERVAL_S = 2.0
EDGE_STARTUP_TIMEOUT_S = 15  # how long we wait for Edge to bind the CDP port

# Suffix paths under platform-specific install prefixes — mirrors Playwright's
# registry/index.js channel resolution for "msedge" so we cover the same set
# of installations Playwright itself does.
_EDGE_WIN_SUFFIX = r"Microsoft\Edge\Application\msedge.exe"
_EDGE_MAC_PATH = "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"
_EDGE_LINUX_DEFAULT = "/opt/microsoft/msedge/msedge"


class PlaywrightSessionError(Exception):
    """Raised when the Edge session cannot produce a usable RT."""


_DUMP_LOCAL_STORAGE_JS = """() => {
    const out = {};
    for (const k of Object.keys(localStorage)) {
        out[k] = localStorage.getItem(k);
    }
    return out;
}"""


def _has_access_token(local_storage: dict[str, str]) -> bool:
    """True when localStorage contains at least one MSAL AccessToken entry.

    Presence of an AT means AAD has finished issuing tokens and any RT we
    pull out is safe to redeem at /oauth2/v2.0/token. Pulling an RT
    earlier than that yields ``invalid_grant`` because AAD hasn't fully
    registered the session yet.
    """
    for key in local_storage:
        if key.startswith("msal.2|") and "|accesstoken|" in key:
            return True
    return False


def _find_edge_binary() -> str | None:
    """Return the platform-specific path to Edge, or None when not found.

    Resolution order (mirrors Playwright's registry/index.js for the
    "msedge" channel, plus a few extensions):

      1. ``PRAESTOCLAW_EDGE_PATH`` env var (escape hatch for non-standard installs)
      2. ``shutil.which`` for ``msedge`` / ``microsoft-edge[-stable]``
         (covers Linux ``apt``/``dnf`` symlinks at ``/usr/bin/...``)
      3. Platform-specific well-known absolute path:
         * Windows — ``Microsoft\\Edge\\Application\\msedge.exe`` under each of
           %LOCALAPPDATA%, %PROGRAMFILES%, %PROGRAMFILES(X86)%
         * macOS — ``/Applications/Microsoft Edge.app/...``
         * Linux — ``/opt/microsoft/msedge/msedge``
    """
    env_override = os.environ.get("PRAESTOCLAW_EDGE_PATH")
    if env_override and Path(env_override).exists():
        return env_override

    for name in ("msedge", "microsoft-edge", "microsoft-edge-stable"):
        found = shutil.which(name)
        if found:
            return found

    if sys.platform == "win32":
        for prefix in (
            os.environ.get("LOCALAPPDATA"),
            os.environ.get("PROGRAMFILES"),
            os.environ.get("PROGRAMFILES(X86)"),
        ):
            if not prefix:
                continue
            candidate = Path(prefix) / _EDGE_WIN_SUFFIX
            if candidate.exists():
                return str(candidate)
    elif sys.platform == "darwin":
        if Path(_EDGE_MAC_PATH).exists():
            return _EDGE_MAC_PATH
    elif sys.platform == "linux":
        if Path(_EDGE_LINUX_DEFAULT).exists():
            return _EDGE_LINUX_DEFAULT

    return None


def _pick_free_port(preferred: int = 9224) -> int:
    """Return *preferred* if free, else any free port chosen by the OS."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", preferred))
            return preferred
    except OSError:
        pass
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def _wait_for_cdp_ready(port: int, timeout_s: int) -> bool:
    """Block until Edge's CDP endpoint responds healthily, or timeout.

    Polling ``GET /json/version`` is more reliable than a raw TCP connect
    check: the TCP socket starts accepting before Edge's CDP machinery is
    ready to serve commands, and Playwright's ``connect_over_cdp`` then
    times out waiting for the post-attach handshake to finish.
    """
    import urllib.error
    import urllib.request

    deadline = time.time() + timeout_s
    url = f"http://127.0.0.1:{port}/json/version"
    last_error: str | None = None
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=1.0) as resp:  # noqa: S310 — fixed http://127.0.0.1 URL
                if resp.status == 200:
                    return True
        except (urllib.error.URLError, OSError, TimeoutError) as exc:
            last_error = type(exc).__name__
            time.sleep(0.5)
    if last_error:
        logger.debug("[m365_auth] CDP /json/version still failing: {}", last_error)
    return False


async def _start_edge(argv: list[str]) -> subprocess.Popen:
    """Start Edge off-loop without losing the process handle to cancellation."""
    launch_task = asyncio.create_task(
        asyncio.to_thread(
            subprocess.Popen,  # noqa: S603 — caller supplies a resolved Edge binary
            argv,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    )
    try:
        return await asyncio.shield(launch_task)
    except asyncio.CancelledError:
        # Popen cannot be cancelled once its worker has started. Wait for its
        # handle and terminate it before propagating cancellation, otherwise a
        # browser created just after cancellation would be orphaned.
        proc = await launch_task
        await _kill_async(proc)
        raise


async def _kill_async(proc: subprocess.Popen) -> None:
    """Run best-effort process cleanup off-loop and let it finish if cancelled."""
    cleanup_task = asyncio.create_task(asyncio.to_thread(_kill, proc))
    try:
        await asyncio.shield(cleanup_task)
    except asyncio.CancelledError:
        # Cancelling ``to_thread`` does not stop its worker. Keep ownership of
        # the cleanup until proc.wait() has completed, then propagate.
        await cleanup_task
        raise


async def acquire_refresh_tokens(
    profile_dir: Path,
    *,
    headless: bool = False,
    timeout_s: int = DEFAULT_LOGIN_TIMEOUT_S,
) -> list[RefreshTokenRecord]:
    """Launch Edge, wait for Teams Web to populate localStorage, return RTs.

    *profile_dir* is created if missing. *headless* is currently ignored —
    we always run a visible window because the visible / headless distinction
    only matters for Playwright's own ``launch_persistent_context``, which
    we no longer use. (Headless via ``--headless=new`` could be added later
    for re-extraction passes if needed.)

    Returns an empty list if the wait condition (RT + AT present) is not
    met within *timeout_s*. The caller should fall back to another
    strategy in that case.
    """
    del headless  # reserved for future use

    # Suppress Node deprecation warnings emitted by Playwright's bundled
    # driver (e.g. DEP0169 url.parse). Must be set before async_playwright
    # spawns the Node subprocess. Harmless for any other Node-driven code
    # in the same process.
    os.environ.setdefault("NODE_NO_WARNINGS", "1")

    try:
        from playwright.async_api import async_playwright
    except ImportError as exc:
        raise PlaywrightSessionError("playwright not installed") from exc

    edge_binary = _find_edge_binary()
    if edge_binary is None:
        raise PlaywrightSessionError(
            "Microsoft Edge not found. Install Edge or disable channels.cloud.m365_auth."
        )

    profile_dir.mkdir(parents=True, exist_ok=True)
    port = _pick_free_port()

    logger.info(
        "[m365_auth] launching Edge via subprocess (port={}, profile={})", port, profile_dir
    )
    proc = await _start_edge(
        [
            edge_binary,
            f"--remote-debugging-port={port}",
            f"--user-data-dir={profile_dir}",
            "--no-first-run",
            "--no-default-browser-check",
            TEAMS_URL,
        ]
    )
    try:
        if not await asyncio.to_thread(_wait_for_cdp_ready, port, EDGE_STARTUP_TIMEOUT_S):
            raise PlaywrightSessionError(
                f"Edge CDP endpoint on port {port} not ready within {EDGE_STARTUP_TIMEOUT_S}s"
            )

        async with async_playwright() as p:
            try:
                # 30s rather than 15s — macOS Edge with a brand-new
                # profile occasionally needs longer to settle the
                # post-attach handshake even after /json/version is up.
                browser = await p.chromium.connect_over_cdp(
                    f"http://127.0.0.1:{port}", timeout=30_000
                )
            except Exception as exc:
                raise PlaywrightSessionError(f"connect_over_cdp failed: {exc}") from exc

            try:
                ctx = browser.contexts[0] if browser.contexts else None
                if ctx is None:
                    logger.warning("[m365_auth] no browser context after attach")
                    return []

                # Pick the page Edge already opened on TEAMS_URL when available;
                # fall back to creating one.
                page = next(
                    (
                        pg
                        for pg in ctx.pages
                        if "teams" in pg.url.lower() or pg.url == "about:blank"
                    ),
                    None,
                )
                if page is None:
                    page = ctx.pages[0] if ctx.pages else await ctx.new_page()

                # Make sure we're pointed at Teams (Edge starts with TEAMS_URL,
                # but if we attached late the user may have navigated away).
                if "teams" not in page.url.lower() and "login" not in page.url.lower():
                    with contextlib.suppress(Exception):
                        await page.goto(TEAMS_URL, wait_until="domcontentloaded")

                return await _poll_until_session_live(page, timeout_s)
            finally:
                # On Windows, the msedge.exe we Popen'd is often a launcher
                # that forks the real browser process and exits. proc.kill()
                # then has nothing to kill. Send a CDP-level Browser.close
                # so whichever process actually owns the windows shuts them
                # down — works on macOS / Windows / Linux uniformly.
                with contextlib.suppress(Exception):
                    cdp = await browser.new_browser_cdp_session()
                    await cdp.send("Browser.close")
                with contextlib.suppress(Exception):
                    await browser.close()
    finally:
        await _kill_async(proc)


def _kill(proc: subprocess.Popen) -> None:
    """Best-effort terminate of the Edge subprocess."""
    if proc.poll() is not None:
        return
    try:
        proc.kill()
        proc.wait(timeout=5)
    except Exception as exc:  # noqa: BLE001 — best-effort cleanup
        logger.debug("[m365_auth] kill subprocess raised {}", type(exc).__name__)


async def _poll_until_session_live(page, timeout_s: int) -> list[RefreshTokenRecord]:
    """Poll localStorage until both an RT and an AccessToken are present.

    Tolerates ``Page.evaluate`` errors caused by mid-navigation execution
    context destruction. Returns the parsed RT list once the wait
    condition is satisfied, or an empty list on timeout.
    """
    deadline = asyncio.get_event_loop().time() + timeout_s
    iters = 0
    rt_seen_at: float | None = None
    while asyncio.get_event_loop().time() < deadline:
        iters += 1
        await asyncio.sleep(DEFAULT_POLL_INTERVAL_S)
        try:
            local_storage: dict[str, str] = await page.evaluate(_DUMP_LOCAL_STORAGE_JS)
        except Exception as exc:
            logger.debug(
                "[m365_auth] evaluate raised (likely mid-navigation): {}", type(exc).__name__
            )
            continue

        records = extract_refresh_tokens(local_storage)
        has_at = _has_access_token(local_storage)

        if records and rt_seen_at is None:
            rt_seen_at = asyncio.get_event_loop().time()
            logger.info(
                "[m365_auth] RT visible after {} polls; waiting for AccessToken to confirm session is live",
                iters,
            )

        if records and has_at:
            logger.info(
                "[m365_auth] Teams session ready after {} polls "
                "(RT + AccessToken both present, {} RT records)",
                iters,
                len(records),
            )
            return records

    if rt_seen_at is not None:
        logger.warning(
            "[m365_auth] RT appeared but no AccessToken within {}s — AAD session may still be initialising",
            timeout_s,
        )
    else:
        logger.warning("[m365_auth] no RT after {}s of polling", timeout_s)
    return []
