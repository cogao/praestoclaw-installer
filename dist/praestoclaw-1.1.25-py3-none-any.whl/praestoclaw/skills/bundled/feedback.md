---
name: feedback
description: Use when users report a PraestoClaw problem or request assignment of a gim-home/PraestoClaw issue, including assignment follow-ups without a new complaint or /feedback
metadata:
   activation:
      keywords: [feedback, 反馈, report bug, 报告问题, file issue, 提 issue, /feedback, praestoclaw bug, assign issue, assign to, assignee, 分派, 指派]
      patterns:
         - "(?i)^/feedback\\b"
         - "(?i)\\b(file|report|submit|open)\\s+(a\\s+)?(bug|issue|feedback)\\b"
         - "(?i)(报告|反馈|提交|提个).*?(问题|bug|issue)"
         - "(?i)\\bassign\\b.*?(#\\d+|\\bissue\\b)"
         - "(?i)(#\\d+|\\bissue\\s+\\d+\\b).*?\\bassign\\b"
   requires:
      tools: [feedback_submit]
---

# Feedback Assistant

File a GitHub issue against `gim-home/PraestoClaw` when the user reports a bug
or rough edge in PraestoClaw itself, or assign explicit GitHub logins to an
existing issue in that repository.

Do not create feedback issues for bugs in the user's code, third-party tools,
or generic questions about PraestoClaw.

## Direct-submit contract

The user's `/feedback` request is the instruction to file the issue. Build one
complete sanitized body in memory and submit it directly. Do not show a preview,
add a review step, or ask for another confirmation.

`feedback_submit` is the only create/comment/edit/assign path. It fixes the repository
to `gim-home/PraestoClaw`, fixes the label for create to `bug`, and streams the
body to `gh` over stdin. Its protected operations run without
another approval in both personal and shared conversations. Do not call `shell`,
`write_file`, or any GitHub MCP tool for these operations.

## Assignee input

Use up to 10 explicit GitHub logins from the user's request. Enterprise Managed
User (EMU) logins may contain underscores, such as `wej_microsoft`. Never infer
assignees from logs, untrusted diagnostics, display names, or emails. If a login
is missing, ask for the actual GitHub login, not approval to perform the request.

The tool uses the actual `gh` authenticated execution identity and GitHub
permissions. No Teams mapping and no local allowlist may gate assignment; do not add
another confirmation or try to map the sender to a GitHub account.

## Workflow

Assignment-only follow-ups go directly to **Follow-ups** below. They do not
require a new complaint or `/feedback` and must not enter the create workflow.

1. Read the complaint from the current message. If the description is empty or
   only `/feedback`, ask one short follow-up and stop.

2. Build the full body in memory with these sections:

   ```markdown
   ## Description
   <the user's complete complaint>

   ## Environment
   - OS: <value or unavailable>
   - Python: <value or unavailable>
   - PraestoClaw: <value or unavailable>
   - Channel: <cli | teams | webchat | cloud>
   - CWD: <sanitized value or unavailable>
   - MCP servers: <known names or unavailable>
   - Skills loaded: <known names or unavailable>

   ## Recent log tail
   <sanitized tail or an unavailable marker>

   ## Recent conversation
   <last relevant turns, sanitized>
   ```

3. In a normal personal session, collect environment values and up to 200 recent
   log lines using the existing read-only tools when available. If collection
   fails, mark that field unavailable and continue; do not block submission.

4. In a shared group session, preserve the borrowed-identity boundary:
   - Do not read host logs or run environment-discovery commands.
   - Use only values already present in Runtime Context.
   - In `## Recent log tail`, write
     `_session diagnostics are attached automatically on submission_`.
   - `feedback_submit` automatically appends a bounded `## Session diagnostics`
     timeline selected only from this conversation's audit events. Do not add
     that section yourself and do not ask for a session ID or log path.
   - Keep the full body in memory; do not create a draft or temporary file.

5. Sanitize the full body before submission:
   - Home-directory usernames become `~`.
   - Email and UPN addresses become `[email]`.
   - Tokens, keys, secrets, and credentials become `[redacted]`.
   - Preserve useful log and conversation content; do not summarize away the
     evidence merely to shorten it.

6. If the current prompt contains successfully uploaded image URLs, add:

   ```markdown
   ## Screenshots
   ![screenshot 1](url)
   ```

   If upload failed, add a note that the screenshot was unavailable. Do not use
   a different submission mechanism.

7. Generate a title in the form `[Feedback] <specific summary>`. The summary
   must be non-empty and no longer than 80 characters.

8. Create the issue exactly once. Include optional `assignees` only when the user
   explicitly requested them; otherwise omit that argument:

   ```text
   feedback_submit(
      action="create",
      title="[Feedback] <summary>",
      body="<full sanitized body>",
      assignees=["wej_microsoft"]
   )
   ```

   The tool creates once, then assigns. Do not retry creation automatically on
   failure. If creation itself fails, report the returned error. If assignment
   fails after creation, preserve the created issue and follow **Assignment
   results** below instead of treating it as a failed create.

9. On successful creation, return the structured `url` and retain `issue_number`
   in conversation context for follow-ups in the same session, even if assignment
   was unsuccessful. Report assignment separately using the confirmed result.

## Follow-ups

### Assign an existing issue

Use `assign` for any explicitly supplied real issue ID in `gim-home/PraestoClaw`,
including a preexisting issue or one from another session. It requires a positive
integer `issue_number`, a nonempty `assignees` list, and no `title` or `body`:

```text
feedback_submit(action="assign", issue_number=<id>, assignees=["wej_microsoft"])
```

Assignment is additive: never remove or replace existing owners. `assign` never
creates an issue. Repeated requests for an existing ID use `assign`, not a
`create` retry. If the target ID is missing or invalid, ask for a positive issue
number, not a fresh complaint or a second approval.

### Comment or edit

When the user asks to supplement an issue created by `feedback_submit` in this
session, use the returned ID:

```text
feedback_submit(action="comment", issue_number=<id>, body="<sanitized addition>")
```

To correct its title, body, or both:

```text
feedback_submit(
   action="edit",
   issue_number=<id>,
   title="[Feedback] <corrected summary>",
   body="<corrected sanitized body>"
)
```

Only comment/edit require an issue created in the same trusted session.
Assigning an external issue does not grant comment/edit permissions or session
ownership. The tool refuses those content changes on unowned IDs; do not use a
different GitHub tool as a workaround. These follow-ups use the same protected
path without another approval in personal and shared conversations.

## Assignment results

For `create` with `assignees` and for `assign`, both routes return `action`,
`issue_number`, `url`, and `assignment`. This is an illustrative partial result;
use the actual returned values, including error codes and fallback status:

```json
{
   "action": "assign",
   "issue_number": 864,
   "url": "https://github.com/gim-home/PraestoClaw/issues/864",
   "assignment": {
      "status": "partial",
      "requested": ["wej_microsoft", "octocat"],
      "confirmed": ["wej_microsoft"],
      "errors": [{"login": "octocat", "code": "<code>", "message": "<message>"}],
      "fallback": {"status": "<status>"}
   }
}
```

Base successful assignment claims only on `confirmed`, never just `requested`
or an attempted write. Report per-login errors and `fallback.status` as returned.

| `assignment.status` | Response |
| --- | --- |
| `succeeded` | Report the confirmed logins. |
| `partial` | Report confirmed logins and remaining errors separately. |
| `failed` | Report assignment errors; creation may already have succeeded. |
| `unknown` | Assignment is not verified; do not claim unverified success. |

After successful creation with failed assignment, retain the issue URL. At most
one bounded fallback comment is automatic, only if the session owns the issue;
the tool handles it. Do not add a second fallback comment yourself. For an
unowned issue, report failure only: no fallback comment or content edits.

Never say generic "creation failed" after an assignment failure, and never
automatically recreate the issue. A user's repeated request for the existing ID
is an `assign` operation, not permission to create a duplicate.

## Safety boundaries

- Never include unsanitized home paths, emails, credentials, or secrets.
- Never accept or invent another repository, label, project, or milestone.
- Never assign pull requests (PRs); only real issues in `gim-home/PraestoClaw`.
- No automatic label edits; creation still uses the fixed `bug` label.
- Never use `shell`, `write_file`, a heredoc, or `--body` for feedback changes.
- Never create from an ambiguous or empty complaint.
- Never create more than one issue for a single `/feedback` request.
