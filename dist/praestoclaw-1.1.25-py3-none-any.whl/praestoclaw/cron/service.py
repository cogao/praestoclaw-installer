"""
Scheduler service — unified trigger framework for cron, interval, and event jobs.

LLM jobs execute via AgentHost.submit_turn() — full tool hook pipeline applies.
Results recorded in run history and optionally delivered to notify_channels.

Based on nanobot (agent pipeline + HEARTBEAT.md + CronTool) and
OpenClaw (session modes + run history).
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import uuid
from collections.abc import Callable
from datetime import UTC, datetime
from inspect import isawaitable
from pathlib import Path
from threading import RLock
from typing import TYPE_CHECKING, Any

from loguru import logger

from praestoclaw.bus.events import EventType, OutboundMessage
from praestoclaw.config.schema import ChannelType, CronConfig
from praestoclaw.cron.heartbeat import JOB_NAME as _HEARTBEAT_JOB_NAME
from praestoclaw.cron.job import Job as _Job
from praestoclaw.cron.job import ScheduledKbCapability, prompt_requires_current_kb_scope
from praestoclaw.cron.job import detect_trigger_type as _detect_trigger_type
from praestoclaw.cron.job import normalize_channel_list as _normalize_channel_list
from praestoclaw.cron.job import parse_at_schedule as _parse_at_schedule
from praestoclaw.cron.job import safe_filename as _safe_filename
from praestoclaw.cron.preview import normalize_cron_for_apscheduler
from praestoclaw.host.resource_locks import tool_resource_lock
from praestoclaw.utils.helpers import get_data_dir
from praestoclaw.utils.limits import cap_output, positive_int


class BlockedJobError(RuntimeError):
    """A scheduled job could not satisfy an immutable capability requirement."""


def _resolve_tz(name: str | None) -> Any:
    """Resolve an IANA timezone name to a tzinfo. None → APScheduler default (tzlocal).

    Raises ValueError on an unknown IANA name so callers can return 400.
    """
    if not name:
        return None
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

    try:
        return ZoneInfo(name)
    except ZoneInfoNotFoundError as exc:
        raise ValueError(f"Unknown timezone: {name!r}") from exc


if TYPE_CHECKING:
    from praestoclaw.agent.loop_v2 import AgentLoopV2
    from praestoclaw.bus.queue import MessageBus
    from praestoclaw.host.agent_host import AgentHost


# ── Service ──────────────────────────────────────────────────────────────────


_LAST_ERROR_MAX_CHARS = 500
_RETIRED_PRAESTOCLAW_WATCHER = ("praestoclaw-pr-watcher", "github_pr_scanner_v1")


def _truncate_error(message: str | None) -> str | None:
    """Cap a persisted error message to 500 chars; empty/None → None."""
    if not message:
        return None
    return message[:_LAST_ERROR_MAX_CHARS]


class SchedulerService:
    """Unified scheduler: cron + interval + event triggers + heartbeat.

    LLM jobs execute via AgentHost.submit_turn() with the full hook pipeline.
    APScheduler imported lazily — not a hard dependency.
    """

    MAX_CONSECUTIVE_FAILURES = 5
    HISTORY_MAX_ENTRIES = 100
    CLOUD_NOTIFICATION_PUSH_TARGET = "teams"
    CLOUD_DELIVERY_ACK_TIMEOUT_SECONDS = 2
    MEGAPHONE_ALERT_PREFIXES = (
        "📢 **小喇叭提醒**",
        "📢 **Megaphone Alert**",
        "📢 小喇叭提醒",
        "📢 Megaphone Alert",
    )

    @staticmethod
    def _has_deliverable_result(result: str) -> bool:
        """Return true when a job result contains user-facing content."""
        return bool(result and result.strip() != "(no response)")

    @staticmethod
    def _message_fallback_channels(channel: ChannelType | None) -> list[str]:
        """Delivery targets for a message-mode job with no explicit channels.

        A message-mode reminder exists solely to notify the user, so an empty
        ``notify_channels`` list is always a mistake. Prefer the originating
        channel; fall back to all active channels ("*") when the origin is
        unknown, so the reminder is never silently dropped.
        """
        return [channel.value] if channel is not None else ["*"]

    @classmethod
    def _should_deliver_result(cls, job: _Job, result: str) -> bool:
        """Return true when a job result should be auto-delivered."""
        if not cls._has_deliverable_result(result):
            return False
        if job.name.startswith("megaphone-") and not job.message:
            return cls._extract_megaphone_alert(result) != ""
        return True

    @classmethod
    def _extract_megaphone_alert(cls, result: str) -> str:
        """Extract the Megaphone alert block from model output.

        Some runs may prepend non-alert text (for example planning prose)
        before the final markdown alert. Delivery should use only the alert
        block starting at the first known Megaphone header.
        """
        text = result.strip()
        if not text:
            return ""
        starts = [text.find(prefix) for prefix in cls.MEGAPHONE_ALERT_PREFIXES]
        starts = [idx for idx in starts if idx >= 0]
        if not starts:
            return ""
        return text[min(starts) :].strip()

    def __init__(
        self,
        config: CronConfig,
        bus: MessageBus | None = None,
        active_channels_fn: Any = None,
        channel_resolver: Callable[[ChannelType | str], Any] | None = None,
        *,
        data_dir: Path | None = None,
    ) -> None:
        self._config = config
        self._bus = bus
        self._active_channels_fn = active_channels_fn  # () -> list[str]
        self._channel_resolver = channel_resolver
        self._agent_loop: AgentLoopV2 | None = None
        self._agent_host: AgentHost | None = None
        # Resolves a workflow recipe name -> its current body (fresh at each fire).
        # Injected by runtime so a scheduled workflow always runs the latest recipe.
        self._recipe_resolver: Callable[[str], str | None] | None = None
        # Resolves a workflow recipe name -> its normalized capability limits
        # (Task 9): allowed_tools / max_runtime / max_output as workflow_* keys
        # (max_iterations is deferred — not emitted). Injected by runtime only when
        # the workflow feature is on; None → scheduled runs use the global defaults.
        self._limits_resolver: Callable[[str], dict[str, Any]] | None = None
        self._jobs: dict[str, _Job] = {}
        self._jobs_lock = RLock()
        self._scheduler: Any = None
        self._running = False
        self._event_subscriptions: list[
            tuple[str, EventType, Any]
        ] = []  # (job_name, event_type, handler)
        self._job_semaphore = asyncio.Semaphore(config.max_concurrent_jobs)
        # Buffered notifications for when no channel is active at delivery time
        self._pending_notifications: list[dict[str, Any]] = []
        self._pending_lock = asyncio.Lock()
        self._max_pending = 100

        # Daily run counters for HISTORY summary (per-job, per-day)
        self._daily_counts: dict[str, dict[str, Any]] = {}

        # Cron data: explicit data_dir > ~/.praestoclaw (user-level default)
        self._data_dir = data_dir or get_data_dir()
        self._cron_dir = self._data_dir / "cron"
        self._runs_dir = self._cron_dir / "runs"
        self._jobs_file = self._cron_dir / "jobs.json"

        # Load dynamic jobs (all jobs managed via CronTool, no config-defined jobs)
        self._load_dynamic_jobs()

    def set_agent_loop(self, agent_loop: AgentLoopV2) -> None:
        """Compatibility wiring for tests and embedders."""
        from praestoclaw.host.agent_host import AgentHost
        from praestoclaw.host.legacy_agent_runtime import AgentLoopRuntimeAdapter

        self._agent_loop = agent_loop
        agent_cfg = getattr(agent_loop, "_config", None)
        self._agent_host = AgentHost(
            agent_id=str(getattr(agent_cfg, "name", None) or "default"),
            inline_runtime=AgentLoopRuntimeAdapter(agent_loop),
        )

    def set_agent_host(self, host: AgentHost, *, agent_loop: AgentLoopV2) -> None:
        """Wire the canonical host plus loop-owned tool services."""
        self._agent_host = host
        self._agent_loop = agent_loop

    def set_recipe_resolver(self, resolver: Callable[[str], str | None]) -> None:
        """Wire the workflow-recipe resolver. Called by Runtime.

        ``resolver(name)`` returns the recipe's current body, or ``None`` if the
        recipe no longer exists. A job with ``workflow_recipe`` set resolves its
        prompt through this at each fire, so a scheduled workflow always runs the
        latest recipe (not a stale snapshot).
        """
        self._recipe_resolver = resolver

    def set_limits_resolver(self, resolver: Callable[[str], dict[str, Any]]) -> None:
        """Wire the workflow capability-limits resolver (Task 9). Called by Runtime.

        ``resolver(name)`` returns the recipe's normalized ``workflow_*`` limit
        keys (or ``{}`` when it declares none), resolved fresh at each fire so a
        scheduled run is bounded by the recipe's current limits — the same caps an
        on-demand run gets. Only wired when the workflow feature is enabled.
        """
        self._limits_resolver = resolver

    # ── Lifecycle ────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Load jobs, register heartbeat, start APScheduler."""
        if not self._config.enabled:
            logger.info("Scheduler disabled — skipping start")
            return

        try:
            from apscheduler.schedulers.asyncio import AsyncIOScheduler
        except ImportError:
            logger.warning("apscheduler not installed — scheduler will not run")
            return

        self._scheduler = AsyncIOScheduler()

        # Register all enabled jobs
        for job in self._jobs.values():
            if job.enabled:
                self._register_trigger(job)

        # Register heartbeat
        if self._config.heartbeat.enabled:
            self._register_heartbeat()

        self._scheduler.start()
        self._running = True

        # APScheduler keeps triggers in memory, so a process restart normally
        # forgets occurrences that passed while PraestoClaw was offline. Claim
        # one occurrence separately from last_run_at so a crash retries the same
        # catch-up without recording it again or pretending it completed.
        now = datetime.now(UTC)
        for job in self._jobs.values():
            if not job.enabled:
                continue
            pending_at = self._pending_catchup_occurrence(job, now=now)
            missed_at = pending_at or self._missed_cron_occurrence(job, now=now)
            if missed_at is None:
                continue
            if pending_at is None:
                job.pending_catchup_at = missed_at.isoformat()
                if job.dynamic:
                    self._persist_dynamic_jobs()
                run_id = missed_at.astimezone(UTC).strftime("%Y%m%dT%H%M%S")
                self._record_run(
                    job.name,
                    run_id,
                    "missed",
                    "Scheduler was offline; one catch-up run was queued at startup.",
                    0.0,
                    started_at=missed_at.astimezone(UTC),
                )
            asyncio.create_task(self._execute_job(job, is_catchup=True))
            logger.warning(
                "Cron job '{}' has pending occurrence {}; queued one catch-up run",
                job.name,
                missed_at.isoformat(),
            )

        # Flush buffered notifications when any channel (re)connects
        if self._bus:
            self._bus.events.on(EventType.CHANNEL_CONNECTED, self._on_channel_connected)

        logger.info(
            "Scheduler started ({} jobs, heartbeat={})",
            len([j for j in self._jobs.values() if j.enabled]),
            self._config.heartbeat.enabled,
        )

    async def stop(self) -> None:
        """Graceful shutdown."""
        if self._scheduler and self._running:
            self._scheduler.shutdown(wait=False)
            self._running = False
            # Unsubscribe event triggers
            if self._bus:
                for _name, event_type, handler in self._event_subscriptions:
                    self._bus.events.off(event_type, handler)
                self._bus.events.off(EventType.CHANNEL_CONNECTED, self._on_channel_connected)
            self._event_subscriptions.clear()
            # Flush pending daily summaries to HISTORY.md
            self.flush_all_daily_summaries()
            logger.info("Scheduler stopped")

    # ── Job management ───────────────────────────────────────────────────

    @staticmethod
    def _validate_schedule(schedule: str | int, *, timezone: str | None = None) -> None:
        """Validate schedule format. Raises ValueError on invalid input."""
        trigger_type = _detect_trigger_type(schedule)
        if trigger_type == "at":
            schedule_str = str(schedule).strip()
            if len(schedule_str) > 2 and schedule_str[2:3] == ":":
                value = schedule_str[3:]
                if not value:
                    raise ValueError(
                        f"Invalid at schedule '{schedule}'. "
                        "Use 'at', 'at:+SECONDS', or 'at:ISO_DATETIME'"
                    )
                if value.startswith("+"):
                    try:
                        delay = int(value[1:])
                    except ValueError:
                        raise ValueError(
                            f"Invalid at schedule '{schedule}'. "
                            "Use 'at', 'at:+SECONDS', or 'at:ISO_DATETIME'"
                        ) from None
                    if delay <= 0:
                        raise ValueError(f"Delay must be positive, got {delay}")
                elif value:
                    dt = _parse_at_schedule(str(schedule), timezone=timezone)
                    if dt is None:
                        raise ValueError(f"Invalid ISO datetime in schedule '{schedule}'") from None
                    if dt < datetime.now(UTC):
                        raise ValueError(f"Schedule time is in the past: {value}")
        elif trigger_type == "cron":
            try:
                from apscheduler.triggers.cron import CronTrigger

                CronTrigger.from_crontab(normalize_cron_for_apscheduler(str(schedule)))
            except ImportError:
                pass
            except (ValueError, TypeError) as exc:
                raise ValueError(f"Invalid cron expression '{schedule}': {exc}") from exc
        elif trigger_type == "interval":
            if int(schedule) <= 0:
                raise ValueError(f"Interval must be positive, got {schedule}")
        elif trigger_type == "event":
            valid = {et.value for et in EventType}
            if str(schedule) not in valid:
                raise ValueError(
                    f"Unknown event type '{schedule}'. Valid: {', '.join(sorted(valid))}"
                )

    def add_job(
        self,
        name: str,
        schedule: str | int,
        prompt: str = "",
        *,
        message: str | None = None,
        agent: str = "default",
        session_mode: str = "isolated",
        notify_channels: list[str] | None = None,
        exclude_tools: list[str] | None = None,
        dynamic: bool = True,
        channel: ChannelType | None = None,
        channel_id: str | None = None,
        kb_capability: ScheduledKbCapability | None = None,
        tool: str | None = None,
        arguments: dict[str, Any] | None = None,
        workflow_recipe: str | None = None,
        timezone: str | None = None,
        description: str | None = None,
    ) -> None:
        """Register a new job (or replace an existing one). Validates schedule before persisting."""
        with self._jobs_lock:
            if name == _HEARTBEAT_JOB_NAME:
                raise ValueError(f"Cannot create or replace reserved internal job '{name}'.")
            existing = self._jobs.get(name)

            if timezone:
                _resolve_tz(timezone)  # validate IANA name; raises ValueError on bad name
            self._validate_schedule(schedule, timezone=timezone)

            # Enforce exactly one mode. workflow_recipe is a prompt-mode variant
            # whose body is resolved fresh at each fire (see _execute_job).
            modes = sum(1 for x in (message, prompt, tool, workflow_recipe) if x)
            if modes == 0:
                raise ValueError(
                    "One of 'message', 'prompt', 'tool', or 'workflow_recipe' is required."
                )
            if modes > 1:
                raise ValueError(
                    "'message', 'prompt', 'tool', and 'workflow_recipe' are mutually exclusive."
                )

            # Validation passed — now safe to remove old job before inserting new one
            now_iso = datetime.now(UTC).isoformat()
            old_created_at: str | None = None
            if existing is not None:
                old_created_at = existing.created_at
                self.remove_job(name)

            resolved_channels = notify_channels if notify_channels is not None else ["*"]
            # Coerce stringified payloads (e.g. an LLM passing the string
            # '["cloud"]' instead of a list) into a real list[str]; otherwise a
            # string is later iterated character-by-character and each character
            # is routed to a garbage channel, silently dropping the message.
            coerced = _normalize_channel_list(resolved_channels)
            if coerced is not None:
                resolved_channels = coerced
            elif message:
                # Caller supplied an empty/whitespace value for a message-mode
                # job — fall through to the origin-channel fallback below rather
                # than defaulting to broadcast (["*"]).
                resolved_channels = []
            else:
                resolved_channels = ["*"]
            # A message-mode job exists solely to deliver its text, so an empty
            # notify_channels list is never intentional (e.g. a caller passing
            # []). Fall back to the originating channel so the reminder is never
            # silently dropped — and so list/info reflect the real delivery target.
            if message and not resolved_channels:
                resolved_channels = self._message_fallback_channels(channel)
                logger.info(
                    "Job '{}' is message-mode with empty notify_channels; "
                    "defaulting delivery to {}",
                    name,
                    resolved_channels,
                )

            job = _Job(
                name=name,
                schedule=schedule,
                agent=agent,
                prompt=prompt,
                message=message,
                tool=tool,
                arguments=arguments,
                workflow_recipe=workflow_recipe,
                session_mode=session_mode,
                notify_channels=resolved_channels,
                exclude_tools=exclude_tools or [],
                dynamic=dynamic,
                channel=channel,
                channel_id=channel_id,
                kb_capability=kb_capability,
                created_at=old_created_at or now_iso,  # preserve original on replace
                updated_at=now_iso if existing is not None else None,
                timezone=timezone,
                description=description,
            )
            self._jobs[name] = job

            if self._running:
                self._register_trigger(job)

            if dynamic:
                self._persist_dynamic_jobs()

        logger.info("Added job '{}' (schedule={})", name, schedule)

    def _check_job(self, name: str) -> None:
        """Raise ValueError if job doesn't exist or is reserved."""
        if name == _HEARTBEAT_JOB_NAME:
            raise ValueError(f"Cannot modify reserved internal job '{name}'.")
        if name not in self._jobs:
            raise ValueError(f"Job '{name}' not found.")

    def remove_job(self, name: str) -> None:
        """Remove a job."""
        with self._jobs_lock:
            self._check_job(name)
            job = self._jobs.pop(name)
            if self._running:
                self._unregister_trigger(job)
            if job.dynamic:
                self._persist_dynamic_jobs()
        logger.info("Removed job '{}'", name)

    def enable(self, name: str) -> None:
        """Enable a disabled job."""
        with self._jobs_lock:
            self._check_job(name)
            job = self._jobs[name]
            job.enabled = True
            job.failure_count = 0
            if self._running:
                self._unregister_trigger(job)  # remove stale subscription first
                self._register_trigger(job)
            if job.dynamic:
                self._persist_dynamic_jobs()
        logger.info("Enabled job '{}'", name)

    def disable(self, name: str) -> None:
        """Disable a job without removing it."""
        with self._jobs_lock:
            self._check_job(name)
            job = self._jobs[name]
            job.enabled = False
            if self._running:
                self._unregister_trigger(job)
            if job.dynamic:
                self._persist_dynamic_jobs()
        logger.info("Disabled job '{}'", name)

    async def run_job(self, name: str, *, background: bool = False) -> str | None:
        """Trigger a job immediately.

        If background=True, fires the job in a background task and returns None
        immediately (result delivered via notify_channels when done).
        """
        with self._jobs_lock:
            self._check_job(name)
            job = self._jobs[name]
        if background:
            import asyncio

            asyncio.create_task(self._execute_job(job))
            return None
        return await self._execute_job(job)

    def list_jobs(self) -> list[dict[str, Any]]:
        """All jobs with status."""
        result = []
        with self._jobs_lock:
            jobs = list(self._jobs.values())
        for job in jobs:
            next_run = None
            if self._scheduler and job.enabled:
                ap_job = self._scheduler.get_job(job.name)
                if ap_job and ap_job.next_run_time:
                    next_run = ap_job.next_run_time.isoformat()
            # mode stays the message/tool/prompt enum existing consumers expect;
            # a workflow-backed job is a prompt job and is identified by the
            # separate workflow_recipe field below, not a new mode value.
            mode = "message" if job.message else ("tool" if job.tool else "prompt")
            entry: dict[str, Any] = {
                "name": job.name,
                "schedule": job.schedule,
                "trigger_type": _detect_trigger_type(job.schedule),
                "mode": mode,
                "agent": job.agent,
                "enabled": job.enabled,
                "timezone": job.timezone,
                "session_mode": job.session_mode,
                "failure_count": job.failure_count,
                "dynamic": job.dynamic,
                "next_run": next_run,
                "next_run_at": next_run,
                "status": self._compute_status(job),
                "description": job.description,
                "last_run_at": job.last_run_at,
                "last_status": job.last_status,
                "last_error": job.last_error,
                "notify_channels": job.notify_channels,
                "exclude_tools": job.exclude_tools,
                "created_at": job.created_at,
                "updated_at": job.updated_at,
            }
            if job.message:
                entry["message"] = job.message[:100]
            if job.prompt and not job.workflow_recipe:
                # A workflow job never emits a prompt (even a malformed job with
                # both set, e.g. a hand-edited jobs.json) — its prompt is resolved
                # fresh from workflow_recipe at fire time.
                entry["prompt"] = job.prompt
            if job.tool:
                entry["tool"] = job.tool
                if job.tool.startswith("societas_scanner_v"):
                    entry["arguments"] = job.arguments or {}
            if job.workflow_recipe:
                # Identify a workflow-backed job by this field (not a fake prompt):
                # its 'prompt' is intentionally absent (the real body is resolved
                # fresh from workflow_recipe at fire time), and its human-readable
                # label lives in 'description' ("workflow: <recipe>") set at schedule
                # time — so 'prompt' stays semantically "the actual prompt to run".
                entry["workflow_recipe"] = job.workflow_recipe
            result.append(entry)
        return result

    # Note: `last_status` is the persisted outcome of the previous execution
    # (success/error/None); `status` is the unified UI badge state derived
    # from enabled / _running / last_status.
    @staticmethod
    def _compute_status(job: _Job) -> str:
        """Map a Job's runtime state to a unified UI badge value."""
        if not job.enabled:
            return "disabled"
        if job._running:
            return "running"
        if job.last_status == "error":
            return "error"
        return "idle"

    def update_job(self, name: str, payload: dict[str, Any]) -> None:
        """Partial-merge ``payload`` into the existing Job (BACK-09).

        Only keys present in ``payload`` are assigned; untouched Job fields
        keep their prior value. The job ``name`` is treated as read-only —
        renaming requires recreating the job (out of scope here). Schedule
        changes re-validate and re-register the trigger.
        """
        with self._jobs_lock:
            self._check_job(name)
            job = self._jobs[name]

            # ``name`` is identity — never mutated through update_job.
            payload = {k: v for k, v in payload.items() if k != "name"}

            # A workflow-backed job's body comes from its recipe (resolved fresh
            # at fire time), not a stored prompt — reject edits to prompt/message/
            # tool so a UI (e.g. the web cron editor) can't save a no-op change
            # that looks effective but is ignored (workflow_recipe always wins).
            if job.workflow_recipe and any(k in payload for k in ("prompt", "message", "tool")):
                raise ValueError(
                    f"Job {name!r} runs workflow recipe {job.workflow_recipe!r}; edit the "
                    "recipe (workflow add … replace=true) instead of its prompt/message/tool."
                )
            capability_bound_fields = {"prompt", "message", "tool", "arguments", "session_mode"}
            capability_mutations = capability_bound_fields & payload.keys()
            if job.kb_capability is not None and capability_mutations:
                raise ValueError(
                    f"Job {name!r} has a captured read-only KB capability; recreate it from "
                    "the authorized personal Teams chat instead of changing execution fields "
                    f"{sorted(capability_mutations)}."
                )

            mutable_fields = {
                "schedule",
                "agent",
                "prompt",
                "message",
                "tool",
                "arguments",
                "session_mode",
                "notify_channels",
                "exclude_tools",
                "enabled",
                "description",
                "timezone",
            }
            unknown = set(payload) - mutable_fields
            if unknown:
                raise ValueError(f"Unknown field(s) in update payload: {sorted(unknown)}")

            # Normalize empty-string timezone to None — empty IANA name is meaningless,
            # and otherwise it would skip validation below while still being assigned.
            if "timezone" in payload and payload["timezone"] == "":
                payload["timezone"] = None

            schedule_changed = "schedule" in payload and payload["schedule"] != job.schedule
            tz_changed = "timezone" in payload and payload["timezone"] != job.timezone
            enabled_changed = "enabled" in payload and bool(payload["enabled"]) != bool(job.enabled)
            new_schedule = payload.get("schedule", job.schedule)
            new_timezone = payload.get("timezone", job.timezone)
            if new_timezone is not None:
                _resolve_tz(new_timezone)  # validate IANA name; raises ValueError on bad name
            if schedule_changed or tz_changed:
                self._validate_schedule(new_schedule, timezone=new_timezone)

            for key, value in payload.items():
                setattr(job, key, value)

            job.updated_at = datetime.now(UTC).isoformat()

            if self._running and (schedule_changed or tz_changed or enabled_changed):
                self._unregister_trigger(job)
                if job.enabled:
                    self._register_trigger(job)

            if job.dynamic:
                self._persist_dynamic_jobs()

        logger.info("Updated job '{}' (fields={})", name, sorted(payload))

    def health(self) -> dict[str, Any]:
        """Scheduler health status."""
        with self._jobs_lock:
            active = sum(1 for j in self._jobs.values() if j.enabled)
            disabled = sum(1 for j in self._jobs.values() if not j.enabled)
            total = len(self._jobs)
            heartbeat_job = self._jobs.get(_HEARTBEAT_JOB_NAME)
            heartbeat_configured = self._config.heartbeat.enabled
            heartbeat_enabled = bool(
                heartbeat_configured and heartbeat_job is not None and heartbeat_job.enabled
            )
            heartbeat_failure_count = heartbeat_job.failure_count if heartbeat_job else 0
        return {
            "running": self._running,
            "total_jobs": total,
            "active_jobs": active,
            "disabled_jobs": disabled,
            "heartbeat_configured": heartbeat_configured,
            "heartbeat_enabled": heartbeat_enabled,
            "heartbeat_failure_count": heartbeat_failure_count,
        }

    def _increment_job_failure(self, job: _Job) -> bool:
        """Increment failures and return whether the internal heartbeat was paused."""
        job.failure_count += 1
        if job.failure_count < self.MAX_CONSECUTIVE_FAILURES:
            return False
        if job.name == _HEARTBEAT_JOB_NAME:
            job.enabled = False
            logger.warning("Internal heartbeat paused after {} failures", job.failure_count)
            if self._scheduler:
                try:
                    self._scheduler.pause_job(job.name)
                except Exception as pause_exc:
                    logger.warning("Failed to pause internal heartbeat: {}", pause_exc)
            return True
        logger.warning(
            "Job '{}' auto-disabled after {} failures",
            job.name,
            job.failure_count,
        )
        self.disable(job.name)
        return False

    async def _notify_heartbeat_paused(self, error: str) -> None:
        if not self._bus:
            return
        notification = {
            "channel_id": f"scheduler:{_HEARTBEAT_JOB_NAME}",
            "content": (
                "[⚠️ heartbeat paused]\n"
                f"Heartbeat paused after {self.MAX_CONSECUTIVE_FAILURES} consecutive failures.\n"
                f"Last error: {_truncate_error(error) or 'unknown'}\n"
                "Restart PraestoClaw or inspect the local logs after fixing the cause."
            ),
            "metadata": {
                "source": "heartbeat",
                "job_name": _HEARTBEAT_JOB_NAME,
                "status": "paused",
            },
        }
        try:
            await self._deliver_notification(notification, ["*"])
        except Exception as exc:
            logger.warning("Failed to deliver heartbeat pause notification: {}", exc)

    # ── Trigger registration ─────────────────────────────────────────────

    def _unregister_trigger(self, job: _Job) -> None:
        """Remove a job's trigger from APScheduler or EventBus."""
        trigger_type = _detect_trigger_type(job.schedule)

        if trigger_type == "at":
            # Cancel pending DateTrigger if registered in APScheduler
            if self._scheduler:
                try:
                    self._scheduler.remove_job(job.name)
                except Exception:
                    pass  # May not be registered (immediate or already fired)
            return
        elif trigger_type == "event" and self._bus:
            to_remove = [(n, et, h) for n, et, h in self._event_subscriptions if n == job.name]
            for name, et, handler in to_remove:
                self._bus.events.off(et, handler)
                self._event_subscriptions.remove((name, et, handler))
        elif self._scheduler:
            try:
                self._scheduler.remove_job(job.name)
            except Exception:
                pass

    def _register_trigger(self, job: _Job) -> None:
        """Register appropriate trigger in APScheduler or EventBus."""
        trigger_type = _detect_trigger_type(job.schedule)

        if trigger_type == "event":
            self._register_event_trigger(job)
            return

        if trigger_type == "at":
            self._register_at_trigger(job)
            return

        if not self._scheduler:
            return

        try:
            if trigger_type == "cron":
                from apscheduler.triggers.cron import CronTrigger

                tz = _resolve_tz(job.timezone)
                normalized = normalize_cron_for_apscheduler(str(job.schedule))
                trigger = (
                    CronTrigger.from_crontab(normalized, timezone=tz)
                    if tz
                    else CronTrigger.from_crontab(normalized)
                )
            else:  # interval
                from apscheduler.triggers.interval import IntervalTrigger

                trigger = IntervalTrigger(seconds=int(job.schedule))

            self._scheduler.add_job(
                self._execute_job,
                trigger=trigger,
                args=[job],
                id=job.name,
                name=job.name,
                replace_existing=True,
                max_instances=1,
            )
            logger.debug("Registered {} trigger for '{}'", trigger_type, job.name)
        except Exception as exc:
            logger.error("Failed to register trigger for '{}': {}", job.name, exc)

    @staticmethod
    def _missed_cron_occurrence(job: _Job, *, now: datetime) -> datetime | None:
        """Return the first unhandled cron occurrence before *now*, if any."""
        if not job.enabled or _detect_trigger_type(job.schedule) != "cron":
            return None
        watermark_raw = job.last_run_at or job.created_at
        if not watermark_raw:
            return None
        try:
            watermark = datetime.fromisoformat(watermark_raw)
        except ValueError:
            return None
        if watermark.tzinfo is None:
            watermark = watermark.replace(tzinfo=UTC)

        try:
            from apscheduler.triggers.cron import CronTrigger

            tz = _resolve_tz(job.timezone)
            normalized = normalize_cron_for_apscheduler(str(job.schedule))
            trigger = (
                CronTrigger.from_crontab(normalized, timezone=tz)
                if tz
                else CronTrigger.from_crontab(normalized)
            )
            occurrence = trigger.get_next_fire_time(watermark, watermark)
        except Exception as exc:
            logger.warning("Could not calculate missed occurrence for '{}': {}", job.name, exc)
            return None
        return occurrence if occurrence is not None and occurrence <= now else None

    @staticmethod
    def _pending_catchup_occurrence(job: _Job, *, now: datetime) -> datetime | None:
        if (
            not job.enabled
            or _detect_trigger_type(job.schedule) != "cron"
            or not job.pending_catchup_at
        ):
            return None
        try:
            pending = datetime.fromisoformat(job.pending_catchup_at)
        except ValueError:
            return None
        if pending.tzinfo is None:
            pending = pending.replace(tzinfo=UTC)
        return pending if pending <= now else None

    def _register_at_trigger(self, job: _Job) -> None:
        """Execute a job at a specific time, then auto-remove on success.

        Schedule formats (nanobot at_iso pattern):
          "at"                            — execute immediately
          "at:+60"                        — execute after 60 seconds
          "at:2026-03-04T15:00:00"        — execute at absolute ISO datetime in job timezone
          "at:2026-03-04T15:00:00+08:00"  — execute at absolute ISO with timezone
        """
        schedule_str = str(job.schedule).strip()
        run_at = _parse_at_schedule(schedule_str, timezone=job.timezone)

        if run_at is None and schedule_str.lower() != "at":
            logger.error(
                "Invalid one-shot schedule for job '{}' (schedule={!r}, timezone={!r}); disabling",
                job.name,
                job.schedule,
                job.timezone,
            )
            self.disable(job.name)
            return

        if run_at is not None:
            if not self._scheduler:
                logger.error(
                    "No scheduler available — cannot register one-shot job '{}' for {}",
                    job.name,
                    run_at.isoformat(),
                )
                return
            # Scheduled one-shot via APScheduler DateTrigger
            from apscheduler.triggers.date import DateTrigger

            async def _run_and_remove_scheduled() -> None:
                result = await self._execute_job(job)
                if result is not None:  # success — clean up
                    self.remove_job(job.name)
                    logger.info("One-shot job '{}' completed and removed", job.name)
                else:  # failure — keep for inspection
                    self.disable(job.name)
                    logger.warning("One-shot job '{}' failed — disabled for inspection", job.name)

            self._scheduler.add_job(
                _run_and_remove_scheduled,
                trigger=DateTrigger(run_date=run_at),
                id=job.name,
                name=job.name,
                replace_existing=True,
            )
            logger.info("One-shot job '{}' scheduled for {}", job.name, run_at.isoformat())
        else:
            # Immediate execution
            async def _run_and_remove() -> None:
                result = await self._execute_job(job)
                if result is not None:  # success — clean up
                    self.remove_job(job.name)
                    logger.info("One-shot job '{}' completed and removed", job.name)
                else:  # failure — keep for inspection
                    self.disable(job.name)
                    logger.warning("One-shot job '{}' failed — disabled for inspection", job.name)

            try:
                loop = asyncio.get_running_loop()
                loop.create_task(_run_and_remove())
            except RuntimeError:
                logger.warning("No event loop — cannot schedule one-shot job '{}'", job.name)

    def _register_event_trigger(self, job: _Job) -> None:
        """Subscribe to EventBus for event-triggered jobs."""
        if not self._bus:
            logger.warning("No bus — cannot register event trigger for '{}'", job.name)
            return

        event_name = str(job.schedule)
        # Find matching EventType
        for et in EventType:
            if et.value == event_name:

                async def _handler(event_type: EventType, payload: dict, _job: _Job = job) -> None:
                    await self._execute_job(_job)

                self._bus.events.on(et, _handler)
                self._event_subscriptions.append((job.name, et, _handler))
                logger.debug("Registered event trigger for '{}' on {}", job.name, event_name)
                return

        logger.warning("Unknown event type '{}' for job '{}'", event_name, job.name)

    def _register_heartbeat(self) -> None:
        """Register the built-in heartbeat interval job."""
        interval = self._config.heartbeat.interval

        job = _Job(
            name=_HEARTBEAT_JOB_NAME,
            schedule=interval,
            agent="default",
            prompt="",  # built dynamically in _execute_heartbeat
            session_mode="persistent",  # single JSONL file; in-memory cleared per run
            notify_channels=[],  # heartbeat notifies via notify() tool, not result broadcast
        )
        self._jobs[_HEARTBEAT_JOB_NAME] = job

        if self._scheduler:
            from apscheduler.triggers.interval import IntervalTrigger

            self._scheduler.add_job(
                self._execute_heartbeat,
                trigger=IntervalTrigger(seconds=interval),
                id=_HEARTBEAT_JOB_NAME,
                name=_HEARTBEAT_JOB_NAME,
                replace_existing=True,
                max_instances=1,
            )
        logger.info("Heartbeat registered (every {}s)", interval)

    # ── Execution ────────────────────────────────────────────────────────

    def _resolve_workflow_recipe(self, name: str) -> str:
        """Return the recipe's current body, or raise so the job's failure path runs.

        Called at fire time for a ``workflow_recipe`` job so the scheduled workflow
        always runs the latest recipe. Raising here (no resolver wired, or recipe
        deleted) routes through ``_execute_job``'s except handler → user is notified
        and the job auto-disables after repeated failures.
        """
        if self._recipe_resolver is None:
            raise RuntimeError(
                f"workflow recipe {name!r} cannot be resolved (workflow feature not available)"
            )
        body = self._recipe_resolver(name)
        if not body:
            raise RuntimeError(f"workflow recipe {name!r} not found (was it deleted?)")
        return body

    @staticmethod
    def _session_id_for_job(job: _Job, *, timestamp: str) -> str:
        if job.session_mode == "isolated":
            return f"scheduler_{job.name}_{timestamp}"
        if job.kb_capability is not None:
            generation = hashlib.sha256(
                json.dumps(job.kb_capability.to_dict(), sort_keys=True).encode("utf-8")
            ).hexdigest()[:12]
            return f"scheduler_{job.name}_{generation}"
        return f"scheduler_{job.name}"

    async def _execute_job(self, job: _Job, *, is_catchup: bool = False) -> str | None:
        """Execute a job through the canonical AgentHost."""
        if not self._agent_loop or not self._agent_host:
            logger.error("Agent host not set — cannot execute '{}'", job.name)
            return None

        # Guard against concurrent execution (especially for event triggers)
        if job._running:
            logger.debug("Job '{}' already running — skipping", job.name)
            return None
        job._running = True

        ts = datetime.now(UTC).strftime("%Y%m%dT%H%M%S")
        session_id = self._session_id_for_job(job, timestamp=ts)

        started = datetime.now(UTC)
        try:
            logger.info("Executing job '{}' (session={})", job.name, session_id)
            if prompt_requires_current_kb_scope(job.prompt) and job.kb_capability is None:
                raise BlockedJobError(
                    "Scheduled PMO grill has no trusted KB capability. Recreate the job "
                    "from the personal Teams chat where the KB scope is bound."
                )
            if job.kb_capability is not None and job.kb_capability.job_id != job.name:
                raise BlockedJobError(
                    "Scheduled KB capability does not match this job; recreate the job "
                    "from the authorized personal Teams chat."
                )
            if job.kb_capability is not None:
                from praestoclaw.security.kb_curation import begin_scheduled_kb_run

                begin_scheduled_kb_run(session_id)
            async with self._job_semaphore:
                result: str = ""
                tool_ref: Any = None
                # Don't pass job.channel_id as general tool context. For ordinary
                # jobs it is the original conversation ID and its ReplyContext is
                # stale after 15m. Scanner jobs use the same persisted field only
                # as the trusted Plan-owner scope injected explicitly below.
                # Tools like notify use the bare channel name -> push frame path.
                if job.message:
                    # Message mode — zero execution, deliver static text
                    result = job.message
                elif job.tool:
                    # Tool mode — pre-flight safety checks + direct registry call.
                    # ApprovalGate is NOT run here (already approved at scheduling time,
                    # arguments are fixed). Only EStop + RBAC + post-tool hooks.
                    if job.tool == "config_praestoclaw":
                        raise RuntimeError("config_praestoclaw is not permitted in cron jobs")
                    registry = getattr(self._agent_loop, "_tool_registry", None)
                    if not registry:
                        raise RuntimeError("Tool registry not available")
                    tool_ref = registry.get(job.tool)

                    # MCP tools may disconnect between scheduling and execution.
                    # Attempt reconnect before pre-flight so tool_ref is available.
                    if registry.get(job.tool) is None and job.tool.startswith("MCP_"):
                        mcp_mgr = getattr(registry, "_mcp_manager", None)
                        if mcp_mgr is not None:
                            parts = job.tool.split("_", 2)  # ["MCP", server, tool]
                            if len(parts) >= 2:
                                server_name = parts[1]
                                try:
                                    await mcp_mgr.describe_server(server_name)
                                    logger.info(
                                        "MCP server '{}' reconnected for cron job '{}'",
                                        server_name,
                                        job.name,
                                    )
                                except Exception as exc:
                                    logger.warning(
                                        "MCP reconnect failed for '{}': {}",
                                        server_name,
                                        exc,
                                    )

                    # Pre-flight: EStop + RBAC (skip ApprovalGate — already
                    # approved at scheduling time, arguments are fixed)
                    from praestoclaw.hooks.handlers import ApprovalGate
                    from praestoclaw.hooks.manager import (
                        HookVerdict,
                        PostToolHookContext,
                        PreToolHookContext,
                    )

                    hooks = getattr(self._agent_loop, "_hooks", None)
                    if hooks and hasattr(hooks, "dispatch_checked"):
                        pre_ctx = PreToolHookContext(
                            tool_name=job.tool,
                            args=job.arguments or {},
                            agent_name="scheduler",
                            session_id=session_id,
                            tool_ref=tool_ref,
                            channel=job.channel,
                        )
                        pre_result = await hooks.dispatch_checked(
                            "pre_tool_use",
                            pre_ctx,
                            exclude_types=(ApprovalGate,),
                        )
                        if pre_result.verdict == HookVerdict.REJECT:
                            raise RuntimeError(f"Blocked by security policy: {pre_result.reason}")

                    is_hb = job.name == _HEARTBEAT_JOB_NAME
                    exec_args = dict(job.arguments or {})
                    workspace = getattr(self._agent_loop, "_workspace", None)
                    async with tool_resource_lock(
                        job.tool or "",
                        exec_args,
                        workspace=workspace if isinstance(workspace, Path) else None,
                    ):
                        execution_metadata: dict[str, Any] = {
                            "source": "heartbeat" if is_hb else "cron",
                            "job_name": job.name,
                        }
                        if job.tool.startswith("societas_scanner_v") and job.channel_id:
                            # CronTool stores this only from registry-injected
                            # personal-Teams provenance. It is intentionally not
                            # part of editable tool arguments.
                            execution_metadata["plan_owner"] = job.channel_id
                        result = await registry.execute(
                            job.tool,
                            exec_args,
                            actor="scheduler",
                            session_id=session_id,
                            channel=job.channel,
                            metadata=execution_metadata,
                        )

                    # Post-flight: LeakScanner + Auditor
                    if hooks and hasattr(hooks, "dispatch_checked"):
                        post_ctx = PostToolHookContext(
                            tool_name=job.tool,
                            args=job.arguments or {},
                            result=result,
                            agent_name="scheduler",
                            session_id=session_id,
                        )
                        await hooks.dispatch_checked("post_tool_use", post_ctx)

                    if result.startswith("Error"):
                        raise RuntimeError(result)
                else:
                    # Task mode — full LLM loop with runtime context injection.
                    # For a workflow-backed job, resolve the recipe body FRESH now
                    # so a scheduled workflow always runs the latest recipe (raising
                    # here routes through the except path → user notified + auto-disable
                    # after repeated failures, e.g. if the recipe was deleted).
                    base_prompt = job.prompt
                    wf_limits: dict[str, Any] = {}
                    if job.workflow_recipe:
                        base_prompt = self._resolve_workflow_recipe(job.workflow_recipe)
                        # Task 9: resolve the recipe's capability limits fresh so a
                        # scheduled run is bounded like an on-demand one. Best-effort
                        # — a resolver hiccup must not fail the run (just no caps).
                        if self._limits_resolver is not None:
                            try:
                                wf_limits = self._limits_resolver(job.workflow_recipe) or {}
                            except Exception as exc:  # noqa: BLE001 - caps are best-effort
                                logger.warning(
                                    "Workflow limits resolution failed for recipe {!r} "
                                    "(job {!r}) — running without caps: {}",
                                    job.workflow_recipe,
                                    job.name,
                                    exc,
                                )
                                wf_limits = {}
                    effective_prompt = base_prompt
                    if job.name != _HEARTBEAT_JOB_NAME:
                        now_str = datetime.now(UTC).strftime("%Y-%m-%d %H:%M UTC")
                        auto_deliver = bool(job.notify_channels)
                        if auto_deliver:
                            delivery_note = (
                                "- Auto-delivery: your text output will be sent to the user "
                                "on their active channels (Teams, Web, CLI — whichever is connected).\n"
                                "- Do NOT use MCP or notify() to re-deliver the same content.\n"
                                "- Only use MCP if the task explicitly asks to send to OTHER "
                                "people or channels (e.g. 'post to #general', 'message Alice').\n"
                                "- Format output as markdown."
                            )
                            if (
                                job.kb_capability is not None
                                and job.kb_capability.origin_session_id
                                and prompt_requires_current_kb_scope(job.prompt)
                            ):
                                delivery_note += (
                                    "\n- Direct PMO continuation is enabled: after delivery, "
                                    "the user's next reply in the originating personal chat is "
                                    "routed back into pmo-grill. Ask them to reply directly to "
                                    "this message; do not emit a copyable PMO grill prompt."
                                )
                        else:
                            delivery_note = (
                                "No auto-delivery configured. Use tools (notify, MCP, etc.) "
                                "to deliver results yourself as needed."
                            )
                        effective_prompt = (
                            f"[Scheduled task — {now_str}]\n\n"
                            f"## Context\n"
                            f"This is an unattended background task — the user cannot interact "
                            f"or ask follow-up questions. Your output must be self-contained.\n\n"
                            f"## Approach\n"
                            f"- Cross-reference multiple sources before producing the final result. "
                            f"Prefer thoroughness over speed.\n"
                            f"- Verify key facts with tools and skills rather than "
                            f"relying on assumptions.\n"
                            f"- If information is conflicting, state what you "
                            f"found and what you could not confirm.\n\n"
                            f"## Delivery\n"
                            f"{delivery_note}\n\n"
                            f"## Task\n\n"
                            f"{base_prompt}"
                        )

                    # For Cloud, use a non-routable channel_id so approval
                    # prompts go through the push path (job.channel_id may
                    # reference a stale ReplyContext on the gateway).
                    # For other channels (Web, CLI), leave empty so
                    # _send_approval_prompt doesn't misclassify as interactive.
                    channel_id = f"scheduler:{job.name}" if job.channel == ChannelType.CLOUD else ""
                    is_heartbeat = job.name == _HEARTBEAT_JOB_NAME
                    exclude_tools = ["cron"] if is_heartbeat else ["cron", "config_praestoclaw"]
                    if job.kb_capability is not None:
                        # Scheduled PMO grill is a non-interactive triage turn.
                        # A visible Plan cannot receive user replies and previously
                        # left report items permanently not_started after delivery.
                        exclude_tools.append("plan")
                    exclude_tools.extend(
                        tool for tool in job.exclude_tools if tool not in exclude_tools
                    )
                    # Task 9: enforce a workflow recipe's allowed_tools on the
                    # scheduled run by turning the allowlist into exclude_tools
                    # (everything NOT allowed) — reusing run_once's existing
                    # allowlist enforcement (_resolve_allowed_tools) instead of
                    # touching the core loop. Inert when no allowed_tools declared.
                    # The exclude_tools ride the turn metadata, and runtime._spawn_agent
                    # honors metadata exclude_tools transitively — so even a child
                    # agent (if the recipe allowlists `spawn`) inherits the same cap.
                    _wf_allow = wf_limits.get("workflow_allowed_tools")
                    if isinstance(_wf_allow, list) and _wf_allow:
                        _reg = getattr(self._agent_loop, "_tool_registry", None)
                        if _reg is not None:
                            try:
                                _all_names = {
                                    s.get("function", {}).get("name", "")
                                    for s in _reg.get_schemas()
                                }
                            except Exception:  # noqa: BLE001 - best-effort caps
                                _all_names = set()
                            exclude_tools.extend(
                                t
                                for t in _all_names
                                if t and t not in _wf_allow and t not in exclude_tools
                            )
                    from agent_gateway_protocol.agent_link.v1 import (
                        InitiatedBy,
                        LogicalChannel,
                    )

                    from praestoclaw.channels.turn.context import (
                        ChannelTurnEnvelope,
                        PhysicalIngress,
                    )
                    from praestoclaw.host.agent_host import TurnCompletion

                    job_channel = job.channel or ChannelType.INTERNAL
                    metadata: dict[str, Any] = {
                        "source": "heartbeat" if is_heartbeat else "cron",
                        "job_name": job.name,
                        "turn_id": f"scheduler:{job.name}:{ts}",
                        "agent_session_key": session_id,
                        "connection_id": channel_id or session_id,
                        "channel_type": job_channel.value,
                        "exclude_tools": exclude_tools,
                        "initiated_by": InitiatedBy.SCHEDULER.value,
                        "source_scope": "system",
                        "requires_human_visibility": False,
                    }
                    if job.kb_capability is not None:
                        metadata["scheduled_kb_capability"] = job.kb_capability.to_dict()
                    notify_targets = _normalize_channel_list(job.notify_channels) or []
                    if job_channel == ChannelType.CLOUD and (
                        "*" in notify_targets or ChannelType.CLOUD.value in notify_targets
                    ):
                        metadata["push_target"] = self.CLOUD_NOTIFICATION_PUSH_TARGET
                    if job.workflow_recipe:
                        # Scoped per-run authorization for a scheduled workflow run:
                        # the ApprovalGate auto-approves in-scope tools (the recipe's
                        # declared allowed_tools) without a per-action human gate,
                        # same as the on-demand path; out-of-scope tools stay gated.
                        # workflow_owner scopes this run's status/resume ownership.
                        metadata["workflow"] = job.workflow_recipe
                        if isinstance(_wf_allow, list) and _wf_allow:
                            metadata["workflow_allowed_tools"] = _wf_allow
                        # The scheduled path is where a denial list matters most —
                        # nobody is watching — and it was the one path that did not
                        # carry it. Without this a cron workflow run gets `shell`
                        # auto-approved by the gate above AND unfiltered.
                        _wf_deny = wf_limits.get("workflow_denied_commands")
                        if isinstance(_wf_deny, list) and _wf_deny:
                            metadata["workflow_denied_commands"] = _wf_deny
                        metadata["workflow_owner"] = session_id
                    _envelope = ChannelTurnEnvelope(
                        trace_id=f"scheduler:{job.name}:{ts}",
                        physical_ingress=PhysicalIngress.LOCAL_SCHEDULER.value,
                        logical_channel=LogicalChannel.SCHEDULER_LOCAL.value,
                        content=effective_prompt,
                        sender_id="scheduler",
                        conversation_id=session_id,
                        received_at=started.isoformat(),
                        metadata=metadata,
                    )
                    # A recipe can override the default scheduled-prompt timeout.
                    # Either bound routes TimeoutError through the normal failure path,
                    # which records history and releases the job/semaphore in finally.
                    _max_runtime = positive_int(wf_limits.get("workflow_max_runtime"))
                    _timeout_value = (
                        _max_runtime
                        if _max_runtime is not None
                        else self._config.prompt_job_timeout_seconds
                    )
                    try:
                        _timeout = float(_timeout_value)
                    except OverflowError:
                        _timeout = None
                    submission = self._agent_host.submit_turn(
                        _envelope,
                        completion=TurnCompletion.RETURN,
                    )
                    turn = (
                        await submission
                        if _timeout is None
                        else await asyncio.wait_for(submission, timeout=_timeout)
                    )
                    result = turn.runtime_result.content if turn.runtime_result else ""
                    # Task 9: truncate the scheduled result to the recipe's max_output.
                    result = cap_output(result, positive_int(wf_limits.get("workflow_max_output")))

                    source_error = self._megaphone_source_read_error(job.name, session_id)
                    if source_error:
                        raise RuntimeError(source_error)

                    kb_error = self._scheduled_kb_read_error(job, session_id)
                    if kb_error:
                        raise BlockedJobError(kb_error)

                    if job.name == _HEARTBEAT_JOB_NAME and not result.strip():
                        raise RuntimeError("Heartbeat returned an empty result")

            duration = (datetime.now(UTC) - started).total_seconds()
            self._record_run(job.name, ts, "success", result, duration, started_at=started)
            self._track_job_run(job.name, success=True)
            self._record_last_run(
                job,
                status="success",
                error=None,
                clear_pending_catchup=is_catchup,
            )

            # Reset failure counter on success
            job.failure_count = 0

            # Deliver to channels ("*" = all active).
            # Skip for tool-mode jobs whose tool already handles delivery
            # (e.g. notify tool) to avoid double delivery.
            _SELF_DELIVERING_TOOLS = {"notify"}
            skip_notify = job.tool in _SELF_DELIVERING_TOOLS
            deliver = self._should_deliver_result(job, result)

            notify_targets = _normalize_channel_list(job.notify_channels) or []
            # Defensive backstop for message-mode jobs persisted before the
            # add_job normalization above (jobs.json may still hold an empty
            # notify_channels). A reminder must never be silently dropped after
            # a successful run just because its channel list is empty.
            if not notify_targets and deliver and job.message:
                notify_targets = self._message_fallback_channels(job.channel)
                logger.warning(
                    "Job '{}' is message-mode with empty notify_channels; "
                    "falling back to {} to deliver the reminder",
                    job.name,
                    notify_targets,
                )

            if notify_targets and deliver and self._bus and not skip_notify:
                delivered_result = (
                    self._extract_megaphone_alert(result)
                    if job.name.startswith("megaphone-") and not job.message
                    else result
                )
                # An Adaptive Card envelope ({"type":"message","attachments":[{
                # contentType:"…card.adaptive",…}]}) must reach the channel as PURE
                # JSON: a text prefix ([📅 …] / [🔔]) makes the content no longer start
                # with "{", so the cloud channel's envelope detector misses it and
                # renders a literal JSON blob instead of the card. Deliver as-is.
                _stripped = delivered_result.lstrip()
                _is_card_envelope = (
                    _stripped.startswith("{")
                    and "card.adaptive" in _stripped
                    and '"attachments"' in _stripped
                )
                if _is_card_envelope:
                    content = _stripped
                elif job.message:
                    content = f"[🔔] {delivered_result}"
                else:
                    content = f"[📅 {job.name}]\n{delivered_result}"
                notification: dict[str, Any] = {
                    "channel_id": f"scheduler:{job.name}",
                    "content": content,
                    "metadata": {
                        "source": "scheduler",
                        "job_name": job.name,
                        "session_id": session_id,
                    },
                }
                acknowledge = getattr(tool_ref, "acknowledge_delivery", None)
                if callable(acknowledge):
                    notification["_on_delivered"] = lambda acknowledge=acknowledge, result=result: (
                        acknowledge(result)
                    )
                # A delivery failure must not flip an otherwise-successful run
                # into the failure path — for a one-shot that would wrongly
                # disable/retain a job whose work already completed.
                try:
                    delivered = await self._deliver_notification(notification, notify_targets)
                    if delivered:
                        await self._record_scheduled_pmo_handoff(job, result)
                except Exception as deliver_exc:  # noqa: BLE001
                    logger.opt(exception=deliver_exc).warning(
                        "Cron delivery for '{}' failed after a successful run",
                        job.name,
                    )

            return result

        except Exception as exc:
            duration = (datetime.now(UTC) - started).total_seconds()
            blocked = isinstance(exc, BlockedJobError)
            run_status = "blocked" if blocked else "failed"
            logger.error("Job '{}' {}: {}", job.name, run_status, exc)
            self._record_run(
                job.name,
                ts,
                run_status,
                str(exc),
                duration,
                started_at=started,
                error_type=type(exc).__name__,
            )
            self._track_job_run(job.name, success=False, error=str(exc))
            self._record_last_run(job, status="error", error=str(exc))

            heartbeat_paused = self._increment_job_failure(job)
            if heartbeat_paused:
                await self._notify_heartbeat_paused(str(exc))

            # Notify user about job failure so it doesn't silently disappear
            if job.notify_channels and self._bus:
                # Fall back to the exception class name when the message is
                # empty (e.g. ``raise RuntimeError()``) — otherwise the user
                # sees the unhelpful literal "Error: None".
                error_msg = _truncate_error(str(exc)) or type(exc).__name__
                outcome_label = "blocked" if blocked else "failed"
                fail_content = (
                    f"[⚠️ {job.name} {outcome_label}]\n"
                    f"Error: {error_msg}\n"
                    f"Failures: {job.failure_count}/{self.MAX_CONSECUTIVE_FAILURES}"
                )
                fail_notification = {
                    "channel_id": f"scheduler:{job.name}",
                    "content": fail_content,
                    "metadata": {
                        "source": "scheduler",
                        "job_name": job.name,
                        "session_id": session_id,
                        "status": outcome_label,
                    },
                }
                try:
                    fail_nc = _normalize_channel_list(job.notify_channels)
                    fail_targets = fail_nc if fail_nc is not None else ["*"]
                    await self._deliver_notification(fail_notification, fail_targets)
                except Exception as notify_exc:
                    logger.warning(
                        "Failed to deliver failure notification for '{}': {}",
                        job.name,
                        notify_exc,
                    )

            return None

        finally:
            if job.kb_capability is not None:
                from praestoclaw.security.kb_curation import consume_scheduled_kb_run

                consume_scheduled_kb_run(session_id)
            job._running = False

    async def _record_scheduled_pmo_handoff(self, job: _Job, result: str) -> None:
        capability = job.kb_capability
        if (
            capability is None
            or not capability.origin_session_id
            or not prompt_requires_current_kb_scope(job.prompt)
            or self._agent_host is None
        ):
            return
        from praestoclaw.host.agent_host import SessionEvent, SessionEventKind

        try:
            await self._agent_host.record_session_event(
                SessionEvent(
                    session_id=capability.origin_session_id,
                    channel=(job.channel or ChannelType.CLOUD).value,
                    sender=capability.subject_id,
                    kind=SessionEventKind.PMO_HANDOFF,
                    content=result,
                    metadata={
                        "source": "scheduled_pmo_handoff",
                        "job_name": job.name,
                        "conversation_id": capability.conversation_id,
                        "repo": capability.repo,
                        "subfolder": capability.subfolder,
                    },
                )
            )
            logger.info(
                "Scheduled PMO handoff recorded job={} session={}",
                job.name,
                capability.origin_session_id,
            )
        except Exception as exc:  # noqa: BLE001 - result delivery already succeeded
            logger.warning("Scheduled PMO handoff recording failed for '{}': {}", job.name, exc)

    def _megaphone_source_read_error(self, job_name: str, session_id: str) -> str | None:
        if not job_name.startswith("megaphone-"):
            return None
        if job_name == "megaphone-email":
            source_prefixes = ("MCP_mail",)
        elif job_name == "megaphone-teams":
            source_prefixes = ("MCP_teams",)
        elif job_name.startswith("megaphone-calendar"):
            source_prefixes = ("MCP_calendar",)
        else:
            return None

        try:
            from praestoclaw.megaphone.audit import (
                audit_entry_is_failure,
                iter_session_audit_entries,
            )

            for entry in iter_session_audit_entries(self._data_dir, session_id):
                tool = str(entry.get("tool") or "")
                if not tool.startswith(source_prefixes):
                    continue
                preview = str(entry.get("result_preview") or "").lstrip()
                if audit_entry_is_failure(entry):
                    return f"Megaphone source read failed in {session_id}: {tool}: {preview[:240]}"
        except OSError as exc:
            logger.warning("Could not inspect Megaphone audit logs: {}", exc)
        return None

    def _scheduled_kb_read_error(self, job: _Job, session_id: str) -> str | None:
        """Promote a structured scheduled KB read failure to a blocked run."""
        if job.kb_capability is None:
            return None
        from praestoclaw.security.kb_curation import consume_scheduled_kb_run

        outcome = consume_scheduled_kb_run(session_id)
        if outcome.error:
            return f"Scheduled KB read blocked in {session_id}: {outcome.error}"
        if outcome.successful_content_read:
            return None
        return (
            "Scheduled job requires its captured KB scope but completed without a "
            "successful kb_inspect content read."
        )

    async def _execute_heartbeat(self) -> None:
        """Execute heartbeat — delegates to praestoclaw.cron.heartbeat module.

        Uses persistent session mode (single JSONL file on disk for audit)
        but clears in-memory history before each run so the LLM starts
        with a clean context. Cross-run context comes from the state file,
        not session history.

        **Pre-flight optimisation**: Python-side checks determine which
        prompt sections need work. When all sections are idle, the run
        short-circuits with HEARTBEAT_OK — no LLM call, no token cost.
        """
        from praestoclaw.cron.heartbeat import (
            is_heartbeat_ok,
            load_heartbeat_prompt,
            mark_successful_sections,
            preflight_check,
            read_state,
            update_state,
        )

        state = read_state(self._data_dir)
        started = datetime.now(UTC)
        ts = started.strftime("%Y%m%dT%H%M%S")
        job = self._jobs.get(_HEARTBEAT_JOB_NAME)

        try:
            # Fast path: if HEARTBEAT.md is disabled (empty override), skip everything
            from praestoclaw.utils.defaults import load_default

            if not load_default("HEARTBEAT.md", allow_empty_override=True):
                return

            if not job or not job.enabled:
                return

            # Pre-flight: skip LLM entirely when nothing needs attention.
            statuses = preflight_check(self._data_dir)
            if not any(s.active for s in statuses.values()):
                logger.debug("Heartbeat pre-flight: all sections idle, skipping LLM call")
                update_state(
                    state,
                    "HEARTBEAT_OK",
                    self._daily_counts.get(_HEARTBEAT_JOB_NAME),
                    data_dir=self._data_dir,
                )
                duration = (datetime.now(UTC) - started).total_seconds()
                self._record_run(
                    _HEARTBEAT_JOB_NAME, ts, "success", "HEARTBEAT_OK", duration, started_at=started
                )
                self._track_job_run(_HEARTBEAT_JOB_NAME, success=True)
                job.failure_count = 0
                return

            prompt = load_heartbeat_prompt(state, statuses=statuses)
            if not prompt:
                return

            active_names = [k for k, s in statuses.items() if s.active]
            logger.info("Heartbeat pre-flight: active sections = {}", active_names)

            # Clear in-memory session so LLM sees no prior conversation.
            # Disk JSONL keeps growing (append-only) for audit; in-memory
            # is just this run's messages.
            sessions = getattr(self._agent_loop, "_sessions", None)
            if sessions:
                sid = f"scheduler_{job.name}"
                sessions.replace_messages(sid, [])

            job.prompt = prompt
            result = await self._execute_job(job)
            if result is not None:
                mark_successful_sections(statuses, data_dir=self._data_dir)

            update_state(
                state,
                result,
                self._daily_counts.get(_HEARTBEAT_JOB_NAME),
                data_dir=self._data_dir,
            )

            # Deliver notification for non-OK results (Python-side, saves LLM
            # a notify() tool call round). LLM just produces content.
            if not is_heartbeat_ok(result) and result and self._bus:
                notification = {
                    "channel_id": f"scheduler:{job.name}",
                    "content": f"[💓 heartbeat]\n{result}",
                    "metadata": {"source": "heartbeat", "job_name": job.name},
                }
                try:
                    await self._deliver_notification(notification, ["*"])
                except Exception as deliver_exc:
                    logger.warning(
                        "Heartbeat notification delivery failed after a successful run: {}",
                        deliver_exc,
                    )
        except Exception as exc:
            logger.error("Heartbeat failed: {}", exc)
            if job is not None:
                heartbeat_paused = self._increment_job_failure(job)
                if heartbeat_paused:
                    await self._notify_heartbeat_paused(str(exc))
            duration = (datetime.now(UTC) - started).total_seconds()
            self._record_run(
                _HEARTBEAT_JOB_NAME, ts, "failed", str(exc), duration, started_at=started
            )
            self._track_job_run(_HEARTBEAT_JOB_NAME, success=False, error=str(exc))
            update_state(
                state,
                None,
                self._daily_counts.get(_HEARTBEAT_JOB_NAME),
                data_dir=self._data_dir,
            )

    def _record_last_run(
        self,
        job: _Job,
        *,
        status: str,
        error: str | None,
        clear_pending_catchup: bool = False,
    ) -> None:
        """Update a job's persisted last-run snapshot (BACK-02 write path).

        Mutates the in-memory Job and, if the job is dynamic, flushes
        ``jobs.json`` so the state survives a service restart. The error
        message is truncated to 500 chars at this boundary so a multi-MB
        traceback never lands on disk.
        """
        with self._jobs_lock:
            job.last_run_at = datetime.now(UTC).isoformat()
            job.last_status = status
            job.last_error = _truncate_error(error)
            if status == "success" and clear_pending_catchup:
                job.pending_catchup_at = None
            if job.dynamic:
                try:
                    self._persist_dynamic_jobs()
                except Exception as exc:  # pragma: no cover — disk failure is best-effort
                    logger.warning("Failed to persist last-run state for '{}': {}", job.name, exc)

    def _track_job_run(self, job_name: str, *, success: bool, error: str = "") -> None:
        """Accumulate daily run count. Flush previous day's summary on day change."""
        today = datetime.now(UTC).strftime("%Y-%m-%d")
        counts = self._daily_counts.get(job_name)

        # Day changed → flush yesterday's summary before starting new day
        if counts and counts["day"] != today:
            self._flush_daily_summary(job_name, counts)
            counts = None

        if counts is None:
            counts = {"day": today, "success": 0, "failed": 0, "last_error": ""}
            self._daily_counts[job_name] = counts

        if success:
            counts["success"] += 1
        else:
            counts["failed"] += 1
            if error:
                counts["last_error"] = error[:200]

    def _flush_daily_summary(self, job_name: str, counts: dict[str, Any]) -> None:
        """Write one HISTORY entry for a completed day's job runs."""
        s, f = counts["success"], counts["failed"]
        if s == 0 and f == 0:
            return

        label = "heartbeat" if job_name == _HEARTBEAT_JOB_NAME else f"cron:{job_name}"
        day = counts.get("day", "unknown")
        summary = f"{label} daily summary ({day})\n  did: {s} successful, {f} failed runs"
        if f and counts.get("last_error"):
            summary += f"\n  error: {counts['last_error'][:120]}"

        try:
            # Reuse agent loop's memory if available, else create temporary
            mem = getattr(self._agent_loop, "_memory", None)
            if mem is None:
                from praestoclaw.agent.memory import AgentMemory

                mem = AgentMemory(data_dir=self._cron_dir.parent)
                mem.history.append(summary, [], f"scheduler_{job_name}")
                mem.close()
            else:
                mem.history.append(summary, [], f"scheduler_{job_name}")
            logger.debug("Flushed daily summary for '{}' to HISTORY.md", job_name)
        except Exception as exc:
            logger.warning("Failed to flush daily summary for '{}': {}", job_name, exc)

    def flush_all_daily_summaries(self) -> None:
        """Flush all pending daily summaries (call on shutdown)."""
        for job_name, counts in list(self._daily_counts.items()):
            if counts["success"] > 0 or counts["failed"] > 0:
                self._flush_daily_summary(job_name, counts)
        self._daily_counts.clear()

    # ── Notification delivery with buffering ─────────────────────────────

    async def _deliver_notification(
        self, notification: dict[str, Any], notify_channels: list[str]
    ) -> bool:
        """Deliver a notification to active channels, buffering if none are available."""
        if not self._bus:
            return False
        # Flush previously buffered notifications first
        await self._flush_pending()

        targets = list(notify_channels)
        if "*" in targets and self._active_channels_fn:
            targets = self._active_channels_fn()
        targets = [t for t in targets if t != "*"]

        if not targets:
            if not self._active_channels_fn:
                # No channel resolver — buffering would never drain; drop.
                logger.debug("No active_channels_fn, dropping notification")
                return False
            async with self._pending_lock:
                if len(self._pending_notifications) >= self._max_pending:
                    dropped = self._pending_notifications.pop(0)
                    logger.warning(
                        "Pending buffer full ({}), dropped oldest: {}",
                        self._max_pending,
                        dropped.get("metadata", {}).get("job_name", "?"),
                    )
                self._pending_notifications.append(notification)
                logger.info(
                    "No active channel for notification '{}', buffered ({} pending)",
                    notification.get("metadata", {}).get("job_name", "?"),
                    len(self._pending_notifications),
                )
            return False

        delivered = await self._publish_to_targets(notification, targets)
        if delivered:
            await self._ack_delivered_notification(notification)
        return delivered

    async def _flush_pending(self) -> None:
        """Drain buffered notifications if channels are now available.

        Copies and clears the buffer under the lock, then publishes
        outside the lock to avoid blocking on slow I/O.
        """
        if not self._pending_notifications or not self._active_channels_fn or not self._bus:
            return
        targets = self._active_channels_fn()
        if not targets:
            return
        async with self._pending_lock:
            if not self._pending_notifications:
                return
            pending = list(self._pending_notifications)
            self._pending_notifications.clear()
        logger.info("Flushing {} buffered notifications to {}", len(pending), targets)
        for notification in pending:
            if await self._publish_to_targets(notification, targets):
                await self._ack_delivered_notification(notification)

    @staticmethod
    async def _ack_delivered_notification(notification: dict[str, Any]) -> None:
        callback = notification.get("_on_delivered")
        if not callable(callback):
            return
        try:
            result = callback()
            if isawaitable(result):
                await result
        except Exception as exc:  # noqa: BLE001 - delivery already succeeded
            logger.warning("Cron delivery acknowledgement failed: {}", exc)

    async def _publish_to_targets(self, notification: dict[str, Any], targets: list[str]) -> bool:
        """Publish a notification to each target channel."""
        if not self._bus:
            return False
        requires_teams_receipt = callable(notification.get("_on_delivered"))
        delivered = False
        for channel in targets:
            try:
                channel_type = ChannelType.of(channel)
                metadata = dict(notification.get("metadata", {}))
                cloud_channel = None
                push_request_id = None
                push_event = None
                if channel_type == ChannelType.CLOUD and "push_target" not in metadata:
                    metadata["push_target"] = self.CLOUD_NOTIFICATION_PUSH_TARGET
                    logger.info(
                        "Publishing cron notification '{}' to cloud:{}",
                        notification.get("metadata", {}).get("job_name", "?"),
                        metadata["push_target"],
                    )
                if channel_type == ChannelType.CLOUD and self._channel_resolver:
                    cloud_channel = self._channel_resolver(channel_type)
                    if cloud_channel is not None:
                        push_request_id = f"cron:{uuid.uuid4().hex}"
                        metadata["push_request_id"] = push_request_id
                        push_event = cloud_channel.wait_push_delivery(push_request_id)
                out = OutboundMessage(
                    channel=channel_type,
                    channel_id=notification["channel_id"],
                    content=notification["content"],
                    metadata=metadata,
                )
                receipt = None
                try:
                    accepted = await self._bus.publish_outbound(out)
                    if channel_type == ChannelType.CLOUD and cloud_channel is not None:
                        if accepted and push_event is not None:
                            await asyncio.wait_for(
                                push_event.wait(),
                                timeout=self.CLOUD_DELIVERY_ACK_TIMEOUT_SECONDS,
                            )
                        receipt = cloud_channel.get_push_delivery(push_request_id)
                except TimeoutError:
                    accepted = False
                finally:
                    if cloud_channel is not None and receipt is None:
                        cloud_channel.get_push_delivery(push_request_id)
                if requires_teams_receipt:
                    accepted = bool(
                        accepted
                        and channel_type == ChannelType.CLOUD
                        and receipt
                        and receipt.get("teams")
                    )
                elif channel_type == ChannelType.CLOUD and cloud_channel is not None:
                    target = str(metadata.get("push_target") or "").casefold()
                    accepted = accepted and bool(receipt and receipt.get(target))
                if accepted:
                    delivered = True
            except Exception as exc:
                logger.warning("Cron notify to '{}' failed: {}", channel, exc)
        return delivered

    async def _on_channel_connected(self, event_type: EventType, payload: dict) -> None:
        """Event handler: a channel just (re)connected — flush buffered notifications."""
        if self._pending_notifications:
            logger.info(
                "Channel '{}' connected, flushing pending notifications",
                payload.get("channel", "?"),
            )
            await self._flush_pending()

    # ── Persistence ──────────────────────────────────────────────────────

    def _load_dynamic_jobs(self) -> None:
        """Load dynamic jobs from ~/.praestoclaw/cron/jobs.json (or data_dir/cron)."""
        if not self._jobs_file.is_file():
            return
        try:
            data = json.loads(self._jobs_file.read_text(encoding="utf-8"))
            retired = False
            for item in data:
                name = item["name"]
                if (name, str(item.get("tool") or "")) == _RETIRED_PRAESTOCLAW_WATCHER:
                    retired = True
                    logger.info(
                        "Removed retired PraestoClaw PR watcher '{}' during cron migration",
                        name,
                    )
                    continue
                # ChannelType is a StrEnum, persisted as a plain string —
                # coerce back to the enum so callers can use ``.value`` etc.
                raw_channel = item.get("channel")
                channel: ChannelType | None
                if raw_channel is None or isinstance(raw_channel, ChannelType):
                    channel = raw_channel
                else:
                    try:
                        channel = ChannelType(raw_channel)
                    except ValueError:
                        logger.warning(
                            "Job '{}' has unknown channel {!r}; ignoring",
                            name,
                            raw_channel,
                        )
                        channel = None
                loaded_nc = _normalize_channel_list(item.get("notify_channels"))
                if loaded_nc is not None:
                    resolved_nc = loaded_nc
                else:
                    resolved_nc = ["*"]
                # For message-mode jobs, an empty channel list is never
                # intentional — fall back to the origin channel so list/info
                # reflects the real delivery target (consistent with add_job).
                if item.get("message") and not resolved_nc:
                    resolved_nc = self._message_fallback_channels(channel)
                self._jobs[name] = _Job(
                    name=name,
                    schedule=item["schedule"],
                    agent=item.get("agent", "default"),
                    prompt=item["prompt"] if "prompt" in item else item.get("task", ""),
                    message=item.get("message"),
                    tool=item.get("tool"),
                    arguments=item.get("arguments"),
                    workflow_recipe=item.get("workflow_recipe"),
                    session_mode=item.get("session_mode", "isolated"),
                    notify_channels=resolved_nc,
                    exclude_tools=item.get("exclude_tools", []),
                    enabled=item.get("enabled", True),
                    dynamic=True,
                    channel=channel,
                    channel_id=item.get("channel_id"),
                    kb_capability=ScheduledKbCapability.from_dict(item.get("kb_capability")),
                    created_at=item.get("created_at"),
                    updated_at=item.get("updated_at"),
                    description=item.get("description"),
                    timezone=item.get("timezone"),
                    last_run_at=item.get("last_run_at"),
                    last_status=item.get("last_status"),
                    last_error=item.get("last_error"),
                    pending_catchup_at=item.get("pending_catchup_at"),
                )
            if retired:
                # The generic fix-bug workflow ends when its draft PR opens and has
                # no Review item to resume. Persist removal so the deleted scanner
                # is not retried every ten minutes after an upgrade.
                self._persist_dynamic_jobs()
            logger.debug("Loaded {} dynamic jobs", len(self._jobs))
        except Exception as exc:
            logger.warning("Failed to load dynamic jobs: {}", exc)

    def _persist_dynamic_jobs(self) -> None:
        """Save dynamic jobs to ~/.praestoclaw/cron/jobs.json (or data_dir/cron)."""
        with self._jobs_lock:
            self._cron_dir.mkdir(parents=True, exist_ok=True)
            dynamic = [
                {
                    "name": j.name,
                    "schedule": j.schedule,
                    "agent": j.agent,
                    "prompt": j.prompt,
                    "session_mode": j.session_mode,
                    "notify_channels": j.notify_channels,
                    **({"exclude_tools": j.exclude_tools} if j.exclude_tools else {}),
                    "enabled": j.enabled,
                    **({"channel": j.channel} if j.channel else {}),
                    **({"channel_id": j.channel_id} if j.channel_id else {}),
                    **(
                        {"kb_capability": j.kb_capability.to_dict()}
                        if j.kb_capability is not None
                        else {}
                    ),
                    **({"message": j.message} if j.message else {}),
                    **({"tool": j.tool} if j.tool else {}),
                    **({"workflow_recipe": j.workflow_recipe} if j.workflow_recipe else {}),
                    **({"arguments": j.arguments} if j.arguments is not None else {}),
                    **({"created_at": j.created_at} if j.created_at else {}),
                    **({"updated_at": j.updated_at} if j.updated_at else {}),
                    **({"description": j.description} if j.description else {}),
                    **({"timezone": j.timezone} if j.timezone else {}),
                    **({"last_run_at": j.last_run_at} if j.last_run_at else {}),
                    **({"last_status": j.last_status} if j.last_status else {}),
                    **({"last_error": j.last_error} if j.last_error else {}),
                    **(
                        {"pending_catchup_at": j.pending_catchup_at} if j.pending_catchup_at else {}
                    ),
                }
                for j in self._jobs.values()
                if j.dynamic
            ]
            self._jobs_file.write_text(
                json.dumps(dynamic, indent=2, ensure_ascii=False), encoding="utf-8"
            )

    def _record_run(
        self,
        job_id: str,
        run_id: str,
        status: str,
        result: str | None,
        duration: float,
        started_at: datetime | None = None,
        error_type: str | None = None,
    ) -> None:
        """Append run record to .praestoclaw/cron/runs/{job_id}.jsonl."""
        self._runs_dir.mkdir(parents=True, exist_ok=True)
        path = self._runs_dir / f"{_safe_filename(job_id)}.jsonl"
        record: dict[str, Any] = {
            "run_id": run_id,
            "triggered_at": (started_at or datetime.now(UTC)).isoformat(),
            "status": status,
            "result_preview": result[:500] if result else "",
            "duration_s": round(duration, 2),
        }
        if error_type:
            record["error_type"] = error_type
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

        # Auto-prune: keep last N entries
        self._prune_history(path)

    def _prune_history(self, path: Path) -> None:
        """Keep only the last HISTORY_MAX_ENTRIES lines."""
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
            if len(lines) > self.HISTORY_MAX_ENTRIES:
                path.write_text(
                    "\n".join(lines[-self.HISTORY_MAX_ENTRIES :]) + "\n",
                    encoding="utf-8",
                )
        except Exception:
            pass

    def get_history(self, job_id: str, limit: int = 20) -> list[dict]:
        """Read run history for a job."""
        path = self._runs_dir / f"{_safe_filename(job_id)}.jsonl"
        if not path.is_file():
            return []
        entries = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return entries[-limit:]
