"""Run deterministic bundle work in the Host's managed Python subprocess."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

from .state import load_state, save_state


async def run(state_path: Path) -> None:
    from .collector import collect_bundle
    from .delivery import deliver_bundle

    state = load_state(state_path)
    try:
        if not state.get("package"):
            state["phase"] = "collection"
            save_state(state_path, state)
            collect_bundle(state, state_path)
            save_state(state_path, state)
        if state.get("package"):
            state["phase"] = "delivery"
            save_state(state_path, state)
            await deliver_bundle(state, state_path)
    except Exception as exc:
        stage = "collection" if state.get("phase") == "collection" else "upload"
        state.setdefault(stage, {}).update(status="failed", error=str(exc))
    finally:
        save_state(state_path, state)
    if state.get("collection", {}).get("status") == "failed":
        raise RuntimeError(state["collection"]["error"])


if __name__ == "__main__":
    asyncio.run(run(Path(sys.argv[1])))
