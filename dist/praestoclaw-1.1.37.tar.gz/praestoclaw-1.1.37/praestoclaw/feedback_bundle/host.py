"""Bind a group feedback bundle to the Host's background lifecycle."""

from __future__ import annotations

import asyncio
import re
import subprocess
import sys
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import asdict
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from praestoclaw.agent.tools.shell import _kill_proc_tree
from praestoclaw.config.schema import ChannelType
from praestoclaw.host.background_tasks import (
    BackgroundOrigin,
    BackgroundTask,
    BackgroundTaskManager,
    origin_from_kwargs,
)
from praestoclaw.security.feedback import feedback_is_shared

from .state import load_state, render_result, save_state

LABEL = "feedback_bundle"


class FeedbackBundleHost:
    def __init__(
        self,
        *,
        data_dir: Path,
        manager: BackgroundTaskManager,
        config: Callable[[], Any],
        context: Callable[[], dict[str, Any]],
        finalize: Callable[[dict[str, Any], Path], Awaitable[None]],
    ) -> None:
        self._root = data_dir / "feedback-bundles"
        self._manager = manager
        self._config = config
        self._context = context
        self._finalize = finalize
        self._paths: dict[str, Path] = {}
        manager.add_terminal_observer(self._terminal)

    @staticmethod
    def _identity(session_id: str, context: dict[str, Any]) -> tuple[str, BackgroundOrigin]:
        metadata = context.get("_metadata") or {}
        cid = str(metadata.get("cid") or "").strip()
        origin = origin_from_kwargs(context)
        if (
            not session_id
            or not cid
            or not feedback_is_shared(metadata)
            or origin is None
            or origin.channel != ChannelType.CLOUD
        ):
            raise ValueError("反馈包仅支持当前可信 Teams 群会话。")
        return cid, origin

    def resolve(self, bundle_id: str, session_id: str, **context: Any) -> Path:
        cid, _ = self._identity(session_id, context)
        if not re.fullmatch(r"[0-9a-f]{32}", bundle_id):
            raise ValueError("无效反馈包 ID。")
        path = self._root / bundle_id / "state.json"
        state = load_state(path)
        if state["cid"] != cid:
            raise ValueError("反馈包不属于当前群。")
        return path

    async def prepare(self, original_text: str, session_id: str, **context: Any) -> dict[str, Any]:
        cid, origin = self._identity(session_id, context)
        if not original_text.strip():
            raise ValueError("请先描述反馈问题。")
        now = datetime.now(UTC)
        bundle_id = uuid.uuid4().hex
        path = self._root / bundle_id / "state.json"
        path.parent.mkdir(parents=True)
        config = self._config().feedback_bundle
        state = {
            "bundle_id": bundle_id,
            "created_at": now.isoformat(),
            "package_name": now.strftime("%Y%m%dT%H%M%S.%fZ.zip"),
            "original_text": original_text,
            "cid": cid,
            "session_id": session_id,
            "origin": {**asdict(origin), "channel": origin.channel.value},
            "recipients": list(config.recipients),
            "sync_timeout_seconds": config.sync_timeout_seconds,
            "phase": "prepared",
            "status": "prepared",
            "issue": {"status": "not_submitted"},
            "association": {"status": "not_started"},
            "receipt": {"status": "not_started"},
        }
        save_state(path, state)
        return {"bundle_id": bundle_id, "status": "prepared", "package_name": state["package_name"]}

    async def status(self, bundle_id: str, session_id: str, **context: Any) -> dict[str, Any]:
        path = self.resolve(bundle_id, session_id, **context)
        state = load_state(path)
        if state["status"] == "running" and not self._manager.status(state.get("task_id", "")):
            state["status"] = "interrupted"
            state["interruption"] = f"{state['phase']}: Host 中已无此后台任务；可重试恢复。"
            save_state(path, state)
        return {
            "bundle_id": bundle_id,
            "status": state["status"],
            "result": render_result(state),
            "receipt": state["receipt"],
            "task_id": state.get("task_id"),
        }

    async def start(
        self,
        bundle_id: str,
        session_id: str,
        retry: bool = False,
        **context: Any,
    ) -> dict[str, Any]:
        path = self.resolve(bundle_id, session_id, **context)
        state = load_state(path)
        config = self._config()
        if not config.execution.background_delivery_enabled:
            return {"status": "not_started", "error": "后台主动投递已关闭，未启动收集。"}
        previous = self._manager.status(state.get("task_id", ""))
        if previous and previous["state"] == "running":
            return {"status": "running", "bundle_id": bundle_id, "task_id": state["task_id"]}
        if state["status"] != "prepared" and not retry:
            return await self.status(bundle_id, session_id, **context)
        origin_fields = dict(state["origin"])
        origin_fields["channel"] = ChannelType(origin_fields["channel"])
        task_id = self._manager.adopt(
            lambda: self._run(path),
            origin=BackgroundOrigin(**origin_fields),
            owner=state["session_id"],
            question=state["original_text"],
            label=LABEL,
            terminal_content=lambda record: render_result(load_state(path)),
            delivery_callback=self._receipt,
        )
        if task_id is None:
            return {
                "status": "not_started",
                "error": "后台任务名额不足或 Host 正在关闭；未启动收集。",
            }
        now = datetime.now(UTC)
        state.update(
            task_id=task_id,
            status="running",
            started_at=now.isoformat(),
            deadline_at=(
                now + timedelta(seconds=config.execution.background_task_timeout_seconds)
            ).isoformat(),
            total_timeout_seconds=config.execution.background_task_timeout_seconds,
            receipt={"status": "pending"},
        )
        state.pop("interruption", None)
        if not state.get("package"):
            state["context"] = {
                **self._context(),
                "cid": state["cid"],
                "session_id": state["session_id"],
                "group_url": "https://teams.microsoft.com/l/chat/"
                + state["cid"]
                + "/conversations",
            }
        save_state(path, state)
        self._paths[task_id] = path
        return {
            "status": "running",
            "bundle_id": bundle_id,
            "task_id": task_id,
            "message": "正在收集，完成后将自动向原群回执。",
        }

    async def _run(self, path: Path) -> str:
        process = None
        try:
            options: dict[str, Any] = (
                {"creationflags": subprocess.CREATE_NO_WINDOW}  # type: ignore[attr-defined]
                if sys.platform == "win32"
                else {"start_new_session": True}
            )
            with path.with_name("worker.log").open("ab") as output:
                process = await asyncio.create_subprocess_exec(
                    sys.executable,
                    "-m",
                    "praestoclaw.feedback_bundle.worker",
                    str(path),
                    stdout=output,
                    stderr=output,
                    **options,
                )
                code = await process.wait()
            if code:
                raise RuntimeError(
                    f"反馈包脚本退出码 {code}；详情见 {path.with_name('worker.log')}"
                )
            state = load_state(path)
            state["phase"] = "association"
            save_state(path, state)
            await self._finalize(state, path)
            return render_result(load_state(path))
        finally:
            if process is not None:
                await _kill_proc_tree(process)

    def _terminal(self, record: BackgroundTask) -> None:
        path = self._paths.get(record.task_id)
        if path is None:
            return
        state = load_state(path)
        state["status"] = record.state
        state["finished_at"] = datetime.now(UTC).isoformat()
        if record.state != "completed":
            reason = "后台总期限已到" if record.state == "timeout" else record.error
            state["interruption"] = f"{state['phase']}: {reason}"
            if record.state == "cancelled":
                state["receipt"] = {"status": "cancelled"}
                if self._manager._closed:
                    self._paths.pop(record.task_id)
        save_state(path, state)

    def _receipt(self, record: BackgroundTask, delivered: bool) -> None:
        path = self._paths.pop(record.task_id)
        state = load_state(path)
        state["receipt"] = {
            "status": "success" if delivered else "failed",
            "at": datetime.now(UTC).isoformat(),
        }
        save_state(path, state)
