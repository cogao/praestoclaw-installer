"""The persisted result and verbatim delivery text for one feedback bundle."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def load_state(path: Path) -> dict[str, Any]:
    state: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
    return state


def save_state(path: Path, state: dict[str, Any]) -> None:
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def render_result(state: dict[str, Any], *, include_association: bool = True) -> str:
    """Render trusted values directly; do not pass this through body sanitization."""
    collection = state.get("collection", {})
    package = state.get("package", {})
    upload = state.get("upload", {})
    issue = state.get("issue", {})
    lines = [
        f"反馈调试包 {state['bundle_id']}",
        f"文字反馈：{issue.get('status', 'not_submitted')}",
        f"包名：{state['package_name']}；大小：{package.get('size', '未知')} bytes",
        f"收集：{collection.get('status', 'not_started')}；"
        f"{collection.get('started_at', '未开始')} — {collection.get('finished_at', '未结束')}",
        f"云端内容核验：{upload.get('status', 'not_started')}",
    ]
    if issue.get("url"):
        lines.append(f"Issue：{issue['url']}")
    if issue.get("status") != "submitted":
        lines.append("文字反馈尚未提交成功；调试包结果独立保留。")
    for part in (issue, collection, upload):
        if part.get("error"):
            lines.append(str(part["error"]))
    if package.get("path"):
        lines.append(f"本地包：{package['path']}")
    else:
        lines.append("尚无有效 ZIP。")
    if upload.get("path"):
        lines.append(f"同步目录：{upload['path']}")
    if upload.get("url"):
        lines.append(f"OneDrive：{upload['url']}")
    recipients = state.get("recipients", [])
    if not recipients:
        lines.append("接收人未配置。")
    for email in recipients:
        permission = state.get("permissions", {}).get(email, {})
        detail = permission.get("error") or permission.get("message")
        lines.append(
            f"{email}：{permission.get('status', 'not_started')}"
            + (f"（{detail}）" if detail else "")
        )
    gaps = collection.get("gaps", [])
    if gaps:
        lines.append(f"材料缺口：{len(gaps)} 项；完整列表见 ZIP 内 data/manifest.json。")
        for gap in gaps[:3]:
            lines.append(str(gap)[:350])
    if include_association:
        association = state.get("association", {})
        lines.append(f"问题关联：{association.get('status', 'not_started')}")
        if association.get("error"):
            lines.append(str(association["error"]))
    if state.get("interruption"):
        lines.append(f"任务中断：{state['interruption']}")
        if upload.get("path"):
            lines.append("同步目录中的文件仍可能被 OneDrive 客户端上传；重试将重新核验。")
    return "\n".join(lines)
