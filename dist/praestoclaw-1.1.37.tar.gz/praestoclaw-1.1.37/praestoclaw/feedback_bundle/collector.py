"""Read-only collection of a group's retained diagnostic material."""

from __future__ import annotations

import gzip
import hashlib
import json
import re
import shutil
import sqlite3
import zipfile
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from praestoclaw.agent.praesto_tag_exp_group_store import _slug
from praestoclaw.cron.job import safe_filename
from praestoclaw.kb.draft import conversation_slug
from praestoclaw.teams_web.store import cid_slug

from .state import save_state

_SESSION_KEYS = {
    "_session_id",
    "_plan_session_id",
    "session_id",
    "plan_session_id",
    "parent_session_id",
    "conversation_session_id",
    "child_session_id",
    "workflow_owner",
}
_PATH_KEYS = {
    "path",
    "local_path",
    "cache_path",
    "text_cache_path",
    "file_path",
    "output_path",
    "artifact_path",
    "attachment_path",
    "source_file",
    "source_path",
    "prompt_path",
    "prompt_file",
    "workflow_path",
    "workspace_path",
    "directory",
    "cwd",
    "workdir",
    "capture_path",
    "draft_path",
    "repo_path",
    "worktree_path",
    "publish_worktree_path",
    "cache_dir",
    "capture_file",
}
_TASK_KEYS = {"task_id", "origin_task", "background_task_id"}
_STAMP = re.compile(r"\d{4}-\d\d-\d\d[T ]\d\d:\d\d:\d\d(?:[.,]\d+)?(?:Z|[+-]\d\d:\d\d)?")


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
    temporary.replace(path)


class _Collection:
    def __init__(self, state: dict[str, Any], state_path: Path) -> None:
        self.state = state
        self.context = state["context"]
        self.root = Path(self.context["data_dir"]).resolve()
        self.cid = self.context["cid"]
        self.stage = state_path.parent / "collected"
        self.stage.mkdir(parents=True, exist_ok=True)
        self.items: list[dict[str, Any]] = []
        self.gaps: list[dict[str, Any]] = []
        self.sessions: dict[str, list[str]] = {}
        self.tasks: set[str] = set()
        self.approvals: set[str] = set()
        self.jobs: set[str] = set()
        self.files: set[Path] = set()
        self.pending: list[tuple[Path, str, str]] = []
        slug = cid_slug(self.cid)
        self.group_roots = {
            self.root / "teams-web/chats": self.root / "teams-web/chats" / slug,
            self.root / "meetings": self.root / "meetings" / slug,
            self.root / "memory/groups": self.root / "memory/groups" / _slug(self.cid),
            self.root / "group-skills": self.root
            / "group-skills"
            / hashlib.sha256(self.cid.encode()).hexdigest()[:24],
        }
        self.excluded = [
            self.root / "feedbacks",
            state_path.parent.parent,
            Path.home() / "OneDrive - Microsoft" / "feedbacks",
            *(Path(p).resolve() for p in self.context.get("excluded_paths", [])),
        ]

    def gap(self, source: str, status: str, reason: str, category: str = "reference") -> None:
        entry = {"category": category, "source": source, "status": status, "reason": reason}
        if entry not in self.gaps:
            self.gaps.append(entry)

    def archive_path(self, path: Path) -> str:
        if path.is_relative_to(self.root):
            return "data/" + path.relative_to(self.root).as_posix()
        digest = hashlib.sha256(str(path.parent).encode()).hexdigest()
        return f"data/external/{digest}/{path.name}"

    def emit(self, name: str, value: Any, source: str, category: str) -> None:
        path = self.stage / name
        _write_json(path, value)
        self.items.append(
            {
                "category": category,
                "source": source,
                "archive_path": name,
                "size": path.stat().st_size,
                "status": "success",
                "records": len(value) if isinstance(value, list) else None,
            }
        )

    def add_session(self, sid: str, reason: str) -> None:
        reasons = self.sessions.setdefault(sid, [])
        if reason not in reasons:
            reasons.append(reason)

    def references(self, value: Any, source: str, base: Path) -> None:
        if isinstance(value, list):
            for child in value:
                self.references(child, source, base)
        elif isinstance(value, dict):
            if value.get("role") == "tool" and isinstance(value.get("content"), str):
                try:
                    self.references(json.loads(value["content"]), source, base)
                except json.JSONDecodeError:
                    pass
            for key, child in value.items():
                if isinstance(child, str) and child:
                    if key in _SESSION_KEYS:
                        self.add_session(child, f"{source}: {key}")
                    elif key in _TASK_KEYS:
                        self.tasks.add(child)
                    elif key in {"request_id", "approval_request_id"}:
                        self.approvals.add(child)
                    elif key == "scheduler_job_id":
                        self.jobs.add(child)
                    elif key == "capture":
                        self.pending.append(
                            (self.root / "kb/captures" / child, "kb", f"{source}: capture")
                        )
                    elif key in {"workflow", "workflow_recipe"}:
                        sources = self.context.get("workflow_sources", {})
                        path = (
                            Path(sources[child])
                            if child in sources
                            else self.root / "workflows" / f"{child}.md"
                        )
                        if child not in sources and not path.exists():
                            path = (
                                Path(__file__).parents[1]
                                / "agent/tools/bundled_workflows"
                                / f"{child}.md"
                            )
                        self.pending.append((path, "workflow", f"{source}: {key}"))
                    elif key in _PATH_KEYS:
                        if child.startswith(("https://", "http://")):
                            self.gap(child, "remote_only", "Referenced URL; not downloaded")
                        else:
                            path = Path(child).expanduser()
                            if not path.is_absolute():
                                path = base / path
                            self.pending.append((path, "reference", f"{source}: {key}"))
                    elif key in {
                        "url",
                        "download_url",
                        "contentUrl",
                        "webUrl",
                        "remote_url",
                    } and child.startswith(("http://", "https://")):
                        self.gap(
                            child, "remote_only", "URL retained; remote content was not downloaded"
                        )
                    elif key in {"metadata", "arguments", "tool_calls"}:
                        try:
                            self.references(json.loads(child), source, base)
                        except json.JSONDecodeError:
                            pass
                self.references(child, source, base)

    def scan(self, path: Path, source: str, base: Path) -> None:
        try:
            if path.suffix == ".json":
                value = json.loads(path.read_text(encoding="utf-8"))
                self.references(value, source, base)
            elif path.suffix == ".jsonl":
                with path.open(encoding="utf-8") as stream:
                    for number, line in enumerate(stream, 1):
                        if line.strip():
                            try:
                                self.references(json.loads(line), f"{source}:{number}", base)
                            except json.JSONDecodeError as exc:
                                self.gap(f"{source}:{number}", "parse_failed", str(exc))
        except (OSError, UnicodeError, ValueError) as exc:
            self.gap(source, "parse_failed", str(exc))

    def copy(self, source: Path, category: str, relation: str, *, scan: bool = True) -> None:
        path = source.resolve()
        if path in {
            self.root / "sessions.db",
            self.root / "group-skills/registry.json",
            self.root / "group-mcps/registry.json",
            self.root / "cron/jobs.json",
        }:
            # These shared sources are exported through their filtered readers.
            return
        for shared, owned in self.group_roots.items():
            if path.is_relative_to(shared) and not path.is_relative_to(owned):
                self.gap(
                    str(path),
                    "excluded",
                    "Other group or shared group root; reference is not ownership",
                    category,
                )
                return
        if any(path.is_relative_to(excluded) for excluded in self.excluded):
            self.gap(str(source), "excluded", "Feedback output excluded", category)
            return
        # References must name an owned resource, never a shared profile root.
        if path in {self.root, self.root / "kb", self.root / "workspace", self.root / "skills"}:
            self.gap(
                str(source), "not_collected", "Reference names an entire shared root", category
            )
            return
        if path in self.files:
            return
        self.files.add(path)
        try:
            if path.is_dir():
                children = list(path.iterdir())
                if not children:
                    self.items.append(
                        {
                            "source": str(path),
                            "category": category,
                            "status": "no_records",
                            "relation": relation,
                        }
                    )
                for child in children:
                    self.copy(child, category, relation, scan=scan)
                return
            before = path.stat()
            name = self.archive_path(path)
            destination = self.stage / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            with path.open("rb") as src, destination.open("wb") as dst:
                shutil.copyfileobj(src, dst, 1024 * 1024)
            after = path.stat()
            size = destination.stat().st_size
            self.items.append(
                {
                    "category": category,
                    "source": str(path),
                    "archive_path": name,
                    "size": size,
                    "status": "success",
                    "relation": relation,
                }
            )
            if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                self.gap(
                    str(path), "changed_during_collection", "Source changed while copied", category
                )
            if scan:
                self.scan(destination, str(path), path.parent)
        except FileNotFoundError:
            config = self.context.get("effective_config", {})
            enabled = {
                "audit": config.get("security", {}).get("audit", {}).get("enabled"),
                "cron/runs": config.get("cron", {}).get("enabled"),
                "workflows/runs": config.get("workflow", {}).get("enabled"),
                f"teams-web/chats/{cid_slug(self.cid)}": config.get("praesto_tag_exp", {})
                .get("teams_web", {})
                .get("enabled"),
            }.get(path.relative_to(self.root).as_posix() if path.is_relative_to(self.root) else "")
            if enabled is False:
                self.items.append(
                    {
                        "category": category,
                        "source": str(path),
                        "status": "not_enabled",
                        "relation": relation,
                    }
                )
            else:
                self.gap(
                    str(path),
                    "source_missing",
                    "Source does not exist; retention history unknown",
                    category,
                )
        except OSError as exc:
            self.gap(str(path), "read_failed", str(exc), category)

    def read_json(self, relative: str) -> Any:
        path = self.root / relative
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            self.gap(str(path), "source_missing", "Source does not exist", "registry")
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            self.gap(str(path), "read_failed", str(exc), "registry")
        return None

    def belongs(self, value: Any) -> bool:
        if isinstance(value, list):
            return any(self.belongs(child) for child in value)
        if not isinstance(value, dict):
            return False
        for key, child in value.items():
            if key in {"chat_id", "cid", "channel_id", "conversation_id"} and child == self.cid:
                return True
            if key in _SESSION_KEYS and isinstance(child, str) and child in self.sessions:
                return True
            if key in _TASK_KEYS and isinstance(child, str) and child in self.tasks:
                return True
            if self.belongs(child):
                return True
        return False

    def collect(self) -> None:
        self.add_session(self.context["session_id"], "feedback original session")
        slug = cid_slug(self.cid)
        for relative in (
            f"teams-web/chats/{slug}",
            f"meetings/{slug}",
            f"memory/groups/{_slug(self.cid)}",
            f"group-skills/{hashlib.sha256(self.cid.encode()).hexdigest()[:24]}",
        ):
            self.copy(self.root / relative, "group", self.cid)
        # These stores carry explicit conversation ownership, unlike a KB binding
        # (which is only a preferred repository/subfolder, not file ownership).
        for directory in (
            self.root / "kb/tasks" / conversation_slug(self.cid),
            self.root / "kb/captures",
        ):
            if not directory.exists():
                self.items.append(
                    {"category": "kb", "source": str(directory), "status": "no_records"}
                )
                continue
            for path in directory.glob("*.json"):
                try:
                    record = json.loads(path.read_text(encoding="utf-8"))
                    owner = record.get("cid") or record.get("request_context", {}).get(
                        "requesting_conversation_id"
                    )
                    if owner == self.cid:
                        self.copy(path, "kb", f"stored conversation ownership: {self.cid}")
                except (OSError, UnicodeError, json.JSONDecodeError) as exc:
                    self.gap(str(path), "read_failed", str(exc), "kb")
        skills = self.read_json("group-skills/registry.json")
        if skills is not None:
            selected = {
                "version": skills.get("version"),
                "skills": [r for r in skills.get("skills", []) if r.get("chat_id") == self.cid],
                "disabled_bundled": [
                    r for r in skills.get("disabled_bundled", []) if r[0] == self.cid
                ],
            }
            self.emit(
                "data/group-skills/registry.json",
                selected,
                "group-skills/registry.json",
                "registry",
            )
            self.references(selected, "group-skills/registry.json", self.root)
        mcps = self.read_json("group-mcps/registry.json")
        if mcps is not None:
            selected_mcps = [r for r in mcps if r.get("chat_id") == self.cid]
            self.emit(
                "data/group-mcps/registry.json",
                selected_mcps,
                "group-mcps/registry.json",
                "registry",
            )
            self.references(selected_mcps, "group-mcps/registry.json", self.root)
        for source in self.context.get("config_sources", []):
            config_path = source.get("path") if isinstance(source, dict) else source
            if config_path:
                # Runtime configuration is retained, but does not expand group ownership.
                self.copy(
                    Path(config_path), "config", "configuration at collection time", scan=False
                )
        self.emit(
            "data/feedback/context.json",
            {k: v for k, v in self.context.items() if k not in {"background_tasks", "approvals"}},
            "Host runtime",
            "environment",
        )
        self.emit(
            "data/feedback/feedback.json",
            {
                k: self.state.get(k)
                for k in ("bundle_id", "created_at", "original_text", "recipients", "package_name")
            },
            "feedback state",
            "feedback",
        )
        self.related_records()
        for relative in ("logs", "audit", "cron/runs", "workflows/runs", "token_usage.jsonl"):
            self.copy(
                self.root / relative,
                "logs",
                "complete mixed logs; no time or group filtering",
                scan=False,
            )
        self.items.append(
            {
                "category": "tasks",
                "source": "historical Host memory",
                "status": "limitation",
                "reason": "Only the supplied snapshot and retained run/plan records are available; unknown historical memory-only state cannot be reconstructed.",
            }
        )

    def related_records(self) -> None:
        cron = self.read_json("cron/jobs.json")
        jobs = cron if isinstance(cron, list) else (cron or {}).get("jobs", [])
        tasks = self.context.get("background_tasks", [])
        if isinstance(tasks, dict):
            tasks = tasks.get("tasks", list(tasks.values()))
        selected_jobs: list[Any] = []
        selected_tasks: list[Any] = []
        selected_approvals: list[Any] = []
        seen_runs: set[tuple[str, int]] = set()
        done: set[str] = set()
        database = self.root / "sessions.db"
        connection = None
        try:
            if database.exists():
                try:
                    connection = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True)
                    connection.row_factory = sqlite3.Row
                    for row in connection.execute(
                        "SELECT id FROM sessions WHERE instr(id, ?) > 0 OR instr(sender, ?) > 0",
                        (self.cid, self.cid),
                    ):
                        self.add_session(row["id"], "sessions.db: id or sender contains full CID")
                except sqlite3.Error as exc:
                    self.gap(str(database), "read_failed", str(exc), "sessions")
                    if connection is not None:
                        connection.close()
                    connection = None
            else:
                self.gap(str(database), "source_missing", "sessions.db does not exist", "sessions")
            while True:
                previous = (
                    len(done),
                    len(self.files),
                    len(selected_jobs),
                    len(selected_tasks),
                    len(selected_approvals),
                    len(seen_runs),
                )
                for job in jobs:
                    if job not in selected_jobs and (
                        self.belongs(job) or job.get("name") in self.jobs
                    ):
                        selected_jobs.append(job)
                        self.jobs.add(job["name"])
                        self.references(job, f"cron job {job.get('name')}", self.root)
                for task in tasks:
                    if task not in selected_tasks and (
                        task.get("owner") in self.sessions or self.belongs(task)
                    ):
                        selected_tasks.append(task)
                        if task.get("owner"):
                            self.add_session(
                                task["owner"], f"background task {task.get('task_id')}: owner"
                            )
                        self.references(task, f"background task {task.get('task_id')}", self.root)
                for approval in self.context.get("approvals", []):
                    if approval not in selected_approvals and (
                        approval.get("id") in self.approvals or self.belongs(approval)
                    ):
                        selected_approvals.append(approval)
                        self.references(approval, f"approval {approval.get('id')}", self.root)
                for directory in (self.root / "cron/runs", self.root / "workflows/runs"):
                    if not directory.exists():
                        continue
                    for path in directory.glob("*.jsonl"):
                        try:
                            with path.open(encoding="utf-8") as stream:
                                for number, line in enumerate(stream, 1):
                                    key = (str(path), number)
                                    if key in seen_runs or not line.strip():
                                        continue
                                    record = json.loads(line)
                                    job_match = (
                                        directory.name == "runs"
                                        and directory.parent.name == "cron"
                                        and any(
                                            path.stem == safe_filename(name) for name in self.jobs
                                        )
                                    )
                                    if job_match or self.belongs(record):
                                        seen_runs.add(key)
                                        self.references(record, f"{path}:{number}", self.root)
                        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
                            self.gap(str(path), "parse_failed", str(exc), "runs")
                for sid in list(self.sessions):
                    if sid in done:
                        continue
                    done.add(sid)
                    try:
                        self.session(sid, connection)
                    except sqlite3.Error as exc:
                        self.gap(f"{database}:{sid}", "read_failed", str(exc), "sessions")
                        self.session(sid, None)
                while self.pending:
                    path, category, relation = self.pending.pop()
                    self.copy(path, category, relation)
                if previous == (
                    len(done),
                    len(self.files),
                    len(selected_jobs),
                    len(selected_tasks),
                    len(selected_approvals),
                    len(seen_runs),
                ):
                    break
        except sqlite3.Error as exc:
            self.gap(str(database), "read_failed", str(exc), "sessions")
        finally:
            if connection is not None:
                connection.close()
        if cron is not None:
            exported = selected_jobs if isinstance(cron, list) else {**cron, "jobs": selected_jobs}
            self.emit(
                "data/cron/jobs.json", exported, str(self.root / "cron/jobs.json"), "registry"
            )
        self.emit(
            "data/feedback/approvals.json",
            {
                "captured_at": self.context.get(
                    "approvals_captured_at", self.state["collection"]["started_at"]
                ),
                "approvals": selected_approvals,
            },
            "Host approval snapshot",
            "approvals",
        )
        self.emit(
            "data/feedback/background_tasks.json",
            {
                "captured_at": self.context.get(
                    "background_tasks_captured_at", self.state["collection"]["started_at"]
                ),
                "tasks": selected_tasks,
            },
            "Host memory snapshot",
            "tasks",
        )

    def session(self, sid: str, connection: sqlite3.Connection | None) -> None:
        digest = hashlib.sha256(sid.encode()).hexdigest()
        safe = re.sub(r"[^A-Za-z0-9_\-.]", "_", sid)
        if connection is not None:
            row = connection.execute("SELECT * FROM sessions WHERE id = ?", (sid,)).fetchone()
            if row is not None:
                metadata = dict(row)
                self.emit(
                    f"data/sessions/metadata/{digest}.json",
                    metadata,
                    f"sessions.db:{sid}",
                    "sessions",
                )
                self.references(metadata, f"sessions.db:{sid}", self.root)
            else:
                self.gap(
                    sid, "no_records", "Referenced session metadata is not retained", "sessions"
                )
            for child in connection.execute(
                "SELECT id FROM sessions WHERE parent_session_id = ?", (sid,)
            ):
                self.add_session(child["id"], f"sessions.db: parent_session_id={sid}")
            if connection.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='messages'"
            ).fetchone():
                # Stream legacy rows rather than accumulate an unlimited transcript in memory.
                name = f"data/sessions/legacy-messages/{digest}.jsonl"
                output = self.stage / name
                output.parent.mkdir(parents=True, exist_ok=True)
                count = 0
                with output.open("w", encoding="utf-8") as stream:
                    for message in connection.execute(
                        "SELECT * FROM messages WHERE session_id = ?", (sid,)
                    ):
                        record = dict(message)
                        stream.write(json.dumps(record, ensure_ascii=False) + "\n")
                        self.references(record, f"messages:{sid}", self.root)
                        count += 1
                self.items.append(
                    {
                        "category": "messages",
                        "source": f"sessions.db:messages:{sid}",
                        "archive_path": name,
                        "size": output.stat().st_size,
                        "status": "success",
                        "records": count,
                    }
                )
        transcripts = [self.root / "sessions" / f"{stem}.jsonl" for stem in {digest, safe}]
        existing = [path for path in transcripts if path.exists()]
        for path in existing:
            self.copy(path, "transcript", sid)
        if not existing:
            self.gap(
                sid, "not_retained", "Neither SHA256 nor legacy transcript exists", "transcript"
            )
        plan = self.root / "plans" / f"{safe[:200] or 'default'}.json"
        if plan.exists():
            self.copy(plan, "plan", sid)
        else:
            self.items.append(
                {"category": "plan", "source": str(plan), "status": "no_records", "relation": sid}
            )

    def log_coverage(self, started: str) -> dict[str, Any]:
        ranges = []
        for item in self.items:
            if item["category"] != "logs" or item.get("status") != "success":
                continue
            path = self.stage / item["archive_path"]
            earliest = latest = None
            unparsed = 0
            try:
                opener = gzip.open if path.suffix == ".gz" else open
                with opener(path, "rt", encoding="utf-8") as stream:
                    for line in stream:
                        match = _STAMP.search(line)
                        if not match:
                            unparsed += 1
                            continue
                        stamp = datetime.fromisoformat(match[0].replace(",", "."))
                        # Loguru's plain timestamps use the Host's local timezone.
                        stamp = stamp.astimezone(UTC)
                        earliest = stamp if earliest is None else min(stamp, earliest)
                        latest = stamp if latest is None else max(stamp, latest)
            except (OSError, UnicodeError, ValueError) as exc:
                self.gap(item["source"], "coverage_unknown", str(exc), "log_coverage")
            ranges.append(
                {
                    "source": item["source"],
                    "earliest": earliest.isoformat() if earliest else None,
                    "latest": latest.isoformat() if latest else None,
                    "unparsed_lines": unparsed,
                }
            )
        return {
            "window_start": (datetime.fromisoformat(started) - timedelta(hours=24)).isoformat(),
            "window_end": started,
            "files": ranges,
            "continuous_coverage": "unknown",
            "note": "Timestamp ranges do not prove continuous coverage. Rotations, unretained files, and lines without parseable timestamps cannot establish continuity; logs are included in full.",
        }


def collect_bundle(state: dict[str, Any], state_path: Path) -> None:
    """Collect into the bundle work directory and publish only a validated ZIP."""
    started = _now()
    collection: dict[str, Any] = {"status": "running", "started_at": started, "gaps": []}
    state["collection"] = collection
    save_state(state_path, state)
    collector = _Collection(state, state_path)
    try:
        collector.collect()
        coverage = collector.log_coverage(started)
        collector.emit("data/feedback/log-coverage.json", coverage, "retained logs", "log_coverage")
        finished = _now()
        manifest = {
            "bundle_id": state["bundle_id"],
            "cid": collector.cid,
            "started_at": started,
            "finished_at": finished,
            "sessions": collector.sessions,
            "materials": collector.items,
            "gaps": collector.gaps,
            "log_coverage": coverage,
        }
        manifest_path = collector.stage / "data/manifest.json"
        _write_json(manifest_path, manifest)
        readme = (
            f"# Group feedback diagnostics\n\nCID: {collector.cid}\n\n"
            f"Group URL: {collector.context.get('group_url', '')}\n\n"
            f"Group name: {collector.context.get('group_name', '')}\n\n"
            f"Bundle: {state['bundle_id']}\n\nCollected: {started} — {finished}\n\n"
            "This is a collection interval, not an atomic or incident-time snapshot. "
            "Stored content is preserved without redaction or truncation; earlier storage losses cannot be recovered. "
            "data/manifest.json records every source, relationship, result and gap. "
            "Profile files retain relative paths; external files use source-specific mappings.\n\n"
            "## Sessions and association evidence\n\n"
            + "\n".join(
                f"- {sid}: {'; '.join(reasons)}" for sid, reasons in collector.sessions.items()
            )
            + "\n\n## Sources and results\n\n"
            + "\n".join(
                f"- {item['source']}: {item['status']} → {item.get('archive_path', '')}"
                for item in collector.items
            )
            + "\n\n## Log coverage (24 hours)\n\n"
            + json.dumps(coverage, ensure_ascii=False, indent=2)
            + "\n\n## Missing or unavailable material\n\n"
            + json.dumps(collector.gaps, ensure_ascii=False, indent=2)
        )
        (collector.stage / "README.md").write_text(readme, encoding="utf-8")
        package = state_path.parent / state["package_name"]
        temporary = package.with_suffix(".zip.tmp")
        names = {
            "README.md",
            "data/manifest.json",
            *(item["archive_path"] for item in collector.items if item.get("status") == "success"),
        }
        with zipfile.ZipFile(
            temporary, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True
        ) as archive:
            archive.writestr("data/", b"")
            for name in sorted(names):
                with (
                    (collector.stage / name).open("rb") as src,
                    archive.open(name, "w", force_zip64=True) as dst,
                ):
                    shutil.copyfileobj(src, dst, 1024 * 1024)
        with zipfile.ZipFile(temporary) as archive:
            bad = archive.testzip()
            if bad:
                raise ValueError(f"ZIP CRC failed: {bad}")
            if not names.issubset(archive.namelist()):
                raise ValueError("ZIP manifest entries are missing")
            for item in collector.items:
                if (
                    item.get("status") == "success"
                    and archive.getinfo(item["archive_path"]).file_size != item["size"]
                ):
                    raise ValueError(f"ZIP size mismatch: {item['archive_path']}")
        temporary.replace(package)
        with package.open("rb") as stream:
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
        state["package"] = {
            "path": str(package.resolve()),
            "size": package.stat().st_size,
            "hashes": {"sha256Hash": digest},
        }
        incomplete = any(gap["status"] not in {"excluded", "remote_only"} for gap in collector.gaps)
        collection.update(
            status="partial" if incomplete else "complete",
            finished_at=finished,
            gaps=collector.gaps,
            manifest_path=str(manifest_path.resolve()),
        )
    except Exception as exc:
        collection.update(status="failed", finished_at=_now(), gaps=collector.gaps, error=str(exc))
    save_state(state_path, state)
