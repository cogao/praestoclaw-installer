"""Group feedback collection and delivery."""
