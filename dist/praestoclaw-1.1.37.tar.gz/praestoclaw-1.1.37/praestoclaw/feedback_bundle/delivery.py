"""OneDrive sync verification and individually confirmed read permissions."""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from urllib.parse import quote

from praestoclaw.chronicle.mcp_caller import McpError, _StdioServer
from praestoclaw.teams_web.store import cid_slug

from .state import save_state


class DeliveryError(McpError):
    def __init__(self, message: str, *, missing: bool = False) -> None:
        super().__init__(message)
        self.missing = missing


def _payload(response: dict[str, Any]) -> Any:
    """Preserve errors which the general Chronicle text adapter discards."""
    error = response.get("error")
    result = response.get("result", {})
    if error or result.get("isError"):
        message = json.dumps(error or result, ensure_ascii=False)
        raise DeliveryError(message, missing="itemNotFound" in message or "404" in message)
    contents = result.get("content", [])
    values = []
    for content in contents:
        if content.get("type") != "text":
            continue
        raw = content["text"]
        try:
            value = json.loads(raw)
        except ValueError as exc:
            raise DeliveryError(raw, missing="itemNotFound" in raw or "404" in raw) from exc
        if isinstance(value, dict) and (value.get("error") or value.get("success") is False):
            message = json.dumps(value, ensure_ascii=False)
            raise DeliveryError(message, missing="itemNotFound" in message or "404" in message)
        values.append(value)
    if not values:
        raise DeliveryError("MCP returned no JSON result")
    return values[0] if len(values) == 1 else values


class _OneDrive(_StdioServer):
    """Reuse Chronicle's stdio plumbing with strict response handling."""

    def __init__(self) -> None:
        super().__init__("onedrive")
        self._request_deadline = 0.0

    async def call_tool(self, tool: str, arguments: dict[str, Any], *, timeout: float) -> Any:
        self._request_deadline = time.monotonic() + timeout
        await self.ensure_started()
        remaining = self._request_deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("OneDrive MCP request deadline")
        return await asyncio.to_thread(self._call_blocking, tool, arguments, remaining)

    def _write(self, payload: dict[str, Any]) -> None:
        if self._closed or time.monotonic() >= self._request_deadline:
            raise TimeoutError("OneDrive MCP request interrupted or deadline reached")
        super()._write(payload)

    def _start_blocking(self) -> None:
        with self._lock:
            if self._closed or time.monotonic() >= self._request_deadline:
                raise TimeoutError("OneDrive MCP initialization interrupted")
            self._proc = subprocess.Popen(
                ["agency", "mcp", self.server, "--transport", "stdio"],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                encoding="utf-8",
                bufsize=1,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,  # type: ignore[attr-defined]
                start_new_session=os.name != "nt",
            )
        import threading

        self._reader = threading.Thread(target=self._read_loop, daemon=True)
        self._reader.start()
        response = self._request_blocking(
            "initialize",
            {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "feedback-bundle", "version": "1"},
            },
            timeout=min(30, self._request_deadline - time.monotonic()),
        )
        if response.get("error") or "protocolVersion" not in response.get("result", {}):
            raise DeliveryError(f"MCP initialize failed: {response}")
        self._write({"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}})

    def _call_blocking(self, tool: str, arguments: dict[str, Any], timeout: float) -> Any:
        return _payload(
            self._request_blocking("tools/call", {"name": tool, "arguments": arguments}, timeout)
        )

    def _close_blocking(self) -> None:
        with self._lock:
            self._closed = True
            proc = self._proc
        if proc is not None and proc.poll() is None:
            if os.name == "nt":
                subprocess.run(
                    ["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    creationflags=subprocess.CREATE_NO_WINDOW,  # type: ignore[attr-defined]
                    check=False,
                )
            else:
                os.killpg(proc.pid, signal.SIGKILL)
        super()._close_blocking()


def quick_xor_hash(path: Path) -> str:
    """Stream QuickXorHash using C-backed bigint XOR folding of 160-byte periods.

    Byte positions repeat every 160 bytes (11-bit rotations in 160 bits).
    Fold a fixed 160 * 4096 byte block logarithmically before rotating its lanes;
    only 160 Python iterations per block are needed, independent of file size.
    """
    folded = 0
    size = 0
    with path.open("rb") as stream:
        while block := stream.read(160 * 4096):
            size += len(block)
            value = int.from_bytes(block, "little")
            width = 160 * 2048 * 8
            while width >= 160 * 8:
                value = (value & ((1 << width) - 1)) ^ (value >> width)
                width //= 2
            folded ^= value
    result = 0
    mask = (1 << 160) - 1
    for index, byte in enumerate(folded.to_bytes(160, "little")):
        shifted = byte << ((index * 11) % 160)
        result ^= (shifted & mask) ^ (shifted >> 160)
    result ^= size << 96
    return base64.b64encode(result.to_bytes(20, "little")).decode("ascii")


def _copy_package(source: Path, destination: Path, sha256: str) -> None:
    try:
        target = destination.open("xb")
    except FileExistsError:
        with destination.open("rb") as stream:
            if hashlib.file_digest(stream, "sha256").hexdigest() != sha256:
                raise DeliveryError(f"OneDrive package name collision: {destination}")
        return
    try:
        with target, source.open("rb") as stream:
            shutil.copyfileobj(stream, target, 1024 * 1024)
    except OSError:
        # Only this attempt's newly created partial copy may be removed.
        destination.unlink()
        raise


def _permission(value: Any, email: str) -> dict[str, Any] | None:
    if isinstance(value, dict):
        if "read" in value.get("roles", []):
            identities = [value.get("grantedToV2", {}), value.get("grantedTo", {})]
            identities += value.get("grantedToIdentitiesV2", [])
            identities += value.get("grantedToIdentities", [])
            for identity in identities:
                for kind in ("user", "siteUser"):
                    user = identity.get(kind, {})
                    if str(user.get("email", "")).casefold() == email.casefold():
                        return value
        for key in ("value", "permissions"):
            if key in value:
                return _permission(value[key], email)
    elif isinstance(value, list):
        for entry in value:
            if found := _permission(entry, email):
                return found
    return None


async def deliver_bundle(
    state: dict[str, Any],
    state_path: Path,
    *,
    _caller: Any = None,
    _root: Path | None = None,
    _poll_seconds: float = 10,
) -> None:
    """Persist stage outcomes; retry the saved package and unsuccessful recipients."""
    upload = state.setdefault("upload", {})
    permissions = state.setdefault("permissions", {})
    caller = _caller or _OneDrive()
    total_deadline = datetime.fromisoformat(state["deadline_at"])

    async def call(tool: str, arguments: dict[str, Any], deadline: datetime) -> Any:
        nonlocal caller
        remaining = (min(deadline, total_deadline) - datetime.now(UTC)).total_seconds()
        if remaining <= 0:
            raise TimeoutError(
                "background total deadline"
                if total_deadline <= deadline
                else "OneDrive sync deadline"
            )
        timeout = min(120, remaining)
        try:
            async with asyncio.timeout(timeout):
                return await caller.call_tool(tool, arguments, timeout=timeout)
        except TimeoutError as exc:
            # Stop the reader/request threads before any subsequent recipient can
            # begin another call and replace the transport's request deadline.
            await caller.aclose()
            caller = _OneDrive()
            if datetime.now(UTC) >= total_deadline:
                reason = "background total deadline"
            elif datetime.now(UTC) >= deadline:
                reason = "OneDrive sync deadline"
            else:
                reason = "OneDrive MCP request deadline"
            raise TimeoutError(reason) from exc

    try:
        if upload.get("status") != "success":
            state["phase"] = "upload"
            upload.update(status="running", error=None)
            save_state(state_path, state)
            if _root is None and os.name != "nt":
                raise DeliveryError("OneDrive delivery requires Windows")
            root = _root or Path.home() / "OneDrive - Microsoft"
            if not root.is_dir():
                raise DeliveryError(f"OneDrive root does not exist: {root}")
            package = state["package"]
            path = Path(package["path"])
            hashes = package["hashes"]
            if "quickXorHash" not in hashes:
                hashes["quickXorHash"] = await asyncio.to_thread(quick_xor_hash, path)
                save_state(state_path, state)
            relative = Path("feedbacks") / cid_slug(state["context"]["cid"]) / state["package_name"]
            destination = root / relative
            upload["path"] = str(destination)
            save_state(state_path, state)
            # Reuse an existing destination only when it contains this package.
            if not upload.get("copied") or not destination.is_file():
                destination.parent.mkdir(parents=True, exist_ok=True)
                await asyncio.to_thread(_copy_package, path, destination, hashes["sha256Hash"])
                upload["copied"] = True
            sync_deadline = datetime.now(UTC) + timedelta(seconds=state["sync_timeout_seconds"])
            upload["sync_deadline_at"] = sync_deadline.isoformat()
            save_state(state_path, state)
            root_item = await call(
                "getFileOrFolderMetadataInMyOnedrive", {"fileOrFolderId": "root"}, sync_deadline
            )
            cloud_url = root_item["webUrl"].rstrip("/") + "/" + quote(relative.as_posix())
            while True:
                try:
                    item = await call(
                        "getFileOrFolderMetadataByUrl",
                        {"fileOrFolderUrl": cloud_url},
                        sync_deadline,
                    )
                except DeliveryError as exc:
                    if not exc.missing:
                        raise
                    upload["message"] = str(exc)
                else:
                    cloud_hashes = item.get("file", {}).get("hashes", {})
                    upload.update(
                        item_id=item["id"],
                        drive_id=item["parentReference"]["driveId"],
                        url=item["webUrl"],
                        size=item.get("size"),
                        hashes=cloud_hashes,
                        etag=item.get("eTag"),
                        ctag=item.get("cTag"),
                    )
                    comparable = next(
                        (
                            key
                            for key in ("sha256Hash", "sha1Hash", "quickXorHash")
                            if hashes.get(key) and cloud_hashes.get(key)
                        ),
                        None,
                    )
                    same = False
                    if comparable:
                        local, remote = hashes[comparable], cloud_hashes[comparable]
                        same = (
                            local == remote
                            if comparable == "quickXorHash"
                            else local.lower() == remote.lower()
                        )
                    if item.get("size") == package["size"] and same:
                        upload.update(status="success", verified_hash=comparable, message=None)
                        save_state(state_path, state)
                        break
                    upload["message"] = (
                        "Cloud content cannot yet be verified"
                        if not comparable
                        else "Cloud content has not synchronized"
                    )
                save_state(state_path, state)
                remaining = (min(sync_deadline, total_deadline) - datetime.now(UTC)).total_seconds()
                if remaining <= 0:
                    raise TimeoutError(
                        "background total deadline"
                        if total_deadline <= sync_deadline
                        else "OneDrive sync deadline"
                    )
                await asyncio.sleep(min(_poll_seconds, remaining))

        state["phase"] = "permissions"
        if not state["recipients"]:
            state["permissions_error"] = "Recipients are not configured"
        for email in state["recipients"]:
            previous = permissions.get(email, {})
            if previous.get("status") == "success":
                continue
            try:
                if previous.get("status") == "unknown":
                    # The available MCP has no permissions-list tool. Metadata may
                    # include permissions; without that evidence keep the result unknown.
                    item = await call(
                        "getFileOrFolderMetadataInMyOnedrive",
                        {"fileOrFolderId": upload["item_id"]},
                        total_deadline,
                    )
                    result = _permission(item.get("permissions", []), email)
                    if result:
                        permissions[email] = {"status": "success", "permission": result}
                    else:
                        permissions[email] = {
                            "status": "unknown",
                            "error": "Existing permission cannot be confirmed through OneDrive metadata",
                        }
                    continue
                # Persist uncertainty before the write so interruption never causes
                # an unexamined repeat of a potentially completed grant.
                permissions[email] = {
                    "status": "unknown",
                    "error": "Permission request in progress",
                }
                save_state(state_path, state)
                response = await call(
                    "shareFileOrFolderInMyOnedrive",
                    {
                        "fileOrFolderId": upload["item_id"],
                        "recipientEmails": [email],
                        "roles": ["read"],
                        "sendInvitation": False,
                    },
                    total_deadline,
                )
                result = _permission(response, email)
                permissions[email] = (
                    {"status": "success", "permission": result}
                    if result
                    else {
                        "status": "unknown",
                        "error": "Returned permissions do not confirm recipient read access",
                    }
                )
            except DeliveryError as exc:
                permissions[email] = {"status": "failed", "error": str(exc)}
            except Exception as exc:
                permissions[email] = {"status": "unknown", "error": str(exc)}
            finally:
                save_state(state_path, state)
    except asyncio.CancelledError:
        if upload.get("status") == "running":
            upload.update(
                status="unknown",
                error="Delivery interrupted; OneDrive may continue syncing the copied file",
            )
        save_state(state_path, state)
        raise
    except Exception as exc:
        upload.update(status="failed", error=str(exc))
        save_state(state_path, state)
    finally:
        await caller.aclose()
