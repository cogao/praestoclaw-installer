"""Shared feedback redaction and conversation classification."""

from __future__ import annotations

import re
from typing import Any
from urllib.parse import parse_qs, urlsplit

from praestoclaw.security.leak import redact_credentials
from praestoclaw.security.praesto_tag_exp import praesto_tag_exp_is_active

_EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE)
_POSIX_HOME_RE = re.compile(r"(?P<prefix>/(?:Users|home)/)[^/\s]+")
_WINDOWS_HOME_RE = re.compile(r"(?P<prefix>[A-Z]:\\Users\\)[^\\\s]+", re.IGNORECASE)
_URL_RE = re.compile(r"https?://[^\s<>\"'\)\]]+", re.IGNORECASE)


def redact_attachment_urls(value: str) -> str:
    def replace(match: re.Match[str]) -> str:
        try:
            parsed = urlsplit(match.group())
            host = (parsed.hostname or "").lower()
            keys = {key.lower() for key in parse_qs(parsed.query, keep_blank_values=True)}
        except ValueError:
            return "[private attachment URL omitted]"
        if host.endswith(
            (".blob.core.windows.net", ".sharepoint.com", ".asm.skype.com")
        ) or keys.intersection({"sig", "signature", "tempauth", "token", "access_token", "jwt"}):
            return "[private attachment URL omitted; use screenshot IDs]"
        return match.group()

    return _URL_RE.sub(replace, value)


def feedback_is_shared(metadata: Any) -> bool:
    """Both borrowed groups and ordinary Teams groups need scoped diagnostics."""
    if not isinstance(metadata, dict):
        return False
    return praesto_tag_exp_is_active(metadata) or any(
        str(metadata.get(key) or "").strip().casefold() in {"groupchat", "channel"}
        for key in ("ctype", "teams_conversation_type")
    )


def sanitize_feedback_text(value: str) -> str:
    sanitized = redact_credentials(redact_attachment_urls(value))
    sanitized = _EMAIL_RE.sub("[email]", sanitized)
    sanitized = _POSIX_HOME_RE.sub(r"\g<prefix>~", sanitized)
    return _WINDOWS_HOME_RE.sub(r"\g<prefix>~", sanitized)
