"""Bounded references to authoritative requests consumed by approval waiters."""

from datetime import UTC, datetime, timedelta

from agent_gateway_protocol.gateway_protocol.v1.approval import ApprovalStatusResponse

from praestoclaw.security.approval import ApprovalManager, ApprovalRequest


class ApprovalStatusRecovery:
    def __init__(self) -> None:
        self._requests: dict[str, ApprovalRequest] = {}

    @staticmethod
    def _expired(request: ApprovalRequest) -> bool:
        now = datetime.now(UTC)
        if request.resolved_at is not None:
            return request.resolved_at < now - timedelta(seconds=60)
        return request.created_at < now - timedelta(minutes=15)

    def remember(self, manager: ApprovalManager | None, request_id: str) -> None:
        self._requests = {
            key: request for key, request in self._requests.items() if not self._expired(request)
        }
        request = manager.get_request(request_id) if manager else None
        cached = self._requests.get(request_id)
        if request is None and cached is not None and cached.status.value == "pending":
            self._requests.pop(request_id, None)
        if request is not None and not self._expired(request):
            if request_id not in self._requests and len(self._requests) >= 4096:
                self._requests.pop(next(iter(self._requests)))
            self._requests[request_id] = request

    def status(self, manager: ApprovalManager | None, request_id: str) -> dict:
        self.remember(manager, request_id)
        request = self._requests.get(request_id)
        if request is None:
            return ApprovalStatusResponse(request_id=request_id, status="unknown").model_dump()
        outcome = request.status.value
        if outcome == "approved" and request.action == "always":
            if request.allowlist_saved is None:
                outcome = "pending"
            else:
                outcome = "approved_always" if request.allowlist_saved else "approved_once"
        return ApprovalStatusResponse.model_validate(
            {
                "request_id": request_id,
                "status": outcome,
                "allowlist_saved": request.allowlist_saved,
                "resolver": request.resolver,
                "action": None if outcome in {"expired", "timeout"} else request.action or None,
            }
        ).model_dump()
