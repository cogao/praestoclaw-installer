"""Prepare report pages and their navigation as one KB draft. No network or Git writes."""

from __future__ import annotations

import argparse
import html
import json
import os
import posixpath
import subprocess
import tempfile
from html.parser import HTMLParser
from pathlib import Path, PurePosixPath
from string import Template
from urllib.parse import quote, unquote, urlsplit

SKILL_DIR = Path(__file__).resolve().parents[1]
REPORT_MARKER = "<!-- generated-by: feature-owner-auto-report -->"
DIRECTORY_MARKER = "<!-- generated-by: feature-owner-auto-report directory -->"
ENTRY = "feature-report-entry"
BACKLINKS = "feature-report-navigation"


class PublicationError(ValueError):
    pass


def git(repo: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(repo), *args]).decode("utf-8")


def repo_path(value: str) -> str:
    path = PurePosixPath(value)
    if (
        not value
        or not path.parts
        or path.is_absolute()
        or ".." in path.parts
        or "\\" in value
        or any(ord(c) < 32 for c in value)
    ):
        raise PublicationError("paths must be repository-relative and cannot escape the repository")
    return str(path)


def relative_url(target: str, source: str) -> str:
    return quote(posixpath.relpath(target, posixpath.dirname(source) or "."), safe="/")


class Page(HTMLParser):
    """Locate generated slots without reserializing the original page."""

    def __init__(self, content: str):
        super().__init__(convert_charrefs=True)
        self.content = content
        self.offsets = [0]
        for line in content.splitlines(keepends=True):
            self.offsets.append(self.offsets[-1] + len(line))
        self.mains: list[tuple[dict, int]] = []
        self.slots: dict[str, list[tuple[int, int]]] = {ENTRY: [], BACKLINKS: []}
        self.pending: list[tuple[str, str, int]] = []
        self.links: list[str] = []
        self.heading: list[str] = []
        self.in_heading = False
        self.feed(content)
        if self.pending:
            raise PublicationError("unclosed generated navigation slot")

    def position(self) -> int:
        line, column = self.getpos()
        return self.offsets[line - 1] + column

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        start = self.position()
        if tag == "a" and values.get("href"):
            self.links.append(values["href"])
        if tag == "main":
            self.mains.append((values, start + len(self.get_starttag_text())))
        for marker in self.slots:
            if f"data-{marker}" in values:
                self.pending.append((tag, marker, start))
        if tag == "h1" and not self.heading:
            self.in_heading = True

    def handle_endtag(self, tag):
        if tag == "h1":
            self.in_heading = False
        if self.pending and self.pending[-1][0] == tag:
            _, marker, start = self.pending.pop()
            end = self.content.find(">", self.position()) + 1
            self.slots[marker].append((start, end))

    def handle_data(self, data):
        if self.in_heading:
            self.heading.append(data)

    @property
    def title(self) -> str:
        value = " ".join("".join(self.heading).split())
        if not value:
            raise PublicationError("report page needs a readable h1 title")
        return value


def insert_slot(content: str, marker: str, snippet: str, *, main_id: str | None = None) -> str:
    page = Page(content)
    slots = page.slots[marker]
    if len(slots) > 1:
        raise PublicationError("duplicate generated navigation slots; review the existing page")
    mains = [item for item in page.mains if main_id is None or item[0].get("id") == main_id]
    if len(mains) != 1:
        raise PublicationError(
            "expected one main content anchor; keep the original homepage intact"
        )
    if slots:
        start, end = slots[0]
        return content[:start] + snippet + content[end:]
    at = mains[0][1]
    newline = "\r\n" if "\r\n" in content else "\n"
    return content[:at] + newline + snippet + content[at:]


def report_kind(path: str, root: str) -> str | None:
    parts = PurePosixPath(path).parts
    prefix = PurePosixPath(root).parts
    rest = parts[len(prefix) :]
    if parts[: len(prefix)] != prefix or len(rest) != 3 or rest[2] != "index.html":
        return None
    return {"owners": "owner", "projects": "project"}.get(rest[0])


def directory_page(entries: dict[str, tuple[str, str]], path: str, homepage: str) -> str:
    sections = []
    for kind, title in [("owner", "按人查看"), ("project", "按项目查看")]:
        rows = [
            (name, target) for target, (page_kind, name) in entries.items() if page_kind == kind
        ]
        links = "".join(
            f'<li><a href="{relative_url(target, path)}"><span>{html.escape(name)}</span><span aria-hidden="true">↗</span></a></li>'
            for name, target in sorted(rows, key=lambda row: (row[0].casefold(), row[1]))
        )
        body = (
            f'<ul class="directory-list">{links}</ul>'
            if rows
            else '<p class="unknown">暂无报告</p>'
        )
        sections.append(f"<section><h2>{title}</h2>{body}</section>")
    return Template((SKILL_DIR / "assets/directory.html").read_text(encoding="utf-8")).substitute(
        marker=DIRECTORY_MARKER,
        styles=(SKILL_DIR / "assets/report.css").read_text(encoding="utf-8"),
        home_url=relative_url(homepage, path),
        sections="\n".join(sections),
    )


def prepare_publication(
    repo: Path,
    revision: str,
    root: str,
    homepage: str,
    reports: dict[str, str],
    task_id: str,
    *,
    home_anchor: str = "main",
) -> dict:
    root, homepage = repo_path(root), repo_path(homepage)
    catalog = f"{root}/reports/index.html"
    if not task_id or not reports or catalog == homepage or report_kind(homepage, root):
        raise PublicationError("a draft task, report pages and distinct homepage are required")
    head = git(repo, "rev-parse", "--verify", "--end-of-options", revision + "^{commit}").strip()
    paths = {p for p in git(repo, "ls-tree", "-r", "--name-only", "-z", head).split("\0") if p}
    if homepage not in paths:
        raise PublicationError("the configured homepage does not exist at the draft base revision")
    original = {homepage: git(repo, "show", f"{head}:{homepage}")}
    if catalog in paths:
        original[catalog] = git(repo, "show", f"{head}:{catalog}")
        if not original[catalog].startswith(DIRECTORY_MARKER):
            raise PublicationError("refusing to replace a directory not managed by this skill")
    entries = {}
    for path in sorted(paths):
        kind = report_kind(path, root)
        if kind:
            original[path] = git(repo, "show", f"{head}:{path}")
            entries[path] = (kind, Page(original[path]).title)
    proposed = {}
    for raw_path, content in reports.items():
        path = repo_path(raw_path)
        kind = report_kind(path, root)
        if not kind or path in proposed:
            raise PublicationError(
                "report targets must be distinct canonical owner/project index pages"
            )
        page = Page(content)
        if (
            not content.startswith(REPORT_MARKER)
            or len(page.mains) != 1
            or page.mains[0][0].get("data-report-type") != kind
        ):
            raise PublicationError("report HTML must come from the matching project/owner renderer")
        if path in original and not original[path].startswith(REPORT_MARKER):
            raise PublicationError("refusing to replace a report not generated by this skill")
        entries[path] = (kind, page.title)
        snippet = (
            f'<nav class="report-navigation" data-{BACKLINKS} aria-label="报告导航">'
            f'<a href="{relative_url(homepage, path)}">首页</a>'
            f'<a href="{relative_url(catalog, path)}">报告目录</a></nav>'
        )
        proposed[path] = insert_slot(content, BACKLINKS, snippet)
    proposed[catalog] = directory_page(entries, catalog, homepage)
    # A content shortcut avoids changing the existing site's position-based
    # mobile menu rules (nth-child/last-child), or any existing navigation items.
    snippet = (
        f'<p class="shell" data-{ENTRY}>'
        f'<a href="{relative_url(catalog, homepage)}">开发进度报告 →</a></p>'
    )
    home = Page(original[homepage])
    without_entry = (
        insert_slot(original[homepage], ENTRY, "", main_id=home_anchor)
        if home.slots[ENTRY]
        else original[homepage]
    )
    linked = False
    for href in Page(without_entry).links:
        try:
            url = urlsplit(href)
        except ValueError:
            continue
        if url.scheme or url.netloc or not url.path:
            continue
        target = unquote(url.path)
        if target.endswith("/"):
            target += "index.html"
        resolved = posixpath.normpath(posixpath.join(posixpath.dirname(homepage), target))
        linked = linked or resolved == catalog
    proposed[homepage] = (
        without_entry
        if linked
        else insert_slot(original[homepage], ENTRY, snippet, main_id=home_anchor)
    )
    changes = []
    for path, content in proposed.items():
        if content == original.get(path):
            continue
        if path == catalog:
            label = "更新报告目录链接"
            owners = sum(kind == "owner" for kind, _ in entries.values())
            details = [
                f"按人列出 {owners} 份报告，按项目列出 {len(entries) - owners} 份报告。",
                "仅链接基准版本已有或本次提交的页面，保留其他报告入口。",
            ]
        elif path == homepage:
            label = "更新报告目录入口"
            details = ["补齐或复用报告目录入口，保留其他导航、正文和布局规则。"]
        else:
            label = f"更新 {entries[path][1]} 的开发进度报告"
            details = ["包含本次生成的报告正文、来源，以及返回首页和报告目录的链接。"]
        changes.append(
            dict(
                path=path,
                operation="update" if path in paths else "create",
                content=content,
                summary=label,
                details=details,
            )
        )
    return dict(task_id=task_id, base_revision=head, changes=changes)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--repo", type=Path, required=True, help="current KB draft's returned worktree"
    )
    parser.add_argument("--revision", required=True, help="that draft's base_head")
    parser.add_argument(
        "--root", required=True, help="project area, e.g. 10x-productivity/inner-loop"
    )
    parser.add_argument(
        "--homepage", required=True, help="existing homepage, e.g. 10x-productivity/index.html"
    )
    parser.add_argument("--home-anchor", default="main")
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--report", action="append", required=True, metavar="TARGET=LOCAL_HTML")
    parser.add_argument(
        "--output", type=Path, required=True, help="JSON proposal file outside the KB worktree"
    )
    args = parser.parse_args()
    temporary = None
    try:
        reports, inputs = {}, set()
        for argument in args.report:
            target, separator, source = argument.partition("=")
            if not separator or target in reports:
                raise PublicationError("each --report needs a distinct TARGET=LOCAL_HTML")
            file = Path(source).expanduser().resolve()
            reports[target] = file.read_text(encoding="utf-8")
            inputs.add(file)
        output = args.output.resolve()
        if (
            output.suffix.lower() != ".json"
            or output.is_relative_to(args.repo.resolve())
            or output in inputs
        ):
            raise PublicationError(
                "write proposal JSON outside the KB worktree and preserve report inputs"
            )
        result = prepare_publication(
            args.repo,
            args.revision,
            args.root,
            args.homepage,
            reports,
            args.task_id,
            home_anchor=args.home_anchor,
        )
        output.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=output.parent, delete=False
        ) as f:
            temporary = f.name
            json.dump(result, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(temporary, output)
        print(
            json.dumps(
                {"proposal_file": str(output), "paths": [c["path"] for c in result["changes"]]},
                ensure_ascii=False,
            )
        )
    except (OSError, ValueError, subprocess.CalledProcessError) as exc:
        parser.exit(1, f"Publication preparation failed: {exc}\n")
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)


if __name__ == "__main__":
    main()
