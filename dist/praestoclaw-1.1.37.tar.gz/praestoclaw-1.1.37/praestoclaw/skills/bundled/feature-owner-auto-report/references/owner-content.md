# Owner report content

Use `render-owner` for one person's development progress across registered projects.
This is a derived view; it never creates an owner project or rewrites source facts.
The project-mode `render` command and schema remain unchanged.

## Source bundle

```json
{
  "registry": {"head": "full-sha", "path": "inner-loop/projects.yaml", "from_line": 1,
    "total_lines": 1, "returned_lines": 1, "content": "complete registry YAML"},
  "projects": ["complete kb_inspect(read) receipt for each project registered to this owner"]
}
```

The strings above illustrate placeholders, not valid receipts. Each real receipt
retains its full content and line counts. The registry has a `projects` list whose
entries contain `id`, `owner`, `path`, and usually `number`. Paths are relative to
the registry directory. All project receipts and the registry must share a full
Git revision. Supply every registered project for this owner, including closed
ones; the renderer derives exclusions from the progress records, not from a
model-written list. Do not include unrelated owners' project receipts.

## Model-selected content

```json
{
  "owner": "Yue Liu",
  "source_revision": "same-full-sha-as-all-receipts",
  "include_closed": false,
  "headline": {"text": "当前主要推进的结果与关键限制", "sources": [
    {"project_id": "alpha", "lines": [[13, 14]]},
    {"project_id": "beta", "lines": [[13, 14]]}
  ]},
  "projects": [
    {"project_id": "alpha", "display_title": "项目的简短中文名称",
     "summary": {"text": "项目结果和重要限制", "lines": [[13, 14]]}},
    {"project_id": "beta", "summary": {"text": "另一个项目的结果", "lines": [[13, 14]]},
     "next_step": {"text": "该项目已记录的下一步", "lines": [[15, 15]]}}
  ],
  "checkpoint": {"text": "跨项目或近期的检查点，保留提议及日期边界", "sources": [
    {"project_id": "beta", "lines": [[15, 15]]}
  ]}
}
```

`owner`, `source_revision`, `headline` and `projects` are required. `include_closed`
is a boolean, default false. `display_title`, per-project `next_step` and the
page-level `checkpoint` are optional. Project entries must cover exactly the
selected set, once each; choose their display order without dropping a project.
The canonical owner matches case-insensitively with whitespace normalized, not
by fuzzy name similarity. Resolve aliases against the KB before making this input.

Per-project claims use `lines` and can only cite that project's source. Headline
and checkpoint claims use `sources`, each naming a selected project and inclusive
line ranges. The renderer keeps citation IDs unique across projects and links to
the exact revision. Unselected/closed projects cannot support a current-work claim.
Each project's lifecycle, acceptance and impact remain separate in the source area.

Keep the whole brief concise. Do not paste several complete project reports into
one page. Omit unrecorded asks and ETAs; describe proposals as proposals. A registry
or progress conflict must be resolved through the existing KB flow, not concealed
by the owner summary. A valid citation range does not prove the prose is true.

Publication uses the same KB proposal flow as a project page. The KB's existing
owner-report path takes precedence. Where none exists, a path such as
`owners/yue-liu/index.html` under the inner-loop root is a **new proposed convention**
shown in the draft for human review, not an existing KB requirement. Keep source
JSON and temporary content inputs local; stage the reviewed HTML, not a new owner
status/registry record. Do not silently replace the team overview or project pages.
