# Refresh and publication

Use the same report skill for manual and scheduled generation. The model already
runs inside PraestoClaw; `report.py` validates and renders its selected content.
No report-config YAML parser, CI model client, Git hook or new deployment service
is needed for this first version. Skill metadata and KB frontmatter remain as-is.

## Manual entry

Resolve one feature/project, generate its report and prepare a KB draft:

> 给项目 08 刷新开发进度页面，面向我、manager 和 skip manager。

A named owner request creates one owner summary across their non-closed projects:

> 使用 feature-owner-auto-report，生成 Yue Liu 的个人开发进度报告，并准备 KB 草稿供我确认。

Use separate project pages only when requested. The owner summary is a derived
view, not an owner project record or a team PMO report.

In a personal Teams chat with the required KB capability, an ordinary manual
report request continues through the proposal flow below. A local HTML file is
an intermediate artifact, not the completed delivery. The agent may run the
manual request in a background worker without making it a read-only cron.
For several named owners/projects, render the requested pages and stage them
together with their navigation. Do not expand the scope to other reports.

Explicit “preview only”, “local only” or “no push” requests stop at the local
report directory; “no push” excludes the KB review-branch workflow. An explicit
“prepare a KB draft, do not publish yet” request allows a review branch and stops
after staging; it does not authorize the published KB branch. A prior completed
preview does not make later independent requests preview-only.

Temporary generation files default to
`<workspace>/reports/<project-id>/<run-id>/index.html` (owner mode:
`<workspace>/reports/owners/<owner-key>/<run-id>/index.html`), retaining the source and
content inputs beside it. For a local-only result, return the renderer's absolute
file path as plain code, state that it is on the PraestoClaw host and has not
entered the KB, and include a short brief. If a manual draft falls back to local
files because a capability failed, identify the actual failure and retain the
inputs; do not silently call it complete. Do not create a `sandbox:`, `file:` or localhost “open preview” link
for Teams. Do not launch a browser or start a preview server for ordinary generation.
Opening the file / visual QA is a separately requested action.

## Independent cron entry

Only configure a live job when the user requests a schedule. Use the existing
PraestoClaw `cron` tool in **prompt mode**: it runs the configured model, which
reads this skill, summarizes the fresh source, and invokes the HTML renderer.
Message mode sends static text; direct tool mode does not summarize new progress.
No scheduler/runtime change is required for this entry.

Use a separate report job with the selected project IDs and an explicit
`feature-owner-auto-report` invocation. For example, its saved prompt could be:

> 使用 feature-owner-auto-report，读取当前绑定 KB 中项目 08 的最新 progress，
> 生成供 dev、manager 和 skip manager 阅读的简短中文 HTML 预览。保留重要限制和
> 来源引用，在本次任务结果中返回简短回执及实际文件位置；如果缺少权限或工具，
> 说明原因并保留旧页面。本次只生成预览。

The prompt example does not choose a schedule. Establish the requested cadence,
projects, running instance and delivery destination before registering a job.
Use `cron list` and `info` to identify existing report jobs before an authorized
replacement; preserve their schedule, delivery and scope unless the user changes
them. Do not edit personal PMO or `kb-progress-sync-daily` jobs as a side effect.
Daily/weekly completion offers, shared team batching and changed-only refresh
are deferred; this version regenerates the selected projects on each invocation.

For jobs using the current personal Teams KB binding, explicitly set
`use_current_kb_scope=true`. Naming the report skill does **not** auto-capture
that scope. The existing runtime captures it only from trusted personal Teams
context as a **read-only** KB capability. Do not borrow another chat's identity,
bypass a refusal or assume a group/web job inherited that scope.
Preview rendering also needs the package and ordinary file/renderer capabilities
in the scheduled runtime; a successfully registered cron does not prove these work.

Use scheduler-managed delivery for scheduled results. Do not call notify again
to duplicate an automatically delivered receipt. Return the project, source
revision and actual preview location, or a short actionable failure. A local path
is not remotely accessible in Teams; identify it as local until an authorized
delivery/publication flow provides a verified remote link. Show local paths as
plain code, not clickable Markdown links, and do not invent a `sandbox:` URL. The job finishes after
its receipt and does not wait for an interactive answer or promise that a bare
“yes” resumes a pending publication.

Before describing scheduled refresh as working, run the authorized job once and
verify fresh source, actual generated HTML, failure behavior and delivery in that
runtime. Setup alone is not an execution receipt. This package adds instructions
for that integration; it does not install a job or grant unattended KB writes.

## Prepare a KB draft

Use this path by default for an ordinary manual report request in personal Teams,
as well as an explicit request to save to the KB, prepare a draft or publish.
Tell the user that this run prepares a KB draft for review; publication waits for
their confirmation. Explicit preview/local-only requests and scheduled runs stay
local. “No push” cannot use `kb_draft(stage)` as a local-only workaround: stage may
push a review branch and create a GitHub Draft PR. Preserve the selected intent
across retries and background handoff.

In personal Teams chat, reuse `pmo-grill`'s direct-proposal flow. No report-specific
card, Git wrapper or new publishing service is needed:

1. Resolve and render the actual report first. Read the current target's KB rules,
   presentation contract and existing page. A project page belongs at
   `projects/<project-id>/index.html` under the discovered root. For an owner page,
   use the KB's established owner path. If none exists, include a proposed path
   such as `owners/yue-liu/index.html` in the draft summary for review; this is a
   new convention, not permission to change the team overview or project registry.
2. Start with `kb_draft(action="start", source="direct", user_request="<actual request and source evidence>")`.
   Preserve its `task_id`, repo, base head and worktree across subsequent actions.
   Resume that exact task for later replies; `list`/`show` may recover it. Do not
   restart unrelated drafts or copy files directly into the managed KB clone.
   The direct source is personal-chat only; a shared-group report follows that
   group's existing capture/curation flow instead of borrowing personal scope.
3. Check the source against the draft's current KB snapshot. Re-read changed
   registry/progress inputs and regenerate when needed. A report must not conceal
   a material source conflict. No new claim is written to progress merely to make
   the HTML appear current.
4. Prepare the report **and navigation** using the script below. It reads only
   the returned task worktree's named Git base revision, discovers existing
   canonical owner/project report pages, and adds this proposal's reports. It
   does not infer pages from registration alone, fetch, edit the KB worktree or
   publish. Do not use it to get around a refused KB read or inspect another
   task's managed clone. Source fact reads still use the current KB tools.
   This applies equally to one owner, several owners or all explicitly requested
   owners. Do not handwrite a separate directory for a larger collection. Preserve
   the helper's explicit `index.html` relative links; neither directory-only hrefs
   nor GitHub `blob` links are substitutes for report navigation. Before staging,
   inspect the proposal's report/directory/homepage paths and check that each new
   report link names its actual `.html` target. An existing custom homepage link
   that the helper reuses may remain unchanged.
5. Stage the resulting proposal file with `kb_draft(action="stage", task_id=...,
   changes_file="<workspace>/reports/.../publication.json", message=..., overview=...)`.
   `changes_file` is a personal-Teams, workspace-only input; its task ID and base
   revision must match this draft. The tool reads complete file contents and
   applies its usual path/content/approval checks. Do not copy the large homepage
   through a model-generated tool argument or call KB tools from a shell to bypass
   this input boundary. Use `changes` and `changes_file` as alternatives, not together.
   Report pages, directory links and the homepage shortcut share this one proposal.
   Temporary receipts/content/proposal JSON remain local. If the file input is
   unavailable, preserve the prepared files and report the capability gap.
6. Present the returned proposal summary, all changed paths and material limits
   as an ordinary Teams message. Include a real `review_url` / proposal review
   URL as a Draft PR link when available. A review mirror is best-effort and is
   not a rendered HTML preview. If it fails, retain the local KB proposal and
   state the actual outcome; do not fabricate a PR or repeat an identical stage.
   The managed KB draft worktree may itself live under `~/.praestoclaw`; the
   renderer's workspace path and the repository-relative target are different.
   Report the task/staging receipt and actual review URL, not a local file as proof
   of KB delivery. The user's separate KB checkout is unchanged until they pull
   after publication.
7. If the user explicitly wants only a draft for now, return the staged-draft
   receipt and stop. Otherwise ask one concrete question: “是否确认将这份报告发布到 KB？”
   Then end the turn. “Prepare draft” itself does not authorize publication. Keep
   the proposal identity so a later explicit publish request, or an affirmative
   reply to that publication question, applies to these exact contents.

## Report directory and homepage entry

For the current Societas layout, use:

```text
<python> <skill-dir>/scripts/publication.py --repo <returned-task-worktree> --revision <task-base-head> --task-id <task-id> --root 10x-productivity/inner-loop --homepage 10x-productivity/index.html --report "10x-productivity/inner-loop/owners/yue-liu/index.html=<absolute-local-report.html>" --output <workspace>/reports/<run-id>/publication.json
```

Repeat `--report TARGET=LOCAL_HTML` for multiple pages. Root/homepage paths come
from the target KB's current contract; these defaults do not apply to every KB.
The existing homepage's main content anchor is `id="main"`; `--home-anchor` may
name a different verified main ID. If the anchor is missing or ambiguous, keep
its original contents and explain that the integration needs review.

The helper prepares:

- The requested report pages with relative links back to the homepage and directory.
- `<root>/reports/index.html`, grouped by owner and project. It uses committed
  canonical `owners/<id>/index.html` / `projects/<id>/index.html` files plus the
  reports in this proposal. Existing links are retained, deleted pages disappear,
  and no links are invented for ungenerated projects. This is navigation only;
  no lifecycle, risk, acceptance or team overview is calculated.
- One managed “开发进度报告” shortcut at the start of the homepage's main content.
  An existing relative link to the same directory is reused without changing it.
  It preserves all other homepage text and avoids its position-based mobile menu
  rules. Repeated preparation does not duplicate the entry. A manual directory
  or ambiguous generated slots are refused rather than overwritten.

The proposal JSON contains the exact `task_id`, `base_revision` and complete
`changes` array. Only changed files are included. If the array is empty, report
that these outputs are already current instead of staging an empty proposal;
finish/cancel only an empty draft created by this invocation, leaving unrelated
drafts alone. When revising an existing proposal, supply every report that it is
still meant to contain, because staging replaces that proposal's complete change
set. Re-prepare against a new draft base when appropriate; never edit the JSON
binding just to force it through another task.

For a navigation-only correction, recover all reports from the existing proposal
and run the helper again with that complete set. Do not stage only the directory:
staging replaces the proposal and would remove its other files. Do not directly
push a different review-branch commit around the KB tools, since their stored
proposal and approval fingerprint must still describe what the user reviews.

Do not start a new hosted service or GitHub Action for this directory. During
review these are draft links; only after the same proposal reaches the KB target
branch and its existing Pages build completes are they deployed links. Homepage,
directory and report-inventory changes by another publisher are relevant inputs:
follow the KB tool's conflict/rebase/restart guidance and review the refreshed
proposal; do not force an old directory over a newer publisher's entries. Use the
verified Pages base URL plus these repository paths when returning an actual
publication receipt. A local preview does not update the live homepage.

## Confirm and publish

On the user's next reply in the same personal Teams conversation:

1. Load the identified draft and distinguish approval, requested edits and refusal.
   If the user previously requested a draft only and no publication question was
   asked, a generic acknowledgement is not a publish request.
   A tool approval, a plan completion card, silence or the model's own text is not
   proposal approval. Never treat “生成报告” or “生成草稿” as the user's confirmation.
2. If the proposal changed since it was shown, present the updated material for
   review. If relevant source facts changed, regenerate/restage and review that
   updated proposal. Unrelated KB changes alone do not invalidate its factual
   contents; preserve the original source citations when those inputs still match.
3. Record the actual human reply with `kb_draft(action="approve", task_id=...,
   stage="draft", decision="approved", quote="<user's words>")`. For edits or
   refusal, use the corresponding decision and do not publish; after editing,
   stage the new contents and present them again.
4. Once that exact proposal is approved, call `kb_publish(task_id=...)` immediately
   in the same reply turn, without a second “confirm publishing” question. The KB
   tool performs commit/push and checks its proposal fingerprint. Keep refusal,
   conflicts and unknown outcomes distinct; follow its reconciliation receipt
   instead of retrying an unknown publication as a new write.
5. Verify the actual publish receipt and return the KB change link. An already
   authorized Pages site may deploy the merged HTML; only return a rendered page
   link after checking its publication/URL. A GitHub blob or Draft PR URL is not
   a deployed report page.

This uses KB curation semantics. Do not route it through `kb-progress-sync`:
that skill's `publish #123` makes a different kind of PR Ready for review and is
not this KB publish confirmation. Do not add a second generic approval card over
the existing proposal review. A dedicated publish button would require its own
binding to the reviewed proposal and trusted user action; it is deferred.

Scheduled KB access remains read-only. A cron can prepare the report and return
a receipt; creating the KB draft and confirming publication happen interactively
with the appropriate current-chat capability. No live job or unattended write
capability is installed by this skill. On failure retain the previous generated
page and source date; no extra page-status ledger or fact YAML is introduced.
