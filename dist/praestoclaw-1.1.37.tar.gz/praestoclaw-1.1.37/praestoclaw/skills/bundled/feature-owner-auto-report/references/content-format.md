# Report content

The owner reports one project upward to their manager and skip manager. Keep the
facts traceable while letting the project's situation determine the presentation.
Write about what the feature does and what remains, not the internal workflow
vocabulary. For example, prefer “功能已完成开发与验证，PR 可评审” over
“FULL_FEATURE / acceptance PASS / READY_TO_REVIEW”. Explain repair as “返工”
and an evidence gap in ordinary Chinese. Put run IDs, F1–F8 codes and detailed
execution phases in folded evidence. Do not repeat the headline in a delivery
bullet or turn an unmeasured benefit into the dev's next assigned task.

This is a schema example, not mandatory section names or a factual report:

```json
{
  "project_id": "the-source-project-id",
  "source_revision": "the-full-source-commit",
  "display_title": "面向读者的简短项目名称",
  "headline": {"text": "一句话说明当前成果与关键限制", "lines": [[81, 85]]},
  "purpose": {"text": "一句话说明项目要解决什么问题", "lines": [[23, 26]]},
  "as_of": {"text": "验证截至 2026-09-14", "lines": [[77, 77]]},
  "sections": [
    {
      "title": "本轮验证",
      "kind": "table",
      "headers": ["场景", "结果"],
      "rows": [
        [
          {"text": "截图功能", "lines": [[94, 94]]},
          {"text": "修改前后验证通过", "lines": [[94, 94]]}
        ]
      ]
    },
    {
      "title": "效果尚未证实",
      "kind": "callout",
      "items": [{"text": "样本少且缺人工投入记录，尚不能证明提效", "lines": [[104, 105]]}]
    },
    {
      "title": "下一步",
      "kind": "bullets",
      "items": [{"text": "增加样本并记录人工投入", "lines": [[104, 105]]}]
    }
  ],
  "evidence": [{"label": "验证证据", "target": "artifacts/evidence/README.md"}]
}
```

`headline`, `purpose`, `sections` and `evidence` are required. Sections and evidence
can be empty when genuinely unnecessary or unavailable. `display_title` is an
optional faithful Chinese shorthand for the source title, never a new project
definition. The original title remains in source details. `as_of` is an optional
cited statement of the business/evidence window; do not derive it from `updated`.

Each claim is nonempty plain `text` plus one or more inclusive, 1-based source
`lines`. Every table cell is also a claim. A title/header labels the content;
factual assertions belong in cited claims. HTML/Markdown formatting is not needed.

The **order and number of `sections` are author-selected**. Each has a short title
and one of these representations:

| `kind` | Content | Use when |
|---|---|---|
| `bullets` | `items`: list of claims | A few distinct outcomes or next actions |
| `table` | `headers`: 2–4 strings; `rows`: equal-width arrays of claims | Cases, results or alternatives need comparison |
| `callout` | `items`: list of claims | A material limit, blocker or recorded decision needs attention |
| `timeline` | `items`: list of dated claims | Sequence is necessary to understand the current stage |

There are no mandatory outcomes/limitations/next-steps/milestones panels in this
format. Do not generate empty panels. Preserve decision-relevant unknowns in the
headline or an appropriate claim instead. A tiny project does not need a table;
a validation report does not need its entire historical roadmap.

For older saved generation inputs, the renderer still accepts the v1
`outcomes`, `limitations`, `next_steps`, and `milestones` lists. Use `sections`
for new reports. This compatibility path is not the new editorial default.

Keep main reading around 200–350 Chinese characters plus English words. Titles and
table headers count; folded source excerpts do not. The renderer reports this
approximation and warns over the target without truncating facts or refusing to
preserve an important risk. The count is a writing aid, not a measured reading time.

Evidence targets must already be Markdown links or images in the source, excluding
examples inside code spans/blocks. Use the actual destination URL, without Markdown
syntax escapes; the parser handles parentheses, reference links and URL normalization.
Preserve the target
exactly; relative links resolve at the source revision and absolute HTTPS links
retain their target. Evidence links, exact excerpts, and project acceptance/impact
metadata are available in the folded reference area, keeping the main brief short.
Valid citations do not establish semantic support; review the actual cited text.

Source receipts use the complete `kb_inspect(read)` shape:

```json
{
  "head": "full-commit-sha",
  "path": "10x-productivity/inner-loop/projects/project-id/progress.md",
  "from_line": 1,
  "total_lines": 100,
  "returned_lines": 100,
  "content": "The complete source document, including YAML frontmatter"
}
```

Save the actual receipt without reconstructing missing text. `capture` produces
this shape from a named local Git revision without fetching. The renderer's
repository URL is the verified credential-free HTTPS GitHub/GitHub Enterprise
repository URL. Temporary receipt/content files are generation inputs, not KB
records or a parallel status system.
