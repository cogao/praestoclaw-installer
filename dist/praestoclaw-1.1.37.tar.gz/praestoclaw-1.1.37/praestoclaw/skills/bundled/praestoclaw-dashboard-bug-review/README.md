# 可迁移的 Dashboard Bug Review

此目录将 Dashboard → 证据判断 → GitHub 去重/建票 → Teams 合并通知作为一个独立 Skill 版本化。调度属于外部调用者：安装不运行分析、不创建 cron、不建 Issue、不发送消息。需要 PraestoClaw 或兼容 Agent Skills 的宿主及已授权的工具。

## 安装与配置

- PraestoClaw 随发行包从 bundled 目录发现本 Skill。也可以将本目录完整复制到目标机器获准的 workspace `skills/praestoclaw-dashboard-bug-review/`；相对引用以该目录为基准，不依赖固定用户路径。
- 已有同名 user/workspace Skill 会覆盖 bundled 版本。先比较内容并保留备份，经用户同意再更新覆盖版本；仅升级发行包不保证实际加载的是本版本。
- 用 `pc skills list`、`pc skills show praestoclaw-dashboard-bug-review` 确認来源与内容；宿主未重载时按宿主支持的方式重新加载或重启。
- 复制 [config.example.json](config.example.json) 到目标机器的获准配置位置，并在调用时给出该路径。示例默认只读；里面的 Dashboard 是团队已选择的入口，不意味着每位安装者都有权限。
- execute 前通过 Teams 查询解析并验证精确目标群，填写非秘密稳定 chat_id。示例故意不携带个人会话目的地；不以名字模糊匹配自动选择。不要将 token、OAuth 缓存、原始样本或个人状态提交进仓库。

## 工具前置条件

1. BizTable MCP：可读取指定 Dashboard、Saved Query 定义并执行有界只读查询。工具发现成功不是数据权限证明，必须实际读取验证。
2. GitHub：可查询 gim-home/PraestoClaw 的 open/closed Issues 及正文。默认写适配器为 PraestoClaw `feedback_submit`，先加载当前 feedback skill；不能用 CLI 绕过其约束。其他宿主若没有此能力只能 analyze，通用写适配器留作后续独立实现。
3. Teams MCP：execute 时需要只读核实目标群/已有批次消息和向该群发送的权限。默认不 @ 人。

授权由各机器/运行身份通过正常登录流程获得，不复制旧机器的密钥。工具、登录及审批规则以当前宿主为准；Skill 不降低安全策略。共享会话不扫描本机日志。

## 手动调用

```text
使用 praestoclaw-dashboard-bug-review。
读取我提供的配置文件，以 analyze 模式分析 2026-09-13（Asia/Shanghai）完整日，
与此前七个完整日比较。只输出候选、证据和已有 Issue 匹配，不做外部写入。
```

确认分析有效后可显式要求 execute（仍遵守宿主审批）。调度器只需要提交同样的调用，日期可指定“昨天”，不在 Skill 内保存调度。此改动不修改现有每日 08:00 cron。

## 完整 execute 入口

```text
使用 praestoclaw-dashboard-bug-review，读取 <获准配置文件路径>。
以 execute 模式分析昨天（Asia/Shanghai）完整一天，与此前七天比较。
在宿主授权允许范围内逐工具取证、检索 open/closed Issues 去重，
为证据达标的新问题实际建票，并把所有候选的合并摘要发送到配置中已验证的目标群。
同一问题不重复建票；最后分别报告 Issue 和 Teams 的真实回执与失败项。
```

建票、核对回执、发群及中断恢复都由 Skill 自己编排，详见 [references/execution.md](references/execution.md)。不需要 cron 再调用一个建票 Skill 或发送脚本。配置示例保持 analyze，必须在调用中明确授权 execute；当前宿主的审批与 feedback 调查要求照常生效。

当前实现是可执行的 agent 操作协议，而非独立 Python worker：helper 不会自行调用网络。跨会话补充旧 Issue 受 feedback_submit 限制，当前只能去重并在群里报告变化，不能承诺已经更新旧票。其他 agent 缺少该工具时只能只读运行，不能宣称已具备通用写适配器。

## 确定性助手与离线测试

Python 3.11+；运行无网络及 API 调用。独立 helper/测试依赖在 requirements.txt 声明（tzdata 提供 IANA 数据，尤其用于 Windows）。先在获准 Python 环境运行 `python -m pip install -r requirements.txt`；离线环境先从获准包源预置该依赖。此目录测试不在包级 pytest testpaths=[tests] 默认收集范围；praestoclaw-ci.yml 已增加显式步骤，在三个平台安装 requirements.txt 并运行此套件。本地按下列命令单独执行。依赖安装完成后从本 Skill 目录运行：

```text
python scripts/review_contract.py windows --day 2026-09-13 --timezone Asia/Shanghai
python scripts/review_contract.py fingerprint --component "MCP Mail" --operation SearchMessagesQueryParameters --failure-mode deadline_120s --trigger standard_search
python -m unittest discover -s tests -v
```

helper 只计算 UTC 时间边界和语义指纹，不执行整个流程、不验证模型判断、不保证并发去重。配置由 agent 解释，不是一个已有的运行引擎。

## 去重与迁移验收

GitHub Issues 是问题事实源，Teams 消息历史是通知回执的可查来源。本地缓存丢失不能导致重建。历史 #957–#961 可用于已知问题的只读检索演练；不得把历史内容当作实时故障或使用固定 allowlist 替代完整搜索。

在目标机器以只读模式跑一个旧窗口，验证：
- 实际能读取 Dashboard 数据而不只是列工具；时间、基线、分母正确。
- 历史无 marker 的 Issue 也能语义匹配；日期/版本普通变化不重复建票。
- Mail/Calendar 等不同工具候选分别分析；遥测缺口不替代功能故障。
- 120 秒不是 429/死锁证据；单次取消/拦截不当作 Bug。
- 截断/搜索权限错误时不建票；缺发送权限时不误报成功。
- 模拟“建票成功、发群失败”：重跑匹配已有票，只补通知；未知送达先查批次消息。

以上是人工/agent 行为验收清单；离线单元测试只覆盖时间、指纹、示例和相对文档链接，不能替代这些集成验收。禁止为了测试向真实仓库/群制造故障或重复写入。

生产只允许单个写执行节点。迁移需先停旧调度，再启新调度；并发锁/原子认领不在第一版。回滚只撤销此 Skill 文件变更或恢复旧副本，不回滚已创建的真实 Issues，不更改 Dashboard/cron。
