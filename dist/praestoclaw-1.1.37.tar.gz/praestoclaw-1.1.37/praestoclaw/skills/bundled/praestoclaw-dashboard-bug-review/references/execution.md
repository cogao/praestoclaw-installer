# Execute：建票与群通知的工具协议

这是 Skill 内部的实际执行步骤，不是要求 cron 实现的回调，也不是仅生成草稿。所有调用以当前工具 schema 为准；示例中的占位值不能直接提交。仅使用获准工具，不增加权限，不携带凭据到配置或回执。

## 1. 执行前建立上下文

- 解析 mode、config_id、时区、绝对分析/基线窗口、app/dashboard ID、固定仓库和目标群。baseline_days 必须为非布尔正整数，实际查询和摘要均使用该配置生成的紧邻分析窗口之前的本地日历天基线，不硬编码七天。single_writer_required 必须严格为 true 并确认只有一个执行节点；false、缺失或无法确认单写时，execute 在任何写入前 blocked。配置不提供原子锁。
- analyze 不执行以下写操作。execute 必须有当前用户或已获准自动化调用的明确授权；策略要求审批时走宿主审批，拒绝/取消立即停止写入。
- 验证 Dashboard 实际只读访问、GitHub open/closed 搜索覆盖、Teams 目标查询及发送工具可用。工具发现不等于数据或写权限通过。
- 先发现当前 Teams 工具 schema：工具名和参数随部署变化，不能把仓库 mock 当成运行时契约。本文 GetChat 示例适用于实际暴露 `chatId` 的部署；若当前 schema 暴露 `chat_id`，使用 `MCP_teams_GetChat(chat_id=配置.chat_id)`，若 schema 暴露 chatId，则使用 `MCP_teams_GetChat(chatId=配置.chat_id)`。这是互斥分支，只调用匹配 schema 的一个形状校验精确群名，不要同时传两个键。无 chat_id 时使用 `MCP_teams_ListChats` 按用户指定群名发现，按实际 schema 设置 fetchAllPages=true 或穷尽分页，完整处理歧义后用 GetChat 校验；不能猜 ID，也不能用当前对话代替目标群。目标不明时暂停整个 execute 写阶段，保留分析。
- 每批生成稳定 `dashboard-review:<config>:<day>:<timezone>` 标记。绝对多日范围用开始/结束时间替代 day，不能与单日批次冲突。

## 2. 逐候选处置，再实际调用提交工具

先完成 detection 和 deduplication 协议。记录每项结果，不能开完第一票就结束。

| 候选结果 | 动作 |
|---|---|
| 新问题、证据达标、去重完整 | 按当前 feedback skill 完成内部调查/审阅，创建前再次搜索，再调用 feedback_submit(create) |
| 同一 open 问题无关键变化 | existing：不写 Issue，群摘要列持续 |
| 同一问题新增关键证据 | 如当前会话拥有该票且授权允许，调用 comment；否则 update_blocked，保留原链接及待补证据，不另建票 |
| closed 匹配 | 区分旧数据/未升级/复发；不自动重开或复制 Issue |
| 证据不足/预期取消或拒绝 | observed：只列观察或排除依据 |
| 搜索覆盖不足/策略不支持 | blocked：不创建 |

读取当前 feedback skill，不省略它要求的内部证据调查，也不通过拆子会话绕过单次请求限制。以下只展示提交参数形状：

```text
feedback_submit(
  action="create",
  title="[Feedback] [MCP Mail][待调查] Search 工具多次约 120 秒后失败",
  body="<按 issue-template 组装、脱敏并包含问题指纹的完整正文>"
)
```

不传虚构 issue_number，不从遥测推断 assignees，不改变固定仓库/标签。标题摘要不超过当前工具的 80 字符限制。正文在内存构建，不借 shell 或文件绕过保护提交。

只有收到成功返回的真实 `issue_number` 和 `url` 才记 created；校验 URL 指向配置仓库且编号一致。缺 URL、超时或“可能已创建”记 unknown，先只读检索确认，不再次调用 create。明确失败也不自动重试。401/403 等共享授权错误触发剩余创建停止，避免逐候选轰炸；其余候选记 blocked。用户取消时不继续建票或发群。

同会话获准补充使用：

```text
feedback_submit(action="comment", issue_number=<本会话真实回执编号>, body="<新增证据>")
```

当前 feedback_submit 不支持跨会话评论/编辑。跨天去重仍工作，但跨天自动补充旧票并未实现，不得声称完成。这是显式能力边界，不为此改用 gh 写操作。

## 3. 发送一条合并摘要

回执 disposition 统一使用 created/existing/updated/observed/blocked/failed/unknown；update_blocked、policy_blocked 仅作为 detail 中的原因，不是额外 disposition。每个候选都有终态（created/existing/updated/observed/blocked/failed/unknown）后，按 summary-template 组装一次摘要。仅使用本轮工具回执或已读 GitHub 记录中的真实链接。列出新建、持续、恶化、恢复和限制；零候选也报告覆盖范围，不宣称系统无 Bug。建票部分失败不应抹掉已成功 Issue，应合并报告成功与失败。

发送前用 `MCP_teams_ListChatMessages(chatId=配置.chat_id, ...)`（参数以实际 schema 为准）在同一目标的历史中检索稳定批次标记，原样跟随 nextLink，从最新页覆盖至本批次可能首次发送之前或历史结束；迁移时没有可靠的最早发送边界则不能判定覆盖完整。曾成功送达就不再次发送；读取失败/覆盖不完整时记 unknown，暂停发送。新批次也要预查，防止迁移后或崩溃重跑重复发送。基于同口径成功证据才可宣称恢复。

发送前加载当前 teams-message skill，遵守其标识、格式和活跃度规则；默认保留 `[🤖]` 标识，除非用户已明确关闭。按其要求选择 HTML 时先读 GetRichMessageFormats 并转义所有动态文本。

下例是当前实际暴露 `MCP_teams_SendMessageToChat` 的部署在获准使用纯文本时的调用。若发现的是旧版 `MCP_teams_PostMessage`，则按该工具的真实 schema 调用 `MCP_teams_PostMessage(chatId=配置.chat_id, content=摘要, contentType=已批准格式)`。这些名字是不同部署的可选契约，不保证两者同时存在；只选择一个已发现的工具，不能在发送失败或结果未知后换工具再发。两者均不存在则 blocked。

```text
MCP_teams_SendMessageToChat(
  chatId=<验证过的配置目标>,
  content=<带稳定批次标记和真实 Issue 链接的合并摘要>,
  contentType="text"
)
```

其他字段按实际 schema 提供空值或省略；不额外 @ 人、不发给自己、不拆成逐票消息。确需 HTML 时先读取 GetRichMessageFormats。不要使用 notify 代替指定 Teams 群发送。

只有工具确认成功并给出消息 ID 才记 sent；如返回 chatId 则还须与目标一致。dispatch 或 background task ID 不是消息回执。发送明确失败：记 failed；发送超时/异常回执：记 unknown，用只读历史核对标记，不盲重试。

## 4. 分项回执与恢复

回执只保留非秘密状态、已获准 URL、消息 ID 和简短限制；实际回执中填真实值，下面是字段说明而非成功结果：

```text
batch: <稳定批次标记>
mode: analyze | execute
coverage: complete | partial | unavailable
candidates:
  - fingerprint: <marker>
    disposition: created | existing | updated | observed | blocked | failed | unknown
    issue_number/url: <仅真实创建回执或已读 Issue>
    detail: <判断或阻塞>
notification:
  status: not_requested | sent | already_sent | blocked | failed | unknown
  chat_id: <已验证目标>
  message_id: <仅已确认发送/历史检索结果>
overall: analyzed | complete | partial | blocked | unknown
```

overall=complete 只适用于 execute、分析覆盖完整、所有候选已安全处置，且摘要 sent/already_sent；有搜索/写权限阻塞或字段不足影响关键判断时明确 partial/blocked，未知外部写结果标 unknown。analyze 返回 analyzed，不伪装执行成功。

恢复流程：重新获取当前 GitHub 去重结果和 Teams 批次历史，不依赖本地回执独存。已建票但发送失败时仅补通知；创建未知时先确认 Issue；发送未知时先确认消息。反馈工具禁止的自动重试不得因恢复而绕过。新一轮已授权运行仍须重新去重。只支持单写节点，迁移先停旧调度；这些步骤不提供并发 exactly-once 保证。

## 离线/集成验收边界

离线测试检查引用、helper 和此执行协议的关键约束，不运行真实 GitHub/Teams 操作。它不能证明模型会正确调用工具或现场权限可用。发布前可用获准的测试仓库/测试群和受支持适配器做集成验收；当前默认适配器固定真实仓库，不为测试绕过它或在生产制造测试 Issue。未做真实副作用验收时必须明确报告。
