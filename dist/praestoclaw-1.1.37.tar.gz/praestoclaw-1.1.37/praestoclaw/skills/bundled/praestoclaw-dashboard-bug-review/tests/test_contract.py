"""Offline contract tests; no production reads or writes."""

import importlib.util
import json
import re
import unittest
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location(
    "review_contract", ROOT / "scripts/review_contract.py"
)
contract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(contract)


class ContractTests(unittest.TestCase):
    def test_china_window(self):
        result = contract.windows("2026-09-14", "Asia/Shanghai")
        self.assertEqual(
            result["analysis"],
            {"start": "2026-09-13T16:00:00+00:00", "end": "2026-09-14T16:00:00+00:00"},
        )
        self.assertEqual(result["baseline"]["end"], result["analysis"]["start"])
        self.assertEqual(result["baseline"]["start"], "2026-09-06T16:00:00+00:00")

    def test_dst_uses_local_calendar_days(self):
        for day, hours in (("2026-03-08", 23), ("2026-11-01", 25)):
            window = contract.windows(day, "America/New_York")["analysis"]
            elapsed = datetime.fromisoformat(window["end"]) - datetime.fromisoformat(
                window["start"]
            )
            self.assertEqual(elapsed.total_seconds(), hours * 3600)

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError):
            contract.windows("2026-09-14", "UTC", 0)
        with self.assertRaises(ValueError):
            contract.windows("not-a-date", "UTC")
        with self.assertRaises(ValueError):
            contract.fingerprint("MCP", " ", "timeout", "search")

    def test_fingerprint_normalization_and_separation(self):
        marker = contract.fingerprint("MCP Mail", "Search", "timeout", "normal search")["marker"]
        self.assertEqual(
            marker,
            contract.fingerprint(" MCP  Mail ", "Search", "timeout", "normal\nsearch")["marker"],
        )
        for field in range(4):
            values = ["MCP Mail", "Search", "timeout", "normal search"]
            values[field] += " different"
            self.assertNotEqual(marker, contract.fingerprint(*values)["marker"])
        self.assertNotEqual(
            marker, contract.fingerprint("MCP Mail", "search", "timeout", "normal search")["marker"]
        )
        self.assertRegex(marker, r"^<!-- dashboard-bug:v1:[0-9a-f]{64} -->$")

    def test_example_is_read_only_and_unbound(self):
        example = json.loads((ROOT / "config.example.json").read_text(encoding="utf-8"))
        self.assertEqual(example["mode"], "analyze")
        self.assertIsNone(example["notification"]["chat_id"])
        self.assertTrue(example["single_writer_required"])
        self.assertEqual(example["issues"]["repository"], "gim-home/PraestoClaw")

    def test_execute_protocol_contains_actual_tool_calls(self):
        skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        execution = (ROOT / "references/execution.md").read_text(encoding="utf-8")
        self.assertIn("references/execution.md", skill)
        for required in (
            "feedback_submit(",
            'action="create"',
            "MCP_teams_GetChat(chatId=配置.chat_id)",
            "MCP_teams_GetChat(chat_id=配置.chat_id)",
            "MCP_teams_SendMessageToChat(",
            "MCP_teams_PostMessage(chatId=配置.chat_id,",
            "只选择一个已发现的工具",
            "不能在发送失败或结果未知后换工具再发",
            "teams-message skill",
            "不是额外 disposition",
            'contentType="text"',
            "issue_number",
            "message_id",
        ):
            self.assertIn(required, execution)

    def test_execute_protocol_preserves_failure_and_permission_boundaries(self):
        execution = (ROOT / "references/execution.md").read_text(encoding="utf-8")
        for required in (
            "analyze 不执行",
            "配置文件不是授权",
            "401/403",
            "跨会话评论/编辑",
            "不另建票",
            "不自动重试",
            "覆盖不完整",
            "先确认消息",
            "不提供并发 exactly-once",
        ):
            # Authorization wording is in the entry skill; the remaining guards
            # belong to the execution protocol. These are doc contract checks,
            # not an integration test of model behavior or external services.
            text = execution + (ROOT / "SKILL.md").read_text(encoding="utf-8")
            self.assertIn(required, text)

    def test_feedback_template_does_not_require_legacy_interview(self):
        template = (ROOT / "references/issue-template.md").read_text(encoding="utf-8")
        self.assertNotIn("逐问逐答", template)
        self.assertIn("内部调查与证据审阅", template)

    def test_bundled_entry_contains_minimum_execute_protocol(self):
        skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        for required in (
            "Bundled 加载与最小执行协议",
            'feedback_submit(action="create",',
            "MCP_teams_ListChatMessages",
            "fetchAllPages=true",
            "nextLink",
            "MCP_teams_SendMessageToChat(chatId=目标,",
            "MCP_teams_PostMessage",
            "32 KB",
            "[🤖]",
            "单写节点",
            "created/existing/updated/observed/blocked/failed/unknown",
        ):
            self.assertIn(required, skill)

    def test_standalone_timezone_dependency_is_declared(self):
        requirements = (ROOT / "requirements.txt").read_text(encoding="utf-8")
        self.assertIn("tzdata>=", requirements)
        readme = (ROOT / "README.md").read_text(encoding="utf-8")
        self.assertIn("pip install -r requirements.txt", readme)

    def test_relative_document_links_exist(self):
        for path in ROOT.rglob("*.md"):
            for target in re.findall(r"\]\(([^)]+)\)", path.read_text(encoding="utf-8")):
                if "://" not in target and not target.startswith("#"):
                    self.assertTrue((path.parent / target.split("#")[0]).exists(), (path, target))


if __name__ == "__main__":
    unittest.main()
