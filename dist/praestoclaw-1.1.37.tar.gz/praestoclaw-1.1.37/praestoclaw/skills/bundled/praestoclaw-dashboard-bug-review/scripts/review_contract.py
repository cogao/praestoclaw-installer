"""Pure helpers; no API calls, credentials, scheduling, or issue writes."""

import argparse
import hashlib
import json
from datetime import UTC, date, datetime, time, timedelta
from zoneinfo import ZoneInfo


def windows(day: str, zone: str, baseline_days: int = 7) -> dict:
    """Return adjacent local-calendar windows converted to UTC, exclusive end."""
    if baseline_days < 1:
        raise ValueError("baseline_days must be positive")
    local_day = date.fromisoformat(day)
    tz = ZoneInfo(zone)

    def boundary(value: date) -> str:
        return datetime.combine(value, time.min, tz).astimezone(UTC).isoformat()

    start = boundary(local_day)
    return {
        "day": local_day.isoformat(),
        "timezone": zone,
        "analysis": {"start": start, "end": boundary(local_day + timedelta(days=1))},
        "baseline": {
            "start": boundary(local_day - timedelta(days=baseline_days)),
            "end": start,
        },
    }


def fingerprint(component: str, operation: str, failure_mode: str, trigger: str) -> dict:
    """Stable hash of explicit, non-secret semantics; NOT a deduplication lock."""
    fields = dict(
        component=component, operation=operation, failure_mode=failure_mode, trigger=trigger
    )
    normalized = {key: " ".join(value.split()) for key, value in fields.items()}
    if not all(normalized.values()):
        raise ValueError("all fingerprint fields must be nonempty")
    payload = json.dumps(normalized, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return {"version": 1, "fields": normalized, "marker": f"<!-- dashboard-bug:v1:{digest} -->"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    window = commands.add_parser("windows")
    window.add_argument("--day", required=True)
    window.add_argument("--timezone", required=True)
    window.add_argument("--baseline-days", type=int, default=7)
    identity = commands.add_parser("fingerprint")
    for name in ("component", "operation", "failure-mode", "trigger"):
        identity.add_argument(f"--{name}", required=True)
    args = parser.parse_args()
    if args.command == "windows":
        result = windows(args.day, args.timezone, args.baseline_days)
    else:
        result = fingerprint(args.component, args.operation, args.failure_mode, args.trigger)
    print(json.dumps(result, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
