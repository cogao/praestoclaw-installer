---
name: team-knowledge-curate
description: Assess whether a saved capture warrants a knowledge-base update, create a local proposal when it does, get one group confirmation, and publish it immediately.
metadata:
  activation:
    praesto-tag-exp-only: true
    keywords:
      - 知识库
      - 团队知识库
      - 整理到知识库
      - 更新知识库
      - 更新到kb
      - 写入知识库
      - 沉淀到知识库
      - 配置知识库
      - 知识库配置
      - 知识库仓库
      - knowledge base
      - team kb
      - curate knowledge
      - publish to kb
      - configure knowledge base
      - should update knowledge base
      - need to update knowledge base
      - go into kb
      - belong in kb
    patterns:
      - "(?i)(整理|沉淀|归档|写入|录入|更新|同步|补充|发布).{0,24}(知识库|kb|team knowledge)"
      - "(?i)(知识库|team kb).{0,24}(整理|沉淀|归档|写入|录入|更新|同步|补充)"
      - "(?i)(配置|设置|绑定|指定|换|改).{0,16}(知识库|kb)"
      - "(?i)(知识库|kb).{0,12}(配置|设置|绑定|指定)"
      - "(?i)(知识库|kb).{0,12}(仓库|repo|目录|文件夹|路径)"
      - "(?i)(update|curate|publish|write|add).{0,24}(knowledge base|team kb|\\bkb\\b)"
      - "(?i)(knowledge base|team kb).{0,24}(update|curate|publish|write|add)"
      - "(?i)(configure|set up|bind|point).{0,24}(knowledge base|team kb|\\bkb\\b)"
      - "(?i)(把|将).{0,32}(整理|沉淀).{0,16}(进|到).{0,8}(知识库|kb)"
      - "(?i)(知识库|kb).{0,20}(是否|需不需要|要不要|该不该|应不应该|有无必要|有没有必要|是否值得).{0,12}(更新|整理|沉淀|补充)"
      - "(?i)(是否|需不需要|要不要|该不该|应不应该|有无必要|有没有必要|是否值得).{0,20}(更新|整理|沉淀|补充|写入).{0,12}(知识库|kb)"
      - "(?i)(should|does|do|is).{0,16}(the )?(knowledge base|team kb|\\bkb\\b).{0,16}(need|require|warrant).{0,12}(an? )?(update|change)"
      - "(?i)(should|need|worth).{0,16}(update|updating|add|adding|put|putting).{0,20}(the )?(knowledge base|team kb|\\bkb\\b)"
      - "(?i)(should|does).{0,24}(go|belong).{0,12}(into|in|to).{0,8}(the )?(knowledge base|team kb|\\bkb\\b)"
      - "(?i)(是否|需不需要|要不要|该不该|应不应该).{0,20}(进|放入|放进|写入).{0,8}(知识库|kb)"
  requires:
    tools: [kb_scope, kb_inspect, kb_draft, kb_publish, kb_change_history]
  os: [win32]
---

# Team Knowledge Curation

Second stage of the two-stage flow. Collection normally happened already:
verbatim Teams material is cached and folded into a capture snapshot. Your job
is to turn that evidence into changes **this** knowledge base will accept, get
the group to confirm the staged proposal once, and publish immediately. If no snapshot exists yet, step 1
tells you how to collect one first.

You never invent the destination. Every repository states its own rules and
those rules change; read them each time.

## Hard rules

1. **The repository's rules win.** Read `kb_inspect(action="rules", task_id="<task ID>")` for the
   area you intend to touch before drafting anything. Rules cascade: the root
   states general ones, each folder narrows them, and a rule may **delegate**
   to another document ("only use the sources listed in sources.md"). Follow
   the delegation — `rules` returns those documents marked `delegated_from`,
   and a constraint you did not open still binds you.
2. **The live group KB is authoritative; session state is only an expectation.**
   Other people and automations may modify the repository between any two turns.
   A capture, session history, active task, prior proposal or published receipt
   proves what happened earlier; none proves what the KB contains now. Before
   drafting, sync the repository and read the complete current target documents.
   Compare that live content with what the session/history led you to expect:

   - If they differ without semantic conflict, preserve the live content and
     apply the still-needed update normally.
   - If they conflict, do not silently restore the expected old state, discard
     the external edit, defer everything, or merely say the KB looks wrong.
     Generate the proposal in the same turn against the live KB. Preserve all
     non-conflicting external edits, and call out each conflict in the proposal
     overview/details: the file path, what the live KB says, what the session or
     prior receipt led you to expect, and how this draft proposes to resolve it.
   - The normal proposal confirmation covers both the ordinary changes and the
     called-out conflict resolutions. Ask a separate blocker question only when
     repository rules make even a reviewable resolution unsafe to propose.

3. **A rule conflict is reported, never drafted around.** If the material breaks a
   stated rule — the wrong source, verbatim content where the repository asks
   for summaries, the wrong location — record it with
   `kb_draft(action="blockers", task_id="<task ID>")`. Staging refuses while a blocker is open. The
   group decides: change the draft, or knowingly override. An override is
   written into the commit message.
4. **One confirmation, in the group, in plain language.** Ask whether the staged
   local proposal is correct as an ordinary chat message, **end your turn**, and
   read the reply when it arrives on the next one. Any group member may answer.
   Record it with `kb_draft(action="approve", task_id="<task ID>", stage="draft", ...)`, quoting their
   words. If approved, call `kb_publish` immediately in that same reply turn.
   Never ask a second "confirm publishing" question. Do not send an Adaptive Card,
   use a plan checkpoint as approval, or ask anyone to approve a remote
   review branch.
5. **Only a clear yes is an approval.** You are reading intent out of chat, so
   read it conservatively. "可以 / 就这样 / 发吧 / ok, go ahead" is approval;
   "改一下 / 再看看 / 等等" is `changes_requested`; "不行 / 算了" is `rejected`.
   Silence, a question, a partial answer or an emoji is **none of them** — ask
   again rather than deciding for them. An answer about something else entirely
   is not an answer to this. The `quote` must be a message a **person** sent:
   tool output describing a decision is not a person agreeing to one, and is
   refused.
6. **Never publish what the group has not confirmed.** The proposal approval
   binds to the current local proposal fingerprint. Updating or amending the
   proposal commit voids it: summarize the new commit and ask again.
7. **The local proposal remains authoritative.** `stage` creates or updates the
   local proposal branch and commit. For GitHub repositories it may also
   best-effort push that branch and create or refresh a Draft PR so people can
   inspect the actual diff. When `stage` returns `review_url`, include that link
   with the normal spoken summary. The confirmation still happens in this Teams
   chat — never ask anyone to approve or merge the PR. If the optional review is
   unavailable, say nothing about it and continue with the local proposal.
8. **Provenance survives.** Every drafted statement traces back to a capture
   record and, where one exists, the original Teams deep link. A claim you
   cannot source does not enter the knowledge base.
9. **Say what you left out.** Gaps in the capture (`source_gap`) and units the
   group dropped are reported, not quietly discarded.
10. **Tasks are independent and identified by `task_id`.** Resume the same ID
   when the group answers or edits its proposal. Start a separate task for an
   independent new request, even when this conversation has unfinished tasks.
   Only when the user explicitly replaces a prior request, call
   `kb_draft(action="restart", task_id="<old task ID>", ...)`. Restart cleans up
   that task's worktree and proposal branch when its publish outcome is known,
   cancels it, and returns a new
   `task_id` and `worktree_path`; unrelated tasks are unaffected. If cleanup
   fails, report it and preserve the recorded task for follow-up. Never carry
   units, approvals or proposal content into the replacement task; re-extract
   still-valid knowledge from its fresh capture.
11. **Do not touch the evidence.** The capture snapshot is append-only input.
12. **Your own messages are not evidence.** The capture contains this chat's
    whole history, and a large part of it is you — `PraestoClaw` in production,
    `PraestoClawStaging` in staging, named in the turn's `Your identity` line.
    The knowledge base records what the *team* worked out, never what you
    previously told them. A statement whose only source is a message you sent
    is unsourced by rule 8: drop it, or find the human message it actually came
    from. Where the group confirmed something you proposed, the evidence is
    *their* confirmation, not your proposal.
13. **The group chooses its knowledge base; you never do.** Which repository
    and folder this conversation writes to comes from `kb_scope`, set from what
    the group actually said — asked now, or said earlier in this chat. Saving it
    announces itself to the group so a wrong reading gets corrected. A
    repository outside the allowed list cannot be reached by asking again — it
    takes a config change by the person the refusal names.
14. **An update-assessment question authorizes a draft.** "知识库需不需要更新？",
    "Should this go into the KB?", and equivalent questions ask you to make the
    assessment and act on it. If the captured evidence warrants a change,
    continue all the way through `kb_draft(action="stage", task_id="<task ID>")` and present the first
    confirmation summary. Do not stop after describing a hypothetical change,
    and do not ask the group to explicitly say "update the knowledge base" or
    whether you should generate the proposal. The question does **not** authorize
    publishing: the single staged-proposal confirmation still applies. If no defensible change is
    warranted, say so with the short reason and do not manufacture a proposal. But
    once you conclude that content should be written, ending with "尚未创建或发布 KB
    草案" (or any recommendation-only equivalent) is a workflow violation: create
    and stage the proposal in that same turn.

## Workflow

### 1. Resume, replace, or start

Use the task ID carried by the conversation or handoff to resume a task with
`kb_draft(action="show", task_id="<task ID>")`. If discovery is needed, use
`kb_draft(action="list")` and match the request; do not choose another task just
because it is newest.

- **They are replying to that task** — continue its explicit ID and status.
  If it is `awaiting_publish` / `ready_to_publish`, publish that approved task
  immediately, subject to the freshness check in step 8. Never ask for a second
  publish confirmation after an agent restart or background-task handoff.
- **They are making an independent update or assessment request** — start a new
  task; leave other unfinished tasks intact.
- **They explicitly replace a previous request** — refresh the capture when
  requested, then call:

  ```
  kb_draft(action="restart", task_id="<old task ID>",
           user_request="<the new request, verbatim>",
           capture="<the fresh capture filename>")
  ```

  Record the new task ID and worktree path returned by restart. Do not call
  start again. Continue through rules, units, selection and stage in this turn;
  the replacement proposal needs its own normal confirmation. If cleanup fails,
  report the failure instead of trying to rebuild the shared repository.

For a new task, check where this group's knowledge goes:

```
kb_scope(action="show")
```

**If it is not configured, configure it before anything else.** Prefer asking
the group, in one message, which repository to use and — optionally — which
folder inside it. When they have already said it earlier in the conversation,
you may take it from there instead of asking again. What you must never do is
choose a repository or folder nobody named.

```
kb_scope(action="set", repo="<what they said>", subfolder="<what they said>")
```

Saving it posts a short message to the group naming what was recorded, so they
can correct it — that is why taking the answer from earlier chat is acceptable.
The reply's `announced_to_group` says whether that message went out; when it is
`false` the announcement is yours to make. Either way do not repeat it back a
second time.

Never substitute a similar-looking name from the list. `show` returns the
repositories that may be chosen — offer them rather than guessing. Two refusals
are possible and they are not the same thing:

- **Not an allowed repository.** Only the person named in the reply can widen
  that list, in the config on the machine running this agent. Relay it, and stop
  — configure again after they confirm it is done.
- **The folder does not exist.** Ask the group again with the folders the reply
  lists. Do not invent a path, and do not quietly drop the folder they asked for
  and bind the whole repository instead.

The subfolder is where this group's knowledge *prefers* to live, not a fence:
read its rules first and draft there by default, but follow the repository's own
conventions when they point elsewhere.

Once a binding exists, start a task only when step 1 did not resume a task or
already call `restart`:

```
kb_draft(action="start", user_request="<what the group asked, verbatim>")
```

This picks the newest capture, fetches the configured target branch, and pins
that starting commit in an isolated task worktree. Record the returned `task_id`
and `worktree_path` for all later turns and skill handoffs. Every existing-task
write action requires that explicit ID, including units, selection, blockers,
staging, approval, cancellation and restart. For shell work, use the returned
worktree path as the working directory on a best-effort basis rather than
locating the shared clone yourself.

The returned capture inventory includes counts, time ranges, transcript sizes
and gaps; the snapshot itself stays on disk. `kb_scope` returns the configured
`base_branch`. To change it, use `kb_scope(action="set", branch="<named branch>")`;
omitting branch preserves an existing same-repository setting or lets the tool
detect the remote default. Do not guess it. Scope changes affect new tasks and
latest KB reads; existing tasks retain their recorded repository and branch.

**If `start` reports that no capture snapshot exists**, the material has simply
not been collected yet — the group asked for the destination without the
collection step. Collect it first, in this same turn:

```
skill(name="team-knowledge-capture", action="load")
```

Follow those instructions to produce a snapshot, then come back here and run
`kb_draft(action="start")` again. Never draft from your memory of the chat: by
rule 8 every statement you publish must trace back to a capture record, and a
recollected message is not one. If that skill comes back unavailable, say so
and stop rather than reconstructing the discussion yourself.

### 2. Learn this repository's rules

```
kb_inspect(action="sync", task_id="<task ID>")
kb_inspect(action="rules", task_id="<task ID>", path="<the area you think this belongs in>")
kb_inspect(action="tree", task_id="<task ID>", path="<that area>")
kb_inspect(action="read", task_id="<task ID>", path="<a neighbouring document>")
```

Use `kb_inspect` without `task_id` to read the latest published KB on the
configured target branch. Pass `task_id="<task ID>"` to rules/tree/read/search
when reading the draft. `sync(task_id=...)` fetches that task's target and
reports both its baseline and latest remote SHA; it does not reset the task or
overwrite draft files. Each latest-KB read reports its SHA and may observe a
newer commit than the preceding call.

`sync` and the subsequent reads are mandatory even when session history or
`kb_change_history` says a change was published. History establishes provenance,
not current repository state. Read the complete current content of every file
you may update; do not reconstruct its base from a prior proposal or receipt.

Read every returned rule document, including the ones marked `delegated_from`
— those were pulled in because another rule pointed at them, and they carry
constraints the pointing document only alludes to.

Ask specifically:

- **May this material be used at all?** Some repositories restrict which
  sources feed the knowledge base. Being asked in a chat is not the same as
  that chat being an accepted source.
- **May it be stored in this form?** A repository that keeps structured
  summaries and source links does not accept a verbatim chat copy, however
  convenient that would be.
- **Does this folder narrow the rule further?** A folder may accept material
  the repository generally refuses, or the reverse.

Read a real neighbouring document too. Matching the shape of what is already
there does more for acceptance than any general instruction about good writing.

If nothing in the repository fits the material, say so and propose a new area
with reasoning — do not force knowledge into an unsuitable place.

### 3. Record any conflict before drafting

Every rule you find that this material appears to break becomes a blocker:

```
kb_draft(action="blockers", task_id="<task ID>", blockers=[
  {"rule_source": "context/sources.md",
   "rule": "<the rule, quoted>",
   "conflict": "<how this material breaks it>"}
])
```

Do this **before** staging. `stage` refuses while a blocker is open, and that
is deliberate: a finished-looking proposal that quietly walked past a rule is
exactly the artefact a group approves by mistake.

Surface each blocker in ordinary chat: quote the rule, name the document and
say plainly what it means. This is clarification required to make a valid
proposal, not the staged-proposal confirmation gate. Record what the group decides:

```
kb_draft(action="resolve_blocker", task_id="<task ID>", blocker_id="b1",
         resolution="resolved|overridden", note="<their reasoning>", decided_by="<who>")
```

`resolved` means you changed the plan so the conflict is gone. `overridden`
means the group knowingly proceeded anyway — it requires a reason and is
written into the commit message as a `KB-Rule-Override` trailer, so the
decision survives the chat.

### 4. Extract knowledge units

Read the capture and record what you found:

```
kb_draft(action="units", task_id="<task ID>", units=[
  {"type": "decision", "title": "...", "content": "...",
   "evidence": [{"capture_record": 0, "message_id": "...", "url": "https://teams..."}]}
])
```

Types: `fact`, `decision`, `action`, `risk`, `question`, `background`, `status`.
Separate what was *decided* from what was merely *discussed*; mark anything
unconfirmed as such in `confidence`.

Skip your own messages while you read (rule 12). Your earlier answers, summaries
and status reports look exactly like well-formed knowledge units, which is the
trap: publishing them launders your own output back in as a team fact, and the
next capture re-reads it as evidence. Attribute by the sender's display name,
not by how authoritative the text sounds. A question you answered contributes
at most the *question* — the answer needs a human source or a group
confirmation before it counts.

### 5. Select the knowledge to include

Use the group request, the repository rules and any blocker resolutions to
select the knowledge units for this proposal:

```
kb_draft(action="select", task_id="<task ID>", unit_ids=[...])
```

Do not silently broaden the request. Units you leave out, capture gaps
(`source_gap`) and the reasons for both remain part of the task record.

For an update-assessment question, this is where you answer it from the evidence
and the current repository contents. If one or more sourced units would add or
correct useful knowledge under the repository's rules, select them and continue
through staging in this turn. The staged local proposal is the answer; a prose
description of what a future diff might contain is not. If nothing would
materially improve the knowledge base, explain that briefly and stop without
staging an empty or cosmetic proposal.

When live content differs from session/history expectations, classify the
difference before selection. Units already represented by the live KB are not
selected again. Non-conflicting missing units proceed normally. Conflicting
units remain eligible for this proposal, but their proposed resolution must be
called out under hard rule 2 rather than silently overwriting either side.

### 6. Record any conflict you find later

If drafting surfaces a further conflict, record it with
`kb_draft(action="blockers", task_id="<task ID>")` and take it back to the group. Staging and
publishing both refuse while a blocker is open.

### 7. Create the local proposal branch and commit

Stage the **complete new content** of each file — not a patch — together with
the commit message:

```
kb_draft(action="stage", task_id="<task ID>",
         message="<conventional-commit subject, in the repo's own style>",
         overview="<macro-level summary of the complete proposal>",
         changes=[
  {"path": "...", "operation": "create|update", "content": "<full document>",
   "summary": "<one sentence retained in publish history>",
   "details": ["<complete semantic detail 1>", "<complete semantic detail 2>"],
   "rationale": "<why here, citing the rule>", "units": ["u1", "u3"]}
])
```

This creates the authoritative local proposal branch and commit. When GitHub
credentials and API permissions are already available, `stage` also mirrors the
same commit to a remote proposal branch and Draft PR. This is optional and
best-effort: absence or failure is not reported to the group. `stage` returns the
proposal fingerprint, a structured confirmation summary and, when available,
`review_url`. The commit message is part of the proposal; changing it is the same
as changing a file, and restaging refreshes the same optional Draft PR.

For every current-KB/session conflict, make the structured confirmation summary
explicitly include: the affected path, the live KB position, the expected prior
position, the proposed resolution, and which external content was preserved.
These conflict callouts accompany the ordinary per-file change details; they do
not replace or delay the rest of the proposal.

### 8. Single confirmation — the local proposal

Turn the structured confirmation summary into an ordinary chat message with:

- a macro-level overview of the proposal;
- every complete file path; and
- a detailed per-file overview of what will be created or changed; and
- the Draft PR link when `review_url` is present, as an optional way to inspect
  the actual diff.

Do not paste the diff into chat or make GitHub review state the approval gate.
Ask whether this draft is correct, then **end your turn**. There is no card or
button; wait for someone to type a reply in the next turn. Record that reply
exactly:

```
kb_draft(action="approve", task_id="<task ID>", stage="draft",
         decision="approved|changes_requested|rejected",
         quote="<their exact words>", by="<who answered>")
```

The quote is required, and `approve` refuses on the same turn the question was
asked — the record has to be a real reply, not your own summary of one.

If they request changes, update the complete file content and call
`kb_draft(action="stage", task_id="<task ID>", ...)` again. It updates or amends the local proposal
commit and returns a new fingerprint and summary. Present the entire current
summary and ask the draft question again; an approval for an earlier local
commit is invalid. If they reject it, cancel with
`kb_draft(action="cancel", task_id="<task ID>")`.

When the recorded decision is `approved`, do **not** summarize the commit again,
ask whether to publish, or end the turn. The approval authorizes the push. Call
`kb_publish(task_id="<task ID>")` immediately and follow step 9. A later proposal change invalidates
the approval and returns to step 7/8.

Immediately before publishing, call `kb_inspect(action="sync", task_id="<task ID>")`
once more and read the latest published files as needed (omit `task_id` when
reading the published target rather than the task's draft). A newer target head
alone does not invalidate approval: publication preserves external edits that
Git can merge without conflict, including edits elsewhere in the same file.
If inspection reveals a semantic conflict, or publication reports a Git merge
conflict, rebuild the proposal from the latest published content, preserve
non-conflicting work, call out the conflict resolutions, and obtain the normal
proposal confirmation again. Never silently resolve a conflict or replace live
content with a session-expected document.

### 9. Publish immediately after proposal approval

```
kb_publish(task_id="<task ID>")
```

Publishing fetches the task's fixed target branch and squash merges the approved
proposal in a temporary detached worktree, then commits and pushes explicitly
to that target. The optional Draft PR is closed rather than merged, with no
additional confirmation. A true Git merge conflict or rejected push is reported
as failure; the tool does not resolve it automatically. The failed attempt's
workspace is cleaned up while the draft is retained, except when a push outcome
is unknown and its record and worktrees must remain available. Proposal edits still
require the normal confirmation again. On success, the task records the final
SHA and cleans up its worktree and proposal branch. A cleanup failure after a
successful push does not mean publication failed; use the reported result.

Use `error.code` to distinguish `merge_conflict` (the latest KB conflicts with
the draft) from `target_advanced` (the target changed during publication; this
alone does not establish a content conflict). Neither means the draft was
judged incorrect. For `publish_outcome_unknown`, do not claim the KB was unchanged.
Calling `kb_publish` again only checks that previous attempt, without pushing
again. A result of `outcome="not_published"` means the check found no published
commit, not that a new update succeeded. The user may cancel or restart before
the outcome is known; the old task ends and retains its record/worktrees for
later checking. Cancellation does not undo a remote update.

Treat the tool's `reply` as factual input, not as a sentence template. Give the
group exactly one brief, natural result sentence in their language:

- On confirmed publication, say in nontechnical terms that the knowledge base was updated and
  preserve the returned explicit Markdown link so it stays clickable in Teams.
- On a known failure, say that the knowledge base could not be updated and give the
  returned short reason in plain language without inventing a diagnosis.
- On an unknown outcome or a reconciliation-only result, report that outcome
  accurately using the returned `reply`; `ok=true` alone does not mean published.
- Avoid implementation vocabulary such as push, commit, branch, squash or PR
  unless the group explicitly asks for technical details.

Do not repeat paths, summaries, unit lists, exclusions, blockers or overrides.
The complete technical receipt — proposal/final SHAs, branch, URL, files,
approval quote, attempts and errors — is persisted and queryable later through
`kb_change_history`.

## When this does not apply

- "What does the KB say about X?" — that is a question, not a curation task.
- "Summarise this discussion" — summarising in chat writes nothing.
- Collection only ("收集一下这两周的群消息") — that is the capture skill's job
  and it ends at the saved snapshot. Curation starts only when the group asks
  for the knowledge base itself to change **or asks you to assess whether the
  captured material warrants a change**. In the latter case, a warranted change
  proceeds directly to a local proposal without another opt-in question.
