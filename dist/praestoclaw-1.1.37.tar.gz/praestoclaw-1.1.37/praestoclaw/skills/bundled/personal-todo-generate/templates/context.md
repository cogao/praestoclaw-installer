# Run metadata
```json
{{metadata}}
```

# Context

## Identity and baselines
- Current user (display name / UPN / user ID), observed at:
- M1 / M2, verified at or unknown:
- State inheritance run:
- Last successful reminder run:
- Current request and explicit user corrections, with time:

## Actual source coverage
- Intent, local runtime, timezone, discovery window and fixed follow-up upper bound:
- KB worktree / commit / weeks / files actually read:
- Teams discovery coverage, per-chat follow-up boundaries, raw JSONL paths and observation times:
- GitHub issue URLs / refresh times / comment coverage / latest cache paths:
- Missing or partial coverage and historical fallback observation times:

## Evidence and changes
Repeat for each new, merged, changed or uncertain item. Preserve the original evidence of carried items by linking its historical run and raw source.

### {{stable todo ID}} · {{title}}
- Original requirement and completion scope:
- Prior state → current state; event time and reason:
- Source URL, raw location and observation time:
- Key original quotation (including issue state and close reason observed then):
- Conflicting or incomplete evidence:
- Merge relationship, if any:

## Reminder comparison
- Items actually included in the last successful reminder and now confirmed complete, with evidence:
- Separate cancellation / transfer changes, if relevant:

## Generation and delivery notes
Lifecycle and actual delivery receipt are maintained in Run metadata by the helper. Record any collection limitation or delivery error here without replacing the recorded result with an inferred success.
