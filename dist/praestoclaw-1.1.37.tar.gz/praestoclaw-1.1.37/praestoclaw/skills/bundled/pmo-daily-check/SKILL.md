---
name: pmo-daily-check
description: "Use in PraestoClaw private chat or group chat for PMO daily progress sync: summarize progress against weekly goals, combined evidence/risk status, and @mention needed follow-ups."
metadata:
  activation:
    keywords:
      - PMO daily check
      - PMO 日检查
      - PMO 每日同步
      - 每日项目进展
      - 本周目标进展
      - 进展百分比
      - 风险完成度
      - evidence and risk
      - daily PMO
      - daily project sync
    patterns:
      - "(?i)(pmo).{0,16}(daily|day|日|每日|日报|日检查)"
      - "(?i)(每日|今天|日常|daily).{0,20}(pmo|项目).{0,20}(同步|进展|风险|检查)"
      - "(?i)(本周目标|weekly goals?).{0,20}(进展|progress|百分比|risk|风险)"
      - "(?i)(统计|汇总).{0,20}(目标|成员|进展|风险).{0,20}(完成度|百分比|evidence)"
  os: [win32]
  safe-tools:
    - tool: kb_scope
      match:
        action: "^show$"
    - tool: kb_inspect
      match:
        action: "^repos$"
    - tool: kb_inspect
      match:
        action: "^sync$"
    - tool: kb_inspect
      match:
        action: "^rules$"
    - tool: kb_inspect
      match:
        action: "^tree$"
    - tool: kb_inspect
      match:
        action: "^read$"
    - tool: kb_inspect
      match:
        action: "^search$"
    - tool: kb_change_history
      match:
        action: "^latest$"
    - tool: kb_change_history
      match:
        action: "^show$"
    - tool: kb_change_history
      match:
        action: "^file$"
---

# PMO Daily Check

Use this skill in a direct PraestoClaw private chat or in the relevant project
group chat. It collects daily progress against this week's goals, produces a
daily table and follow-up list, uses `pmo-grill` only as a pre-send self-check
on the generated draft, and remains read-only.

## Conversation visibility

Keep the visible chat quiet. Keep internal plan progress, checklist progress,
step-by-step verification messages, and background status cards out of the
visible conversation. The user should see only the daily table, action-needed
follow-ups, up to three PMO focus items, and one short source blocker when
KB/source access is unavailable.

Follow the runtime's Teams native-mention guidance. Send a live Teams
`groupChat` or `channel` report through
`group_notify(content="...", teams_mentions=[...])`; use
`notify(channel="cloud", content="...", teams_mentions=[...])` only for a
personal/non-group cloud turn. After successful delivery, reply only with a
short receipt such as `已发送 PMO daily check。` and do not repeat the report.

Mention every distinct human represented in the table or follow-up list, not
only the sender. Match each visible `@Full Name` with one
`{"name": "<display name>", "type": "user"}` object, adding `upn` or `id` when
available. A display-name-only identity with `type="user"` remains a structured
best-effort mention. Do not substitute `@所有人`, `@everyone`, or `type="all"`
unless the user explicitly requests a Teams-wide mention.

If the required delivery tool is unavailable, emit the complete report in the
normal final reply with visible `@Full Name` text and no `teams_mentions`. Do not
claim native delivery or include mention-tool/fallback diagnostics.

Teams reports must be readable without horizontal scrolling. Do not use a wide
Markdown table for owner status. Use one compact summary table with at most four
short columns, followed only by rows that need action and up to three PMO focus
bullets. Do not repeat table content in owner sections, narrate how the report
was produced, or add a conclusion paragraph. Use one short line per follow-up.

## Permission and approval model

Follow the same KB permission model as `pmo-grill`: KB tools are optional
capabilities for discovery and stay out of hard `requires.tools`. Safe KB read/discovery
actions are declared in `safe-tools`; KB write actions are outside this skill.
Use `kb_scope show`,
`kb_inspect` repos/sync/rules/tree/read/search, and `kb_change_history`
latest/show/file as the only KB read path. These KB read/discovery actions,
including `kb_inspect(action="sync")` even when it creates or updates the local
checkout, must run without interactive human approval. Do not ask the user to
approve KB reads, and do not substitute `shell`, `git`, `Remove-Item`, `curl`, or
filesystem commands for KB read/sync/discovery work. If a safe KB read tool is
missing or refused, report that exact capability as blocked and ask for the
needed KB text/link instead of requesting a shell approval. Do not call
KB write or KB binding mutation tools from daily check.

## External source boundary

Default evidence sources are the configured KB, the current PraestoClaw turn,
and text or links the user explicitly provides in this daily-check conversation.
Do not call Teams, M365 Copilot, M365 user, mail, calendar, SharePoint, WorkIQ,
or similar external MCP tools to discover updates, resolve people, search chat
history, inspect meetings, or fill missing evidence unless the current user
explicitly asks for that external search in this turn.

In particular, do not use or discover tools such as `MCP_teams_*`,
`MCP_m365-copilot_*`, `MCP_m365-user_*`, `MCP_mail_*`, `MCP_calendar_*`,
`MCP_sharepoint_*`, `MCP_workiq_*`, `teams_group_fetch`, or
`team_knowledge_capture` for a normal PMO daily check. If the user explicitly
asks to search Teams/M365, keep that search narrowly scoped to the named chat,
person, meeting, date range, or message link, and label the result as external
evidence. Otherwise mark unavailable updates as `not updated`, `partial`, or
`insufficient` instead of trying to recover them from Teams/M365.

For follow-up mentions, use mention metadata already present in the KB or in the
current turn. Do not query Teams/M365 only to resolve a mention; fall back to
plain `@Full Name` text only when the required delivery tool is unavailable.

Daily check does not write KB content. Do not include a `Recommended KB
follow-up`, KB update plan, target-file list, or handoff prompt in the visible
daily report.

## Mandatory preflight

Before daily work starts, perform the same KB preflight as `pmo-grill`:

1. Run `kb_scope(action="show")`.
2. If no KB is configured and the current user provided a GitHub URL under
  `gim-home/SocietasKnowledgeBase/tree/main/...`, derive the repo and subfolder
  for this run without saving a conversation binding. Ask the user for a KB URL
  or PMO folder scope only when no KB binding and no usable KB URL are present.
3. Run `kb_inspect(action="sync")` so a missing clone is created and an existing
  checkout is updated to the latest remote state. This is a safe KB read/sync
  action and must not be replaced by an approval-gated shell/git command.
4. If a KB capability is unavailable in the current chat context, keep the daily
  check moving. Ask the user for the KB URL or PMO folder scope when the
  destination cannot be resolved, continue from that provided source, and mark
  only the unavailable capability as blocked. Report the exact blocked
  capability: binding, live sync, or read.

## Reminder semantics

The daily check message itself is the reminder. Send the check result without
waiting for member responses inside this skill. Read the previous daily/weekly
PMO records and check whether each previously requested evidence/update has been
supplied. Carry unresolved items forward and increment or state the reminder
count.

Every missing-update row must @mention the responsible member when a mention form
is known, using the same spelling supplied by the KB or current conversation.
Example: `@Member：请在 <date/time> 前补 <goal> 的 evidence；这是第 2 次提醒。`

If a member replies later, the next daily check should detect the new evidence or
owner update and close or carry forward the follow-up in the next report. Keep
the current daily check on its scheduled path.

## Daily workflow

1. Resolve today's date, the active week, and the weekly goal list. In a new
  group-chat session, use the configured KB to discover this before asking the
  user for a goal list. Read the root/area README, weekly-cycle files, active
  weekly report, progress files, and recent daily/weekly PMO records as needed.
  Ask the user for the goal list only after KB read tools are unavailable or the
  configured source genuinely contains no active-week/goals signal.
2. For each goal, collect or confirm:
  - goal owner and participating members;
  - current weekly-goal progress estimated from available evidence;
  - weekly-goal progress made since the last daily check;
  - evidence supplied today;
  - risk level and reason;
  - blocker or dependency;
  - next action, owner, due date, and requested PMO help.
3. Draft the daily table and follow-up list from the available information. When
   a row is missing evidence, owner, date, or risk reason, mark that missing
   state explicitly in the draft instead of hiding it.
4. Before sending the daily result, apply the `pmo-grill` evidence standard as
  an inline self-check on the draft. Use the standard directly inside daily
  check: every table row needs goal status versus expectation, evidence or an
  evidence gap, and delivery risk with its reason. Every action-needed follow-up
  needs a next action and date. Check every original and added goal against the
  source inventory; verify that progress summaries and scope changes have not
  replaced goal text.

5. If the self-check finds a defect, revise the draft before sending. Ask a new
  question only when the defect makes the daily result materially misleading and
  the row cannot be represented as `partial`, `insufficient`, or `not updated`.
6. After sending the daily result, stop. Daily check remains read-only and does
  not append KB recommendations or handoff instructions.

## Required daily table

Present the daily result as a compact table with these columns:

| Weekly goal | Owner | Goal progress | Evidence / risk |
|---|---|---|---|

Do not replace this required table with an owner/risk summary table. The `Owner`
cell must contain the visible `@Full Name` form used by `teams_mentions`.
One row represents one weekly goal. A work item gets its own row only when that
work item is itself the weekly goal. Immediately after the table, use short
per-goal or per-owner bullets only for action-needed follow-ups, then list PMO
focus separately. `Next action` and `PMO focus` must not be table columns.

Keep the visible report compact:

- no prose introduction beyond a one-line date/week heading;
- one table row per goal;
- follow-up lines only for goals that need owner action;
- at most three PMO focus bullets, omitting the section when there is no focus;
- no repeated summary, methodology, source inventory, handoff code block, or KB
  recommendation section.

## Goal preservation contract

- `Weekly goal` contains the original week-start goals plus goals added during
  the week. Preserve the original goal wording, deliverable, quantities, and
  acceptance boundaries; do not replace them with a project label, progress
  summary, latest forecast, or reduced scope. Compact formatting must not remove
  goal content; allow the cell to wrap instead.
- Reconcile the week-start baseline with dated additions in the weekly change
  log, project records, and authorized human updates. Append each newly agreed
  goal with its addition date and source, preserving its wording at addition.
  Do not omit an added goal merely because it lacks a weekly commitment ID or
  its weekly-cycle update is pending sync. Keep existing IDs; never invent one.
  A former candidate becomes a row when a human adds it to this week's goals,
  even if its ETA or acceptance details still need clarification. Mere ideas
  without a decision to add them this week remain candidates, not commitments.
- `Evidence / risk` summarizes progress and evidence against that row's goal,
  including missing evidence, blockers, and dated scope/ETA changes with their
  decision source. Preserve the original goal even after an approved reduction,
  deferral, or cancellation; describe that decision here instead of rewriting
  or silently dropping the row. Flag conflicting sources or pending sync here.
- Before sending, verify one row per original or added goal, no omissions or
  duplicates, faithful goal wording, and a goal-to-evidence rationale for each
  progress estimate. Earlier agent reports are not the goal source.

## Evidence and risk semantics

Use one short `Evidence / risk` cell to combine all three previously separate
signals: evidence completeness, the concrete evidence or missing evidence, and
delivery risk. Do not create separate `Evidence completeness`, `Missing
update/evidence`, or `Risk` columns.

Start the cell with one of these evidence labels:

- `complete`: progress, risk, evidence, owner, next action, and date are all
  present;
- `partial`: enough to track the goal, but at least one useful detail is missing;
- `insufficient`: PMO cannot support the risk/progress judgment from the update;
- `not updated`: the member has not provided today's required update.

Then include the shortest concrete basis or gap and the delivery risk
(`green`, `yellow`, or `red`) with a reason. Evidence status describes how well
the progress/risk judgment is supported; delivery risk describes the likelihood
that the weekly goal will miss its expected outcome or date. They are related
but not interchangeable: a goal can have complete evidence and red delivery
risk, or incomplete evidence with no confirmed delivery risk.

## Goal progress semantics

`Goal progress` is the estimated completion of the weekly goal as of today, not
the progress of whichever work item was most recently updated. Work-item status
is evidence for the goal estimate. Do not equate one work item's completion with
goal completion unless that work item covers the whole goal.

Estimate against the preserved goal, not a reduced scope. Completing a reduced
subset does not make the original goal 100% complete. A deferral, cancellation,
or retirement decision is not delivery evidence: retain the supported progress
estimate and explain the decision in `Evidence / risk`. If no progress signal
is available, use `unknown` rather than treating retirement as completion.
Distinguish changes to the execution plan from progress toward the original
goal, and do not treat an approved cancellation as an unresolved delivery risk.

Populate `Goal progress` as the agent's PMO estimate from available evidence.
Use an explicit goal-level percentage when it is supported, but do not wait for
a person to provide one. Otherwise estimate against the goal's acceptance
criteria, milestones, and constituent work items, weighting them by scope or
criticality when known rather than blindly averaging item counts. Concrete
signals include completed checklist items, accepted PRs, merged commits,
shipped/deployed artifacts, test or trial results, approved documents, closed
issues, unresolved blockers, and remaining acceptance criteria. Put the short
basis in `Evidence / risk`, for example `partial; 3/5 release gates; yellow -
validation pending`.

Keep percentages per weekly goal rather than averaging unrelated goals. If a
goal has multiple owners, show the owner accountable for the next decision or
action first. When useful, show today's change compactly, for example `60%
(+10pp today)`.

Use conservative ranges when evidence is incomplete: `0-20%` for only setup or
planning, `20-50%` for partial implementation without validation, `50-80%` for
working implementation with incomplete evidence or open blockers, and `80-95%`
for validated work still missing closeout/owner confirmation. Use `100%` only
when completion evidence and closeout criteria are both present. Write `unknown`
only when the available sources give no usable progress signal at all.

Ask people for missing evidence, blockers, next action, or owner confirmation;
do not ask them merely to supply a percentage.

## Mentions and follow-up list

After the table, list exactly who still needs to do what. Mention the member in
the same spelling the user provided, using `@Full Name` when a mention form is known.
Include the reminder count when the same missing update was already requested in
a prior check:

- `@Full Name`: provide missing evidence for `<goal>` by `<date>`; reminder #N.
- `@Full Name`: confirm risk/mitigation for `<goal>` by `<date>`; reminder #N.
- `@Full Name`: unblock dependency with `<team/person>` by `<date>`; reminder #N.

The daily table itself must also use the visible `@Full Name` form for each
owner or member row, and the `teams_mentions` array must contain one object for
every distinct mentioned human. Owner section headings must also be visible
mentions, for example `@Coraline Gao`, not plain `Coraline Gao`. If the same
person appears in multiple rows, mention them once in `teams_mentions` and use
the same visible spelling everywhere.

Do not append a handoff code block, structured handoff payload, or instructions
to copy content into private chat. The follow-up line itself must contain the
owner, goal, missing evidence or decision, due date, and reminder count when
applicable.

Then list no more than three PMO focus items, and omit this section when empty:

- escalations PMO should drive;
- decisions PMO should force this week;
- goals whose risk moved since yesterday;
- members/goals with repeated missing updates.
