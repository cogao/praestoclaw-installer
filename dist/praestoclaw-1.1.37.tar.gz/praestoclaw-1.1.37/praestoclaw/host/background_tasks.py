"""Detached background tasks with proactive result delivery.

A long task delegated via ``spawn(mode=background)`` or started as a workflow
should not block the originating conversation. The
:class:`BackgroundTaskManager` owns both spawned subagents and first-class
workflow sessions:

- starts the run on its own ``asyncio`` task (the spawning turn returns
  immediately, freeing the main session lane and the channel's sync window);
- enforces a hard wall-clock timeout and a concurrency cap;
- when the task finishes (success / failure / timeout / cancellation), delivers
  the outcome proactively back to the originating conversation through the
  message bus (reusing the same ``keep_context=True`` intermediate-emit path the
  scheduler and notify tool use, so it never consumes a synchronous waiter);
- retains a bounded history of finished tasks so the main agent can poll status
  and results via the ``tasks`` tool.
"""

from __future__ import annotations

import asyncio
import json
import re
import time
import uuid
from collections import OrderedDict
from collections.abc import Awaitable, Callable, Coroutine
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

from loguru import logger

from praestoclaw.bus.events import OutboundMessage
from praestoclaw.bus.queue import MessageBus
from praestoclaw.config.schema import ChannelType
from praestoclaw.host.execution_chains import (
    ExecutionChainRunner,
    ExecutionLane,
    detached_chain_context,
)
from praestoclaw.security.praesto_tag_exp import praesto_tag_exp_is_active
from praestoclaw.session.store import SessionNotFoundError
from praestoclaw.utils.helpers import (
    REPLY_QUOTE_SNIPPET_MAX,
    contains_cjk,
    truncate_ellipsis,
)
from praestoclaw.utils.limits import cap_output, positive_int

if TYPE_CHECKING:
    from praestoclaw.session.store import SessionStore

# Runtime spawn callback. Signature: spawn_fn(agent, prompt, *, metadata) -> str
SpawnFn = Callable[..., Awaitable[str]]
CompletionValidator = Callable[[str, str], Awaitable[str]]

TaskState = Literal["running", "completed", "failed", "cancelled", "timeout"]

_TERMINAL_STATES: frozenset[str] = frozenset({"completed", "failed", "cancelled", "timeout"})

# The ``adopt(label=…)`` value that flags a record as an event-loop promoted
# worker (as opposed to a normal ``spawn(mode=background)``). Used to gate the
# fold-back history append and the bare-result delivery format.
_PROMOTED_LABEL = "promoted"


def _effective_task_timeout(metadata: dict[str, Any] | None, global_timeout: float) -> float:
    """Task 9: a workflow recipe's ``max_runtime`` can only SHORTEN the run's
    wall-clock timeout, never exceed the manager's global cap. Returns the global
    timeout unchanged for non-workflow tasks / invalid values (gate stays inert).
    """
    if not metadata:
        return global_timeout
    n = positive_int(metadata.get("workflow_max_runtime"))
    # Compare int-vs-float via min() BEFORE float() — an absurdly large YAML
    # integer would OverflowError on float(n), and it's ≥ the global cap anyway.
    return float(min(n, global_timeout)) if n is not None else global_timeout


# Match the snippet AND optional ``task=<id>`` marker inside a fold-back row's
# ``[回复：「…」]`` (zh) or ``[Re: "…"]`` (en) attribution. Anchored at start
# because both completion (``[回复…`` / ``[Re…``) and non-completion
# (``(已取消) [回复…``) paths put the attribution at — or very near — the
# start of the row. We allow a short non-bracket prefix to absorb the optional
# ``(已取消) `` / ``(cancelled) `` / ``(超时) `` / ``(失败：…) `` tag.
# ``re.DOTALL`` on the snippet capture so multi-line user questions (URLs
# after newlines, pasted blocks, …) match the full snippet — the ack row's
# ``[Q] …`` captures everything up to the row's end via the same DOTALL trick,
# so the two sides agree on the full text.
#
# The ``task=<id>`` marker is the load-bearing part for the reaper's idempotency
# check: snippet-only matching gets fooled by repeat questions ("today's
# weather?" twice in a row) and by 80-char truncation collisions, both of which
# would let an orphan ack be silently dropped because some *other* foldback
# happened to share the same snippet. The marker is appended to the attribution
# (not separately to content) so the legacy `^[^\[]{0,40}\[回复…` / `^[^\[]…\[Re:`
# anchor still wraps the whole closure-token in one match. Older rows that pre-
# date the marker still match (the `(?: · task=…)?` group is optional) and fall
# back to snippet matching — so an existing session's ack→foldback pairing is
# preserved across the upgrade.
_FOLDBACK_ZH_RE = re.compile(r"^[^\[]{0,80}\[回复：「(.*?)」(?: · task=([0-9a-f]+))?\]", re.DOTALL)
_FOLDBACK_EN_RE = re.compile(r'^[^\[]{0,80}\[Re: "(.*?)"(?: · task=([0-9a-f]+))?\]', re.DOTALL)
# Lost-on-restart phrasing emitted by ``_compose_lost_on_restart_content``.
# Reaper uses these in addition to the ``[Re: …]`` / ``[回复:「…」]`` patterns
# when matching ack→foldback closures, so a session whose orphan was already
# reaped on a previous startup is not re-reaped on the next one. Same
# task-marker scheme: appended at the end of the row, optional for back-compat.
_LOST_RESTART_ZH_RE = re.compile(
    r"^⚠️ 「(.*?)」这条任务在重启时丢失了.*?(?:\(task=([0-9a-f]+)\))?$", re.DOTALL
)
_LOST_RESTART_EN_RE = re.compile(
    r'^⚠️ "(.*?)" was lost when the service restarted.*?(?:\(task=([0-9a-f]+)\))?$',
    re.DOTALL,
)


def _extract_foldback_marker(content: str) -> tuple[str, str | None] | None:
    """Return ``(snippet, task_id_or_None)`` for a fold-back / lost-on-restart row.

    Returns ``None`` when *content* is not a recognized closure row. The
    ``task_id`` is ``None`` for legacy rows written before the task marker
    was added — the reaper falls back to snippet-only matching for those,
    which preserves pre-upgrade idempotency.

    Recognises four forms (regular fold-back zh/en + lost-on-restart zh/en),
    matching whichever pattern fires first. Inputs that fail every pattern
    return ``None``.
    """
    if not isinstance(content, str):
        return None
    for pattern in (
        _FOLDBACK_ZH_RE,
        _FOLDBACK_EN_RE,
        _LOST_RESTART_ZH_RE,
        _LOST_RESTART_EN_RE,
    ):
        m = pattern.match(content)
        if m is not None:
            snippet = m.group(1)
            task_id = m.group(2) if m.lastindex and m.lastindex >= 2 else None
            return snippet, task_id
    return None


def _extract_foldback_snippet(content: str) -> str | None:
    """Back-compat wrapper around :func:`_extract_foldback_marker`.

    Returns just the snippet (or ``None``). Retained for callers that do
    not need the task-id discrimination — but the reaper itself uses the
    full marker form so that snippet-collisions cannot mask orphans.
    """
    parsed = _extract_foldback_marker(content)
    return parsed[0] if parsed is not None else None


@dataclass(slots=True)
class BackgroundOrigin:
    """Where a detached task's result should be delivered.

    ``push_target`` is captured only when the caller supplies an explicit valid
    cloud target. This is required for scheduler channel IDs, which carry no
    Teams route for the cloud channel to rediscover later.

    ``teams_conversation_id`` IS captured (the originating Teams
    ``conversation.Id``) because a background delivery can outlive the
    in-memory Teams route table: the parent turn's promotion fold-back calls
    ``forget_teams_route`` when it completes, so a spawned task that finishes
    later would otherwise lose its Teams route and fall back to webchat
    (issue #473). Freezing the cid here makes the delivery self-contained —
    ``_deliver`` forwards it so the result lands in the originating chat.
    """

    channel: ChannelType
    channel_id: str
    thread_id: str | None = None
    route_hint: str | None = None
    teams_conversation_id: str | None = None
    push_target: str | None = None


INSTANCE_LIMIT_PREFIX = "Workflow instance already running:"


def _meta_label(value: Any) -> str | None:
    """Single-line, whitespace-trimmed, 200-char-capped view of a metadata string.

    Keeps a stray newline in caller-supplied metadata from garbling the
    ``workflow status`` view.
    """
    return str(value or "").strip().split("\n", 1)[0].strip()[:200] or None


def _sanitize_teams_mentions(value: Any) -> list[dict[str, str]]:
    """Copy only bounded mention selectors into the durable task record."""
    if not isinstance(value, list):
        return []
    result: list[dict[str, str]] = []
    seen: set[tuple[str, str, str, str]] = set()
    for raw in value[:500]:
        if not isinstance(raw, dict):
            continue
        mention_type = str(raw.get("type") or "user").strip().casefold()
        if mention_type not in {"user", "all", "tag"}:
            continue
        item = {
            "name": str(raw.get("name") or "").strip()[:1000],
            "upn": str(raw.get("upn") or "").strip()[:1000],
            "id": str(raw.get("id") or "").strip()[:1000],
            "type": mention_type,
        }
        if mention_type == "user" and not any(item[key] for key in ("name", "upn", "id")):
            continue
        if mention_type == "tag" and not (item["name"] and item["id"]):
            continue
        key = (item["type"], item["id"].casefold(), item["upn"].casefold(), item["name"].casefold())
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result


def is_instance_limit_message(message: str) -> bool:
    """True when ``start()`` declined because a workflow instance limit was hit.

    This is a neutral outcome, not a failure: the caller should surface the
    message as-is instead of wrapping it in "could not start". Callers must
    treat every *other* non-start message as an error, so a future failure mode
    can't be mistaken for a benign one.
    """
    return message.startswith(INSTANCE_LIMIT_PREFIX)


def origin_from_kwargs(kwargs: dict[str, Any]) -> BackgroundOrigin | None:
    """Build a delivery origin from registry-injected conversation context.

    Shared by SpawnTool and WorkflowTool (single source of truth). ``push_target``
    is captured only for explicit Teams delivery from a scheduled cloud run;
    interactive routes are re-classified from ``channel_id`` at send time.
    """
    channel = kwargs.get("_channel")
    channel_id = kwargs.get("_channel_id")
    if not isinstance(channel, ChannelType) or not channel_id:
        return None
    raw_metadata = kwargs.get("_metadata")
    metadata = raw_metadata if isinstance(raw_metadata, dict) else {}
    thread_id = kwargs.get("_thread_id")
    route_hint = metadata.get("route_hint")
    source = str(metadata.get("source") or "").strip().casefold()
    push_target = str(metadata.get("push_target") or "").strip().casefold()
    return BackgroundOrigin(
        channel=channel,
        channel_id=str(channel_id),
        thread_id=str(thread_id) if thread_id is not None else None,
        route_hint=str(route_hint) if route_hint is not None else None,
        teams_conversation_id=str(metadata.get("cid") or "").strip() or None,
        push_target=(
            push_target
            if channel == ChannelType.CLOUD
            and source in {"cron", "heartbeat"}
            and push_target == "teams"
            else None
        ),
    )


@dataclass(slots=True)
class BackgroundTask:
    """Tracking record for one detached background run."""

    task_id: str
    agent: str
    origin: BackgroundOrigin
    # Owner = the originating conversation's session key. Used to scope
    # status/result/cancel/list so one conversation cannot read or disturb
    # another conversation's background tasks. ``None`` = unowned (internal / legacy)
    # and is visible to any caller for back-compat.
    owner: str | None = None
    state: TaskState = "running"
    started_at: float = field(default_factory=time.monotonic)
    finished_at: float | None = None
    result: str | None = None
    error: str | None = None
    task: asyncio.Task[str] | None = field(default=None, repr=False)
    # The user-visible question that kicked this task off. Used by the
    # fold-back step to attribute the proactive answer (e.g.
    # ``[Re: "<question>"]``). Empty string when unknown (legacy spawn paths).
    question: str = ""
    # Recipe name when this task is a workflow run (from metadata["workflow"]),
    # else None — lets the status view label/filter workflow runs vs plain spawns.
    workflow: str | None = None
    # Opaque grouping key for per-workflow instance limits; None keeps the gate inert.
    workflow_instance_key: str | None = None
    # Stable workflow Plan owner from trusted runtime metadata. This may differ
    # from ``owner`` for older local sessions whose conversation UUID changes on
    # process restart. It scopes workflow status only; task control stays tied
    # to the concrete session in ``owner``.
    workflow_owner: str | None = None
    # Effective wall-clock timeout for THIS task (seconds). A workflow recipe's
    # limits.max_runtime can shorten it below the manager's global cap (Task 9);
    # None → the manager's global _task_timeout_seconds. Kept so the timeout
    # message reports the actual bound, not the global one.
    timeout_seconds: float | None = None
    # Resolved param values for a workflow run (from metadata["workflow_params"]),
    # else None. Kept so a timeout/failure notification can offer an accurate
    # one-click resume / re-run command (``resume workflow <name> bug_id=…``):
    # the substituted prompt that carried them is discarded, so the record is the
    # only place the params survive to the terminal-delivery step.
    workflow_params: dict[str, Any] | None = None
    # Structured Teams mention selectors frozen at task creation.  Meeting
    # automation uses this because terminal result text is not authoritative:
    # the model may say "Wenkai" without emitting a literal @ placeholder.
    teams_mentions: list[dict[str, str]] = field(default_factory=list)
    # Tag-mode group assistants should speak as the shared assistant, without
    # exposing the host's detached-task implementation in the final message.
    praesto_tag_exp: bool = False
    terminal_content: Callable[[BackgroundTask], str] | None = field(default=None, repr=False)
    delivery_callback: Callable[[BackgroundTask, bool], None] | None = field(
        default=None, repr=False
    )

    @property
    def elapsed_seconds(self) -> float:
        end = self.finished_at if self.finished_at is not None else time.monotonic()
        return max(0.0, end - self.started_at)


@dataclass(frozen=True, slots=True)
class BackgroundTaskSnapshot:
    """Lightweight view of one active background task, scoped by owner.

    Returned from :meth:`BackgroundTaskManager.list_for_owner` to feed the
    event-loop status fast-path: it lets ``_publish_status_ack`` cite how
    many workers are still running for the user without exposing the raw
    :class:`BackgroundTask` (which carries ``asyncio.Task`` handles and
    ``error`` strings that should never appear in user-facing copy). The
    ``label`` mirrors :attr:`BackgroundTask.agent`, kept under a more
    snapshot-natural name because adopted promotion tasks use ``"promoted"``
    rather than a real agent name.
    """

    task_id: str
    label: str
    question: str
    started_at: float
    elapsed_s: float


def _plan_progress(plan: Any) -> tuple[int, int, str, str]:
    """``(done, total, current_title, current_note)`` for a run's Plan.

    ``done`` counts terminally-finished items (``done``/``skipped``); the
    *current* step is the first unfinished item — preferring a ``blocked`` one —
    i.e. the step the run stopped on. Used to say "stopped at step i/n (<title>)"
    and to anchor a failure diagnosis with the step's note. Returns
    ``(0, 0, "", "")`` for a missing/empty plan.
    """
    items = list(getattr(plan, "items", None) or [])
    if not items:
        return 0, 0, "", ""
    finished = {"done", "skipped"}
    done = sum(1 for it in items if str(getattr(it, "status", "")) in finished)
    blocked = next((it for it in items if str(getattr(it, "status", "")) == "blocked"), None)
    current = blocked or next(
        (it for it in items if str(getattr(it, "status", "")) not in finished), None
    )
    title = str(getattr(current, "title", "") or "") if current is not None else ""
    note = str(getattr(current, "note", "") or "") if current is not None else ""
    return done, len(items), title, note


def _workflow_command(verb: str, name: str, params: dict[str, Any] | None) -> str:
    """Build a copy-paste ``<verb> workflow <name> k=v …`` command.

    Sanitizes every interpolated part so the result is a safe single-line command
    (it also backs a hidden Teams ``imBack`` payload): the NAME is JSON-quoted if
    it isn't a clean single token (legacy workflow names may contain whitespace);
    a param whose KEY is empty or contains whitespace/``=`` is dropped; and a
    VALUE that is ``None``/empty or contains whitespace/newlines is dropped. So an
    unset optional param (e.g. ``repo_path``) is omitted rather than emitted as
    ``repo_path=``, and no part can smuggle extra tokens/lines into the command.
    """
    # Quote the name unless it's already a clean single token, so a legacy name
    # with whitespace/'='/newlines stays one auditable token (json.dumps escapes
    # newlines) rather than injecting into the command / hidden imBack.
    safe_name = (
        name
        if name and "=" not in name and not any(ch.isspace() for ch in name)
        else json.dumps(name)
    )
    parts = [f"{verb} workflow {safe_name}"]
    for key, value in (params or {}).items():
        skey = str(key)
        # Defense in depth: a key with whitespace or '=' could inject extra tokens
        # into the space-delimited command / hidden imBack (keys are also validated
        # against the param-name rule before they are ever stored).
        if not skey or "=" in skey or any(ch.isspace() for ch in skey):
            continue
        if value is None:
            continue
        sval = str(value).strip()
        # Only single-token values survive into the space-delimited command. A
        # value with internal whitespace/newlines can't round-trip `k=v` and could
        # smuggle extra tokens/lines into the hidden imBack payload — drop it (the
        # user re-supplies it on resume).
        if not sval or any(ch.isspace() for ch in sval):
            continue
        parts.append(f"{skey}={sval}")
    return " ".join(parts)


class BackgroundTaskManager:
    """Owns detached tasks and their proactive delivery."""

    def __init__(
        self,
        bus: MessageBus,
        spawn_fn: SpawnFn,
        *,
        workflow_fn: SpawnFn | None = None,
        delivery_enabled: bool = True,
        max_tasks: int = 16,
        result_retention: int = 50,
        task_timeout_seconds: float = 1800,
        session_store: SessionStore | None = None,
        execution_runner: ExecutionChainRunner | None = None,
        run_recorder: Callable[[BackgroundTask], None] | None = None,
        plans_fn: Callable[[], list[Any]] | None = None,
        plan_store: Any | None = None,
    ) -> None:
        self._bus = bus
        self._spawn_fn = spawn_fn
        self._workflow_fn = workflow_fn
        self._delivery_enabled = delivery_enabled
        self._max_tasks = max_tasks
        self._result_retention = result_retention
        self._task_timeout_seconds = task_timeout_seconds
        # Optional durable-record hook (6d-2): called with the finished record
        # of a *workflow* run (``record.workflow`` set) so on-demand workflow
        # runs get a restart-surviving history like scheduled ones. Best-effort;
        # unset for non-workflow / internal / test setups. NOTE: invoked on a
        # thread-pool thread (via ``run_in_executor``), NOT the event loop — the
        # callback must be thread-safe and must not touch event-loop-only state.
        self._run_recorder = run_recorder
        # Optional active-Plan lister (``get_plan_store().list_active``) so a
        # workflow run's terminal notification can report step progress
        # (第 i/n 步) and decide resumability by correlating the finished task to
        # its orphan plan (``plan.origin_task == task_id``). None → the
        # notification degrades to a name-only message (never a false resume
        # offer). Called via a thread executor in ``_deliver`` (disk I/O).
        self._plans_fn = plans_fn
        # Store used to persist a terminally-reconciled plan (#718). Must be the
        # same store ``plans_fn`` reads from, or the reconciled item is written
        # somewhere the next load will never see. Defaults to the process plan
        # store — which is exactly what ``runtime.py`` derives ``plans_fn`` from
        # — and is injectable so a test can point both at a tmp dir instead of
        # writing into the real data dir.
        self._plan_store = plan_store
        # ``session_store`` + ``execution_runner`` are optional: legacy ``spawn``
        # bg tasks don't need a fold-back, and internal/test setups may skip them.
        # When either is missing the fold-back step is a no-op (logged at
        # ``_fold_back_append``), but channel delivery still happens. Promotion
        # call sites (``AgentLoopV2._promote_turn_to_worker``) MUST wire both,
        # which the runtime does at construction.
        self._session_store = session_store
        self._execution_runner = execution_runner
        self._active: dict[str, BackgroundTask] = {}
        self._terminal: OrderedDict[str, BackgroundTask] = OrderedDict()
        # Lightweight lifecycle observers for durable feature-specific state
        # (for example, meeting task-group instances). Observers run
        # synchronously on the event-loop thread and therefore must stay fast.
        self._terminal_observers: list[Callable[[BackgroundTask], None]] = []
        self._deliveries: set[asyncio.Task[None]] = set()
        self._foldbacks: set[asyncio.Task[None]] = set()
        self._closed = False

    @property
    def pending_count(self) -> int:
        return len(self._active)

    def add_terminal_observer(self, observer: Callable[[BackgroundTask], None]) -> None:
        """Notify *observer* whenever a detached task reaches a terminal state."""
        if observer not in self._terminal_observers:
            self._terminal_observers.append(observer)

    # ── Lifecycle ────────────────────────────────────────────────────────

    async def start(
        self,
        agent: str,
        prompt: str,
        *,
        origin: BackgroundOrigin,
        metadata: dict[str, Any] | None = None,
        parent_session: str | None = None,
        completion_validator: CompletionValidator | None = None,
    ) -> tuple[str | None, str]:
        """Start a detached task.

        ``parent_session`` is the originating conversation's session id; it is
        forwarded to ordinary spawned sub-agents for parent linkage and retained
        as the delivery/status owner for workflow sessions. Returns
        ``(task_id, message)``. ``task_id`` is ``None`` when the task could not
        be started (manager closed, capacity reached, or workflow instance limit
        reached); ``message`` is always the human-readable string surfaced to the user.

        An optional completion validator receives the task id and untruncated
        result within the task's timeout. It returns an empty string to accept
        completion or a refusal reason to fail before recording or delivering it.
        """
        if self._closed:
            return None, "Error: agent is shutting down; cannot start a background task now."

        meta = metadata or {}
        # Normalize the workflow label (strip + first line, capped) so a stray
        # newline/whitespace in metadata can't garble the ``workflow status`` view.
        _wf_label = _meta_label(meta.get("workflow"))
        # Capped like the label: the key embeds caller-supplied parameter values,
        # and it only ever needs to be compared, never displayed in full.
        _instance_key = str(meta.get("workflow_instance_key") or "")[:2000] or None
        max_instances = positive_int(meta.get("workflow_max_instances"))
        # Checked BEFORE the global capacity gate on purpose: a duplicate instance
        # is never going to start regardless of capacity, so "one is already
        # running (here's its task_id)" is strictly more actionable than "too many
        # background tasks". Check → _register_task below stays await-free, which
        # is what makes this gate atomic against concurrent starts.
        if _wf_label and _instance_key and max_instances is not None:
            active_ids = [
                record.task_id
                for record in self._active.values()
                if record.workflow == _wf_label and record.workflow_instance_key == _instance_key
            ]
            if len(active_ids) >= max_instances:
                return None, (
                    f"{INSTANCE_LIMIT_PREFIX} {_wf_label!r} is at its limit "
                    f"({len(active_ids)}/{max_instances}); active task_id(s): "
                    f"{', '.join(active_ids)}."
                )

        if len(self._active) >= self._max_tasks:
            return None, (
                f"Error: too many background tasks running ({len(self._active)}/"
                f"{self._max_tasks}). Wait for one to finish or cancel it first."
            )

        task_metadata = dict(meta)
        task_id = uuid.uuid4().hex[:12]
        _wf_owner = _meta_label(meta.get("workflow_owner"))
        record = BackgroundTask(
            task_id=task_id,
            agent=agent,
            origin=origin,
            owner=parent_session,
            workflow=_wf_label,
            workflow_instance_key=_instance_key if _wf_label else None,
            workflow_owner=_wf_owner if _wf_label else None,
            teams_mentions=_sanitize_teams_mentions(meta.get("teams_mentions")),
            praesto_tag_exp=praesto_tag_exp_is_active(meta),
        )

        # Workflows run as independent, top-level sessions gated on the MAIN execution
        # lane; ordinary spawn tasks retain SUBAGENT semantics. NOTE: ExecutionChainRunner's
        # lane semaphores are GLOBAL per-lane (not per-session), so a workflow run holds
        # one MAIN slot (main_max_concurrent, default 10) for its whole duration, SHARED
        # with the user's foreground conversation turns — it is not lane-isolated from the
        # originating chat. Bounded and acceptable at current scale (workflows are
        # occasional, and one run leaves 9 MAIN slots for the foreground); if many long
        # workflows ever need to run without contending with foreground turns, give them a
        # dedicated lane instead of reusing MAIN.
        task_metadata["execution_lane"] = "main" if record.workflow else "subagent"
        task_metadata["background_task_id"] = task_id
        # Trusted out-of-band routing context for tools that must interact with
        # the originating user while this detached task is still running (most
        # notably plan(checkpoint, ask_user=true)). Overwrite any caller value:
        # the origin was built from registry-injected channel provenance.
        task_metadata["_background_origin"] = {
            "channel": origin.channel.value,
            "channel_id": origin.channel_id,
            "thread_id": origin.thread_id,
        }

        # Task 9 capability caps: a workflow recipe's max_runtime shortens THIS
        # task's wall-clock timeout (never exceeds the global cap), and max_output
        # truncates the delivered result. Inert for plain spawns (keys absent).
        effective_timeout = _effective_task_timeout(task_metadata, self._task_timeout_seconds)
        max_output = positive_int(task_metadata.get("workflow_max_output"))
        # Only record a per-task timeout when a recipe actually SHORTENED it — leave
        # None (→ the global cap) otherwise, so the field stays semantic ("None =
        # default") for every non-workflow task.
        record.timeout_seconds = (
            effective_timeout if effective_timeout != self._task_timeout_seconds else None
        )
        # Stash resolved workflow params on the record so a terminal notification
        # can emit an accurate resume / re-run command. Only for workflow runs, so
        # a plain spawn task that happens to carry a workflow_params key is
        # untouched. The key is deliberately LEFT IN ``task_metadata`` (it used to
        # be popped): the run's own plan(create) persists it onto the Plan, which
        # is what lets `workflow resume` restore the params after the process that
        # holds this record is gone.
        if record.workflow:
            _wf_params = task_metadata.get("workflow_params")
            if isinstance(_wf_params, dict) and _wf_params:
                record.workflow_params = dict(_wf_params)

        async def _run() -> str:
            spawn_kwargs: dict[str, Any] = {"metadata": task_metadata}
            if parent_session is not None:
                spawn_kwargs["_parent_session"] = parent_session
            runner = self._workflow_fn if record.workflow and self._workflow_fn else self._spawn_fn
            async with asyncio.timeout(effective_timeout):
                result = await runner(agent, prompt, **spawn_kwargs)
                if completion_validator is not None:
                    refusal = await completion_validator(task_id, result)
                    if not isinstance(refusal, str):
                        raise TypeError("Completion validator must return a string.")
                    if refusal:
                        raise ValueError(f"Completion validation failed: {refusal}")
            return cap_output(result, max_output)

        # Run in a context with the spawning turn's chain-reentry vars reset, so
        # the detached run is scheduled as an independent session rather than a
        # reentry of the turn that called spawn().
        self._register_task(record, _run(), task_name=f"bg-task-{task_id}")

        logger.info("Background task started: id={} agent={}", task_id, agent)
        message = (
            f"Background task started (id={task_id}, agent={agent}). "
            "It runs independently — keep chatting normally. I'll send the result "
            f"to this conversation when it's done; ask me to check task {task_id} anytime."
        )
        return task_id, message

    def adopt(
        self,
        coro_factory: Callable[[], Awaitable[str]],
        *,
        origin: BackgroundOrigin,
        owner: str | None,
        question: str,
        label: str = "promoted",
        terminal_content: Callable[[BackgroundTask], str] | None = None,
        delivery_callback: Callable[[BackgroundTask, bool], None] | None = None,
    ) -> str | None:
        """Adopt an already-built continuation into the background lifecycle.

        Unlike :meth:`start`, which *launches* a sub-agent through ``spawn_fn``,
        ``adopt`` takes a pre-built coroutine factory (e.g. the worker's
        ``_drive_turn(state)`` re-entry) and wraps it in the same hard timeout,
        concurrency cap, done callback, and proactive delivery machinery.

        Returns the new ``task_id``, or ``None`` if the manager is closed or
        the worker cap is full. The caller MUST handle ``None`` by degrading
        inline (the cap pre-check here is intentionally cheap and side-effect
        free so a refused adoption does not corrupt the main session).
        """
        if self._closed or len(self._active) >= self._max_tasks:
            return None

        task_id = uuid.uuid4().hex[:12]
        record = BackgroundTask(task_id=task_id, agent=label, origin=origin, owner=owner)
        record.question = question
        record.terminal_content = terminal_content
        record.delivery_callback = delivery_callback

        async def _run() -> str:
            return await asyncio.wait_for(coro_factory(), timeout=self._task_timeout_seconds)

        self._register_task(record, _run(), task_name=f"worker-{task_id}")

        logger.info("Background task adopted: id={} label={}", task_id, label)
        return task_id

    def _register_task(
        self, record: BackgroundTask, coro: Coroutine[Any, Any, str], *, task_name: str
    ) -> None:
        """Schedule *coro* on its own detached asyncio task and track *record*.

        Shared tail of :meth:`start` and :meth:`adopt`: both create a detached
        task (chain-reentry vars reset), strong-ref it on the record, register
        the record in ``_active``, and wire the terminal-state callback. The
        only thing that differs between the two entry points is how ``coro`` is
        built — so everything past that point lives here.
        """
        task_id = record.task_id
        task = asyncio.create_task(coro, name=task_name, context=detached_chain_context())
        record.task = task
        self._active[task_id] = record

        def _on_done(t: asyncio.Task[str], tid: str = task_id) -> None:
            self._on_task_done(tid, t)

        task.add_done_callback(_on_done)

    def _on_task_done(self, task_id: str, task: asyncio.Task[str]) -> None:
        record = self._active.pop(task_id, None)
        if record is None:
            return
        record.finished_at = time.monotonic()

        if task.cancelled():
            record.state = "cancelled"
            record.error = "Task was cancelled."
        else:
            exc = task.exception()
            if exc is None:
                record.state = "completed"
                record.result = task.result()
            elif isinstance(exc, TimeoutError):
                record.state = "timeout"
                _to = (
                    record.timeout_seconds
                    if record.timeout_seconds is not None
                    else self._task_timeout_seconds
                )
                record.error = f"Task timed out after {_to:g}s."
                logger.warning("Background task {} timed out", record.task_id)
                # Promoted workers also emit the canonical event_loop.timeout
                # line so the §5.2 grep recipes find the hard-timeout case
                # without having to parse the generic "timed out" string.
                # Non-promoted spawn() background tasks keep only the legacy
                # warning above so the §5.2 log surface stays event-loop-only.
                if record.agent == _PROMOTED_LABEL:
                    logger.warning(
                        "event_loop.timeout task_id={} elapsed_s={:.2f}",
                        record.task_id,
                        record.elapsed_seconds,
                    )
            else:
                record.state = "failed"
                record.error = f"{type(exc).__name__}: {exc}"
                logger.error("Background task {} failed: {}", record.task_id, exc)

        self._remember_terminal(record)

        for observer in tuple(self._terminal_observers):
            try:
                observer(record)
            except Exception as exc:  # noqa: BLE001 - lifecycle observers are best-effort
                logger.debug("Background terminal observer failed for {}: {}", record.task_id, exc)

        # Durable run record (6d-2): a workflow run gets a restart-surviving
        # history entry. The recorder does filesystem I/O, so run it OFF the
        # event-loop thread (a thread executor) — a slow disk must not delay the
        # delivery / fold-back below. Best-effort: fire-and-forget; the recorder
        # itself is internally guarded. Falls back to inline if there is no
        # running loop (e.g. a direct unit-test call).
        if record.workflow and self._run_recorder is not None:
            recorder = self._run_recorder

            def _safe_record() -> None:
                try:
                    recorder(record)
                except Exception as exc:  # noqa: BLE001 - audit is best-effort
                    logger.debug("Workflow run recorder failed for {}: {}", record.task_id, exc)

            try:
                # Wrap the recorder so an exception raised inside the executor
                # thread is logged, not left on an unobserved future.
                asyncio.get_running_loop().run_in_executor(None, _safe_record)
            except RuntimeError:
                _safe_record()  # no running loop (e.g. a direct unit-test call)

        # Emit the canonical terminal-state line for promoted (event-loop)
        # workers. §5.2 requires task_id / state / elapsed_s / result_len so a
        # single conversation's full chain — ``event_loop.promote → adopt →
        # worker_done → foldback`` — can be reconstructed by grepping a single
        # task id. ``result_len`` is the assistant text length (or 0 on
        # non-completion) so an operator can spot empty / truncated outputs.
        # Non-promoted ``spawn(mode=background)`` records are intentionally
        # not logged here: the §5.2 surface is event-loop-only, and the
        # legacy delivery path already emits per-task lifecycle lines.
        if record.agent == _PROMOTED_LABEL:
            result_len = len(record.result or "") if record.state == "completed" else 0
            logger.info(
                "event_loop.worker_done task_id={} state={} elapsed_s={:.2f} result_len={}",
                record.task_id,
                record.state,
                record.elapsed_seconds,
                result_len,
            )

        # Don't spam the user with cancellations triggered by shutdown.
        if self._delivery_enabled and not (self._closed and record.state == "cancelled"):
            delivery = asyncio.create_task(
                self._deliver(record), name=f"bg-deliver-{record.task_id}"
            )
            self._deliveries.add(delivery)
            delivery.add_done_callback(self._deliveries.discard)

        # Fold-back is event-loop-only: promoted workers (adopt(label="promoted"))
        # must also append a self-describing assistant row to the OWNER main
        # session via the per-session serial queue, so the next main turn reads
        # the answer in its assembled history (docs §2.5 / D-attribution). Bare
        # ``spawn(mode=background)`` tasks keep the legacy delivery-only path.
        if self._should_fold_back(record):
            foldback = asyncio.create_task(
                self._fold_back(record), name=f"bg-foldback-{record.task_id}"
            )
            self._foldbacks.add(foldback)
            foldback.add_done_callback(self._foldbacks.discard)

    def _remember_terminal(self, record: BackgroundTask) -> None:
        self._terminal[record.task_id] = record
        while len(self._terminal) > self._result_retention:
            self._terminal.popitem(last=False)

    async def _deliver(self, record: BackgroundTask) -> None:
        origin = record.origin
        promoted = record.agent == _PROMOTED_LABEL
        if record.terminal_content is not None:
            content = record.terminal_content(record)
        elif promoted:
            # Promoted (event-loop) workers: deliver the bare final text so the
            # cloud channel's ``_teams_timeout_quote`` → ``_prefix_reply_quote``
            # path produces the user-visible ``↩️ Re your earlier question
            # "…":`` envelope without a redundant "📋 Background task done"
            # header. For non-completion states surface a localized terse
            # note (so the channel ↩️ quote still attributes the message and
            # the durable fold-back row matches char-for-char).
            content = self._compose_promoted_delivery(record)
        else:
            # Workflow runs get an enriched terminal notification: a card-first
            # resume offer on timeout, a mechanical diagnosis on failure. Falls
            # through to the generic text below for completed / non-workflow.
            enriched: str | None = None
            if record.workflow and record.state in ("timeout", "failed"):
                plan = None
                # Only hop to the thread pool when a plan lister is actually wired.
                if self._plans_fn is not None:
                    loop = asyncio.get_running_loop()
                    plan = await loop.run_in_executor(None, self._find_workflow_plan, record)
                # Only a real Teams conversation renders an adaptive card; the
                # cloud channel also serves webchat (no card support), which would
                # show raw card JSON. Gate the card on the captured Teams cid.
                teams = bool((record.origin.teams_conversation_id or "").strip())
                enriched = self._compose_workflow_terminal(record, plan=plan, teams=teams)
            if enriched is not None:
                content = enriched
            elif record.state == "completed":
                result = record.result or "(no output)"
                content = (
                    result
                    if record.praesto_tag_exp
                    else f"📋 Background task done (id={record.task_id}):\n\n{result}"
                )
                # Terminal reconciliation (#718): when the agent finished
                # without explicitly marking the last plan item ``done``,
                # the progress card stays stuck at N-1/N.  Reconcile the
                # plan and emit a final 100% card so Teams reflects the
                # true completed state.
                if record.workflow:
                    await self._reconcile_plan_terminal(record)
            else:
                content = (
                    f"⚠️ Background task {record.task_id} {record.state}: "
                    f"{record.error or 'unknown error'}"
                )

        metadata: dict[str, Any] = {
            # Intermediate side-emit: must NOT consume a pending sync waiter on
            # the carrier channel, and lets the cloud channel promote a
            # remembered Teams/webchat route to the proactive /api/notify path.
            "keep_context": True,
            "notify_category": "background_task",
            "background_task_id": record.task_id,
        }
        if promoted:
            # Promoted workers' delivery IS the user-visible final reply for
            # that turn (even though it's "intermediate" relative to the
            # already-consumed sync carrier slot). The cloud channel's
            # ↩️ quote-prefix path is gated on ``not is_intermediate`` to
            # protect normal mid-turn cards / status pings, so we opt this
            # one emission back in via an explicit flag. Without it the
            # late notify went out as the raw worker answer (prod
            # 2026-06-14 line 14382), losing the question attribution
            # the whole event-loop design depends on.
            metadata["promoted_final"] = True

        # Self-contained Teams routing: when the originating conversation id was
        # captured at task-creation time, force the delivery back to that Teams
        # chat regardless of whether the in-memory route table still remembers
        # this channel_id. A spawned background task can finish AFTER the parent
        # turn's promotion fold-back already called ``forget_teams_route`` — so
        # without this the late result falls back to webchat instead of the
        # originating group/DM (issue #473). ``committed_teams_conversation_id``
        # is consumed by ``CloudChannel._send_notify``.
        committed_cid = (origin.teams_conversation_id or "").strip()
        if committed_cid:
            metadata["push_target"] = "teams"
            metadata["committed_teams_conversation_id"] = committed_cid
        elif origin.push_target:
            metadata["push_target"] = origin.push_target
        if record.teams_mentions:
            metadata["teams_mentions"] = record.teams_mentions

        try:
            delivered = await self._bus.publish_outbound(
                OutboundMessage(
                    channel=origin.channel,
                    channel_id=origin.channel_id,
                    content=content,
                    thread_id=origin.thread_id,
                    route_hint=origin.route_hint,
                    metadata=metadata,
                )
            )
        except Exception as exc:  # noqa: BLE001 — delivery must never crash the loop
            logger.error("Background task {} delivery failed: {}", record.task_id, exc)
            delivered = False

        if record.delivery_callback is not None:
            record.delivery_callback(record, bool(delivered))
            return

        if not delivered:
            # The origin is the channel_id captured at spawn. On web that is a
            # one-shot HTTP request queue, dead within seconds of the run
            # starting, so a detached run's result has nowhere to land — and an
            # API client like borgee has no inbound channel to push to at all.
            # Try Teams before falling back to the store: a summary the user can
            # only find by reading the database is a summary they never see.
            delivered = await self._escalate_terminal_to_teams(record, content)

        if not delivered:
            # Nobody was listening. For a workflow run this message is the only
            # thing telling the user the run stopped and how to resume it, and a
            # push has no second chance — observed live: a browser tab closed
            # 25 minutes before the run hit its ceiling, and the timeout notice
            # (with its resume offer) was dropped along with everything else.
            # Persist it so it is there on reload instead of lost.
            await self._persist_terminal_to_owner(record, content)

    async def _escalate_terminal_to_teams(self, record: BackgroundTask, content: str) -> bool:
        """Push a detached run's terminal summary to Teams when its origin is dead.

        A run's origin is the ``channel_id`` captured at spawn. On Teams that is a
        long-lived conversation; on web it is a one-shot HTTP request queue that
        dies when that request returns, seconds into a run that may last half an
        hour. Observed 2026-08-06: a completed workflow's 1749-character summary —
        bug id, PR number, branch, red→green evidence, checks run — reached only
        the session store, which the originating client cannot read.

        Skipped when the run already targets Teams (its own delivery covers it)
        and for promoted workers, whose content is a turn's final reply and
        belongs on the surface that asked, not broadcast to Teams.
        """
        if record.agent == _PROMOTED_LABEL:
            return False
        origin = record.origin
        if (origin.teams_conversation_id or "").strip():
            return False  # already a Teams delivery; a second push would duplicate
        if origin.channel == ChannelType.CLOUD:
            return False  # cloud already routes its own webchat/Teams fallback
        try:
            return await self._bus.publish_outbound(
                OutboundMessage(
                    channel=ChannelType.CLOUD,
                    channel_id=ChannelType.CLOUD.value,
                    content=content,
                    metadata={
                        "keep_context": True,
                        "notify_category": "background_task",
                        "background_task_id": record.task_id,
                        "push_target": "teams",
                    },
                )
            )
        except Exception as exc:  # noqa: BLE001 — escalation must never crash the loop
            logger.warning(
                "background_task.teams_escalation_failed task_id={} err={}",
                record.task_id,
                exc,
            )
            return False

    async def _persist_terminal_to_owner(self, record: BackgroundTask, content: str) -> None:
        """Append an undelivered terminal notice to the owner's conversation.

        Only for workflow runs: they are detached, long-lived, and their terminal
        message carries the resume offer, so losing it strands the user with no
        indication the run ended. A spawn/notify task that nobody saw is noise
        worth dropping.

        Distinct from :meth:`_fold_back` — that is the promoted-worker path with
        its own content format and idempotency marker. This one only writes the
        message the channel could not deliver.

        Best-effort: never let history bookkeeping break task teardown.
        """
        if not record.workflow or not record.owner or self._session_store is None:
            return
        try:
            await self._session_store.add_message(
                record.owner, {"role": "assistant", "content": content}
            )
            logger.info(
                "background_task.terminal_persisted task_id={} owner={} state={} "
                "— channel had no listener",
                record.task_id,
                record.owner,
                record.state,
            )
        except SessionNotFoundError:
            logger.info(
                "background_task.terminal_persist_skipped task_id={} owner={} reason=session_gone",
                record.task_id,
                record.owner,
            )
        except Exception as exc:  # noqa: BLE001 — persistence is best-effort
            logger.debug(
                "background_task.terminal_persist_failed task_id={} error={}",
                record.task_id,
                exc,
            )

    # ── Fold-back (event-loop promoted workers) ──────────────────────────

    def _should_fold_back(self, record: BackgroundTask) -> bool:
        """Whether *record* warrants a fold-back history append.

        Fold-back is only meaningful for event-loop promoted workers, which we
        identify by the ``adopt(label="promoted")`` flag (legacy ``spawn`` bg
        tasks have an agent name, not ``"promoted"``). It also requires an
        owner main session (the destination) and the runtime wiring
        (``session_store`` + ``execution_runner``); when either is missing
        the manager logs and skips silently.
        """
        if record.agent != _PROMOTED_LABEL:
            return False
        if record.owner is None:
            return False
        if self._session_store is None or self._execution_runner is None:
            return False
        # Suppress fold-back on shutdown cancellations: aclose() cancels all
        # pending workers, which would otherwise post a "(cancelled)" row to
        # every conversation right before the runtime tears down (matching the
        # same guard in the delivery path above).
        if self._closed and record.state == "cancelled":
            return False
        return True

    async def _fold_back(self, record: BackgroundTask) -> None:
        """Enqueue the self-describing assistant row on the main session lane.

        The append is submitted as a zero-LLM ``execute=`` callable to
        :meth:`ExecutionChainRunner.run` on the OWNER main session key, so it
        serializes behind any active main turn and its compaction
        (docs §3.3 / D-serialization). ``ExecutionLane.SYSTEM`` keeps the
        op from consuming a user-facing ``MAIN`` slot. The fold-back never
        raises into the bg-task lifecycle: any error is logged and swallowed
        so a fold-back failure cannot leak into another worker's path.
        """
        assert self._execution_runner is not None  # gated by _should_fold_back
        owner = record.owner
        assert owner is not None  # gated by _should_fold_back
        try:
            await self._execution_runner.run(
                session_key=owner,
                turn_id=f"foldback:{record.task_id}",
                lane=ExecutionLane.SYSTEM,
                execute=lambda: self._fold_back_append(record),
            )
        except Exception as exc:  # noqa: BLE001 — fold-back must never crash the loop
            logger.error(
                "event_loop.foldback_failed task_id={} owner={} error={}",
                record.task_id,
                owner,
                exc,
            )

    async def _fold_back_append(
        self,
        record: BackgroundTask,
        *,
        content_override: str | None = None,
    ) -> None:
        """Append one self-describing assistant row to the main session.

        Runs *inside* the main session's serial lane (see :meth:`_fold_back`).
        ``SessionStore.add_message`` atomically rejects a missing session, so a
        concurrent delete cannot turn this write into an orphan row.
        """
        assert self._session_store is not None  # gated by _should_fold_back
        owner = record.owner
        assert owner is not None  # gated by _should_fold_back
        content = (
            content_override
            if content_override is not None
            else self._compose_foldback_content(record)
        )
        try:
            rowid = await self._session_store.add_message(
                owner, {"role": "assistant", "content": content}
            )
        except SessionNotFoundError:
            logger.info(
                "event_loop.foldback_skipped task_id={} owner={} reason=session_gone",
                record.task_id,
                owner,
            )
            return
        except Exception as exc:  # noqa: BLE001 — append must be defensive
            logger.error(
                "event_loop.foldback_append_failed task_id={} owner={} error={}",
                record.task_id,
                owner,
                exc,
            )
            return

        logger.info(
            "event_loop.foldback main={} task_id={} foldback_rowid={} channel_delivered=true",
            owner,
            record.task_id,
            rowid,
        )

    def _compose_foldback_content(self, record: BackgroundTask) -> str:
        """Build the self-describing assistant content for the fold-back row.

        Format (docs §2.5 / §3.2):

        * completed → ``[回复：「<snip>」 · task=<id>]\n\n<final_text>`` (zh) /
          ``[Re: "<snip>" · task=<id>]\n\n<final_text>`` (en)
        * cancelled → ``(已取消) [回复…]`` / ``(cancelled) [Re…]``
        * timeout   → ``(超时) [回复…]`` / ``(timeout) [Re…]``
        * failed    → ``(失败：<short>) [回复…]`` / ``(failed: <short>) [Re…]``

        Language is picked from the original question via CJK detection so the
        row reads natural in the conversation's language even when the answer
        text is mixed-script.

        The ``· task=<id>`` suffix is the reaper's idempotency token; without
        it, an orphan whose ack snippet collides with a *different* completed
        task's snippet (repeat questions, 80-char truncation collisions) would
        be silently skipped on restart and never closed. See
        :func:`_extract_foldback_marker` for the matching side.
        """
        question = record.question or ""
        snippet = self._foldback_snippet(question)
        lang_zh = contains_cjk(question)
        marker = f" · task={record.task_id}" if record.task_id else ""
        if lang_zh:
            attribution = f"[回复：「{snippet}」{marker}]"
        else:
            attribution = f'[Re: "{snippet}"{marker}]'

        if record.state == "completed":
            body = record.result or ""
            return f"{attribution}\n\n{body}".rstrip()

        # Non-completion: short prefix + attribution; never include the full
        # exception trace (which can contain user-private detail). Also bound
        # the length AND strip ``[`` characters so the prefix tag fits inside
        # the ``[^\[]{0,80}`` window the ``_FOLDBACK_*_RE`` patterns reserve
        # for it — without the cleanup, a long error like
        # ``ConnectionResetError: [Errno 104] Connection reset by peer …``
        # would either push the ``[回复:「…`` bracket past the 80-codepoint
        # limit or — even worse — embed a ``[`` inside the prefix that
        # short-circuits the negated character class, in both cases making
        # ``_extract_foldback_marker`` return None and the reaper write a
        # duplicate lost-on-restart on the next daemon startup.
        short_error = (record.error or "").strip().splitlines()[0] if record.error else ""
        # Strip ``[`` / ``]`` so the negated-bracket regex prefix never bails
        # out early on an embedded bracket from e.g. ``[Errno 104]``.
        short_error = short_error.replace("[", "").replace("]", "")
        short_error = truncate_ellipsis(short_error, 28)
        if record.state == "cancelled":
            tag = "(已取消)" if lang_zh else "(cancelled)"
        elif record.state == "timeout":
            tag = "(超时)" if lang_zh else "(timeout)"
        else:  # "failed" (or any future terminal we forgot to enumerate)
            if lang_zh:
                tag = f"(失败：{short_error})" if short_error else "(失败)"
            else:
                tag = f"(failed: {short_error})" if short_error else "(failed)"
        return f"{tag} {attribution}"

    def _compose_lost_on_restart_content(self, record: BackgroundTask) -> str:
        """Build the user-facing row for a task lost across a process restart.

        Distinct from ``_compose_foldback_content`` because the regular
        fold-back attribution (``[回复:「…」]`` / ``[Re: "…"]``) reads as
        "(failed) reply: «…»" — a confusing self-loop. Lost-on-restart is
        not a reply at all; it's a status update telling the user their
        in-flight task did not survive the daemon restart and offering the
        option to retry.

        Format:
            zh: ``⚠️ 「<snippet>」这条任务在重启时丢失了，需要我重新跑吗？(task=<id>)``
            en: ``⚠️ "<snippet>" was lost when the service restarted. Want me to retry? (task=<id>)``

        The trailing ``(task=<id>)`` mirrors the regular fold-back's
        idempotency token (a parenthesised tail rather than the inline
        ``· task=…`` form so the lead sentence keeps its natural cadence).
        Snippet truncation reuses the fold-back limit so the row matches
        the channel ↩️ bubble width. Language is keyed on the question's
        CJK content (same heuristic as the fold-back composer).
        """
        question = record.question or ""
        snippet = self._foldback_snippet(question)
        marker = f" (task={record.task_id})" if record.task_id else ""
        if contains_cjk(question):
            return f"⚠️ 「{snippet}」这条任务在重启时丢失了，需要我重新跑吗？{marker}"
        return f'⚠️ "{snippet}" was lost when the service restarted. Want me to retry?{marker}'

    @staticmethod
    def _foldback_snippet(question: str) -> str:
        """Cap the quoted question at the same width as the channel ↩️ quote.

        Truncation collapses to ``…`` (matching ``_prefix_reply_quote``) so the
        channel-side bubble and the durable fold-back row read identically.
        """
        return truncate_ellipsis((question or "").strip(), REPLY_QUOTE_SNIPPET_MAX)

    def _compose_promoted_delivery(self, record: BackgroundTask) -> str:
        """Build the carrier-bound text for a promoted (adopted) worker.

        The cloud channel will subsequently call ``_prefix_reply_quote`` to
        wrap this with ``↩️ Re your earlier question "…"`` (the request_id was
        stashed at promotion time by ``_stash_promotion_quote``). For other
        channels (web) this text stands on its own. Non-completion
        states surface a short, self-attributed note — same shape as the
        fold-back row so the user-visible bubble and the durable history row
        match.
        """
        if record.state == "completed":
            return record.result or ""
        # Reuse the fold-back composer so the channel ↩️ bubble and the
        # durable assistant row stay byte-identical for non-completion paths.
        return self._compose_foldback_content(record)

    def _find_workflow_plan(self, record: BackgroundTask) -> Any | None:
        """The finished run's orphan Plan (``origin_task == task_id``), or None.

        Correlates by task id — the same key ``make_run_recorder`` uses — so a
        timed-out / failed run's incomplete plan (still in ``list_active``) can
        be read for step progress + resumability. Best-effort: any error (or no
        ``plans_fn`` wired) yields None, degrading the notification to a
        name-only message rather than a false resume offer. Runs on a thread
        executor (disk I/O) — do not touch event-loop-only state here.
        """
        if self._plans_fn is None:
            return None
        try:
            tid = record.task_id
            for plan in self._plans_fn() or []:
                if str(getattr(plan, "origin_task", "") or "") != tid:
                    continue
                # Guard against a false match: when the plan carries workflow/owner
                # (PlanStore persists both), they must agree with the run's before
                # we offer to resume it.
                pwf = str(getattr(plan, "workflow", "") or "")
                if pwf and record.workflow and pwf != record.workflow:
                    continue
                powner = str(getattr(plan, "owner", "") or "")
                if powner and record.owner and powner != record.owner:
                    continue
                return plan
        except Exception as exc:  # noqa: BLE001 - notification enrichment is best-effort
            logger.debug("workflow plan lookup for {} failed: {}", record.task_id, exc)
        return None

    async def _reconcile_plan_terminal(self, record: BackgroundTask) -> None:
        """Auto-complete the sole remaining ``in_progress`` item on successful run end.

        When the agent finished without explicitly marking the last plan item
        ``done`` the progress card stays stuck at N-1/N (<100%).  This helper
        loads the plan, reconciles it, persists the change, and emits a final
        100% progress card to Teams so the user sees the correct state.

        Best-effort: any failure is logged and swallowed — the result delivery
        must never be blocked by a cosmetic card update.
        """
        if self._plans_fn is None:
            return
        try:
            loop = asyncio.get_running_loop()
            plan = await loop.run_in_executor(None, self._find_workflow_plan, record)
            if plan is None:
                return
            if not hasattr(plan, "reconcile_terminal"):
                return
            item = plan.reconcile_terminal()
            if item is None:
                return  # nothing to reconcile — plan was already complete or >1 item pending

            # Persist the reconciled plan.
            from praestoclaw.agent.tools.plan import get_plan_store

            store = self._plan_store or get_plan_store()
            await loop.run_in_executor(None, store.save, plan)
            plan_sid = str(getattr(plan, "session_id", "") or "")
            logger.info(
                "plan.terminal_reconciled task_id={} session={}",
                record.task_id,
                plan_sid or "?",
            )

            # Emit a final progress card so Teams reflects 100%.
            from praestoclaw.agent.tools.plan import build_progress_card

            activity = build_progress_card(plan, action="update", last_item=item)
            if activity is None or self._bus is None:
                return

            origin = record.origin
            committed_cid = (origin.teams_conversation_id or "").strip()
            if not committed_cid:
                return  # not a Teams conversation — no card to push

            card_json = json.dumps(activity, ensure_ascii=False)
            card_metadata: dict[str, Any] = {
                "keep_context": True,
                "push_target": "teams",
                "committed_teams_conversation_id": committed_cid,
            }
            # Pin to the SAME activity every progress tick of this plan used
            # (``PlanTool._push_live_update``), so the bridge's
            # ``(oid, update_key) -> activityId`` map resolves and it calls
            # UpdateActivityAsync. Without it this is a brand-new message and
            # the stale N-1/N card stays on screen right next to the 100% one.
            plan_created_at = str(getattr(plan, "created_at", "") or "")
            if plan_sid and plan_created_at:
                card_metadata["update_key"] = f"plan:{plan_sid}:{plan_created_at}"
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=origin.channel,
                    channel_id=origin.channel_id,
                    content=card_json,
                    thread_id=origin.thread_id,
                    route_hint=origin.route_hint,
                    metadata=card_metadata,
                )
            )
        except Exception as exc:  # noqa: BLE001 — reconciliation is best-effort
            logger.debug("plan terminal reconciliation failed for {}: {}", record.task_id, exc)

    def _compose_workflow_terminal(
        self, record: BackgroundTask, *, plan: Any | None = None, teams: bool = False
    ) -> str | None:
        """Enriched delivery content for a workflow run's terminal state.

        Returns None for anything this method doesn't enrich (non-workflow runs,
        or ``completed`` / ``cancelled`` states) so ``_deliver`` falls back to
        its generic text. For ``timeout`` it offers a resume **card** when
        ``teams`` is set (a real Teams conversation renders adaptive cards),
        else a copy-paste command; for ``failed`` it returns a mechanical
        diagnosis. (Design: mechanical diagnosis + card-first resume.)
        """
        name = record.workflow
        if not name or record.state not in ("timeout", "failed"):
            return None
        from praestoclaw.agent.tools.plan import PlanDisposition, get_plan_disposition

        disposition = get_plan_disposition(plan)
        done, total, step_title, step_note = _plan_progress(plan)
        where = ""
        if total:
            # ``done`` is the count of FINISHED steps (not the current index), so
            # phrase it as completed-progress and name the step it stopped on —
            # "已完成 2/4 步，卡在「Verify」" — rather than a misleading "第 2 步".
            where = f"，已完成 {done}/{total} 步" + (
                f"，卡在「{step_title}」" if step_title else ""
            )

        if record.state == "timeout":
            secs = record.elapsed_seconds
            # Sub-minute bounds (short max_runtime) would render as "约 0 分钟";
            # show seconds under a minute so the duration stays accurate.
            dur = f"约 {secs:.0f} 秒" if secs < 60 else f"约 {secs / 60:.0f} 分钟"
            head = f"⏱️ workflow `{name}` 跑了{dur}后超时{where}。"
            if disposition is PlanDisposition.CALLOUT_TERMINAL:
                return f"📣 workflow `{name}` 已以 terminal Callout 结束{where}；不可续跑。"
            # Resumable only when an orphan plan with unfinished steps was found
            # — never promise a resume we can't back.
            if plan is not None and total > done:
                resume_cmd = _workflow_command("resume", name, record.workflow_params)
                if teams:
                    # Show the exact command in the card body too: the imBack is
                    # otherwise hidden, so surfacing it makes the one-click action
                    # auditable (and unsurprising if a param was sanitized away).
                    text = head + f"点「▶️ 继续跑完」我就从中断处继续跑完（= 发送 `{resume_cmd}`）。"
                    from praestoclaw.channels.teams_cards import (
                        build_action_card,
                        wrap_for_teams,
                    )

                    return json.dumps(
                        wrap_for_teams(build_action_card(text, "▶️ 继续跑完", resume_cmd)),
                        ensure_ascii=False,
                    )
                return head + f"\n从中断处继续跑完 → 回复：`{resume_cmd}`"
            # No resumable checkpoint (recipe made no plan, or all steps done):
            # offer a fresh re-run instead of a resume.
            rerun_cmd = _workflow_command("run", name, record.workflow_params)
            return head + f"\n没有可续跑的检查点，需要从头重跑 → 回复：`{rerun_cmd}`"

        # failed → mechanical diagnosis (no LLM): where + error (+ blocked note).
        diag = (record.error or "unknown error").strip()
        if step_note:
            diag = f"{diag}（{step_note}）"
        return f"⚠️ workflow `{name}` 失败{where}：{diag}"

    async def reap_orphan_acks(
        self,
        session_store: Any,
        *,
        limit: int = 100,
        recent_threshold_s: float = 600.0,
    ) -> int:
        """Replace orphan ``[BG task=…]`` ack rows with lost-on-restart fold-backs.

        Walks recent main sessions (newest first, capped by *limit*) and
        identifies ack rows whose ``task_id`` is not in ``self._active`` and
        which do not already have a fold-back row in the same session. For
        each, append a ``(failed: lost-on-restart) [Re: "<snip>"]`` /
        ``(失败：lost-on-restart) [回复:「<snip>」]`` row to that session by
        calling :meth:`_fold_back_append` directly.

        For Teams-sourced sessions whose orphan ack is within
        *recent_threshold_s* of now, additionally schedule a proactive
        ``OutboundMessage`` so the Teams client (which does not read sqlite)
        learns the work was lost. Older orphans only get the durable
        sqlite row — Web Chat / Desktop clients read sqlite directly.
        Non-Teams sessions never receive a proactive notify (internal execution
        has no delivery; Web Chat/Desktop reads sqlite).

        The recency threshold targets the IM mental model: a user who just
        restarted the daemon at 0:07 with a turn in flight should see a
        notification immediately on Teams; a 3-hour-old leftover from a
        crash they've already moved past should not retroactively spam.

        Idempotent: a session whose orphan acks have already been "closed"
        with a lost-on-restart row will not re-trigger because the prior
        fold-back row makes the snippet match the existing-foldback set.

        Returns the number of ack rows that were converted to fold-backs.
        """
        from praestoclaw.agent.loop_v2 import parse_promotion_ack

        if self._session_store is None:
            logger.debug("event_loop.reap_skip reason=no_session_store")
            return 0

        start_t = time.monotonic()
        sessions_scanned = 0
        acks_found = 0
        orphans_reaped = 0
        notifies_sent = 0

        try:
            session_ids = await session_store.list_main_sessions(limit=limit)
        except Exception as exc:  # noqa: BLE001 — defensive
            logger.warning("event_loop.reap_failed reason=list_sessions error={}", exc)
            return 0

        for session_id in session_ids:
            sessions_scanned += 1
            try:
                rows_with_ts = await session_store.get_assistant_rows_with_timestamps(session_id)
            except Exception as exc:  # noqa: BLE001 — per-session defensive
                logger.warning(
                    "event_loop.reap_session_skipped session={} error={}", session_id, exc
                )
                continue

            ack_by_task: dict[str, tuple[str, str]] = {}  # task_id → (snippet, created_at)
            # Two parallel closure indexes, both consulted before deciding an
            # ack is orphaned:
            #
            #   ``closed_task_ids`` — task_ids that already have a fold-back
            #   row written for them (extracted from the new ``· task=<id>``
            #   marker on the attribution). This is the load-bearing dedupe
            #   key. Two acks with the same snippet but different task_ids
            #   close independently; an old fold-back's snippet cannot mask
            #   a fresh orphan with the same question text.
            #
            #   ``closed_snippets`` — fallback for legacy fold-back rows
            #   written before the task marker existed. Without this we'd
            #   re-reap any session that was already closed on a previous
            #   release. The two-tier check (task_id first, snippet second)
            #   means upgraded sessions get the strict guarantee while
            #   pre-upgrade sessions degrade gracefully to the old behavior.
            closed_task_ids: set[str] = set()
            closed_snippets: set[str] = set()
            for content, created_at in rows_with_ts:
                parsed = parse_promotion_ack(content)
                if parsed is not None:
                    task_id, snippet = parsed
                    ack_by_task[task_id] = (snippet, created_at)
                    continue
                marker = _extract_foldback_marker(content)
                if marker is not None:
                    snip, foldback_task_id = marker
                    if foldback_task_id is not None:
                        closed_task_ids.add(foldback_task_id)
                    else:
                        closed_snippets.add(snip)

            # ``:teams:`` substring in the session id marks a Teams-sourced
            # main session whose user expects proactive Teams notifies (see
            # ``cloud.py`` session-id construction at line ~2206). Web Chat
            # and internal sessions do not appear in the Teams notify path.
            session_is_teams = ":teams:" in session_id

            for task_id, (snippet, created_at) in ack_by_task.items():
                acks_found += 1
                if task_id in self._active:
                    continue
                if task_id in closed_task_ids:
                    continue
                # Snippet fallback only applies when nothing else has
                # closed this task. Don't conflate distinct task_ids whose
                # snippets happen to collide (repeat questions, 80-char
                # truncation): the task_id is authoritative when present.
                if snippet in closed_snippets:
                    continue
                origin = BackgroundOrigin(
                    channel=ChannelType.CLOUD if session_is_teams else ChannelType.INTERNAL,
                    channel_id=session_id,
                )
                fake = BackgroundTask(
                    task_id=task_id,
                    agent=_PROMOTED_LABEL,
                    origin=origin,
                    owner=session_id,
                    state="failed",
                    error="lost-on-restart",
                    question=snippet,
                )
                fake.finished_at = time.monotonic()
                # Reaper-specific copy: the regular fold-back attribution
                # (``[回复:「…」]`` / ``[Re: "…"]``) reads as "(failed) reply:
                # «…»" — confusing self-loop. We use a status-update
                # phrasing instead (see ``_compose_lost_on_restart_content``).
                lost_content = self._compose_lost_on_restart_content(fake)
                try:
                    await self._fold_back_append(fake, content_override=lost_content)
                except Exception as exc:  # noqa: BLE001 — per-orphan defensive
                    logger.warning(
                        "event_loop.reap_append_failed session={} task_id={} error={}",
                        session_id,
                        task_id,
                        exc,
                    )
                    continue
                orphans_reaped += 1
                logger.info(
                    "event_loop.reap_orphan_ack main={} task_id={} snippet_len={}",
                    session_id,
                    task_id,
                    len(snippet),
                )

                # Proactive Teams notify for fresh orphans. Two gates:
                # (1) session id contains ``:teams:`` so the cloud channel
                #     can route the notify to Teams; (2) ack row's
                #     ``created_at`` is within the recency threshold.
                # Web Chat / Desktop sessions read sqlite directly,
                # so the durable fold-back row from above already covers
                # them; pushing a notify on those would either no-op or
                # mis-route.
                if (
                    session_is_teams
                    and recent_threshold_s > 0
                    and self._is_recent(created_at, recent_threshold_s)
                ):
                    try:
                        await self._reap_push_teams_notify(fake)
                        notifies_sent += 1
                    except Exception as exc:  # noqa: BLE001 — push is best-effort
                        logger.warning(
                            "event_loop.reap_push_failed session={} task_id={} error={}",
                            session_id,
                            task_id,
                            exc,
                        )

        elapsed_ms = int((time.monotonic() - start_t) * 1000)
        logger.info(
            "event_loop.reap_summary sessions_scanned={} acks_found={} "
            "orphans_reaped={} notifies_sent={} elapsed_ms={}",
            sessions_scanned,
            acks_found,
            orphans_reaped,
            notifies_sent,
            elapsed_ms,
        )
        return orphans_reaped

    @staticmethod
    def _is_recent(created_at: str, threshold_s: float) -> bool:
        """True iff ``created_at`` (ISO 8601 UTC) is within ``threshold_s``
        seconds of now. Defensive: a malformed timestamp logs at debug and
        is treated as "not recent" so the reaper falls back to sqlite-only
        behavior rather than spamming on garbage data.
        """
        if not created_at:
            return False
        try:
            from datetime import UTC, datetime

            ts = datetime.fromisoformat(created_at)
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=UTC)
            age = (datetime.now(UTC) - ts).total_seconds()
        except (ValueError, TypeError) as exc:
            logger.debug(
                "event_loop.reap_recency_parse_failed created_at={} error={}", created_at, exc
            )
            return False
        return 0 <= age <= threshold_s

    async def _reap_push_teams_notify(self, record: BackgroundTask) -> None:
        """Send a proactive ``OutboundMessage`` for a freshly-reaped orphan
        on a Teams session.

        Body uses the lost-on-restart phrasing (not the regular fold-back
        ``[Re: …]`` envelope, which would read as "(failed) reply: «…»"
        — see ``_compose_lost_on_restart_content``). The phrasing already
        embeds the original question, so we deliberately do NOT set
        ``promoted_final=True``: that flag would trigger the cloud
        channel's ``↩️ 回复你刚才的提问「…」`` quote-prefix, duplicating
        the question and reading "(reply re: A) ⚠️ A was lost…" — wordy
        and confusing. ``push_target="teams"`` is set explicitly because
        the in-memory ``_teams_routed_channel_ids`` set is empty on a
        fresh process — the carrier route was lost with the previous run.
        """
        content = self._compose_lost_on_restart_content(record)
        metadata: dict[str, Any] = {
            "keep_context": True,
            "notify_category": "background_task",
            "background_task_id": record.task_id,
            # Force Teams routing — the per-session route table is empty on
            # restart, so without this the notify would default to webchat.
            "push_target": "teams",
        }
        await self._bus.publish_outbound(
            OutboundMessage(
                channel=record.origin.channel,
                channel_id=record.origin.channel_id,
                content=content,
                thread_id=record.origin.thread_id,
                route_hint=record.origin.route_hint,
                metadata=metadata,
            )
        )

    async def aclose(self) -> None:
        """Cancel all pending tasks and await in-flight deliveries."""
        self._closed = True
        pending = [
            r.task for r in self._active.values() if r.task is not None and not r.task.done()
        ]
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        # Let done callbacks scheduled by the cancellations run.
        await asyncio.sleep(0)
        deliveries = [d for d in self._deliveries if not d.done()]
        if deliveries:
            await asyncio.gather(*deliveries, return_exceptions=True)
        foldbacks = [f for f in self._foldbacks if not f.done()]
        if foldbacks:
            await asyncio.gather(*foldbacks, return_exceptions=True)

    # ── Status / control (read by the ``tasks`` tool) ────────────────────

    @staticmethod
    def _owner_ok(record: BackgroundTask, owner: str | None) -> bool:
        """Whether *owner* may see/control *record*.

        ``owner=None`` callers (system / internal / legacy) see everything. Records
        with no owner are visible to everyone for back-compat. Otherwise the
        caller's session must match the task's owning session.
        """
        if owner is None or record.owner is None:
            return True
        return record.owner == owner

    def status(self, task_id: str, *, owner: str | None = None) -> dict[str, Any] | None:
        record = self._find(task_id)
        if record is None or not self._owner_ok(record, owner):
            return None
        return self._snapshot(record)

    def list_tasks(self, *, owner: str | None = None) -> list[dict[str, Any]]:
        records = [*self._active.values(), *self._terminal.values()]
        return [self._snapshot(r) for r in records if self._owner_ok(r, owner)]

    def investigation_records(self, owner: str) -> list[dict[str, Any]]:
        """Strict read scope; legacy unowned tasks are not feedback evidence."""
        if not owner:
            return []
        records = [*self._active.values(), *self._terminal.values()]
        return [
            {
                **self._snapshot(r),
                "question": r.question,
                "result": r.result,
                "error": r.error,
                "workflow": r.workflow,
                "workflow_params": r.workflow_params,
            }
            for r in sorted(records, key=lambda r: r.started_at, reverse=True)
            if r.owner == owner or (r.workflow_owner and r.workflow_owner == owner)
        ]

    def feedback_snapshot(self) -> list[dict[str, Any]]:
        """Unabridged task data for the collector's explicit group/session selection."""
        from dataclasses import fields

        return [
            {
                item.name: getattr(record, item.name)
                for item in fields(record)
                if item.name not in {"task", "terminal_content", "delivery_callback", "origin"}
            }
            | {
                "origin": {
                    "channel": record.origin.channel.value,
                    "channel_id": record.origin.channel_id,
                    "thread_id": record.origin.thread_id,
                    "route_hint": record.origin.route_hint,
                    "teams_conversation_id": record.origin.teams_conversation_id,
                    "push_target": record.origin.push_target,
                }
            }
            for record in [*self._active.values(), *self._terminal.values()]
        ]

    def list_workflow_runs(self, *, owner: str | None = None) -> list[dict[str, Any]]:
        """Active workflow runs (records that carry a ``workflow`` recipe name),
        for the ``workflow status`` in-flight view. Active only (a finished run's
        outcome is delivered back to its channel, not here).

        ``owner`` is the workflow status/resume scope: it uses the stable
        ``workflow_owner`` when present and otherwise falls back to the concrete
        task-control owner. Scoping is STRICT (unlike :meth:`list_tasks`):
        ``owner=None`` sees all, but a non-None owner sees only its own runs; an
        unowned task does not bleed into a specific scope."""
        out: list[dict[str, Any]] = []
        for r in self._active.values():
            if not r.workflow:
                continue
            if owner is not None and (r.workflow_owner or r.owner) != owner:
                continue
            out.append(
                {
                    "workflow": r.workflow,
                    "task_id": r.task_id,
                    "elapsed_seconds": round(r.elapsed_seconds, 1),
                }
            )
        return out

    def list_for_owner(self, owner: str) -> list[BackgroundTaskSnapshot]:
        """Return active tasks owned by *owner*.

        Used by the event-loop status fast-path (``AgentLoopV2._schedule_inbound``):
        when a "how's it going?" check arrives, the loop counts how many of the
        caller's promoted workers are still in flight and emits a count-aware ack
        instead of enqueuing the status check behind the work it asks about
        (which would deadlock the serial main lane). Terminal records are
        intentionally excluded — the ack only cares about *running* work.

        Unlike :meth:`list_tasks` this requires a non-None owner and ignores
        records that lack one (unowned legacy tasks should not bleed into a
        specific conversation's status answer).
        """
        snaps: list[BackgroundTaskSnapshot] = []
        for record in self._active.values():
            if record.owner is None or record.owner != owner:
                continue
            snaps.append(
                BackgroundTaskSnapshot(
                    task_id=record.task_id,
                    label=record.agent,
                    question=record.question,
                    started_at=record.started_at,
                    elapsed_s=round(record.elapsed_seconds, 1),
                )
            )
        return snaps

    def cancel_by_owner(self, owner: str) -> int:
        """Cancel every active task owned by *owner* and return the count.

        Used by the event-loop interrupt fast-path: a "stop" / "取消" message
        scoped to a conversation must cancel all of that conversation's
        promoted workers (not just the inline turn). Iterates a snapshot of
        ``self._active`` because cancellation can mutate the dict via the
        done-callback. Records without an explicit owner are NOT cancelled —
        legacy / internal callers manage those through :meth:`cancel`.

        Returns the number of cancel requests issued (a record may finish
        before the cooperative ``CancelledError`` actually propagates; the
        terminal fold-back path handles the eventual state transition).
        """
        cancelled = 0
        for record in list(self._active.values()):
            if record.owner is None or record.owner != owner:
                continue
            task = record.task
            if task is None or task.done():
                continue
            task.cancel()
            cancelled += 1
            # Emit the canonical cancel line per record so a fan-out
            # ``/stop`` shows up once per worker, matching the §5.2 grep
            # recipe (filter by task_id and you see promote → cancel →
            # worker_done → foldback for that exact worker).
            if record.agent == _PROMOTED_LABEL:
                logger.info(
                    "event_loop.cancel task_id={} reason={} by=owner",
                    record.task_id,
                    "owner_interrupt",
                )
        return cancelled

    def get_result(self, task_id: str, *, owner: str | None = None) -> str | None:
        """Return the result/error string for a finished task, else None."""
        record = self._find(task_id)
        if record is None or not self._owner_ok(record, owner):
            return None
        if record.state not in _TERMINAL_STATES:
            return None
        return record.result if record.state == "completed" else record.error

    async def cancel(self, task_id: str, *, owner: str | None = None) -> str:
        record = self._find(task_id)
        # Treat a non-owner's request as "unknown" so task existence is not
        # disclosed across conversations.
        if record is None or not self._owner_ok(record, owner):
            return f"Unknown task {task_id}."
        if record.task is None or record.task.done():
            return f"Task {task_id} already finished."
        record.task.cancel()
        # Emit the canonical cancel line for promoted (event-loop) workers
        # so a ``/stop <id>`` shows up in the §5.2 chain alongside its
        # eventual ``event_loop.worker_done state=cancelled`` line. The
        # ``by`` field distinguishes a targeted single-worker stop
        # (``by=id``) from a fan-out owner interrupt
        # (``cancel_by_owner`` emits ``by=owner``).
        if record.agent == _PROMOTED_LABEL:
            logger.info(
                "event_loop.cancel task_id={} reason={} by=id",
                record.task_id,
                "stop_command",
            )
        return f"Cancellation requested for task {task_id}."

    # ── Internals ────────────────────────────────────────────────────────

    def _find(self, task_id: str) -> BackgroundTask | None:
        return self._active.get(task_id) or self._terminal.get(task_id)

    @staticmethod
    def _snapshot(record: BackgroundTask) -> dict[str, Any]:
        return {
            "task_id": record.task_id,
            "agent": record.agent,
            "state": record.state,
            "elapsed_seconds": round(record.elapsed_seconds, 1),
        }
