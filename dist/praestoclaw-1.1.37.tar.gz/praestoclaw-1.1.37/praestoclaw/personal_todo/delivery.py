"""Send the saved reminder through the agent's cloud channel."""

from datetime import UTC, datetime
from uuid import uuid4

from praestoclaw.channels.base import BaseChannel
from praestoclaw.personal_todo.store import Store


async def send(store: Store, run: str, channel: BaseChannel) -> dict:
    message = (store.run_dir(run) / "message.md").read_text(encoding="utf-8")
    request_id = str(uuid4())
    store.claim_delivery(run)
    store.update_metadata(
        run, delivery_channel="cloud", push_target="teams", push_request_id=request_id
    )
    try:
        await channel.send(
            "personal-todo",
            message,
            push_target="teams",
            keep_context=True,
            notify_category="notify_tool",
            push_request_id=request_id,
        )
    except Exception as exc:
        # A transport failure can occur after the service accepted the message.
        return store.update_metadata(run, delivery="unknown", delivery_error=str(exc))
    receipt = channel.get_push_delivery(request_id)
    if receipt is None:
        return store.update_metadata(
            run, delivery="unknown", delivery_error="Cloud channel returned no delivery receipt"
        )
    if not receipt.get("teams"):
        return store.update_metadata(
            run,
            delivery="failed",
            delivery_receipt=receipt,
            delivery_error="Cloud channel did not deliver the reminder to Teams",
        )
    return store.update_metadata(
        run,
        delivery="sent",
        sent_at=datetime.now(UTC).isoformat(),
        delivery_receipt=receipt,
    )
