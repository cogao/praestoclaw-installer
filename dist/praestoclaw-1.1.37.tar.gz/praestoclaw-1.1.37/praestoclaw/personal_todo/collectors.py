"""Bounded source reads for personal todo skills; all semantic decisions stay in the skill."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from filelock import FileLock

from praestoclaw.chronicle.mcp_caller import McpCaller
from praestoclaw.chronicle.textutil import extract_json, parse_iso
from praestoclaw.personal_todo.store import Store, run_path


def _command(*args: str) -> str:
    result = subprocess.run(
        [shutil.which(args[0]) or args[0], *args[1:]],
        check=True,
        capture_output=True,
        encoding="utf-8",
    )
    return result.stdout.strip()


async def _call(caller: McpCaller, server: str, tool: str, args: dict) -> dict:
    payload = extract_json(await caller.call_tool(server, tool, args))
    if not isinstance(payload, dict) or payload.get("error"):
        raise RuntimeError(f"{server}.{tool} returned no usable result: {payload}")
    return payload


async def resolve_identity(caller: McpCaller, *, observed_at: datetime) -> dict:
    fields = "id,displayName,userPrincipalName,mail"
    account = _command("az", "account", "show", "--query", "user.name", "--output", "tsv")
    me = await _call(caller, "m365-user", "GetMyDetails", {"select": fields})
    result: dict[str, Any] = {
        "me": me,
        "m1": None,
        "m2": None,
        "azure_account": account,
        "observed_at": observed_at.isoformat(),
        "missing": [],
    }
    try:
        result["m1"] = await _call(
            caller, "m365-user", "GetManagerDetails", {"userId": "me", "select": fields}
        )
        manager = await _call(
            caller,
            "m365-user",
            "GetUserDetails",
            {
                "userIdentifier": result["m1"]["id"],
                "select": fields,
            },
        )
        result["m2"] = await _call(
            caller,
            "m365-user",
            "GetManagerDetails",
            {
                "userId": manager["userPrincipalName"],
                "select": fields,
            },
        )
    except Exception as exc:
        result["missing"].append(str(exc))
    return result


def snapshot_kb(store: Store, repository: str, run_id: str) -> dict:
    root = store.root / "raw" / "kb"
    repo = root / "repo"
    worktree = run_path(root / "worktrees", run_id)
    root.mkdir(parents=True, exist_ok=True)
    # Generation and queries share this clone, including origin and FETCH_HEAD.
    with FileLock(root / ".repo.lock", timeout=120):
        if not repo.exists():
            _command("git", "clone", "--no-checkout", "--", repository, str(repo))
        else:
            _command("git", "-C", str(repo), "remote", "set-url", "origin", repository)
        # Fetch remote HEAD afresh, including when the configured default branch changed.
        _command("git", "-C", str(repo), "fetch", "origin", "HEAD")
        commit = _command("git", "-C", str(repo), "rev-parse", "FETCH_HEAD")
        worktree.parent.mkdir(parents=True, exist_ok=True)
        _command("git", "-C", str(repo), "worktree", "add", "--detach", str(worktree), commit)
    return {
        "repository": repository,
        "path": str(worktree),
        "commit": commit,
        "observed_at": datetime.now().astimezone().isoformat(),
    }


def _chat_supported(chat: dict) -> bool:
    if chat.get("chatType"):
        return chat["chatType"] in {"oneOnOne", "group", "meeting"}
    return bool(chat["id"].endswith(("@thread.v2", "@unq.gbl.spaces")))


def _next(page: dict) -> str | None:
    return page.get("nextLink") or page.get("@odata.nextLink")


def _items(page: dict, key: str) -> list[dict]:
    for name in (key, "value"):
        items = page.get(name)
        if isinstance(items, list):
            return items
    raise ValueError(f"Expected a {key} or value array in the Teams response")


async def collect_teams(
    caller: McpCaller,
    store: Store,
    *,
    since: datetime,
    until: datetime,
    history_since: dict[str, datetime] | None = None,
    chat_ids: list[str] | None = None,
    max_pages: int = 20,
) -> dict:
    """Discover in [since, until), extending only historical chats to their own lower bounds."""
    history_since = history_since or {}
    result: dict[str, Any] = {
        "since": since.isoformat(),
        "until": until.isoformat(),
        "roster_complete": None,
        "chats": [],
        "missing": [],
    }
    if chat_ids is None:
        try:
            page = await _call(caller, "teams", "ListChats", {"fetchAllPages": True})
            chats = _items(page, "chats")
            result["roster_complete"] = not (page.get("hasMoreResults") or _next(page))
            if not result["roster_complete"]:
                result["missing"].append(
                    "ListChats did not exhaust the roster; no continuation parameter is exposed"
                )
        except Exception as exc:
            chats = []
            result["roster_complete"] = False
            result["missing"].append(str(exc))
        selected = {
            chat["id"]
            for chat in chats
            if _chat_supported(chat)
            and (
                (last := parse_iso((chat.get("lastMessagePreview") or {}).get("createdDateTime")))
                is None
                or last >= since
            )
        }
    else:
        selected = set(chat_ids)
    selected.update(history_since)
    for chat_id in sorted(selected):
        lower = min(since, history_since.get(chat_id, since))
        coverage = {
            "chat_id": chat_id,
            "since": lower.isoformat(),
            "until": until.isoformat(),
            "complete": False,
            "pages": 0,
            "messages": 0,
            "paths": [],
            "oldest_observed": None,
            "next_link": None,
        }
        args = {"chatId": chat_id, "include": "attachments,reactions"}
        try:
            for _ in range(max_pages):
                page = await _call(caller, "teams", "ListChatMessages", args)
                messages = _items(page, "messages")
                collected_at = datetime.now(until.tzinfo)
                coverage["last_observed_at"] = collected_at.isoformat()
                path = store.append_teams(chat_id, messages, "agency", collected_at)
                if str(path) not in coverage["paths"]:
                    coverage["paths"].append(str(path))
                coverage["pages"] += 1
                dates = [
                    parse_iso(m.get("lastModifiedDateTime") or m.get("createdDateTime"))
                    for m in messages
                ]
                known_dates = [d for d in dates if d is not None]
                if known_dates:
                    coverage["oldest_observed"] = min(known_dates).isoformat()
                coverage["messages"] += sum(
                    1
                    for m in messages
                    if (dt := parse_iso(m.get("createdDateTime"))) is not None
                    and lower <= dt < until
                )
                coverage["next_link"] = _next(page)
                # Graph orders by last modification: an edited old creation is not a boundary.
                crossed = (
                    bool(dates) and all(d is not None for d in dates) and min(known_dates) < lower
                )
                exhausted = not _next(page) and not page.get("hasMoreResults")
                if crossed or exhausted:
                    coverage["complete"] = True
                    coverage["stop_reason"] = "lower_bound" if crossed else "exhausted"
                    break
                if not _next(page):
                    coverage["stop_reason"] = "missing_next_link"
                    break
                args = {
                    "chatId": chat_id,
                    "nextLink": _next(page),
                    "include": "attachments,reactions",
                }
            else:
                coverage["stop_reason"] = "page_limit"
        except Exception as exc:
            coverage["error"] = str(exc)
        result["chats"].append(coverage)
    return result


async def refresh_teams_message(
    caller: McpCaller,
    store: Store,
    *,
    chat_id: str,
    message_id: str,
) -> dict:
    message = await _call(
        caller,
        "teams",
        "GetChatMessage",
        {
            "chatId": chat_id,
            "messageId": message_id,
            "include": "attachments,reactions",
        },
    )
    observed = datetime.now().astimezone()
    path = store.append_teams(chat_id, [message], "agency", observed)
    return {"path": str(path), "observed_at": observed.isoformat(), "message": message}


async def supplement_teams_web(
    store: Store,
    *,
    data_dir: Path,
    chat_id: str,
    since: datetime,
    until: datetime,
    max_pages: int = 20,
) -> dict:
    from praestoclaw.config.loader import load_config
    from praestoclaw.teams_web.chatsvc import TeamsChatsvcClient, message_time, parse_message_time
    from praestoclaw.teams_web.tokens import TOKEN_CACHE_FILENAME, TeamsWebTokenProvider
    from praestoclaw.utils.helpers import get_data_dir, set_data_dir

    original_data_dir = get_data_dir()
    try:
        set_data_dir(data_dir)
        config = load_config().praesto_tag_exp.teams_web
    finally:
        set_data_dir(original_data_dir)
    provider = TeamsWebTokenProvider(
        cache_path=data_dir / "auth" / TOKEN_CACHE_FILENAME,
        profile_dir=Path(config.profile_dir).expanduser() if config.profile_dir else None,
        allow_headed_login=False,
        skew_s=config.token_skew_s,
    )
    token = await provider.get_token()
    fetched = await TeamsChatsvcClient(chat_id, access_token=token.secret).fetch_messages(
        since=since - timedelta(microseconds=1),
        max_pages=max_pages,
    )
    observed = datetime.now(until.tzinfo)
    # Preserve every returned raw message, including the page crossing the lower bound.
    raw = [
        m
        for page in fetched.raw_pages
        for m in page.get("messages", [])
        if not m.get("conversationid") or m["conversationid"] == chat_id
    ]
    path = store.append_teams(chat_id, raw, "teams_web", observed)
    last = fetched.raw_pages[-1] if fetched.raw_pages else {}
    continuation = (last.get("_metadata") or {}).get("backwardLink") or last.get("nextLink")
    complete = fetched.reached_start or bool(fetched.raw_pages) and not continuation
    return {
        "chat_id": chat_id,
        "path": str(path),
        "observed_at": observed.isoformat(),
        "since": since.isoformat(),
        "until": until.isoformat(),
        "complete": complete,
        "pages": fetched.pages_fetched,
        "next_link": continuation,
        "messages": sum(
            1
            for m in raw
            if (dt := parse_message_time(message_time(m))) is not None and since <= dt < until
        ),
    }


def refresh_issue(store: Store, url: str) -> dict:
    match = re.fullmatch(r"https://github\.com/([\w.-]+)/([\w.-]+)/issues/(\d+)(?:[?#].*)?", url)
    if not match:
        raise ValueError("Expected an explicit github.com owner/repo/issues/number URL")
    owner, repo, number = match.groups()
    if owner in {".", ".."} or repo in {".", ".."}:
        raise ValueError("GitHub owner and repo must not be relative path components")
    endpoint = f"repos/{owner}/{repo}/issues/{number}"
    issue = json.loads(_command("gh", "api", endpoint))
    pages = json.loads(
        _command("gh", "api", "--paginate", "--slurp", endpoint + "/comments?per_page=100")
    )
    observed = datetime.now().astimezone()
    result = {
        "issue": issue,
        "comments": [comment for page in pages for comment in page],
        "observed_at": observed.isoformat(),
    }
    path = store.root / "raw" / "github" / owner / repo / f"{number}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"path": str(path), **result}
