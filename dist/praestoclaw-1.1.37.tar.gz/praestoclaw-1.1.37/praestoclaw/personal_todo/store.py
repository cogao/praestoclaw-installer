"""Markdown runs and raw evidence under the agent's explicit workspace."""

from __future__ import annotations

import hashlib
import json
import re
from datetime import UTC, datetime, timedelta
from importlib.resources import files
from pathlib import Path
from typing import Any, cast
from zoneinfo import ZoneInfo

from filelock import FileLock

from praestoclaw.chronicle.textutil import parse_iso
from praestoclaw.security.secrets import _atomic_write_file

_METADATA = re.compile(r"(# Run metadata\s*\n```json\n)(.*?)(\n```)", re.DOTALL)


def run_path(directory: Path, run: str) -> Path:
    """Resolve a generated run timestamp within its designated storage directory."""
    if not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}_[0-9]{9}(?:-[1-9][0-9]*)?", run):
        raise ValueError("Expected a run timestamp, optionally followed by a collision suffix")
    root = directory.resolve()
    path = (root / run).resolve()
    if path == root or not path.is_relative_to(root):
        raise ValueError("Run path must stay within its storage directory")
    return path


def clock_context(timezone: str, intent: str = "today", now: datetime | None = None) -> dict:
    started = (now or datetime.now().astimezone()).astimezone(ZoneInfo(timezone))
    midnight = started.replace(hour=0, minute=0, second=0, microsecond=0)
    monday = midnight.date() - timedelta(days=midnight.weekday())
    return {
        "timestamp": started.strftime("%Y-%m-%d_%H%M%S") + f"{started.microsecond // 1000:03d}",
        "started_at": started.isoformat(),
        "timezone": timezone,
        "intent": intent,
        "since": (midnight - timedelta(days=intent == "yesterday")).isoformat(),
        "discovery_until": (midnight if intent == "yesterday" else started).isoformat(),
        "until": started.isoformat(),
        "this_week": monday.isoformat(),
        "last_week": (monday - timedelta(days=7)).isoformat(),
    }


def template(name: str) -> str:
    return (
        files("praestoclaw.skills.bundled")
        .joinpath("personal-todo-generate", "templates", name)
        .read_text(encoding="utf-8")
    )


class Store:
    def __init__(self, workspace: str | Path):
        self.root = Path(workspace).expanduser().resolve() / "personal-todo"
        self._lock = FileLock(self.root / ".store.lock", timeout=30)

    def config(self, *, kb_repo: str | None = None, timezone: str | None = None) -> dict:
        path = self.root / "config.json"
        config = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
        if kb_repo is not None:
            config["kb_repo"] = kb_repo
        if timezone is not None:
            ZoneInfo(timezone)
            config["timezone"] = timezone
        if not config.get("kb_repo") or not config.get("timezone"):
            raise ValueError("Provide --kb-repo and --timezone on the first invocation")
        if kb_repo is not None or timezone is not None:
            self.root.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
        return config

    def history(self) -> list[str]:
        path = self.root / "history.json"
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else []

    def run_dir(self, run: str) -> Path:
        return run_path(self.root / "runs", run)

    def metadata(self, run: str) -> dict:
        content = (self.run_dir(run) / "context.md").read_text(encoding="utf-8")
        match = _METADATA.search(content)
        if match is None:
            raise ValueError(f"Missing run metadata: {run}")
        return cast(dict, json.loads(match[2]))

    def update_metadata(self, run: str, **changes: Any) -> dict:
        with self._lock:
            path = self.run_dir(run) / "context.md"
            content = path.read_text(encoding="utf-8")
            metadata = self.metadata(run) | changes
            encoded = json.dumps(metadata, ensure_ascii=False, indent=2)
            _atomic_write_file(
                path, _METADATA.sub(lambda m: m[1] + encoded + m[3], content, count=1)
            )
            return metadata

    def claim_delivery(self, run: str) -> dict:
        """Persist the single delivery attempt before crossing the network boundary."""
        with self._lock:
            metadata = self.metadata(run)
            if metadata["generation"] != "complete":
                raise ValueError("Complete the run before sending")
            if metadata["delivery"] != "unsent":
                raise ValueError(
                    "This run already has a delivery attempt; do not automatically resend"
                )
            return self.update_metadata(run, delivery="sending")

    def baselines(self) -> dict:
        generated = sent = None
        for run in reversed(self.history()):
            metadata = self.metadata(run)
            if generated is None and metadata["generation"] == "complete":
                generated = run
            if sent is None and metadata["delivery"] == "sent":
                sent = run
            if generated is not None and sent is not None:
                break
        return {"generated": generated, "sent": sent}

    def start(self, context: dict) -> dict:
        self.root.mkdir(parents=True, exist_ok=True)
        with self._lock:
            return self._start(context)

    def _start(self, context: dict) -> dict:
        run = context["timestamp"]
        baselines = self.baselines()
        # Allocate under the same cross-process lock as the history update.
        suffix = 0
        while self.run_dir(run).exists():
            suffix += 1
            run = f"{context['timestamp']}-{suffix}"
        directory = self.run_dir(run)
        directory.mkdir(parents=True)
        metadata = context | {
            "timestamp": run,
            "generation": "generating",
            "delivery": "unsent",
            "state_baseline": baselines["generated"],
            "sent_baseline": baselines["sent"],
        }
        (directory / "context.md").write_text(
            template("context.md").replace(
                "{{metadata}}", json.dumps(metadata, ensure_ascii=False, indent=2)
            ),
            encoding="utf-8",
        )
        for name in ("todos.md", "message.md"):
            (directory / name).write_text(template(name), encoding="utf-8")
        history = self.history()
        history.append(run)
        # Publish only fully initialized runs; readers see either complete index version.
        _atomic_write_file(self.root / "history.json", json.dumps(history))
        return metadata | {"run_dir": str(directory), "baselines": baselines}

    def complete(self, run: str) -> dict:
        for name in ("context.md", "todos.md", "message.md"):
            content = (self.run_dir(run) / name).read_text(encoding="utf-8")
            if not content.strip() or "{{" in content:
                raise ValueError(f"Finish {name} before marking the run complete")
        return self.update_metadata(run, generation="complete")

    @staticmethod
    def chat_key(chat_id: str) -> str:
        return hashlib.sha256(chat_id.encode()).hexdigest()[:24]

    def append_teams(
        self, chat_id: str, messages: list[dict], source: str, collected_at: datetime
    ) -> Path:
        local = collected_at.astimezone(ZoneInfo(self.config()["timezone"]))
        path = self.root / "raw" / "teams" / self.chat_key(chat_id) / f"{local.date()}.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as stream:
            for message in messages:
                record = {
                    "collected_at": collected_at.isoformat(),
                    "source": source,
                    "chat_id": chat_id,
                    "message": message,
                }
                stream.write(json.dumps(record, ensure_ascii=False) + "\n")
        return path

    def read_teams(self, chat_id: str, as_of: datetime | None = None) -> list[dict]:
        """One message identity with latest raw versions from each source interface."""
        records: dict[str, dict[str, dict]] = {}
        directory = self.root / "raw" / "teams" / self.chat_key(chat_id)
        for path in sorted(directory.glob("*.jsonl")):
            for line in path.read_text(encoding="utf-8").splitlines():
                record = json.loads(line)
                observed = datetime.fromisoformat(record["collected_at"])
                if as_of is not None and observed > as_of:
                    continue
                message = record["message"]
                mid = str(message["id"])
                versions = records.setdefault(mid, {})
                prior = versions.get(record["source"])
                if prior is None or self._version(record) >= self._version(prior):
                    versions[record["source"]] = record
        result = []
        for mid, sources in records.items():
            source_versions = sorted(sources.values(), key=self._version, reverse=True)
            result.append(
                source_versions[0] | {"message_id": mid, "source_versions": source_versions}
            )
        return result

    @staticmethod
    def _version(record: dict) -> tuple:
        msg = record["message"]
        observed = datetime.fromisoformat(record["collected_at"])
        modified = parse_iso(
            msg.get("lastModifiedDateTime")
            or msg.get("edittime")
            or msg.get("createdDateTime")
            or msg.get("originalarrivaltime")
        )
        if record["source"] == "teams_web" and msg.get("version"):
            modified = datetime.fromtimestamp(int(msg["version"]) / 1000, UTC)
        return modified or observed, observed
