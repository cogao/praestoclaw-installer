"""Shell entrypoint shared by the generation and query skills."""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from datetime import UTC, datetime
from io import TextIOWrapper
from pathlib import Path
from typing import cast

from praestoclaw.personal_todo.store import Store, clock_context, template


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(description=__doc__)
    root.add_argument("--data-dir", required=True)
    root.add_argument("--workspace", required=True)
    commands = root.add_subparsers(dest="command", required=True)
    for name in ("start", "query-start"):
        command = commands.add_parser(name)
        command.add_argument("--kb-repo")
        command.add_argument("--timezone")
        command.add_argument("--intent", choices=("today", "yesterday"), default="today")
    commands.add_parser("history")
    commands.add_parser("identity")
    commands.add_parser("complete").add_argument("run")
    commands.add_parser("template").add_argument(
        "name", choices=("context.md", "todos.md", "message.md")
    )
    commands.add_parser("kb").add_argument("--timestamp", required=True)
    commands.add_parser("issue").add_argument("urls", nargs="+")
    for name in ("teams", "teams-web"):
        command = commands.add_parser(name)
        command.add_argument("--since", required=True, type=datetime.fromisoformat)
        command.add_argument("--until", required=True, type=datetime.fromisoformat)
        command.add_argument("--chat-id", required=name == "teams-web")
        if name == "teams":
            command.add_argument("--history-chats", type=Path)
    command = commands.add_parser("teams-message")
    command.add_argument("--chat-id", required=True)
    command.add_argument("--message-id", required=True)
    command = commands.add_parser("cache-teams")
    command.add_argument("--chat-id", required=True)
    command.add_argument("--as-of", type=datetime.fromisoformat)
    return root


async def execute(args: argparse.Namespace):
    store = Store(args.workspace)
    name = args.command
    if name in ("start", "query-start"):
        now = datetime.now(UTC)
        config = store.config(kb_repo=args.kb_repo, timezone=args.timezone)
        context = clock_context(config["timezone"], args.intent, now)
        if name == "start":
            return store.start(context) | {"config": config}
        return context | {"config": config, "baselines": store.baselines()}
    if name == "history":
        return {"history": store.history(), "baselines": store.baselines(), "root": str(store.root)}
    if name == "template":
        return template(args.name)
    if name == "complete":
        return store.complete(args.run)
    if name == "cache-teams":
        return store.read_teams(args.chat_id, args.as_of)

    from praestoclaw.personal_todo import collectors

    if name == "kb":
        return collectors.snapshot_kb(store, store.config()["kb_repo"], args.timestamp)
    if name == "issue":
        results = []
        for url in dict.fromkeys(args.urls):
            try:
                results.append(collectors.refresh_issue(store, url))
            except Exception as exc:
                results.append({"url": url, "refreshed": False, "error": str(exc)})
        return results
    if name == "teams-web":
        return await collectors.supplement_teams_web(
            store,
            data_dir=Path(args.data_dir).expanduser().resolve(),
            chat_id=args.chat_id,
            since=args.since,
            until=args.until,
        )

    from praestoclaw.chronicle.mcp_caller import StdioMcpCaller

    caller = StdioMcpCaller()
    try:
        if name == "identity":
            return await collectors.resolve_identity(caller, observed_at=datetime.now(UTC))
        if name == "teams":
            history = (
                json.loads(args.history_chats.read_text(encoding="utf-8"))
                if args.history_chats
                else {}
            )
            return await collectors.collect_teams(
                caller,
                store,
                since=args.since,
                until=args.until,
                history_since={
                    cid: datetime.fromisoformat(since) for cid, since in history.items()
                },
                chat_ids=[args.chat_id] if args.chat_id else None,
            )
        if name == "teams-message":
            return await collectors.refresh_teams_message(
                caller, store, chat_id=args.chat_id, message_id=args.message_id
            )
    finally:
        await caller.aclose()


def main() -> None:
    cast(TextIOWrapper, sys.stdout).reconfigure(encoding="utf-8")
    cast(TextIOWrapper, sys.stderr).reconfigure(encoding="utf-8")
    result = asyncio.run(execute(parser().parse_args()))
    print(result if isinstance(result, str) else json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
