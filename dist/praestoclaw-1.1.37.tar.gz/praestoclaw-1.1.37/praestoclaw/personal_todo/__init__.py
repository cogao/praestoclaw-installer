"""Shared storage and collection helpers for the personal todo skills."""
