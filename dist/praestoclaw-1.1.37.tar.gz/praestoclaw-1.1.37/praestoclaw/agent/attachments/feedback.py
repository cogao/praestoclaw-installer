"""Bounded, conversation-owned screenshot references for feedback uploads."""

from __future__ import annotations

import asyncio
import io
import secrets
from collections import OrderedDict
from dataclasses import dataclass, replace
from pathlib import Path
from time import monotonic
from typing import Any

from PIL import Image

from praestoclaw.agent.attachments.preprocessor import AttachmentResolver, download_attachment
from praestoclaw.host.runtime_contracts import (
    AgentRuntimeProtocol,
    AgentRuntimeRequest,
    AgentRuntimeResult,
)

MAX_IMAGES = 10
MAX_IMAGE_BYTES = 8 * 1024 * 1024
MAX_TOTAL_BYTES = 32 * 1024 * 1024
_TTL = 7 * 24 * 3600


@dataclass(frozen=True)
class Screenshot:
    image_id: str
    scope: tuple[str, str, str]
    url: str
    created: float
    index: int
    github_url: str = ""
    upload_uncertain: bool = False
    issue_url: str = ""


class FeedbackImages:
    def __init__(self) -> None:
        self._images: OrderedDict[str, Screenshot] = OrderedDict()

    @staticmethod
    def scope(session_id: str, metadata: Any) -> tuple[str, str, str]:
        if not isinstance(metadata, dict):
            raise ValueError("screenshots require a trusted human Teams conversation")
        provenance = metadata.get("turn_provenance")
        sender = metadata.get("_feedback_sender_id")
        conversation = metadata.get("_feedback_conversation_id")
        if (
            not session_id
            or not isinstance(provenance, dict)
            or provenance.get("human_initiated") is not True
            or provenance.get("logical_channel") != "teams"
            or metadata.get("source") in {"cron", "heartbeat"}
            or metadata.get("execution_lane") in {"system", "subagent"}
            or not isinstance(sender, str)
            or not sender
            or not isinstance(conversation, str)
            or not conversation
        ):
            raise ValueError("screenshots require a trusted human Teams conversation")
        return session_id, conversation, sender

    def _prune(self) -> None:
        now = monotonic()
        for image_id, image in list(self._images.items()):
            if now - image.created >= _TTL:
                del self._images[image_id]

    def candidates(self, session_id: str, metadata: Any) -> list[dict[str, Any]]:
        self._prune()
        try:
            scope = self.scope(session_id, metadata)
        except ValueError:
            return []
        return [
            {"image_id": image.image_id, "index": image.index}
            for image in self._images.values()
            if image.scope == scope
        ][-MAX_IMAGES:]

    def record_upload(self, image: Screenshot, url: str) -> None:
        current = self._images.get(image.image_id)
        if current is not None and current.scope == image.scope:
            self._images[image.image_id] = replace(current, github_url=url, upload_uncertain=False)

    def record_issue(self, images: list[Screenshot], issue_url: str) -> None:
        for image in images:
            current = self._images.get(image.image_id)
            if current is not None and current.scope == image.scope:
                self._images[image.image_id] = replace(current, issue_url=issue_url)

    def begin_upload(self, images: list[Screenshot]) -> None:
        current = [self._images.get(image.image_id) for image in images]
        if any(
            stored is None
            or stored.scope != image.scope
            or stored.upload_uncertain
            or stored.github_url
            for stored, image in zip(current, images, strict=True)
        ):
            raise ValueError(
                "screenshot state changed or upload is unconfirmed; verify the existing issue before retrying"
            )
        for image in images:
            self._images[image.image_id] = replace(image, upload_uncertain=True)

    def remember(self, session_id: str, metadata: Any) -> list[dict[str, Any]]:
        self._prune()
        try:
            scope = self.scope(session_id, metadata)
        except ValueError:
            return []
        for ref in AttachmentResolver().list_current(metadata):
            if ref.kind != "image" or ref.requires_auth:
                continue
            if any(
                image.scope == scope and image.url == ref.url for image in self._images.values()
            ):
                continue
            image_id = "screenshot_" + secrets.token_hex(12)
            self._images[image_id] = Screenshot(image_id, scope, ref.url, monotonic(), ref.index)
            owned = [key for key, image in self._images.items() if image.scope[0] == session_id]
            for key in owned[:-100]:
                del self._images[key]
            while len(self._images) > 1000:
                self._images.popitem(last=False)
        return self.candidates(session_id, metadata)

    def resolve(self, image_ids: Any, session_id: str, metadata: Any) -> list[Screenshot]:
        if (
            not isinstance(image_ids, list)
            or len(image_ids) > MAX_IMAGES
            or any(not isinstance(image_id, str) for image_id in image_ids)
            or len(set(image_ids)) != len(image_ids)
        ):
            raise ValueError("image_ids must contain at most 10 distinct screenshot IDs")
        if not image_ids:
            return []
        scope = self.scope(session_id, metadata)
        self._prune()
        images = [self._images.get(image_id) for image_id in image_ids]
        if any(image is None or image.scope != scope for image in images):
            raise ValueError("screenshot unavailable in this conversation; attach it again")
        if any(image is not None and image.upload_uncertain for image in images):
            raise ValueError(
                "screenshot upload is unconfirmed; verify the existing issue before retrying, do not blindly reupload"
            )
        return [image for image in images if image is not None]


class FeedbackImageRuntime:
    """Capture private screenshot references at the authenticated cloud boundary."""

    def __init__(self, runtime: AgentRuntimeProtocol, images: FeedbackImages) -> None:
        self._runtime = runtime
        self._images = images

    async def run_once(self, request: AgentRuntimeRequest) -> AgentRuntimeResult:
        policy = dict(request.runtime_policy)
        metadata = dict(policy.get("message_metadata") or {})
        metadata.pop("_feedback_sender_id", None)
        metadata.pop("_feedback_conversation_id", None)
        provenance = request.turn_provenance
        if provenance and provenance.human_initiated and provenance.logical_channel == "teams":
            metadata["_feedback_sender_id"] = str(policy.get("sender_id") or "")
            metadata["_feedback_conversation_id"] = str(policy.get("conversation_id") or "")
            self._images.remember(
                request.session_id,
                {
                    **metadata,
                    "turn_provenance": {
                        "human_initiated": provenance.human_initiated,
                        "logical_channel": provenance.logical_channel,
                    },
                },
            )
        policy["message_metadata"] = metadata
        return await self._runtime.run_once(replace(request, runtime_policy=policy))


async def prepare_screenshots(
    images: list[Screenshot], directory: Path, *, deadline: float
) -> tuple[list[tuple[str, Path]], list[dict[str, str]]]:
    prepared: list[tuple[str, Path]] = []
    failures: list[dict[str, str]] = []
    total = 0
    for image in images:
        try:
            remaining = min(15.0, deadline - monotonic())
            if remaining <= 0:
                raise TimeoutError
            allowance = min(MAX_IMAGE_BYTES, MAX_TOTAL_BYTES - total)
            if allowance <= 0:
                raise ValueError("batch size exceeded")
            total += allowance
            fetched = await asyncio.wait_for(
                download_attachment(image.url, max_bytes=allowance), remaining
            )
            if len(fetched.data) > allowance:
                raise ValueError("download exceeded its byte allowance")
            total -= allowance - len(fetched.data)
            with Image.open(io.BytesIO(fetched.data)) as decoded:
                extension = {"PNG": ".png", "JPEG": ".jpg", "GIF": ".gif"}.get(decoded.format or "")
                if extension is None:
                    raise ValueError("unsupported screenshot format")
                decoded.verify()
            path = directory / f"{image.image_id}{extension}"
            path.write_bytes(fetched.data)
            prepared.append((image.image_id, path))
        except Exception:
            failures.append(
                {
                    "image_id": image.image_id,
                    "status": "unavailable",
                    "reason": "Download failed, expired, or image exceeds supported size/type limits.",
                }
            )
    return prepared, failures
