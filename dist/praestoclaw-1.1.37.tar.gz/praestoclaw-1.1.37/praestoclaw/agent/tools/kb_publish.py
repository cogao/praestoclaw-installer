"""Publish a locally committed KB proposal after its one draft confirmation.

The group confirms its detailed file-level summary once; that approval closes
any optional Draft PR mirror and authorizes this tool to update the real branch,
squash the local proposal onto it, create one commit, and push immediately.
"""

from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.agent.tools.kb_base import KbToolBase
from praestoclaw.kb.draft import (
    DECISION_APPROVED,
    DECISION_DRAFT,
    STATUS_AWAITING_PUBLISH,
    STATUS_CANCELLED,
    STATUS_PUBLISHED,
    CurationTask,
    CurationTaskStore,
    commit_message_for,
)
from praestoclaw.kb.github_review import close_draft_review
from praestoclaw.kb.repo import KbAuthRequiredError, KbPathError, KbRepo, KbRepoError
from praestoclaw.security.kb_curation import kb_curation_is_active
from praestoclaw.security.risk import RiskAssessment, RiskScore


def _now() -> str:
    return datetime.now(UTC).isoformat()


class KbPublishTool(KbToolBase, Tool):
    """Squash and push a proposal approved in ordinary group chat."""

    risk_range = (6, 6)

    @property
    def name(self) -> str:
        return "kb_publish"

    @property
    def description(self) -> str:
        return (
            "Publish the current conversation's local KB proposal. This tool has its "
            "own durable natural-language gate: it refuses unless the detailed draft "
            "approval, including the group's exact words, matches the current proposal "
            "fingerprint. There is no second publish confirmation or Adaptive Card. "
            "Once approved it updates the real branch from origin, squash-merges the "
            "local proposal, commits and pushes. Only after confirmed publication does "
            "it close the optional Draft PR and clean up. On merge_conflict, continue "
            "with kb_draft(action='rebase') to prepare a resolved draft for fresh approval; "
            "do not stop at the conflict or retry the unchanged proposal."
            " An interrupted push is only reconciled on the next call, even for a "
            "cancelled task; that call never starts another push."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=300, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(6, reason="Commit and push to the shared team knowledge base")

    def handles_approval_internally(self, args: dict[str, Any], metadata: dict[str, Any]) -> bool:
        """Tell the generic gate not to create a third, card-based confirmation.

        This says only that the tool owns the gate, not that approval exists.
        ``execute`` validates the durable chat decisions and otherwise performs
        no repository mutation.
        """
        del args
        return kb_curation_is_active(metadata)

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "Explicit ID of the approved task to publish.",
                },
                "message": {
                    "type": "string",
                    "description": (
                        "Optional assertion of the already-confirmed commit message. A "
                        "different message is refused."
                    ),
                },
            },
            "required": ["task_id"],
        }

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata") or {}
        if not kb_curation_is_active(metadata):
            return (
                "kb_publish is only available in a Teams group experiment or personal Teams chat."
            )
        if not self._enabled():
            return "Knowledge-base curation is disabled in this PraestoClaw config."

        cid = str(metadata.get("cid") or "")
        if not cid:
            return "Error: kb_publish needs a Teams conversation id on this turn."

        store = CurationTaskStore(cid)
        task_id = str(kwargs.get("task_id") or "").strip()
        if not task_id:
            return "Error: task_id is required; use kb_draft(list) to find the proposal."
        task = store.load(task_id)
        if task is None:
            return "No curation task found for this conversation."
        if task.status == STATUS_PUBLISHED:
            repo = self._repo_for_task(task.repo)
            if isinstance(repo, KbRepo):
                await self._cleanup_published(store, task, repo)
            return self._success_result(task)
        pending = self._pending_publish(task)
        if pending is not None:
            resolved = self._repo_for_task(task.repo)
            if isinstance(resolved, str):
                return self._failure_result(store, task, resolved, stage="reconcile")
            return await self._reconcile_publish(store, task, resolved, pending)
        cleanup = next(
            (
                attempt
                for attempt in reversed(task.publish_attempts)
                if attempt.get("outcome") == "not_published" and attempt.get("cleanup_pending")
            ),
            None,
        )
        if cleanup is not None:
            resolved = self._repo_for_task(task.repo)
            if isinstance(resolved, str):
                return self._failure_result(store, task, resolved, stage="cleanup")
            return await self._cleanup_unpublished_attempt(store, task, resolved, cleanup)
        if not task.is_active:
            return f"Task {task.task_id} is {task.status} and cannot be published."
        if task.status != STATUS_AWAITING_PUBLISH or not task.changes or not task.proposal_sha:
            return self._dump(
                {
                    "ok": False,
                    "task_id": task.task_id,
                    "refused": "No approved local proposal is ready to publish.",
                }
            )

        refusal = self._approval_refusal(task)
        if refusal:
            return refusal
        if task.open_blockers:
            return self._dump(
                {
                    "ok": False,
                    "task_id": task.task_id,
                    "refused": "Unanswered rule conflicts — this cannot be published.",
                    "open_blockers": [item.to_dict() for item in task.open_blockers],
                }
            )

        passed_message = str(kwargs.get("message") or "").strip()
        if passed_message and commit_message_for(passed_message, task) != task.commit_message:
            return self._dump(
                {
                    "ok": False,
                    "task_id": task.task_id,
                    "refused": "That commit message is not the one the group confirmed.",
                }
            )

        resolved = self._repo_for_task(task.repo)
        if isinstance(resolved, str):
            return self._failure_result(store, task, resolved)

        try:
            return await self._publish(store, task, resolved)
        except (KbAuthRequiredError, KbPathError, KbRepoError, OSError) as exc:
            return self._failure_result(
                store,
                task,
                str(exc),
                code="authentication" if isinstance(exc, KbAuthRequiredError) else "git_error",
            )

    def _approval_refusal(self, task: CurationTask) -> str:
        draft = task.latest_decision(DECISION_DRAFT)
        if draft is None or draft.decision != DECISION_APPROVED:
            return self._dump(
                {
                    "ok": False,
                    "task_id": task.task_id,
                    "refused": "The group has not approved the detailed draft in chat.",
                }
            )
        if task.draft_approval() is None:
            return self._dump(
                {
                    "ok": False,
                    "task_id": task.task_id,
                    "refused": "The local proposal changed after draft confirmation.",
                }
            )
        return ""

    async def _reconcile_publish(
        self, store: CurationTaskStore, task: CurationTask, repo: KbRepo, pending: dict[str, Any]
    ) -> str:
        """Establish the previous outcome without starting another publication."""
        branch = pending.get("branch") or task.base_branch
        try:
            accepted = await asyncio.to_thread(
                repo.remote_contains, pending["commit"], branch, timeout=self._sync_timeout()
            )
        except (KbRepoError, OSError) as exc:
            return self._failure_result(store, task, str(exc), stage="reconcile")
        if accepted:
            return await self._record_success(store, task, repo, pending["commit"], branch)

        # Persist the known outcome and cleanup obligation before removing any
        # path. Later calls retry cleanup without reconciling or pushing again.
        pending["outcome"] = "not_published"
        pending["cleanup_pending"] = True
        store.save(task)
        return await self._cleanup_unpublished_attempt(store, task, repo, pending)

    async def _cleanup_unpublished_attempt(
        self, store: CurationTaskStore, task: CurationTask, repo: KbRepo, attempt: dict[str, Any]
    ) -> str:
        error = ""
        cancelled = task.status == STATUS_CANCELLED
        try:
            if cancelled:
                removed = await asyncio.to_thread(self._cleanup_task, store, task, repo)
                if not removed:
                    raise KbRepoError("The local proposal branch could not be removed.")
            elif task.publish_worktree_path:
                await asyncio.to_thread(
                    repo.remove_worktree, task.publish_worktree_path, force=True
                )
                task.publish_worktree_path = ""
            attempt["cleanup_pending"] = False
            store.save(task)
        except (KbRepoError, OSError) as exc:
            attempt["cleanup_pending"] = True
            error = str(exc)
            logger.warning("kb_publish {}, cleanup pending: {}", task.task_id, exc)
        return self._dump(
            {
                "ok": not error,
                "task_id": task.task_id,
                "outcome": "not_published",
                "status": task.status,
                "cleanup_pending": bool(error),
                "cleanup_error": error,
                "reply": (
                    "已确认上次发布提交不在知识库目标分支上；本地清理尚未完成。"
                    if error
                    else "已确认上次发布提交不在知识库目标分支上，已清理取消任务的本地草稿。"
                    if cancelled
                    else "已确认上次发布提交不在知识库目标分支上，本次核对没有再次发布。"
                ),
                "next": (
                    f"Resolve the cleanup error and call kb_publish(task_id='{task.task_id}') "
                    "to retry cleanup only; that call will not publish."
                    if error
                    else "This task is cancelled; no further publication will run."
                    if cancelled
                    else "The draft is retained. Continue editing, cancel, or call kb_publish "
                    "again to attempt publication of the approved proposal."
                ),
            }
        )

    async def _publish(self, store: CurationTaskStore, task: CurationTask, repo: KbRepo) -> str:
        target_branch = task.base_branch
        paths = [change.path for change in task.changes]
        if task.publish_worktree_path:
            await asyncio.to_thread(repo.remove_worktree, task.publish_worktree_path, force=True)
            task.publish_worktree_path = ""
            store.save(task)

        await asyncio.to_thread(self._task_worktree, store, task)
        try:
            status = await asyncio.to_thread(
                repo.fetch_branch, target_branch, timeout=self._sync_timeout()
            )
        except (KbRepoError, OSError) as exc:
            return self._failure_result(
                store,
                task,
                str(exc),
                stage="fetch",
                code="authentication" if isinstance(exc, KbAuthRequiredError) else "git_error",
            )
        path = self._worktree_path(repo, task, kind="publish") / uuid4().hex[:12]
        task.publish_worktree_path = str(path)
        store.save(task)
        sha = ""
        stage = "prepare"
        try:
            publishing = await asyncio.to_thread(repo.create_worktree, path, status.head)
            # Use the approved commit, even if a shell user moved the proposal branch.
            stage = "merge"
            await asyncio.to_thread(publishing.squash_merge, task.proposal_sha)
            stage = "commit"
            sha = await asyncio.to_thread(publishing.commit, paths, task.commit_message)
            stage = "record_attempt"
            task.publish_attempts.append(
                {
                    "at": _now(),
                    "outcome": "pushing",
                    "commit": sha,
                    "branch": target_branch,
                    "worktree_path": str(path),
                    "proposal_commit": task.proposal_sha,
                    "fingerprint": task.change_fingerprint(),
                    "publish_base_head": status.head,
                }
            )
            store.save(task)
            stage = "push"
            await asyncio.to_thread(
                publishing.push_to,
                target_branch,
                expected_head=status.head,
                timeout=self._sync_timeout(),
            )
        except (KbRepoError, OSError) as exc:
            code = "authentication" if isinstance(exc, KbAuthRequiredError) else "git_error"
            conflicts: list[str] = []
            if stage == "merge":
                unmerged = await asyncio.to_thread(
                    publishing._git_in_repo, "diff", "--name-only", "--diff-filter=U", "-z"
                )
                conflicts = unmerged.stdout.rstrip("\0").split("\0") if unmerged.stdout else []
                if conflicts:
                    code = "merge_conflict"
            if stage == "push" and any(
                marker in str(exc)
                for marker in ("(non-fast-forward)", "(fetch first)", "(stale info)")
            ):
                code = "target_advanced"
            # A failed/lost push response can still mean the remote accepted it.
            if stage == "push" and code not in {"target_advanced", "authentication"}:
                try:
                    accepted = await asyncio.to_thread(
                        repo.remote_contains, sha, target_branch, timeout=self._sync_timeout()
                    )
                except (KbRepoError, OSError) as verify_error:
                    # Retain the commit and path so a later attempt can establish the outcome.
                    return self._failure_result(
                        store,
                        task,
                        f"{exc}; outcome check failed: {verify_error}",
                        stage=stage,
                        code="publish_outcome_unknown",
                        publish_base_head=status.head,
                    )
                if accepted:
                    return await self._record_success(store, task, repo, sha, target_branch)
            pending = self._pending_publish(task)
            if pending is not None:
                pending["outcome"] = "not_published"
                pending["cleanup_pending"] = True
                store.save(task)
            try:
                await asyncio.to_thread(repo.remove_worktree, path, force=True)
                task.publish_worktree_path = ""
                if pending is not None:
                    pending["cleanup_pending"] = False
                store.save(task)
            except (KbRepoError, OSError) as cleanup_error:
                logger.warning("kb_publish cleanup failed for {}: {}", task.task_id, cleanup_error)
            return self._failure_result(
                store,
                task,
                str(exc),
                stage=stage,
                code=code,
                publish_base_head=status.head,
                conflict_paths=conflicts,
            )
        return await self._record_success(store, task, repo, sha, target_branch)

    async def _record_success(
        self, store: CurationTaskStore, task: CurationTask, repo: KbRepo, sha: str, branch: str
    ) -> str:
        paths = [change.path for change in task.changes]
        approval = task.draft_approval()
        task.status = STATUS_PUBLISHED
        task.published = {
            "proposal_commit": task.proposal_sha,
            "proposal_review": task.proposal_review or None,
            "commit": sha,
            "branch": branch,
            "url": repo.commit_url(sha),
            "message": task.commit_message,
            "overview": task.overview,
            "paths": paths,
            "files": [
                {
                    "path": change.path,
                    "operation": change.operation,
                    "summary": change.summary,
                    "details": change.details,
                    "units": change.units,
                }
                for change in task.changes
            ],
            "overrode_rules": [item.to_dict() for item in task.overridden_blockers],
            "approved_by": approval.by if approval else "",
            "approval_quote": approval.quote if approval else "",
            "approval_stage": DECISION_DRAFT,
            "proposal_branch_removed": False,
            "published_at": _now(),
            "fingerprint": task.change_fingerprint(),
        }
        task.publish_attempts.append(
            {
                "at": task.published["published_at"],
                "outcome": "succeeded",
                "proposal_commit": task.proposal_sha,
                "commit": sha,
                "branch": branch,
                "url": task.published["url"],
                "message": task.commit_message,
                "paths": paths,
                "approved_by": task.published["approved_by"],
                "approval_quote": task.published["approval_quote"],
                "fingerprint": task.published["fingerprint"],
            }
        )
        try:
            store.save(task)
        except OSError as exc:
            # The remote has already accepted the commit. Keep the durable
            # pending attempt/worktree for reconciliation on the next call.
            logger.warning("kb_publish: {} pushed, receipt save pending: {}", task.task_id, exc)
            return self._success_result(task)
        await self._cleanup_published(store, task, repo)
        logger.info(
            "kb_publish: task={} proposal={} commit={} paths={}",
            task.task_id,
            task.proposal_sha[:8],
            sha[:8],
            ", ".join(paths),
        )
        return self._success_result(task)

    async def _cleanup_published(
        self, store: CurationTaskStore, task: CurationTask, repo: KbRepo
    ) -> None:
        try:
            if task.proposal_review:
                task.proposal_review = await asyncio.to_thread(
                    close_draft_review,
                    repo,
                    task.proposal_review,
                    fallback_branch=task.proposal_branch,
                )
                task.published["proposal_review"] = task.proposal_review
                store.save(task)
            removed = await asyncio.to_thread(self._cleanup_task, store, task, repo)
            task.published["proposal_branch_removed"] = removed
            store.save(task)
        except (KbRepoError, OSError) as exc:
            logger.warning("kb_publish: published {}, cleanup pending: {}", task.task_id, exc)

    def _success_result(self, task: CurationTask) -> str:
        published = task.published
        link = str(published.get("url") or published.get("commit") or "").strip()
        reply = (
            f"知识库已更新：[查看更新]({link})"
            if link.startswith(("https://", "http://"))
            else "知识库已更新。"
        )
        return self._dump({"ok": True, "task_id": task.task_id, "reply": reply})

    def _failure_result(
        self,
        store: CurationTaskStore,
        task: CurationTask,
        reason: str,
        *,
        stage: str = "prepare",
        code: str = "git_error",
        publish_base_head: str = "",
        conflict_paths: list[str] | None = None,
    ) -> str:
        detail = " ".join((reason or "unknown error").split())[:4000]
        pending = self._pending_publish(task)
        if pending is not None:
            code = "publish_outcome_unknown"
            publish_base_head = publish_base_head or pending.get("publish_base_head", "")
        outcome = "unknown" if code == "publish_outcome_unknown" else "failed"
        error = {
            "code": code,
            "stage": stage,
            "detail": detail,
            "base_branch": task.base_branch,
            "base_head": task.base_head,
            "publish_base_head": publish_base_head,
            "conflict_paths": conflict_paths or [],
        }
        replies = {
            "merge_conflict": "知识库已有更新，与当前草稿发生合并冲突，尚未发布；草稿已保留。",
            "target_advanced": "发布期间知识库目标分支又有了更新，本次提交被拒绝；草稿已保留。",
            "publish_outcome_unknown": "暂时无法确认上次发布是否成功，记录和现场已保留；可以稍后核对，也可以取消任务。",
            "authentication": "知识库认证或访问权限检查失败，尚未发布；草稿已保留。",
        }
        next_steps = {
            "merge_conflict": (
                f"Continue now with kb_draft(action='rebase', task_id='{task.task_id}'). "
                "Read the three-way inputs, preserve both sides' independent changes and "
                "stage resolved content with rebase on this same task. Do not retry the "
                "unchanged proposal or wait for another instruction to fix conflicts. "
                "Present the repaired draft and request fresh approval before publication. "
                "Ask a specific question only if conflicting business facts require a choice."
            ),
            "target_advanced": "Fetch and review the latest target before retrying. This rejection does not establish a content conflict.",
            "publish_outcome_unknown": "Call kb_publish with this task_id to check the previous outcome only, or cancel/restart. Do not claim the KB was unchanged.",
            "authentication": "Restore repository access before retrying.",
        }
        logger.warning(
            "kb_publish.failed task={} stage={} code={} branch={} base={} publish_base={} conflicts={} detail={}",
            task.task_id,
            stage,
            code,
            task.base_branch,
            task.base_head,
            publish_base_head,
            conflict_paths or [],
            detail,
        )
        task.publish_attempts.append(
            {
                "at": _now(),
                "outcome": outcome,
                "reason": detail,
                "error": error,
                "proposal_commit": task.proposal_sha,
                "message": task.commit_message,
                "paths": [change.path for change in task.changes],
                "fingerprint": task.change_fingerprint(),
            }
        )
        store.save(task)
        return self._dump(
            {
                "ok": False,
                "task_id": task.task_id,
                "outcome": outcome,
                "error": error,
                "draft_preserved": True,
                "reply": replies.get(code, f"知识库暂时没有更新成功：{detail[:180]}"),
                "next": next_steps.get(
                    code, "Inspect the reported operation failure before retrying."
                ),
            }
        )

    @staticmethod
    def _dump(payload: dict[str, Any]) -> str:
        return json.dumps(payload, ensure_ascii=False, indent=2)
