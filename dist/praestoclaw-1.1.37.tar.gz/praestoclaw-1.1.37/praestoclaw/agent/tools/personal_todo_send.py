"""Deliver a completed personal-todo run through the agent's Teams bot."""

import json
from collections.abc import Callable
from pathlib import Path
from typing import Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.channels.base import BaseChannel
from praestoclaw.personal_todo.delivery import send
from praestoclaw.personal_todo.store import Store
from praestoclaw.security.risk import RiskAssessment, RiskScore


class PersonalTodoSendTool(Tool):
    risk_range = (0, 0)

    def __init__(
        self,
        workspace_fn: Callable[[], Path],
        cloud_channel_fn: Callable[[], BaseChannel | None],
    ) -> None:
        self._workspace_fn = workspace_fn
        self._cloud_channel_fn = cloud_channel_fn

    @property
    def name(self) -> str:
        return "personal_todo_send"

    @property
    def description(self) -> str:
        return (
            "Send a completed personal-todo run's saved message.md to the user's Teams bot "
            "chat through the agent cloud channel. Records the delivery result; never retries "
            "a previously attempted run."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=60, tier="standard")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "run": {"type": "string", "description": "Completed run timestamp."},
            },
            "required": ["run"],
        }

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="Notification to user")

    async def execute(self, **kwargs: Any) -> str:
        channel = self._cloud_channel_fn()
        if channel is None or not channel.is_connected:
            return "Error: cloud channel is unavailable; no delivery attempted."
        result = await send(Store(self._workspace_fn()), kwargs["run"], channel)
        return json.dumps(result, ensure_ascii=False, indent=2)
