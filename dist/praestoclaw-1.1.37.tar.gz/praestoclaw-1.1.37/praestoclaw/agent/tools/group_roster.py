"""Bounded roster reads and member searches for the current Teams group."""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.praesto_tag_exp import praesto_tag_exp_is_active
from praestoclaw.security.risk import RiskAssessment, RiskScore


class GroupRosterTool(Tool):
    risk_range = (3, 3)

    def __init__(self, cloud_channel_getter: Callable[[], Any]) -> None:
        self._cloud_channel_getter = cloud_channel_getter

    @property
    def name(self) -> str:
        return "group_roster"

    @property
    def description(self) -> str:
        return (
            "List one page of CURRENT Teams group members, returning only display_name, "
            "alias and upn. Alias is the part of upn before @; both are null if upn is missing. "
            "Data comes from a Redis snapshot cached for up to 5 minutes, "
            "not a live membership check; as_of is the snapshot time. Default 20, maximum "
            "50 members per call. Use next_cursor only "
            "when more members are needed; do not automatically fetch the entire roster. "
            "Pages use the same snapshot. If it expires, restart without cursor. "
            "Use group_member_search to find a particular member."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=65, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(3, reason="Read current Teams group members")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "limit": {
                    "type": ["integer", "string"],
                    "minimum": 1,
                    "maximum": 50,
                    "default": 20,
                    "description": "Page size from 1 to 50; accepts a whole number or numeric string.",
                },
                "cursor": {
                    "type": "string",
                    "description": (
                        "next_cursor from the previous page of the same query and snapshot. "
                        "Omit for the first page; restart without it if the snapshot expires."
                    ),
                },
            },
            "additionalProperties": False,
        }

    async def execute(self, **kwargs: Any) -> str:
        return await self._fetch(kwargs)

    async def _fetch(self, kwargs: dict[str, Any], *, query: str = "") -> str:
        metadata = kwargs.get("_metadata") or {}
        cid = str(metadata.get("cid") or "").strip()
        if not praesto_tag_exp_is_active(metadata) or not cid:
            return "Error: this tool requires a praesto_tag_exp Teams group conversation."
        raw_limit = kwargs.get("limit", 20)
        limit_error = (
            "Error: limit must be a whole number from 1 to 50, as a number or numeric string."
        )
        if type(raw_limit) not in (int, float, str):
            return limit_error
        try:
            numeric_limit = float(raw_limit)
        except (ValueError, OverflowError):
            return limit_error
        if not 1 <= numeric_limit <= 50 or not numeric_limit.is_integer():
            return limit_error
        limit = int(numeric_limit)
        cursor = kwargs.get("cursor")
        if cursor is None:
            cursor = ""
        if not isinstance(cursor, str):
            return "Error: cursor must be a string copied from next_cursor, or omitted for the first page."
        cursor = cursor.strip()
        channel = self._cloud_channel_getter()
        if channel is None:
            return "Error: cloud channel is not available."
        result = await channel.get_group_roster(cid, limit=limit, cursor=cursor, query=query)
        return json.dumps(result, ensure_ascii=False, separators=(",", ":"))


class GroupMemberSearchTool(GroupRosterTool):
    @property
    def name(self) -> str:
        return "group_member_search"

    @property
    def description(self) -> str:
        return (
            "Find members of the CURRENT Teams group by case-insensitive partial display "
            "name or UPN alias (before @), or full UPN. Use full UPN to identify a member. "
            "Returns only display_name, "
            "alias and upn, at most 50 matches per page (default 20). Alias is the part "
            "of upn before @; both are null if upn is missing. Multiple matches are "
            "ambiguous: do not pick one arbitrarily. Empty members with has_more=false "
            "on the first request means no match in this group's snapshot, not that the "
            "user does not exist in the organisation or is absent from the live group. "
            "The snapshot is cached for up to 5 minutes; as_of gives its time. "
            "Errors do not establish absence. Page further only if needed, keeping "
            "the same query and snapshot cursor. If the snapshot expires, restart "
            "without cursor. A missing upn cannot be used to rule out an alias match."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        schema = super().parameters
        schema["properties"]["query"] = {
            "type": ["string", "number"],
            "minLength": 1,
            "description": (
                "Partial display name or UPN alias, or full UPN. "
                "Numbers are converted to text; use a string to preserve leading zeros."
            ),
        }
        schema["required"] = ["query"]
        return schema

    async def execute(self, **kwargs: Any) -> str:
        query = kwargs.get("query")
        if type(query) not in (str, int, float):
            return (
                "Error: query must be a string or number containing a name, UPN alias, or full UPN."
            )
        query = str(query).strip()
        if not query:
            return "Error: query must not be empty."
        return await self._fetch(kwargs, query=query)
