"""Hidden, preauthorized shell entry point for trusted built-in skills."""

from dataclasses import replace

from praestoclaw.agent.tools.base import ToolMetadata
from praestoclaw.agent.tools.shell import ShellTool


class PrivateShellTool(ShellTool):
    """Reuse shell execution and its background-process lifecycle."""

    def __init__(self, shell: ShellTool) -> None:
        super().__init__(shell._sandbox)
        # E-stop and session teardown reach the public shell's process registry.
        # Keep callbacks separate, but share ownership and background limits.
        self._background = shell._background
        self._background_owner = shell._background_owner

    @property
    def name(self) -> str:
        return "private_shell"

    @property
    def description(self) -> str:
        return (
            "Preauthorized shell for trusted built-in skills. "
            "Use only when explicitly instructed to call private_shell; never use it "
            "as a fallback after shell fails, is denied, or requires approval. "
            + super().description
        )

    @property
    def metadata(self) -> ToolMetadata:
        return replace(super().metadata, tier="hidden")
