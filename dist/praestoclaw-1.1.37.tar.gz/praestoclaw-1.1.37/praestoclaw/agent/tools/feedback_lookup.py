"""Read fixed-repository feedback evidence without borrowing general GitHub access."""

from __future__ import annotations

import asyncio
import json
import re
from typing import Any
from urllib.parse import urlencode

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.feedback import sanitize_feedback_text
from praestoclaw.security.risk import RiskAssessment, RiskScore

REPO = "gim-home/PraestoClaw"
MIRRORS = {"cogao/praestoclaw-installer", "xchunzhao/praestoclaw-installer-staging"}


class FeedbackLookupTool(Tool):
    """Facts only; matching complaints and deciding mutations belong to the parent."""

    risk_range = (0, 0)

    def __init__(self, *, command: tuple[str, ...] = ("gh",)) -> None:
        self._command = command
        self._read_issues: dict[str, set[int]] = {}

    @property
    def name(self) -> str:
        return "feedback_lookup"

    @property
    def description(self) -> str:
        return (
            "Read issues, PRs and publication evidence in the fixed PraestoClaw repository. "
            "Before feedback investigation search distinctive complaint terms and pass candidates "
            "to the independent feedback-investigator. Search returns candidates, not same-bug "
            "decisions. When candidates exist or lookup fails, read feedback references/routing.md: "
            "when the standalone skill tool is available, use "
            "skill(action='read', name='feedback', path='references/routing.md'); otherwise use "
            "tools(action='skill', name='feedback', path='references/routing.md'), including "
            "ordinary group chats outside the shared-agent experiment. "
            "Read issue body and comments before supplementing; only useful new evidence merits "
            "a comment. Never interpret unavailable/partial lookup as no matching issue."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=120, tier="core")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["search", "read_issue", "read_pr", "release_status"],
                },
                "query": {
                    "type": "string",
                    "description": "Distinctive search words, without GitHub qualifiers.",
                },
                "number": {"type": "integer", "minimum": 1},
                "page": {"type": "integer", "minimum": 1, "maximum": 10},
                "channel": {"type": "string", "enum": ["production", "staging"]},
                "current_version": {
                    "type": "string",
                    "description": "Affected target version, only if known; never assume execution host is target.",
                },
                "current_build": {
                    "type": "string",
                    "enum": ["published", "unknown"],
                    "description": "published for a confirmed standard supported installed release of the affected target, with known channel/version and no known custom/source conflict or untracked development build. Official dev/pre/post releases are supported. Missing direct_url or build SHA alone does not require unknown.",
                },
                "current_source_sha": {
                    "type": "string",
                    "description": "Verified affected build source SHA, if available; never infer it from version alone.",
                },
            },
            "required": ["action"],
            "additionalProperties": False,
        }

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="Read fixed PraestoClaw feedback and installer records")

    def can_comment(self, owner: str, number: int) -> bool:
        return number in self._read_issues.get(owner, set())

    async def _api(self, endpoint: str) -> Any:
        process = await asyncio.create_subprocess_exec(
            *self._command,
            "api",
            "--hostname",
            "github.com",
            "--method",
            "GET",
            endpoint,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=20)
        except BaseException:
            if process.returncode is None:
                process.kill()
            await process.wait()
            raise
        if process.returncode:
            raise ValueError(stderr.decode(errors="replace")[:500] or "GitHub read failed")
        return json.loads(stdout)

    async def _read(self, repo: str, endpoint: str) -> Any:
        if repo not in {REPO, *MIRRORS}:
            raise ValueError("Repository is outside feedback lookup scope")
        return await self._api(f"repos/{repo}/{endpoint}")

    async def read_issue(self, number: int, page: int = 1) -> dict[str, Any]:
        payload = await self._read(REPO, f"issues/{number}")
        self._validate_issue(payload, number)
        comments = await self._read(REPO, f"issues/{number}/comments?per_page=30&page={page}")
        if not isinstance(comments, list):
            raise ValueError("Invalid issue comments response")
        timeline = await self._read(REPO, f"issues/{number}/timeline?per_page=30&page={page}")
        if not isinstance(timeline, list):
            raise ValueError("Invalid issue timeline response")
        return {
            "status": "partial"
            if len(comments) == 30 or len(timeline) == 30 or page > 1
            else "success",
            "issue": {
                key: payload.get(key)
                for key in ("number", "html_url", "title", "body", "state", "updated_at")
            },
            "comments": [
                {
                    key: item.get(key)
                    for key in ("id", "html_url", "body", "created_at", "updated_at")
                }
                for item in comments
            ],
            "timeline": timeline,
            "coverage": {
                "page": page,
                "page_size": 30,
                "comments_total": payload.get("comments"),
                "next_comments_page": page + 1 if len(comments) == 30 and page < 10 else None,
                "next_timeline_page": page + 1 if len(timeline) == 30 and page < 10 else None,
                "note": "Timeline references are candidates, not proof of the same bug or a repair. "
                "Reads stop at page 10; remaining history may be unexamined.",
            },
        }

    @staticmethod
    def _validate_issue(payload: Any, number: int) -> None:
        if (
            not isinstance(payload, dict)
            or payload.get("number") != number
            or payload.get("html_url") != f"https://github.com/{REPO}/issues/{number}"
            or "pull_request" in payload
        ):
            raise ValueError("Target is not the requested real PraestoClaw issue")

    async def _read_pr(self, number: int) -> dict[str, Any]:
        payload = await self._read(REPO, f"pulls/{number}")
        if (
            not isinstance(payload, dict)
            or payload.get("number") != number
            or payload.get("html_url") != f"https://github.com/{REPO}/pull/{number}"
        ):
            raise ValueError("Target is not the requested PraestoClaw PR")
        return {
            key: payload.get(key)
            for key in (
                "number",
                "html_url",
                "title",
                "body",
                "state",
                "draft",
                "merged",
                "merged_at",
                "merge_commit_sha",
                "updated_at",
            )
        }

    async def execute(self, **kwargs: Any) -> str:
        owner = str(kwargs.get("_plan_session_id") or kwargs.get("_session_id") or "")
        action = kwargs.get("action")
        result: dict[str, Any]
        try:
            async with asyncio.timeout(110):
                if not owner:
                    raise ValueError("Trusted conversation is required")
                page = kwargs.get("page", 1)
                if type(page) is not int or not 1 <= page <= 10:
                    raise ValueError("page must be 1..10")
                if action == "search":
                    terms = re.findall(r"[\w.-]+", str(kwargs.get("query", "")), flags=re.UNICODE)
                    if not terms:
                        raise ValueError("Supply distinctive complaint terms")
                    query = f"repo:{REPO} " + " ".join(f'"{term}"' for term in terms[:15])
                    data = await self._api(
                        "search/issues?" + urlencode({"q": query, "per_page": 30, "page": page})
                    )
                    items = data["items"]
                    result = {
                        "status": "partial"
                        if data.get("incomplete_results")
                        or data["total_count"] > page * 30
                        or page > 1
                        else "success",
                        "query": query,
                        "total_count": data["total_count"],
                        "page": page,
                        "next_page": page + 1
                        if data["total_count"] > page * 30 and page < 10
                        else None,
                        "incomplete_results": data.get("incomplete_results", False),
                        "candidates": [
                            {
                                key: item.get(key)
                                for key in (
                                    "number",
                                    "html_url",
                                    "title",
                                    "body",
                                    "state",
                                    "pull_request",
                                )
                            }
                            for item in items
                        ],
                    }
                elif action in {"read_issue", "read_pr", "release_status"}:
                    number = kwargs.get("number")
                    if type(number) is not int or number < 1:
                        raise ValueError("number must be a positive integer")
                    if action == "read_issue":
                        result = await self.read_issue(number, page)
                        self._read_issues.setdefault(owner, set()).add(number)
                    else:
                        pr = await self._read_pr(number)
                        if action == "read_pr":
                            result = {"status": "success", "pr": pr}
                        else:
                            from praestoclaw.agent.tools.feedback_release import release_status

                            result = await release_status(
                                self._read,
                                pr,
                                kwargs.get("channel", ""),
                                kwargs.get("current_version"),
                                kwargs.get("current_source_sha"),
                                kwargs.get("current_build", "unknown"),
                            )
                else:
                    raise ValueError("Unknown feedback lookup action")
        except (OSError, ValueError, KeyError, TypeError, TimeoutError) as exc:
            result = {
                "status": "unavailable",
                "error": str(exc),
                "note": "Lookup failed, not evidence of no match. Preserve valid investigation evidence.",
            }
        text = sanitize_feedback_text(
            json.dumps({"repository": REPO, "action": action, **result}, ensure_ascii=False)
        )
        if len(text) > 60000:
            return json.dumps(
                {
                    "status": "partial",
                    "action": action,
                    "truncated": True,
                    "note": "Response exceeded output limit; use narrower search or another page. Do not assume omitted evidence is absent.",
                    "excerpt": text[:55000],
                }
            )
        return text
