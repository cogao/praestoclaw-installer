"""Submit a PraestoClaw feedback issue without exposing shell or filesystem access."""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from time import monotonic
from typing import TYPE_CHECKING, Any

from praestoclaw.agent.attachments.feedback import FeedbackImages, Screenshot, prepare_screenshots
from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.feedback import feedback_is_shared, sanitize_feedback_text
from praestoclaw.security.risk import RiskAssessment, RiskScore

if TYPE_CHECKING:
    from praestoclaw.agent.tools.feedback_lookup import FeedbackLookupTool
    from praestoclaw.security.audit import AuditLogger

_TITLE_PREFIXES = ("[Feedback] ", "[fix societas bug] ")
_MAX_SUMMARY_CHARS = 80
_MAX_BODY_BYTES = 256 * 1024
_REPO = "gim-home/PraestoClaw"
_BUNDLE_ACTIONS = frozenset({"bundle_prepare", "bundle_start", "bundle_status", "bundle_retry"})
_ACTIONS = frozenset({"create", "comment", "edit", "assign"}) | _BUNDLE_ACTIONS
_MAX_ASSIGNEES = 10
_GH_TIMEOUT_SECONDS = 20.0
_ASSIGNMENT_TIMEOUT_SECONDS = 110.0
_FALLBACK_TIMEOUT_SECONDS = 5.0
_LOGIN_RE = re.compile(r"[A-Za-z0-9](?:[A-Za-z0-9_-]{0,37}[A-Za-z0-9])?")
_ISSUE_URL_RE = re.compile(r"https://github\.com/gim-home/PraestoClaw/issues/(?P<number>[1-9]\d*)")
_DIAGNOSTICS_HEADING_RE = re.compile(r"(?im)^##[ \t]+Session diagnostics[ \t]*$")
_DIAGNOSTICS_HEADING = "## Session diagnostics"


@dataclass(frozen=True, slots=True)
class _IssueRef:
    number: int
    url: str


class _AssignmentError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


class FeedbackSubmitTool(Tool):
    """Create feedback, assign repository issues, and amend session-owned issues."""

    risk_range = (6, 6)

    def __init__(
        self,
        *,
        command: tuple[str, ...] = ("gh",),
        diagnostics: AuditLogger | None = None,
        lookup: FeedbackLookupTool | None = None,
    ) -> None:
        self._command = command
        self._diagnostics = diagnostics
        self._lookup = lookup
        self.images = FeedbackImages()
        self._gh_upgrade_lock = asyncio.Lock()
        self._gh_upgrade_attempted = False
        self.bundle_host: Any = None
        self._issues_by_session: dict[str, dict[int, _IssueRef]] = {}

    @property
    def name(self) -> str:
        return "feedback_submit"

    @property
    def description(self) -> str:
        return (
            "For screenshots, pass selected conversation screenshot IDs in image_ids. "
            "Never copy private download URLs into the body. Images are uploaded to GitHub "
            "using gh --attach; check attachments separately from the issue result. "
            "Always relay attachment prerequisite failures and user_action to the user. "
            "Text submission is not screenshot success. Shared feedback never upgrades host software. "
            "For group problem feedback, first bundle_prepare with original_text, then perform "
            "the existing investigation and create/comment with that bundle_id. Whether text "
            "submission succeeds or fails, bundle_start and return its immediate status; the Host "
            "collects raw group materials and full Host logs, verifies OneDrive sync and grants "
            "configured recipients read access without invitation email in the background. "
            "Use bundle_status or bundle_retry with the same ID to inspect or resume delivery. "
            "These operations are bound to the trusted group; recipients, paths and MCP are Host-owned. "
            "Assignment-only requests do not generate bundles. "
            "Create a PraestoClaw feedback issue, optionally assigning explicit GitHub "
            "logins, or assign an existing issue by ID. The repository and create label "
            "are fixed. Assignment adds owners without removing existing ones. Only "
            "edit requires an issue created in the current conversation session; comment also accepts "
            "real issues detailed-read by feedback_lookup in this conversation. First search with "
            "feedback_lookup; when candidates exist or lookup fails, read feedback references/routing.md "
            "with skill(action='read',name='feedback',path='references/routing.md') when the "
            "standalone skill tool is available; otherwise use "
            "tools(action='skill',name='feedback',path='references/routing.md'), including "
            "ordinary group chats outside the shared-agent experiment. "
            "For a new problem report, first use spawn(agent='feedback-investigator', "
            "mode='serial') with the original complaint, relevant conversation, time/IDs and "
            "evidence, separating facts from guesses. Include unexplained phenomena and initial "
            "leads, not an exhaustive checklist. Ask for independent investigation and an account "
            "of material leads: findings/references, evidence-based irrelevance, actual access "
            "limits, or unchecked scope and its impact. Internally review the report against "
            "the complaint for unexplained phenomena and alternatives; use feedback_context "
            "to reread decisive evidence and suspicious claims of exhausted leads. Zero matches, "
            "unsearched windows and truncation do not prove inaccessibility or absence. If a "
            "returned report leaves a material gap that accessible evidence could resolve, "
            "spawn one targeted serial follow-up with the original context, first report/refs "
            "and explicit gaps; earlier conclusions remain hypotheses. At most two investigator "
            "spawns per feedback; no third round. Resolve conflicts using primary evidence or "
            "retain the uncertainty. Do not automatically rerun a failed/timed-out investigation; "
            "retain available evidence and disclose limitations, including follow-up failure. "
            "For material cloud gaps, the parent first reads feedback_context snapshot. Use its "
            "existing scope contract: shared/group/channel/meeting markers, conflicts or "
            "unavailable scope forbid Azure queries; personal scope permits this flow without "
            "extra chat-type proof. Load tools(action='skill', name='feedback', path='references/cloud-logs.md') through "
            "the configured lookup, preserving user/workspace overrides and disabled choices. "
            "Do not claim bundled provenance from the name; feedback scope, JIT, read-only and "
            "sanitization rules apply to every selected reference. Use existing shell permissions "
            "for targeted read-only Azure queries, preferably before the one follow-up. Supply "
            "sanitized cloud evidence and query/source limits to the investigator; its tools "
            "remain feedback_context only. Later parent-only cloud evidence is not independently "
            "analyzed; never add a third spawn. On insufficient Azure log-reading access, ask "
            "in ordinary chat for JIT using the feedback skill's PIM guidance and keep the issue "
            "unsubmitted: no plan checkpoint or full_auto substitute. Retain context and spawn "
            "count; after activation verify access and resume the same request. Explicit inability "
            "to activate or a request to submit existing evidence permits submission with the gap. "
            "Other failures (missing CLI, expired login, denied shell, unavailable logging) "
            "are limitations, not automatically JIT. Shared sessions do not query Azure or wait "
            "for JIT; record cloud gaps without transferring evidence across sessions implicitly. "
            "After internal review and any follow-up, with no unresolved JIT wait, submit once. "
            "Organize the body for the "
            "complaint, preserving expected/actual behavior, decisive evidence, possible causes "
            "and unknowns; no mandatory lead checklist in the issue. Apart from the parent's "
            "personal cloud-query flow, stay within feedback_context scope; do not bypass denied "
            "sources or change authentication. Do not ask diagnostic follow-up questions "
            "or seek user review/confirmation of missing details. Cancellation stops submission."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=120, tier="core")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": sorted(_ACTIONS),
                    "description": "Write feedback, or prepare/start/query/retry this group's debug bundle.",
                },
                "bundle_id": {
                    "type": "string",
                    "description": "ID returned by bundle_prepare; also attach to create/comment.",
                },
                "original_text": {
                    "type": "string",
                    "description": "Complete original group complaint; required for bundle_prepare.",
                },
                "image_ids": {
                    "type": "array",
                    "items": {"type": "string", "pattern": "^screenshot_[0-9a-f]{24}$"},
                    "maxItems": 10,
                    "uniqueItems": True,
                    "description": "Selected screenshot IDs from this human's conversation; create/comment/body-edit only, never URLs or file paths.",
                },
                "issue_number": {
                    "type": "integer",
                    "minimum": 1,
                    "description": (
                        "Required for assign: any explicit issue ID in gim-home/PraestoClaw. "
                        "For edit: created in this session. For comment: created or detailed-read "
                        "by feedback_lookup in this conversation."
                    ),
                },
                "title": {
                    "type": "string",
                    "description": (
                        "For create/edit: title beginning with '[Feedback] ' or the "
                        "workflow-specific '[fix societas bug] '."
                    ),
                    "maxLength": max(map(len, _TITLE_PREFIXES)) + _MAX_SUMMARY_CHARS,
                },
                "body": {
                    "type": "string",
                    "description": "Issue body, comment, or replacement body.",
                },
                "assignees": {
                    "type": "array",
                    "items": {"type": "string", "pattern": f"^{_LOGIN_RE.pattern}$"},
                    "maxItems": _MAX_ASSIGNEES,
                    "description": (
                        "Explicit GitHub logins to add, preserving existing owners. "
                        "Optional for create; required and nonempty for assign. "
                        "Not accepted for comment/edit. Do not infer logins from diagnostics."
                    ),
                },
            },
            "required": ["action"],
            "additionalProperties": False,
        }

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        action = str(args.get("action") or "create")
        if action in _BUNDLE_ACTIONS:
            return RiskScore(
                6, reason="Manage this group's raw debug bundle and configured OneDrive delivery"
            )
        return RiskScore(6, reason=f"{action.title()} a public issue in {_REPO}")

    def audit_args(self, args: dict[str, Any]) -> dict[str, Any]:
        body = args.get("body") if isinstance(args.get("body"), str) else ""
        title = args.get("title") if isinstance(args.get("title"), str) else ""
        assignees = self._validate_assignees(args.get("assignees", []))
        return {
            "action": str(args.get("action") or ""),
            **({"bundle_id": args["bundle_id"]} if "bundle_id" in args else {}),
            **({"issue_number": args["issue_number"]} if "issue_number" in args else {}),
            **({"title": self._sanitize_text(title)} if title else {}),
            **({"body": f"[omitted: {len(body)} chars]"} if body else {}),
            **(
                {"assignees": "[invalid]" if isinstance(assignees, str) else assignees}
                if "assignees" in args
                else {}
            ),
        }

    @staticmethod
    def _validate_title(title: str) -> str:
        prefix = next(
            (candidate for candidate in _TITLE_PREFIXES if title.startswith(candidate)), ""
        )
        if not prefix or not title[len(prefix) :].strip():
            return (
                "Refused: title must begin with '[Feedback] ' or "
                "'[fix societas bug] ' and include a summary."
            )
        if len(title[len(prefix) :]) > _MAX_SUMMARY_CHARS:
            return f"Refused: title summary exceeds {_MAX_SUMMARY_CHARS} characters."
        if any(char in title for char in ("\0", "\r", "\n")):
            return "Refused: title contains an invalid control character."
        return ""

    @staticmethod
    def _sanitize_text(value: str) -> str:
        return sanitize_feedback_text(value)

    @staticmethod
    def _encode_body(body: str) -> tuple[bytes, str]:
        if not body.strip():
            return b"", "Refused: body must not be empty."
        sanitized = FeedbackSubmitTool._sanitize_text(body)
        try:
            encoded = sanitized.encode("utf-8")
        except UnicodeEncodeError:
            return b"", "Refused: body contains invalid Unicode."
        if len(encoded) > _MAX_BODY_BYTES:
            return b"", f"Refused: body is too large (maximum {_MAX_BODY_BYTES} bytes)."
        return encoded, ""

    def _append_session_diagnostics(self, body: str, session_id: str, *, reserve: int = 0) -> str:
        """Append trusted, session-filtered diagnostics without exposing a selector."""
        if _DIAGNOSTICS_HEADING_RE.search(body):
            return body
        timeline = ""
        if self._diagnostics is not None:
            timeline = self._diagnostics.recent_session_diagnostics(session_id)
        timeline = timeline or "_No session diagnostics were available._"
        section_prefix = f"\n\n{_DIAGNOSTICS_HEADING}\n"

        # Size the addition after deterministic sanitization. Preserve the
        # user's report and trim only the automatically generated timeline.
        sanitized_body = self._sanitize_text(body)
        prefix_bytes = self._sanitize_text(section_prefix).encode("utf-8")
        remaining = (
            _MAX_BODY_BYTES - reserve - len(sanitized_body.encode("utf-8")) - len(prefix_bytes)
        )
        if remaining <= 0:
            return body
        sanitized_timeline = self._sanitize_text(timeline)
        encoded_timeline = sanitized_timeline.encode("utf-8")
        if len(encoded_timeline) > remaining:
            marker = "\n… diagnostics truncated to fit issue body limit …"
            marker_bytes = marker.encode("utf-8")
            budget = max(0, remaining - len(marker_bytes))
            encoded_timeline = encoded_timeline[:budget]
            while True:
                try:
                    sanitized_timeline = encoded_timeline.decode("utf-8")
                    break
                except UnicodeDecodeError:
                    encoded_timeline = encoded_timeline[:-1]
            if len(marker_bytes) <= remaining:
                sanitized_timeline += marker
        return f"{body}{section_prefix}{sanitized_timeline}"

    def _session_issue(self, session_id: str, issue_number: Any) -> _IssueRef | str:
        if not session_id:
            return "Refused: a trusted session is required for feedback follow-ups."
        if isinstance(issue_number, bool) or not isinstance(issue_number, int) or issue_number < 1:
            return "Refused: issue_number must be a positive integer."
        issue = self._issues_by_session.get(session_id, {}).get(issue_number)
        if issue is None:
            return "Refused: that issue was not created by feedback_submit in the current session."
        return issue

    @staticmethod
    def _validate_assignees(value: Any) -> list[str] | str:
        if not isinstance(value, list) or len(value) > _MAX_ASSIGNEES:
            return f"Refused: assignees must be a list of at most {_MAX_ASSIGNEES} GitHub logins."
        if any(not isinstance(login, str) or not _LOGIN_RE.fullmatch(login) for login in value):
            return "Refused: assignees must contain valid GitHub logins, not mentions or URLs."
        unique: dict[str, str] = {}
        for login in value:
            unique.setdefault(login.casefold(), login)
        return list(unique.values())

    @staticmethod
    def _result(action: str, issue: _IssueRef, assignment: dict[str, Any] | None = None) -> str:
        return json.dumps(
            {
                "action": action,
                "issue_number": issue.number,
                "url": issue.url,
                **({"assignment": assignment} if assignment is not None else {}),
            },
            ensure_ascii=False,
        )

    async def _api(
        self,
        method: str,
        endpoint: str,
        payload: dict[str, Any] | None = None,
        *,
        deadline: float,
    ) -> Any:
        argv = (*self._command, "api", "--hostname", "github.com", "--method", method, endpoint)
        stdin_data = b""
        if payload is not None:
            argv += ("--input", "-")
            stdin_data = json.dumps(payload).encode("utf-8")
        outcome = await self._run_bounded(argv, stdin_data, deadline - _FALLBACK_TIMEOUT_SECONDS)
        if isinstance(outcome, str):
            code = "transport_error" if "before completion" in outcome else "unavailable"
            raise _AssignmentError(code, self._sanitize_text(outcome)[:500])
        stdout, stderr, returncode = outcome
        if returncode:
            code = "transport_error"
            message = stderr or "GitHub request failed."
            try:
                error = json.loads(stdout)
            except ValueError:
                error = None
            if isinstance(error, dict):
                if isinstance(error.get("message"), str):
                    message = error["message"]
                status = str(error.get("status", ""))
                if re.fullmatch(r"[45]\d{2}", status):
                    code = f"http_{status}"
            if code == "transport_error":
                match = re.search(r"\(HTTP ([45]\d{2})\)", stderr)
                if match:
                    code = f"http_{match.group(1)}"
            raise _AssignmentError(code, self._sanitize_text(message)[:500])
        if not stdout:
            return None
        try:
            return json.loads(stdout)
        except ValueError as exc:
            raise _AssignmentError("invalid_response", "GitHub returned invalid JSON.") from exc

    @staticmethod
    def _issue_assignees(payload: Any, issue: _IssueRef) -> list[str]:
        if (
            not isinstance(payload, dict)
            or type(payload.get("number")) is not int
            or payload["number"] != issue.number
            or payload.get("html_url") != issue.url
            or payload.get("repository_url") != f"https://api.github.com/repos/{_REPO}"
        ):
            raise _AssignmentError("invalid_response", "GitHub did not return the requested issue.")
        if "pull_request" in payload:
            raise _AssignmentError(
                "not_an_issue", "Assignment is limited to issues, not pull requests."
            )
        assignees = payload.get("assignees")
        if not isinstance(assignees, list) or any(
            not isinstance(user, dict)
            or not isinstance(user.get("login"), str)
            or not user["login"]
            for user in assignees
        ):
            raise _AssignmentError("invalid_response", "GitHub did not return an assignees list.")
        return [user["login"] for user in assignees]

    @staticmethod
    def _assignment_summary(
        requested: list[str],
        existing: list[str],
        errors: dict[str, _AssignmentError],
        *,
        uncertain: bool = False,
    ) -> dict[str, Any]:
        current = {login.casefold(): login for login in existing}
        confirmed = [
            current[login.casefold()] for login in requested if login.casefold() in current
        ]
        failures = []
        for login in requested:
            if login.casefold() in current:
                continue
            error = errors.get(login) or _AssignmentError(
                "not_applied",
                "GitHub did not apply this assignment; the response does not establish why.",
            )
            failures.append({"login": login, "code": error.code, "message": str(error)})
        if not failures:
            status = "succeeded"
        elif uncertain:
            status = "unknown"
        else:
            status = "partial" if confirmed else "failed"
        return {
            "status": status,
            "requested": requested,
            "confirmed": confirmed,
            "errors": failures,
            "fallback": {"status": "not_needed" if not failures else "not_applicable"},
        }

    async def _assign_issue(
        self,
        issue: _IssueRef,
        requested: list[str],
        existing: list[str],
        session_id: str,
        deadline: float,
    ) -> dict[str, Any]:
        current = {login.casefold() for login in existing}
        eligible: list[str] = []
        errors: dict[str, _AssignmentError] = {}
        for login in requested:
            if login.casefold() in current:
                continue
            try:
                response = await self._api(
                    "GET", f"repos/{_REPO}/assignees/{login}", deadline=deadline
                )
                if response is not None:
                    raise _AssignmentError(
                        "invalid_response", "GitHub did not confirm assignability."
                    )
                eligible.append(login)
            except _AssignmentError as exc:
                errors[login] = (
                    _AssignmentError(
                        "not_assignable",
                        "The user is not assignable or not visible in this repository.",
                    )
                    if exc.code == "http_404"
                    else exc
                )

        uncertain = False
        if eligible:
            try:
                payload = await self._api(
                    "POST",
                    f"repos/{_REPO}/issues/{issue.number}/assignees",
                    {"assignees": eligible},
                    deadline=deadline,
                )
                existing = self._issue_assignees(payload, issue)
            except _AssignmentError as exc:
                errors.update({login: exc for login in eligible})
                uncertain = exc.code in {
                    "transport_error",
                    "invalid_response",
                    "timeout",
                } or exc.code.startswith("http_5")
                if uncertain:
                    try:
                        payload = await self._api(
                            "GET", f"repos/{_REPO}/issues/{issue.number}", deadline=deadline
                        )
                        existing = self._issue_assignees(payload, issue)
                    except _AssignmentError as recovery_error:
                        for login in eligible:
                            errors[login] = _AssignmentError(
                                "verification_failed",
                                f"Assignment could not be confirmed: {str(recovery_error)[:400]}",
                            )
                    confirmed = {login.casefold() for login in existing}
                    uncertain = any(login.casefold() not in confirmed for login in eligible)

        assignment = self._assignment_summary(requested, existing, errors, uncertain=uncertain)
        await self._assignment_fallback(issue, assignment, session_id, deadline)
        return assignment

    async def _assignment_fallback(
        self, issue: _IssueRef, assignment: dict[str, Any], session_id: str, deadline: float
    ) -> None:
        if assignment["status"] == "succeeded" or isinstance(
            self._session_issue(session_id, issue.number), str
        ):
            return
        body = (
            "## Requested assignment\n\n"
            f"Assignment status: {assignment['status']}. Only confirmed owners were verified.\n\n"
            + "\n".join(
                f"- `{error['login']}`: {error['code']} - {error['message']}"
                for error in assignment["errors"]
            )
        )
        encoded, refusal = self._encode_body(body)
        if refusal:
            assignment["fallback"] = {"status": "failed", "message": refusal}
            return
        argv = (
            *self._command,
            "issue",
            "comment",
            str(issue.number),
            "--repo",
            _REPO,
            "--body-file",
            "-",
        )
        try:
            outcome = await self._run_bounded(
                argv, encoded, min(deadline, monotonic() + _FALLBACK_TIMEOUT_SECONDS)
            )
        except _AssignmentError as exc:
            assignment["fallback"] = {
                "status": "not_attempted" if exc.code == "deadline_exceeded" else "unknown",
                "message": str(exc),
            }
            return
        if isinstance(outcome, str):
            message = outcome
        elif outcome[2]:
            message = outcome[1] or "The assignment fallback comment failed."
        else:
            assignment["fallback"] = {"status": "recorded"}
            return
        assignment["fallback"] = {"status": "failed", "message": self._sanitize_text(message)[:500]}

    async def _run_bounded(
        self, argv: tuple[str, ...], stdin_data: bytes, deadline: float
    ) -> tuple[str, str, int] | str:
        remaining = min(_GH_TIMEOUT_SECONDS, deadline - monotonic())
        if remaining <= 0:
            raise _AssignmentError(
                "deadline_exceeded", "Time budget exhausted; request not attempted."
            )
        try:
            return await asyncio.wait_for(self._run(argv, stdin_data), timeout=remaining)
        except TimeoutError as exc:
            raise _AssignmentError(
                "timeout", "GitHub request timed out; its result is unconfirmed."
            ) from exc

    async def _run(self, argv: tuple[str, ...], stdin_data: bytes) -> tuple[str, str, int] | str:
        try:
            process = await asyncio.create_subprocess_exec(
                *argv,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env={**os.environ, "GH_PROMPT_DISABLED": "1"},
            )
        except FileNotFoundError:
            return "Feedback submission unavailable: GitHub CLI (`gh`) is not installed."
        except OSError as exc:
            return f"Feedback submission unavailable: {exc}"

        try:
            stdout, stderr = await process.communicate(stdin_data)
        except asyncio.CancelledError:
            if process.returncode is None:
                process.kill()
            await process.wait()
            raise
        except Exception as exc:
            if process.returncode is None:
                process.kill()
            await process.wait()
            return f"Feedback submission failed before completion: {exc}"

        return (
            stdout.decode("utf-8", errors="replace").strip(),
            stderr.decode("utf-8", errors="replace").strip(),
            int(process.returncode or 0),
        )

    async def execute(self, **kwargs: Any) -> str:
        from praestoclaw.feedback_bundle.state import load_state, render_result, save_state

        kwargs.pop("_bundle_attachment", None)
        action = str(kwargs.get("action") or "").strip().lower()
        session_id = str(kwargs.get("_plan_session_id") or kwargs.get("_session_id") or "").strip()
        context = {key: value for key, value in kwargs.items() if key.startswith("_")}
        bundle_id = str(kwargs.get("bundle_id") or "")
        if "image_ids" in kwargs and action not in {"create", "comment", "edit"}:
            return "Refused: image_ids are accepted only for create/comment/body-edit."
        if any(
            key not in self.parameters["properties"] for key in kwargs if not key.startswith("_")
        ):
            return "Refused: unsupported feedback parameter."
        if action in _BUNDLE_ACTIONS:
            if self.bundle_host is None:
                return "Feedback bundle unavailable: Host background delivery is not configured."
            try:
                if action == "bundle_prepare":
                    result = await self.bundle_host.prepare(
                        str(kwargs.get("original_text") or ""), session_id, **context
                    )
                elif action == "bundle_status":
                    result = await self.bundle_host.status(bundle_id, session_id, **context)
                else:
                    result = await self.bundle_host.start(
                        bundle_id, session_id, retry=action == "bundle_retry", **context
                    )
            except (ValueError, OSError) as exc:
                return f"Feedback bundle unavailable: {exc}"
            return json.dumps(result, ensure_ascii=False)

        state_path = None
        if bundle_id:
            if action not in {"create", "comment"}:
                return (
                    "Refused: bundle_id is accepted only for create/comment and bundle operations."
                )
            if self.bundle_host is None:
                return "Refused: feedback bundle Host is unavailable."
            try:
                state_path = self.bundle_host.resolve(bundle_id, session_id, **context)
                state = load_state(state_path)
            except (ValueError, OSError) as exc:
                return f"Refused: {exc}"
            if state.get("status") == "running":
                return (
                    "Refused: this bundle is running; query its status before changing its issue."
                )
            issue = state.get("issue", {})
            if action == "create" and issue.get("number"):
                return "Refused: this bundle already has a confirmed issue; use comment with that issue."
            if action == "create" and issue.get("status") == "unknown":
                return "Refused: prior creation is unconfirmed; use feedback_lookup before attaching to the original issue."
            if (
                issue.get("number")
                and kwargs.get("issue_number", issue["number"]) != issue["number"]
            ):
                return "Refused: this bundle belongs to a different issue."
            if issue.get("number"):
                kwargs.setdefault("issue_number", issue["number"])
            attachment = (
                render_result(state, include_association=False)
                if state.get("package")
                else f"调试包待交付：{bundle_id}\n包名：{state['package_name']}"
            )
            kwargs["_bundle_attachment"] = "\n\n## Feedback debug bundle\n" + attachment

        result = await self._execute_issue(**kwargs)
        if state_path is not None:
            state = load_state(state_path)
            try:
                submitted = json.loads(result)
            except ValueError:
                submitted = None
            if isinstance(submitted, dict) and submitted.get("issue_number"):
                state["issue"] = {
                    "status": "submitted",
                    "number": submitted["issue_number"],
                    "url": submitted["url"],
                }
                if submitted.get("comment_id"):
                    state["issue"]["comment_id"] = submitted["comment_id"]
            else:
                uncertain = any(
                    text in result.lower()
                    for text in (
                        "may have been created",
                        "before completion",
                        "timed out",
                        "unconfirmed",
                    )
                )
                state.setdefault("issue", {}).update(
                    status="unknown" if uncertain else "failed", error=result
                )
                number = kwargs.get("issue_number")
                if (
                    action == "comment"
                    and type(number) is int
                    and (
                        not isinstance(self._session_issue(session_id, number), str)
                        or (
                            self._lookup is not None
                            and self._lookup.can_comment(session_id, number)
                        )
                    )
                ):
                    state["issue"].update(
                        number=number, url=f"https://github.com/{_REPO}/issues/{number}"
                    )
            save_state(state_path, state)
        return result

    def _gh_upgrade_command(self) -> tuple[tuple[str, ...] | None, str]:
        if len(self._command) != 1 or sys.platform != "win32":
            return None, "Automatic upgrade is unavailable for this installation."
        executable = shutil.which(self._command[0])
        winget = shutil.which("winget")
        program_files = os.environ.get("ProgramFiles")
        if not executable or not program_files or not winget:
            return None, "GitHub CLI installation or WinGet could not be identified."
        expected = Path(program_files) / "GitHub CLI" / "gh.exe"
        if Path(executable).resolve() != expected.resolve():
            return (
                None,
                "GitHub CLI is not the recognized system installation; use its original installer.",
            )
        import ctypes

        try:
            elevated = bool(ctypes.windll.shell32.IsUserAnAdmin())
        except (AttributeError, OSError):
            elevated = False
        if not elevated:
            return (
                None,
                "Administrator permission required; PraestoClaw will not request elevation.",
            )
        try:
            folder = ctypes.create_unicode_buffer(260)
            if ctypes.windll.shell32.SHGetFolderPathW(None, 0x0026, None, 0, folder) != 0:
                return None, "Windows could not identify the protected WinGet installation root."
            system_program_files = Path(folder.value)
            if not system_program_files.is_absolute():
                return None, "Windows returned no valid protected WinGet installation root."
            updater = Path(winget).resolve(strict=True)
            protected_root = system_program_files.resolve() / "WindowsApps"
            trusted = (
                updater.is_file()
                and Path(program_files).resolve() == system_program_files.resolve()
                and updater.name.lower() == "winget.exe"
                and updater.parent.parent == protected_root
                and re.fullmatch(
                    r"Microsoft\.DesktopAppInstaller_\d+(?:\.\d+){3}_(?:x64|x86|arm64)__8wekyb3d8bbwe",
                    updater.parent.name,
                    re.IGNORECASE,
                )
                is not None
            )
        except (AttributeError, OSError, RuntimeError):
            trusted = False
        if not trusted:
            return (
                None,
                "WinGet is not a verified protected App Installer package executable; upgrade manually through the approved installation channel.",
            )
        return (
            str(updater),
            "upgrade",
            "--id",
            "GitHub.cli",
            "--exact",
            "--source",
            "winget",
            "--scope",
            "machine",
            "--silent",
            "--disable-interactivity",
            "--accept-source-agreements",
            "--accept-package-agreements",
        ), ""

    async def _ensure_gh_attachments(
        self, command: str, deadline: float, *, allow_upgrade: bool
    ) -> dict[str, str]:
        required = "2.99.0"
        manual = (
            "Ask the host owner to upgrade GitHub CLI to 2.99.0+ through its approved "
            "installation channel, then retry only missing screenshots on the existing issue. "
            "For a Windows WinGet installation, run in an approved administrator terminal: "
            "winget upgrade --id GitHub.cli --exact --silent --disable-interactivity."
        )

        def unavailable(code: str, message: str, version: str = "unknown") -> dict[str, str]:
            action = manual
            if code in {"cli_check_failed", "attach_unsupported", "upgrade_verification_failed"}:
                action = (
                    f"Ask the host owner to run gh --version and gh issue {command} --help, "
                    "verify the active executable/PATH and --attach support, and repair the "
                    "installation through its approved channel. Verify the existing issue before retrying."
                )
            return {
                "status": "unavailable",
                "code": code,
                "message": message,
                "installed_version": version,
                "required_version": required,
                "user_action": action,
            }

        async def capability() -> bool | None:
            outcome = await self._run_bounded(
                (*self._command, "issue", command, "--help"), b"", deadline
            )
            if isinstance(outcome, str) or outcome[2] != 0:
                return None
            return re.search(r"(?m)^\s+--attach\s", outcome[0]) is not None

        async def version() -> tuple[str, tuple[int, ...]] | None:
            outcome = await self._run_bounded((*self._command, "--version"), b"", deadline)
            if isinstance(outcome, str) or outcome[2] != 0:
                return None
            match = re.search(r"\bgh version (\d+)\.(\d+)\.(\d+)\b", outcome[0])
            if match is None:
                return None
            return ".".join(match.groups()), tuple(map(int, match.groups()))

        try:
            supported = await capability()
            if supported:
                return {"status": "ready", "required_version": required}
            installed = await version()
            if supported is None or installed is None:
                return unavailable(
                    "cli_check_failed",
                    "GitHub CLI capability/version check failed; no upgrade attempted.",
                )
            installed_text, installed_number = installed
            if installed_number >= (2, 99, 0):
                return unavailable(
                    "attach_unsupported",
                    "This GitHub CLI build does not expose --attach; no upgrade attempted.",
                    installed_text,
                )
            if not allow_upgrade:
                return unavailable(
                    "upgrade_not_allowed",
                    "GitHub CLI is too old. Only explicitly personal feedback may upgrade host software; shared or unknown scope cannot.",
                    installed_text,
                )
            async with self._gh_upgrade_lock:
                if await capability():
                    return {"status": "ready", "required_version": required}
                if self._gh_upgrade_attempted:
                    return unavailable(
                        "upgrade_already_attempted",
                        "Automatic upgrade was already attempted in this process; manual intervention is required.",
                        installed_text,
                    )
                upgrade, reason = self._gh_upgrade_command()
                if upgrade is None:
                    return unavailable("upgrade_unavailable", reason, installed_text)
                available = min(60.0, deadline - monotonic() - 35.0)
                if available < 15:
                    return unavailable(
                        "upgrade_deferred",
                        "Insufficient time for a bounded upgrade; no upgrade attempted.",
                        installed_text,
                    )
                self._gh_upgrade_attempted = True
                try:
                    outcome = await asyncio.wait_for(self._run(upgrade, b""), timeout=available)
                except TimeoutError:
                    return unavailable(
                        "upgrade_timeout",
                        "Automatic upgrade timed out; installation state is unconfirmed. Verify it manually before retrying.",
                        installed_text,
                    )
                if isinstance(outcome, str) or outcome[2] != 0:
                    return unavailable(
                        "upgrade_failed",
                        "Automatic upgrade failed or was blocked by installer policy; no elevation or authentication changes were attempted.",
                        installed_text,
                    )
                installed = await version()
                if not installed or installed[1] < (2, 99, 0) or not await capability():
                    return unavailable(
                        "upgrade_verification_failed",
                        "Installer completed but the active GitHub CLI still lacks verified attachment support. Check PATH and the installed version.",
                        installed[0] if installed else "unknown",
                    )
                return {
                    "status": "ready",
                    "upgrade": "succeeded",
                    "installed_version": installed[0],
                    "required_version": required,
                }
        except _AssignmentError:
            return unavailable(
                "cli_check_failed",
                "GitHub CLI prerequisite check timed out or could not complete. No upload was attempted.",
            )

    async def _write_with_images(
        self,
        argv: tuple[str, ...],
        body: bytes,
        images: list[Screenshot],
        deadline: float,
        *,
        allow_upgrade: bool = False,
    ) -> tuple[tuple[str, str, int] | str, dict[str, Any]]:
        report: dict[str, Any] = {"status": "unavailable", "items": []}
        reused = [image for image in images if image.github_url]
        images = [image for image in images if not image.github_url]
        if reused:
            body += (
                "\n\n## Screenshots\n"
                + "\n".join(f"![{image.image_id}]({image.github_url})" for image in reused)
            ).encode("utf-8")
        if not images:
            report = {
                "status": "succeeded",
                "items": [{"image_id": image.image_id, "status": "reused"} for image in reused],
                "urls": [image.github_url for image in reused],
            }
            try:
                return await self._run_bounded(argv, body, deadline), report
            except _AssignmentError:
                return (
                    "Feedback write is unconfirmed. Do not automatically retry; use feedback_lookup first.",
                    report,
                )
        command = argv[len(self._command) + 1]
        prerequisite = await self._ensure_gh_attachments(
            command, deadline, allow_upgrade=allow_upgrade
        )
        if prerequisite["status"] == "ready":
            try:
                permission = await self._api("GET", f"repos/{_REPO}", deadline=deadline)
                permissions = (
                    permission.get("permissions") if isinstance(permission, dict) else None
                )
                if not isinstance(permissions, dict) or type(permissions.get("push")) is not bool:
                    prerequisite = {
                        "status": "unavailable",
                        "code": "permission_check_failed",
                        "message": "GitHub returned no verifiable repository push permission.",
                        "user_action": "Ask the host owner to verify repository access; upgrading gh will not fix this.",
                    }
                elif not permissions["push"]:
                    prerequisite = {
                        "status": "unavailable",
                        "code": "push_permission_required",
                        "message": "The authenticated GitHub account lacks repository push access required for image uploads.",
                        "user_action": "Ask the repository owner to grant the appropriate access, then retry missing screenshots. Do not recreate the issue.",
                    }
            except _AssignmentError as exc:
                prerequisite = {
                    "status": "unavailable",
                    "code": "permission_check_failed",
                    "message": f"GitHub permission check failed ({exc.code}); missing permission was not established.",
                    "user_action": "Verify GitHub connectivity and the host account's repository access; retry missing screenshots after recovery.",
                }
        supported = prerequisite["status"] == "ready"
        report["prerequisite"] = prerequisite
        if not supported:
            report["notice"] = (
                "Screenshots were not uploaded. "
                + prerequisite["message"]
                + " "
                + prerequisite["user_action"]
            )
            if self._progress:
                await self._progress(report["notice"])
        with tempfile.TemporaryDirectory(prefix="praestoclaw-feedback-") as temporary:
            if supported:
                prepared, failures = await prepare_screenshots(
                    images, Path(temporary), deadline=min(deadline - 30, monotonic() + 45)
                )
            else:
                prepared = []
                failures = [
                    {
                        "image_id": image.image_id,
                        "status": "unavailable",
                        "reason": prerequisite["message"],
                        "code": prerequisite["code"],
                    }
                    for image in images
                ]
            report["items"] = failures
            report["items"] += [
                {"image_id": image.image_id, "status": "reused"} for image in reused
            ]
            report["urls"] = [image.github_url for image in reused]
            if reused:
                report["status"] = "partial" if failures else "succeeded"
            if failures:
                body += b"\n\n## Screenshot availability\nSome selected screenshots could not be attached."
            if len(body) + len(prepared) * 2048 > _MAX_BODY_BYTES:
                return "Refused: body leaves insufficient room for screenshot links.", report
            attach_args = tuple(
                value for image_id, path in prepared for value in ("--attach", f"{path}#{image_id}")
            )
            by_id = {image.image_id: image for image in images}
            try:
                self.images.begin_upload([by_id[image_id] for image_id, _ in prepared])
            except ValueError as exc:
                return f"Refused: {exc}", report
            try:
                outcome = await self._run_bounded((*argv, *attach_args), body, deadline)
            except _AssignmentError:
                report["status"] = "unknown"
                return (
                    "Feedback write is unconfirmed: GitHub request timed out. "
                    "Do not automatically retry creation or upload; use feedback_lookup first.",
                    report,
                )
            if isinstance(outcome, str):
                return (
                    "Feedback write is unconfirmed. Do not automatically retry; use feedback_lookup first.",
                    report,
                )
            stdout, stderr, returncode = outcome
            if not prepared:
                if returncode and report.get("notice"):
                    return (stdout, stderr + "\n" + report["notice"], returncode), report
                return outcome, report
            for _, path in prepared:
                stderr = stderr.replace(str(path), "[screenshot]")
            stdout = stdout.replace(temporary, "[temporary]")
            stderr = stderr.replace(temporary, "[temporary]")
            match = re.search(
                r"(?m)^https://github\.com/gim-home/PraestoClaw/issues/([1-9]\d*)(?:#issuecomment-([1-9]\d*))?\s*$",
                stdout,
            )
            verified = False
            attached_urls: list[str] = []
            confirmed: dict[str, str] = {}
            if match is not None:
                number, comment_id = match.groups()
                endpoint = (
                    f"repos/{_REPO}/issues/comments/{comment_id}"
                    if comment_id and command == "comment"
                    else f"repos/{_REPO}/issues/{number}"
                )
                try:
                    payload = await self._api("GET", endpoint, deadline=deadline)
                    published_body = payload.get("body") if isinstance(payload, dict) else None
                    verified = (
                        isinstance(payload, dict)
                        and payload.get("html_url") == match.group(0).strip()
                        and isinstance(published_body, str)
                        and published_body.startswith(body.decode("utf-8"))
                        and (command == "create" or number == argv[len(self._command) + 2])
                        and (command != "comment" or comment_id is not None)
                    )
                    if verified:
                        appended = str(published_body)[len(body.decode("utf-8")) :]
                        for image_id, _ in prepared:
                            matches = re.findall(
                                rf"!\[{re.escape(image_id)}\]\((https://github\.com/user-attachments/assets/"
                                r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})\)",
                                appended,
                            )
                            if len(matches) == 1:
                                confirmed[image_id] = matches[0]
                        attached_urls = list(confirmed.values())
                except _AssignmentError:
                    pass
            for image_id, url in confirmed.items():
                self.images.record_upload(by_id[image_id], url)
            complete = len(confirmed) == len(prepared)
            report["status"] = (
                "succeeded"
                if complete and not failures
                else "partial"
                if confirmed or reused
                else "unknown"
            )
            report["items"] += [
                {
                    "image_id": image_id,
                    "status": "succeeded" if image_id in confirmed else "unknown",
                }
                for image_id, _ in prepared
            ]
            if not complete:
                report["notice"] = (
                    "Some screenshot uploads are unconfirmed and blocked from reupload. Verify the existing issue; reuse confirmed image links rather than retrying the entire batch."
                )
            if verified:
                report["urls"] += attached_urls
                return (stdout, "", 0), report
            report["status"] = "unknown"
            return (
                "Feedback write is unconfirmed: "
                + (match.group(0).strip() if match else "GitHub returned no verifiable issue URL")
                + ". Do not automatically retry creation or upload; use feedback_lookup first.",
                report,
            )

    async def finalize_bundle(self, state: dict[str, Any], state_path: Path) -> None:
        """Append/update one marked result on the already confirmed fixed-repository issue."""
        from praestoclaw.feedback_bundle.state import render_result, save_state

        issue = state.get("issue", {})
        if not issue.get("number"):
            state["association"] = {
                "status": "failed",
                "error": "Issue 尚未确认，保留调试包供文字反馈恢复。",
            }
            save_state(state_path, state)
            return
        marker = f"<!-- praestoclaw-feedback-bundle:{state['bundle_id']} -->"
        body = marker + "\n" + render_result(state, include_association=False)
        body_hash = hashlib.sha256(body.encode("utf-8")).hexdigest()
        association = state.setdefault("association", {})
        if association.get("status") == "success" and association.get("body_hash") == body_hash:
            return
        deadline = monotonic() + _ASSIGNMENT_TIMEOUT_SECONDS
        endpoint = f"repos/{_REPO}/issues/{issue['number']}/comments"
        if state.get("deadline_at"):
            remaining = (
                datetime.fromisoformat(state["deadline_at"]) - datetime.now(UTC)
            ).total_seconds()
            deadline = min(deadline, monotonic() + remaining)
        try:
            comment_id = association.get("comment_id")
            if not comment_id:
                page = 1
                while True:
                    comments = await self._api(
                        "GET", f"{endpoint}?per_page=100&page={page}", deadline=deadline
                    )
                    if not isinstance(comments, list):
                        raise ValueError("GitHub did not return issue comments.")
                    existing = next(
                        (item for item in comments if marker in item.get("body", "")), None
                    )
                    if existing:
                        comment_id = existing["id"]
                        if existing["body"] == body:
                            association.update(
                                status="success", comment_id=comment_id, body_hash=body_hash
                            )
                            association.pop("error", None)
                            save_state(state_path, state)
                            return
                        break
                    if len(comments) < 100:
                        break
                    page += 1
            association.update(status="unknown")
            if comment_id:
                association["comment_id"] = comment_id
            save_state(state_path, state)
            result = await self._api(
                "PATCH" if comment_id else "POST",
                f"repos/{_REPO}/issues/comments/{comment_id}" if comment_id else endpoint,
                {"body": body},
                deadline=deadline,
            )
            if not isinstance(result, dict) or not result.get("id") or result.get("body") != body:
                raise ValueError("GitHub result comment is unconfirmed.")
            association.update(status="success", comment_id=result["id"], body_hash=body_hash)
            association.pop("error", None)
        except (_AssignmentError, ValueError, OSError) as exc:
            association.update(status="unknown", error=str(exc))
        save_state(state_path, state)

    async def _execute_issue(self, **kwargs: Any) -> str:
        action = str(kwargs.get("action") or "").strip().lower()
        if action not in _ACTIONS:
            return f"Refused: action must be one of {', '.join(sorted(_ACTIONS))}."
        if any(
            key not in self.parameters["properties"] for key in kwargs if not key.startswith("_")
        ):
            return "Refused: unsupported feedback parameter."

        # A promoted worker has an isolated execution session. The registry's
        # hidden, non-model-facing owner override keeps issue ownership and
        # diagnostics bound to the conversation that launched it.
        session_id = str(kwargs.get("_plan_session_id") or kwargs.get("_session_id") or "").strip()
        raw_title = kwargs.get("title")
        raw_body = kwargs.get("body")
        title: str = raw_title if isinstance(raw_title, str) else ""
        body: str = raw_body if isinstance(raw_body, str) else ""
        attachment = str(kwargs.get("_bundle_attachment") or "")
        try:
            images = self.images.resolve(
                kwargs.get("image_ids", []), session_id, kwargs.get("_metadata")
            )
        except ValueError as exc:
            return f"Refused: {exc}"
        if action == "create" and any(image.issue_url for image in images):
            existing = sorted({image.issue_url for image in images if image.issue_url})
            return (
                "Refused: these screenshots already belong to feedback at "
                + ", ".join(existing)
                + ". Use comment/edit on the existing issue instead of creating another."
            )
        if images and action == "edit" and not body:
            return "Refused: screenshots on edit require a replacement body."
        image_report: dict[str, Any] | None = None
        metadata = kwargs.get("_metadata")
        allow_cli_upgrade = (
            isinstance(metadata, dict)
            and not feedback_is_shared(metadata)
            and str(
                metadata.get("ctype") or metadata.get("teams_conversation_type") or ""
            ).casefold()
            == "personal"
        )

        def result(issue: _IssueRef, assignment: dict[str, Any] | None = None) -> str:
            payload = json.loads(self._result(action, issue, assignment))
            if image_report is not None:
                payload["attachments"] = image_report
            return json.dumps(payload, ensure_ascii=False)

        def failure(message: str) -> str:
            if image_report is None:
                return message
            return message + "\nAttachment status: " + json.dumps(image_report, ensure_ascii=False)

        def encode_body(value: str) -> tuple[bytes, str]:
            encoded, refusal = self._encode_body(value)
            if refusal:
                return encoded, refusal
            encoded += attachment.encode("utf-8")
            if len(encoded) > _MAX_BODY_BYTES:
                return (
                    b"",
                    f"Refused: body plus bundle information exceeds {_MAX_BODY_BYTES} bytes.",
                )
            if images and len(encoded) + len(images) * 2048 + 256 > _MAX_BODY_BYTES:
                return b"", "Refused: body leaves insufficient room for screenshot links."
            return encoded, ""

        if (
            "assignees" in kwargs
            and action not in {"create", "assign"}
            and not (action == "comment" and kwargs["assignees"] == [])
        ):
            return "Refused: assignees are accepted only for create or assign."
        assignees = self._validate_assignees(kwargs.get("assignees", []))
        if isinstance(assignees, str):
            return assignees
        deadline = monotonic() + _ASSIGNMENT_TIMEOUT_SECONDS
        if action == "assign":
            if "title" in kwargs or "body" in kwargs:
                return "Refused: assign does not accept title or body."
            if not assignees:
                return "Refused: assign requires nonempty assignees."
            issue_number = kwargs.get("issue_number")
            if type(issue_number) is not int or issue_number < 1:
                return "Refused: issue_number must be a positive integer."
            if not session_id:
                return "Refused: a trusted session is required to assign an issue."
            issue = _IssueRef(issue_number, f"https://github.com/{_REPO}/issues/{issue_number}")
            try:
                payload = await self._api(
                    "GET", f"repos/{_REPO}/issues/{issue.number}", deadline=deadline
                )
                existing = self._issue_assignees(payload, issue)
            except _AssignmentError as exc:
                return self._result(
                    action,
                    issue,
                    self._assignment_summary(assignees, [], {login: exc for login in assignees}),
                )
            assignment = await self._assign_issue(issue, assignees, existing, session_id, deadline)
            return self._result(action, issue, assignment)

        if action == "create":
            refusal = self._validate_title(title)
            if refusal:
                return refusal
            metadata = kwargs.get("_metadata")
            if title.startswith("[Feedback] ") and feedback_is_shared(metadata) and session_id:
                body = self._append_session_diagnostics(
                    body, session_id, reserve=len(attachment.encode("utf-8"))
                )
            body_bytes, refusal = encode_body(body)
            if refusal:
                return refusal
            if not session_id:
                return "Refused: a trusted session is required to create feedback."
            sanitized_title = self._sanitize_text(title)
            try:
                sanitized_title.encode("utf-8")
            except UnicodeEncodeError:
                return "Refused: title contains invalid Unicode."
            argv = (
                *self._command,
                "issue",
                "create",
                "--repo",
                _REPO,
                "--title",
                sanitized_title,
                "--body-file",
                "-",
                "--label",
                "bug",
            )
            try:
                if images:
                    outcome, image_report = await self._write_with_images(
                        argv,
                        body_bytes,
                        images,
                        deadline,
                        allow_upgrade=allow_cli_upgrade,
                    )
                else:
                    outcome = (
                        await self._run_bounded(
                            argv, body_bytes, deadline - _FALLBACK_TIMEOUT_SECONDS
                        )
                        if assignees
                        else await self._run(argv, body_bytes)
                    )
            except _AssignmentError as exc:
                return (
                    f"Feedback issue may have been created, but creation is unconfirmed: {exc} "
                    "Do not automatically retry creation."
                )
            if isinstance(outcome, str):
                return failure(outcome)
            stdout_text, stderr_text, returncode = outcome
            match = _ISSUE_URL_RE.search(stdout_text)
            if returncode != 0:
                if match is not None:
                    return failure(
                        "Feedback issue may have been created, but creation is unconfirmed: "
                        f"{match.group(0)} (GitHub CLI exit {returncode}). "
                        "Do not automatically retry creation; use feedback_lookup to verify "
                        "the issue and its attachments first."
                    )
                detail = stderr_text or stdout_text or "no error output"
                return failure(f"Feedback submission failed (exit {returncode}): {detail}")
            if match is None:
                return failure(
                    "Feedback issue may have been created, but its URL could not be parsed."
                )
            created_issue = _IssueRef(number=int(match.group("number")), url=match.group(0))
            self._issues_by_session.setdefault(session_id, {})[created_issue.number] = created_issue
            self.images.record_issue(images, created_issue.url)
            if assignees:
                assignment = await self._assign_issue(
                    created_issue, assignees, [], session_id, deadline
                )
                return result(created_issue, assignment)
            return result(created_issue)

        if action == "edit" and not title and not body:
            return "Refused: edit requires a title or body."

        session_issue = self._session_issue(session_id, kwargs.get("issue_number"))
        if isinstance(session_issue, str):
            number = kwargs.get("issue_number")
            if (
                action != "comment"
                or type(number) is not int
                or self._lookup is None
                or not self._lookup.can_comment(session_id, number)
            ):
                return session_issue
            try:
                await self._lookup.read_issue(number)
            except (OSError, ValueError, KeyError, TypeError, TimeoutError) as exc:
                return f"Feedback comment refused: issue reread failed: {self._sanitize_text(str(exc))}. Do not create a replacement issue."
            session_issue = _IssueRef(number, f"https://github.com/{_REPO}/issues/{number}")

        if action == "comment":
            body_bytes, refusal = encode_body(body)
            if refusal:
                return refusal
            argv = (
                *self._command,
                "issue",
                "comment",
                str(session_issue.number),
                "--repo",
                _REPO,
                "--body-file",
                "-",
            )
        else:
            argv_parts = [
                *self._command,
                "issue",
                "edit",
                str(session_issue.number),
                "--repo",
                _REPO,
            ]
            if title:
                refusal = self._validate_title(title)
                if refusal:
                    return refusal
                sanitized_title = self._sanitize_text(title)
                try:
                    sanitized_title.encode("utf-8")
                except UnicodeEncodeError:
                    return "Refused: title contains invalid Unicode."
                argv_parts.extend(("--title", sanitized_title))
            if body:
                body_bytes, refusal = encode_body(body)
                if refusal:
                    return refusal
                argv_parts.extend(("--body-file", "-"))
            else:
                body_bytes = b""
            argv = tuple(argv_parts)

        if images:
            outcome, image_report = await self._write_with_images(
                argv,
                body_bytes,
                images,
                deadline,
                allow_upgrade=allow_cli_upgrade,
            )
        else:
            outcome = await self._run(argv, body_bytes)
        if isinstance(outcome, str):
            return failure(outcome)
        stdout_text, stderr_text, returncode = outcome
        if returncode != 0:
            if _ISSUE_URL_RE.search(stdout_text):
                return failure(
                    f"Feedback {action} is unconfirmed: {session_issue.url}. "
                    "Do not automatically retry; use feedback_lookup to verify first."
                )
            detail = stderr_text or stdout_text or "no error output"
            return failure(f"Feedback submission failed (exit {returncode}): {detail}")
        self.images.record_issue(images, session_issue.url)
        if action == "comment" and kwargs.get("bundle_id"):
            payload = json.loads(result(session_issue))
            if match := re.search(r"#issuecomment-(\d+)", stdout_text):
                payload["comment_id"] = int(match[1])
            return json.dumps(payload, ensure_ascii=False)
        return result(session_issue)
