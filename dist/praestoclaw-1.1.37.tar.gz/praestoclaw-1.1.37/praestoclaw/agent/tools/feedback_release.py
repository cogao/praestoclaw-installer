"""Publication facts from the existing channel-specific installer mirrors."""

from __future__ import annotations

import base64
import re
from collections.abc import Awaitable, Callable
from typing import Any
from urllib.parse import quote

from packaging.version import Version

_REPO = "gim-home/PraestoClaw"
_MIRRORS = {
    "production": ("cogao/praestoclaw-installer", "v"),
    "staging": ("xchunzhao/praestoclaw-installer-staging", "staging-v"),
}
Read = Callable[[str, str], Awaitable[Any]]


def _version(value: str) -> Version:
    parsed = Version(value)
    if parsed.local:
        raise ValueError("Local builds have unknown publication provenance")
    return parsed


async def _contains(read: Read, fix: str, source: str) -> bool | None:
    comparison = await read(_REPO, f"compare/{fix}...{source}")
    status = comparison.get("status")
    if status in {"ahead", "identical"}:
        return True
    if status in {"behind", "diverged"}:
        return False
    return None


async def _record(read: Read, mirror: str, prefix: str, ref: str) -> dict[str, Any]:
    commit = await read(mirror, f"commits/{quote(ref, safe='')}")
    sha = commit["sha"]
    if not re.fullmatch(r"[0-9a-f]{40}", sha):
        raise ValueError("Invalid mirror commit")
    pointer = await read(mirror, f"contents/latest.txt?ref={sha}")
    version = base64.b64decode(pointer["content"]).decode().strip()
    _version(version)
    tag = prefix + version
    tagged = await read(mirror, f"commits/{quote(tag, safe='')}")
    tag_sha = tagged["sha"]
    match = re.fullmatch(
        rf"(?:staging )?release {re.escape(tag)} \(source ([0-9a-f]{{40}})\)",
        tagged["commit"]["message"].strip(),
    )
    if not match:
        raise ValueError("Mirror tag lacks a matching version/source publication record")
    if tag_sha != sha:
        tagged_pointer = await read(mirror, f"contents/latest.txt?ref={tag_sha}")
        if tagged_pointer.get("sha") != pointer.get("sha") or not pointer.get("sha"):
            raise ValueError("Mirror latest pointer differs from the publication tag")
    entries = await read(mirror, f"contents/dist?ref={sha}")
    wheels = []
    for entry in entries:
        name = entry.get("name", "")
        if name.startswith("praestoclaw-") and name.endswith(".whl"):
            parts = name.split("-")
            if (
                len(parts) >= 5
                and _version(parts[1]) == _version(version)
                and entry.get("size", 0) > 0
            ):
                wheels.append(
                    {"name": name, "sha": entry.get("sha"), "url": entry.get("download_url")}
                )
    if not wheels:
        raise ValueError("Published version has no available PraestoClaw wheel")
    if tag_sha != sha:
        tagged_entries = await read(mirror, f"contents/dist?ref={tag_sha}")
        tagged_blobs = {item.get("name"): item.get("sha") for item in tagged_entries}
        if any(
            not wheel["sha"] or tagged_blobs.get(wheel["name"]) != wheel["sha"] for wheel in wheels
        ):
            raise ValueError("Available wheel differs from its publication tag")
    return {
        "version": version,
        "mirror": mirror,
        "mirror_commit": sha,
        "tag": tag,
        "publication_commit": tag_sha,
        "source_sha": match.group(1),
        "wheels": wheels,
        "source": f"https://github.com/{mirror}/tree/{sha}",
    }


async def release_status(
    read: Read,
    pr: dict[str, Any],
    channel: str,
    current_version: str | None = None,
    current_source_sha: str | None = None,
    current_build: str = "unknown",
) -> dict[str, Any]:
    result: dict[str, Any] = {
        "status": "success",
        "pr": pr,
        "publication": "unknown",
        "target_contains_fix": None,
        "channel": channel,
    }
    if not pr.get("merged"):
        result["publication"] = "not_merged"
        return result
    fix = pr.get("merge_commit_sha", "")
    if channel not in _MIRRORS or not re.fullmatch(r"[0-9a-f]{40}", fix or ""):
        result.update(status="partial", reason="Channel or merged source commit is unknown")
        return result
    mirror, prefix = _MIRRORS[channel]
    try:
        latest = await _record(read, mirror, prefix, "main")
        latest["contains_fix"] = await _contains(read, fix, latest["source_sha"])
        result["available_release"] = latest
        result["publication"] = "published" if latest["contains_fix"] else "unknown"
        if latest["contains_fix"] is False:
            result["reason"] = (
                "Current channel artifact does not contain this merge; other/cherry-picked publication is not established"
            )
        if current_version:
            _version(current_version)
            try:
                current = await _record(read, mirror, prefix, prefix + current_version)
                if _version(current["version"]) != _version(current_version):
                    raise ValueError(
                        "Requested version tag points to a different published version"
                    )
                current["contains_fix"] = await _contains(read, fix, current["source_sha"])
                result["version_record"] = current
                if current_build == "published":
                    result["target_contains_fix"] = current["contains_fix"]
                    result["target_provenance"] = (
                        "Confirmed supported mirror installation mapped to its version publication record"
                    )
            except (ValueError, KeyError, TypeError, OSError) as exc:
                result["version_record_error"] = str(exc)
                result["status"] = "partial"
        if current_source_sha:
            if not re.fullmatch(r"[0-9a-f]{40}", current_source_sha):
                raise ValueError("Invalid verified target source SHA")
            result["target_contains_fix"] = await _contains(read, fix, current_source_sha)
            result["target_source_sha"] = current_source_sha
        elif current_build != "published" or "version_record" not in result:
            result["target_provenance"] = (
                "unknown: version alone does not identify the user's build; same-version artifacts can be republished"
            )
    except (ValueError, KeyError, TypeError, OSError) as exc:
        result.update(status="partial", reason=str(exc))
    return result
