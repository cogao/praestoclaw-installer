"""Agent-facing configuration tool for meeting task-group automation."""

from __future__ import annotations

import asyncio
import json
from typing import Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.config.schema import ChannelType
from praestoclaw.meeting_automation.models import RoutingContext
from praestoclaw.meeting_automation.service import (
    MeetingAutomationService,
    is_short_meeting_url,
    normalize_meeting_chat_id,
)
from praestoclaw.security.praesto_tag_exp import praesto_tag_exp_is_active
from praestoclaw.security.risk import RiskAssessment, RiskPrompt, RiskScore


class MeetingAutomationTool(Tool):
    """Configure a task-flow template for one meeting series/chat."""

    risk_range = (0, 8)

    def __init__(self, service: MeetingAutomationService) -> None:
        self._service = service
        # Reconcile and one-shot launches both update the same durable instance
        # records. Serialize mutations so a manual scan cannot race a firing job.
        self._operation_lock = asyncio.Lock()

    @property
    def name(self) -> str:
        return "meeting_automation"

    @property
    def description(self) -> str:
        return (
            "Manage persistent meeting-relative or weekly task groups for one Teams meeting series. "
            "This tool automatically queries calendar occurrences for the target meeting series "
            "and uses them to calculate and update scheduling, including on initial configuration. "
            "You do not need to enable or call calendar MCP to look up meeting times before configuring "
            "meeting automation. Supply the task definitions; this tool returns scheduling results "
            "or a specific error. "
            "Before every create, update, delete, replacement, enable, or disable, call status and pass its version "
            "as expected_version. Use history for audit. During a meeting goal turn, call "
            "finish_task_group only when the current instance is done or concretely blocked. "
            "Task auto_reply controls automatic delivery of done/blocked final responses to the meeting chat. "
            "For ad hoc testing, use run_task, reschedule_next, or cancel_next with task_key; "
            "the current meeting chat is resolved automatically. run_task runs an extra test; "
            "reschedule_next/cancel_next affect only the next scheduled execution, not the series. "
            "Use these actions instead of simulating a task in chat. "
            "disable retains configuration and cancels all unfinished executions, including running and user waits. "
            "enable resumes future scheduling without reviving cancelled executions. "
            "Use task_key with enable/disable to control one task; omit it for the whole series. "
            "run_task also works while disabled and needs no calendar occurrence or refresh. "
            "Use delete_task to remove an individual task. "
            "Task updates replace executions that have not started. Executions already started, "
            "including user waits and retries, continue with their original task definition. "
            "For EVERY request to configure, change, refresh, enable, disable, or inspect "
            "meeting automation, call this tool in the current turn. Never infer live "
            "configuration or ownership from chat history or a prior assistant reply."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": [
                        "replace_all",
                        "create_task",
                        "update_task",
                        "delete_task",
                        "status",
                        "history",
                        "refresh",
                        "disable",
                        "enable",
                        "run_task",
                        "reschedule_next",
                        "cancel_next",
                        "reconcile",
                        "run_instance",
                        "run_weekly",
                        "finish_task_group",
                    ],
                    "description": (
                        "status reads current state/version; create_task, update_task, delete_task, "
                        "replace_all, enable, and disable require expected_version; history reads revisions; "
                        "refresh immediately re-reads that meeting series and reschedules its "
                        "nearest occurrence; disable retains configuration and cancels all unfinished executions. "
                        "enable resumes future scheduling, without reviving cancelled instances or catching up missed triggers. "
                        "enable/disable target one task with task_key, otherwise the whole series. "
                        "run_task queues an extra execution now, bypassing its original timing "
                        "and keeping the normal schedule; it can be repeated for testing, even while disabled. "
                        "It needs no calendar occurrence or refresh. "
                        "reschedule_next changes only its next execution time using run_at; "
                        "cancel_next skips only its next execution. These testing controls use "
                        "task_key in the current chat, without meeting or instance IDs, and "
                        "may be overwritten by refresh. Use update_task/delete_task for the series. "
                        "reconcile and run_instance are scheduler-owned internal actions; "
                        "finish_task_group is reserved for the current meeting goal turn."
                    ),
                },
                "meeting_url": {
                    "type": "string",
                    "description": (
                        "Teams meeting chat/join URL. Required when configuring outside the "
                        "target meeting chat."
                    ),
                },
                "meeting_chat_id": {
                    "type": "string",
                    "description": "Internal canonical meeting thread id used by scheduled jobs.",
                },
                "task_groups": {
                    "type": "array",
                    "description": (
                        "Task definitions for replace_all, or exactly one definition for create_task/update_task. Use one "
                        "entry per distinct timing point; for example, -60 and -30 minutes "
                        "before a meeting are TWO pre entries, never one prompt that waits. "
                        "delete_task uses task_key and an empty list to remove an individual task. "
                        "replace_all with an empty list or deleting the last task removes the "
                        "meeting configuration."
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "key": {
                                "type": "string",
                                "description": "Stable unique key such as pre-kb-reminder.",
                            },
                            "phase": {"type": "string", "enum": ["pre", "post"]},
                            "schedule": {
                                "oneOf": [
                                    {
                                        "type": "object",
                                        "properties": {
                                            "type": {
                                                "type": "string",
                                                "enum": ["meeting_relative"],
                                            },
                                            "anchor": {"type": "string", "enum": ["start", "end"]},
                                            "offset_minutes": {
                                                "type": "integer",
                                                "minimum": 0,
                                                "maximum": 10080,
                                            },
                                        },
                                        "required": ["type", "anchor", "offset_minutes"],
                                        "additionalProperties": False,
                                    },
                                    {
                                        "type": "object",
                                        "properties": {
                                            "type": {"type": "string", "enum": ["weekly"]},
                                            "weekday": {
                                                "type": "integer",
                                                "minimum": 1,
                                                "maximum": 7,
                                            },
                                            "local_time": {
                                                "type": "string",
                                                "pattern": "^(?:[01]\\d|2[0-3]):[0-5]\\d$",
                                            },
                                        },
                                        "required": ["type", "weekday", "local_time"],
                                        "additionalProperties": False,
                                    },
                                ],
                            },
                            "prompt": {"type": "string"},
                            "enabled": {
                                "type": "boolean",
                                "description": "Whether to schedule this task automatically. Omit to preserve its current state; new tasks default to true.",
                            },
                            "auto_reply": {
                                "type": "boolean",
                                "description": (
                                    "Automatically send done and blocked final responses to the meeting chat. "
                                    "New tasks default to true; omit to preserve the existing value. "
                                    "When false, explicit message-sending tools still work, and questions "
                                    "requiring a user answer must be sent through those tools. "
                                    "Failure alerts are unaffected."
                                ),
                            },
                            "skills": {
                                "type": "array",
                                "maxItems": 100,
                                "description": (
                                    "Explicit Group Skills bound to this meeting chat. Preserve each "
                                    "repository URL supplied by the user. Omit repo_url only for an "
                                    "exact same-named bundled skill; an external repository is "
                                    "installed as the authoritative same-named version."
                                ),
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "name": {"type": "string"},
                                        "repo_url": {
                                            "type": "string",
                                            "description": ("Repository URL supplied by the user."),
                                        },
                                    },
                                    "required": ["name"],
                                    "additionalProperties": False,
                                },
                            },
                            "mentions": {
                                "type": "array",
                                "items": {"type": "string"},
                                "maxItems": 500,
                                "description": (
                                    "People to natively @mention in this task's automatic final reply. Preserve the "
                                    "user's exact full or partial name/UPN selector; the Teams "
                                    "bridge resolves it uniquely against the target chat's live "
                                    "roster. Use ['all'] for every current chat member. Supply "
                                    "this when the automatic final reply should notify/remind/tell/ask a person; "
                                    "never rely only on spelling @Name in prompt text. "
                                    "When auto_reply is false, no automatic @mentions are sent. "
                                    "Explicit messages use the sending tool's own mention parameters."
                                ),
                            },
                        },
                        "required": ["key", "phase", "schedule", "prompt"],
                        "additionalProperties": False,
                    },
                },
                "instance_id": {
                    "type": "string",
                    "description": "Internal scheduled task-group instance id.",
                },
                "task_key": {
                    "type": "string",
                    "description": "Registered task name; required for run_task/reschedule_next/cancel_next/delete_task. Optional for enable/disable to target one task.",
                },
                "run_at": {
                    "type": "string",
                    "description": (
                        "New execution time for reschedule_next, in ISO 8601 format. "
                        "Include a timezone offset, or omit it to use the meeting's timezone."
                    ),
                },
                "outcome": {"type": "string", "enum": ["done", "blocked"]},
                "note": {"type": "string"},
                "expected_version": {"type": "integer", "minimum": 0},
                "version": {"type": "integer", "minimum": 1},
            },
            "required": ["action"],
            "additionalProperties": False,
        }

    @property
    def metadata(self) -> ToolMetadata:
        # Registered only while praesto_tag_exp is enabled, then injected into
        # every shared group session like the team-knowledge experiment tools.
        return ToolMetadata(category="builtin", tier="core", timeout=3600)

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        action = str(args.get("action") or "")
        if action in {"status", "history"}:
            return RiskScore(0, reason="Read meeting automation status")
        if action == "refresh":
            return RiskScore(3, reason="Refresh one meeting series and replace its scheduled jobs")
        if action == "run_task":
            return RiskScore(2, reason="Test a registered task in the current meeting")
        if action in {"reschedule_next", "cancel_next"}:
            return RiskScore(3, reason="Change only the next task execution in the current meeting")
        if action in {"reconcile", "run_instance", "finish_task_group"}:
            return RiskScore(1, reason="Run an already-approved meeting automation job")
        if action == "run_weekly":
            return RiskScore(2, reason="Continue an existing meeting automation")
        if action in {"enable", "disable"}:
            return RiskScore(
                3, reason="Resume automation or stop it and cancel unfinished executions"
            )
        if action == "delete_task" or (action == "replace_all" and args.get("task_groups") == []):
            return RiskScore(
                3, reason="Delete meeting automation configuration and cancel executions"
            )
        prompts = [
            f"{item.get('key')}: {str(item.get('prompt'))[:200]}"
            for item in (args.get("task_groups") or [])
            if isinstance(item, dict) and item.get("prompt")
        ]
        return RiskPrompt(
            context=(
                "Create unattended, recurring meeting task groups.\n"
                + "\n".join(prompts or ["Existing saved prompts are being updated."])
            ),
            range=(2, 8),
            factors=(
                "2: Summarization and local reads only",
                "3: Read Microsoft 365 data",
                "4: Persist automation settings",
                "5: Modify files or issue notifications",
                "6: Send to other people",
                "7: Broad multi-system actions",
                "8: Destructive or irreversible actions",
            ),
        )

    async def execute(self, **kwargs: Any) -> str:
        action = str(kwargs.get("action") or "")
        metadata = kwargs.get("_metadata")
        metadata = metadata if isinstance(metadata, dict) else {}
        meeting_url = str(kwargs.get("meeting_url") or "").strip()
        if not kwargs.get("meeting_chat_id") and is_short_meeting_url(meeting_url):
            current = normalize_meeting_chat_id(str(metadata.get("cid") or ""))
            if current:
                kwargs["meeting_chat_id"] = current
                kwargs["meeting_url"] = ""
        scope_error = _praesto_tag_exp_scope_error(kwargs)
        if scope_error:
            return scope_error
        try:
            if action in {"run_task", "reschedule_next", "cancel_next"}:
                meeting_chat_id = normalize_meeting_chat_id(str(metadata.get("cid") or ""))
                if not meeting_chat_id:
                    return f"Error: {action} requires the current meeting chat context."
                if (
                    kwargs.get("meeting_url")
                    or kwargs.get("meeting_chat_id")
                    or kwargs.get("instance_id")
                ):
                    return f"Error: {action} uses task_key in the current chat; omit meeting and instance IDs."
                task_key = str(kwargs.get("task_key") or "").strip()
                if not task_key:
                    return f"Error: {action} requires task_key."
                async with self._operation_lock:
                    result = await self._service.control_task(
                        meeting_chat_id,
                        task_key,
                        action=action,
                        run_at=str(kwargs.get("run_at") or ""),
                    )
                return json.dumps(result, ensure_ascii=False, indent=2)
            if action == "status":
                meeting_chat_id = _meeting_chat_id(kwargs)
                if not meeting_chat_id:
                    return "Error: status requires the current meeting chat context."
                return json.dumps(
                    self._service.status(meeting_chat_id), ensure_ascii=False, indent=2
                )
            if action == "history":
                meeting_chat_id = _meeting_chat_id(kwargs)
                if not meeting_chat_id:
                    return "Error: history requires the current meeting chat context."
                version = kwargs.get("version")
                return json.dumps(
                    self._service.history(
                        meeting_chat_id, int(version) if version is not None else None
                    ),
                    ensure_ascii=False,
                    indent=2,
                )
            if action == "refresh":
                meeting_chat_id = _meeting_chat_id(kwargs)
                if not meeting_chat_id:
                    return "Error: refresh requires meeting_url or the target meeting chat context."
                template = self._service.store.get_template(meeting_chat_id)
                if template is None:
                    return "Error: meeting automation is not configured."
                async with self._operation_lock:
                    stats = await self._service.refresh(meeting_chat_id)
                return "Meeting series refreshed. " + json.dumps(stats, ensure_ascii=False)
            if action in {"replace_all", "create_task", "update_task", "delete_task"}:
                meeting_url = str(kwargs.get("meeting_url") or "").strip()
                meeting_chat_id = _meeting_chat_id(kwargs)
                if not meeting_chat_id:
                    return f"Error: {action} requires a Teams meeting_url or meeting chat context."
                task_groups = kwargs.get("task_groups", [])
                if not isinstance(task_groups, list) or not all(
                    isinstance(item, dict) for item in task_groups
                ):
                    return f"Error: {action} requires task_groups as an array of objects."
                if kwargs.get("expected_version") is None:
                    return (
                        "Error: configuration changes require expected_version; "
                        "call status and use its current version."
                    )
                async with self._operation_lock:
                    template, stats = await self._service.mutate(
                        operation=action,
                        meeting_chat_id=meeting_chat_id,
                        meeting_url=meeting_url,
                        routing=_routing(kwargs),
                        expected_version=int(kwargs["expected_version"]),
                        task_groups_patch=task_groups,
                        task_key=str(kwargs.get("task_key") or ""),
                        provenance=_provenance(kwargs),
                    )
                phases = [
                    f"{task.key}: {task.phase} ({task.schedule.type})"
                    for task in template.task_groups
                ]
                if self._service.store.get_template(template.meeting_chat_id) is None:
                    return "Meeting automation configuration removed. " + json.dumps(
                        stats, ensure_ascii=False
                    )
                result_heading = (
                    "Meeting automation configured.\n"
                    if not stats.get("error")
                    else "Meeting automation saved but NOT scheduled.\n"
                )
                return result_heading + (
                    f"  Meeting: {template.subject or template.meeting_chat_id}\n"
                    f"  Task groups: {', '.join(phases)}\n"
                    f"  Next series check: {template.tracker_scheduled_for}\n"
                    f"  Reconcile: {json.dumps(stats, ensure_ascii=False)}"
                )
            if action in {"enable", "disable"}:
                meeting_chat_id = _meeting_chat_id(kwargs)
                if not meeting_chat_id:
                    return (
                        f"Error: {action} requires meeting_url or the target meeting chat context."
                    )
                if kwargs.get("expected_version") is None:
                    return "Error: configuration changes require expected_version; call status and use its current version."
                async with self._operation_lock:
                    task_key = str(kwargs.get("task_key") or "")
                    expected_version = int(kwargs["expected_version"])
                    if action == "enable":
                        stats = await self._service.enable(
                            meeting_chat_id, task_key=task_key, expected_version=expected_version
                        )
                    else:
                        stats = self._service.disable(
                            meeting_chat_id, task_key=task_key, expected_version=expected_version
                        )
                return json.dumps({"action": action, **stats}, ensure_ascii=False)
            if action == "reconcile":
                meeting_chat_id = _meeting_chat_id(kwargs)
                if not meeting_chat_id:
                    return "Error: reconcile requires meeting_chat_id."
                error = self._validate_tracker_call(meeting_chat_id, kwargs)
                if error:
                    return error
                async with self._operation_lock:
                    stats = await self._service.reconcile(meeting_chat_id)
                return json.dumps(stats, ensure_ascii=False)
            if action == "run_instance":
                instance_id = str(kwargs.get("instance_id") or "").strip()
                if not instance_id:
                    return "Error: run_instance requires instance_id."
                error = self._validate_instance_call(instance_id, kwargs)
                if error:
                    return error
                return await self._service.run_instance(instance_id)
            if action == "finish_task_group":
                instance_id = str(kwargs.get("instance_id") or "").strip()
                if not instance_id:
                    return "Error: finish_task_group requires instance_id."
                metadata = kwargs.get("_metadata")
                metadata = metadata if isinstance(metadata, dict) else {}
                return self._service.finish_task_group(
                    instance_id=instance_id,
                    outcome=str(kwargs.get("outcome") or ""),
                    note=str(kwargs.get("note") or ""),
                    metadata=metadata,
                )
            if action == "run_weekly":
                meeting_chat_id = _meeting_chat_id(kwargs)
                task_key = str(kwargs.get("task_key") or "")
                if not meeting_chat_id or not task_key:
                    return "Error: run_weekly requires meeting_chat_id and task_key."
                error = self._validate_weekly_call(meeting_chat_id, task_key, kwargs)
                if error:
                    return error
                return await self._service.run_weekly(meeting_chat_id, task_key)
        except (ValueError, RuntimeError) as exc:
            return f"Error: {exc}"
        return f"Error: unknown action {action!r}."

    def _validate_tracker_call(self, meeting_chat_id: str, kwargs: dict[str, Any]) -> str | None:
        metadata = kwargs.get("_metadata")
        metadata = metadata if isinstance(metadata, dict) else {}
        template = self._service.store.get_template(meeting_chat_id)
        if template is None:
            return "Error: meeting automation is not configured."
        if metadata.get("source") != "cron" or metadata.get("job_name") != template.tracker_job_id:
            return "Error: reconcile is reserved for the meeting's tracker job."
        return None

    def _validate_instance_call(self, instance_id: str, kwargs: dict[str, Any]) -> str | None:
        metadata = kwargs.get("_metadata")
        metadata = metadata if isinstance(metadata, dict) else {}
        instance = self._service.store.get_instance(instance_id)
        if instance is None:
            return f"Error: unknown meeting task-group instance {instance_id!r}."
        if (
            metadata.get("source") != "cron"
            or metadata.get("job_name") != instance.scheduler_job_id
        ):
            return "Error: run_instance is reserved for its scheduled one-shot job."
        return None

    def _validate_weekly_call(
        self, meeting_chat_id: str, task_key: str, kwargs: dict[str, Any]
    ) -> str | None:
        raw_metadata = kwargs.get("_metadata")
        metadata: dict[str, Any] = raw_metadata if isinstance(raw_metadata, dict) else {}
        from praestoclaw.meeting_automation.service import _weekly_job_id

        if metadata.get("source") != "cron" or metadata.get("job_name") != _weekly_job_id(
            meeting_chat_id, task_key
        ):
            return "Error: run_weekly is reserved for its weekly cron job."
        return None


def _meeting_chat_id(kwargs: dict[str, Any]) -> str:
    explicit = str(kwargs.get("meeting_chat_id") or kwargs.get("meeting_url") or "").strip()
    if explicit:
        return normalize_meeting_chat_id(explicit)
    metadata = kwargs.get("_metadata")
    return normalize_meeting_chat_id(
        str(metadata.get("cid") or "") if isinstance(metadata, dict) else ""
    )


def _praesto_tag_exp_scope_error(kwargs: dict[str, Any]) -> str | None:
    """Keep a borrowed group turn inside the meeting chat that invoked it."""
    metadata = kwargs.get("_metadata")
    metadata = metadata if isinstance(metadata, dict) else {}
    if not praesto_tag_exp_is_active(metadata):
        return None

    current = normalize_meeting_chat_id(str(metadata.get("cid") or ""))
    if not current:
        return "Error: meeting_automation requires the current Teams meeting chat context."

    explicit = str(kwargs.get("meeting_chat_id") or kwargs.get("meeting_url") or "").strip()
    if explicit and normalize_meeting_chat_id(explicit) != current:
        return (
            "Error: meeting_automation is scoped to the current Teams meeting chat "
            "in this shared group session."
        )
    return None


def _routing(kwargs: dict[str, Any]) -> RoutingContext:
    metadata = kwargs.get("_metadata")
    metadata = metadata if isinstance(metadata, dict) else {}
    channel = kwargs.get("_channel")
    channel_name = channel.value if isinstance(channel, ChannelType) else str(channel or "internal")
    return RoutingContext(
        channel=channel_name,
        channel_id=str(kwargs.get("_channel_id") or "meeting-automation"),
        thread_id=str(kwargs.get("_thread_id") or "") or None,
        session_id=_durable_session_id(kwargs),
        route_hint=str(metadata.get("route_hint") or "") or None,
        teams_conversation_id=str(metadata.get("cid") or "") or None,
    )


def _durable_session_id(kwargs: dict[str, Any]) -> str:
    metadata = kwargs.get("_metadata")
    metadata = metadata if isinstance(metadata, dict) else {}
    if praesto_tag_exp_is_active(metadata):
        cid = normalize_meeting_chat_id(str(metadata.get("cid") or ""))
        if cid:
            return f"cloud:praesto_tag_exp:teams:{cid}"
    return str(kwargs.get("_session_id") or "").strip()


def _actor(kwargs: dict[str, Any]) -> dict[str, str]:
    raw_metadata = kwargs.get("_metadata")
    metadata: dict[str, Any] = raw_metadata if isinstance(raw_metadata, dict) else {}
    return {
        "id": str(metadata.get("sender_id") or metadata.get("from_id") or ""),
        "upn": str(metadata.get("sender_upn") or ""),
        "display_name": str(metadata.get("sender_name") or metadata.get("from_name") or ""),
    }


def _provenance(kwargs: dict[str, Any]) -> dict[str, Any]:
    raw_metadata = kwargs.get("_metadata")
    metadata: dict[str, Any] = raw_metadata if isinstance(raw_metadata, dict) else {}
    return {
        "actor": _actor(kwargs),
        "source": {
            "conversation_id": str(metadata.get("cid") or ""),
            "message_id": str(metadata.get("message_id") or ""),
            "turn_id": str(metadata.get("turn_id") or ""),
            "session_id": str(kwargs.get("_session_id") or ""),
            "tool_call_id": str(kwargs.get("_tool_call_id") or ""),
        },
        "original_message": str(kwargs.get("_original_message") or ""),
    }
