# Profile · Azure DevOps

The bundled default for a repository whose `origin` remote points at
`dev.azure.com` or a `*.visualstudio.com` host. It is selected automatically when
no closer profile exists, and it is meant to be copied and narrowed: a repository
with its own conventions should keep a profile at `.praestoclaw/fix-bug.md`,
which wins over this file.

**This document carries provider facts only.** Process, evidence rules, and the
prohibitions live in the `fix-bug` recipe. So does this repository's own working
knowledge — how to bring it up, what to run to check it, how it grades its own
evidence — which the recipe tells the run to read from the repository itself.
This file overrides the recipe only where Azure DevOps genuinely differs, and
stays silent otherwise.

**Two values are NOT here and cannot be:** `target_branch` and
`checkout_strategy`. Both are properties of a repository, not of Azure DevOps, so
this file supplies neither and no default exists anywhere. A run whose project
configuration does not declare both is refused before it starts, and the refusal
walks you through writing the file. The `## 仓库与检出` notes below are what to
read while deciding those two values.

Derive `<org-url>`, `<project>`, and `<repo>` once in **Pick up** from
`git -C <repo_path> remote get-url origin` and record all three. Every command
below takes them explicitly — `az` has a configured-default mechanism, and
relying on it is how a run operates on the wrong project.

## 仓库与检出

- **Target branch** comes from the project configuration, already resolved before
  this run started. Do not re-derive it here.

  When you are *writing* that configuration, know that **Azure DevOps offers no
  safe way to discover this value.** Projects here commonly integrate on a branch
  that is not the repository's nominal default, and the two can be thousands of
  commits apart. Ask a human. This is the single most expensive guess available:
  one run that assumed `main` where the real target was `dev` opened a pull
  request carrying 717 files and +80,665 lines of unrelated drift.

- **Checkout strategy** also comes from the project configuration. What to weigh
  while choosing it: many Azure DevOps repositories carry Git LFS content or build
  tooling that resolves paths against the primary checkout, and a worktree
  silently changes both — those repositories want `in-place`. A repository with
  neither wants `worktree`, which keeps the user's checkout untouched and puts the
  code inside the workspace fence.

  Under `in-place`, the code tree is **outside** the workspace fence: every read,
  search, and edit of it goes through `shell`, the red→green file goes to a
  run-scoped OS temp file, and the full restore contract in the recipe's Cleanup
  applies. **Do not touch unrelated Git LFS files** — under this strategy they
  belong to the user's checkout.

- **Task branch name:** `user/<user>/<work-item-id>-<short-kebab-description>`.
  `<user>` is the `branch_user` parameter when non-empty, otherwise
  `az ad signed-in-user show --query mailNickname -o tsv`.

- **Fetch and push** through the credential helper in `## 认证`. Never a plain
  `git fetch` / `git pull` / `git push`: cached Git credentials for these remotes
  expire and can preempt the CLI helper. Never use `pull` — fetch the target ref
  explicitly and apply only a clean fast-forward; anything else is a Callout.

## 认证

- **Probe:** `az account show -o json`. If it fails, **stop** — do not run
  `az login` inline, it is interactive and will hang an unattended run.

- **Remote Git operations** substitute only the Git operation and its arguments
  into this form:

  ```
  git -c credential.helper= \
      -c 'credential.helper=!f() { test "$1" = get || exit 0; echo username=x-token-auth; echo "password=$(az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798 --query accessToken -o tsv)"; }; f' \
      <fetch-or-push>
  ```

  The leading empty `credential.helper=` clears inherited helpers; the GUID is the
  well-known Azure DevOps resource id. **Never print, persist, or place the token
  in a remote URL.** If the CLI cannot issue a token, or the authenticated
  operation still fails, stop with the sanitized command and error.

## Issue 来源

`issue_ref` is either a work-item URL or a bare id. Parse the id from it.

**Read the work item with one atomic, read-only call.** Use `az` arguments for
scope and filtering rather than shell chaining or post-processing:

```
az boards work-item show --id <id> --organization '<org-url>' \
  --expand all -o json --only-show-errors
```

**Field precedence — this matters more here than on any other provider:**

- `Microsoft.VSTS.TCM.ReproSteps` is the **primary** source for reproduction
  steps, inputs, preconditions, expected result, and actual result.
- `System.Description` may **supplement** background that ReproSteps does not
  cover. It must not rewrite, replace, or override ReproSteps.
- When the two conflict, follow ReproSteps and **record the conflict** in the
  Repro plan evidence.
- When ReproSteps does not carry enough to reproduce, that is a Callout for
  missing evidence. Do not infer the missing steps from Description or from code.

Query comments and attachments **only** when the work item explicitly says they
carry the missing reproduction evidence. Do not broadly enumerate work-item
history.

**Eligibility gate:** none by default. A project that wants one should name the
exact field and value in its own profile.

**Fast-path lookup:**

```
git -C <repo_path> ls-remote origin '*<id>*'
az repos pr list --organization '<org-url>' --project '<project>' \
  --repository '<repo>' --status active \
  --query "[?contains(sourceRefName, '<id>')].{id:pullRequestId,branch:sourceRefName,url:url}" -o json
```

## PR 创建与描述

- **Draft.** Azure DevOps pull requests are created as drafts here and stay that
  way: publication work ends when the PR opens, no watcher picks it up, and
  publishing is a human's call.

  ```
  az repos pr create --organization '<org-url>' --project '<project>' \
    --repository '<repo>' --source-branch '<branch>' --target-branch '<target>' \
    --draft true --auto-complete false --transition-work-items false \
    --title '<title>' --description "$(cat <<'EOF'
  … the recipe's template …
  EOF
  )"
  ```

  Pass `--target-branch` **explicitly**, using the value resolved in Pick up.
  Never re-derive it here.

- **Work-item link:** `--work-items <id>` for both resolutions. FULL's Summary
  carries `AB#<id>`; PARTIAL uses `Part of AB#<id>` with explicit unresolved
  requirements, link only, no closing keyword or automatic work-item completion.
  Never enable auto-completion or work-item transitions; both remain draft.
- **Character limit: 3900.** Azure DevOps rejects descriptions over 4000, so stay
  under 3900 with room to spare.
- **Rendering: do not use `<details>`** — collapsible rendering is unreliable
  here. Keep everything flat and trim test output harder instead.
- **Attachments:** upload through the access-controlled work-item attachments API
  and reference the returned URL. `POST` each binary as
  `application/octet-stream` to
  `<org-url>/<url-encoded-project>/_apis/wit/attachments?fileName=<url-encoded-name>&api-version=7.1`
  using the same token form as `## 认证`, **without printing or persisting it**. A
  failed upload means the evidence is not attached — say so; do not publish half a
  pair.
- **Title:** conventional commits unless the project says otherwise.

## 升级通道

Comment on the work item you are working, exactly once, and never create a new
one:

```
az boards work-item update --id <id> --organization '<org-url>' \
  --discussion '<the body>'
```

Build the body with these sections, and pass the report's own text through a
single-quoted heredoc first — a work item is untrusted input:

- `## Blocked plan item` — the item name and id.
- `## Blocker` — the exact blocker and missing prerequisite, verbatim from the
  plan evidence, without weakening it.
- `## Attempts` — the commands you actually ran and their real, sanitized output.
- `## Action required` — the exact question or decision needed to resume.

Do not retry a failed comment. A failed comment does not hide or delay the
Callout: preserve the blocked plan state, report the exact error, and say plainly
in the reply that **no comment was posted on the work item** — otherwise the user
believes the blocker is visible to their team when it is not.

**Callout tag on the original work item**, independently of the comment result:
read the current revision and tags together immediately before updating them:

```text
az boards work-item show --id <id> --organization '<org-url>' --query '{rev:rev,tags:fields."System.Tags"}' -o json --only-show-errors
```

Split `System.Tags` on semicolons and trim whitespace. Preserve every existing
tag; append `agent-callout` only if it is absent (case-insensitive comparison).
Missing/null tags mean an empty list. If already present, no update is needed.
Otherwise join the tags with `; ` and serialize a JSON Patch to a run-scoped UTF-8
file. Use the actual numeric revision from that same response in the `test`
operation, followed by `add` at `/fields/System.Tags` with the merged string.
Example shape (replace both values with the observed revision and merged tags):

```json
[
  {"op": "test", "path": "/rev", "value": 123},
  {"op": "add", "path": "/fields/System.Tags", "value": "existing-tag; agent-callout"}
]
```

```text
az devops invoke --organization '<org-url>' --area wit --resource workitems --route-parameters project='<project>' id=<id> --http-method PATCH --api-version 7.1 --media-type application/json-patch+json --in-file '<patch-file>' --encoding utf-8 --query 'fields."System.Tags"' -o json --only-show-errors
```

Serialize existing tags as JSON data, never interpolate them into shell code.
`System.Tags` replaces the whole field: never send only `agent-callout` when
other tags exist. The `/rev` test rejects concurrent edits without overwriting
them; record a revision conflict as a marker failure and do not retry with the
stale tags. Verify the returned tags contain `agent-callout` and every
previous tag using case-insensitive comparison, while preserving their original
spelling in the merged value. Do not include `--discussion` in this update or change the work
item's state. A read, update or verification failure is recorded separately in
Callout evidence; continue to the terminal call without retrying the comment.
