# Profile · GitHub

The bundled default for a repository whose `origin` remote points at GitHub. It
is selected automatically when no closer profile exists, and it is meant to be
copied and narrowed: a repository with its own conventions should keep a profile
at `.praestoclaw/fix-bug.md`, which wins over this file.

**This document carries provider facts only.** Process, evidence rules, and the
prohibitions live in the `fix-bug` recipe. So does this repository's own working
knowledge — how to bring it up, what to run to check it, how it grades its own
evidence — which the recipe tells the run to read from the repository itself.
This file overrides the recipe only where GitHub genuinely differs, and stays
silent otherwise; that silence is what keeps a profile short enough to write for
a new project.

**Two values are NOT here and cannot be:** `target_branch` and
`checkout_strategy`. They are properties of a repository, not of GitHub, so this
file supplies neither and no default exists anywhere. A run whose project
configuration does not declare both is refused before it starts, and the refusal
walks you through writing the file.

Throughout, `<slug>` is the `owner/repo` parsed from
`git -C <repo_path> remote get-url origin`. Derive it once in **Pick up** and
record it; do not re-parse it in every command.

## 仓库与检出

- **Target branch** comes from the project configuration, already resolved before
  this run started. Do not re-derive it here, and do not fall back to anything.

  When you are *writing* that configuration, this is how to find the value — the
  repository's default branch, read rather than guessed:

  ```
  gh repo view <slug> --json defaultBranchRef --jq .defaultBranchRef.name
  ```

  It is only a suggestion at authoring time. A repository that integrates on a
  release branch should say so in its configuration instead.
- **Task branch name:** `user/<user>/<issue-number>-<short-kebab-description>`.
  `<user>` is the `branch_user` parameter when non-empty, otherwise
  `gh api user --jq .login`. Do not guess it and do not shorten it.
- **Push:** plain `git push -u origin '<branch>'`. `gh`'s credential helper is
  already configured by `gh auth login`; do not construct a token-bearing URL.

## 认证

- **Probe, before any mutating command:** `gh auth status`.
- If it fails, **stop**. Do not run `gh auth login` inline — it is interactive and
  will hang an unattended run. Do not run `gh auth refresh` for the same reason.
- The `gh` CLI holds the credential. There is no second sanctioned source.

## Issue 来源

`issue_ref` is either a full issue URL or a bare number. Parse the number from it;
when it is a URL, take `<slug>` from the URL's own path rather than from the
remote, and if the two disagree, stop and say so.

**Read the issue with one call:**

```
gh issue view <number> --repo <slug> \
  --json number,title,body,labels,state,url,comments
```

- `body` is the primary source for symptom, preconditions, expected result, and
  actual result. `comments` supplement it and often carry the real repro steps.
- If `state` is not `OPEN`, stop and say so.

**Eligibility gate:** none by default. A repository that wants one — the common
shape is a human-applied label meaning "safe to fix autonomously" — should say so
in its own `.praestoclaw/fix-bug.md`, naming the exact label. Do not invent a
gate, and never apply a gate label yourself.

**Fast-path lookup**, for prior attempts at this issue:

```
git -C <repo_path> ls-remote origin '*<number>*'
gh pr list --repo <slug> --state open --json number,headRefName,url \
  --jq '.[] | select(.headRefName | contains("<number>"))'
```

## PR 创建与描述

- **Draft.** Open with `--draft`; only FULL may use a repository profile's explicit
  ready policy naming who follows up. PARTIAL is always draft. Publication work
  stops when the PR opens and no watcher picks it up.

  ```
  gh pr create --repo <slug> --base '<target branch>' --draft \
    --title '<title>' --body "$(cat <<'EOF'
  … the recipe's template …
  EOF
  )"
  ```

- **Title:** follow the repository's own convention. When a
  `.github/workflows/*` job lints PR titles, read its config and obey it exactly
  rather than assuming. Absent one, use conventional commits
  (`feat fix perf refactor docs test build ci chore style revert`) with a subject
  that does not start with an uppercase letter.
- **Single-commit repositories:** several PR-title linters require the title to
  equal the lone commit's subject character for character, because GitHub uses
  that subject as the default merge message. When the branch carries exactly one
  non-merge commit, build the title from it rather than writing it twice:

  ```
  TITLE=$(git -C '<tree>' log -1 --pretty=%s)
  ```

- **Issue reference:** FULL uses `Fixes #<number>` in the Summary only when it
  finishes the issue. PARTIAL uses `Part of #<number>` with explicit unresolved
  requirements and no closing keyword.
- **Character limit:** 4000.
- **Rendering:** GitHub renders `<details>` reliably; use it to collapse long
  output if the body is tight.
- **Attachments:** not supported by `gh pr create`. Inline evidence as fenced
  text; do not commit screenshots into the repository to link them.

## 升级通道

Comment on the issue you are working, exactly once, and never open a new one:

```
gh issue comment <number> --repo <slug> --body-file -
```

with a heredoc body carrying these sections:

- `## Blocked plan item` — the item name and id.
- `## Blocker` — the exact blocker and missing prerequisite, verbatim from the
  plan evidence, without weakening it.
- `## Attempts` — the commands you actually ran and their real, sanitized output.
- `## Action required` — the exact question or decision needed to resume.

Do not retry a failed comment. A failed comment does not hide or delay the
Callout: preserve the blocked plan state and report the exact error.

**Callout label on the original issue**, independently of the comment result:

```text
gh api repos/<slug>/labels/agent-callout
```

Only if that lookup returns HTTP 404, create the missing repository label:

```text
gh label create agent-callout --repo <slug> --color D4C5F9 --description 'Agent callout requires attention'
```

Keep an existing label's color and description unchanged. Add the label without
replacing any existing issue labels, then verify it appears in the returned list:

```text
gh issue edit <number> --repo <slug> --add-label agent-callout
gh issue view <number> --repo <slug> --json labels
```

An already-present label is success; do not remove or duplicate it. On an auth,
lookup, creation, update or verification failure, record the exact error in
Callout evidence and continue to the terminal call without retrying the comment.
