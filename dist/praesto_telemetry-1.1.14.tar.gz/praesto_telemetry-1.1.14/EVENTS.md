# Praesto Telemetry — Event Schema

This document is the canonical list of every event the Praesto Python apps emit
through `praesto_telemetry`. Every new event must:

1. Be added as a constant in `src/praesto_telemetry/events.py`.
2. Be documented here with name, fields, data classification, and emitter.
3. Be reviewed for privacy in the same PR that adds it.

## Data classification

| Class                | Meaning                                                        | Examples                          |
| -------------------- | -------------------------------------------------------------- | --------------------------------- |
| `SystemMetadata`     | About the running process, no user link                        | `appVersion`, `platform`, `arch`  |
| `AnonymousDeviceId`  | Per-machine random UUID, not linkable to identity              | `deviceId`                        |
| `AnonymousUserHash`  | SHA256(AAD object id + secret salt), single-direction          | `enduser_id`                      |
| `OperationalData`   | Free of personal data — counts, names of skills/routes, etc.   | `skill_name`, `route`, `success`  |

**Explicitly forbidden** in any field: AAD object id (raw), UPN, email, display
name, conversation content, prompt text, tool arguments, model output.

## Global properties (attached automatically to every event)

| Field         | Class                | Source                                                          |
| ------------- | -------------------- | --------------------------------------------------------------- |
| `appName`     | `SystemMetadata`     | `init()` arg — free-form (e.g. `praestoclaw`).                  |
| `appType`     | `SystemMetadata`     | `init()` arg — `AppType` enum (`client_agent`, `cloud_gateway`, `teams_bot`, `client_gui`, `website`). Filter by this in dashboards. |
| `appVersion`  | `SystemMetadata`     | `init()` arg — semver / build string.                           |
| `deviceId`    | `AnonymousDeviceId`  | Random UUID persisted at `<data_dir>/telemetry/device_id` (defaults to `~/.praesto/telemetry/`). Per-installation, not per-hardware. A reinstall yields a new id. |
| `os`          | `SystemMetadata`     | `macos`, `windows`, `linux`, or `sys.platform` for others.      |
| `osVersion`   | `SystemMetadata`     | macOS product version (`26.5.1`), Windows build (`10.0.22631`), Linux `NAME VERSION_ID`. |
| `platform`    | `SystemMetadata`     | Legacy field — `sys.platform` lowercased. Kept for back-compat. |
| `arch`        | `SystemMetadata`     | `platform.machine()` (e.g. `arm64`, `x86_64`).                  |

## Authenticated user identity

After login, hosts call `set_user_id(id)` with a stable user identifier. The
value is persisted at `<data_dir>/telemetry/user_id` and attached to every
subsequent span via the OpenTelemetry `enduser.id` semantic-convention
attribute. `azure-monitor-opentelemetry` maps that onto the App Insights
`ai.user.authUserId` envelope tag, which Log Analytics exposes as the
top-level `user_AuthenticatedId` column — picked up automatically by the
built-in Users / Retention / Funnel workbooks.

| App Insights field        | Source                                                  |
| ------------------------- | ------------------------------------------------------- |
| `user_AuthenticatedId`    | Caller-chosen stable user identifier (see below).       |

### How each app picks the value

| App           | Value sent                                                          | Why |
| ------------- | ------------------------------------------------------------------- | --- |
| `client_agent`| `SHA256(upn.lower())[:32]` — unsalted hash of the AAD UPN.          | The `azure_cli` default auth path can't reliably surface the AAD `oid` on Microsoft tenants because of TBCAD (token-binding conditional access). UPN is always available in `fre_state` after `pc init`. Hashing strips the EUII (the value is opaque and irreversible); skipping the salt keeps the hash stable across Praesto apps so Gateway and Bot, which also see the UPN, produce the same id for cross-app join. |
| `cloud_gateway` (planned) | Same `SHA256(upn.lower())[:32]` from the auth handshake. | Cross-app join with client_agent. |
| `teams_bot` (planned)     | Same `SHA256(upn.lower())[:32]` from Bot Framework identity. | Same. |

This is intentionally simpler than the Societas backend pattern (which sends
raw AAD `oid`): the backend has the `oid` available; PraestoClaw's CLI does
not, in the realistic deployment.

## Gateway events

### `agent_connected` — a client agent authenticated and opened a session

| Field          | Class               | Notes                                                                          |
| -------------- | ------------------- | ------------------------------------------------------------------------------ |
| `enduser_id`   | `AnonymousUserHash` | Gateway computes `SHA256(AAD_object_id + PRAESTO_USER_HASH_SALT)`, sends hex.  |
| `client_type`  | `OperationalData`   | `teams`, `web`, `cli`, etc.                                                    |
| `agent_id`     | `OperationalData`   | Agent registration id (opaque server-side identifier, not user-derived).       |

### `agent_disconnected` — client session ended

| Field          | Class               | Notes                                |
| -------------- | ------------------- | ------------------------------------ |
| `enduser_id`   | `AnonymousUserHash` |                                      |
| `agent_id`     | `OperationalData`   |                                      |
| `reason`       | `OperationalData`   | `client_close`, `timeout`, `error`.  |
| `duration_ms`  | `OperationalData`   | Session length in ms.                |

### `gateway_request` — single API request

| Field          | Class               | Notes                              |
| -------------- | ------------------- | ---------------------------------- |
| `route`        | `OperationalData`   | Route template, not raw path with ids. |
| `method`       | `OperationalData`   | HTTP verb.                         |
| `status_code`  | `OperationalData`   |                                    |
| `duration_ms`  | `OperationalData`   |                                    |

### `a2a_message_delivered` / `a2a_message_failed`

*Gateway perspective — emitted by `cloud_gateway` (planned PR2).*

| Field         | Class               | Notes                                  |
| ------------- | ------------------- | -------------------------------------- |
| `from_agent`  | `OperationalData`   | Agent id, not user.                    |
| `to_agent`    | `OperationalData`   |                                        |
| `message_kind`| `OperationalData`   | Protocol message type.                 |
| `error`       | `OperationalData`   | Failure mode tag for `_failed` only.   |

### `a2a_message_sent` — client-side dispatch outcome

*Sender-perspective. Emitted at the end of every `A2ARuntime.send_async` —
happy path **and** all four early-return failure modes (invalid_target,
no_transport, transport_error, dispatch_timeout). Lets you compute
client-side A2A success rate without correlating to Gateway events.*

| Field          | Class             | Notes                                                |
| -------------- | ----------------- | ---------------------------------------------------- |
| `message_id`   | `OperationalData` | UUID; join with Gateway events later for full chain. |
| `peer_agent_id`| `OperationalData` | Opaque receiver id (UPN or agent id).                |
| `success`      | `OperationalData` | Bool from the dispatch result.                       |
| `error_code`   | `OperationalData` | `""` on success; otherwise `invalid_target` / `no_transport` / `transport_error` / `dispatch_timeout` / Gateway-supplied code. |
| `has_task`     | `OperationalData` | Bool. True when caller upgraded to the task-bearing carrier. |
| `duration_ms`  | `OperationalData` | Wall time from `send_async` entry to return.         |
| `gateway_env`  | `OperationalData` | `staging` / `production` / `local` / `unknown`. Inferred from the configured cloud URL; only present on A2A events. |

## Client agent events

### `client_startup` — client agent process booted

| Field    | Class               | Notes |
| -------- | ------------------- | ----- |
| (only global properties) | | |

### `skill_invoked` — *deprecated, see `tool_invoked`*

Skills in PraestoClaw are markdown prompt overlays auto-loaded into context,
not discrete invokable units, so we instrument tools instead.

### `tool_invoked` — a tool call ran (or was blocked) in the 3-phase pipeline

| Field         | Class             | Notes                                                  |
| ------------- | ----------------- | ------------------------------------------------------ |
| `tool_name`   | `OperationalData` | Tool identifier from the registry.                     |
| `duration_ms` | `OperationalData` | Wall time of phase-2 execute (0 when blocked).         |
| `success`     | `OperationalData` | Bool. False on preflight blocks and execute errors.    |
| `blocked_by`  | `OperationalData` | Optional. `allowlist`, `risk_scorer`, `hook_reject`, `memory_writable`. Absent when the tool ran. |
| `turn_id`     | `OperationalData` | Per-turn UUID (from `ChannelTurnEnvelope.trace_id`). Join with `task_completed` and other `tool_invoked` rows of the same turn. |
| `session_id`  | `OperationalData` | `SHA256(session_key)[:16]` — never exposes raw Teams thread ids. Join across turns of the same conversation. |

### `task_completed` — top-level user task finished

| Field            | Class             | Notes                                                  |
| ---------------- | ----------------- | ------------------------------------------------------ |
| `outcome`        | `OperationalData` | `success`, `error`, `no_result`, `claimed`, or an admission-decision kind. |
| `duration_ms`    | `OperationalData` | Wall time of the whole turn (admission + dispatch + runtime). |
| `logical_channel`| `OperationalData` | `local_tui`, `teams`, `cloud_tui`, …                   |
| `error_type`     | `OperationalData` | Optional. `timeout`, `cancelled`, or exception class name when `outcome=error`. Absent on success. |
| `turn_id`        | `OperationalData` | Per-turn UUID. Same value as `tool_invoked.turn_id` for the same turn. |
| `session_id`     | `OperationalData` | `SHA256(session_key)[:16]`. Count turns per session via `dcount(turn_id) by session_id`. |

### `mcp_server_connected` — outcome of a single `MCPManager.connect_server` call

Emitted at the top-level entry so retries inside `_connect_server_locked`
roll up into one event per *user-visible* connect attempt. Fires on every
exit path: short-circuit (already connected), happy connect, unknown
server name, and any exception out of the locked region.

| Field               | Class             | Notes                                          |
| ------------------- | ----------------- | ---------------------------------------------- |
| `server_name`       | `OperationalData` | MCP server identifier from config.             |
| `success`           | `OperationalData` | Bool. False on `unknown_server` and any raised exception. |
| `duration_ms`       | `OperationalData` | Wall time of the connect attempt.              |
| `already_connected` | `OperationalData` | Bool. True when the call short-circuited because state was CONNECTED and `force=False`. |
| `error_type`        | `OperationalData` | Absent on success. `unknown_server` for unknown name; exception class name otherwise. |

### `token_fetched`

| Field          | Class             | Notes                                       |
| -------------- | ----------------- | ------------------------------------------- |
| `scope`        | `OperationalData` | OAuth scope being requested.                |
| `success`      | `OperationalData` |                                             |
| `duration_ms`  | `OperationalData` |                                             |
| `cache_hit`    | `OperationalData` | Bool.                                       |

### `auth_succeeded` / `auth_failed` — outcome of an auth provider call

Emitted by `client_agent` at the two callers of the `AuthProvider`
interface (`host/tui_backend.py` for connect-time silent + interactive
acquisition, `web/server.py` for the AZ CLI proxy). Split into two
event names so KQL doesn't need `where success`.

| Field          | Class             | Notes                                                 |
| -------------- | ----------------- | ----------------------------------------------------- |
| `provider`     | `OperationalData` | `azure_cli` / `m365` / `os_account` / `browser`.      |
| `mode`         | `OperationalData` | `silent` (cache-only) or `interactive` (UI flow).     |
| `duration_ms`  | `OperationalData` | Wall time of the auth attempt.                        |
| `error_type`   | `OperationalData` | `auth_failed` only. `no_token` when silent acquisition returned `None` without raising; otherwise the exception class name. |
