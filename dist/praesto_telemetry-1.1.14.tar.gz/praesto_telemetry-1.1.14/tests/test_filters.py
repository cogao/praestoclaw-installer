"""Tests for the sensitive-field redaction filter."""

from __future__ import annotations

from praesto_telemetry._filters import REDACTED, sanitize


def test_passes_through_safe_props() -> None:
    out = sanitize({"skill_name": "memex", "duration_ms": 42, "success": True})
    assert out == {"skill_name": "memex", "duration_ms": 42, "success": True}


def test_redacts_banned_field_names() -> None:
    out = sanitize({"password": "hunter2", "token": "abc", "email": "a@b.com"})
    assert out == {"password": REDACTED, "token": REDACTED, "email": REDACTED}


def test_redact_is_case_insensitive() -> None:
    out = sanitize({"Authorization": "Bearer xyz", "API_Key": "k"})
    assert out["Authorization"] == REDACTED
    assert out["API_Key"] == REDACTED


def test_redacts_jwt_shaped_values() -> None:
    out = sanitize({"header": "Bearer eyJhbGciOiJIUzI1NiJ9.payload"})
    assert out["header"] == REDACTED


def test_redacts_microsoft_email_in_value() -> None:
    out = sanitize({"note": "contact alice@microsoft.com for access"})
    assert out["note"] == REDACTED


def test_preserves_non_string_values() -> None:
    out = sanitize({"count": 5, "ratio": 0.4, "tags": ["a", "b"]})
    assert out == {"count": 5, "ratio": 0.4, "tags": ["a", "b"]}
