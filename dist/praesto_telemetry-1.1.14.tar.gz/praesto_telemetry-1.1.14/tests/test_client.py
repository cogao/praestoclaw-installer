"""Tests for the public client surface.

These tests stub the singleton's tracer with an in-memory recorder so we can
exercise queue-before-init, sanitisation, and global-property merging without
talking to the real Application Insights SDK.
"""

from __future__ import annotations

from typing import Any

import pytest

from praesto_telemetry import _client


class _FakeSpan:
    def __init__(self) -> None:
        self.attributes: dict[str, Any] = {}

    def __enter__(self) -> _FakeSpan:
        return self

    def __exit__(self, *_: object) -> None:
        return None

    def set_attribute(self, key: str, value: Any) -> None:
        self.attributes[key] = value


class _FakeTracer:
    def __init__(self) -> None:
        self.spans: list[tuple[str, _FakeSpan]] = []

    def start_as_current_span(self, name: str) -> _FakeSpan:
        span = _FakeSpan()
        self.spans.append((name, span))
        return span


@pytest.fixture
def fake_init(monkeypatch: pytest.MonkeyPatch) -> _FakeTracer:
    """Replace the singleton's init() so it installs a fake tracer."""
    _client._reset_for_tests()
    tracer = _FakeTracer()

    def _fake_init(
        self: _client._Client,
        app_name: str,
        app_version: str,
        app_type: str = "unknown",
        data_dir: Any = None,
    ) -> None:
        if self._initialized or self._disabled:
            return
        self._tracer = tracer
        self._data_dir = data_dir
        self._global_props = {
            "appName": app_name,
            "appType": app_type,
            "appVersion": app_version,
            "deviceId": "test-device",
        }
        from praesto_telemetry._user import load_persisted_user_id, persist_user_id

        # Mirror real init(): pre-init set_user_id wins and gets persisted;
        # otherwise load whatever the disk has.
        if self._user_id:
            persist_user_id(self._user_id, data_dir)
        else:
            self._user_id = load_persisted_user_id(data_dir)
        self._initialized = True
        self._drain_pending()

    monkeypatch.setattr(_client._Client, "init", _fake_init)
    return tracer


def test_emit_before_init_queues_then_replays(fake_init: _FakeTracer) -> None:
    _client.emit("agent_connected", client_type="teams")
    assert fake_init.spans == []  # nothing sent yet

    _client.init("cloud_gateway", "1.0.0")
    # Drain runs on a daemon thread; give it a beat to fire.
    import time

    for _ in range(50):
        if fake_init.spans:
            break
        time.sleep(0.01)

    assert len(fake_init.spans) == 1
    name, span = fake_init.spans[0]
    assert name == "agent_connected"
    assert span.attributes["client_type"] == "teams"
    assert span.attributes["appName"] == "cloud_gateway"
    assert span.attributes["deviceId"] == "test-device"


def test_emit_after_init_redacts_banned_fields(fake_init: _FakeTracer) -> None:
    _client.init("cloud_gateway", "1.0.0")
    _client.emit("gateway_request", route="/api", token="leaked-secret")
    assert len(fake_init.spans) == 1
    _name, span = fake_init.spans[0]
    assert span.attributes["route"] == "/api"
    assert span.attributes["token"] == "[REDACTED]"


def test_shutdown_drops_pending_and_silences_further_emits(fake_init: _FakeTracer) -> None:
    _client.emit("agent_connected")
    _client.shutdown()
    _client.emit("agent_connected")  # should be a no-op
    # init() now becomes a no-op too because _disabled is set.
    _client.init("cloud_gateway", "1.0.0")
    assert fake_init.spans == []


def test_double_init_is_safe(fake_init: _FakeTracer) -> None:
    _client.init("cloud_gateway", "1.0.0")
    _client.init("cloud_gateway", "2.0.0")  # second call should no-op
    _client.emit("agent_connected")
    _, span = fake_init.spans[0]
    assert span.attributes["appVersion"] == "1.0.0"


def test_non_primitive_attribute_is_stringified(fake_init: _FakeTracer) -> None:
    _client.init("cloud_gateway", "1.0.0")
    _client.emit("skill_invoked", payload={"nested": "value"})
    _, span = fake_init.spans[0]
    assert isinstance(span.attributes["payload"], str)
    assert "nested" in span.attributes["payload"]


def test_set_user_id_attaches_enduser_id_to_subsequent_events(
    fake_init: _FakeTracer, tmp_path: Any, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("PRAESTO_USER_ID", raising=False)
    _client.init("praestoclaw", "1.0.0", data_dir=tmp_path)
    _client.emit("client_startup")  # before login → no enduser.id
    _client.set_user_id("aad-oid-xyz")
    _client.emit("tool_invoked", tool_name="read")

    pre, post = fake_init.spans
    assert "enduser.id" not in pre[1].attributes
    assert post[1].attributes["enduser.id"] == "aad-oid-xyz"
    # Persisted to disk so next process picks it up.
    assert (tmp_path / "telemetry" / "user_id").read_text(encoding="utf-8") == "aad-oid-xyz"


def test_set_user_id_none_clears_and_stops_attaching(
    fake_init: _FakeTracer, tmp_path: Any, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("PRAESTO_USER_ID", raising=False)
    _client.init("praestoclaw", "1.0.0", data_dir=tmp_path)
    _client.set_user_id("aad-oid-xyz")
    _client.set_user_id(None)
    _client.emit("client_startup")

    _, span = fake_init.spans[0]
    assert "enduser.id" not in span.attributes
    assert not (tmp_path / "telemetry" / "user_id").exists()


def test_persisted_user_id_loaded_on_init(
    fake_init: _FakeTracer, tmp_path: Any, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("PRAESTO_USER_ID", raising=False)
    (tmp_path / "telemetry").mkdir(parents=True)
    (tmp_path / "telemetry" / "user_id").write_text("persisted-oid", encoding="utf-8")

    _client.init("praestoclaw", "1.0.0", data_dir=tmp_path)
    _client.emit("client_startup")

    _, span = fake_init.spans[0]
    assert span.attributes["enduser.id"] == "persisted-oid"


def test_set_user_id_before_init_is_buffered_then_persisted(
    fake_init: _FakeTracer, tmp_path: Any, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Reviewer flagged: set_user_id() called before init() used to write to
    the default data dir and then get clobbered when init() loaded the
    persisted file. Pre-init values must win over disk and end up at the
    right data_dir.
    """
    monkeypatch.delenv("PRAESTO_USER_ID", raising=False)
    # Disk has an *old* persisted id at the target data_dir — the pre-init
    # set_user_id call should override it.
    (tmp_path / "telemetry").mkdir(parents=True)
    (tmp_path / "telemetry" / "user_id").write_text("stale-from-disk", encoding="utf-8")

    _client.set_user_id("fresh-pre-init")
    # No disk write yet — data_dir not known.
    _client.init("praestoclaw", "1.0.0", data_dir=tmp_path)
    _client.emit("client_startup")

    _, span = fake_init.spans[0]
    assert span.attributes["enduser.id"] == "fresh-pre-init"
    # Persisted to the resolved data_dir, overwriting the stale value.
    assert (tmp_path / "telemetry" / "user_id").read_text(encoding="utf-8") == "fresh-pre-init"
