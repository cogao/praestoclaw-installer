"""Tests for the device-id persistence helper."""

from __future__ import annotations

import uuid
from pathlib import Path

import pytest

from praesto_telemetry import _identity


@pytest.fixture
def _isolated_home(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> Path:
    """Pin the device-id file under a per-test tmp dir."""
    monkeypatch.delenv(_identity._ENV_OVERRIDE, raising=False)
    monkeypatch.setattr(_identity, "_DEFAULT_DIR", tmp_path / "telemetry")
    return tmp_path


def test_generates_and_persists_on_first_call(_isolated_home: Path) -> None:
    first = _identity.get_or_create_device_id()
    # Should look like a UUID and be stable on disk.
    uuid.UUID(first)
    assert _identity._device_id_path().read_text(encoding="utf-8").strip() == first


def test_returns_persisted_value_on_subsequent_calls(_isolated_home: Path) -> None:
    first = _identity.get_or_create_device_id()
    second = _identity.get_or_create_device_id()
    assert first == second


def test_env_override_wins(monkeypatch: pytest.MonkeyPatch, _isolated_home: Path) -> None:
    monkeypatch.setenv(_identity._ENV_OVERRIDE, "fixed-instance-42")
    assert _identity.get_or_create_device_id() == "fixed-instance-42"
    # File should not have been touched on the override path.
    assert not _identity._device_id_path().exists()


def test_blank_file_regenerates(_isolated_home: Path) -> None:
    path = _identity._device_id_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("   \n", encoding="utf-8")
    new_id = _identity.get_or_create_device_id()
    uuid.UUID(new_id)
    assert path.read_text(encoding="utf-8").strip() == new_id


def test_data_dir_overrides_default(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.delenv(_identity._ENV_OVERRIDE, raising=False)
    custom = tmp_path / "praestoclaw"
    new_id = _identity.get_or_create_device_id(data_dir=custom)
    uuid.UUID(new_id)
    assert (custom / "telemetry" / "device_id").read_text(encoding="utf-8").strip() == new_id


def test_get_os_details_returns_known_family() -> None:
    _identity.get_os_details.cache_clear()
    details = _identity.get_os_details()
    assert set(details.keys()) == {"os", "osVersion"}
    assert details["os"] in {"macos", "windows", "linux"}
    assert isinstance(details["osVersion"], str) and details["osVersion"]
