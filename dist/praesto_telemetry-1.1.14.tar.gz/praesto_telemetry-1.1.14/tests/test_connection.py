"""Tests for the connection-string resolver."""

from __future__ import annotations

import pytest

from praesto_telemetry import _connection


@pytest.fixture(autouse=True)
def _clear_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for var in ("DISABLE_TELEMETRY", "CI", "PRAESTO_TELEMETRY_CONN_STR", "PRAESTO_ENV"):
        monkeypatch.delenv(var, raising=False)


def test_disable_telemetry_env_returns_none(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DISABLE_TELEMETRY", "true")
    assert _connection.resolve_connection_string() is None


def test_ci_env_returns_none(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("CI", "true")
    assert _connection.resolve_connection_string() is None


def test_override_takes_precedence(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PRAESTO_TELEMETRY_CONN_STR", "InstrumentationKey=override")
    monkeypatch.setenv("PRAESTO_ENV", "staging")
    assert _connection.resolve_connection_string() == "InstrumentationKey=override"


def test_staging_env_returns_staging_string(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PRAESTO_ENV", "staging")
    result = _connection.resolve_connection_string()
    assert result is not None
    assert "4eab5240-5ec7-4e32-a762-548875d62122" in result


def test_default_is_production(monkeypatch: pytest.MonkeyPatch) -> None:
    # Production is now provisioned (PraestoProductionAI). Unset env should
    # resolve to the prod connection string.
    result = _connection.resolve_connection_string()
    assert result is not None
    assert "2d512b25-6f22-47d4-b5f0-34f6fe3bb74e" in result


def test_unknown_env_disables_telemetry(monkeypatch: pytest.MonkeyPatch) -> None:
    """A typo / unknown value should disable telemetry, not fall through to prod.

    Reviewers flagged that ``PRAESTO_ENV=prod`` (lowercase typo, not the
    canonical ``production``) would silently land in the prod workspace —
    so we normalise common aliases and reject everything else.
    """
    monkeypatch.setenv("PRAESTO_ENV", "totally-bogus")
    assert _connection.resolve_connection_string() is None


@pytest.mark.parametrize(
    ("alias", "needle"),
    [
        ("prod", "2d512b25-6f22-47d4-b5f0-34f6fe3bb74e"),  # → production
        ("stg", "4eab5240-5ec7-4e32-a762-548875d62122"),  # → staging
        ("dev", "4eab5240-5ec7-4e32-a762-548875d62122"),  # → staging (dev fallback)
    ],
)
def test_common_aliases_are_normalised(
    monkeypatch: pytest.MonkeyPatch, alias: str, needle: str
) -> None:
    monkeypatch.setenv("PRAESTO_ENV", alias)
    result = _connection.resolve_connection_string()
    assert result is not None
    assert needle in result


def test_truthy_variants() -> None:
    assert _connection._is_truthy("true")
    assert _connection._is_truthy("True")
    assert _connection._is_truthy("1")
    assert _connection._is_truthy("yes")
    assert not _connection._is_truthy("false")
    assert not _connection._is_truthy("")
    assert not _connection._is_truthy(None)
