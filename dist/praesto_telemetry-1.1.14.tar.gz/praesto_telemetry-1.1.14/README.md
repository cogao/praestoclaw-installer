# praesto_telemetry

Shared Application Insights client for Praesto Python apps (`cloud_gateway`, `client_agent`).

Wraps `azure-monitor-opentelemetry` with a tiny 5-function surface so that
business code never touches the SDK directly. Picks the right connection string
per environment, attaches global context (app name, version, platform, anonymous
device id) to every event, buffers events emitted before `init()`, filters
known-sensitive field names defensively, and disables itself in CI.

## Usage

```python
from praesto_telemetry import AppType, Events, emit, flush, init, set_user_id, shutdown

init(
    app_name="client_agent",
    app_version="1.2.3",
    app_type=AppType.CLIENT_AGENT,
    data_dir=Path.home() / ".praestoclaw",   # optional; defaults to ~/.praesto
)

# After authentication completes (host decides what value to send;
# see EVENTS.md → "Authenticated user identity").
set_user_id(hashed_user_id)

emit(Events.TOOL_INVOKED, tool_name="read", duration_ms=42, success=True)

# On graceful shutdown
shutdown()  # flushes then disables further emits
```

## Environment

| Variable                          | Purpose                                                     |
| --------------------------------- | ----------------------------------------------------------- |
| `PRAESTO_ENV`                     | `production` (default), `staging`, or `development`. Common aliases (`prod`, `stg`, `dev`) are normalised; unknown values disable telemetry rather than fall through to prod. |
| `PRAESTO_TELEMETRY_CONN_STR`      | Override the built-in connection string (dev / local runs)  |
| `PRAESTO_DEVICE_ID`               | Pin a specific device id (CI, ops, multi-instance testing)  |
| `PRAESTO_USER_ID`                 | Pin a specific user id (tests / ops)                        |
| `DISABLE_TELEMETRY`               | Set to `true` to skip init entirely                         |
| `CI`                              | When `true`, init is a no-op (avoids polluting prod data)   |

## Events

See [EVENTS.md](./EVENTS.md) for the full event schema and data classification.
Always add new events to `events.py` and document them in `EVENTS.md` in the same PR.

## Privacy

- No conversation content, prompts, or tool arguments are emitted.
- **Device identity** is an anonymous per-installation random UUID, persisted
  at `<data_dir>/telemetry/device_id` (default `~/.praesto/telemetry/`). A
  reinstall yields a new id; the package never reads OS-level hardware ids.
- **User identity** is a caller-chosen stable opaque value, set via
  `set_user_id(...)` after login and persisted at
  `<data_dir>/telemetry/user_id`. The package does not prescribe the
  encoding — `client_agent` sends `SHA256(upn.lower())[:32]`, a backend
  that already has an opaque AAD `oid` from a trusted token claim can
  send that. The value surfaces through OpenTelemetry's `enduser.id`
  semantic-convention attribute, which the Azure Monitor exporter maps
  onto the standard `ai.user.authUserId` envelope tag (Log Analytics
  column `user_AuthenticatedId`). Callers must not pass raw UPN, email,
  or display name.
- A defensive filter strips fields with names like `password`, `token`,
  `email`, `upn`, etc., replacing the value with `[REDACTED]` before send.
