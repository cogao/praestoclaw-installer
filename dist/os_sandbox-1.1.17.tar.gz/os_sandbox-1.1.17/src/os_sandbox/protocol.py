"""OsSandbox protocol — the shape every backend implements."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Protocol, runtime_checkable

from os_sandbox.spec import SandboxSpec


@runtime_checkable
class OsSandbox(Protocol):
    """Pure transform over ``argv``.

    ``wrap`` MUST NOT spawn processes. It returns a new argv (and possibly
    augmented env) that the caller can then spawn with their preferred
    subprocess primitive.

    Implementations should be cheap to construct: callers are free to
    instantiate one per call site.
    """

    name: str  # short identifier for logs ("seatbelt", "bwrap", "noop", ...)

    def wrap(
        self,
        argv: Sequence[str],
        *,
        cwd: Path,
        env: Mapping[str, str],
        spec: SandboxSpec,
    ) -> tuple[list[str], dict[str, str]]:
        """Wrap ``argv`` so the OS enforces ``spec``.

        ``cwd`` is the directory the child will be spawned in. Backends use
        it for any "current directory" semantics; it is *not* automatically
        added to the writable allow-list (the caller decides whether cwd is
        writable by putting it in ``spec.writable_paths``).

        Returns ``(new_argv, new_env)``. ``new_env`` may equal ``dict(env)``
        if the backend doesn't need to touch the environment.
        """
        ...
