"""Sandbox spec: the low-level technical description of what a wrapped
child may do. No business concepts — no "mode", no "workspace", no
"profile". Callers translate their domain vocabulary into a ``SandboxSpec``
and hand it to a backend.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True)
class SandboxSpec:
    """Pure technical sandbox parameters.

    The kernel cares about exactly two things, and nothing more:

    - which absolute paths are writable (everything else is read-only);
    - whether outbound network is allowed at all.

    An empty ``writable_paths`` means the entire FS is read-only.
    ``allow_network=False`` means no outbound network, period.

    A spec is agnostic about *why* a path is writable — "workspace",
    "scratch", "extra root" are all just paths to the kernel.

    Proxy-only network routing (codex's ``NetworkProxy`` equivalent) is
    deliberately out of scope until we ship a real implementation; adding
    a field now would be an API lie.
    """

    writable_paths: tuple[Path, ...] = field(default_factory=tuple)
    allow_network: bool = False

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "writable_paths",
            tuple(Path(p).resolve() for p in self.writable_paths),
        )

    def with_extra_writable(self, extra: Iterable[Path | str]) -> SandboxSpec:
        """Return a new spec with ``extra`` paths appended to writable_paths.

        Dedups against existing entries; returns ``self`` unchanged when
        nothing new gets added.
        """
        extra_list = [Path(p).resolve() for p in extra]
        if not extra_list:
            return self
        merged: list[Path] = list(self.writable_paths)
        for rp in extra_list:
            if rp not in merged:
                merged.append(rp)
        if merged == list(self.writable_paths):
            return self
        return SandboxSpec(
            writable_paths=tuple(merged),
            allow_network=self.allow_network,
        )
