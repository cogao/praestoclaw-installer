"""OS-level subprocess sandbox.

The public surface is a tiny pure-technical API:

- :class:`SandboxSpec` describes what a wrapped child may do
  (writable paths + network policy).
- :class:`OsSandbox` is the protocol every backend implements: ``wrap(argv,
  cwd, env, spec)`` returns ``(argv, env)`` ready to spawn.
- :func:`select_sandbox` picks the right platform backend
  (or :class:`NoopSandbox` on degradation).

Higher-level concepts — "modes", "profiles", "workspaces" — belong to
callers, who translate them into a :class:`SandboxSpec`.
"""

from os_sandbox.errors import (
    SandboxDeniedError,
    SandboxUnsupportedError,
    is_likely_sandbox_denied,
)
from os_sandbox.manager import select_sandbox
from os_sandbox.noop import NoopSandbox
from os_sandbox.protocol import OsSandbox
from os_sandbox.spec import SandboxSpec

__all__ = [
    "NoopSandbox",
    "OsSandbox",
    "SandboxDeniedError",
    "SandboxSpec",
    "SandboxUnsupportedError",
    "is_likely_sandbox_denied",
    "select_sandbox",
]
