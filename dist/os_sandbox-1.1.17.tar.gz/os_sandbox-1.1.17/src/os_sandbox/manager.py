"""Backend selection."""

from __future__ import annotations

import logging
import sys

from os_sandbox.errors import SandboxUnsupportedError
from os_sandbox.noop import NoopSandbox
from os_sandbox.protocol import OsSandbox

logger = logging.getLogger(__name__)


def select_sandbox() -> OsSandbox:
    """Pick the right backend for the current platform.

    Selection rules:

    - darwin   → SeatbeltSandbox
    - linux    → BwrapSandbox (auto-falls-back to Noop if bwrap is missing).
                  Includes WSL2 — sys.platform there is ``linux``, and the
                  bwrap probe passes because WSL2 ships real user namespaces.
                  WSL1 is detected up-front by BwrapSandbox and raises
                  ``SandboxUnsupportedError`` with a "move to WSL2" hint.
    - win32    → NoopSandbox + warning (native Windows backend is a v2
                  follow-up; users on Windows should run inside WSL2, where
                  the linux branch above takes over automatically).
    - other    → NoopSandbox + warning

    Any backend may raise :class:`SandboxUnsupportedError` from its constructor
    (e.g. helper binary missing); we always degrade to :class:`NoopSandbox` with
    a warning rather than crash the caller.

    If the caller wants "no sandbox at all" they should construct
    :class:`NoopSandbox` directly instead of calling this — passing through
    here unnecessarily would still pick the platform backend.
    """
    if sys.platform == "darwin":
        try:
            from os_sandbox.backends.seatbelt import SeatbeltSandbox

            return SeatbeltSandbox()
        except (ImportError, SandboxUnsupportedError) as exc:  # pragma: no cover
            logger.warning(
                "os_sandbox: Seatbelt backend unavailable (%s); falling back to NoopSandbox", exc
            )
            return NoopSandbox()

    if sys.platform.startswith("linux"):
        try:
            from os_sandbox.backends.bwrap import BwrapSandbox

            return BwrapSandbox()
        except (ImportError, SandboxUnsupportedError) as exc:  # pragma: no cover
            logger.warning(
                "os_sandbox: bwrap backend unavailable (%s); falling back to NoopSandbox", exc
            )
            return NoopSandbox()

    if sys.platform == "win32":
        logger.warning(
            "os_sandbox: native Windows backend not implemented yet; "
            "run inside WSL2 to get the bwrap sandbox automatically. "
            "Falling back to NoopSandbox."
        )
        return NoopSandbox()

    logger.warning(
        "os_sandbox: no backend for platform %s; falling back to NoopSandbox", sys.platform
    )
    return NoopSandbox()
