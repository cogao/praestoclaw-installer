"""Linux bubblewrap backend.

Wraps argv with ``bwrap`` so the kernel enforces filesystem and network
isolation through mount and network namespaces. Mirrors the codex CLI
strategy: rootfs is ``--ro-bind``-mounted read-only, then writable paths
are layered on top as writable binds. Network is denied via ``--unshare-net``
unless ``allow_network``.

If ``bwrap`` is not installed on the host, the constructor raises
:class:`SandboxUnsupportedError` and the manager falls back to NoopSandbox.
"""

from __future__ import annotations

import shutil
import subprocess
from collections.abc import Mapping, Sequence
from pathlib import Path

from os_sandbox.errors import SandboxUnsupportedError
from os_sandbox.spec import SandboxSpec

# Env hint mirroring codex CLI. Kept literal-compatible so any tool already
# coded against codex's variable Just Works under our sandbox too.
SANDBOX_NETWORK_DISABLED_ENV = "CODEX_SANDBOX_NETWORK_DISABLED"

# Surfaced when the backend constructor refuses to run because we're on WSL1.
# WSL1 has no user-namespace support, so bwrap can never succeed; tell the
# user the actionable thing (move to WSL2) instead of leaving them to decode
# the generic "user namespaces blocked" probe message.
_WSL1_MESSAGE = (
    "bwrap requires Linux user namespaces, which WSL1 does not provide. "
    "Use WSL2 for sandboxed shell commands."
)

# Paths that always need to exist for a usable userspace inside the namespace.
# proc/dev/sys are mounted fresh; the rest are read-only binds from the host.
# /home and /root are bound read-only so tools like git can read ~/.gitconfig,
# ~/.ssh, ~/.git-credentials — without these, git commit/push fails in
# read_only and workspace_write modes with no obvious cause.
_READONLY_BINDS = (
    "/usr",
    "/lib",
    "/lib64",
    "/bin",
    "/sbin",
    "/etc",
    "/opt",
    "/var",
    "/home",
    "/root",
)

# Subdirs inside each writable bind that we re-layer as read-only to keep
# the LLM from blowing away version-control state. Codex carves these out
# inside its writable allow-list; bwrap's mechanism is different (we layer
# a ``--ro-bind`` on top of the writable bind — last bind for a given path
# wins inside the namespace), but the user-visible result is the same.
_READONLY_CARVE_OUTS = (".git",)


def _which_bwrap() -> str | None:
    return shutil.which("bwrap")


def proc_version_indicates_wsl1(proc_version: str) -> bool:
    """Pure-function half of :func:`is_wsl1` — exposed for tests.

    Mirrors codex's heuristic (``codex-rs/sandboxing/src/bwrap.rs``): the
    Microsoft kernel reports its WSL major version in ``/proc/version`` as
    e.g. ``"... WSL2 ..."``. When the explicit token is absent, fall back
    to the legacy ``"Microsoft"`` marker — WSL2 always says
    ``"microsoft-standard"``, so anything else microsofty is WSL1.
    """
    lowered = proc_version.lower()
    remaining = lowered
    while True:
        idx = remaining.find("wsl")
        if idx < 0:
            break
        tail = remaining[idx + len("wsl") :]
        digits = ""
        for ch in tail:
            if ch.isdigit():
                digits += ch
            else:
                break
        if digits:
            try:
                if int(digits) == 1:
                    return True
            except ValueError:
                pass
            # WSL<N> with N != 1 → not WSL1; keep scanning in case the line
            # also contains a stray "wsl" elsewhere.
        remaining = tail

    return "microsoft" in lowered and "microsoft-standard" not in lowered


def is_wsl1() -> bool:
    """``True`` iff the current kernel looks like WSL1.

    Reads ``/proc/version`` and applies :func:`proc_version_indicates_wsl1`.
    Returns ``False`` on any read failure — we'd rather fall through to the
    generic user-namespace probe than incorrectly block native Linux.
    """
    try:
        text = Path("/proc/version").read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    return proc_version_indicates_wsl1(text)


def probe_user_namespace(bwrap_path: str, timeout_s: float = 0.5) -> str | None:
    """Run a trivial bwrap invocation; return a human-readable failure
    reason if it didn't work, or ``None`` if it succeeded.

    This is codex's ``system_bwrap_has_user_namespace_access`` pattern.
    It catches the three main "bwrap is installed but won't actually
    sandbox anything" failure modes:

    - **WSL1** — namespaces are entirely missing
    - **Ubuntu 24+ AppArmor profile** — unprivileged user namespaces gated
      behind the ``bwrap-userns-restrict`` profile not being applied
    - **kernel.unprivileged_userns_clone=0** — disabled by sysctl

    Caller logs the message; backend can still hand back NoopSandbox if
    the probe fails, instead of letting every command silently bypass.
    """
    try:
        result = subprocess.run(
            [
                bwrap_path,
                "--unshare-user",
                "--unshare-net",
                "--ro-bind",
                "/",
                "/",
                "/bin/true",
            ],
            capture_output=True,
            timeout=timeout_s,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        return f"bwrap probe failed: {exc}"
    if result.returncode == 0:
        return None
    stderr = result.stderr.decode("utf-8", errors="replace").strip()
    if "user namespace" in stderr.lower() or "setting up uid map" in stderr.lower():
        return (
            "bwrap rejected user namespaces — likely WSL1, an AppArmor "
            "profile (Ubuntu 24+ needs `bwrap-userns-restrict`), or "
            f"`kernel.unprivileged_userns_clone=0`. stderr: {stderr!r}"
        )
    return f"bwrap probe exit={result.returncode} stderr={stderr!r}"


def build_argv(
    bwrap_path: str,
    spec: SandboxSpec,
    inner_argv: Sequence[str],
    *,
    cwd: Path,
) -> list[str]:
    """Compose the full ``bwrap ... -- <inner_argv>`` command line.

    The mount layout: bind the OS rootfs read-only, layer writable binds for
    every path in ``spec.writable_paths``, mount a fresh tmpfs on /tmp
    (always — many tools assume /tmp exists), disable network unless allowed.
    ``cwd`` is mounted read-only when it falls outside the rootfs binds, so
    the child can at least see its working directory.

    Carve-outs (``.git``) are layered LAST so they win the
    last-mount-wins resolution that bwrap applies inside the namespace.
    """
    args: list[str] = [bwrap_path]

    # Namespaces: user (so we don't need root), PID, IPC, UTS. Mount and
    # network are unshared selectively below.
    args += ["--unshare-user", "--unshare-pid", "--unshare-ipc", "--unshare-uts"]

    # Network: deny by default via --unshare-net (cuts the net namespace,
    # leaving the child with only loopback). To allow network, we omit the
    # flag entirely — bwrap inherits the host net namespace by default.
    # (There is no --share-net flag; using one fails at startup.)
    if not spec.allow_network:
        args += ["--unshare-net"]

    # /proc and /dev are mounted fresh — required by most runtimes.
    # (/sys is intentionally NOT mounted; tools that need cgroup/CPU info
    # via /sys must request a writable_root if they need it.)
    args += ["--proc", "/proc", "--dev", "/dev"]

    # Bind the host rootfs read-only piece by piece. _READONLY_BINDS is the
    # explicit allowlist of host dirs the child can read; everything else is
    # invisible. /home and /root ARE included so git can find ~/.gitconfig
    # / ~/.ssh; /tmp and /var/tmp are handled below (tmpfs or carve-out).
    for path in _READONLY_BINDS:
        if Path(path).exists():
            args += ["--ro-bind", path, path]

    # Writable region: every path the spec lists.
    writables: list[Path] = []
    for p in spec.writable_paths:
        rp = p.resolve()
        if rp not in writables and rp.exists():
            writables.append(rp)
    for p in writables:
        args += ["--bind", str(p), str(p)]

    # Ensure cwd is visible. If it isn't already covered by a writable bind
    # or a read-only bind, add it as read-only.
    cwd_resolved = cwd.resolve()
    if (
        cwd_resolved.exists()
        and not any(_is_within(cwd_resolved, root) for root in writables)
        and not any(_is_within(cwd_resolved, Path(p)) for p in _READONLY_BINDS)
    ):
        args += ["--ro-bind", str(cwd_resolved), str(cwd_resolved)]

    # /tmp handling: a fresh tmpfs ONLY when /tmp itself appears in the
    # writable spec (workspace_write semantics). In read-only mode (empty
    # writable_paths, or writable set that doesn't include /tmp) we leave
    # /tmp unmounted so the spec's "entire FS read-only" contract holds —
    # callers that need readable /tmp must add it explicitly.
    # SandboxSpec normalises with Path.resolve(); on macOS /tmp is a
    # symlink to /private/tmp, so we compare against both.
    tmp_aliases = {Path("/tmp").resolve(), Path("/tmp")}
    if any(root in tmp_aliases for root in writables):
        # Replace the per-call writable bind for /tmp with a fresh tmpfs —
        # avoids polluting host /tmp and matches codex.
        args += ["--tmpfs", "/tmp"]

    # Carve-outs: re-layer ``.git`` etc. as read-only over the writable
    # binds. ``last bind wins`` in the namespace so the order is critical.
    for writable in writables:
        for sub in _READONLY_CARVE_OUTS:
            target = writable / sub
            if target.exists():
                args += ["--ro-bind", str(target), str(target)]

    args += ["--die-with-parent"]

    args += ["--", *inner_argv]
    return args


def _is_within(child: Path, parent: Path) -> bool:
    try:
        child.relative_to(parent)
        return True
    except ValueError:
        return False


class BwrapSandbox:
    """Wraps argv with bubblewrap. Stateless; safe to instantiate per call."""

    name = "bwrap"

    def __init__(self) -> None:
        path = _which_bwrap()
        if not path:
            raise SandboxUnsupportedError(
                "bwrap binary not found in PATH; install bubblewrap to enable Linux sandboxing"
            )
        # WSL1 has no user-namespace support; probe would fail with the
        # generic message. Short-circuit with an actionable hint instead.
        if is_wsl1():
            raise SandboxUnsupportedError(_WSL1_MESSAGE)
        # Verify user namespaces actually work in this environment. The
        # binary being present isn't enough — WSL1, certain AppArmor
        # configs, and sysctl lockdowns all leave a working `bwrap` that
        # exits non-zero on first use. We surface a specific reason in
        # the exception so the manager / runtime can log it once at
        # startup instead of every command failing mysteriously.
        reason = probe_user_namespace(path)
        if reason is not None:
            raise SandboxUnsupportedError(reason)
        self._bwrap_path = path

    def wrap(
        self,
        argv: Sequence[str],
        *,
        cwd: Path,
        env: Mapping[str, str],
        spec: SandboxSpec,
    ) -> tuple[list[str], dict[str, str]]:
        wrapped = build_argv(self._bwrap_path, spec, argv, cwd=cwd)
        child_env = dict(env)
        if not spec.allow_network:
            child_env[SANDBOX_NETWORK_DISABLED_ENV] = "1"
        return wrapped, child_env
