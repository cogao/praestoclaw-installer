"""macOS Seatbelt backend (``/usr/bin/sandbox-exec``).

The strategy mirrors codex CLI: write a tiny SBPL profile that's
*default-deny*, then explicitly allow what's needed. ``/usr/bin/sandbox-exec``
is hardcoded so it cannot be hijacked via PATH.

Writable paths are passed via ``-D KEY=value`` parameters and referenced
in the SBPL with ``(param "WRITABLE_ROOT_N")`` — this is the codex pattern
and it eliminates an entire class of SBPL injection / escaping bugs that
would exist if we string-interpolated paths into policy text. Workspace
paths can contain quotes, parens, or newlines in principle; with the ``-D``
indirection none of that touches the policy parser.

Inside every writable root we carve out ``.git`` as read-only (both the
``(literal)`` exact match and the ``(subpath)`` covering its contents).
Codex does this to keep the LLM from blowing away version-control state
or modifying hooks. The dual rule is required: ``(subpath)`` alone leaves
a gap for first-time *creation* of ``.git`` inside a writable subtree.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from pathlib import Path

from os_sandbox.errors import SandboxUnsupportedError
from os_sandbox.spec import SandboxSpec

SANDBOX_EXEC = "/usr/bin/sandbox-exec"

# Env hint that child processes (and any tools wrapping them) can read to
# self-check "I'm running under a sandbox with network disabled" without
# having to probe a socket. Codex sets CODEX_SANDBOX_NETWORK_DISABLED=1;
# we use the same key so cross-tool ecosystems (npm postinstall scripts,
# pip build hooks, etc.) that already check for it Just Work.
SANDBOX_NETWORK_DISABLED_ENV = "CODEX_SANDBOX_NETWORK_DISABLED"

# Subpaths inside any writable root that are carved back to read-only.
# Order matters for predictability but not for correctness.
_READONLY_CARVE_OUTS = (".git",)

# Permissions every wrapped process needs to function at all (exec children,
# read its own libraries, talk to expected system daemons, use TTY/PTY).
# Defaults are read-only — write permissions are added separately.
_BASE_POLICY = """
(version 1)
(deny default)

;; --- process / signals ---
(allow process-exec)
(allow process-fork)
(allow signal (target same-sandbox))
(allow process-info-pidinfo)
(allow process-info-pidfdinfo)
(allow process-info-pidfileportinfo)
(allow process-info-setcontrol)
(allow process-info-dirtycontrol)
(allow process-info-rusage)
(allow process-info-codesignature)
(allow process-info-listpids)

;; --- read everything (read-only baseline) ---
(allow file-read*)

;; --- always-writable scratch devices ---
(allow file-write*
       (literal "/dev/null")
       (literal "/dev/zero")
       (literal "/dev/dtracehelper")
       (literal "/dev/tty")
       (literal "/dev/stdout")
       (literal "/dev/stderr"))

;; --- pseudo-terminals (interactive shells, command line tools) ---
(allow file-write* (regex #"^/dev/fd/[0-9]+$"))
(allow file-write* (regex #"^/dev/ttys[0-9]+$"))
(allow file-write* (literal "/dev/ptmx"))
(allow pseudo-tty)

;; --- sysctl reads commonly used by libc / runtimes ---
(allow sysctl-read)

;; --- IPC primitives needed by Python / common runtimes ---
(allow ipc-posix-shm)
(allow ipc-posix-sem)

;; --- mach-lookups for the daemons everything talks to ---
(allow mach-lookup
       (global-name "com.apple.system.notification_center")
       (global-name "com.apple.distributed_notifications@Uv3")
       (global-name "com.apple.cfprefsd.agent")
       (global-name "com.apple.cfprefsd.daemon")
       (global-name "com.apple.system.opendirectoryd.api")
       (global-name "com.apple.system.opendirectoryd.libinfo")
       (global-name "com.apple.system.logger")
       (global-name "com.apple.logd")
       (global-name "com.apple.trustd")
       (global-name "com.apple.trustd.agent")
       (global-name "com.apple.SecurityServer"))
"""


def _build_policy_and_params(
    spec: SandboxSpec,
) -> tuple[str, list[tuple[str, str]]]:
    """Compose SBPL text + the ``-D`` parameter list for ``spec``.

    Returns ``(policy_text, [(key, value), ...])``. Caller passes each
    ``(key, value)`` as ``-D<key>=<value>`` on the ``sandbox-exec`` argv.

    Empty ``writable_paths`` → no write rules (only the base policy's
    device literals are writable). ``allow_network=True`` opens outbound.
    """
    parts: list[str] = [_BASE_POLICY]
    params: list[tuple[str, str]] = []

    if spec.writable_paths:
        write_lines: list[str] = []
        for i, path in enumerate(spec.writable_paths):
            key = f"WRITABLE_ROOT_{i}"
            params.append((key, str(path)))
            write_lines.append(f'       (subpath (param "{key}"))')
        parts.append("(allow file-write*\n" + "\n".join(write_lines) + ")\n")

        # Carve-outs: .git stays read-only inside any writable root, both
        # for existing dirs (subpath) and to block first-time creation
        # (literal). Match codex's dual-rule pattern.
        carve_lines: list[str] = []
        for i in range(len(spec.writable_paths)):
            for sub in _READONLY_CARVE_OUTS:
                carve_lines.append(
                    f'    (require-all (subpath (param "WRITABLE_ROOT_{i}")) '
                    f'(regex #"/{sub}(/|$)"))'
                )
        if carve_lines:
            parts.append("(deny file-write*\n" + "\n".join(carve_lines) + ")\n")

    if spec.allow_network:
        parts.append("(allow network*)\n")

    return "".join(parts), params


# Kept as a thin wrapper for backwards-compat with existing tests.
def build_policy(spec: SandboxSpec) -> str:
    """Return only the policy text (legacy helper).

    Prefer :func:`_build_policy_and_params` in new code so writable paths
    use ``-D`` parameter indirection instead of being baked into the text.
    """
    text, _ = _build_policy_and_params(spec)
    return text


class SeatbeltSandbox:
    """Wraps argv with ``sandbox-exec -p <policy> -D...= -- argv``. Stateless."""

    name = "seatbelt"

    def __init__(self) -> None:
        if not Path(SANDBOX_EXEC).exists():
            raise SandboxUnsupportedError(
                f"{SANDBOX_EXEC} not present; Seatbelt backend cannot run"
            )

    def wrap(
        self,
        argv: Sequence[str],
        *,
        cwd: Path,
        env: Mapping[str, str],
        spec: SandboxSpec,
    ) -> tuple[list[str], dict[str, str]]:
        del cwd  # Seatbelt policies don't need cwd; spec carries everything
        policy, params = _build_policy_and_params(spec)
        wrapped = [SANDBOX_EXEC, "-p", policy]
        for key, value in params:
            wrapped.append(f"-D{key}={value}")
        wrapped.append("--")
        wrapped.extend(argv)

        child_env = dict(env)
        if not spec.allow_network:
            child_env[SANDBOX_NETWORK_DISABLED_ENV] = "1"
        return wrapped, child_env
