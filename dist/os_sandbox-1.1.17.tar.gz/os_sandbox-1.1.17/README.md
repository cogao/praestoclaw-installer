# os-sandbox

OS-level subprocess sandbox wrappers. Wraps a child-process `argv` so the kernel enforces filesystem and network isolation regardless of what the spawned process tries to do.

This package is intentionally **pure-technical** — it exposes a single low-level type (`SandboxSpec`) and platform backends. Higher-level concepts like "modes", "profiles", or "workspaces" belong to consumers, who translate them into a `SandboxSpec` and hand it to a backend.

## Backends

| Platform | Backend                  | Notes                                                    |
| -------- | ------------------------ | -------------------------------------------------------- |
| macOS    | Seatbelt (`sandbox-exec`)| `/usr/bin/sandbox-exec` + generated SBPL                 |
| Linux    | bubblewrap (`bwrap`)     | Raises `SandboxUnsupportedError` if `bwrap` is absent or user namespaces are blocked |
| WSL2     | bubblewrap (`bwrap`)     | Picked automatically — `sys.platform == "linux"` and user namespaces work |
| WSL1     | (none)                   | Detected via `/proc/version`; `BwrapSandbox` raises with a "use WSL2" hint |
| Windows  | (not yet implemented)    | `select_sandbox()` returns `NoopSandbox` with a warning; native backend is a v2 follow-up |
| any      | `NoopSandbox`            | Construct directly when the caller wants no wrapping     |

On Ubuntu 24+ the unprivileged user namespaces bwrap relies on are gated by
an AppArmor profile shipped as `bwrap-userns-restrict`. Install it (or use
a distro-provided wrapper) if bwrap exits with `setting up uid map`.

## Quick example

```python
import os
from pathlib import Path
from os_sandbox import SandboxSpec, select_sandbox

spec = SandboxSpec(
    writable_paths=(Path.cwd(), Path("/tmp")),
    allow_network=False,
)
sandbox = select_sandbox()  # picks the right backend for the current platform

argv, env = sandbox.wrap(
    ["bash", "-c", "echo hi > /tmp/x.txt"],
    cwd=Path.cwd(),
    env=dict(os.environ),
    spec=spec,
)
# spawn argv as you normally would; the kernel enforces the spec.
```

## API

- **`SandboxSpec(writable_paths, allow_network)`** — pure-technical description of what a wrapped child may do. Empty `writable_paths` means the entire filesystem is read-only.
- **`select_sandbox() -> OsSandbox`** — pick a backend for the current platform. Returns `NoopSandbox` if no real backend is available (e.g. Windows today, or Linux without bwrap).
- **`NoopSandbox()`** — instantiate directly when the caller explicitly wants no wrapping. Useful for "sandbox off" paths so call sites don't have to branch.
- **`is_likely_sandbox_denied(stderr, exit_code) -> bool`** — heuristic so callers can distinguish kernel-denied failures from regular command errors.

## Design notes

- **Stand-alone**: zero non-stdlib dependencies, no coupling to any consumer app.
- **Pure argv transform**: `OsSandbox.wrap()` never spawns processes. Callers stay in control of how they spawn (subprocess, asyncio, etc.).
- **No mode vocabulary**: this package doesn't know about "off" / "read_only" / "workspace_write". Consumers map their own product-level vocabulary onto `SandboxSpec`.
- **Backends raise, not silently degrade**: `BwrapSandbox()` raises `SandboxUnsupportedError` if the binary is missing or user namespaces don't work. `select_sandbox()` catches this and falls back to `NoopSandbox` with a logged warning — but callers that want to fail loud can call backend constructors directly.

## Network policy

`allow_network=False` denies all outbound network. `allow_network=True` shares the host network namespace.

When network is denied, backends set `CODEX_SANDBOX_NETWORK_DISABLED=1` in the child env so existing tools (npm, pip build hooks) that already check this variable can skip network-dependent steps cleanly.
