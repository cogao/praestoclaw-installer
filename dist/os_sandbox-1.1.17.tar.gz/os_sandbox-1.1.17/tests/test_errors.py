from os_sandbox import SandboxDeniedError, SandboxUnsupportedError, is_likely_sandbox_denied
from os_sandbox.errors import SandboxError


def test_denied_and_unsupported_are_sandbox_errors() -> None:
    assert isinstance(SandboxDeniedError("x"), SandboxError)
    assert isinstance(SandboxUnsupportedError("y"), SandboxError)


def test_zero_exit_never_denied() -> None:
    assert is_likely_sandbox_denied("Operation not permitted", 0) is False


def test_none_exit_never_denied() -> None:
    assert is_likely_sandbox_denied("anything", None) is False


def test_empty_stderr() -> None:
    assert is_likely_sandbox_denied("", 1) is False


def test_macos_pattern() -> None:
    assert is_likely_sandbox_denied("Sandbox: bash(123) deny file-write-create /etc/x", 1) is True


def test_macos_pattern_without_prefix_not_matched() -> None:
    # "Operation not permitted" alone is a generic EPERM string; we no longer
    # treat it as sandbox denial to avoid false positives on chmod/rm/etc.
    assert is_likely_sandbox_denied("chmod: foo: Operation not permitted", 1) is False


def test_bwrap_pattern() -> None:
    assert is_likely_sandbox_denied("bwrap: Can't mount tmpfs: Permission denied", 1) is True


def test_landlock_pattern() -> None:
    assert is_likely_sandbox_denied("landlock_restrict_self failed", 13) is True


def test_unrelated_error_not_matched() -> None:
    assert is_likely_sandbox_denied("ENOENT: no such file or directory", 2) is False


def test_bare_eacces_not_matched() -> None:
    # Plain EACCES from a normal failing command must NOT be flagged.
    assert is_likely_sandbox_denied("rm: cannot remove '/x': EACCES", 1) is False
