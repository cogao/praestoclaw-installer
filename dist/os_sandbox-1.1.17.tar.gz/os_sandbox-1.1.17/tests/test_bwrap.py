"""Tests for the bubblewrap backend.

``build_argv`` is a pure function and is tested on every platform — only the
backend constructor and integration tests are Linux-gated.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

from os_sandbox import SandboxSpec
from os_sandbox.backends.bwrap import (
    SANDBOX_NETWORK_DISABLED_ENV,
    BwrapSandbox,
    build_argv,
    probe_user_namespace,
    proc_version_indicates_wsl1,
)
from os_sandbox.errors import SandboxUnsupportedError

# ---------- unit: argv generation (runs everywhere) ----------


def _args(text: list[str]) -> set[tuple[str, ...]]:
    """Bucket bwrap pair-args (``--ro-bind A B``) so order-insensitive asserts work."""
    pairs: set[tuple[str, ...]] = set()
    i = 0
    while i < len(text):
        tok = text[i]
        if tok in {"--ro-bind", "--bind", "--tmpfs", "--proc", "--dev"}:
            n = 3 if tok in {"--ro-bind", "--bind"} else 2
            pairs.add(tuple(text[i : i + n]))
            i += n
        else:
            i += 1
    return pairs


def test_no_network_emits_unshare_net(tmp_path: Path) -> None:
    argv = build_argv("/usr/bin/bwrap", SandboxSpec(), ["true"], cwd=tmp_path)
    assert "--unshare-net" in argv
    assert "--share-net" not in argv


def test_writable_paths_emit_bind(tmp_path: Path) -> None:
    argv = build_argv(
        "/usr/bin/bwrap",
        SandboxSpec(writable_paths=(tmp_path,)),
        ["true"],
        cwd=tmp_path,
    )
    pairs = _args(argv)
    assert ("--bind", str(tmp_path.resolve()), str(tmp_path.resolve())) in pairs


def test_multiple_writable_paths(tmp_path: Path) -> None:
    a = tmp_path / "a"
    a.mkdir()
    b = tmp_path / "b"
    b.mkdir()
    argv = build_argv(
        "/usr/bin/bwrap",
        SandboxSpec(writable_paths=(a, b)),
        ["true"],
        cwd=tmp_path,
    )
    pairs = _args(argv)
    assert ("--bind", str(a.resolve()), str(a.resolve())) in pairs
    assert ("--bind", str(b.resolve()), str(b.resolve())) in pairs


def test_tmpfs_only_when_tmp_writable(tmp_path: Path) -> None:
    """Empty writable_paths must not produce a writable /tmp tmpfs —
    that would violate the spec's read-only contract."""
    argv = build_argv("/usr/bin/bwrap", SandboxSpec(), ["true"], cwd=tmp_path)
    assert ("--tmpfs", "/tmp") not in _args(argv)


def test_tmpfs_when_tmp_in_writable_paths(tmp_path: Path) -> None:
    """When /tmp is explicitly in the writable set, we mount a fresh
    tmpfs there (avoids polluting host /tmp)."""
    argv = build_argv(
        "/usr/bin/bwrap",
        SandboxSpec(writable_paths=(Path("/tmp"),)),
        ["true"],
        cwd=tmp_path,
    )
    assert ("--tmpfs", "/tmp") in _args(argv)


def test_allow_network_omits_unshare_net(tmp_path: Path) -> None:
    """bwrap has no --share-net flag (using one fails at startup).
    To allow network, we omit --unshare-net so the child inherits the
    host net namespace."""
    argv = build_argv(
        "/usr/bin/bwrap",
        SandboxSpec(allow_network=True),
        ["true"],
        cwd=tmp_path,
    )
    assert "--unshare-net" not in argv
    assert "--share-net" not in argv, "bwrap has no --share-net flag"


def test_argv_separator_and_inner(tmp_path: Path) -> None:
    argv = build_argv("/usr/bin/bwrap", SandboxSpec(), ["echo", "hi"], cwd=tmp_path)
    sep = argv.index("--")
    assert argv[sep + 1 :] == ["echo", "hi"]
    assert argv[0] == "/usr/bin/bwrap"


def test_die_with_parent_included(tmp_path: Path) -> None:
    argv = build_argv("/usr/bin/bwrap", SandboxSpec(), ["true"], cwd=tmp_path)
    assert "--die-with-parent" in argv


def test_home_and_root_are_readonly_bound(tmp_path: Path) -> None:
    """Git reads ~/.gitconfig / ~/.ssh — without /home + /root binds those
    fail silently inside the namespace. Regression guard."""
    argv = build_argv("/usr/bin/bwrap", SandboxSpec(), ["true"], cwd=tmp_path)
    pairs = _args(argv)
    if Path("/home").exists():
        assert ("--ro-bind", "/home", "/home") in pairs
    if Path("/root").exists():
        assert ("--ro-bind", "/root", "/root") in pairs


def test_git_carve_out_layered_over_writable(tmp_path: Path) -> None:
    """``.git`` inside a writable root should re-appear as ``--ro-bind``
    AFTER the writable ``--bind``; last bind wins inside the namespace."""
    git_dir = tmp_path / ".git"
    git_dir.mkdir()
    argv = build_argv(
        "/usr/bin/bwrap",
        SandboxSpec(writable_paths=(tmp_path,)),
        ["true"],
        cwd=tmp_path,
    )
    # The writable bind must come BEFORE the readonly carve-out, else
    # the carve-out gets overwritten by the writable bind.
    writable_idx = None
    carveout_idx = None
    for i, tok in enumerate(argv):
        if tok == "--bind" and i + 2 < len(argv) and argv[i + 1] == str(tmp_path.resolve()):
            writable_idx = i
        if tok == "--ro-bind" and i + 2 < len(argv) and argv[i + 1] == str(git_dir.resolve()):
            carveout_idx = i
    assert writable_idx is not None, "writable bind missing"
    assert carveout_idx is not None, ".git carve-out missing"
    assert writable_idx < carveout_idx, "carve-out must follow writable bind"


def test_unsupported_when_bwrap_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("os_sandbox.backends.bwrap._which_bwrap", lambda: None)
    with pytest.raises(SandboxUnsupportedError, match="bwrap binary not found"):
        BwrapSandbox()


def test_unsupported_when_probe_fails(monkeypatch: pytest.MonkeyPatch) -> None:
    """User namespaces gated (WSL1, AppArmor, sysctl) → constructor raises."""
    monkeypatch.setattr("os_sandbox.backends.bwrap._which_bwrap", lambda: "/usr/bin/bwrap")
    monkeypatch.setattr(
        "os_sandbox.backends.bwrap.probe_user_namespace",
        lambda *_a, **_k: "user namespace denied (synthetic)",
    )
    with pytest.raises(SandboxUnsupportedError, match="user namespace"):
        BwrapSandbox()


def test_network_disabled_env_injected(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setattr("os_sandbox.backends.bwrap._which_bwrap", lambda: "/usr/bin/bwrap")
    monkeypatch.setattr("os_sandbox.backends.bwrap.probe_user_namespace", lambda *_a, **_k: None)
    sb = BwrapSandbox()
    _, env = sb.wrap(["echo"], cwd=tmp_path, env={"X": "1"}, spec=SandboxSpec())
    assert env.get(SANDBOX_NETWORK_DISABLED_ENV) == "1"
    assert env["X"] == "1"


def test_network_disabled_env_absent_when_network_allowed(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr("os_sandbox.backends.bwrap._which_bwrap", lambda: "/usr/bin/bwrap")
    monkeypatch.setattr("os_sandbox.backends.bwrap.probe_user_namespace", lambda *_a, **_k: None)
    sb = BwrapSandbox()
    _, env = sb.wrap(["echo"], cwd=tmp_path, env={}, spec=SandboxSpec(allow_network=True))
    assert SANDBOX_NETWORK_DISABLED_ENV not in env


def test_probe_returns_none_on_success(monkeypatch: pytest.MonkeyPatch) -> None:
    class _R:
        returncode = 0
        stderr = b""

    monkeypatch.setattr(subprocess, "run", lambda *a, **k: _R())
    assert probe_user_namespace("/usr/bin/bwrap") is None


def test_probe_classifies_user_namespace_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    class _R:
        returncode = 1
        stderr = b"bwrap: setting up uid map: Permission denied"

    monkeypatch.setattr(subprocess, "run", lambda *a, **k: _R())
    reason = probe_user_namespace("/usr/bin/bwrap")
    assert reason is not None
    assert "user namespaces" in reason
    assert "AppArmor" in reason or "WSL1" in reason


# ---------- unit: WSL1 detection (mirrors codex bwrap_tests.rs) ----------


@pytest.mark.parametrize(
    "proc_version",
    [
        "Linux version 4.4.0-22621-Microsoft",
        "Linux version 5.15.0-microsoft-standard-WSL1",
        "Linux version 5.15.0-wsl-microsoft-standard-WSL1",
    ],
)
def test_proc_version_detects_wsl1(proc_version: str) -> None:
    assert proc_version_indicates_wsl1(proc_version)


@pytest.mark.parametrize(
    "proc_version",
    [
        "Linux version 6.6.87.2-microsoft-standard-WSL2",
        "Linux version 6.6.87.2-wsl-microsoft-standard-WSL2",
        "Linux version 4.19.104-microsoft-standard",
        "Linux version 6.6.87.2-microsoft-standard-WSL3",
        "Linux version 6.8.0",
    ],
)
def test_proc_version_does_not_mistake_wsl2_or_native_for_wsl1(proc_version: str) -> None:
    assert not proc_version_indicates_wsl1(proc_version)


def test_bwrap_sandbox_rejects_wsl1(monkeypatch: pytest.MonkeyPatch) -> None:
    """WSL1 short-circuit fires before the user-namespace probe so the
    error message points users at the actionable fix (move to WSL2)."""
    monkeypatch.setattr("os_sandbox.backends.bwrap._which_bwrap", lambda: "/usr/bin/bwrap")
    monkeypatch.setattr("os_sandbox.backends.bwrap.is_wsl1", lambda: True)

    def _fail_probe(*_a: object, **_k: object) -> str:
        raise AssertionError("probe must not run when is_wsl1() is True")

    monkeypatch.setattr("os_sandbox.backends.bwrap.probe_user_namespace", _fail_probe)
    with pytest.raises(SandboxUnsupportedError, match="WSL2"):
        BwrapSandbox()


# ---------- integration: real bwrap spawn ----------

if sys.platform.startswith("linux"):
    import shutil as _shutil

    _BWRAP_AVAILABLE = _shutil.which("bwrap") is not None
else:
    _BWRAP_AVAILABLE = False


def _run(argv: list[str], cwd: Path) -> tuple[int, str, str]:
    res = subprocess.run(argv, cwd=str(cwd), capture_output=True, text=True, timeout=20)
    return res.returncode, res.stdout, res.stderr


@pytest.mark.integration
@pytest.mark.platform_linux
@pytest.mark.skipif(
    sys.platform != "linux" or not _BWRAP_AVAILABLE,
    reason="bwrap integration test requires Linux + bubblewrap",
)
def test_writable_path_allows_write(tmp_path: Path) -> None:
    sb = BwrapSandbox()
    target = tmp_path / "ok.txt"
    argv, _ = sb.wrap(
        ["/bin/sh", "-c", f"echo hi > {target}"],
        cwd=tmp_path,
        env={"PATH": "/usr/bin:/bin"},
        spec=SandboxSpec(writable_paths=(tmp_path,)),
    )
    code, _, err = _run(argv, tmp_path)
    assert code == 0, err
    assert target.read_text().strip() == "hi"


@pytest.mark.integration
@pytest.mark.platform_linux
@pytest.mark.skipif(
    sys.platform != "linux" or not _BWRAP_AVAILABLE,
    reason="bwrap integration test requires Linux + bubblewrap",
)
def test_empty_writable_denies_write(tmp_path: Path) -> None:
    sb = BwrapSandbox()
    target = tmp_path / "should-not-exist.txt"
    argv, _ = sb.wrap(
        ["/bin/sh", "-c", f"echo hi > {target}"],
        cwd=tmp_path,
        env={"PATH": "/usr/bin:/bin"},
        spec=SandboxSpec(),
    )
    code, _, _ = _run(argv, tmp_path)
    assert code != 0
    assert not target.exists()


@pytest.mark.integration
@pytest.mark.platform_linux
@pytest.mark.skipif(
    sys.platform != "linux" or not _BWRAP_AVAILABLE,
    reason="bwrap integration test requires Linux + bubblewrap",
)
def test_unshare_net_denies_outbound(tmp_path: Path) -> None:
    sb = BwrapSandbox()
    argv, _ = sb.wrap(
        ["/bin/sh", "-c", "getent hosts example.com >/dev/null && echo OK || echo FAIL"],
        cwd=tmp_path,
        env={"PATH": "/usr/bin:/bin"},
        spec=SandboxSpec(writable_paths=(tmp_path,)),
    )
    code, out, _ = _run(argv, tmp_path)
    assert "OK" not in out
