"""Tests for the Seatbelt backend.

The entire module is gated to macOS via a module-level skip — Seatbelt
import only works on darwin, and the pure-unit functions still exercise
real Apple SBPL primitives. Linux runs collect-then-skip these.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

from os_sandbox import SandboxSpec
from os_sandbox.errors import SandboxUnsupportedError

pytestmark = pytest.mark.platform_macos

if sys.platform != "darwin":  # pragma: no cover — collected, skipped on non-mac
    pytest.skip("Seatbelt backend only runs on macOS", allow_module_level=True)

from os_sandbox.backends.seatbelt import (  # noqa: E402
    SANDBOX_EXEC,
    SANDBOX_NETWORK_DISABLED_ENV,
    SeatbeltSandbox,
    _build_policy_and_params,
    build_policy,
)

# ---------- unit: policy text generation ----------


def test_empty_writable_paths_denies_writes() -> None:
    text = build_policy(SandboxSpec())
    assert "(deny default)" in text
    assert "(allow file-read*)" in text
    assert "(allow network*)" not in text
    # No writable rules at all.
    assert "(subpath (param" not in text


def test_writable_paths_use_param_indirection(tmp_path: Path) -> None:
    """Codex pattern: writable paths go through -D params, NOT string
    interpolation. This protects against SBPL injection if a path ever
    contains quotes / parens / newlines."""
    text, params = _build_policy_and_params(SandboxSpec(writable_paths=(tmp_path,)))
    # Path appears in params, NOT in policy text.
    assert ("WRITABLE_ROOT_0", str(tmp_path.resolve())) in params
    assert str(tmp_path.resolve()) not in text
    assert '(subpath (param "WRITABLE_ROOT_0"))' in text


def test_multiple_writable_paths(tmp_path: Path) -> None:
    a = tmp_path / "a"
    a.mkdir()
    b = tmp_path / "b"
    b.mkdir()
    text, params = _build_policy_and_params(SandboxSpec(writable_paths=(a, b)))
    assert ("WRITABLE_ROOT_0", str(a.resolve())) in params
    assert ("WRITABLE_ROOT_1", str(b.resolve())) in params
    assert '(subpath (param "WRITABLE_ROOT_0"))' in text
    assert '(subpath (param "WRITABLE_ROOT_1"))' in text


def test_git_carve_out_when_writable(tmp_path: Path) -> None:
    """``.git`` stays read-only inside writable roots."""
    text, _ = _build_policy_and_params(SandboxSpec(writable_paths=(tmp_path,)))
    assert "(deny file-write*" in text
    assert "/.git" in text


def test_allow_network_emits_rule() -> None:
    text = build_policy(SandboxSpec(allow_network=True))
    assert "(allow network*)" in text


def test_backend_construction(tmp_path: Path) -> None:
    sb = SeatbeltSandbox()
    assert sb.name == "seatbelt"
    argv, env = sb.wrap(["echo", "hi"], cwd=tmp_path, env={"X": "1"}, spec=SandboxSpec())
    assert argv[0] == SANDBOX_EXEC
    assert argv[1] == "-p"
    # No params on empty spec → argv layout: [exec, -p, policy, --, ...]
    assert argv[3] == "--"
    assert argv[4:] == ["echo", "hi"]


def test_wrap_passes_writable_via_dash_d(tmp_path: Path) -> None:
    sb = SeatbeltSandbox()
    argv, _ = sb.wrap(["echo"], cwd=tmp_path, env={}, spec=SandboxSpec(writable_paths=(tmp_path,)))
    # Find -D entries.
    d_args = [a for a in argv if a.startswith("-DWRITABLE_ROOT_")]
    assert d_args, f"expected -D params in argv, got {argv}"
    assert any(str(tmp_path.resolve()) in a for a in d_args)


def test_network_disabled_env_injected(tmp_path: Path) -> None:
    sb = SeatbeltSandbox()
    _, env = sb.wrap(["echo"], cwd=tmp_path, env={"X": "1"}, spec=SandboxSpec())
    assert env.get(SANDBOX_NETWORK_DISABLED_ENV) == "1"
    assert env["X"] == "1"


def test_network_disabled_env_absent_when_network_allowed(tmp_path: Path) -> None:
    sb = SeatbeltSandbox()
    _, env = sb.wrap(["echo"], cwd=tmp_path, env={}, spec=SandboxSpec(allow_network=True))
    assert SANDBOX_NETWORK_DISABLED_ENV not in env


def test_unsupported_when_sandbox_exec_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("os_sandbox.backends.seatbelt.SANDBOX_EXEC", "/nonexistent/sandbox-exec")
    with pytest.raises(SandboxUnsupportedError):
        SeatbeltSandbox()


# ---------- integration: real sandbox-exec spawn ----------


def _run(argv: list[str], cwd: Path) -> tuple[int, str, str]:
    res = subprocess.run(argv, cwd=str(cwd), capture_output=True, text=True, timeout=20)
    return res.returncode, res.stdout, res.stderr


@pytest.mark.integration
def test_read_only_allows_read(tmp_path: Path) -> None:
    target = tmp_path / "hello.txt"
    target.write_text("hi\n")
    sb = SeatbeltSandbox()
    argv, _ = sb.wrap(["/bin/cat", str(target)], cwd=tmp_path, env={}, spec=SandboxSpec())
    code, out, _ = _run(argv, tmp_path)
    assert code == 0, out
    assert out.strip() == "hi"


@pytest.mark.integration
def test_empty_writable_denies_write(tmp_path: Path) -> None:
    sb = SeatbeltSandbox()
    target = tmp_path / "should-not-exist.txt"
    argv, _ = sb.wrap(
        ["/bin/sh", "-c", f"echo hi > {target}"],
        cwd=tmp_path,
        env={},
        spec=SandboxSpec(),
    )
    code, _, err = _run(argv, tmp_path)
    assert code != 0, "expected sandbox to deny the write"
    assert not target.exists()
    assert err


@pytest.mark.integration
def test_writable_path_allows_write(tmp_path: Path) -> None:
    sb = SeatbeltSandbox()
    target = tmp_path / "ok.txt"
    argv, _ = sb.wrap(
        ["/bin/sh", "-c", f"echo hi > {target}"],
        cwd=tmp_path,
        env={"PATH": "/usr/bin:/bin"},
        spec=SandboxSpec(writable_paths=(tmp_path,)),
    )
    code, _, err = _run(argv, tmp_path)
    assert code == 0, err
    assert target.read_text().strip() == "hi"


@pytest.mark.integration
def test_write_outside_writable_denied(tmp_path: Path) -> None:
    """Writing outside the writable_paths union must be denied."""
    sb = SeatbeltSandbox()
    forbidden = Path.home() / ".os-sandbox-should-not-create"
    if forbidden.exists():
        pytest.skip("target file pre-exists; rerun after removing it")
    argv, _ = sb.wrap(
        ["/bin/sh", "-c", f"echo hi > {forbidden}"],
        cwd=tmp_path,
        env={"PATH": "/usr/bin:/bin"},
        spec=SandboxSpec(writable_paths=(tmp_path,)),
    )
    code, _, _ = _run(argv, tmp_path)
    assert code != 0
    assert not forbidden.exists()


@pytest.fixture
def _local_tcp_listener():
    """Bind a localhost TCP socket so network integration tests can probe
    a target that's deterministic across CI environments (no external
    dependency on 1.1.1.1 or any other public address)."""
    import socket

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    s.listen(1)
    port = s.getsockname()[1]
    try:
        yield port
    finally:
        s.close()


@pytest.mark.integration
def test_no_network_denies_outbound(tmp_path: Path, _local_tcp_listener: int) -> None:
    """Without allow_network, even a loopback TCP connect must fail —
    Seatbelt's deny-default network policy applies to all network*
    operations, not just public endpoints."""
    sb = SeatbeltSandbox()
    nc = Path("/usr/bin/nc")
    if not nc.exists():
        pytest.skip("/usr/bin/nc unavailable")
    argv, _ = sb.wrap(
        ["/usr/bin/nc", "-w", "2", "-z", "127.0.0.1", str(_local_tcp_listener)],
        cwd=tmp_path,
        env={"PATH": "/usr/bin:/bin"},
        spec=SandboxSpec(writable_paths=(tmp_path,), allow_network=False),
    )
    code, _, _ = _run(argv, tmp_path)
    assert code != 0, "expected nc to fail under sandbox without network"


@pytest.mark.integration
def test_allow_network_permits_outbound(tmp_path: Path, _local_tcp_listener: int) -> None:
    """allow_network=True must permit at least loopback TCP — using a real
    in-test listener instead of a public endpoint keeps CI deterministic."""
    sb = SeatbeltSandbox()
    nc = Path("/usr/bin/nc")
    if not nc.exists():
        pytest.skip("/usr/bin/nc unavailable")
    argv, _ = sb.wrap(
        ["/usr/bin/nc", "-w", "5", "-z", "127.0.0.1", str(_local_tcp_listener)],
        cwd=tmp_path,
        env={"PATH": "/usr/bin:/bin"},
        spec=SandboxSpec(writable_paths=(tmp_path,), allow_network=True),
    )
    code, _, _ = _run(argv, tmp_path)
    assert code == 0, "expected nc to succeed when allow_network=True"
