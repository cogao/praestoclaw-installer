from pathlib import Path

from os_sandbox import SandboxSpec
from os_sandbox.noop import NoopSandbox


def test_default_spec_is_locked_down() -> None:
    spec = SandboxSpec()
    assert spec.writable_paths == ()
    assert spec.allow_network is False


def test_paths_normalized(tmp_path: Path) -> None:
    nested = tmp_path / "ws" / "sub"
    nested.mkdir(parents=True)
    spec = SandboxSpec(writable_paths=(nested,))
    assert spec.writable_paths == (nested.resolve(),)


def test_with_extra_writable_dedups(tmp_path: Path) -> None:
    a = tmp_path / "a"
    a.mkdir()
    b = tmp_path / "b"
    b.mkdir()
    spec = SandboxSpec(writable_paths=(a,))
    extended = spec.with_extra_writable((a, b))
    assert extended.writable_paths == (a.resolve(), b.resolve())


def test_with_extra_writable_empty_returns_same() -> None:
    spec = SandboxSpec()
    assert spec.with_extra_writable(()) is spec


def test_with_extra_writable_all_known_returns_same(tmp_path: Path) -> None:
    a = tmp_path / "a"
    a.mkdir()
    spec = SandboxSpec(writable_paths=(a,))
    assert spec.with_extra_writable((a,)) is spec


def test_with_extra_writable_accepts_strings(tmp_path: Path) -> None:
    a = tmp_path / "a"
    a.mkdir()
    spec = SandboxSpec()
    extended = spec.with_extra_writable([str(a)])
    assert extended.writable_paths == (a.resolve(),)


def test_with_extra_writable_preserves_other_fields(tmp_path: Path) -> None:
    a = tmp_path / "a"
    a.mkdir()
    spec = SandboxSpec(allow_network=True)
    extended = spec.with_extra_writable((a,))
    assert extended.allow_network is True


def test_noop_wraps_unchanged(tmp_path: Path) -> None:
    spec = SandboxSpec()
    sb = NoopSandbox()
    argv, env = sb.wrap(["echo", "hi"], cwd=tmp_path, env={"X": "1"}, spec=spec)
    assert argv == ["echo", "hi"]
    assert env == {"X": "1"}
    assert sb.name == "noop"
