from pathlib import Path

import pytest

from os_sandbox import OsSandbox, SandboxSpec, select_sandbox
from os_sandbox.noop import NoopSandbox


def test_select_returns_protocol_compliant_backend() -> None:
    sb = select_sandbox()
    assert isinstance(sb, OsSandbox)
    assert isinstance(sb.name, str) and sb.name


def test_noop_satisfies_protocol() -> None:
    # Pin the runtime_checkable contract.
    assert isinstance(NoopSandbox(), OsSandbox)


def test_callers_can_construct_noop_directly(tmp_path: Path) -> None:
    # The "no sandbox at all" use case bypasses select_sandbox entirely.
    sb = NoopSandbox()
    argv, env = sb.wrap(["true"], cwd=tmp_path, env={}, spec=SandboxSpec())
    assert argv == ["true"]


@pytest.mark.parametrize(
    "platform",
    ["darwin", "linux", "linux2", "win32", "freebsd", "aix"],
)
def test_unknown_or_unsupported_platform_falls_back_to_noop(
    monkeypatch: pytest.MonkeyPatch,
    platform: str,
) -> None:
    """Force-fail backend imports so we exercise the fallback path on every OS branch."""
    import sys as _sys

    monkeypatch.setattr(_sys, "platform", platform)

    for cached in list(_sys.modules):
        if cached.startswith("os_sandbox.backends."):
            monkeypatch.delitem(_sys.modules, cached, raising=False)
    import os_sandbox.backends as backends_pkg

    monkeypatch.setattr(backends_pkg, "__path__", [])

    sb = select_sandbox()
    assert isinstance(sb, NoopSandbox), f"platform={platform} did not fall back"
    assert sb.name == "noop"
