"""Unified terminal input — cross-platform key reading for interactive UIs.

Replaces duplicate implementations in init.py, mcp_setup.py, and auth.py.
Supports Windows (msvcrt) and Unix/macOS (termios).
"""

from __future__ import annotations

import sys
from typing import Any, cast


def is_tty() -> bool:
    """Return True if both stdin and stdout are real terminals."""
    try:
        return sys.stdin.isatty() and sys.stdout.isatty()
    except Exception:
        return False


def stdin_is_tty() -> bool:
    """Return True if stdin is a real terminal (can read keys)."""
    try:
        return sys.stdin.isatty()
    except Exception:
        return False


# ── Key names returned by read_key_* ────────────────────────────────────────
# "up", "down", "left", "right", "enter", "esc", "space", "tab",
# or the literal character (e.g. "a", "q", "1").


def read_key_blocking() -> str:
    """Read a single keypress (blocks until a key is pressed).

    Returns a named key string: ``"up"``, ``"down"``, ``"enter"``,
    ``"esc"``, ``"space"``, or the literal character.
    Raises ``KeyboardInterrupt`` on Ctrl+C.
    Raises ``EOFError`` if stdin is not a TTY.
    """
    if not stdin_is_tty():
        raise EOFError("stdin is not a TTY")
    if sys.platform == "win32":
        return _win32_read(blocking=True)  # type: ignore[return-value]
    return _unix_read(blocking=True)  # type: ignore[return-value]


def read_key_nonblocking() -> str | None:
    """Check for a keypress without blocking.

    Returns ``None`` if no input is ready or stdin is not a TTY;
    otherwise same as ``read_key_blocking()``.
    """
    if not stdin_is_tty():
        return None
    if sys.platform == "win32":
        return _win32_read(blocking=False)
    return _unix_read(blocking=False)


# ── Platform implementations ────────────────────────────────────────────────


def _win32_read(*, blocking: bool) -> str | None:  # type: ignore[return-value]
    """Windows key reading via msvcrt."""
    import msvcrt  # type: ignore[import-not-found]  # Windows-only

    if not blocking and not msvcrt.kbhit():  # type: ignore[attr-defined]
        return None

    ch: str = msvcrt.getwch()  # type: ignore[attr-defined]
    if ch == "\x03":
        raise KeyboardInterrupt
    if ch in ("\x00", "\xe0"):
        # Arrow / function key prefix
        ch2: str = msvcrt.getwch()  # type: ignore[attr-defined]
        return {"H": "up", "P": "down", "K": "left", "M": "right"}.get(ch2, "")
    if ch == "\r":
        return "enter"
    if ch == "\x1b":
        return "esc"
    if ch == " ":
        return "space"
    if ch == "\t":
        return "tab"
    return ch


def _unix_read(*, blocking: bool) -> str | None:
    """Unix/macOS key reading via termios."""
    import os
    import termios
    import tty

    termios_mod = cast(Any, termios)
    tty_mod = cast(Any, tty)
    fd = sys.stdin.fileno()
    old = termios_mod.tcgetattr(fd)
    try:
        tty_mod.setraw(fd)

        if not blocking:
            import select

            if not select.select([sys.stdin], [], [], 0)[0]:
                return None

        ch = os.read(fd, 1).decode("utf-8", errors="replace")
        if ch == "\x03":
            raise KeyboardInterrupt
        if ch in ("\r", "\n"):
            return "enter"
        if ch == " ":
            return "space"
        if ch == "\t":
            return "tab"
        if ch == "\x1b":
            # ESC: could be bare ESC or start of arrow sequence (\x1b[A).
            # Peek with a short timeout to distinguish.
            import select

            if select.select([fd], [], [], 0.05)[0]:
                ch2 = os.read(fd, 1).decode("utf-8", errors="replace")
                if ch2 == "[" and select.select([fd], [], [], 0.05)[0]:
                    ch3 = os.read(fd, 1).decode("utf-8", errors="replace")
                    return {
                        "A": "up",
                        "B": "down",
                        "C": "right",
                        "D": "left",
                    }.get(ch3, "")
                return ""
            return "esc"
        return ch
    finally:
        termios_mod.tcsetattr(fd, termios_mod.TCSADRAIN, old)
