"""Background update worker for PraestoClaw — cross-platform.

On Windows this module waits for the locked entry-point exe to exit before
running pip (which would otherwise fail with a file-lock error). On all
platforms it also handles the daemon self-update path (``--reexec-update``):
kill the running daemon, then re-run ``pc update`` from a clean process.
"""

from __future__ import annotations

import argparse
import ctypes
import os
import subprocess
import sys
import time
from pathlib import Path

# Flags whose values may embed credentials (e.g. URLs with tokens). When echoing
# argv for diagnostics, we substitute "<redacted>" for the value of any of these.
_SENSITIVE_FLAGS = frozenset(
    {
        "--package",
        "--mirror",
        "--index-url",
        "--extra-index-url",
        "-i",
    }
)


def _redact_argv(argv: list[str]) -> list[str]:
    """Return a copy of ``argv`` with values of sensitive flags redacted.

    Handles both ``--flag value`` and ``--flag=value`` forms.
    """
    out: list[str] = []
    i = 0
    while i < len(argv):
        token = argv[i]
        if "=" in token:
            flag, _, _value = token.partition("=")
            if flag in _SENSITIVE_FLAGS:
                out.append(f"{flag}=<redacted>")
                i += 1
                continue
        if token in _SENSITIVE_FLAGS and i + 1 < len(argv):
            out.append(token)
            out.append("<redacted>")
            i += 2
            continue
        out.append(token)
        i += 1
    return out


def _wait_for_process_exit(pid: int, timeout_seconds: float | None = None) -> None:
    """Wait for a process to exit. Best-effort on POSIX; uses WaitForSingleObject on Windows."""
    if sys.platform != "win32":
        # POSIX: poll with kill(0)
        deadline = (time.time() + timeout_seconds) if timeout_seconds else None
        while True:
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                return
            except OSError:
                # Permission denied — process exists but in another user's
                # namespace; treat as alive for waiting purposes.
                pass
            if deadline is not None and time.time() >= deadline:
                return
            time.sleep(0.5)
        return

    synchronize = 0x00100000
    infinite = 0xFFFFFFFF
    kernel32 = ctypes.windll.kernel32
    handle = kernel32.OpenProcess(synchronize, False, pid)
    if not handle:
        return
    try:
        wait_ms = int(timeout_seconds * 1000) if timeout_seconds else infinite
        kernel32.WaitForSingleObject(handle, wait_ms)
    finally:
        kernel32.CloseHandle(handle)


def _kill_process(pid: int) -> None:
    """Terminate a process. Best-effort — no exception on failure."""
    if pid < 1:
        return
    if sys.platform == "win32":
        try:
            subprocess.run(
                ["taskkill", "/PID", str(pid), "/T", "/F"],
                capture_output=True,
                timeout=20,
            )
        except Exception:  # noqa: BLE001
            pass
        return
    import signal

    for sig in (signal.SIGTERM, signal.SIGKILL):
        try:
            os.kill(pid, sig)
        except ProcessLookupError:
            return
        except OSError:
            return
        time.sleep(1)


def _reexec_pc_update(original_args: list[str]) -> int:
    """Re-run ``pc update`` after the daemon is gone. Returns the exit code."""
    # Prefer the entry-point script so the user-visible command matches what
    # they would type manually. Fall back to ``python -m`` if the script is
    # not on PATH (e.g. a virtualenv without ``Scripts``/``bin`` activated).
    import shutil

    pc_path = shutil.which("praestoclaw") or shutil.which("pc")
    if pc_path:
        cmd = [pc_path, "update", *original_args]
    else:
        cmd = [sys.executable, "-m", "praestoclaw", "update", *original_args]
    print("Re-running:", " ".join(_redact_argv(cmd)), flush=True)
    try:
        result = subprocess.run(cmd)
    except OSError as exc:
        print(f"Failed to re-run pc update: {exc}", file=sys.stderr)
        return 1
    return result.returncode


def main() -> int:
    parser = argparse.ArgumentParser(description="PraestoClaw self-update background worker")
    parser.add_argument("--parent-pid", type=int, required=True)
    parser.add_argument("--cwd", default=None)
    parser.add_argument(
        "--start-praestoclaw",
        action="store_true",
        help="Start PraestoClaw after a successful update.",
    )
    parser.add_argument(
        "--reexec-update",
        action="store_true",
        help=(
            "Daemon self-update mode: kill --parent-pid then re-run "
            "`pc update` with the trailing argv. Used when the bot "
            "invokes pc update against its own process tree."
        ),
    )
    parser.add_argument("pip_args", nargs=argparse.REMAINDER)
    args = parser.parse_args()

    pip_args = list(args.pip_args)
    if pip_args and pip_args[0] == "--":
        pip_args = pip_args[1:]

    if args.reexec_update:
        # Give the bot ~2s to send its "update scheduled" reply through the
        # message bus before we yank the daemon out from under it.
        time.sleep(2)
        print(f"Stopping daemon PID {args.parent_pid}...", flush=True)
        _kill_process(args.parent_pid)
        _wait_for_process_exit(args.parent_pid, timeout_seconds=30)
        return _reexec_pc_update(pip_args)

    if not pip_args:
        print("No pip arguments provided.", file=sys.stderr)
        return 1

    _wait_for_process_exit(args.parent_pid)

    cwd = Path(args.cwd) if args.cwd else None
    cmd = [sys.executable, "-m", "pip", *pip_args]
    print("Running:", " ".join(_redact_argv(cmd)), flush=True)
    result = subprocess.run(cmd, cwd=cwd)
    if result.returncode == 0:
        print("PraestoClaw update complete.", flush=True)
        if args.start_praestoclaw:
            print("Running post-update startup sequence...", flush=True)
            try:
                step_result = subprocess.run(
                    ["praestoclaw", "init", "--quick"], cwd=cwd, timeout=300
                )
                if step_result.returncode != 0:
                    print(
                        f"Command failed ({step_result.returncode}): praestoclaw init --quick",
                        file=sys.stderr,
                    )
            except subprocess.TimeoutExpired:
                print("praestoclaw init --quick timed out (300s)", file=sys.stderr)
            except OSError as exc:
                print(f"Failed to run praestoclaw init --quick: {exc}", file=sys.stderr)

            print("Starting PraestoClaw server...", flush=True)
            try:
                subprocess.Popen(["praestoclaw", "s"], cwd=cwd)
            except OSError as exc:
                print(f"Failed to start PraestoClaw: {exc}", file=sys.stderr)
    else:
        print(f"PraestoClaw update failed with exit code {result.returncode}.", file=sys.stderr)
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
