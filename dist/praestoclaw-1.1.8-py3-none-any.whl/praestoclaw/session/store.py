"""Async SQLite session store with FTS5 full-text search."""

from __future__ import annotations

import json
import uuid
from datetime import UTC, datetime
from pathlib import Path

import aiosqlite

from praestoclaw.agent.compaction import count_tokens
from praestoclaw.utils.helpers import get_data_dir

_SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    channel TEXT NOT NULL,
    sender TEXT NOT NULL,
    model TEXT,
    parent_session_id TEXT,
    prompt_tokens INTEGER DEFAULT 0,
    completion_tokens INTEGER DEFAULT 0,
    cost REAL DEFAULT 0.0,
    title TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL REFERENCES sessions(id),
    role TEXT NOT NULL,
    content TEXT,
    tool_calls TEXT,
    tool_call_id TEXT,
    tokens INTEGER DEFAULT 0,
    created_at TEXT NOT NULL
);

CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5(
    content,
    content=messages,
    content_rowid=id
);

CREATE TRIGGER IF NOT EXISTS messages_ai AFTER INSERT ON messages BEGIN
    INSERT INTO messages_fts(rowid, content) VALUES (new.id, new.content);
END;

CREATE TRIGGER IF NOT EXISTS messages_ad AFTER DELETE ON messages BEGIN
    INSERT INTO messages_fts(messages_fts, rowid, content) VALUES ('delete', old.id, old.content);
END;

CREATE TRIGGER IF NOT EXISTS messages_au AFTER UPDATE ON messages BEGIN
    INSERT INTO messages_fts(messages_fts, rowid, content) VALUES ('delete', old.id, old.content);
    INSERT INTO messages_fts(rowid, content) VALUES (new.id, new.content);
END;
"""


def _now() -> str:
    return datetime.now(UTC).isoformat()


# Maps a session id prefix or legacy stored channel value to a UI group.
# Single source of truth — chat.js trusts the `group` field on each row.
_CHANNEL_PREFIXES: tuple[tuple[tuple[str, ...], str], ...] = (
    (("teams:", "cloud_teams"), "teams"),
    (("webchat:", "cloud_web", "cloud_webchat"), "web"),
    (("scheduler",), "scheduler"),
    (("a2a:", "u2u:"), "a2a"),
)

# Direct channel -> UI group mapping. Aliases collapse here (e.g. local_webchat -> web).
_CHANNEL_TO_GROUP: dict[str, str] = {
    "web": "web",
    "local_webchat": "web",
    "teams": "teams",
    "scheduler": "scheduler",
    "a2a": "a2a",
}


def _infer_channel_from_id(session_id: str) -> str:
    sid = (session_id or "").lower()
    for prefixes, channel in _CHANNEL_PREFIXES:
        if sid.startswith(prefixes):
            return channel
    return "cloud"


def _group_for_row(session_id: str, channel: str | None) -> str:
    ch = (channel or "").lower()
    if ch in _CHANNEL_TO_GROUP:
        return _CHANNEL_TO_GROUP[ch]
    return _infer_channel_from_id(session_id)


def _row_to_message(row: aiosqlite.Row) -> dict:
    """Convert a database row to a message dict."""
    msg: dict = {"role": row["role"]}
    # Only include content if non-empty, or if the role requires it.
    # Assistant messages with tool_calls may have content=None; sending
    # content="" to some providers triggers rejection.
    content = row["content"]
    if row["tool_calls"]:
        msg["tool_calls"] = json.loads(row["tool_calls"])
        if content:  # only set content when it's non-empty
            msg["content"] = content
    else:
        msg["content"] = content or ""
    if row["tool_call_id"]:
        msg["tool_call_id"] = row["tool_call_id"]
    return msg


class SessionStore:
    """Async SQLite session store with FTS5 search."""

    def __init__(self, db_path: Path | None = None) -> None:
        self._db_path = db_path or (get_data_dir() / "sessions.db")
        self._db: aiosqlite.Connection | None = None

    async def initialize(self) -> None:
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._db = await aiosqlite.connect(str(self._db_path))
        self._db.row_factory = aiosqlite.Row
        await self._db.execute("PRAGMA journal_mode=WAL")
        await self._db.executescript(_SCHEMA)
        await self._db.commit()

    async def close(self) -> None:
        if self._db:
            await self._db.close()
            self._db = None

    @property
    def _conn(self) -> aiosqlite.Connection:
        assert self._db is not None, "Store not initialized"
        return self._db

    async def get_or_create_session(self, channel: str, sender: str) -> str:
        existing = await self.find_session(channel, sender)
        if existing is not None:
            return existing
        sid = str(uuid.uuid4())
        now = _now()
        await self._conn.execute(
            "INSERT INTO sessions (id, channel, sender, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
            (sid, channel, sender, now, now),
        )
        await self._conn.commit()
        return sid

    async def find_session(self, channel: str, sender: str) -> str | None:
        cursor = await self._conn.execute(
            "SELECT id FROM sessions WHERE channel = ? AND sender = ? ORDER BY updated_at DESC LIMIT 1",
            (channel, sender),
        )
        row = await cursor.fetchone()
        return str(row["id"]) if row else None

    async def ensure_session(self, session_id: str, channel: str, sender: str) -> None:
        now = _now()
        await self._conn.execute(
            "INSERT OR IGNORE INTO sessions (id, channel, sender, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (session_id, channel, sender, now, now),
        )
        await self._conn.commit()

    async def session_exists(self, session_id: str) -> bool:
        # Messages-without-row covers legacy orphans surfaced by list_sessions;
        # treating them as existing keeps stale-link 404 detection honest.
        cursor = await self._conn.execute(
            "SELECT 1 FROM sessions WHERE id = ? "
            "UNION ALL SELECT 1 FROM messages WHERE session_id = ? LIMIT 1",
            (session_id, session_id),
        )
        return await cursor.fetchone() is not None

    async def add_message(self, session_id: str, message_dict: dict) -> int:
        now = _now()
        content = message_dict.get("content") or ""
        tokens = count_tokens(content)
        tool_calls = (
            json.dumps(message_dict["tool_calls"]) if "tool_calls" in message_dict else None
        )
        tool_call_id = message_dict.get("tool_call_id")
        cursor = await self._conn.execute(
            "INSERT INTO messages (session_id, role, content, tool_calls, tool_call_id, tokens, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (session_id, message_dict["role"], content, tool_calls, tool_call_id, tokens, now),
        )
        await self._conn.execute(
            "UPDATE sessions SET updated_at = ? WHERE id = ?", (now, session_id)
        )
        await self._conn.commit()
        return cursor.lastrowid  # type: ignore[return-value]

    async def get_messages(self, session_id: str, *, limit: int | None = None) -> list[dict]:
        if limit:
            cursor = await self._conn.execute(
                "SELECT * FROM (SELECT * FROM messages WHERE session_id = ? ORDER BY id DESC LIMIT ?) ORDER BY id ASC",
                (session_id, limit),
            )
        else:
            cursor = await self._conn.execute(
                "SELECT * FROM messages WHERE session_id = ? ORDER BY id ASC",
                (session_id,),
            )
        return [_row_to_message(r) for r in await cursor.fetchall()]

    async def replace_messages(self, session_id: str, messages: list[dict]) -> None:
        await self._conn.execute("DELETE FROM messages WHERE session_id = ?", (session_id,))
        if messages:
            for msg in messages:
                await self.add_message(session_id, msg)
        else:
            # add_message commits per call; when messages is empty the
            # DELETE must still be committed (e.g. /new clear session).
            await self._conn.commit()

    async def fork(self, session_id: str) -> str:
        # Get parent session info
        cursor = await self._conn.execute(
            "SELECT channel, sender FROM sessions WHERE id = ?", (session_id,)
        )
        row = await cursor.fetchone()
        assert row, f"Session {session_id} not found"
        child_id = str(uuid.uuid4())
        now = _now()
        await self._conn.execute(
            "INSERT INTO sessions (id, channel, sender, parent_session_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
            (child_id, row["channel"], row["sender"], session_id, now, now),
        )
        await self._conn.commit()
        return child_id

    async def search(
        self, query: str, *, session_id: str | None = None, limit: int = 20
    ) -> list[dict]:
        if session_id:
            cursor = await self._conn.execute(
                "SELECT m.* FROM messages m JOIN messages_fts f ON m.id = f.rowid WHERE f.content MATCH ? AND m.session_id = ? LIMIT ?",
                (query, session_id, limit),
            )
        else:
            cursor = await self._conn.execute(
                "SELECT m.* FROM messages m JOIN messages_fts f ON m.id = f.rowid WHERE f.content MATCH ? LIMIT ?",
                (query, limit),
            )
        return [_row_to_message(r) for r in await cursor.fetchall()]

    async def update_usage(
        self, session_id: str, prompt_tokens: int, completion_tokens: int, cost: float
    ) -> None:
        await self._conn.execute(
            "UPDATE sessions SET prompt_tokens = prompt_tokens + ?, completion_tokens = completion_tokens + ?, cost = cost + ?, updated_at = ? WHERE id = ?",
            (prompt_tokens, completion_tokens, cost, _now(), session_id),
        )
        await self._conn.commit()

    async def smart_load(self, session_id: str, token_budget: int) -> list[dict]:
        cursor = await self._conn.execute(
            "SELECT * FROM messages WHERE session_id = ? ORDER BY id DESC",
            (session_id,),
        )
        rows = await cursor.fetchall()
        result: list[dict] = []
        total = 0
        for row in rows:
            tokens = row["tokens"] or 0
            if total + tokens > token_budget and result:
                break
            result.append(_row_to_message(row))
            total += tokens
        result.reverse()
        return result

    async def list_sessions(self, *, channel: str | None = None, limit: int = 50) -> list[dict]:
        # Include message_count via LEFT JOIN; alias `id` to `session_id` so
        # the API surface matches the single-session endpoint.
        base = (
            "SELECT s.*, s.id AS session_id, "
            "COALESCE((SELECT COUNT(*) FROM messages m WHERE m.session_id = s.id), 0) "
            "AS message_count FROM sessions s"
        )
        if channel:
            cursor = await self._conn.execute(
                f"{base} WHERE s.channel = ? ORDER BY s.updated_at DESC LIMIT ?",
                (channel, limit),
            )
        else:
            cursor = await self._conn.execute(
                f"{base} ORDER BY s.updated_at DESC LIMIT ?", (limit,)
            )
        rows = [dict(r) for r in await cursor.fetchall()]

        if channel:
            for r in rows:
                r["group"] = _group_for_row(
                    r.get("session_id") or r.get("id") or "", r.get("channel")
                )
            return rows
        known_ids = {r.get("id") for r in rows}
        cursor = await self._conn.execute(
            "SELECT m.session_id AS session_id, COUNT(*) AS message_count, "
            "MAX(m.created_at) AS updated_at "
            "FROM messages m LEFT JOIN sessions s ON s.id = m.session_id "
            "WHERE s.id IS NULL "
            "GROUP BY m.session_id ORDER BY updated_at DESC LIMIT ?",
            (limit,),
        )
        for orow in await cursor.fetchall():
            sid = orow["session_id"]
            if not sid or sid in known_ids:
                continue
            rows.append(
                {
                    "id": sid,
                    "session_id": sid,
                    "channel": _infer_channel_from_id(sid),
                    "sender": "",
                    "message_count": orow["message_count"],
                    "updated_at": orow["updated_at"],
                    "orphan": True,
                }
            )
        for r in rows:
            r["group"] = _group_for_row(r.get("session_id") or r.get("id") or "", r.get("channel"))
        rows.sort(key=lambda r: r.get("updated_at") or "", reverse=True)
        return rows[:limit]

    async def delete_session(self, session_id: str) -> None:
        await self._conn.execute("DELETE FROM messages WHERE session_id = ?", (session_id,))
        await self._conn.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
        await self._conn.commit()
