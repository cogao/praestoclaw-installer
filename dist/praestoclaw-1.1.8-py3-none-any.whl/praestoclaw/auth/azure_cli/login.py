"""`az login` / `az account show` helpers.

The interactive login is intentionally blocking: it runs in the foreground
during ``praestoclaw init`` so the user sees the browser popup, completes
the flow, and the wizard can immediately verify that token acquisition
works before persisting the choice.

We never call ``az login`` from the running daemon — token expiry there
turns into a notify + degraded state, never an autonomous re-login (it
would hang waiting on browser interaction).
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from typing import Any

from loguru import logger


def _resolve_az() -> str | None:
    """Return the absolute path to the ``az`` binary, or None.

    On Windows, ``az`` is ``az.cmd`` — ``subprocess`` does not consult
    ``PATHEXT`` when launching directly (it does when ``shell=True``, but
    that introduces quoting hazards). ``shutil.which`` does honor
    ``PATHEXT``, so we resolve once here and pass the absolute path to
    ``subprocess`` everywhere.

    Falls through to a probe of well-known install directories when az is
    on disk but not yet on this process's PATH (e.g. winget just installed
    it, or this Python process started before the install).
    """
    found = shutil.which("az")
    if found is not None:
        return found
    from praestoclaw.auth.azure_cli.installer import _try_fixup_path_for_az

    _try_fixup_path_for_az()
    return shutil.which("az")


def is_logged_in() -> bool:
    """Return True when ``az account show`` succeeds (a session exists)."""
    az = _resolve_az()
    if az is None:
        return False
    try:
        result = subprocess.run(
            [az, "account", "show", "--output", "none"],
            check=False,
            capture_output=True,
            timeout=10,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        logger.debug("[azure_cli] account show probe failed: {}", exc)
        return False
    return result.returncode == 0


def interactive_login(tenant_id: str | None = None, *, console: Any | None = None) -> bool:
    """Run ``az login`` interactively. Return True on success.

    Blocking — control returns when the user finishes (or cancels) the browser
    flow. Refuses to run without a tty since the CLI prompts on stderr and
    expects ``az`` itself to spawn a browser.
    """
    if not sys.stdin.isatty():
        logger.warning("[azure_cli] no tty — refusing to run `az login`")
        return False

    az = _resolve_az()
    if az is None:
        logger.error("[azure_cli] `az` not found on PATH")
        return False

    cmd = [az, "login", "--output", "none", "--only-show-errors"]
    if tenant_id:
        cmd.extend(["--tenant", tenant_id])

    if console is not None:
        try:
            console.print(f"  [dim]Running:[/dim] az login {' '.join(cmd[2:])}")
            console.print("  [dim]A browser will open. Complete sign-in, then return here.[/dim]")
        except Exception:
            pass

    # az 2.61+ ships a "v2 login experience" that, when the tenant has
    # multiple subscriptions, lists them all and prompts the user to pick a
    # default. We don't care which subscription is default — we only need a
    # token — and on tenants with hundreds of subs the picker is overwhelming.
    # Disable v2 so az falls back to picking the first subscription silently.
    env = os.environ.copy()
    env["AZURE_CORE_LOGIN_EXPERIENCE_V2"] = "off"

    try:
        result = subprocess.run(cmd, check=False, env=env)
    except FileNotFoundError:
        logger.error("[azure_cli] `az` not found on PATH")
        return False
    except KeyboardInterrupt:
        logger.warning("[azure_cli] login interrupted by user")
        return False

    if result.returncode != 0:
        logger.warning("[azure_cli] `az login` exited with code {}", result.returncode)
        return False

    return is_logged_in()
