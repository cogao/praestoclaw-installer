"""Azure CLI auth provider.

Reuses the user's existing ``az login`` session to mint access tokens.
Silent path is a single subprocess (``az account get-access-token``);
the daemon owns no cache or refresh logic — az manages everything under
``~/.azure/``.

Interactive flow (``pc init`` and runtime menu re-pick) walks the user
through brew/winget/distro PM install when az is missing, then ``az login``
in the foreground, then mints a token to verify.

``supports_interactive`` is True for the install/login walkthrough, but
the provider cannot drive ``az login`` from a daemon — it requires a tty.
The caller is expected to have a real user terminal when interactive
sign-in is requested.
"""

from __future__ import annotations

import asyncio
import json
import sys
from typing import ClassVar

from loguru import logger
from rich.console import Console

from praestoclaw.auth.base import AuthResult


class AzureCliError(Exception):
    """Base class for azure_cli provider errors."""


class AzureCliNotInstalled(AzureCliError):  # noqa: N818 — kept descriptive
    """The ``az`` binary is not on PATH."""


class AzureCliNotLoggedIn(AzureCliError):  # noqa: N818 — kept descriptive
    """az has no active session, or its refresh token has expired."""


_NOT_LOGGED_IN_HINTS = (
    "AADSTS700082",
    "AADSTS50173",
    "AADSTS50078",
    "AADSTS50076",  # MFA required
    "Please run 'az login'",
    "az login --scope",
    "No subscription found",
)


_console = Console()


class AzureCliProvider:
    """:class:`AuthProvider` backed by the Azure CLI.

    *resource* — passed to ``--resource``; defaults to ARM since enterprise
    tenants commonly enforce CA Token Protection on Graph for non-FOCI
    clients (AADSTS530084). The gateway does not validate ``aud``.
    *tenant_id* — forwarded to ``az login --tenant`` during interactive flow.
    """

    name: ClassVar[str] = "azure_cli"
    display_label: ClassVar[str] = "Azure sign-in"
    supports_interactive: ClassVar[bool] = True

    def __init__(
        self,
        *,
        resource: str = "https://management.azure.com",
        tenant_id: str | None = None,
    ) -> None:
        self._resource = resource
        self._tenant_id = tenant_id

    def has_cached_credentials(self) -> bool:
        from praestoclaw.auth.azure_cli.login import is_logged_in

        try:
            return is_logged_in()
        except Exception:
            return False

    def try_silent(self) -> str | None:
        try:
            return asyncio.run(self._get_token_async())
        except RuntimeError as exc:
            if "running event loop" not in str(exc):
                logger.debug("[azure_cli] sync bridge failed: {}", exc)
                return None
            try:
                loop = asyncio.get_event_loop()
                fut = asyncio.run_coroutine_threadsafe(self._get_token_async(), loop)
                return fut.result(timeout=30)
            except Exception as inner:
                logger.debug("[azure_cli] threaded bridge failed: {}", inner)
                return None
        except Exception as exc:  # noqa: BLE001 — defensive
            logger.warning("[azure_cli] silent acquisition failed: {}", exc)
            return None

    def interactive_login(self) -> AuthResult:
        from praestoclaw.auth.azure_cli.installer import (
            detect_install_plan,
            install_az,
            is_az_installed,
        )
        from praestoclaw.auth.azure_cli.login import interactive_login, is_logged_in

        if not is_az_installed():
            plan = detect_install_plan()
            if plan is None:
                raise RuntimeError(
                    "No supported install method on this platform. Install Azure CLI"
                    " manually: https://learn.microsoft.com/cli/azure/install-azure-cli"
                )
            if not sys.stdin.isatty():
                raise RuntimeError(f"Non-interactive shell — please run: {' '.join(plan.cmd)}")
            _console.print(
                f"  [dim]Azure CLI not detected. Installing via {plan.label}"
                f" (~{plan.size_mb} MB, ~{plan.est_seconds}s"
                f"{', requires sudo' if plan.needs_sudo else ''})...[/dim]"
            )
            if not install_az(plan, console=_console):
                raise RuntimeError("Install did not complete successfully.")
            _console.print("  [green]+[/green] Azure CLI installed")

        if not is_logged_in():
            if not sys.stdin.isatty():
                raise RuntimeError("Not signed in. Run `az login` in a terminal, then retry.")
            _console.print("  [dim]Running `az login`...[/dim]")
            if not interactive_login(self._tenant_id, console=_console):
                raise RuntimeError("`az login` did not complete.")

        token = self.try_silent()
        if not token:
            raise RuntimeError(
                f"az is signed in but token acquisition failed for resource"
                f" {self._resource!r}. Check Conditional Access policies or"
                " override channels.cloud.azure_cli.resource in your local yaml."
            )

        _console.print(
            f"  [green]+[/green] Azure CLI auth successful [dim](resource: {self._resource})[/dim]"
        )
        return AuthResult(token=token, claims=_decode_claims(token))

    async def _get_token_async(self) -> str | None:
        import shutil

        from praestoclaw.auth.azure_cli.installer import _try_fixup_path_for_az

        az = shutil.which("az")
        if az is None:
            _try_fixup_path_for_az()
            az = shutil.which("az")
        if az is None:
            logger.warning("[azure_cli] `az` not on PATH — silent path unavailable")
            return None

        cmd = [
            az,
            "account",
            "get-access-token",
            "--resource",
            self._resource,
            "--output",
            "json",
        ]
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
        except FileNotFoundError as exc:
            logger.warning("[azure_cli] launch failed: {}", exc)
            return None

        stdout_b, stderr_b = await proc.communicate()
        stderr = stderr_b.decode("utf-8", errors="replace")

        if proc.returncode != 0:
            if any(hint in stderr for hint in _NOT_LOGGED_IN_HINTS):
                logger.warning(
                    "[azure_cli] not signed in (run `az login`): {}",
                    stderr.strip()[:300],
                )
            else:
                logger.warning(
                    "[azure_cli] az exited {}: {}",
                    proc.returncode,
                    stderr.strip()[:300],
                )
            return None

        try:
            payload = json.loads(stdout_b.decode("utf-8"))
        except json.JSONDecodeError as exc:
            logger.warning("[azure_cli] failed to parse az output: {}", exc)
            return None

        token = payload.get("accessToken")
        if not isinstance(token, str) or not token:
            logger.warning("[azure_cli] az output missing accessToken")
            return None
        return token


def _decode_claims(token: str) -> dict[str, object]:
    """Best-effort decode of a JWT payload section. Returns {} on failure."""
    import base64
    import json as _json

    try:
        parts = token.split(".")
        if len(parts) < 2:
            return {}
        payload = parts[1]
        padding = 4 - (len(payload) % 4)
        if padding != 4:
            payload = payload + ("=" * padding)
        decoded = base64.urlsafe_b64decode(payload.encode("ascii"))
        result = _json.loads(decoded)
        return result if isinstance(result, dict) else {}
    except Exception:
        return {}
