"""
Multi-pass context compressor — reduces context window usage while
preserving conversation coherence.

Three passes:
1. Prune old tool outputs (cheap, no LLM call)
2. Summarize middle messages via LLM
3. Assemble final message list with role-alternation fix

Anti-thrashing: after 2 consecutive ineffective compressions, skip.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any

from loguru import logger

from praestoclaw.agent.compaction import estimate_tokens
from praestoclaw.agent.tool_sanitizer import sanitize_tool_messages
from praestoclaw.providers.base import LLMProvider


@dataclass
class CompressorResult:
    """Result of a compression pass."""

    messages: list[dict[str, Any]]
    tokens_before: int
    tokens_after: int
    savings_percent: float
    method: str  # "pruned" | "summarized" | "fallback" | "skipped"


class ContextCompressor:
    """Multi-pass context compressor with anti-thrashing."""

    def __init__(
        self,
        provider: LLMProvider,
        *,
        protect_first_n: int = 3,
        protect_last_n: int = 20,
        post_threshold: float = 0.80,
        pre_threshold: float = 0.95,
        anti_thrashing_min_savings: float = 0.10,
    ) -> None:
        self._provider = provider
        self._protect_first_n = protect_first_n
        self._protect_last_n = protect_last_n
        self._post_threshold = post_threshold
        self._pre_threshold = pre_threshold
        self._anti_thrashing_min_savings = anti_thrashing_min_savings
        self._ineffective_count: int = 0

    def should_compress(self, prompt_tokens: int, context_limit: int) -> bool:
        return prompt_tokens / context_limit > self._post_threshold

    def should_preflight_compress(self, history_tokens: int, context_limit: int) -> bool:
        return history_tokens / context_limit > self._pre_threshold

    async def compress(
        self,
        messages: list[dict[str, Any]],
        *,
        current_tokens: int | None = None,
        focus_topic: str | None = None,
    ) -> CompressorResult:
        tokens_before = current_tokens or estimate_tokens(messages)

        # Anti-thrashing
        if self._ineffective_count >= 2:
            logger.debug("Compressor: skipping (anti-thrashing)")
            return CompressorResult(
                messages=messages,
                tokens_before=tokens_before,
                tokens_after=tokens_before,
                savings_percent=0.0,
                method="skipped",
            )

        # Pass 1: prune old tool outputs
        pruned = self._prune_tool_outputs(messages, self._protect_last_n)
        pruned_tokens = estimate_tokens(pruned)
        savings = 1.0 - (pruned_tokens / tokens_before) if tokens_before else 0.0

        if savings > 0.20:
            self._track_savings(savings)
            return CompressorResult(
                messages=pruned,
                tokens_before=tokens_before,
                tokens_after=pruned_tokens,
                savings_percent=savings,
                method="pruned",
            )

        # Pass 2: LLM summarization
        system_msgs = [m for m in pruned if m.get("role") == "system"]
        non_system = [m for m in pruned if m.get("role") != "system"]

        head_n = min(self._protect_first_n, len(non_system))
        tail_n = min(self._protect_last_n, len(non_system))

        # Adjust split points so they never land inside a tool-call group
        # (assistant with tool_calls + its tool responses must stay together)
        head_n = self._snap_to_group_boundary(non_system, head_n, direction="down")
        tail_start = len(non_system) - tail_n
        tail_start = self._snap_to_group_boundary(non_system, tail_start, direction="up")

        if head_n + (len(non_system) - tail_start) >= len(non_system):
            # Not enough middle to summarize
            self._track_savings(savings)
            return CompressorResult(
                messages=pruned,
                tokens_before=tokens_before,
                tokens_after=pruned_tokens,
                savings_percent=savings,
                method="pruned",
            )

        head = non_system[:head_n]
        middle = non_system[head_n:tail_start]
        tail = non_system[tail_start:]

        if len(middle) < 4:
            self._track_savings(savings)
            return CompressorResult(
                messages=pruned,
                tokens_before=tokens_before,
                tokens_after=pruned_tokens,
                savings_percent=savings,
                method="pruned",
            )

        summary = await self._generate_summary(middle, focus_topic)

        if summary is None:
            # Fallback: keep system + tail
            result_msgs = system_msgs + tail
            result_msgs = self._fix_role_alternation(result_msgs)
            result_msgs = sanitize_tool_messages(result_msgs, stub_missing=False)
            after = estimate_tokens(result_msgs)
            s = 1.0 - (after / tokens_before) if tokens_before else 0.0
            self._track_savings(s)
            return CompressorResult(
                messages=result_msgs,
                tokens_before=tokens_before,
                tokens_after=after,
                savings_percent=s,
                method="fallback",
            )

        # Pass 3: assemble
        summary_msg = {
            "role": "user",
            "content": f"[CONTEXT COMPACTION — REFERENCE ONLY]\n{summary}\n\n[END COMPACTION]",
        }
        result_msgs = system_msgs + head[:1] + [summary_msg] + list(tail)
        result_msgs = self._fix_role_alternation(result_msgs)
        result_msgs = sanitize_tool_messages(result_msgs, stub_missing=False)

        after = estimate_tokens(result_msgs)
        s = 1.0 - (after / tokens_before) if tokens_before else 0.0
        self._track_savings(s)

        return CompressorResult(
            messages=result_msgs,
            tokens_before=tokens_before,
            tokens_after=after,
            savings_percent=s,
            method="summarized",
        )

    def _track_savings(self, savings: float) -> None:
        if savings < self._anti_thrashing_min_savings:
            self._ineffective_count += 1
        else:
            self._ineffective_count = 0

    @staticmethod
    def _prune_tool_outputs(
        messages: list[dict[str, Any]], protect_last_n: int
    ) -> list[dict[str, Any]]:
        msgs = copy.deepcopy(messages)
        cutoff = max(0, len(msgs) - protect_last_n)

        for i in range(cutoff):
            m = msgs[i]
            if m.get("role") != "tool":
                continue
            content = m.get("content", "")
            if not isinstance(content, str) or len(content) <= 200:
                continue

            # Find tool name
            tool_name = "tool"
            tool_call_id = m.get("tool_call_id")
            if tool_call_id:
                for j in range(i - 1, -1, -1):
                    tc_list = msgs[j].get("tool_calls", [])
                    for tc in tc_list:
                        tc_id = tc.get("id") if isinstance(tc, dict) else None
                        if tc_id == tool_call_id:
                            fn = tc.get("function", {})
                            tool_name = fn.get("name", "tool") if isinstance(fn, dict) else "tool"
                            break

            lines = content.count("\n") + 1
            m["content"] = f"[{tool_name}] {content[:100]}... ({lines} lines, truncated)"

        return msgs

    async def _generate_summary(
        self, middle: list[dict[str, Any]], focus_topic: str | None
    ) -> str | None:
        lines: list[str] = []
        for m in middle:
            role = m.get("role", "?")
            content = str(m.get("content", ""))[:500]
            lines.append(f"[{role}]: {content}")

        topic_hint = f"\nFocus topic: {focus_topic}" if focus_topic else ""
        user_prompt = (
            "Summarize this conversation segment concisely. "
            "Preserve key decisions, code changes, file paths, and action items."
            f"{topic_hint}\n\n" + "\n".join(lines)
        )

        try:
            resp = await self._provider.complete(
                model="auto",
                messages=[
                    {"role": "system", "content": "You are a conversation summarizer. Be concise."},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.2,
                max_tokens=2000,
            )
            return resp.content if resp.content else None
        except Exception:
            logger.warning("Compressor: LLM summary failed, using fallback")
            return None

    @staticmethod
    def _fix_role_alternation(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        if not messages:
            return messages

        result: list[dict[str, Any]] = [messages[0]]
        for m in messages[1:]:
            prev = result[-1]
            # Never merge assistant messages that carry tool_calls
            if (
                m.get("role") == prev.get("role")
                and m.get("role") in ("user", "assistant")
                and not prev.get("tool_calls")
                and not m.get("tool_calls")
            ):
                prev_content = prev.get("content", "") or ""
                cur_content = m.get("content", "") or ""
                result[-1] = {**prev, "content": f"{prev_content}\n\n{cur_content}"}
            else:
                result.append(m)
        return result

    @staticmethod
    def _snap_to_group_boundary(
        messages: list[dict[str, Any]], idx: int, *, direction: str = "down"
    ) -> int:
        """Adjust an index so it doesn't land inside a tool-call group.

        A tool-call group is: assistant msg with tool_calls + consecutive tool responses.
        ``direction="down"`` moves idx earlier, ``"up"`` moves it later.
        """
        if idx <= 0 or idx >= len(messages):
            return idx

        if direction == "down":
            # If idx points at a tool response, move it back before the
            # assistant message that owns the group.
            while idx > 0 and messages[idx].get("role") == "tool":
                idx -= 1
            # If we landed on an assistant with tool_calls, move before it
            if idx > 0 and messages[idx].get("tool_calls"):
                idx -= 1
                # Skip past any preceding tool msgs from an even earlier group
                while idx > 0 and messages[idx].get("role") == "tool":
                    idx -= 1
        else:  # direction == "up"
            # If idx points inside a tool-call group, skip past the whole group.
            # First, check if the message *before* idx is an assistant with tool_calls
            # whose tool responses extend at or past idx.
            if idx > 0 and messages[idx - 1].get("tool_calls"):
                # Skip past all tool responses that follow
                while idx < len(messages) and messages[idx].get("role") == "tool":
                    idx += 1
            elif messages[idx].get("role") == "tool":
                # We're inside tool responses — find the end of this group
                while idx < len(messages) and messages[idx].get("role") == "tool":
                    idx += 1

        return idx
