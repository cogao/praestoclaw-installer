"""Outbound helpers and correlation tracking for business envelopes."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator, Mapping
from dataclasses import dataclass
from typing import Any, Protocol

from praestoclaw.gateway_protocol.business.debug_log import log_business_envelope_debug
from praestoclaw.gateway_protocol.business.envelope import BusinessError, Envelope, EnvelopeKind


class TransportSender(Protocol):
    """Minimal transport API used by the business layer."""

    async def send(self, payload: Any) -> Any: ...


@dataclass
class _PendingUnary:
    future: asyncio.Future[dict[str, Any]]


@dataclass
class _PendingStream:
    queue: asyncio.Queue[Any]


@dataclass(frozen=True)
class _StreamEnd:
    body: dict[str, Any]


class Outbound:
    """Business send helpers over an opaque transport sender."""

    def __init__(self, transport: TransportSender) -> None:
        self._transport = transport
        self._pending: dict[str, _PendingUnary | _PendingStream] = {}

    async def send_envelope(self, envelope: Envelope) -> None:
        await self._transport.send(envelope.to_dict())
        log_business_envelope_debug("tx", envelope)

    async def send_event(
        self,
        topic: str,
        body: Mapping[str, Any],
        *,
        headers: Mapping[str, Any] | None = None,
    ) -> None:
        await self.send_envelope(Envelope.event(topic, body, headers=headers))

    async def send_response(self, correlation_id: str, body: Mapping[str, Any]) -> None:
        await self.send_envelope(Envelope.response(correlation_id, body))

    async def send_stream_item(self, correlation_id: str, body: Mapping[str, Any]) -> None:
        await self.send_envelope(Envelope.stream_item(correlation_id, body))

    async def send_stream_end(
        self,
        correlation_id: str,
        body: Mapping[str, Any] | None = None,
    ) -> None:
        await self.send_envelope(Envelope.stream_end(correlation_id, body))

    async def send_error(self, correlation_id: str, error: BusinessError) -> None:
        await self.send_envelope(Envelope.error(correlation_id, error))

    async def request(
        self,
        topic: str,
        body: Mapping[str, Any],
        *,
        headers: Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        envelope = Envelope.request(topic, body, headers=headers)
        loop = asyncio.get_running_loop()
        future: asyncio.Future[dict[str, Any]] = loop.create_future()
        self._pending[envelope.id] = _PendingUnary(future)
        try:
            await self.send_envelope(envelope)
            return await asyncio.wait_for(future, timeout=timeout)
        except TimeoutError:
            await self.cancel(envelope.id, reason="timeout")
            raise
        finally:
            self._pending.pop(envelope.id, None)

    async def stream(
        self,
        topic: str,
        body: Mapping[str, Any],
        *,
        headers: Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        envelope = Envelope.request(topic, body, headers=headers)
        queue: asyncio.Queue[Any] = asyncio.Queue()
        self._pending[envelope.id] = _PendingStream(queue)
        try:
            await self.send_envelope(envelope)
            while True:
                item = await asyncio.wait_for(queue.get(), timeout=timeout)
                if isinstance(item, _StreamEnd):
                    break
                if isinstance(item, BusinessError):
                    raise item
                yield item
        except TimeoutError:
            await self.cancel(envelope.id, reason="timeout")
            raise
        finally:
            self._pending.pop(envelope.id, None)

    async def cancel(self, correlation_id: str, *, reason: str | None = None) -> None:
        await self.send_envelope(Envelope.cancel(correlation_id, reason=reason))

    async def fail_pending(self, error: BusinessError) -> None:
        """Fail all locally pending requests, usually after `resumed:false`."""

        pending_items = list(self._pending.items())
        self._pending.clear()
        for _, pending in pending_items:
            if isinstance(pending, _PendingUnary):
                if not pending.future.done():
                    pending.future.set_exception(error)
            else:
                await pending.queue.put(error)

    async def handle_incoming(self, envelope: Envelope) -> bool:
        """Resolve a pending request/stream if this envelope is a reply."""

        if envelope.kind not in {
            EnvelopeKind.RESPONSE,
            EnvelopeKind.STREAM_ITEM,
            EnvelopeKind.STREAM_END,
            EnvelopeKind.ERROR,
        }:
            return False
        if envelope.correlation_id is None:
            return False

        pending = self._pending.get(envelope.correlation_id)
        if pending is None:
            return False

        if isinstance(pending, _PendingUnary):
            self._resolve_unary(pending, envelope)
        else:
            await self._resolve_stream(pending, envelope)
        return True

    def _resolve_unary(self, pending: _PendingUnary, envelope: Envelope) -> None:
        if pending.future.done():
            return
        if envelope.kind is EnvelopeKind.RESPONSE:
            pending.future.set_result(dict(envelope.body))
        elif envelope.kind is EnvelopeKind.ERROR:
            pending.future.set_exception(BusinessError.from_body(envelope.body))
        else:
            pending.future.set_exception(
                BusinessError(
                    "invalid_envelope",
                    f"unexpected {envelope.kind.value} for unary request",
                    retryable=False,
                )
            )

    async def _resolve_stream(self, pending: _PendingStream, envelope: Envelope) -> None:
        if envelope.kind is EnvelopeKind.STREAM_ITEM:
            await pending.queue.put(dict(envelope.body))
        elif envelope.kind is EnvelopeKind.STREAM_END:
            await pending.queue.put(_StreamEnd(dict(envelope.body)))
        elif envelope.kind is EnvelopeKind.ERROR:
            await pending.queue.put(BusinessError.from_body(envelope.body))
        elif envelope.kind is EnvelopeKind.RESPONSE:
            await pending.queue.put(
                BusinessError(
                    "invalid_envelope",
                    "unexpected response for streaming request",
                    retryable=False,
                )
            )
