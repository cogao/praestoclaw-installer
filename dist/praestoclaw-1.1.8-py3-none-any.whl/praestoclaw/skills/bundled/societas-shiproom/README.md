# Societas Shiproom — 使用指南

一个 skill，扔进任意 IDE 就能跑团队每周的 shiproom。所有数据都在共享的 SharePoint 文件夹里，不用本地存数据，也不会因为每个人配置不同而走样。

## 它能做什么

- **会前**：团队任何成员用 `/sr-update` 更新自己负责的章节；host 用 `/sr-prep` 把 current.loop、数据快照、OCV 快照和大家更新的内容一起准备到 `current/`。
- **会中**：用 `/sr-notes` 实时记录决策，自动签上你的名字。
- **会后**：host 用 `/sr-archive` 先从 Teams meeting/chat 抓最新 notes，再把 `current/` 归档到 `history/<日期>/` 并清空，准备下一周。
- **任何时候**：用 `/sr-ask` 提问，agent 会从 `current/` 和 `history/*/` 里翻答案。

所有数据都存在这里：[Societas / Shiproom channel / Files / Shiproom/](https://microsoftapc.sharepoint.com/teams/Societas/Shared%20Documents/Shiproom)

## 首次设置（每个人一次就够）

1. **把 `societas-shiproom/` 文件夹放进 IDE 的 skill 目录**。不需要 `git clone`，拷贝过去就行。位置取决于 IDE：
   - **Claude Code / Cursor**：`~/.claude/skills/societas-shiproom/`（用户级）或 `<项目>/.claude/skills/societas-shiproom/`（项目级）
   - **GitHub Copilot (VS Code)**：放在 workspace 的任何位置，agent 会从 `SKILL.md` 的 frontmatter 识别它
   - **其他 IDE**：按各自的 skill 加载约定
2. 装一次 Python 依赖：
   ```bash
   pip install -r societas-shiproom/framework/scripts/requirements.txt
   ```
3. 登录一次：
   ```bash
   python societas-shiproom/framework/scripts/cloud_cli.py whoami
   ```
   会弹一个微软登录窗，用你的 `@microsoft.com` 工作账号。后续运行全部静默。
4. 确认你是 Societas Teams team 的成员。如果 403，去 channel 里找 owner 拉你进去。

## 常见场景

### 作为团队成员，会前

> “我要更新 todo：VFS bug 修好了，alice 负责，周三上线。”

Agent 会把它归到 `1-todo`，可能问一个澄清问题，然后调 `cloud_cli update 1-todo "..."`。你会拿到一个 SharePoint 链接，你的条目上会签上 `@<你的 handle>`。

### 作为 host，会前

> “帮我准备一下 shiproom。”

Agent 会走一遍 checklist（详见 [`framework/rules/prep.md`](framework/rules/prep.md)）：
1. 自动抓最新 Loop（`cloud_cli fetch-loop`，静默 headless）。失败时弹一个可见窗口让你 SSO 一次；如果这个也不行，会把 Loop URL 给你，让你导出为 PDF 后 `/sr-upload-loop`。
2. 自动把 Loop 内容按章节拆到各个 section 文件（`1-todo`/`4-release`/`5-gdpval`/`6-deep-worker`/`7-others`）的 `<!-- BEGIN LOOP-SYNC -->` 块里——你手动 `/sr-update` 的条目在 marker 块外面，不会被覆盖。
3. 提醒你：Claire 应该已经上传了 `2-data.md`；如果没传或太旧会 ping 一下。
4. 自动重抓 OCV（`cloud_cli fetch-ocv`）。
5. 从 SharePoint 读一遍本周累积的所有 section 内容（LOOP-SYNC 块内的自动来源 + 块外的人工更新）。
6. 生成会前总结，然后用硬编码渲染器 `cloud_cli render-view` 生成固定格式的 `view.html` dashboard 上传到 `current/`。Agent 给你一条 SharePoint 链接，点开就能在浏览器看；同时也下载一份到当前 workspace 作为 IDE 内的备用预览。

### 任何人，会中或会后

> “Notes: 决策——保留两个 branch 满足 compliance。”

Agent 调 `cloud_cli notes "..."`，自动签上你的 @handle。

### 作为 host，会后

> “把这周归档了。”

Agent 会走完会后收尾流程（详见 [`framework/rules/archive.md`](framework/rules/archive.md)）：
1. 跑 `cloud_cli status` 看 `current/` 里什么趋势。
2. 从 Teams 群里自动抓最新会议 notes 的 Loop（`cloud_cli fetch-notes`）。和 `fetch-loop` 同一套三层 fallback：静默 → 可见窗口 SSO → 手动 PDF 上传 `/sr-upload-notes`。
3. 问你要不要补一个总结性的 `/sr-notes`。
4. 确认归档日期，再推次确认（这个操作会清空 current/），然后跑 `cloud_cli archive`。`current/` → `history/<日期>/`，然后 `current/` 被清空。

### 任何人，任何时候

> “上个月关于 enterprise compliance 我们决定了什么？”

Agent 跑 `cloud_cli list-history`，挑 1–3 个可能的日期，读其 `notes.md` 和 `updates/*.md`，总结出答案并带上 SharePoint 链接引用。

## 文件与目录结构

整个 `Shiproom/` 就两部分：

- **`current/`** —— 本周正在跑的内容
- **`history/<日期>/`** —— 每次 `/sr-archive` 把 `current/` 整个拷贝过来的一份存档（结构和 `current/` 一模一样）

`current/` 内部长这样：

```
current/
├── currentloop.md         /sr-fetch-loop 自动抓取
├── currentloop.pdf        抓取失败时 host 兜底上传的 PDF
├── notes.md               /sr-fetch-notes 自动抓 + 任何人 /sr-notes 追加
├── notes.pdf              抓取失败时 host 兜底上传的 PDF
├── view.html              /sr-prep 用硬编码 renderer 生成的会议 dashboard
└── updates/               本周大家关心的所有正文（0–7）
    ├── 0-meeting-prep-summary.md     agent 在 /sr-prep 最后生成
    ├── 1-todo.md                     团队 /sr-update + 从 currentloop 切出的 Action Items 段
    ├── 2-data.md                     团队 /sr-update + Claire 每周 /sr-upload-md 的数据快照
    ├── 3-ocv.md                      团队 /sr-update + /sr-fetch-ocv 抓的 OCV 表
    ├── 4-release.md                  团队 /sr-update + 从 currentloop 切出的 release 段
    ├── 5-gdpval.md                   团队 /sr-update + 从 currentloop 切出的 GDPVal 段
    ├── 6-deep-worker.md              团队 /sr-update + 从 currentloop 切出的 Digital Worker 段
    └── 7-others.md                   团队 /sr-update + 从 currentloop 切出的杂项（AAD、MCP、MSA…）
```

`updates/1`–`7` 的两个来源是这样合在一个文件里的：自动来源（切片或 fetch）写在 `<!-- BEGIN LOOP-SYNC -->` 和 `<!-- END LOOP-SYNC -->` 之间，每次重跑会被整块覆盖；团队 `/sr-update` 写在 marker 块**下面**，永远不会被覆盖。

## 故障排查

- **MSAL 窗口反复弹** — token 缓存在 `%LOCALAPPDATA%\.IdentityService\msal.cache.bin3`，删掉重新登录。
- **SharePoint 返回 403** — 你不是 Societas team 成员，去 channel 里说一声让 owner 拉你进去。
- **`/sr-fetch-loop` 或 `/sr-fetch-notes` 弹出可见浏览器** — 这台机器首次 SSO，或者是你第一次访问某个组织者的 OneDrive。登录 / 同意 “request access” 后回 terminal 按 ENTER。后续运行静默。
- **连可见浏览器都失败** — 脚本会在 stderr 打出 Loop URL。手动打开 → `Print & PDF export` → 保存 PDF → `/sr-upload-loop <pdf>` 或 `/sr-upload-notes <pdf>`。Agent 会接手后续。
- **PowerShell 把文件转乱了** — Windows 上千万别用 `cloud_cli read ... > file.md`这种重定向，它会重编码为 UTF-16。请用 `cloud_cli download <remote> <local>`。

## 参考

- 斜杠命令定义 → [AGENT.md](./AGENT.md)
- 各命令 playbook（update / prep / archive / ask）→ [framework/rules/](./framework/rules/)
- 权限与安全约定 → [PERMISSIONS.md](./PERMISSIONS.md)
- Workspace 配置 → [shiproom-config.yaml](./shiproom-config.yaml)
