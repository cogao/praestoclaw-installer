# /sr-ask 检索与回答策略

## 检索范围

- `history/<date>/**/*.md` —— 所有归档 shiproom 的 content + notes（用 `cloud_cli read` 读取）
- `current/**/*.md` —— 本周尚未开会的累积内容（让用户能问"本周到目前为止…"）

可用 archive 日期通过 `cloud_cli list-history` 拿到（不要 hardcode 日期，list 一下挑最相关的 1-3 个）。

典型 CLI 调用：

```bash
# 看有哪些归档
python framework/scripts/cloud_cli.py list-history

# 拉某一周的具体文件
python framework/scripts/cloud_cli.py read history/2026-04-29/notes.md
python framework/scripts/cloud_cli.py read history/2026-04-29/updates/1-todo.md

# 或者本周
python framework/scripts/cloud_cli.py read current/updates/4-release.md
```

## AI 自动判断问题类型(用户无感)

判断维度:**问题是否带时间跨度 / 趋势词汇 / 聚合需求**。

### 事实问答(单点查找)
- 信号:具体编号、单一日期、"什么时候"、"是谁"、"在哪次会"
- 例:
  - "#4521 是哪次 shiproom 提的?"
  - "上周三 GDPval 的结论是什么?"
  - "Alice 上次的 action item 是什么?"
- 处理:用 `cloud_cli read history/<date>/updates/<section>.md` 或 `notes.md` 定位条目,**直接引用原文回答**

### 趋势问答(跨会议汇总)
- 信号:"最近"、"过去 N 周"、"趋势"、"对比"、"变化"、"整体"
- 例:
  - "GDPval 最近 4 周趋势如何?"
  - "Feedback 里负反馈占比的变化?"
  - "Release Status 这个月 blocker 数量?"
- 处理:扫描相关日期范围,提取相关字段,**给出趋势描述 + 各时间点数据 + 引用列表**

### 混合型
- 既问事实又问对比时,先答事实再补趋势

## 回答要求

1. **必带引用**:SharePoint web URL，用 `cloud_cli url history/<date>/<具体文件>` 获取
2. **找不到就说找不到**,绝不编造。回答模板:`未在 history 中找到关于 X 的记录。建议:① 检查日期范围 ② 用 /sr-update 补录`
3. **简洁**:事实问答 ≤ 3 句话;趋势问答 ≤ 1 段 + 引用列表
4. **数字必须从原文中来**,不要计算/推算到原文没有的精度

## 消歧

- 用户问题模糊(如 "那个 bug 怎么样了") → 追问最多 1 次,提供候选项
- 候选项 > 5 时,要求用户提供更多线索(日期、议程项、Owner)
