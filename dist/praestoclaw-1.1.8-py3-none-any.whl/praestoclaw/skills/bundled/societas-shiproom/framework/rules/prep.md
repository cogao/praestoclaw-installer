# `/sr-prep` — Pre-meeting Orchestration Playbook

**Audience:** AI agents (Copilot, Cloud Code, PM Studio, etc.). Humans don't run these steps.

**Trigger phrases:** "我要开始准备会议" / "帮我准备一下" / "/sr-prep" / "prep the meeting" / "shiproom prep" → enter this flow.

This file is the single source of truth for the prep flow. The high-level mention in [`AGENT.md` §2.8](../../AGENT.md) points here.

---

## 0. Announce + plan (do this first, before any tool call)

The host should know what's about to happen. Send one short message:

> 我开始准备本周 shiproom，会按下面步骤走：
>
> 1. 跑 checklist，看哪些文件需要刷新。
> 2. 抓最新 Loop，并切分到各个 section。
> 3. 检查 Data 快照是否已上传/是否新鲜。
> 4. 重抓 OCV 快照。
> 5. 读取本周所有 sections 的内容。
> 6. 生成 prep summary 和 view.html。
> 7. 给出 SharePoint 链接并确认完成。
>
> 一般 1–2 分钟，需要你介入时我会停下来问。

Then proceed.

---

## 1. Checklist — `cloud_cli.py prep`

```bash
python framework/scripts/cloud_cli.py prep
```

The script tags every expected file:

| Tag | Meaning | Action |
|---|---|---|
| `[OK]`     | Present, fresh | nothing |
| `[MISS]`   | Not in `current/` | fetch / upload |
| `[STALE]`  | `refresh` kind, mtime before this ISO week's Monday or > 48h old | re-fetch (Steps 2–4) |
| `[LEFT]`   | `accumulate` kind, mtime before this ISO week's Monday | last meeting wasn't archived — see §1.1 |

### 1.1 If you see `[LEFT]` — STOP and ask the host

Example:
> `1-todo.md`, `4-release.md` 等还是 2026-05-04 的，看起来上周会议没归档。要不要我先 archive 上周（`history/2026-05-04/`），再开始这周的准备？
>
> - `yes` / `好` → 我会跑 `/sr-archive 2026-05-04`（即 `cloud_cli.py archive 2026-05-04`，**默认 carry-forward，不清空 current/**），然后接 Step 2 重抓 LOOP-SYNC 块
> - `no, 上周内容这周还要用` → 上周的 LOOP-SYNC 部分会被新一轮 fetch-loop 覆盖；上周的 manual `/sr-update` 条目（`### @user · ISO`）renderer 会自动按时间戳过滤掉，**不会泄漏到本周 view.html**，所以这条选项其实没必要选
> - `let me check` → 等你回复

**Carry-forward 模式下的安全保证**（从 archive.md 复述）：
1. fetch-loop / fetch-ocv 会覆盖 LOOP-SYNC 块 + 更新 `<!-- Auto-synced at <ISO> -->` 时间戳。
2. render_view 读 `current/.last-archive` 作为 cutoff，过滤掉 `### @user · ISO` 时间戳 < cutoff 的 manual entry，原文件保留。
3. 没刷新的文件 mtime 仍是上个周期 → checklist 报 `[STALE]` → host 看得见。
4. **多会议节奏（周三 + 周五）自动适配**：cutoff = 上次 `/sr-archive` 时间，不需要硬编码会议日。只要 host 会后及时归档，下次 view 自动只含本会议周期内的 update。

**Never silently proceed and reuse last week's content as if it were this week's.**

---

## 2. Loop content (`refresh`) — `fetch-loop` first, PDF fallback

```bash
python framework/scripts/cloud_cli.py fetch-loop
```

### Success path (exit 0)
- Writes `current/currentloop.md` (full Loop innerText via headless Chrome).
- Auto-splits sections into the LOOP-SYNC block of each target file:
  - `Action Items` → `current/updates/1-todo.md`
  - `Pending release` / `Lab Release plan` / `Consumer Release ...` → `4-release.md`
  - `GDPVal` / `GDPVal-AA Manufacturing` → `5-gdpval.md`
  - `Digital Worker & Quality` → `6-deep-worker.md`
  - `MSA Security Review` / `Excel agent` / `Commercial compliance` / `MCP Hubs` / `AAD ...` → `7-others.md`
- Human `/sr-update` entries (outside the markers) are preserved.

Tell the host: ✅ Loop 已抓取并切片，1/4/5/6/7 自动部分已更新。

### Failure path (exit 3 or 1)
The script printed the Loop URL on stderr. Surface it to the host **verbatim**:

> Auto-fetch failed: `<reason>`. 请打开下面的 Loop 页面，用 `...` → `Print & PDF export` → Save as PDF，然后把 PDF 直接拖进对话里（我来上传）：
>
> `<loop_url>`

When the host attaches the PDF in chat:
1. Save it to a local path (e.g. workspace tmp).
2. Run `python framework/scripts/cloud_cli.py upload-loop <saved-path>`.
3. The script uploads the PDF AND extracts text via pdfminer AND runs the same splitter — so 1/4/5/6/7 still get refreshed.
4. **Do NOT make the host run any CLI command themselves.**

---

## 3. Data snapshot (`refresh`) — Claire-owned

`current/updates/2-data.md` is uploaded by Claire each week. There is no auto-fetch script.

- If `prep` showed `[OK]` for `2-data.md` → skip.
- If `[STALE]` or `[MISS]`:
  - Default: ping Claire to re-run the usage-analysis report and upload.
  - Fallback: if the host already has the markdown locally:
    ```bash
    python framework/scripts/cloud_cli.py upload-md <local> current/updates/2-data.md
    ```
    This **merges** the new snapshot into the LOOP-SYNC block; any human `/sr-update 2-data` entries below the block survive.

---

## 4. OCV snapshot (`refresh`) — always re-fetch

```bash
python framework/scripts/cloud_cli.py fetch-ocv
```

- Reads the workbook at `ocv_source.remote_path` (default `Shiproom/Societas OCV Issues & Bugs.xlsx`) via Microsoft Graph.
- Picks the latest sheet per `ocv_source.sheet_pick` (default `last`).
- Merges a markdown table summary into `current/updates/3-ocv.md`'s LOOP-SYNC block.
- Human `/sr-update 3-ocv` entries below the block are preserved.

If exit is non-zero (config wrong / file missing): print the error verbatim, ask host to fix the config or upload the workbook into `Shiproom/`.

---

## 5. Read this week's accumulated human updates

本周团队成员通过 `/sr-update` 写入的人工内容都在以下几个文件里（连同 LOOP-SYNC 块里刚刚刷新过的 Loop / data / OCV 来源内容）。Agent 必须全部读进上下文，作为 Step 6 生成总结的原材料：

```bash
python framework/scripts/cloud_cli.py read current/updates/1-todo.md
python framework/scripts/cloud_cli.py read current/updates/2-data.md
python framework/scripts/cloud_cli.py read current/updates/3-ocv.md
python framework/scripts/cloud_cli.py read current/updates/4-release.md
python framework/scripts/cloud_cli.py read current/updates/5-gdpval.md
python framework/scripts/cloud_cli.py read current/updates/6-deep-worker.md
python framework/scripts/cloud_cli.py read current/updates/7-others.md
```

---

## 6. Generate prep summary + view.html (one step)

生成两个产出同时上传，不再额外问 host。

### 6.1 Prep summary

`0-meeting-prep-summary.md` 是 view.html 的**唯一分析来源**。`render_view.py` 只搬运不分析，所以**这一步偷懒，会议页面就会缺分析**。每个 section 的分析内容都必须先在这里落地。

#### 6.1.1 Required heading schema (renderer contract)

prep summary **必须**包含下列 heading 字面值，缺一个 renderer 就抓不到对应 section 的 intro（会回退到原始 markdown，没有 AI 分析）：

```
# 0 — Meeting Prep Summary (<date>)
## 🚨 Top Risks (...)                  ← 必填
## ① To Do (1-todo)                   ← 必填
## ② Data (2-data)                    ← 必填
## ③ OCV (3-ocv)                      ← 必填
## ④ Release (4-release)              ← 必填
## ⑤ Deep Worker (6-deep-worker)      ← 必填（注意编号 5 对应文件 6-deep-worker）
## ⑥ GDPVal (5-gdpval)                ← 必填（注意编号 6 对应文件 5-gdpval）
## ⑦ Others (7-others)                ← 必填
## ✅ Suggested Discussion Order      ← 可选
```

可以另外加 `## 📊 本周 vs 上周 ...` / `## 🎯 OCV — 本周 vs 上周对比` 这类辅助对比表放在 Top Risks 之后、① To Do 之前，不会破坏 schema。

#### 6.1.2 Per-section content rules

每个 section 的写法明确分两类：**要分析的** vs **只搬运的**。Renderer 抓 heading 下面的 bullet 作为 intro paragraph，所以**分析内容必须用 `-` bullet 列出，不要写成大段散文，更不要写"详见 xx.md"或纯 link**。

| Section | 是否需要 AI 分析 | 内容要求 |
|---|---|---|
| **🚨 Top Risks** | ✅ **必须分析** | 3–6 条 numbered list。每条一句话点出 risk + 数据 + owner + meeting ask。**禁止只写 "Review X"** 这类占位话。**这一节是 view.html Top Risk 的唯一来源**，写不出来等于会议没有 risk callout。 |
| **① To Do** | ❌ 不分析 | 一段简述本周 vs 上周变化（哪些新增 / 完成 / 仍 in progress），具体 action item 表交给 view.html 从 `1-todo.md` 渲染。不要复制 action item 全表。 |
| **② Data** | ⚠️ **只写 meeting ask，不复述事实** | 2–3 条 bullet：**只挑出会上要讨论的点**（哪个指标异常需谁跟、是否影响发版决策、是否需要加 follow-up）。**禁止复述具体数字 / 趋势** —— Claire 报告里的 Executive Overview + Key Takeaways 会被 renderer 直接渲染在下方，prep agent 再写一遍是重复。如果本周确实没有需要讨论的点，写一条 "_本周数据无需讨论，详见下方 Key Takeaways_" 即可。 |
| **③ OCV** | ✅ **必须分析** | 3–5 条 bullet：本周 top complaints / spikes / no-DRI 待指派项 / WoW 趋势。不要只丢 link。如果有 `## 🎯 OCV — 本周 vs 上周对比` 辅助表，也要在 ③ 段里再用 bullet 概括一次（renderer 只看 ③ 段）。 |
| **④ Release** | ✅ **简单分析** | 2–4 条 bullet：Consumer 本周状态 + 哪些 bug 阻塞 + Lab 哪些 feature 落后 / 过期 ETA。明确指出 meeting ask。 |
| **⑤ Deep Worker** | ✅ **分析 + 原文摘录** | 先写 3–5 条 AI 总结 bullet（工程进展 / quality eval 结果 / 模型升级 / 风险点），再可选放一两段从 `6-deep-worker.md` 抓出的关键原文 / 表格。**不要全文复制 Loop 内容**，那部分 view.html 会自己渲染。 |
| **⑥ GDPVal** | ✅ **分析 + 原文摘录** | 先写 2–4 条 AI 总结 bullet（行业 skill 进度 / Cowork & Task 对比 / Excel Agent 状态），再可选放对比表 / 关键数字。**Excel Agent 归 GDPVal，不是 Others**。 |
| **⑦ Others** | ❌ 不分析 | 直接列前 6 个 section 没覆盖的横向事项（MSA Security / Commercial compliance / MCP Hubs 等），一行一条。不要写"本节用于..."这类元说明。 |

#### 6.1.3 Hard rules

1. **从不写元说明**：禁止 "本节聚焦..." / "建议会上确认..." / "这块应该看 X" 这种没有具体内容的占位句。要么写真分析，要么留空（renderer 会落到原始 markdown）。
2. **从不只写 link**：所有"详见 xx.md"句式必须先有 ≥2 条具体 bullet。
3. **数字 / owner / ETA / @handle / Bug ID 一律保留**，不能改事实，也不能为了简洁删掉关键标识。
4. **每个必填 section 至少 1 条 bullet**。彻底没素材时，写一条 "_本周无新进展（last update: <date>）_" bullet，不要让 section 留空到看不出有没有写过。
5. **永远整体重写**，不要在上周 summary 上 diff。

Write to a temp file, then upload:

```bash
python framework/scripts/cloud_cli.py upload-md /tmp/prep-summary.md current/updates/0-meeting-prep-summary.md
```

### 6.2 view.html

view.html 是会议现场用的 status page。**格式已经硬编码**在 `framework/scripts/render_view.py`，agent 不允许自己重新设计或手写 HTML。生成时必须运行：

```bash
python framework/scripts/cloud_cli.py render-view --local ./view.html
```

这个命令会从 SharePoint 读取 `current/updates/1..7` 和 `0-meeting-prep-summary.md`，用固定模板生成旧版蓝色 section / sticky nav 页面，上传到 `current/view.html`，并下载/写出本地预览 `./view.html`。

`render_view.py` 是唯一的 HTML/CSS source of truth。如果需要改版，只能改脚本，不能让 agent 临场发挥或在规则文档里再复制一份骨架。

view.html **必须使用旧版蓝色 section / sticky nav 的 UI**，顶部放 Top Risk，然后按固定顺序展示 7 个 section。内容要“详略得当”：不是原文全量 dump，也不是过短 brief；每个 section 第一段必须是业务总结，不能写“我保留了什么 / 我不展示什么 / 本节用于...”这类生成规则说明。不要生成 compact card dashboard、灰底白卡片堆叠、圆角 callout 卡、emoji section header、或一屏摘要版。

**页面结构（从上到下）：**

1. 标题 + 顶部元信息：会议日期、Loop/Data/OCV 的来源时间戳。
2. **Top Risk**：3–5 条本周最高优先级风险/进展，使用业务语言直接总结，不要写括号说明、不要写“后续专门讨论”、不要写“建议优先讨论”。
3. **7 个 section**，按下面固定顺序。每个 section 先写业务总结，再放必要表格/细节。

**Section 顺序固定，不能省略 Others：**

| 顺序 | 标题 | 来源文件 |
|---|---|---|
| ① | **To Do / Action Items** | `1-todo.md` |
| ② | **Data** | `2-data.md` |
| ③ | **OCV** | `3-ocv.md` |
| ④ | **Release**（正式 + Lab 环境） | `4-release.md` |
| ⑤ | **Deep Worker** | `6-deep-worker.md` |
| ⑥ | **GDPVal** | `5-gdpval.md` |
| ⑦ | **Others** | `7-others.md` |

Deep Worker (⑤) 在 GDPVal (⑥) 之前，跟文件编号反着 —— 这是会议讨论顺序约定。

**各 section 内容规则：**

1. **To Do**：必须展示当前 Action Items 表，包含 item、owner、ETA/progress、meeting ask/notes；不要把历史 completed 长列表全量展开。人工 `/sr-update`（如 `@handle` 的进展）要合并进 To Do 表或总结。
2. **Data**：保留 Claire 报告第一页 **Executive Overview 四组指标**（User Base / Engagement / Retention / Quality & Perf）+ Key Takeaways。**不要**再追加 Selected Report Tables / slide 1,2,3... 的长表 dump。
3. **OCV**：一段 OCV 业务总结 + 一张可扫描问题表。表里放 Items、Trend、Title、Type/State、Bug ID。不要重复贴两张 OCV 表。
4. **Release**：只保留 **Consumer Release Status** 和 **Lab Release Plan (Rick Yang)**；必要时用表格列出 0430 bugs 和 Lab pending release 关键项。
5. **Deep Worker**：一页左右，保留概括总结 + 工程链路、quality/eval、模型升级、人工 update 的关键细节。
6. **GDPVal**：一页左右，保留概括总结 + Excel/GDPVal eval 表。**Excel Agent 属于 GDPVal**，不要放到 Others。
7. **Others**：必须列出前 6 个 section 没覆盖的项目（例如 MSA Security Review、Commercial compliance、MCP Hubs）。Others 是兜底，不要省略。

**通用规则：**

- 每个 section 的第一段都必须是“Societas/Data/OCV/Release/Deep Worker/GDPVal/Others 的业务总结”，不要写 agent 的生成策略。
- 保留关键数字、owner、ETA、bug ID、@handle；可以适度归纳/合并原文，但不能改事实。
- 可以使用 `<h3>`/表格帮助阅读，但不要用明显蓝色色块/分隔条在 section 内切碎内容。
- 空 section 显示标题 + "_本周无更新_"，不要省略。
- 不要把 `0-meeting-prep-summary.md` 整段塞进 view.html；Top Risk 是为 dashboard 重新写的浓缩版。
- 不要显示 `<!-- BEGIN/END LOOP-SYNC -->` 注释行。

这是 `/sr-prep` 的默认产出，**不要问 host，也不要手写 HTML**。最后反馈（SharePoint 链接是主体，本地路径只是备注）：

> ✅ [view.html](<SharePoint URL for current/view.html>) 已生成。
> （也下载了一份到本地 `./view.html`，在 IDE 里双击能预览。）

SharePoint URL 从 `cloud_cli.py render-view` stdout 拿，拿不到就调 `cloud_cli.py url current/view.html`。

---

## Failure handling (applies to every step)

- Each step is independent — a failure in Step 3 does not block Steps 4–6.
- Surface CLI errors **verbatim** (stderr text, exit code).
- Never pretend success. Never silently retry destructive operations.
- If the same retry has failed twice with the same error, stop and ask the host.

## Universal feedback contract

Every successful upload (Steps 2, 3, 4, 6) must be acknowledged in chat with:
- the file path under `current/`
- the SharePoint URL from stdout

Example:
> ✅ 已写入 [current/updates/3-ocv.md](<SharePoint URL>)（auto-merged into LOOP-SYNC block, human entries preserved）
