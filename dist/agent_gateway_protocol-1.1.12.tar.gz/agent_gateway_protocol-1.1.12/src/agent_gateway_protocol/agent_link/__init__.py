"""Agent Link shared protocol models."""
