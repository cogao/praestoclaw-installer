from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class AgentLinkModel(BaseModel):
    """Base model for Agent Link v1 wire contracts."""

    model_config = ConfigDict(extra="forbid")
