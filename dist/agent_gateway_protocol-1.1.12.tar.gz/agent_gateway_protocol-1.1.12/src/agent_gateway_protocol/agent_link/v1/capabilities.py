from __future__ import annotations

from typing import Any

from pydantic import Field

from agent_gateway_protocol.agent_link.v1._base import AgentLinkModel


class ChannelCapabilities(AgentLinkModel):
    streaming: bool = False
    markdown: bool = True
    cards: bool = False
    attachments: bool = False
    max_message_chars: int | None = Field(default=None, gt=0)
    features: dict[str, Any] = Field(default_factory=dict)


class DeliveryContext(AgentLinkModel):
    target: str | None = None
    thread_id: str | None = None
    reply_to_id: str | None = None
    route: dict[str, Any] = Field(default_factory=dict)


class PolicyContext(AgentLinkModel):
    trust_domain: str | None = None
    policy_profile: str | None = None
    auth_context: dict[str, Any] = Field(default_factory=dict)


class RenderingHints(AgentLinkModel):
    format: str = "markdown"
    card: str | None = None
    collapse_tool_progress: bool = False
    extra: dict[str, Any] = Field(default_factory=dict)


class StreamingState(AgentLinkModel):
    sequence: int | None = Field(default=None, ge=0)
    is_final: bool = True
    stream_id: str | None = None
    extra: dict[str, Any] = Field(default_factory=dict)
