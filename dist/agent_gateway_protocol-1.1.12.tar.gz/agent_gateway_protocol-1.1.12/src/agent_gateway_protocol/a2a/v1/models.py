"""A2A envelope models for async agent-to-agent communication."""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class A2AMessageType(StrEnum):
    """Wire-level A2A message types."""

    TEXT = "text"
    ACK = "ack"
    ERROR = "error"


@dataclass(frozen=True)
class A2AParty:
    """Sender or receiver identity on the A2A wire."""

    id: str
    name: str = ""
    agent_id: str = ""

    def to_dict(self) -> dict[str, Any]:
        result = {"id": self.id, "name": self.name}
        if self.agent_id:
            result["agent_id"] = self.agent_id
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> A2AParty:
        return cls(
            id=str(data.get("id", "")),
            name=str(data.get("name", "")),
            agent_id=str(data.get("agent_id", "")),
        )


@dataclass
class A2AEnvelope:
    """Single async A2A message envelope."""

    id: str
    type: A2AMessageType
    sender: A2AParty
    receiver: A2AParty
    timestamp: int
    parent_id: str | None = None
    payload: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def new_text(
        cls,
        sender: A2AParty,
        receiver: A2AParty,
        content: str,
        parent_id: str | None = None,
    ) -> A2AEnvelope:
        return cls(
            id=str(uuid.uuid4()),
            type=A2AMessageType.TEXT,
            sender=sender,
            receiver=receiver,
            timestamp=int(time.time()),
            parent_id=parent_id,
            payload={"content": content},
        )

    @classmethod
    def new_ack(
        cls,
        sender: A2AParty,
        receiver: A2AParty,
        parent_id: str,
    ) -> A2AEnvelope:
        return cls(
            id=str(uuid.uuid4()),
            type=A2AMessageType.ACK,
            sender=sender,
            receiver=receiver,
            timestamp=int(time.time()),
            parent_id=parent_id,
            payload={"status": "received"},
        )

    @classmethod
    def new_error(
        cls,
        sender: A2AParty,
        receiver: A2AParty,
        code: str,
        reason: str,
        detail: str = "",
        parent_id: str | None = None,
    ) -> A2AEnvelope:
        return cls(
            id=str(uuid.uuid4()),
            type=A2AMessageType.ERROR,
            sender=sender,
            receiver=receiver,
            timestamp=int(time.time()),
            parent_id=parent_id,
            payload={"code": code, "reason": reason, "detail": detail},
        )

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "id": self.id,
            "type": self.type.value,
            "sender": self.sender.to_dict(),
            "receiver": self.receiver.to_dict(),
            "payload": dict(self.payload),
            "timestamp": int(self.timestamp),
        }
        if self.parent_id is not None:
            result["parent_id"] = self.parent_id
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> A2AEnvelope:
        return cls(
            id=str(data["id"]),
            type=A2AMessageType(data["type"]),
            sender=A2AParty.from_dict(data.get("sender", {})),
            receiver=A2AParty.from_dict(data.get("receiver", {})),
            timestamp=int(data.get("timestamp", 0)),
            parent_id=data.get("parent_id"),
            payload=dict(data.get("payload", {})),
        )

    @property
    def text(self) -> str:
        """Return text payload content; empty string for non-text envelopes."""

        if self.type is not A2AMessageType.TEXT:
            return ""
        value = self.payload.get("content", "")
        return value if isinstance(value, str) else str(value)
