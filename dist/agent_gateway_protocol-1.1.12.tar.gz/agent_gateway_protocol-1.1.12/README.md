# agent_gateway_protocol

Shared protocol models for Praesto projects.

The package provides shared wire contracts used across Praesto projects:

- `agent_gateway_protocol.agent_link.v1` for Agent Link channel frames.
- `agent_gateway_protocol.gateway_protocol.v1` for Agent-Gateway business envelopes,
  transport frames, task protocol types, and U2U/A2A topic constants.
- `agent_gateway_protocol.gateway_protocol.v2` for the Azure Web PubSub link
  variant, sharing the v1 envelope and messaging contracts.
- `agent_gateway_protocol.a2a.v1` for async agent-to-agent envelope models.
