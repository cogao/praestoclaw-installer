from __future__ import annotations

import json
from importlib import resources

import pytest
from pydantic import ValidationError

from agent_gateway_protocol.agent_link.v1 import (
    ChannelInboundFrame,
    ChannelOutboundFrame,
    ConversationIdentity,
    LogicalChannel,
    MessageContent,
    SourceIdentity,
    SourceIdentityKind,
    parse_agent_link_frame,
)


def test_channel_inbound_round_trip() -> None:
    frame = ChannelInboundFrame(
        frame_id="frame-123",
        trace_id="trace-123",
        agent_host_id="host-123",
        agent_id="agent-default",
        logical_channel=LogicalChannel.A2A,
        source_identity=SourceIdentity(id="agent-peer", kind=SourceIdentityKind.AGENT),
        conversation_identity=ConversationIdentity(conversation_id="a2a:conversation"),
        message=MessageContent(content="status?"),
    )

    dumped = frame.model_dump(mode="json")
    parsed = parse_agent_link_frame(dumped)

    assert isinstance(parsed, ChannelInboundFrame)
    assert parsed.logical_channel is LogicalChannel.A2A
    assert parsed.proposed_session_key is None


def test_local_tui_channel_round_trip() -> None:
    frame = ChannelInboundFrame(
        frame_id="frame-tui",
        trace_id="trace-tui",
        agent_host_id="host-123",
        agent_id="agent-default",
        logical_channel=LogicalChannel.LOCAL_TUI,
        source_identity=SourceIdentity(id="local", kind=SourceIdentityKind.HUMAN),
        conversation_identity=ConversationIdentity(conversation_id="session-1"),
        message=MessageContent(content="hello"),
    )

    parsed = parse_agent_link_frame(frame.model_dump(mode="json"))

    assert isinstance(parsed, ChannelInboundFrame)
    assert parsed.logical_channel is LogicalChannel.LOCAL_TUI


def test_channel_outbound_round_trip() -> None:
    frame = ChannelOutboundFrame(
        frame_id="out-123",
        trace_id="trace-123",
        in_reply_to_frame_id="frame-123",
        agent_id="agent-default",
        logical_channel=LogicalChannel.TEAMS,
        content="done",
        requires_ack=True,
    )

    parsed = parse_agent_link_frame(frame.model_dump(mode="json"))

    assert isinstance(parsed, ChannelOutboundFrame)
    assert parsed.requires_ack is True
    assert parsed.content == "done"


def test_invalid_logical_channel_rejected() -> None:
    data = {
        "schema_version": "agent-link.v1",
        "frame_type": "channel_inbound",
        "frame_id": "frame-123",
        "trace_id": "trace-123",
        "agent_host_id": "host-123",
        "agent_id": "agent-default",
        "logical_channel": "not-a-channel",
        "source_identity": {"id": "user-123", "kind": "human"},
        "conversation_identity": {"conversation_id": "conversation-123"},
        "message": {"content": "hello"},
    }

    with pytest.raises(ValidationError):
        parse_agent_link_frame(data)


def test_packaged_inbound_fixture_is_valid() -> None:
    fixture = (
        resources.files("agent_gateway_protocol.agent_link.v1.fixtures")
        .joinpath("channel_inbound.json")
        .read_text(encoding="utf-8")
    )
    parsed = parse_agent_link_frame(json.loads(fixture))

    assert isinstance(parsed, ChannelInboundFrame)
    assert parsed.logical_channel is LogicalChannel.TEAMS
    assert parsed.proposed_session_key == "teams:tenant-001:conversation-001:thread-001"
