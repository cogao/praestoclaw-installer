from __future__ import annotations

import pytest

from agent_gateway_protocol.a2a.v1 import A2AEnvelope, A2AMessageType, A2AParty
from agent_gateway_protocol.gateway_protocol.v1 import (
    CONTENT_TYPE_TASK_REQUEST,
    ConversationBody,
    Envelope,
    EnvelopeKind,
    TaskRequest,
    TransportCloseCode,
    TransportHelloFrame,
    TransportWelcomeFrame,
    extract_task_request,
    new_envelope_id,
    parse_transport_frame,
)
from agent_gateway_protocol.gateway_protocol.v1.business import BusinessError, BusinessProtocolError


def test_business_envelope_round_trip_supports_agent_helpers() -> None:
    envelope = Envelope.request(
        "conversation.message.send",
        {"content_type": "text", "text": "hello"},
        headers={"deadline_ms": 1000},
        envelope_id="01HV3ZA1B0F5XK0M8EVR6S6P5C",
    )

    restored = Envelope.parse(envelope.to_dict())

    assert restored == envelope
    assert restored.kind is EnvelopeKind.REQUEST
    assert restored.to_dict()["correlation_id"] is None


def test_business_envelope_supports_gateway_model_dump() -> None:
    envelope = Envelope(
        kind="error",
        id="err-1",
        correlation_id="req-1",
        body=BusinessError("offline", "recipient offline", retryable=True).to_body(),
    )

    dumped = envelope.model_dump(exclude_none=True)

    assert dumped["kind"] == EnvelopeKind.ERROR
    assert "topic" not in dumped
    assert envelope.is_terminal is True


def test_business_envelope_rejects_bad_headers() -> None:
    with pytest.raises(BusinessProtocolError):
        Envelope.parse(
            {
                "kind": "request",
                "id": "req-1",
                "topic": "conversation.message.send",
                "headers": {"bad header": "x"},
                "body": {},
            }
        )


def test_conversation_body_contract_shape() -> None:
    parsed = ConversationBody.parse(
        {
            "context": {"conversation_id": "webchat:tab-1", "task_id": None},
            "sender": {"kind": "human", "id": "principal-1", "display_name": "Alice"},
            "recipient": {
                "kind": "agent",
                "user_id": "alice@example.com",
                "agent_id": "agent-1",
            },
            "content": {"content_type": "text", "text": "hello", "format": "text"},
            "metadata": {},
        }
    )

    assert parsed.content.to_dict()["text"] == "hello"


def test_transport_parse_roles_and_close_code_aliases() -> None:
    gateway_frame = parse_transport_frame(
        '{"type":"t.hello","protocol_version":1,"features":[]}',
        role="gateway",
    )
    agent_frame = parse_transport_frame(
        '{"type":"t.welcome","protocol_version":1,"features":[],"session_id":"s",'
        '"session_token":"t","connection_epoch":1,"resumed":false,'
        '"last_received_seq":0,"ping_interval_ms":25000,"pong_timeout_ms":20000,'
        '"resume_ttl_ms":300000,"max_payload_bytes":1024,"max_outbox_bytes":2048}',
        role="agent",
    )

    assert isinstance(gateway_frame, TransportHelloFrame)
    assert isinstance(agent_frame, TransportWelcomeFrame)
    assert int(TransportCloseCode.PROTOCOL_ERROR) == 4000
    assert int(TransportCloseCode.SEQUENCE_ERROR) == 4001


def test_envelope_id_is_canonical_ulid_shape() -> None:
    envelope_id = new_envelope_id()

    assert len(envelope_id) == 26
    assert envelope_id == envelope_id.upper()
    assert "-" not in envelope_id


def test_task_request_extraction() -> None:
    request = extract_task_request(
        {
            "content": {
                "content_type": CONTENT_TYPE_TASK_REQUEST,
                "task": {
                    "task_id": "task-1",
                    "intent": {"summary": "Do thing", "hint_risk": "read"},
                },
            }
        }
    )

    assert isinstance(request, TaskRequest)
    assert request.intent.summary == "Do thing"


def test_a2a_envelope_round_trip() -> None:
    envelope = A2AEnvelope.new_text(
        A2AParty(id="alice@example.com", name="Alice"),
        A2AParty(id="bob@example.com", name="Bob"),
        "hello",
    )
    restored = A2AEnvelope.from_dict(envelope.to_dict())

    assert restored == envelope
    assert restored.type is A2AMessageType.TEXT
