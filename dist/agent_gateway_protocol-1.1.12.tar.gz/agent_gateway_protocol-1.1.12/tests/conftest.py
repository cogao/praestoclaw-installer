"""Shared pytest fixtures and CLI options for the protocol package."""

from __future__ import annotations

import sys
from pathlib import Path


def pytest_addoption(parser):  # type: ignore[no-untyped-def]
    parser.addoption(
        "--snapshot-update",
        action="store_true",
        default=False,
        help="Rewrite protocol schema snapshot files instead of asserting equality.",
    )


# Make ``scripts/`` importable so tests can reuse the dump helper.
_REPO_ROOT = Path(__file__).resolve().parent.parent
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))
