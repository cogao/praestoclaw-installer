"""
Base channel — abstract interface with allowlist-based access control.

Every channel enforces an allow-list before publishing to the bus.
Empty allow_from = allow all (enterprise deployments should always set this).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from loguru import logger

from praestoclaw.bus.events import InboundMessage
from praestoclaw.bus.queue import MessageBus


class BaseChannel(ABC):
    """Abstract base for all communication channels."""

    def __init__(self, bus: MessageBus, allow_from: list[str] | None = None) -> None:
        self._bus = bus
        self._allow_from = set(allow_from) if allow_from else set()

    @property
    @abstractmethod
    def name(self) -> str:
        """Channel identifier."""

    @abstractmethod
    async def start(self) -> None:
        """Connect and begin receiving messages."""

    @abstractmethod
    async def stop(self) -> None:
        """Disconnect and clean up."""

    @abstractmethod
    async def send(self, channel_id: str, content: str, **kwargs: Any) -> bool | None:
        """Send a message to a specific channel destination.

        Returns ``True`` when the message reached a listener, ``False`` when the
        channel accepted the call but had nobody to hand it to (e.g. the client
        disconnected), and ``None`` when the implementation does not report
        delivery. Callers that must distinguish "shown to the user" from "call
        did not raise" have to treat ``None`` as unknown — see
        ``ChannelManager._dispatch_outbound`` for the established idiom.
        """

    @property
    def is_connected(self) -> bool:
        """True when the channel has at least one active client.

        Subclasses override to reflect their real connection state.
        Default returns True for backward compatibility.
        """
        return True

    def get_push_delivery(self, request_id: str) -> dict[str, bool] | None:
        """Return push delivery results for *request_id*, or ``None``.

        Only CloudChannel returns meaningful data — other channels return
        ``None`` (no push delivery tracking).
        """
        return None

    def wait_push_delivery(self, request_id: str) -> Any:
        """Return an awaitable that resolves when a push_ack arrives for *request_id*.

        Returns ``None`` for channels that don't support push delivery
        tracking.  CloudChannel returns an ``asyncio.Event``.
        """
        return None

    async def send_typing(self, channel_id: str, **kwargs: Any) -> None:  # noqa: B027
        """Send a typing indicator to the channel. No-op by default.

        Subclasses (Teams, Cloud) override to show a typing indicator
        while the agent is processing a request.
        """

    def is_allowed(self, sender_id: str) -> bool:
        """Check if the sender is in the allow list."""
        if not self._allow_from:
            return True  # Empty list = allow all
        return sender_id in self._allow_from

    async def _handle_message(
        self,
        *,
        channel_id: str,
        sender_id: str,
        sender_name: str,
        content: str,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Shared message handler — checks allowlist then publishes to bus."""
        if not self.is_allowed(sender_id):
            logger.warning(f"Message blocked from {sender_id} on {self.name} (not in allow_from)")
            return

        meta = metadata or {}
        conversation_id = str(meta.get("conversation_id") or thread_id or channel_id)
        msg = InboundMessage(
            logical_channel=self.name,
            physical_ingress=str(self.name),
            delivery_route_id=channel_id,
            sender_id=sender_id,
            sender_name=sender_name,
            content=content,
            content_format=meta.get("content_format", "text"),
            conversation_id=conversation_id,
            turn_id=str(meta.get("turn_id") or meta.get("request_id") or channel_id),
            agent_session_key=meta.get("agent_session_key"),
            metadata=meta,
        )
        await self._bus.publish_inbound(msg)
