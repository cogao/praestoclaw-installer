---
name: team-knowledge-curate
description: Assess whether a saved capture warrants a knowledge-base update, create a local proposal when it does, get one group confirmation, and publish it immediately.
metadata:
  activation:
    praesto-tag-exp-only: true
    keywords:
      - 知识库
      - 团队知识库
      - 整理到知识库
      - 更新知识库
      - 更新到kb
      - 写入知识库
      - 沉淀到知识库
      - 配置知识库
      - 知识库配置
      - 知识库仓库
      - knowledge base
      - team kb
      - curate knowledge
      - publish to kb
      - configure knowledge base
      - should update knowledge base
      - need to update knowledge base
      - go into kb
      - belong in kb
    patterns:
      - "(?i)(整理|沉淀|归档|写入|录入|更新|同步|补充|发布).{0,24}(知识库|kb|team knowledge)"
      - "(?i)(知识库|team kb).{0,24}(整理|沉淀|归档|写入|录入|更新|同步|补充)"
      - "(?i)(配置|设置|绑定|指定|换|改).{0,16}(知识库|kb)"
      - "(?i)(知识库|kb).{0,12}(配置|设置|绑定|指定)"
      - "(?i)(知识库|kb).{0,12}(仓库|repo|目录|文件夹|路径)"
      - "(?i)(update|curate|publish|write|add).{0,24}(knowledge base|team kb|\\bkb\\b)"
      - "(?i)(knowledge base|team kb).{0,24}(update|curate|publish|write|add)"
      - "(?i)(configure|set up|bind|point).{0,24}(knowledge base|team kb|\\bkb\\b)"
      - "(?i)(把|将).{0,32}(整理|沉淀).{0,16}(进|到).{0,8}(知识库|kb)"
      - "(?i)(知识库|kb).{0,20}(是否|需不需要|要不要|该不该|应不应该|有无必要|有没有必要|是否值得).{0,12}(更新|整理|沉淀|补充)"
      - "(?i)(是否|需不需要|要不要|该不该|应不应该|有无必要|有没有必要|是否值得).{0,20}(更新|整理|沉淀|补充|写入).{0,12}(知识库|kb)"
      - "(?i)(should|does|do|is).{0,16}(the )?(knowledge base|team kb|\\bkb\\b).{0,16}(need|require|warrant).{0,12}(an? )?(update|change)"
      - "(?i)(should|need|worth).{0,16}(update|updating|add|adding|put|putting).{0,20}(the )?(knowledge base|team kb|\\bkb\\b)"
      - "(?i)(should|does).{0,24}(go|belong).{0,12}(into|in|to).{0,8}(the )?(knowledge base|team kb|\\bkb\\b)"
      - "(?i)(是否|需不需要|要不要|该不该|应不应该).{0,20}(进|放入|放进|写入).{0,8}(知识库|kb)"
  requires:
    tools: [kb_scope, kb_inspect, kb_draft, kb_publish, kb_change_history]
  os: [win32]
---

# Team Knowledge Curation

Second stage of the two-stage flow. Collection normally happened already:
verbatim Teams material is cached and folded into a capture snapshot. Your job
is to turn that evidence into changes **this** knowledge base will accept, get
the group to confirm the staged proposal once, and publish immediately. If no snapshot exists yet, step 1
tells you how to collect one first.

You never invent the destination. Every repository states its own rules and
those rules change; read them each time.

## Hard rules

1. **The repository's rules win.** Read `kb_inspect(action="rules")` for the
   area you intend to touch before drafting anything. Rules cascade: the root
   states general ones, each folder narrows them, and a rule may **delegate**
   to another document ("only use the sources listed in sources.md"). Follow
   the delegation — `rules` returns those documents marked `delegated_from`,
   and a constraint you did not open still binds you.
2. **The live group KB is authoritative; session state is only an expectation.**
   Other people and automations may modify the repository between any two turns.
   A capture, session history, active task, prior proposal or published receipt
   proves what happened earlier; none proves what the KB contains now. Before
   drafting, sync the repository and read the complete current target documents.
   Compare that live content with what the session/history led you to expect:

   - If they differ without semantic conflict, preserve the live content and
     apply the still-needed update normally.
   - If they conflict, do not silently restore the expected old state, discard
     the external edit, defer everything, or merely say the KB looks wrong.
     Generate the proposal in the same turn against the live KB. Preserve all
     non-conflicting external edits, and call out each conflict in the proposal
     overview/details: the file path, what the live KB says, what the session or
     prior receipt led you to expect, and how this draft proposes to resolve it.
   - The normal proposal confirmation covers both the ordinary changes and the
     called-out conflict resolutions. Ask a separate blocker question only when
     repository rules make even a reviewable resolution unsafe to propose.

3. **A rule conflict is reported, never drafted around.** If the material breaks a
   stated rule — the wrong source, verbatim content where the repository asks
   for summaries, the wrong location — record it with
   `kb_draft(action="blockers")`. Staging refuses while a blocker is open. The
   group decides: change the draft, or knowingly override. An override is
   written into the commit message.
4. **One confirmation, in the group, in plain language.** Ask whether the staged
   local proposal is correct as an ordinary chat message, **end your turn**, and
   read the reply when it arrives on the next one. Any group member may answer.
   Record it with `kb_draft(action="approve", stage="draft", ...)`, quoting their
   words. If approved, call `kb_publish` immediately in that same reply turn.
   Never ask a second "confirm publishing" question. Do not send an Adaptive Card,
   use a plan checkpoint as approval, or ask anyone to approve a remote
   review branch.
5. **Only a clear yes is an approval.** You are reading intent out of chat, so
   read it conservatively. "可以 / 就这样 / 发吧 / ok, go ahead" is approval;
   "改一下 / 再看看 / 等等" is `changes_requested`; "不行 / 算了" is `rejected`.
   Silence, a question, a partial answer or an emoji is **none of them** — ask
   again rather than deciding for them. An answer about something else entirely
   is not an answer to this. The `quote` must be a message a **person** sent:
   tool output describing a decision is not a person agreeing to one, and is
   refused.
6. **Never publish what the group has not confirmed.** The proposal approval
   binds to the current local proposal fingerprint. Updating or amending the
   proposal commit voids it: summarize the new commit and ask again.
7. **The local proposal remains authoritative.** `stage` creates or updates the
   local proposal branch and commit. For GitHub repositories it may also
   best-effort push that branch and create or refresh a Draft PR so people can
   inspect the actual diff. When `stage` returns `review_url`, include that link
   with the normal spoken summary. The confirmation still happens in this Teams
   chat — never ask anyone to approve or merge the PR. If the optional review is
   unavailable, say nothing about it and continue with the local proposal.
8. **Provenance survives.** Every drafted statement traces back to a capture
   record and, where one exists, the original Teams deep link. A claim you
   cannot source does not enter the knowledge base.
9. **Say what you left out.** Gaps in the capture (`source_gap`) and units the
   group dropped are reported, not quietly discarded.
10. **A new request replaces an unfinished proposal completely.** Keep only one task active
   in a conversation. If the current human message answers the pending proposal
   confirmation or asks for changes to that draft, resume it normally.
   But if the message starts a new knowledge-base update or update-assessment
   request while another task is open, do not ask whether to resume or cancel.
   Tell the group that an unfinished proposal exists, that you are cancelling it,
   and that you are starting a completely new KB publish process. This is a notice,
   not a confirmation gate: do not end your turn after the notice. Use
   `kb_draft(action="restart", ...)`, not a prose promise and not a bare `cancel`:
   `restart` verifies that the old local Git proposal branch is actually deleted,
   marks the old task cancelled and opens the fresh task. If ordinary branch
   deletion fails, it hard-resets the PraestoClaw-managed KB checkout; if needed,
   it rebuilds that local clone from the configured remote. Restart also closes
   any optional Draft PR and deletes its proposal branch from origin; no other
   remote branch is changed. Only if all local cleanup modes fail may you stop
   and report failure. Never carry units, approvals, fingerprints or proposal
   content from the superseded task into the new one; re-extract any still-valid
   knowledge from the fresh capture.
11. **Do not touch the evidence.** The capture snapshot is append-only input.
12. **Your own messages are not evidence.** The capture contains this chat's
    whole history, and a large part of it is you — `PraestoClaw` in production,
    `PraestoClawStaging` in staging, named in the turn's `Your identity` line.
    The knowledge base records what the *team* worked out, never what you
    previously told them. A statement whose only source is a message you sent
    is unsourced by rule 8: drop it, or find the human message it actually came
    from. Where the group confirmed something you proposed, the evidence is
    *their* confirmation, not your proposal.
13. **The group chooses its knowledge base; you never do.** Which repository
    and folder this conversation writes to comes from `kb_scope`, set from what
    the group actually said — asked now, or said earlier in this chat. Saving it
    announces itself to the group so a wrong reading gets corrected. A
    repository outside the allowed list cannot be reached by asking again — it
    takes a config change by the person the refusal names.
14. **An update-assessment question authorizes a draft.** "知识库需不需要更新？",
    "Should this go into the KB?", and equivalent questions ask you to make the
    assessment and act on it. If the captured evidence warrants a change,
    continue all the way through `kb_draft(action="stage")` and present the first
    confirmation summary. Do not stop after describing a hypothetical change,
    and do not ask the group to explicitly say "update the knowledge base" or
    whether you should generate the proposal. The question does **not** authorize
    publishing: the single staged-proposal confirmation still applies. If no defensible change is
    warranted, say so with the short reason and do not manufacture a proposal. But
    once you conclude that content should be written, ending with "尚未创建或发布 KB
    草案" (or any recommendation-only equivalent) is a workflow violation: create
    and stage the proposal in that same turn.

## Workflow

### 1. Resume, replace, or start

`kb_draft(action="show")` first. If a task is already open, compare its
`user_request` and status with the current human message:

- **They are replying to that task** — for example approving it, rejecting it,
  or requesting edits to its presented draft. Continue from its status.
- **It is already `awaiting_publish` / `ready_to_publish`** — the proposal was
  approved on an earlier turn. Call `kb_publish()` immediately. Never ask for
  publish confirmation, even after an agent restart or background-task handoff.
- **They are making a new update or update-assessment request** — tell the group
  in one short sentence that an unfinished proposal exists, you are cancelling
  it, and you are immediately starting a completely new KB publish process. Do
  not phrase this as a question and do not wait for confirmation.

  If the new request asks you to scan/check the current group, first refresh the
  conversation and save a fresh capture by following `team-knowledge-capture`.
  Returning a list of suggested changes is forbidden: collection is input to the
  replacement publish process, not its result. Then, in the same turn, run:

  ```
  kb_draft(action="restart",
           user_request="<the new request, verbatim>",
           capture="<the fresh capture filename>")
  ```

  `restart` is the evidence that cancellation happened: its
  `replaced_task.proposal_branch_removed` must be true when the old task had a
  proposal branch. `replaced_task.proposal_cleanup` reports `delete`,
  `hard_reset`, or `reclone`; all three mean the old local proposal is gone. If
  every recovery mode fails and `restart` refuses, stop and report it. If it
  succeeds, a fresh task is already open — do not call `start` again. Continue
  directly through rules, units, selection and `stage` in this turn. The first
  permissible stopping point is the detailed confirmation for the newly staged
  proposal. The old task's approval does not transfer; the fresh proposal still
  needs its one normal confirmation before publishing.

If no task is open, continue normally.

Otherwise check where this group's knowledge goes:

```
kb_scope(action="show")
```

**If it is not configured, configure it before anything else.** Prefer asking
the group, in one message, which repository to use and — optionally — which
folder inside it. When they have already said it earlier in the conversation,
you may take it from there instead of asking again. What you must never do is
choose a repository or folder nobody named.

```
kb_scope(action="set", repo="<what they said>", subfolder="<what they said>")
```

Saving it posts a short message to the group naming what was recorded, so they
can correct it — that is why taking the answer from earlier chat is acceptable.
The reply's `announced_to_group` says whether that message went out; when it is
`false` the announcement is yours to make. Either way do not repeat it back a
second time.

Never substitute a similar-looking name from the list. `show` returns the
repositories that may be chosen — offer them rather than guessing. Two refusals
are possible and they are not the same thing:

- **Not an allowed repository.** Only the person named in the reply can widen
  that list, in the config on the machine running this agent. Relay it, and stop
  — configure again after they confirm it is done.
- **The folder does not exist.** Ask the group again with the folders the reply
  lists. Do not invent a path, and do not quietly drop the folder they asked for
  and bind the whole repository instead.

The subfolder is where this group's knowledge *prefers* to live, not a fence:
read its rules first and draft there by default, but follow the repository's own
conventions when they point elsewhere.

Once a binding exists, start a task only when step 1 did not already call
`restart`:

```
kb_draft(action="start", user_request="<what the group asked, verbatim>")
```

This picks the newest capture and, **before any proposal work begins**, fetches
and synchronizes the local knowledge base with `origin/main`. It then pins that
starting point and returns an inventory of what was captured — counts, time
ranges, transcript sizes and any gaps. That inventory is your menu; the
snapshot itself stays on disk. Do not begin drafting against a stale checkout.

**If `start` reports that no capture snapshot exists**, the material has simply
not been collected yet — the group asked for the destination without the
collection step. Collect it first, in this same turn:

```
tools(name="team-knowledge-capture", action="skill")
```

Follow those instructions to produce a snapshot, then come back here and run
`kb_draft(action="start")` again. Never draft from your memory of the chat: by
rule 8 every statement you publish must trace back to a capture record, and a
recollected message is not one. If that skill comes back unavailable, say so
and stop rather than reconstructing the discussion yourself.

### 2. Learn this repository's rules

```
kb_inspect(action="sync")
kb_inspect(action="rules", path="<the area you think this belongs in>")
kb_inspect(action="tree", path="<that area>")
kb_inspect(action="read", path="<a neighbouring document>")
```

`sync` and the subsequent reads are mandatory even when session history or
`kb_change_history` says a change was published. History establishes provenance,
not current repository state. Read the complete current content of every file
you may update; do not reconstruct its base from a prior proposal or receipt.

Read every returned rule document, including the ones marked `delegated_from`
— those were pulled in because another rule pointed at them, and they carry
constraints the pointing document only alludes to.

Ask specifically:

- **May this material be used at all?** Some repositories restrict which
  sources feed the knowledge base. Being asked in a chat is not the same as
  that chat being an accepted source.
- **May it be stored in this form?** A repository that keeps structured
  summaries and source links does not accept a verbatim chat copy, however
  convenient that would be.
- **Does this folder narrow the rule further?** A folder may accept material
  the repository generally refuses, or the reverse.

Read a real neighbouring document too. Matching the shape of what is already
there does more for acceptance than any general instruction about good writing.

If nothing in the repository fits the material, say so and propose a new area
with reasoning — do not force knowledge into an unsuitable place.

### 3. Record any conflict before drafting

Every rule you find that this material appears to break becomes a blocker:

```
kb_draft(action="blockers", blockers=[
  {"rule_source": "context/sources.md",
   "rule": "<the rule, quoted>",
   "conflict": "<how this material breaks it>"}
])
```

Do this **before** staging. `stage` refuses while a blocker is open, and that
is deliberate: a finished-looking proposal that quietly walked past a rule is
exactly the artefact a group approves by mistake.

Surface each blocker in ordinary chat: quote the rule, name the document and
say plainly what it means. This is clarification required to make a valid
proposal, not the staged-proposal confirmation gate. Record what the group decides:

```
kb_draft(action="resolve_blocker", blocker_id="b1",
         resolution="resolved|overridden", note="<their reasoning>", decided_by="<who>")
```

`resolved` means you changed the plan so the conflict is gone. `overridden`
means the group knowingly proceeded anyway — it requires a reason and is
written into the commit message as a `KB-Rule-Override` trailer, so the
decision survives the chat.

### 4. Extract knowledge units

Read the capture and record what you found:

```
kb_draft(action="units", units=[
  {"type": "decision", "title": "...", "content": "...",
   "evidence": [{"capture_record": 0, "message_id": "...", "url": "https://teams..."}]}
])
```

Types: `fact`, `decision`, `action`, `risk`, `question`, `background`, `status`.
Separate what was *decided* from what was merely *discussed*; mark anything
unconfirmed as such in `confidence`.

Skip your own messages while you read (rule 12). Your earlier answers, summaries
and status reports look exactly like well-formed knowledge units, which is the
trap: publishing them launders your own output back in as a team fact, and the
next capture re-reads it as evidence. Attribute by the sender's display name,
not by how authoritative the text sounds. A question you answered contributes
at most the *question* — the answer needs a human source or a group
confirmation before it counts.

### 5. Select the knowledge to include

Use the group request, the repository rules and any blocker resolutions to
select the knowledge units for this proposal:

```
kb_draft(action="select", unit_ids=[...])
```

Do not silently broaden the request. Units you leave out, capture gaps
(`source_gap`) and the reasons for both remain part of the task record.

For an update-assessment question, this is where you answer it from the evidence
and the current repository contents. If one or more sourced units would add or
correct useful knowledge under the repository's rules, select them and continue
through staging in this turn. The staged local proposal is the answer; a prose
description of what a future diff might contain is not. If nothing would
materially improve the knowledge base, explain that briefly and stop without
staging an empty or cosmetic proposal.

When live content differs from session/history expectations, classify the
difference before selection. Units already represented by the live KB are not
selected again. Non-conflicting missing units proceed normally. Conflicting
units remain eligible for this proposal, but their proposed resolution must be
called out under hard rule 2 rather than silently overwriting either side.

### 6. Record any conflict you find later

If drafting surfaces a further conflict, record it with
`kb_draft(action="blockers")` and take it back to the group. Staging and
publishing both refuse while a blocker is open.

### 7. Create the local proposal branch and commit

Stage the **complete new content** of each file — not a patch — together with
the commit message:

```
kb_draft(action="stage",
         message="<conventional-commit subject, in the repo's own style>",
         overview="<macro-level summary of the complete proposal>",
         changes=[
  {"path": "...", "operation": "create|update", "content": "<full document>",
   "summary": "<one sentence retained in publish history>",
   "details": ["<complete semantic detail 1>", "<complete semantic detail 2>"],
   "rationale": "<why here, citing the rule>", "units": ["u1", "u3"]}
])
```

This creates the authoritative local proposal branch and commit. When GitHub
credentials and API permissions are already available, `stage` also mirrors the
same commit to a remote proposal branch and Draft PR. This is optional and
best-effort: absence or failure is not reported to the group. `stage` returns the
proposal fingerprint, a structured confirmation summary and, when available,
`review_url`. The commit message is part of the proposal; changing it is the same
as changing a file, and restaging refreshes the same optional Draft PR.

For every current-KB/session conflict, make the structured confirmation summary
explicitly include: the affected path, the live KB position, the expected prior
position, the proposed resolution, and which external content was preserved.
These conflict callouts accompany the ordinary per-file change details; they do
not replace or delay the rest of the proposal.

### 8. Single confirmation — the local proposal

Turn the structured confirmation summary into an ordinary chat message with:

- a macro-level overview of the proposal;
- every complete file path; and
- a detailed per-file overview of what will be created or changed; and
- the Draft PR link when `review_url` is present, as an optional way to inspect
  the actual diff.

Do not paste the diff into chat or make GitHub review state the approval gate.
Ask whether this draft is correct, then **end your turn**. There is no card or
button; wait for someone to type a reply in the next turn. Record that reply
exactly:

```
kb_draft(action="approve", stage="draft",
         decision="approved|changes_requested|rejected",
         quote="<their exact words>", by="<who answered>")
```

The quote is required, and `approve` refuses on the same turn the question was
asked — the record has to be a real reply, not your own summary of one.

If they request changes, update the complete file content and call
`kb_draft(action="stage", ...)` again. It updates or amends the local proposal
commit and returns a new fingerprint and summary. Present the entire current
summary and ask the draft question again; an approval for an earlier local
commit is invalid. If they reject it, cancel with
`kb_draft(action="cancel")`.

When the recorded decision is `approved`, do **not** summarize the commit again,
ask whether to publish, or end the turn. The approval authorizes the push. Call
`kb_publish()` immediately and follow step 9. A later proposal change invalidates
the approval and returns to step 7/8.

Immediately before publishing, sync once more. If the live head changed after
this proposal was staged, do not silently merge the session-expected document or
push the stale proposal. Rebuild the proposal from the new live content, carry
forward all non-conflicting work, call out and resolve conflicts in that new
draft, then obtain the normal proposal confirmation again. Repository changes
that do not conflict are preserved and otherwise follow the normal flow.

### 9. Publish immediately after proposal approval

```
kb_publish()
```

After the proposal approval, this first closes the optional Draft PR and deletes
its remote proposal branch. It then automatically merges `origin/main`, squash
merges the local proposal branch onto local `main`, creates the final commit and
pushes it. The PR is never merged, and there is no additional confirmation.
The local proposal commit and final squash commit may have different SHAs; the
task history keeps their association. The local proposal branch is cleaned up
after success and retained when needed to diagnose or retry a failure.

Treat the tool's `reply` as factual input, not as a sentence template. Give the
group exactly one brief, natural result sentence in their language:

- On success, say in nontechnical terms that the knowledge base was updated and
  preserve the returned explicit Markdown link so it stays clickable in Teams.
- On failure, say that the knowledge base could not be updated and give the
  returned short reason in plain language without inventing a diagnosis.
- Avoid implementation vocabulary such as push, commit, branch, squash or PR
  unless the group explicitly asks for technical details.

Do not repeat paths, summaries, unit lists, exclusions, blockers or overrides.
The complete technical receipt — proposal/final SHAs, branch, URL, files,
approval quote, attempts and errors — is persisted and queryable later through
`kb_change_history`.

## When this does not apply

- "What does the KB say about X?" — that is a question, not a curation task.
- "Summarise this discussion" — summarising in chat writes nothing.
- Collection only ("收集一下这两周的群消息") — that is the capture skill's job
  and it ends at the saved snapshot. Curation starts only when the group asks
  for the knowledge base itself to change **or asks you to assess whether the
  captured material warrants a change**. In the latter case, a warranted change
  proceeds directly to a local proposal without another opt-in question.
