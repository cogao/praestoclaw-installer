# `/sr-update` —— 更新流程说明

> **这份文档干嘛用的**：跟 [`prep.md`](prep.md)、[`ask.md`](ask.md) 是同级的 "playbook"，专门讲 agent 在用户想往 shiproom 加东西时该怎么对话、怎么追问、怎么落盘。
>
> **谁会读它**：上半部分（中文）是给人看的，让你理解整个流程是怎么跑的；下半部分（英文 rules block）是给 agent 看的，落实成具体的判断规则。

[`AGENT.md` §2.2](../../AGENT.md) 里的高阶描述指向这里。

---

## 一、整体逻辑（中文说明）

整个 dashboard 由团队的 **Loop 自动生成**（Loop 的标题结构 = 议程目录，见 [`prep.md`](prep.md)）。团队成员的 `/sr-update` **不改 Loop**，而是给 Loop 里**某个节点**挂一条"团队补充"，落到 overlay 层：

- **存储**：`current/overlay/<节点slug>.md`（按节点标题 slug，例如 `1-showcase.md`、`3-consumer-release-status.md`）。
- **命令**：`cloud_cli overlay <节点> "<内容>"` —— `<节点>` 可以是节点标题片段或 slug，CLI 自动匹配到最接近的 Loop 节点（匹配不上会列出可选节点）。
- **渲染**：`render-view` 把每个节点的 overlay 渲染在该 section 下方的绿色「团队补充 / Team updates」块里，自动签 `@<handle>`。**Loop 本身永不被改动。**

> 仅有两个**非 Loop** 文档：`2-data.md`（数据部分负责人上传）和 `3-ocv.md`（`/sr-fetch-ocv`），它们被注入到 Loop 的 Business Metrics / Customer Voice 节点。当前负责人以 Loop 为准；更新数据 / OCV 走各自的上传 / 抓取入口，不走 overlay。

overlay 文件长这样：

```
# Overlay — 1. Showcase

### @user · 2026-06-30T10:00
... 团队补充 1 ...

### @wenbiao · 2026-06-30T11:30
... 团队补充 2 ...
```

**核心契约：overlay 和 Loop 完全分离，团队补充永远不会污染 Loop。**

---

## 二、用户更新时的三种情况

### 情况 A.1：用户已给内容，并且明确指定了节点
> 例："在 Showcase 里加：demo 站本周上线"
> 例：`/sr-update consumer-release "Lumina 0430 已通过 RAI"`

agent 信任用户判断，**不再问节点**。直接进入"追问阶梯"判断要不要补字段，然后 `cloud_cli overlay <节点> "..."`。

### 情况 A.2：用户给了内容，但没说放哪
> 例："VFS bug fixed, ETA Wed"

agent 从**当前 Loop 的节点列表**里挑最匹配的，先**回头确认节点对不对**：

> 我会把这条挂到 Loop 的 **`Action Items`** 节点（todo / ETA 类）。需要换别的节点吗？
> _原文：VFS bug fixed, ETA Wed_

用户说 yes / 改到别的 → 继续往下走。

### 情况 B：用户只说"我要 update"，还没给内容
> 例："我想 update 一下" / "/sr-update" / "我想做 shiproom 的更新"

这种时候用户多半是想先看一眼上周 / 本周现有的内容找找感觉。尤其是刚跑完 `/sr-archive` 之后，`current/` 会被清空，这不是“没有上下文”，而是上下文已经搬到最新的 `history/<date>/` 里了。Agent 应该**尽量**把现有的上下文拼进回复里，拿到哪个给哪个：

优先级从高到低（有哪个给哪个，不存在的静默跳过）：

1. **本周 view.html dashboard** — `cloud_cli url current/view.html`（最有用，如果 `/sr-prep` 跑过就会有）
2. **本周 currentloop.md** — `cloud_cli url current/currentloop.md`（本周原始 Loop）
3. **最新 archive view.html** — 先 `cloud_cli list-history` 找最新日期，再 `cloud_cli url history/<date>/view.html`（archive 刚清空 current 后优先给这个）
4. **最新 archive prep summary** — `cloud_cli url history/<date>/updates/0-meeting-prep-summary.md`
5. **最新 archive currentloop.md / currentloop.pdf** — `cloud_cli url history/<date>/currentloop.md`，没有就试 `.pdf`

拿到什么就贴什么，后面接上 section 菜单。例：

> 上次会议 dashboard：&lt;history view.html url&gt;
>
> 想挂到哪个 Loop 节点？（常见：Action Items / Business Metrics / OCV / Consumer Release status / Mythos Security Bugs / Capabilities / Showcase / Foundation / 10x Productivity Research——以本周 Loop 为准）
> 或者直接把这周要加的发我，我帮你归类。

**这些都拿不到（例如首周运行、history 为空）→ 直接上 section 菜单即可，不要卡住。**

重要：历史链接只是帮用户回忆上下文，**不能替代下面的智能判断**。用户一旦给出具体内容，仍然必须回到情况 A：先判断是否 FYI；需要推动时再轻量追问；不要因为 `current/` 刚被 archive 清空就变成裸聊，也不要硬问固定 Owner / ETA。

用户回复内容后，回到情况 A 继续。

---

## 三、追问逻辑（重点）

agent 站在**会议参与者 / 决策者**的角度看每条 update：这条到了会上能讨论吗？

一条 meeting-ready 的 update 至少要回答 **What's the state**（现在怎么了）。如果它需要会上推动，就补 **What does the user want from the room**（想在会上拿到什么）；如果只是同步状态 / 评估反馈 / 观察结果，就标成 `#fyi` 直接写入。

追问要像一个会前 PM 助手，不要像表单。默认先判断这是不是 FYI；如果是，就直接写入 `#fyi`。只有内容明显需要会上推动 / 决策 / unblock，或者缺字段会让行动项无法执行时，才轻量追问。

### 第一层：诉求清晰度检查
agent 看完用户给的内容，判断**有没有明确的"会上想要什么"**。

**已经够清楚或明显 FYI → 跳过这一层，直接写入**：
- 内容已经描述了一个结论性事实（"已解决 / fixed / done / 已上线 / 已通过"等）
- 内容只是同步状态、评估反馈、观察结果、实验结论、下周观察，没有明确要别人做决定
- 内容里已经写出了诉求（"求老板 push" / "需要 X approve" / "想拿到 A vs B 的决议"等）
- 用户标了 `#fyi` / `#asis` / "就这样" / "直接放"
- 是 `2-data` / `3-ocv`（异常 note，flag 出来本身就是诉求，不用追问）

如果判断为 FYI，但用户没写 `#fyi`，agent 可以自动在最终 entry 末尾加 `#fyi`，不要再问 Owner/ETA。

**不确定时才追问一层**，按内容里的信号选问题。追问必须像建议，不像必填项；用户可以忽略，agent 可按原文或 `#fyi` 写入：

| 文本里的信号 | 大概想要什么 | agent 怎么问 |
|---|---|---|
| blocker / 卡住 / 阻塞 | 想被人 unblock | 这个 blocker 想拿到什么？(a) 老板 push X (b) Y approve (c) A&B 团队对齐 (d) 仅同步 |
| investigation / 排查中 / 不确定 | 想要方向或换 owner | 还在调查 — 想要什么？(a) 加人换 owner (b) 批准延期 (c) 仅同步 |
| delay / 延期 / 风险 | approve 新 ETA 或要资源 | 延期/风险 — 想要？(a) approve 新 ETA (b) 加资源 (c) 仅 risk 同步 |
| 提案 / option A vs B | 想要决议 | 想拿到？(a) 选 A/B (b) 谁 review (c) 征求意见 |
| 模糊只描述现象 | 不清楚 | 这条我可以先按 FYI 放进去；如果你想会上推动某件事，也可以补一句 meeting ask。 |

**用户选了 actionable 选项 → agent 把诉求 bake 进 entry 改写一遍**，例：
- 改写前：`Lumina 集成被 cookie iframe 问题卡住`
- 改写后：`Lumina 集成 blocker：cookie iframe 问题 — 求老板 push Edge 团队优先 review PR #5123312`

**用户选 (d) 同步 → 自动加 `#fyi` tag，跳过第二层**。

### 第二层：字段完整性（可选，不是表单）
只有当 entry 会变成行动项、release blocker、明确需要 owner 跟进的风险时，才检查 owner / ETA / branch。不要对普通 FYI、评估反馈、观察结果硬问 Owner & ETA。

如果需要追问，**最多问 1 条综合问题**，并明确用户可跳过：

| Section | 问 1 | 问 2 |
|---|---|---|
| `1-todo` | 如果这是 action item，owner / ETA 是谁？不知道也可以先跳过。 | — |
| `4-release` | 如果和 release gate 有关，branch/release 和当前 status 是什么？不确定可跳过。 | — |
| `5-mythos` | 安全 bug 同步还是需要会上推动？要推动可补 owner / SLA 状态。 | — |
| `6-skill-quality` / `7-excel` / `8-showcase` / `9-productivity` | 这是 FYI 同步，还是需要某人后续跟进？如果要跟进，可补 owner / next milestone；否则我按 FYI 写。 | — |
| `2-data` / `3-ocv` | 跳过 | 跳过 |

**如果文本里已经有这些字段（regex 命中 `Owner:` / `@name` / `ETA` / `due` / `status` / `branch`）→ 这一层也跳过。**

**两层加起来最多一个必要 round-trip**。如果 agent 已经能合理判断为 FYI，就不要问；如果问了而用户没答字段，也可以按 `#fyi` 或原文写入。

### 完整对话示例
```
用户：release 那边 Native tool call 还在 testing
agent：放到 4-release 对吗？另外 — testing 中你想在会上拿到什么？
       (a) 同步进度 (b) 申请 ETA 延期 (c) 拿到 QA 的 sign-off (d) 其他
用户：b，想 push 到 5/19
agent：收到。改写成 "Native tool call 还在 testing — 申请 ETA 延期到 5/19，求老板 approve"。
agent：✅ 已写入 [current/overlay/consumer-release-status.md](<SharePoint URL>) （节点：Consumer Release status）...
```
FYI 示例：
```
用户：skill quality: 人工评估反馈 PPT 视觉好看但偏 dark mode，缺少呼吸感，下一轮调视觉风格
agent：✅ 已写入 [current/overlay/capabilities.md](<SharePoint URL>)（signed @user，节点：Capabilities）
内容：人工评估反馈视觉好看但偏 dark mode，缺少呼吸感；下一轮调视觉风格。 #fyi
```
---

## 四、写入后的反馈契约

每次成功写入，**必须**给一条结构化反馈，包含：节点名、最终文本。文件路径本身**就是** SharePoint 超链接，不要另起一行 "🔗 <url>" 或 "on SharePoint"：

```
✅ 已写入 [current/overlay/<节点slug>.md](<SharePoint URL>)（signed @<user>，节点：<node>）
内容：<final text>
```

Markdown 超链接语法让路径本身变成点击就能跳到 SharePoint，用户看到的就是一个可点的 `current/overlay/1-showcase.md`。

如果 Q&A 改写过原文，要把**最终落盘的那行**给用户看，用户能核对。

SharePoint URL 从 `cloud_cli.py overlay` 的输出拿（它会返回完整 webUrl），拿不到就调 `cloud_cli.py url current/overlay/<节点slug>.md`。

---

## 五、其他规则

- **5 分钟去重**：写入前读一下文件最后 3 条人工 entry，如果同样内容（忽略大小写和空白）5 分钟内刚加过，先警告再追加。
- **失败要说**：`cloud_cli.py update` 退出非 0 时，把 stderr 原文显示给用户 + 提议一次重试；不能假装写成功了。
- **`2-data` / `3-ocv` 的人工 entry 不会被覆盖**：用户问"我加的会不会被刷掉"时回答 "不会，自动来源只更新文件顶部的 LOOP-SYNC 块，你的条目永远在下面"。

---

## Agent rules — machine-readable summary (English)

> This block restates the above as a tight checklist. Agents in any IDE can use it as the source of truth at runtime; the Chinese narrative above is for human comprehension only. If the two ever conflict, this block wins.

### Trigger detection
Enter this flow when user input matches any of:
- CLI form: `/sr-update [<section>] [<text>]`
- Natural language with update intent: `update / 更新 / 加一条 / 记一下 / append / 补一下 / 加进 ...`

### Decision tree
```
user message
   │
   ├─ no content  ──────────────────────► CASE B: surface last week's history/<latest>/currentloop.pdf URL + optionally last week's section content
   │
   ├─ explicit section + content ───────► CASE A.1: skip classify + skip section confirm → Q ladder → write → confirm
   │
   └─ implicit section + content ───────► CASE A.2: classify → confirm section → Q ladder → write → confirm
```

### Node matching (Case A.2 classifier)
Match the user's text to the closest **Loop node** (node titles come from this week's Loop——list them with `cloud_cli.py read current/currentloop.md` if unsure). Common nodes & hints:
- `Action Items`             ← todo / action item / blocker / owner-task / 行动项
- `Consumer Release status`  ← release / ship / GA / lab / candidate / branch / 发布 / 上线
- `Mythos Security Bugs`     ← Mythos / security bug / critical / SLA / 安全
- `Capabilities` (+ a/b/c…) ← PPT skill / artifact quality / eval / 减 AI 味 / Excel / GDPval / Taste+
- `Showcase`                 ← showcase site / 对外 demo
- `Foundation`               ← Eval Infra / Langfuse / operating loop
- `10x Productivity Research` ← 10x productivity / productivity research
- `Business Metrics` (Data) / `OCV` —— **非 Loop 文档**，走数据部分负责人上传 / `/sr-fetch-ocv`，**不走 overlay**

### Explicit-section signals (Case A.1)
Treat as explicit if user said any of (case-insensitive, EN/中):
- file name: `1-todo`, `4-release`, `6-skill-quality`, `9-productivity`, ...
- keyword: `todo / 待办 / 行动项`, `data / 数据 / 指标`, `ocv / 反馈 / 客户`, `release / 发布 / 上线`, `mythos / security / 安全`, `skill quality / ppt skill`, `excel`, `showcase / eval infra / langfuse`, `10x / productivity`

### Layer 1 — decision-readiness / FYI detection
Skip if ANY of:
- text contains a resolved/past-tense outcome: `已解决 / fixed / done / completed / resolved / shipped / signed off / 上线 / 已完成 / 已修复 / 已通过`
- text is status/feedback/observation/evaluation only and has no decision or unblock ask; append `#fyi` if helpful
- text contains an explicit ask: `求 push / 需要 ... approve / 想拿到决议 / 求 align / 需要决定`
- user flagged: `#fyi / #asis / 就这样 / 直接放 / 原文不变`
- section ∈ {`2-data`, `3-ocv`}

Otherwise ask at most ONE optional multiple-choice + freeform question, picking the template by signal in text (blocker / investigation / delay / proposal / vague). Phrase it as optional: user can answer, say skip, or ignore. If user picks an actionable option, **rewrite the entry to bake in the ask** and show the rewrite to the user. If user picks "just FYI" or provides no action fields, append `#fyi` and skip Layer 2.

### Layer 2 — field completeness (optional)
Skip if ANY of:
- Layer 1 resolved to `#fyi`
- text is FYI / feedback / observation / evaluation result
- text already contains the field (regex: `Owner:`, `@<name>`, `ETA`, `due`, `status`, `branch`)
- section ∈ {`2-data`, `3-ocv`}
- user flagged `#asis`

Ask AT MOST 1 combined optional question, only when the entry is actionable:

| Section | Q1 | Q2 |
|---|---|---|
| `1-todo` | If this is an action item, owner / ETA? Skip is OK. | — |
| `4-release` | If release-gating, branch/release + status? Skip is OK. | — |
| `5-mythos` | Security sync or follow-up? If follow-up, owner / SLA state? Skip is OK. | — |
| `6-skill-quality` / `7-excel` / `8-showcase` / `9-productivity` | FYI or follow-up? If follow-up, owner / next milestone? Skip is OK. | — |
| `2-data` / `3-ocv` | (skip) | (skip) |

Accept `skip / 不知道 / —` as valid.

### Write
```bash
python framework/scripts/cloud_cli.py overlay <node> "<final text>"
```
`<node>` is a Loop node title fragment or slug (e.g. `showcase`, `consumer-release-status`). The CLI resolves it to the matching Loop node, auto-signs with `@<upn-handle>` + ISO timestamp, and appends to `current/overlay/<node-slug>.md` (it never touches the Loop).

### Confirmation (mandatory)
After every successful write, emit (路径本身就是 SharePoint 超链接，不要再单独起一行 "🔗 url" 或 "on SharePoint")：
```
✅ 已写入 [current/overlay/<node-slug>.md](<SharePoint URL>)（signed @<user>，节点：<node>）
内容：<final text>
```
The text shown MUST be the final post-Q&A version, not the original. SharePoint URL 从 `cloud_cli.py overlay` 的 stdout 拿（它会返回完整 webUrl），拿不到就调 `cloud_cli.py url current/overlay/<node-slug>.md`。

### Idempotency
Before write: `cloud_cli.py read current/overlay/<node-slug>.md`, inspect last 3 entries. If a normalized match (case-insensitive, whitespace-collapsed) was appended within 5 minutes, prompt:
> 这条 5 分钟前刚加过 (`<ts>`)。再加一遍吗？(yes / 算了)

### Failure
If `cloud_cli.py update` exits non-zero: print stderr verbatim, do NOT claim success, offer one retry; if still failing, ask user to re-paste or fall back to manual `cloud_cli.py upload-md`.
