# `/sr-prep` — Pre-meeting Orchestration Playbook

**Audience:** AI agents (Copilot, Cloud Code, PM Studio, etc.). Humans don't run these steps.

**Trigger phrases:** "我要开始准备会议" / "帮我准备一下" / "/sr-prep" / "prep the meeting" / "shiproom prep" → enter this flow.

This file is the single source of truth for the prep flow. The high-level mention in [`AGENT.md` §2.8](../../AGENT.md) points here.

> ## ⚠️ CURRENT ARCHITECTURE — Loop-as-tree (overrides the legacy section/JSON details below)
>
> The dashboard is rendered **directly from the Loop's heading outline**, with zero hard-coded section keywords:
> - `fetch-loop` injects `[SR_H:<px>]` heading-level markers + embeds Loop images; it does **not** split content into `1-todo`…`9-*` section files.
> - `render-view` reads `current/currentloop.md`, rebuilds the outline tree (`loop_tree.py`), and renders it (`render_view_tree`) — keeping the rich **Todo / Data / Release** tables, injecting **Data (`2-data.md`) + OCV (`3-ocv.md`)** at their Loop nodes, and rendering each node's `current/overlay/<slug>.md` as a green "团队补充" block. The page starts directly from the Loop outline, normally `Action Items`.
> - `0-meeting-prep-summary.md` still supplies per-node intro bullets (matched by node title).
> - Everything below about `LOOP-SYNC` section files, the `SR_VIEW_JSON` block, the heading-schema, and the keyword `section_map` is the **legacy fallback** (used only when `currentloop.md` has no `[SR_H:]` markers). On the current Loop you do **not** need to hand-craft section files or a JSON contract — just `fetch-loop` → ensure Data/OCV are fresh → `render-view`.

---

## 0. Announce + plan (do this first, before any tool call)

The host should know what's about to happen. Send one short message:

> 我开始准备本周 shiproom，会按下面步骤走：
>
> 1. 跑 checklist，看哪些文件需要刷新。
> 2. 抓最新 Loop，并切分到各个 section。
> 3. 检查 Data 快照是否已上传/是否新鲜。
> 4. 重抓 OCV 快照。
> 5. 读取本周所有 sections 的内容。
> 6. 生成 prep summary 和 view.html。
> 7. 给出 SharePoint 链接并确认完成。
>
> 一般 1–2 分钟，需要你介入时我会停下来问。

Then proceed.

---

## 1. Checklist — `cloud_cli.py prep`

```bash
python framework/scripts/cloud_cli.py prep
```

The script tags every expected file:

| Tag | Meaning | Action |
|---|---|---|
| `[OK]`     | Present, fresh | nothing |
| `[MISS]`   | Not in `current/` | fetch / upload |
| `[STALE]`  | `refresh` kind, generally mtime before cycle cutoff or > 48h old. `2-data.md` has an exception: if file content shows a recent data period (or upload is within archive grace), it stays `[OK]`. | re-fetch (Steps 2–4) |
| `[LEFT]`   | `accumulate` kind, mtime before this ISO week's Monday | last meeting wasn't archived — see §1.1 |

### 1.1 If you see `[LEFT]` — STOP and ask the host

Example:
> `1-todo.md`, `4-release.md` 等还是 2026-05-04 的，看起来上周会议没归档。要不要我先 archive 上周（`history/2026-05-04/`），再开始这周的准备？
>
> - `yes` / `好` → 我会跑 `/sr-archive 2026-05-04`（即 `cloud_cli.py archive 2026-05-04`，**默认 carry-forward，不清空 current/**），然后接 Step 2 重抓 LOOP-SYNC 块
> - `no, 上周内容这周还要用` → 上周的 LOOP-SYNC 部分会被新一轮 fetch-loop 覆盖；上周的 manual `/sr-update` 条目（`### @user · ISO`）renderer 会自动按时间戳过滤掉，**不会泄漏到本周 view.html**，所以这条选项其实没必要选
> - `let me check` → 等你回复

**Carry-forward 模式下的安全保证**（从 archive.md 复述）：
1. fetch-loop / fetch-ocv 会覆盖 LOOP-SYNC 块 + 更新 `<!-- Auto-synced at <ISO> -->` 时间戳。
2. render_view 读 `current/.last-archive` 作为 cutoff，过滤掉 `### @user · ISO` 时间戳 < cutoff 的 manual entry，原文件保留。
3. 没刷新的文件 mtime 仍是上个周期 → checklist 报 `[STALE]` → host 看得见。
4. **多会议节奏（周三 + 周五）自动适配**：cutoff = 上次 `/sr-archive` 时间，不需要硬编码会议日。只要 host 会后及时归档，下次 view 自动只含本会议周期内的 update。

**Never silently proceed and reuse last week's content as if it were this week's.**

---

## 2. Loop content (`refresh`) — `fetch-loop` first, PDF fallback

```bash
python framework/scripts/cloud_cli.py fetch-loop
```

### Success path (exit 0)
- Writes `current/currentloop.md` (full Loop innerText via headless Chrome).
- Auto-splits sections into the LOOP-SYNC block of each target file:
  - `Action Items` → `current/updates/1-todo.md`
  - `Pending release` / `Lab Release plan` / `Consumer Release ...` → `4-release.md`
  - `Mythos Security Bugs` → `5-mythos.md`
  - `Skill package & Artifact Quality & Efficiency` → `6-skill-quality.md`
  - `Excel capability` → `7-excel.md`
  - `Internal showcase & Fundamental` → `8-showcase.md`
  - `10x Productivity Research` → `9-productivity.md`
- Human `/sr-update` entries (outside the markers) are preserved.
- 上述 Release 名称只用于 legacy splitter 路由 fallback 输入，不是 HTML 输出契约；展示标题、段落、表格数量、列和顺序必须来自当前 Loop。

Tell the host: ✅ Loop 已抓取并切片，1/4/5/6/7/8/9 自动部分已更新。

### Failure path (exit 3 or 1)
The script printed the Loop URL on stderr. Surface it to the host **verbatim**:

> Auto-fetch failed: `<reason>`. 请打开下面的 Loop 页面，用 `...` → `Print & PDF export` → Save as PDF，然后把 PDF 直接拖进对话里（我来上传）：
>
> `<loop_url>`

When the host attaches the PDF in chat:
1. Save it to a local path (e.g. workspace tmp).
2. Run `python framework/scripts/cloud_cli.py upload-loop <saved-path>`.
3. The script uploads the PDF AND extracts text via pdfminer AND runs the same splitter — so 1/4/5/6/7/8/9 still get refreshed.
4. **Do NOT make the host run any CLI command themselves.**

---

## 3. Data snapshot (`refresh`) — Data-owner upload

`current/updates/2-data.md` is uploaded by the Data owner each week. The current owner comes from the Loop; there is no hard-coded person name or auto-fetch script.

- If `prep` showed `[OK]` for `2-data.md` → skip.
- If `[STALE]` or `[MISS]`:
  - Default: read the current Data owner from the Loop, then ping that owner to re-run the usage-analysis report and upload.
  - Fallback: if the host already has the markdown locally:
    ```bash
    python framework/scripts/cloud_cli.py upload-md <local> current/updates/2-data.md
    ```
    This **merges** the new snapshot into the LOOP-SYNC block; any human `/sr-update 2-data` entries below the block survive.

  Note: `/sr-prep` no longer treats `2-data.md` as stale only by `mtime < .last-archive`.
  It now checks the declared data period in markdown first; this avoids false
  stale when the Data owner uploads before archive in the same meeting cycle.

---

## 4. OCV snapshot (`refresh`) — always re-fetch

```bash
python framework/scripts/cloud_cli.py fetch-ocv
```

- Reads the workbook at `ocv_source.remote_path` (default `Shiproom/Societas OCV Issues & Bugs.xlsx`) via Microsoft Graph.
- Picks the latest sheet per `ocv_source.sheet_pick` (default `last`).
- Merges a markdown table summary into `current/updates/3-ocv.md`'s LOOP-SYNC block.
- Microsoft Graph workbook range APIs return cell display values but not hyperlink targets. For Bugs cells beginning with a numeric ADO work-item ID, `fetch-ocv` must rebuild an inline Markdown link using `ocv_source.bug_url_template` (`{id}` placeholder). `Create or Link` has no Bug ID and remains plain text.
- The HTML renderer must keep these Bug links inline in the corresponding `Bug ID / note` cell; never extract them into a separate links block.
- Human `/sr-update 3-ocv` entries below the block are preserved.

If exit is non-zero (config wrong / file missing): print the error verbatim, ask host to fix the config or upload the workbook into `Shiproom/`.

---

## 5. Read this week's accumulated human updates

本周团队成员通过 `/sr-update` 写入的人工内容都在以下几个文件里（连同 LOOP-SYNC 块里刚刚刷新过的 Loop / data / OCV 来源内容）。Agent 必须全部读进上下文，作为 Step 6 生成总结的原材料：

```bash
python framework/scripts/cloud_cli.py read current/updates/1-todo.md
python framework/scripts/cloud_cli.py read current/updates/2-data.md
python framework/scripts/cloud_cli.py read current/updates/3-ocv.md
python framework/scripts/cloud_cli.py read current/updates/4-release.md
python framework/scripts/cloud_cli.py read current/updates/5-mythos.md
python framework/scripts/cloud_cli.py read current/updates/6-skill-quality.md
python framework/scripts/cloud_cli.py read current/updates/7-excel.md
python framework/scripts/cloud_cli.py read current/updates/8-showcase.md
python framework/scripts/cloud_cli.py read current/updates/9-productivity.md
```

---

## 6. Generate prep summary + view.html (one step)

生成两个产出同时上传，不再额外问 host。

### 6.1 Prep summary

`0-meeting-prep-summary.md` 是 view.html 的**唯一分析来源**。`render_view.py` 只搬运不分析，所以**这一步偷懒，会议页面就会缺分析**。每个 section 的分析内容都必须先在这里落地。

#### 6.1.1 Required heading schema (renderer contract)

prep summary **必须**包含下列 heading 字面值，缺一个 renderer 就抓不到对应 section 的 intro（会回退到原始 markdown，没有 AI 分析）。`render_view.py` 按 **标题文字**（不再是圈号编号）匹配这些 heading：

```
# 0 — Meeting Prep Summary (<date>)
## 🚨 Top Risks (...)                      ← 必填
## 0. Todo                                 ← 必填
## Data                                    ← 必填（归 1. Online Product）
## OCV                                     ← 必填（归 1. Online Product）
## Release                                 ← 必填（归 1. Online Product）
## Security Bug                            ← 必填（归 1. Online Product）
## Skill Package & Artifact Quality        ← 必填（归 2. Core Workstream）
## Excel Capability                        ← 必填（归 2. Core Workstream）
## Internal Showcase & Fundamental         ← 必填（归 2. Core Workstream）
## 10x Productivity Research               ← 必填（归 2. Core Workstream）
## ✅ Suggested Discussion Order            ← 可选
```

> 结构镜像 Loop 的 3 个顶层分组：**0. Todo** / **1. Online Product**（Data、OCV、Release、Security Bug）/ **2. Core Workstream**（四个子工作流）。`render_view.py` 把 Data/OCV/Release/Security 呈现为 Online Product 下的子小节，把四个 workstream 呈现为 Core Workstream 下的子小节。

可以另外加 `## 📊 本周 vs 上周 ...` / `## 🎯 OCV — 本周 vs 上周对比` 这类辅助对比表放在 Top Risks 之后、① To Do 之前，不会破坏 schema。

#### 6.1.1.a Structured contract (default, machine-readable)

除了上面的 heading schema，`/sr-prep` **默认必须**在文档开头或结尾额外嵌入一个 JSON block，供 `render_view.py` 优先读取。这样即使自然语言 heading / bullet 形式被不同 agent 改写，HTML 仍然稳定。**不要再把它当作可选增强项。**

格式：

```md
<!-- SR_VIEW_JSON:START -->
{
  "top_risks": [
    "risk 1 ...",
    "risk 2 ..."
  ],
  "sections": {
    "todo": ["...", "..."],
    "data": ["...", "..."],
    "ocv": ["...", "..."],
    "release": ["...", "..."],
    "security": ["...", "..."],
    "skill_quality": ["...", "..."],
    "excel": ["...", "..."],
    "showcase": ["...", "..."],
    "productivity": ["...", "..."]
  }
}
<!-- SR_VIEW_JSON:END -->
```

规则：

1. 这个 block 只是给 renderer 读，**人类正文仍然必须完整保留**。
2. `top_risks` 对应 Top Risk 区域；`sections.*` 对应各 section 的 intro。
3. 每个数组元素就是一条 intro bullet；不要塞 markdown heading/table，只放纯句子。
4. key 必须固定为：`todo` / `data` / `ocv` / `release` / `security` / `skill_quality` / `excel` / `showcase` / `productivity`。
5. 如果 JSON block 缺失，renderer 才会回退到旧的 markdown heading/bullet 解析逻辑。
6. **默认语言 = 简体中文**。人给人看的 summary bullet、以及 JSON block 里的 `top_risks` / `sections.*`，默认都用中文写；产品名、模型名、Bug ID、owner 名称、专有名词保留原文即可。

#### 6.1.1.b Default generation template (copy this skeleton)

`/sr-prep` 生成 `0-meeting-prep-summary.md` 时，默认按下面骨架写。先写 JSON block，再写完整人类正文；两者内容必须一致，JSON 是给 renderer 读的稳定 contract，正文是给人看的完整 summary。

```md
# 0 — Meeting Prep Summary (<date>)

<!-- SR_VIEW_JSON:START -->
{
  "top_risks": [
    "<中文 risk 1>",
    "<中文 risk 2>",
    "<中文 risk 3>"
  ],
  "sections": {
    "todo": ["<中文 bullet>", "<中文 bullet>"],
    "data": ["<中文 bullet>", "<中文 bullet>"],
    "ocv": ["<中文 bullet>", "<中文 bullet>"],
    "release": ["<中文 bullet>", "<中文 bullet>"],
    "security": ["<中文 bullet>", "<中文 bullet>"],
    "skill_quality": ["<中文 bullet>", "<中文 bullet>"],
    "excel": ["<中文 bullet>"],
    "showcase": ["<中文 bullet>"],
    "productivity": ["<中文 bullet>"]
  }
}
<!-- SR_VIEW_JSON:END -->

## 🚨 Top Risks (<date>)

1. <与 top_risks[0] 对齐的中文 risk>
2. <与 top_risks[1] 对齐的中文 risk>
3. <与 top_risks[2] 对齐的中文 risk>

## 0. Todo

- <与 sections.todo 对齐的中文 bullet>
- <与 sections.todo 对齐的中文 bullet>

## Data

- <与 sections.data 对齐的中文 bullet>
- <与 sections.data 对齐的中文 bullet>

## OCV

- <与 sections.ocv 对齐的中文 bullet>
- <与 sections.ocv 对齐的中文 bullet>

## Release

- <与 sections.release 对齐的中文 bullet>
- <与 sections.release 对齐的中文 bullet>

## Security Bug

- <与 sections.security 对齐的中文 bullet>
- <与 sections.security 对齐的中文 bullet>

## Skill Package & Artifact Quality

- <与 sections.skill_quality 对齐的中文 bullet>
- <与 sections.skill_quality 对齐的中文 bullet>

## Excel Capability

- <与 sections.excel 对齐的中文 bullet>

## Internal Showcase & Fundamental

- <与 sections.showcase 对齐的中文 bullet>

## 10x Productivity Research

- <与 sections.productivity 对齐的中文 bullet>

## ✅ Suggested Discussion Order

1. <可选>
2. <可选>
```

要求：

1. **JSON block 不得省略**。未来默认链路是 `sr-prep -> 0-meeting-prep-summary.md(SR_VIEW_JSON) -> render_view.py -> view.html`。
2. **JSON 和正文必须语义对齐**。允许一句话粒度略有差异，但不能 JSON 写一套、正文写另一套。
3. **JSON 必须是合法 JSON**：双引号、逗号、方括号/花括号配对完整。不要写注释、不要写 trailing comma。
4. **优先写 2–5 条 intro bullet**。不要把整个 section 正文复制进 JSON；JSON 只放 intro。
5. **如果某个 section 本周确实无新内容**，也要给 JSON 和正文各写一条明确 bullet，而不是留空。
6. **人名一律使用 Loop 给出的全名**（例如 "Example Owner"），**禁止使用 "EO / XY" 这类 2–4 字母缩写**——不论是在 Top Risks、各 section bullet、meeting ask 还是 `@提及`。Loop chip 给出的缩写只是头像 placeholder，会议页面读者看不懂；如果只知道缩写、查不到全名，要么去 Loop 把鼠标悬停 chip 看 tooltip，要么把这条 owner 留空标 `TBD`，**不要把缩写写进 summary**。这条规则对 `0-meeting-prep-summary.md` 的所有正文段落和 SR_VIEW_JSON 同时生效。

#### 6.1.2 Per-section content rules

每个 section 的写法明确分两类：**要分析的** vs **只搬运的**。Renderer 抓 heading 下面的 bullet 作为 intro paragraph，所以**分析内容必须用 `-` bullet 列出，不要写成大段散文，更不要写"详见 xx.md"或纯 link**。

| Section | 是否需要 AI 分析 | 内容要求 |
|---|---|---|
| **🚨 Top Risks** | ✅ **必须分析** | 3–6 条 numbered list。每条一句话点出 risk + 数据 + owner + meeting ask。**禁止只写 "Review X"** 这类占位话。**这一节是 view.html Top Risk 的唯一来源**。 |
| **0. Todo** | ❌ 不分析 | 只简述仍未完成的 Action Items；`Completed` 项不写入 summary，也不在 view.html 中展示。具体未完成 action item 表交给 view.html 从 `1-todo.md` 渲染，不要复制全表。 |
| **Data** （Online Product）| ⚠️ **只写 meeting ask，不复述事实** | 2–3 条 bullet：**只挑出会上要讨论的点**。**禁止复述具体数字 / 趋势** —— 数据报告的 Executive Overview + Key Takeaways 会被 renderer 直接渲染在下方。本周无需讨论写一条 "_本周数据无需讨论，详见下方 Key Takeaways_"。 |
| **OCV** （Online Product）| ✅ **必须分析** | 3–5 条 bullet：本周 top complaints / spikes / no-DRI 待指派项 / WoW 趋势。不要只丢 link。 |
| **Release** （Online Product）| ✅ **简单分析** | 2–4 条 bullet：Consumer 本周状态 + 哪些 bug 阻塞 + Lab 哪些 feature 落后 / 过期 ETA。明确指出 meeting ask。 |
| **Security Bug** （Online Product）| ✅ **必须分析** | 2–4 条 bullet：Total / Critical 计数、按 owner 的 bug 分布、哪些人 SLA 快超期（Critical 30 天 / High 90 天）、是否需重新分担工作量。保留 Dashboard 链接。 |
| **Skill Package & Artifact Quality** （Core Workstream）| ✅ **分析 + 原文摘录** | 2–4 条 AI 总结 bullet（工程进展 / quality eval / PPT skill / 减 AI 味），必要时附一两段从 `6-skill-quality.md` 抓出的关键原文。 |
| **Excel Capability** （Core Workstream）| ✅ **简单分析** | 1–3 条 bullet：Excel skill 进展 / next steps / 与 Cowork 对比。 |
| **Internal Showcase & Fundamental** （Core Workstream）| ✅ **简单分析** | 1–3 条 bullet：Eval Infra / Langfuse 调研 / internal showcase 安排。 |
| **10x Productivity Research** （Core Workstream）| ✅ **简单分析** | 1–3 条 bullet：立项进展 / owner / next milestone。本周无进展写一条明确 bullet。 |

#### 6.1.3 Hard rules

1. **从不写元说明**：禁止 "本节聚焦..." / "建议会上确认..." / "这块应该看 X" 这种没有具体内容的占位句。要么写真分析，要么留空（renderer 会落到原始 markdown）。
2. **从不只写 link**：所有"详见 xx.md"句式必须先有 ≥2 条具体 bullet。
3. **数字 / owner / ETA / @handle / Bug ID 一律保留**，不能改事实，也不能为了简洁删掉关键标识。
4. **每个必填 section 至少 1 条 bullet**。彻底没素材时，写一条 "_本周无新进展（last update: <date>）_" bullet，不要让 section 留空到看不出有没有写过。
5. **永远整体重写**，不要在上周 summary 上 diff。
6. **默认中文输出**：除非 host 明确要求英文，AI 生成的总结、meeting ask、risk callout 一律优先写中文；只在必要处夹英文专有名词。
7. **`SR_VIEW_JSON` 是 `/sr-prep` 默认产物，不再是手动补丁**。如果最终上传的 summary 没有这个 block，视为 prep 未完成。

Write to a temp file, then upload:

```bash
python framework/scripts/cloud_cli.py upload-md /tmp/prep-summary.md current/updates/0-meeting-prep-summary.md
```

### 6.2 view.html

view.html 是会议现场用的 status page。**格式已经硬编码**在 `framework/scripts/render_view.py`，agent 不允许自己重新设计或手写 HTML。生成时必须运行：

```bash
python framework/scripts/cloud_cli.py render-view --local ./view.html
```

这个命令会从 SharePoint 读取 `current/updates/1..9` 和 `0-meeting-prep-summary.md`，用固定模板生成旧版蓝色 section / sticky nav 页面，上传到 `current/view.html`，并下载/写出本地预览 `./view.html`。

`render_view.py` 是唯一的 HTML/CSS source of truth。如果需要改版，只能改脚本，不能让 agent 临场发挥或在规则文档里再复制一份骨架。

#### 6.2.1 ① To Do 表格的硬性格式规则

`1-todo.md` 是从 Loop innerText dump 解析出来的，**Owner / ETA 必须由 `render_view.py` 归一化后再写进 HTML**。任何新出现的格式都要回到脚本里加分支（见 `render_view.py` 顶部 docstring 的 "HARD FORMATTING RULES"），**不要在 agent 链路上临时打补丁**。

- **Owner 列**：只渲染 Loop 给出的全名（例如 "Example Owner / Another Owner"）。Loop chip 同时吐出 "EO" 缩写和 "Example Owner" 全名时，只要存在全名就丢掉缩写；只有完全没有全名时才退回到缩写，避免空 Owner。多 owner 用 ` / ` 拼接，保持原序去重。全名判定：含空格的英文或包含中文字符。纯 2–4 个大写字母视为缩写。
- **ETA 列**：统一成 `YYYY-MM-DD`，**绝不允许把 Loop 原文（"2026年5月26日周二" / "Tue, May 26, 2026" / "5/26"）原样输出**。支持的输入格式见 `_normalize_eta`：`YYYY-MM-DD`、`YYYY年M月D日(周X)`、`Mon DD, YYYY`、`M月D日`（无年默认今年）、`M/D`（无年默认今年）。如果遇到新格式渲染出来不是 ISO 日期，**修脚本而不是改数据**。
- **Item 列**：Loop 会把长标题拆成多行，progress 之前所有既不像 ETA 也不像人名的行会用 ` — ` 拼回 Item，**不要让它们漏进 Owner / ETA / Notes**。
- **Progress 列**：必须严格匹配 `in progress` / `completed` / `not started`（大小写不敏感）。`completed` 行在 renderer 中统一过滤，不进入 HTML；其他写法解析不出来就整行进 fallback，提示有人在 Loop 里乱填状态。

#### 6.2.2 三条渲染不变量（每次 render-view 都必须成立，**只能在脚本里实现，禁止只改某一版 view.html**）

下面三条是 dashboard 的硬性行为规则。它们**必须**由 `render_view.py`（`render_view_tree` 路径）保证，任何一次 `/sr-prep` 重新生成 view.html 时都自动生效。**绝对不允许**只在当前这版 `view.html` 上手改一下就算完 —— 那样下一次 run 会原样退回错误状态。改行为 = 改脚本 + 更新本节，二者缺一不可。

**规则 1 — 口头/团队更新只在当前会议周期内有效（自动过期）**

- 所有“口头更新”——即团队成员通过 `/sr-update` 写入的内容，包括：
  - Loop 节点的 overlay 层（`current/overlay/<slug>.md`，渲染成绿色「团队补充」块）；
  - 各 `updates/*.md` 里 `<!-- END LOOP-SYNC -->` 之后的 manual 条目——
  都必须由 `_filter_fresh_manual_blocks()` 按时间戳过滤，**只保留当前周期内的**。
- 每条更新的头是 `### @user · <ISO 时间戳>`。cutoff 取**两者中更严格的一个**：`current/.last-archive`（上次归档时间）与 `now - 7 天`。时间戳早于 cutoff 的块**一律丢弃**，源文件保留不动。
- 效果：不管**什么时候** run 这个 HTML，只会显示本会议周期（本周）的口头更新。多会议节奏（例如周三 + 周五）天然适配——周三之前的更新在周三展示，周五之前的在周五展示，过期的自动消失。**上上周的 6/30 那种更新永远不该再出现。**
- 实现位置：`render_view.py` 的 `_filter_fresh_manual_blocks` / `extract_manual_entries` / `_render_overlay_block` + `_ACTIVE_CUTOFF`。cutoff 由 `render-view` CLI 从 `current/.last-archive` 传入。**若发现旧更新仍在页面上，是脚本/cutoff 的问题，回脚本修，不要手删 HTML。**

**规则 2 — 每个 section 标题自动带出负责人（从 Loop 读，不硬编码）**

- dashboard 每个分组 / section 的标题后面**必须**追加该块的负责人：`标题 (Owner)`，多 owner 用 ` & ` 连接。这样 host 一眼就知道该在会上 cue 谁讲这一块。
- 负责人**必须从 Loop 自己的 person-chip 读取**，不允许在脚本或规则里硬编码人名。Loop 在标题下方把每个负责人吐成两行：缩写头像（如 `EO`）+ 全名（如 `Example Owner`）。只有当缩写与全名首字母吻合时才认这一对，保证精确。
- 实现位置：`render_view.py` 的 `extract_node_owners` / `node_owner_label` / `display_section_title`，在 `render_view_tree` 里对每个 group 和 child 节点调用。**若某块没显示 owner，先确认 Loop 里该标题下确实挂了 person-chip；缺 chip 就去 Loop 补，而不是在 HTML 里手写名字。**

**规则 3 — 所有链接只在正文原位展示，禁止独立链接框**

- dashboard **任何位置都禁止**生成 `Loop links:`、`Source links:` 或类似的独立链接汇总框，也不能把正文链接抽出来统一放到 section 顶部或底部。
- 每个链接必须保留在它所属的原句、表格单元格、状态或 comment 中。例如 Release 的版本链接留在版本说明里，Bug 链接留在对应状态/Comments 单元格，OCV Bug ID 留在问题表中。
- `clean_markdown` 必须保留 `[SR_LINK:]` marker，由 `inline_md` / `sr_links_to_markdown` 在原位生成 `<a>`。禁止先 `strip_sr_link_markers` 再用 `extract_source_links` 补一个链接框，这会丢失语义位置并造成重复。
- `render_view.py` 中不得存在 `.loop-links` 样式、`render_loop_links` helper 或任何 `<strong>Loop links:</strong>` 输出。legacy 与 Loop-as-tree 两条路径都适用。

**规则 4 — Release 必须复刻 Loop 当前结构，禁止按标题写死格式**

- Release 下有哪些子标题、段落、表格及其顺序，HTML 就按原顺序展示；标题文字必须来自当前 Loop。不得假设一定叫 `Consumer Release` / `Pending Release`，也不得假设一定有两张表。
- Loop 是一段话就渲染一段话；是一张或多张 Markdown 表就按原列头和行渲染；子标题改成 `Preparatives` 或其他名称时，HTML 必须自动使用新名称和它下面的实际结构。
- legacy 扁平文本仅允许按“连续短列头 + 编号行”的结构信号恢复表格，列名和列数来自输入，不得根据 section 名称选择固定 schema。多个 owner chip 可合并到输入中的 Owner 列。
- 链接和图片保持原位置。普通 prose 不得为了凑表格而重排；无法可靠识别的结构宁可忠实渲染原文，也不能套用旧模板。
- 实现位置：`render_view.py` 的 `render_release` / `render_structured_loop_document` / `render_structured_loop_block` / `_parse_flattened_numbered_table`，以及 tree 路径的通用 `render_tree_generic`。禁止新增基于 Release 子标题名称的 renderer 分支。

view.html **必须使用旧版蓝色 section / sticky nav 的 UI**，顶部放 Top Risk，然后按 3 个顶层分组展示。内容要“详略得当”：不是原文全量 dump，也不是过短 brief；每个子 section 第一段必须是业务总结，不能写“我保留了什么 / 我不展示什么 / 本节用于...”这类生成规则说明。不要生成 compact card dashboard、灰底白卡片堆叠、圆角 callout 卡、emoji section header、或一屏摘要版。

**页面结构（从上到下）：**

1. 标题 + 顶部元信息：会议日期、Loop/Data/OCV 的来源时间戳。
2. **Top Risk**：3–5 条本周最高优先级风险/进展，使用业务语言直接总结。
3. **3 个顶层分组**，按下面固定顺序。每个子 section 先写业务总结，再放必要表格/细节。

**分组 / Section 顺序固定（镜像 Loop）：**

| 分组 | 子 Section | 来源文件 |
|---|---|---|
| **0. Todo** | To Do / Action Items | `1-todo.md` |
| **1. Online Product** | Data | `2-data.md` |
|  | OCV | `3-ocv.md` |
|  | Release（正式 + Lab） | `4-release.md` |
|  | Security Bug | `5-mythos.md` |
| **2. Core Workstream** | Skill Package & Artifact Quality | `6-skill-quality.md` |
|  | Excel Capability | `7-excel.md` |
|  | Internal Showcase & Fundamental | `8-showcase.md` |
|  | 10x Productivity Research | `9-productivity.md` |

**各 section 内容规则：**

1. **To Do**：只展示未完成的 Action Items，包含 item、owner、ETA/progress、meeting ask/notes；所有 `Completed` 项统一隐藏，不进入表格或 Todo summary。人工 `/sr-update`（如 `@handle` 的进展）要合并进 To Do 表或总结。
2. **Data**（Online Product）：保留数据报告第一页 **Executive Overview 四组指标**（User Base / Engagement / Retention / Quality & Perf）+ Key Takeaways。**不要**再追加 Selected Report Tables / slide 1,2,3... 的长表 dump。
3. **OCV**（Online Product）：一段 OCV 业务总结 + 一张可扫描问题表。表里放 Items、Trend、Title、Type/State、Bug ID。不要重复贴两张 OCV 表。
4. **Release**（Online Product）：严格按规则 4 复刻当前 Loop 的标题、段落、表格及顺序，不预设标题名称、表格数量或固定列。负责人从当前 Loop person-chip 读取，不在规则中写死。
5. **Security Bug**（Online Product）：保留概括总结 + 安全 bug dashboard 概况（Total / Critical 计数、按 owner 分布、SLA 超期风险）。
6. **Skill Package & Artifact Quality**（Core Workstream）：一页左右，总结工程链路 / quality eval / PPT skill / 减 AI 味等关键进展。
7. **Excel Capability**（Core Workstream）：Excel skill 进展 / next steps / 与 Cowork 横向对比。
8. **Internal Showcase & Fundamental**（Core Workstream）：Eval Infra / Langfuse 调研 / internal showcase 安排。
9. **10x Productivity Research**（Core Workstream）：立项进展 / owner / next milestone。

**通用规则：**

- 每个子 section 的第一段都必须是“Data/OCV/Release/Security Bug/各 Workstream 的业务总结”，不要写 agent 的生成策略。
- 保留关键数字、owner、ETA、bug ID、@handle；可以适度归纳/合并原文，但不能改事实。
- 可以使用 `<h3>`/表格帮助阅读，但不要用明显蓝色色块/分隔条在 section 内切碎内容。
- 空 section 显示标题 + "_本周无更新_"，不要省略。
- 不要把 `0-meeting-prep-summary.md` 整段塞进 view.html；Top Risk 是为 dashboard 重新写的浓缩版。
- 不要显示 `<!-- BEGIN/END LOOP-SYNC -->` 注释行。

这是 `/sr-prep` 的默认产出，**不要问 host，也不要手写 HTML**。最后反馈（SharePoint 链接是主体，本地路径只是备注）：

> ✅ [view.html](<SharePoint URL for current/view.html>) 已生成。
> （也下载了一份到本地 `./view.html`，在 IDE 里双击能预览。）

SharePoint URL 从 `cloud_cli.py render-view` stdout 拿，拿不到就调 `cloud_cli.py url current/view.html`。

---

## Failure handling (applies to every step)

- Each step is independent — a failure in Step 3 does not block Steps 4–6.
- Surface CLI errors **verbatim** (stderr text, exit code).
- Never pretend success. Never silently retry destructive operations.
- If the same retry has failed twice with the same error, stop and ask the host.

## Universal feedback contract

Every successful upload (Steps 2, 3, 4, 6) must be acknowledged in chat with:
- the file path under `current/`
- the SharePoint URL from stdout

Example:
> ✅ 已写入 [current/updates/3-ocv.md](<SharePoint URL>)（auto-merged into LOOP-SYNC block, human entries preserved）
