"""
Configuration schema — Pydantic v2 models for PraestoClaw.

All sensitive fields use SecretStr so they are never accidentally logged or serialised.
"""

from __future__ import annotations

from enum import Enum, StrEnum
from typing import Any, Literal

from pydantic import BaseModel, Field, SecretStr, model_validator

# ── Enums ────────────────────────────────────────────────────────────────────


class LogLevel(str, Enum):
    TRACE = "TRACE"
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class ChannelType(StrEnum):
    CLI = "cli"
    WEB = "web"
    LOCAL_WEBCHAT = "local_webchat"
    CLOUD = "cloud"

    @classmethod
    def of(cls, value: str | None, default: ChannelType | None = None) -> ChannelType:
        """Convert a string to ChannelType. Returns *default* (or CLI) for None/empty/unknown."""
        if not value:
            return default if default is not None else cls.CLI
        try:
            return cls(value)
        except ValueError:
            return default if default is not None else cls.CLI


class SecurityProfile(str, Enum):
    """Security profile presets — higher = more restrictive."""

    OPEN = "open"
    STANDARD = "standard"
    CONTROLLED = "controlled"
    RESTRICTED = "restricted"


class AutonomyLevel(int, Enum):
    """Progressive autonomy levels for agent actions."""

    FORBIDDEN = 0  # Level 0: action is prohibited
    APPROVAL = 1  # Level 1: agent executes after human confirms
    NOTIFY = 2  # Level 2: agent executes, then notifies
    AUTONOMOUS = 3  # Level 3: agent executes silently (audit log only)


# ── Provider configs ─────────────────────────────────────────────────────────


class ProviderConfig(BaseModel):
    """OpenAI-compatible provider config.

    Works for OpenAI, Azure OpenAI, Azure AI Foundry, and any OpenAI-compatible endpoint.
    PraestoClaw detects the service from the endpoint URL:
    - no endpoint           → OpenAI direct          (model prefix: openai/)
    - *.openai.azure.com    → Azure OpenAI Service   (model prefix: azure/)
    - anything else         → Azure AI Foundry        (model prefix: azure_ai/)
    """

    api_key: SecretStr | None = Field(
        default=None,
        description="API key for OpenAI/Azure OpenAI-compatible endpoint.",
    )
    endpoint: str | None = Field(
        default=None,
        description=(
            "Base endpoint URL. Leave empty for OpenAI direct; set Azure endpoint "
            "for Azure OpenAI (for example: https://xxx.openai.azure.com)."
        ),
    )
    api_version: str = Field(
        default="2024-10-21",
        description="Azure OpenAI / Azure AI Foundry API version (used for azure/* and azure_ai/* models).",
    )


class GitHubCopilotConfig(BaseModel):
    """GitHub Copilot authentication settings."""

    token: SecretStr | None = Field(
        default=None,
        description="GitHub OAuth token used to exchange a Copilot session token.",
    )
    ghe_host: str | None = Field(
        default=None,
        description=(
            "Optional GitHub Enterprise host for Copilot token exchange, for example "
            "'msft.ghe.com'. Leave empty for github.com. Device login remains github.com-scoped; "
            "provide a GHE token when this is set. The LLM API base is read from the "
            "token response's endpoints.api."
        ),
    )


class ModelAlias(BaseModel):
    """Named model aliases for convenience.

    Use "auto" to let PraestoClaw pick the best available model
    based on configured provider credentials.
    """

    default: str | list[str] = Field(
        default="auto",
        description=(
            "Primary model alias. Use a concrete model ID, 'auto', or an ordered "
            "list for fallback (for example: ['github/gpt-5.4', 'github/gpt-5.2'])."
        ),
    )
    fast: str | list[str] = Field(
        default="auto",
        description=(
            "Low-latency alias. Use a concrete model ID, 'auto', or an ordered fallback list."
        ),
    )
    reasoning: str | list[str] = Field(
        default="auto",
        description=(
            "Deep-reasoning alias. Use a concrete model ID, 'auto', or an ordered fallback list."
        ),
    )
    coding: str | list[str] = Field(
        default="auto",
        description=(
            "Coding-optimized alias. Use a concrete model ID, 'auto', or an ordered fallback list."
        ),
    )


class ModelRouting(BaseModel):
    """Alias candidate chains used when alias values are set to "auto".

    Supported candidate item formats:
    - concrete model id: github/gpt-5.4, openai/gpt-4o-mini, azure/gpt-4o
    - smart OpenAI tokens: openai:auto, openai:fast, openai:reasoning

    Resolution rule: pick the first candidate with available credentials,
    then continue with the rest as runtime fallback candidates.
    """

    default_candidates: list[str] = Field(
        default_factory=lambda: [
            "github/claude-opus-4.6",
            "github/gpt-5.4",
            "github/gpt-5.2",
            "openai:auto",
        ],
        description="Candidate chain for alias 'auto' (and 'coding' when coding=auto).",
    )
    fast_candidates: list[str] = Field(
        default_factory=lambda: [
            "github/gpt-5-mini",
            "github/claude-haiku-4.5",
            "openai:fast",
        ],
        description="Candidate chain for alias 'fast'.",
    )
    reasoning_candidates: list[str] = Field(
        default_factory=lambda: ["github/o3", "openai:reasoning"],
        description="Candidate chain for alias 'reasoning'.",
    )


class ProvidersConfig(BaseModel):
    """Top-level provider configuration used by model routing and auth.

    Minimal examples:

    1) GitHub-only:
         providers:
             github_copilot:
                 token: ${GITHUB_COPILOT_TOKEN}
                 ghe_host: null  # optional, e.g. msft.ghe.com

    2) GitHub + Azure OpenAI:
         providers:
             github_copilot:
                 token: ${GITHUB_COPILOT_TOKEN}
             openai:
                 api_key: ${AZURE_OPENAI_API_KEY}
                 endpoint: ${AZURE_OPENAI_ENDPOINT}

    3) Custom routing order:
         providers:
             routing:
                 default_candidates: [github/gpt-5.4, github/gpt-5.2, openai:auto]
                 fast_candidates: [github/gpt-5-mini, openai:fast]
    """

    openai: ProviderConfig = Field(default_factory=ProviderConfig)
    github_copilot: GitHubCopilotConfig = Field(default_factory=GitHubCopilotConfig)
    aliases: ModelAlias = Field(default_factory=ModelAlias)
    routing: ModelRouting = Field(default_factory=ModelRouting)


# ── Agent config ─────────────────────────────────────────────────────────────


class BudgetConfig(BaseModel):
    """Iteration budget settings (Hermes-style)."""

    max_iterations: int = Field(default=90, ge=1)
    subagent_max_iterations: int = Field(default=50, ge=1)
    grace_call: bool = True


class CompactionConfig(BaseModel):
    """Enhanced compaction settings (multi-pass)."""

    post_threshold: float = Field(default=0.80, ge=0.0, le=1.0)
    pre_threshold: float = Field(default=0.95, ge=0.0, le=1.0)
    protect_first_n: int = Field(default=3, ge=0)
    protect_last_n: int = Field(default=20, ge=1)
    summary_target_ratio: float = Field(default=0.20, ge=0.0, le=1.0)
    anti_thrashing_min_savings: float = Field(default=0.10, ge=0.0, le=1.0)


class ProviderBackendConfig(BaseModel):
    """Per-provider backend configuration."""

    type: Literal["openai", "anthropic", "gemini"] = "openai"
    api_key: SecretStr | None = None
    base_url: str | None = None
    api_mode: Literal["auto", "chat_completions", "responses", "anthropic_messages"] = "auto"
    model: str | None = None


class FailoverConfig(BaseModel):
    """Failover chain configuration."""

    chain: list[ProviderBackendConfig] = Field(default_factory=list)
    restore_primary_after_turns: int = Field(default=1, ge=1)


class CredentialPoolConfig(BaseModel):
    """Multi-key rotation configuration."""

    credentials: list[ProviderBackendConfig] = Field(default_factory=list)
    strategy: Literal["fill_first", "round_robin", "random"] = "fill_first"
    cooldown_seconds: int = Field(default=3600, ge=0)


class AgentConfig(BaseModel):
    name: str = "PraestoClaw Assistant"
    description: str = ""
    model: str = "auto"
    reasoning_effort: Literal["low", "medium", "high", "none"] | None = Field(
        default="high",
        description=(
            "Default reasoning/thinking level forwarded to the LLM provider. "
            "One of 'low', 'medium', 'high', 'none', or null to disable. "
            "Maps to OpenAI/GitHub reasoning_effort and is ignored by providers "
            "that don't support extended thinking."
        ),
    )
    instructions: str = Field(
        default="",
        description="Agent instructions. For built-in agents (explorer, default), prefer ~/.praestoclaw/EXPLORER.md or AGENTS.md instead.",
    )
    max_iterations: int = Field(default=40, ge=1)
    timeout: int = Field(default=1200, ge=0)
    memory_window: int = Field(default=50, ge=1)
    memory_writable: bool = True
    compaction_keep_min_turns: int = Field(default=5, ge=1)
    compaction_keep_min_msgs: int = Field(default=15, ge=1)
    compaction_topic_threshold: float = Field(default=0.3, ge=0.0, le=1.0)
    context_limit: int | None = Field(
        default=None, ge=1
    )  # None = auto-detect from model; set explicitly to override
    reminder_interval: int = Field(
        default=10, ge=0
    )  # Inject a system reminder every N tool calls (0 = disabled)
    max_spawn_depth: int = Field(default=2, ge=0)
    max_concurrent_children: int = Field(default=5, ge=1)
    tools: list[str] | None = Field(
        default_factory=list
    )  # None=all tools; default [] for YAML safety
    skills: list[str] = Field(default_factory=list)
    chat: bool = True
    enabled: bool = True
    metadata: dict[str, Any] = Field(default_factory=dict)
    # Identity files
    soul_file: str | None = None  # SOUL.md path
    user_file: str | None = None  # USER.md path (auto-learning)
    agents_file: str | None = None  # AGENTS.md path (multi-agent rules)
    # Per-agent permissions
    permissions: AgentPermissions | None = None
    # v2 agent core settings
    budget: BudgetConfig = Field(default_factory=BudgetConfig)
    compaction_v2: CompactionConfig = Field(default_factory=CompactionConfig)
    failover: FailoverConfig = Field(default_factory=FailoverConfig)
    credential_pool: CredentialPoolConfig = Field(default_factory=CredentialPoolConfig)
    memory_nudge_interval: int = Field(default=10, ge=0)


class AgentPermissions(BaseModel):
    """Per-agent permission overrides."""

    allow_shell: bool = True
    allow_file_write: bool = True
    allow_file_read: bool = True
    allow_network: bool = True
    allow_browser: bool = False
    allow_spawn: bool = False
    allowed_tools: list[str] = Field(default_factory=lambda: ["*"])
    denied_tools: list[str] = Field(default_factory=list)


# Update forward reference
AgentConfig.model_rebuild()


class AgentsConfig(BaseModel):
    default: AgentConfig = Field(default_factory=AgentConfig)
    agents: dict[str, AgentConfig] = Field(default_factory=dict)

    @model_validator(mode="before")
    @classmethod
    def _flatten_agents(cls, data: Any) -> Any:
        """Allow extra agents at the top level instead of under an 'agents' key.

        Both formats are accepted:
          agents:            agents:
            reviewer: ...      agents:
                                 reviewer: ...
        """
        if not isinstance(data, dict):
            return data
        data = dict(data)
        extra: dict[str, Any] = {}
        reserved = {"default", "agents"}
        for key in list(data):
            if key not in reserved:
                extra[key] = data.pop(key)
        if extra:
            nested = data.get("agents", {})
            if not isinstance(nested, dict):
                raise ValueError(f"'agents' must be a mapping, got {type(nested).__name__}")
            duplicates = set(nested).intersection(extra)
            if duplicates:
                raise ValueError(
                    f"Agent(s) defined both at top level and under 'agents': "
                    f"{', '.join(sorted(duplicates))}. Remove the duplicate."
                )
            nested.update(extra)
            data["agents"] = nested
        return data


# ── Tools config ─────────────────────────────────────────────────────────────


class ShellConfig(BaseModel):
    """Shell execution guardrails."""

    timeout: int = Field(default=120, ge=1)
    deny_patterns: list[str] = Field(
        default_factory=lambda: [
            r"rm\s+-rf\s+/",
            r":\(\)\s*\{\s*:\|:&\s*\}\s*;",
            r"\bformat\b.*\s[A-Za-z]:(?:\s|\\|/|$)",
            r"\bshutdown\b",
            r"\breboot\b",
            r"\bmkfs\b",
            r"\bdd\b\s+if=.*/dev/",
            r"\b(curl|wget)\b.*\|\s*(ba)?sh",
            r"\bchmod\b\s+777\b",
            r"\bchown\b\s+-R\s+root",
        ]
    )
    allow_patterns: list[str] = Field(default_factory=list)


class FileSystemConfig(BaseModel):
    """File system tool settings."""

    max_file_size_bytes: int = 10 * 1024 * 1024  # 10 MB


class BrowserConfig(BaseModel):
    """Browser automation (Playwright) settings."""

    enabled: bool = True
    browser: Literal["msedge", "chromium", "firefox"] = "msedge"
    headless: bool = True
    timeout: int = Field(default=30_000, ge=0)
    viewport_width: int = Field(default=1280, ge=1)
    viewport_height: int = Field(default=720, ge=1)
    evaluate_enabled: bool = True  # allow JS evaluation
    allowed_domains: list[str] = Field(default_factory=list)  # empty = all (with SSRF rules)
    persistent_profile: str | None = None  # path to user data dir for authenticated browsing
    cdp_url: str | None = (
        None  # CDP endpoint to connect to existing browser (e.g. "http://localhost:9222")
    )
    mark_content_untrusted: bool = True  # wrap extracted content as untrusted


class MCPAuthConfig(BaseModel):
    """Authentication config for HTTP MCP servers."""

    type: Literal["none", "implicit", "bearer", "oauth"] = "none"
    token: SecretStr | None = None
    token_env: str | None = None
    client_id: str | None = None
    client_secret: SecretStr | None = None
    scopes: list[str] = Field(default_factory=list)
    grant_type: Literal["authorization_code", "client_credentials"] | None = None
    callback_port: int | None = Field(default=None, ge=0, le=65535)
    auth_server_url: str | None = None


class MCPServerConfig(BaseModel):
    """Configuration for a single MCP server."""

    # Connection
    command: str | None = None
    args: list[str] = Field(default_factory=list)
    url: str | None = None
    env: dict[str, str] = Field(default_factory=dict)

    # Metadata
    description: str | None = Field(None, max_length=100)  # one-line summary (≤100 chars)
    enabled: bool | Literal["auto"] = True  # True/False/"auto" (auto = connect if token cached)

    # Per-server overrides (all optional)
    timeout: int | None = Field(default=None, ge=1)
    trusted: bool = Field(
        default=False,
        description=(
            "If true, cap this server's effective bundled / no-match risk "
            "score at 6 (Timeout-auto in the standard profile, Human in "
            "controlled / restricted).  Bundled destructive tools "
            "(delete_release: 8, deleteListColumn: 7, etc.) are lowered to "
            "6, so they still produce a user-visible manual approval gate "
            "before running — they are NOT "
            "silently auto-executed.  Use only for servers you have "
            "vetted; for tools that you've audited and want to run "
            "silently, set ``tool_risks: {<tool>: 5}`` per-tool — those "
            "explicit user values bypass the cap and are honoured verbatim."
        ),
    )
    risk: int | str | None = Field(
        None, description="Server default risk: int (score) or str (LLM prompt)"
    )
    tool_risks: dict[str, int | str] = Field(
        default_factory=dict,
        description="Per-tool risk overrides. Key=tool_name, value=int (score) or str (prompt).",
    )
    tool_timeouts: dict[str, int] = Field(
        default_factory=dict,
        description=(
            "Per-tool timeout overrides in seconds. Key=raw tool name (without "
            "MCP_<ns>_ prefix), value=timeout. Wins over the server-level "
            "``timeout`` and the agency/standard defaults. Use for tools that "
            "are known to legitimately exceed the default (e.g. ADO "
            "``repo_pull_request`` on large PRs)."
        ),
    )
    risk_rules: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Conditional risk rules. [{match: {tool: regex, arg: regex}, risk: int|str}]",
    )
    namespace: str | None = Field(None, pattern=r"^[a-zA-Z0-9_-]+$")

    # Auth (HTTP transport only)
    auth: MCPAuthConfig = Field(default_factory=MCPAuthConfig)
    # Extra static HTTP headers merged with auth headers (HTTP transport only)
    headers: dict[str, str] = Field(default_factory=dict)

    @property
    def is_agency(self) -> bool:
        """Auto-detect Agency-proxied servers by command name."""
        return self.command == "agency"


class CopilotModelPolicyConfig(BaseModel):
    """Per-task-type default model. Overrides default_model when set."""

    code: str = "claude-opus-4.6"
    review: str = "claude-opus-4.6"
    test: str = "claude-opus-4.6"
    refactor: str = "claude-opus-4.6"


class CopilotRetryConfig(BaseModel):
    enabled: bool = False
    max_attempts: int = Field(default=2, ge=1)


class CopilotHooksConfig(BaseModel):
    block_copilot_tools: list[str] = Field(default_factory=list)


class CopilotToolConfig(BaseModel):
    """GitHub Copilot CLI delegate tool settings."""

    enabled: bool = True
    cli_path: str | None = (
        None  # None = use SDK bundled binary; set to override (e.g. "/usr/local/bin/copilot")
    )
    default_model: str = "claude-opus-4.6"
    task_timeout: int = Field(default=0, ge=0)  # seconds; 0 = use 1h cap (SDK default is only 60s)
    max_concurrent: int = Field(default=5, ge=1)  # max parallel background tasks; must be >= 1
    notification_max_chars: int = Field(default=4000, ge=0)
    model_policy: CopilotModelPolicyConfig = Field(default_factory=CopilotModelPolicyConfig)
    retry: CopilotRetryConfig = Field(default_factory=CopilotRetryConfig)
    hooks: CopilotHooksConfig = Field(default_factory=CopilotHooksConfig)


class ClaudeCodeModelPolicyConfig(BaseModel):
    """Per-task-type default model for Claude Code CLI tasks."""

    code: str = "opus"
    review: str = "opus"
    test: str = "opus"
    refactor: str = "opus"
    research: str = "opus"


class ClaudeCodeToolConfig(BaseModel):
    """Claude Code CLI delegate tool settings."""

    enabled: bool = True
    cli_path: str | None = None  # None = use SDK default; set to override
    default_model: str = "opus"
    task_timeout: int = Field(default=1800, ge=0)  # seconds; 0 = use 1h cap
    max_concurrent: int = Field(default=3, ge=1)
    notification_max_chars: int = Field(default=4000, ge=0)
    model_policy: ClaudeCodeModelPolicyConfig = Field(default_factory=ClaudeCodeModelPolicyConfig)
    dangerously_skip_permissions: bool = False
    # SDK setting sources — include 'local' so .claude/settings.local.json
    # (which has enabledPlugins for Agency plugins) is loaded
    setting_sources: list[Literal["user", "project", "local"]] = Field(
        default_factory=lambda: ["user", "project", "local"]  # type: ignore[arg-type]
    )
    # Whether to instruct Claude to use Agency plugins (/review-pr, /code-review)
    use_plugins: bool = True


class MarketplaceSourceConfig(BaseModel):
    """A single marketplace source."""

    label: str = Field(description="Human-readable name for the marketplace.")
    path: str = Field(description="Absolute path to the marketplace directory.")
    format: str = Field(
        default="auto",
        description=(
            "Skill format: 'flat', 'plugin', 'single', 'zip-archive', "
            "'github-org', or 'auto' (auto-detect)."
        ),
    )


class SkillsConfig(BaseModel):
    """Skills system configuration."""

    inject_threshold: int = Field(
        default=20,
        ge=0,
        description="Minimum score to auto-inject a skill into user context.",
    )
    max_inject: int = Field(
        default=1,
        ge=0,
        description="Maximum number of skills to auto-inject per message.",
    )
    summary_budget: int = Field(
        default=8000,
        ge=0,
        description="Max chars for skills summary section in system prompt.",
    )
    always_budget: int = Field(
        default=8000,
        ge=0,
        description="Max chars for always-loaded skills content in system prompt.",
    )
    marketplaces: dict[str, MarketplaceSourceConfig] = Field(
        default_factory=dict,
        description="Marketplace sources keyed by ID.",
    )
    disabled: list[str] = Field(
        default_factory=list,
        description="Skill names disabled by user — hidden from LLM but still listed in UI.",
    )


class ToolOutputConfig(BaseModel):
    """Global defaults for tool output truncation."""

    max_chars: int = Field(
        default=32_000,
        ge=1_000,
        description="Default max output chars for tools that don't declare their own limit.",
    )
    llm_compression_enabled: bool = Field(
        default=True,
        description="Use fast LLM for intelligent compression. Falls back to smart_truncate if False.",
    )


class ToolsConfig(BaseModel):
    output: ToolOutputConfig = Field(default_factory=ToolOutputConfig)
    shell: ShellConfig = Field(default_factory=ShellConfig)
    filesystem: FileSystemConfig = Field(default_factory=FileSystemConfig)
    browser: BrowserConfig = Field(default_factory=BrowserConfig)
    copilot: CopilotToolConfig = Field(default_factory=lambda: CopilotToolConfig())
    claude_code: ClaudeCodeToolConfig = Field(default_factory=ClaudeCodeToolConfig)
    mcp_servers: dict[str, MCPServerConfig] = Field(default_factory=dict)
    mcp_risk_policy: dict[str, Any] = Field(
        default_factory=dict,
        description="MCP risk policy. _default_risk, _rules at top level; server blocks with tool scores and _rules.",
    )

    @model_validator(mode="before")
    @classmethod
    def _coerce_none(cls, data: Any) -> Any:
        """Accept `tools: null` in YAML as empty ToolsConfig."""
        if data is None:
            return {}
        return data


# ── Security config ──────────────────────────────────────────────────────────


class AuditConfig(BaseModel):
    enabled: bool = True
    log_file: str | None = "~/.praestoclaw/audit/audit.jsonl"
    redact_secrets: bool = True


class RBACRole(BaseModel):
    """Role-based access control role."""

    name: str
    allowed_tools: list[str] = Field(default_factory=lambda: ["*"])
    denied_tools: list[str] = Field(default_factory=list)
    allowed_channels: list[str] = Field(default_factory=lambda: ["*"])
    max_iterations: int = Field(default=25, ge=1)


class ToolAutonomyConfig(BaseModel):
    """Per-tool autonomy level override."""

    level: AutonomyLevel = AutonomyLevel.AUTONOMOUS


class PathAutonomyConfig(BaseModel):
    """Per-path autonomy override."""

    read: AutonomyLevel = AutonomyLevel.AUTONOMOUS
    write: AutonomyLevel = AutonomyLevel.NOTIFY


class AutoModeConfig(BaseModel):
    """Auto-mode classifier settings (``approval.decider == "auto"``).

    When the auto decider is active, a fast LLM classifier decides per tool call
    whether to auto-run or pause for human review. These lists let admins tune
    the classifier's system prompt without code changes (mirrors claude-code's
    ``settings.autoMode`` allow / soft_deny / environment sections).
    """

    allow: list[str] = Field(
        default_factory=list,
        description="Extra patterns the classifier should treat as safe (ALLOW).",
    )
    soft_deny: list[str] = Field(
        default_factory=list,
        description="Extra patterns the classifier should treat as risky (BLOCK).",
    )
    environment: list[str] = Field(
        default_factory=list,
        description="Environment/context hints injected as user intent.",
    )
    classifier: Literal["tool_use", "both", "fast", "thinking"] = Field(
        default="tool_use",
        description=(
            "Auto-mode classifier implementation. 'tool_use' (default) is a "
            "single-stage JSON classifier. 'both' is the 2-stage XML classifier "
            "(fast yes/no, escalating to chain-of-thought only on a block); "
            "'fast' is stage-1 only; 'thinking' is stage-2 only."
        ),
    )
    safe_tools: list[str] | None = Field(
        default=None,
        description=(
            "Override the read-only/metadata tool fast-path allowlist. "
            "None keeps the built-in default set."
        ),
    )
    custom_prompt: str | None = Field(
        default=None,
        description=(
            "Free-form operator instructions injected as a prefix message on "
            "every auto-mode classifier call (the claude-code buildClaudeMdMessage "
            "port). Unlike allow/soft_deny/environment (which rewrite fixed "
            "sections of the system prompt), this rides alongside the action "
            "being judged and can tighten the decision. None injects nothing."
        ),
    )


class ApprovalConfig(BaseModel):
    """Approval workflow settings."""

    decider: Literal["scoring", "auto"] = Field(
        default="scoring",
        description=(
            "Which approval decision engine to use. 'scoring' (default) uses the "
            "risk-score × profile policy table. 'auto' uses an LLM classifier "
            "(claude-code style auto mode) to decide allow vs human review. "
            "Downstream approval-card / human-review flow is identical either way."
        ),
    )
    auto_mode: AutoModeConfig = Field(default_factory=AutoModeConfig)
    timeout_seconds: int = Field(default=900, ge=0)  # 15 min before escalation
    max_age_seconds: int = Field(
        default=86400,
        ge=0,
        description=(
            "Maximum age for a pending approval before it expires fail-closed. "
            "Set 0 to disable expiry."
        ),
    )
    auto_approve_timeout: int = Field(
        default=30,
        ge=0,
        description="Deprecated compatibility setting. Approval gates no longer auto-approve.",
    )
    escalation_channels: list[ChannelType] = Field(default_factory=lambda: [ChannelType.CLOUD])
    default_channel: ChannelType = ChannelType.CLI


class AllowlistEntry(BaseModel):
    """A single allowlist rule — tool name + per-field match patterns.

    Each key in ``match`` is checked against the corresponding arg value
    via ``re.fullmatch(pattern, str(value))``.  All must pass (AND logic).
    Fields not in ``match`` are ignored (content can vary freely).
    Empty or absent ``match`` means all args pass (full tool bypass).

    .. versionchanged:: P0 fix (commit fc1df09)
        The matcher uses ``re.fullmatch`` (not ``re.search``).  An
        unanchored pattern like ``git status`` only matches the **exact**
        string ``git status`` — not ``git status ; rm -rf /``.  This
        closes a substring-smuggling bypass where a lookahead trailer
        (``(?=\\s|$)``) or missing end anchor allowed an attacker
        prefix to satisfy the pattern.  Authors who want trailing args
        must opt in explicitly with a bounded tail like
        ``^git status(?:[ \\t][^;|&$\\`<>\\n\\r]*)?$``.
    """

    tool: str
    match: dict[str, str] = Field(default_factory=dict)  # arg_key → regex pattern
    added_by: str = ""
    note: str = ""


class AllowlistConfig(BaseModel):
    """Per-user tool approval allowlist settings.

    Entries can be auto-added via "Always Allow" or manually edited in
    ``praestoclaw.local.yaml`` under ``security.allowlist.entries``.
    """

    enabled: bool = True
    entries: list[AllowlistEntry] = Field(default_factory=list)


class SecurityOverrides(BaseModel):
    """Fine-grained security overrides on top of profile."""

    tools: dict[str, int] = Field(default_factory=dict)  # tool_name → autonomy level
    paths: dict[str, PathAutonomyConfig] = Field(default_factory=dict)  # glob → config
    agents: dict[str, dict[str, Any]] = Field(default_factory=dict)  # agent → restrictions


class EStopConfig(BaseModel):
    """Emergency stop configuration."""

    enabled: bool = True
    trigger_on_leak: bool = True
    notify_channels: list[str] = Field(default_factory=list)


class OsSandboxConfig(BaseModel):
    """OS-level subprocess sandbox (Seatbelt / bwrap / Windows Sandbox).

    Disabled by default — with ``enabled=False`` the behaviour is byte-identical
    to the legacy "Python policy layer only" world. Flipping ``enabled=True``
    wraps every shell/git subprocess so the kernel enforces filesystem and
    network isolation regardless of what the spawned command tries.

    The kill switch (``enabled``) is intentionally separate from the strategy
    (``mode``) so config can ship with a non-default mode pre-staged but
    inert. The env var ``PRAESTOCLAW_OS_SANDBOX_DISABLE=1`` force-disables
    regardless of config (rescue valve when the sandbox itself misbehaves).

    Modes follow the codex CLI vocabulary:

    - ``read_only`` — entire FS read-only, no network. For exploration tasks.
    - ``workspace_write`` — read-only FS except workspace + writable_roots + /tmp.
      Network denied unless ``allow_network`` is set.
    - ``danger_full_access`` — explicit "I know what I'm doing"; behaves like
      disabled but surfaces separately in audits.
    """

    enabled: bool = Field(
        default=False,
        description=(
            "Master kill switch. False (default) preserves legacy behaviour exactly. "
            "True activates kernel-level wrapping per ``mode``. "
            "Env var PRAESTOCLAW_OS_SANDBOX_DISABLE=1 overrides to False."
        ),
    )
    mode: Literal["read_only", "workspace_write", "danger_full_access"] = "workspace_write"
    writable_roots: list[str] = Field(
        default_factory=list,
        description="Extra absolute paths that become writable in workspace_write mode.",
    )
    allow_network: bool = Field(
        default=False,
        description="Allow outbound network in workspace_write/read_only modes (default: deny).",
    )


class SecurityConfig(BaseModel):
    profile: SecurityProfile = SecurityProfile.STANDARD
    allowed_paths: list[str] | None = None  # None = use profile defaults
    denied_paths: list[str] | None = None  # None = use profile defaults
    audit: AuditConfig = Field(default_factory=AuditConfig)
    estop: EStopConfig = Field(default_factory=EStopConfig)
    roles: dict[str, RBACRole] = Field(default_factory=dict)
    default_role: str = "user"
    require_auth: bool = False
    approval: ApprovalConfig = Field(default_factory=ApprovalConfig)
    allowlist: AllowlistConfig = Field(default_factory=AllowlistConfig)
    overrides: SecurityOverrides = Field(default_factory=SecurityOverrides)
    secret_backend: Literal["auto", "keyring", "fernet", "env"] = "auto"
    auto_migrate_secrets: bool = True
    risk_context: str | None = Field(
        default=None,
        description="Environment-specific risk hints injected into LLM scorer prompts.",
    )
    os_sandbox: OsSandboxConfig = Field(default_factory=OsSandboxConfig)

    # Profile-based autonomy defaults (populated from profile)
    autonomy_defaults: dict[str, int] = Field(default_factory=dict)


# ── Web server config ────────────────────────────────────────────────────────


class WebServerConfig(BaseModel):
    """Self-hosted HTTP web server (web channel)."""

    enabled: bool = False
    host: str = "localhost"
    port: int = Field(default=3004, ge=1, le=65535)
    api_key: SecretStr | None = None
    cors_origins: list[str] = Field(default_factory=list)  # empty = same-origin only

    @model_validator(mode="after")
    def _coerce_empty_api_key(self) -> WebServerConfig:
        """Treat empty/whitespace API key as unset (None)."""
        if self.api_key is not None and not self.api_key.get_secret_value().strip():
            self.api_key = None
        return self

    rate_limit_per_minute: int = Field(default=60, ge=1)
    request_timeout: int = Field(default=300, ge=0)  # Per-request timeout in seconds
    entra_tenant_id: str = ""  # must be configured explicitly
    entra_client_id: str = ""  # must be configured explicitly
    entra_client_id_legacy: list[str] = Field(
        default_factory=list,
        description="Additional client IDs to accept during app registration migration",
    )
    owner_oid: str = Field(default="", exclude=True)  # runtime-only; never serialized


# ── Channel configs ──────────────────────────────────────────────────────────


class BaseChannelConfig(BaseModel):
    enabled: bool = False
    allow_from: list[str] = Field(default_factory=list)


class CLIChannelConfig(BaseChannelConfig):
    enabled: bool = True
    prompt: str = "you> "


class CloudChannelConfig(BaseChannelConfig):
    """PraestoClaw Cloud Gateway relay channel.

    In AWPS mode, negotiates an Azure Web PubSub client URL through Gateway
    using an Entra ID access token, then connects outbound without inbound
    firewall rules.

    login_method:
      auto    — (default) browser PKCE only
      browser — same as auto (explicit)
      wam     — WAM broker → browser PKCE fallback (requires msal[broker] on Windows)
      device  — device code flow (visit URL + enter code); only when explicitly configured
                (many tenants disable device code via Conditional Access)
    """

    enabled: bool = True  # auto-connect on every praestoclaw startup (silent auth only)

    # Defaults are empty here; bundled praestoclaw.yaml provides pre-configured values.
    # If url/client_id are still empty after config merge, cloud channel is disabled.
    url: str = ""
    transport_mode: Literal["direct", "awps"] = "awps"
    negotiate_url: str = ""
    negotiate_timeout_s: float = Field(default=15.0, gt=0)
    client_url_refresh_skew_s: float = Field(default=300.0, ge=0)
    tenant_id: str = ""
    client_id: str = ""
    scope: str = ""
    login_method: Literal["auto", "browser", "wam", "device"] = "auto"
    login_port: int = Field(
        default=49216, ge=0, le=65535
    )  # localhost port for MSAL PKCE callback; 0 = OS-assigned
    auto_reconnect: bool = True
    reconnect_max: int = Field(default=60, ge=1)
    # Local dev only: skip MSAL and use this token directly as the Bearer value.
    # Set to the gateway's Auth:Bypass:Token (default "dev-bypass") for local testing.
    bypass_token: str | None = None
    # Teams bot direct-chat URL shown on the status dashboard and home page.
    # Format: https://teams.microsoft.com/l/chat/0/0?users=28:<bot-id>
    teams_bot_url: str = ""

    # Teams @mention display name of this bot (the text users type after "@").
    # A staging or custom-named deployment MUST set this to its real bot name
    # (e.g. "PraestoClawStaging"); the staging bundled diff does so. Used so a
    # group turn can tell the LLM which "@name" refers to itself — a wrong value
    # makes the bot fail to strip its own @mention and record its own name as a
    # topic.
    bot_display_name: str = "PraestoClaw"

    # Teams group/channel verbosity. Personal chats keep full detail.
    # - minimal: drop non-actionable intermediate process emissions; keep final
    #   replies, promoted fold-back, and background-task delivery in the group.
    # - full: show non-approval intermediate process emissions in the group.
    # - silent: same delivery policy as minimal for now: no intermediate noise,
    #   but final results still return to the originating group/channel.
    # Approval prompt/resolved cards always route to the owner's private chat.
    group_chat_verbosity: Literal["minimal", "full", "silent"] = Field(
        default="minimal",
        description=(
            "Teams group/channel verbosity. 'minimal' and 'silent' suppress "
            "non-actionable intermediate emissions while preserving final "
            "delivery in the originating group/channel; 'full' shows "
            "non-approval intermediate emissions in the group/channel. "
            "Approval prompt/resolved cards always route to the owner's "
            "private chat."
        ),
    )

    # Automatically check Teams app installation and prompt to install on startup.
    # Set to false to suppress the Teams sideload check during development.
    teams_startup_check: bool = True

    # Override a2a identity for local multi-instance testing
    a2a_instance_id: str | None = None
    a2a_user_id: str | None = None

    # Local dev only: when set, the cloud channel uses this string verbatim as
    # the agent_id sent in `_session.hello`, bypassing the normal
    # ``{instance_id}@{run_id}`` composition. Set by ``--instance-id`` CLI
    # flag for predictable, restart-stable agent ids during local testing.
    agent_id_override: str | None = None

    # Auth provider for the silent-token path. Four mutually-exclusive
    # options matching the user-facing sign-in menu (1-to-1):
    #   azure_cli  — (default) reuse `az login` session
    #   m365       — DEPRECATED: borrow Teams Web's MSAL RT via Playwright
    #   os_account — MSAL WAM broker (PRT-based, scopes=["openid"])
    #   browser    — MSAL browser PKCE (refresh_token cache)
    # Failures do NOT cross providers; each runs in isolation. Persisted by
    # `pc init` from the user's menu choice.
    auth_provider: Literal["azure_cli", "m365", "os_account", "browser"] = "azure_cli"

    # Teams RT strategy — borrow Teams Web's MSAL session to escape Conditional
    # Access on a custom AAD app. See docs/design/features/cloud-auth-lifecycle.md.
    m365_auth: M365AuthConfig = Field(default_factory=lambda: M365AuthConfig())

    # Azure CLI strategy — reuse the user's `az login` session.
    azure_cli: AzureCliAuthConfig = Field(default_factory=lambda: AzureCliAuthConfig())


class M365AuthConfig(BaseModel):
    """Teams RT silent-token strategy options.

    When ``enabled`` is True (default) the cloud channel will attempt to
    obtain access tokens by borrowing the user's Teams Web session via a
    persistent Edge profile that PraestoClaw manages (separate from the
    user's own Edge browser). This is the only silent path that escapes
    Entra Conditional Access on our custom client_id reliably.

    Set ``allow_browser_launch=False`` to skip the Playwright re-extract
    phase — useful in headless dev environments where launching Edge is
    undesirable. Phases A (cache hit) and B (HTTP refresh of cached RT)
    still run.
    """

    enabled: bool = True
    allow_browser_launch: bool = True
    profile_dir: str = ""  # default: <data_dir>/teams-edge-profile
    login_timeout_s: int = Field(default=120, ge=10, le=600)


class AzureCliAuthConfig(BaseModel):
    """Azure CLI silent-token strategy options.

    When ``channels.cloud.auth_provider == "azure_cli"``, the cloud channel
    obtains access tokens by shelling out to ``az account get-access-token``.
    No local cache or refresh logic — az manages its own ``~/.azure/`` cache.

    ``resource`` is what gets passed to ``--resource``. Default is ARM, not
    Graph: enterprise tenants commonly enforce Conditional Access Token
    Protection on Graph for non-FOCI clients (including the az CLI), which
    blocks token issuance with AADSTS530084. ARM is the az CLI's primary
    audience and is rarely subject to the same restriction. The gateway does
    not validate ``aud`` (see jwt_auth.py) so any Entra token with an ``oid``
    claim is accepted — ARM works exactly the same as Graph here.

    ``tenant_id`` is forwarded to ``az login --tenant`` during the init
    wizard; when None, the cloud tenant_id is reused.
    """

    resource: str = "https://management.azure.com"
    tenant_id: str | None = None


class A2AConfig(BaseModel):
    """A2A overlay configuration (Phase 1)."""

    enabled: bool = True  # Feature flag — on by default
    instance_id: str | None = None  # Agent instance identity advertised to Gateway/A2A
    user_id: str | None = None  # User-level identity (username/alias email)
    # Phase 1: PraestoClaw is always marked as the active instance for its user
    is_active_instance: bool = True
    protocol_version: str = "1"

    # ── Executor-side notify filter ────────────────────────────────────
    # When an a2a_task carrier promotes its request_id to a Teams route
    # (so the executor's intermediate emissions render as Adaptive Cards
    # in the executor's own Teams chat), every plan card / hook status /
    # approval prompt / NotifyTool emission lands in the executor's
    # Teams. That can be very noisy for a long-running remote task.
    #
    # This filter drops categories listed here *only* on the a2a_task
    # executor-side teams-routed channels. Other flows (native Teams
    # conversation, webchat session, CLI) are untouched.
    #
    # Default keeps ``plan_progress`` and approval cards: plan progress lets
    # the owner watch the task unfold, while approval prompts are actionable
    # manual gates and must remain visible or the worker can block on an
    # invisible card. Approval prompts remain pending until manually resolved.
    # Final replies / errors pass through naturally because they don't carry
    # ``keep_context=True`` and aren't classified as intermediate. Other
    # noisy intermediate categories are dropped.
    #
    # Recognized category tokens (see ``CloudChannel._classify_notify_category``):
    #   * ``plan_progress``      — plan/checkpoint progress card
    #   * ``tool_status``        — pre/post/progress tool status card
    #   * ``task_progress``      — gateway stage-transition card
    #   * ``approval_prompt``    — risk-gate approval request card
    #   * ``approval_resolved``  — approval decision update card
    #   * ``notify_tool``        — agent's NotifyTool broadcast
    #   * ``intermediate_other`` — any other ``keep_context=True`` emission
    #                              not matching the above (catch-all)
    executor_notify_filter: list[str] = Field(
        default_factory=lambda: [
            "tool_status",
            "task_progress",
            "notify_tool",
            "intermediate_other",
        ]
    )


class ChannelsConfig(BaseModel):
    cli: CLIChannelConfig = Field(default_factory=CLIChannelConfig)
    cloud: CloudChannelConfig = Field(default_factory=CloudChannelConfig)
    web: WebServerConfig = Field(default_factory=WebServerConfig)
    a2a: A2AConfig = Field(default_factory=A2AConfig)


# ── Cron config ──────────────────────────────────────────────────────────────


class HeartbeatConfig(BaseModel):
    """Built-in heartbeat job configuration."""

    enabled: bool = True
    interval: int = Field(default=1800, ge=1)  # 30 minutes, in seconds


class CronConfig(BaseModel):
    enabled: bool = False
    heartbeat: HeartbeatConfig = Field(default_factory=HeartbeatConfig)
    max_concurrent_jobs: int = Field(default=5, ge=1)


class WorkflowConfig(BaseModel):
    """Reusable single-agent workflow orchestration.

    Shipped and enabled by default. Users can set ``enabled: false`` to opt out;
    when disabled, the ``workflow`` tool and its runtime support are not registered.

    Part of the UWF/Sumeru workflow-orchestration integration (see #543).
    """

    enabled: bool = True

    suggest: bool = False
    """Opt-in workflow auto-suggest (P2). When on, a hook nudges — at most once
    per session — to *run* a matching saved workflow, or *save* a just-described
    repeatable procedure as one. Suggest-only: it never runs a workflow and never
    modifies a reply. It fires ONLY on the CLI and local desktop webchat
    (``local_webchat``) channels; WEB (Tier-2 HTTP/SSE) and CLOUD are intentionally
    silent because a proactive bubble can't be routed to a single connection there
    safely. Requires ``enabled`` (the WorkflowTool must be registered for a nudge
    to be actionable), so the suggester registers only when BOTH flags are on. Flag
    off → the hook handler is not registered → zero diff, no cost."""


# ── Execution-chain config ──────────────────────────────────────────────────


class ExecutionConfig(BaseModel):
    """OpenClaw-style execution-chain limits."""

    same_session_policy: Literal["queue"] = Field(
        default="queue",
        description="Same-session turns are serialized in FIFO order.",
    )
    main_max_concurrent: int = Field(
        default=4,
        ge=1,
        description="Maximum concurrently running main user/session chains.",
    )
    system_max_concurrent: int = Field(
        default=2,
        ge=1,
        description="Maximum concurrently running system/background chains.",
    )
    subagent_max_concurrent: int = Field(
        default=8,
        ge=1,
        description="Maximum concurrently running subagent chains.",
    )
    pending_per_session: int = Field(
        default=20,
        ge=1,
        description="Maximum active plus queued turns allowed per session.",
    )
    background_delivery_enabled: bool = Field(
        default=True,
        description=(
            "When true, detached background sub-agent tasks (spawn mode=background) "
            "deliver their result proactively to the originating conversation. "
            "When false, results are only retrievable via the 'tasks' tool."
        ),
    )
    max_background_tasks: int = Field(
        default=16,
        ge=1,
        description="Maximum concurrently running detached background sub-agent tasks.",
    )
    background_result_retention: int = Field(
        default=50,
        ge=1,
        description="Number of finished background-task results retained for status queries.",
    )
    background_task_timeout_seconds: int = Field(
        default=3600,
        ge=1,
        description="Hard wall-clock timeout for a detached background sub-agent task.",
    )
    workflow_orphan_retention_days: int = Field(
        default=7,
        ge=0,
        description=(
            "Days an interrupted workflow run stays offered as resumable before it is "
            "retired (kept on disk, hidden from status/resume). 0 disables the age rule."
        ),
    )
    workflow_orphan_max_per_recipe: int = Field(
        default=3,
        ge=0,
        description=(
            "How many interrupted runs of the same recipe stay resumable; older ones "
            "beyond this are retired. 0 disables the count rule."
        ),
    )

    # ── Event-loop execution model (see docs/design/core/event-loop/) ──
    # Per-channel granularity is governed by ``event_loop_promotion_channels``
    # below; the default allow-list is Teams-only (Web Chat / CLI excluded).
    main_turn_tool_budget: int = Field(
        default=3,
        ge=0,
        description=(
            "Promote on the Nth tool batch (T-count trigger). 0 disables the "
            "count trigger entirely, leaving only ``wall_clock_promote_s`` as "
            "the backstop. "
            'Default is 3: two-step interactive patterns like "check task X '
            'progress" (list + status) or "cancel task X" (list + cancel) '
            "should NOT promote — they're conversational follow-ups, not "
            "long-running work. A turn that needs a 3rd batch is genuinely "
            "multi-step and worth handing off."
        ),
    )
    wall_clock_promote_s: float = Field(
        default=20.0,
        ge=0,
        description=(
            "T-time backstop: promote a turn once its elapsed wall-clock time "
            "reaches this many seconds, checked at each loop-iteration boundary. "
            "0 disables the time trigger. Covers turns that issue many fast "
            "batches and never reach the count trigger. "
            "NOTE: only checked at batch boundaries — a turn blocked inside a "
            "single long tool call (e.g. a slow MCP RPC) cannot reach this "
            "trigger until the tool returns or hits its own per-tool timeout. "
            "See ``docs/design/core/event-loop/04-runtime-behavior.md`` §4.1 "
            '("single-long-tool gap").'
        ),
    )
    event_loop_promotion_channels: tuple[str, ...] = Field(
        default=("teams_bridge", "cloud_teams"),
        description=(
            "Allow-list of inbound source labels eligible for event-loop "
            "promotion. Web Chat is omitted by default because it streams "
            "inline with no carrier ceiling; enable it by adding "
            "'cloud_webchat'."
        ),
    )
    reaper_recent_threshold_s: float = Field(
        default=600.0,
        ge=0,
        description=(
            "Recency threshold for the startup reaper's proactive Teams "
            "notify. When a process restart leaves an orphan ``[BG task=…]`` "
            "ack row on a Teams-sourced main session AND the ack's "
            "``created_at`` is within this many seconds of startup, the "
            "reaper sends a proactive ``(failed: lost-on-restart) [Re: …]`` "
            "notify so the Teams client (which doesn't read sqlite) sees the "
            "lost work. Older orphans only get the durable sqlite fold-back "
            "row (Web/Desktop clients pick those up automatically when the "
            "user opens the conversation). 0 disables the proactive notify "
            "entirely (sqlite-only behavior, the pre-2026-06-15 default)."
        ),
    )
    background_task_receipt: Literal["adaptive", "full", "minimal", "silent"] = Field(
        default="adaptive",
        description=(
            "Verbosity of the synchronous receipt shown when a Teams turn is "
            "promoted to a background worker (event-loop promotion). "
            "'adaptive' (default, used when the user has set no explicit "
            "preference): ramp down per user — the first 3 promotions show the "
            "full copy, the next 3 show the minimal one-liner, and every one "
            "after that is silent (the per-user count is durable across "
            "restarts). "
            "'full': always the complete educational handoff copy. "
            "'minimal': always a terse one-liner. "
            "'silent': never show a visible receipt — the carrier reply is "
            "empty so nothing is posted, and the user only sees the eventual "
            "fold-back result. Setting any explicit value (full/minimal/silent) "
            "disables the adaptive ramp and is always honoured. In every mode "
            "the promotion itself, the orphan-prevention ack row, and the late "
            "fold-back are unchanged; this knob only governs the human-visible "
            "handoff message."
        ),
    )


# ── Logging config ───────────────────────────────────────────────────────────


class LoggingConfig(BaseModel):
    level: LogLevel | None = None
    console_level: LogLevel = LogLevel.INFO
    file_level: LogLevel = LogLevel.DEBUG
    format: Literal["pretty", "json"] = "pretty"
    file: str | None = None  # None → <data_dir>/logs/praestoclaw-<version>.log
    retention: str = "14 days"
    rotation: str = "10 MB"

    def model_post_init(self, _ctx: Any) -> None:
        # Legacy `level` is treated as a console-level alias. It does NOT
        # demote file_level — file logs stay at DEBUG by default so they're
        # useful for postmortem even when the console is quiet.
        if self.level is not None:
            self.console_level = self.level


# ── Hooks config ─────────────────────────────────────────────────────────────


class HooksConfig(BaseModel):
    """Built-in hook visibility and behavior controls."""

    tool_status_card: bool = Field(
        default=False,
        description="When true, show Teams tool-status Adaptive Cards during tool execution.",
    )


# ── Top-level config ─────────────────────────────────────────────────────────


class TeamsWebCaptureConfig(BaseModel):
    """Deterministic Teams capture over a logged-in Teams Web session.

    Powers ``teams_group_fetch``. Messages come from chatsvc (which, unlike
    Graph, returns the system events carrying the transcript pointer and the
    rename history) and transcripts come from the pointer the chat itself
    embeds. Everything is scoped to the conversation the turn arrived from.

    Requires a persistent Edge profile that has completed a Teams sign-in.
    ``profile_dir`` defaults to ``~/.playwright/teams-graph``.
    """

    enabled: bool = True
    profile_dir: str = Field(
        default="",
        description="Persistent Edge profile with a signed-in Teams Web session. "
        "Empty uses ~/.playwright/teams-graph.",
    )
    region: str = Field(
        default="",
        description="chatsvc region ring (e.g. apac-pilot1). Empty auto-discovers it.",
    )
    allow_headed_login: bool = Field(
        default=False,
        description="Open a visible Edge window when the browser session has expired. "
        "Off by default so a group turn never pops UI on the lending employee's desktop.",
    )
    login_timeout_s: int = Field(default=180, ge=10, le=600)
    token_skew_s: int = Field(
        default=300,
        ge=30,
        le=1800,
        description="Treat the cached Teams Web token as expired this many seconds early.",
    )
    max_pages: int = Field(default=20, ge=1, le=200)
    cache_root: str = Field(
        default="",
        description="Root for per-conversation capture caches. Empty uses <data_dir>/teams-web.",
    )


class KbCurationConfig(BaseModel):
    """Knowledge-base repositories a group turn may read and update.

    ``repos`` is an authorisation boundary, and that is the point: the curation
    stage clones and later commits to real repositories with the lending
    employee's git credentials, so the set of reachable ones must come from the
    operator, never from a message in the group. List every repository this
    agent may write to on their behalf. An empty list means no knowledge base is
    reachable and the KB tools say so plainly.

    Being *allowed* is not the same as being *chosen*. Which of these a given
    Teams conversation actually uses — and which folder inside it that group
    prefers — is set from the chat with ``kb_scope`` and stored per conversation,
    because that is a working preference rather than a permission. Widening this
    list needs a config edit; picking from it does not.

    Note what is *not* configured here: any map from a kind of knowledge to a
    directory or document. Each repository states its own conventions in its
    READMEs and those change; ``kb_inspect(action="rules")`` reads them at task
    time. Freezing that map in config would silently rot.
    """

    enabled: bool = True
    repos: list[str] = Field(
        default_factory=lambda: [
            "https://github.com/gim-home/SocietasKnowledgeBase.git",
            "https://github.com/alexyuan_microsoft/Societas-PM-Workspace.git",
            "https://github.com/gim-home/biz-table.git",
            "https://github.com/gim-home/borgee.git",
            "https://github.com/gim-home/Societas-Public.git",
        ],
        description=(
            "Repositories this agent may write to on the operator's behalf, as "
            "'owner/name' or clone URLs. Each group picks one of these with kb_scope."
        ),
    )
    max_file_bytes: int = Field(
        default=200_000,
        ge=1_000,
        le=5_000_000,
        description="Largest single document kb_inspect will return.",
    )
    sync_timeout_s: int = Field(default=180, ge=10, le=1800)


class PraestoTagExpConfig(BaseModel):
    """praesto tag exp — group-chat shared digital-employee experiment.

    EXPERIMENTAL / THROWAWAY. Each group has an isolated local MEMORY.md under
    the agent's data directory. Grep ``praesto_tag_exp`` to find the experiment.
    """

    enabled: bool = True
    # Optional tightening prompt for the borrowed-identity auto-approval gate.
    # When set AND the auto-mode ("two-step") decider is active, tool calls the
    # deterministic capability gate would auto-borrow are re-checked through the
    # classifier with this prompt injected — letting an operator narrow what a
    # borrowed group turn may auto-run without the lending employee's OK. Empty
    # keeps the fast deterministic borrow (no extra classifier call).
    approval_prompt: str | None = None
    teams_web: TeamsWebCaptureConfig = Field(default_factory=lambda: TeamsWebCaptureConfig())
    kb: KbCurationConfig = Field(default_factory=lambda: KbCurationConfig())


class AppConfig(BaseModel):
    """Root configuration for PraestoClaw."""

    name: str = "praestoclaw"
    entrypoint: str = "default"
    workspace: str = ""

    providers: ProvidersConfig = Field(default_factory=ProvidersConfig)
    agents: AgentsConfig = Field(default_factory=AgentsConfig)
    tools: ToolsConfig = Field(default_factory=ToolsConfig)
    skills: SkillsConfig = Field(default_factory=SkillsConfig)
    security: SecurityConfig = Field(default_factory=SecurityConfig)
    channels: ChannelsConfig = Field(default_factory=ChannelsConfig)
    cron: CronConfig = Field(default_factory=CronConfig)
    workflow: WorkflowConfig = Field(default_factory=WorkflowConfig)
    execution: ExecutionConfig = Field(default_factory=ExecutionConfig)
    hooks: HooksConfig = Field(default_factory=HooksConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    praesto_tag_exp: PraestoTagExpConfig = Field(default_factory=lambda: PraestoTagExpConfig())
