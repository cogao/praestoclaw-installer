"""Praesto Tag Experiment — borrowed-identity capability gate.

EXPERIMENTAL / THROWAWAY. Pairs with the gateway/channel ``praesto_tag_exp``
glue (grep that prefix to see the whole experiment).

Context: in this mock the bot acts as a group's shared digital employee, but it
is physically backed by a *real* employee's agent — it borrows that employee's
identity and permissions. A real digital employee would have its own
permissions; until that exists we must not let the borrowed session silently
use permissions the lending employee never agreed to lend.

Policy (the gentleman's-mock trade-off):
  * Exposed built-ins — plan, group_memory, teams_group_fetch,
    team_knowledge_capture, kb_scope/kb_inspect/kb_change_history/kb_draft/kb_publish,
    attachment_process, spawn, tasks, and tools. ``kb_scope`` lets the group
    pick *which* knowledge base it uses, but only from the operator's
    ``kb.repos`` allowlist — the choice is borrowed, the authorisation is not.
  * Exposed MCP — none. The Teams MCP used to be exposed wholesale, which was
    never really defensible: its search tools accept no ``chatId`` at all, so
    the only thing keeping a borrowed turn inside the group that asked was the
    wording of a prompt. One date-scoped query was observed returning 34
    unrelated conversations from across the tenant while missing the meeting it
    was asked about. ``teams_group_fetch`` replaces it and is structurally
    incapable of leaving ``metadata["cid"]``.
  * Everything else — every MCP server, general host filesystem, shell,
    networking, general skill loading, and all other tools — is unavailable to
    the group turn. ``teams_group_fetch`` is the only Teams reader and
    ``team_knowledge_capture`` the only filesystem sink.
  * Skills — only the experiment's own ``praesto-tag-exp-only`` skills may be
    loaded. They drive nothing but the whitelist above, so loading one borrows
    no further permission; a general skill exists to drive the personal agent's
    shell / filesystem / MCP surface and stays gated. This is what lets the
    capture stage hand off to the curation stage inside one turn.

This module only *classifies*; the ``ApprovalGate`` in ``hooks/handlers.py``
turns an ``"approve"`` classification into a real human-in-the-loop prompt.
"""

from __future__ import annotations

from typing import Any

PRAESTO_TAG_EXP_METADATA_KEY = "praesto_tag_exp"

# Prefix marking an MCP-server-targeting ``tools`` meta-tool call (connecting a
# server can exercise the employee's agency creds, so it stays gated).
_MCP_PREFIX_FOR_GATE = "MCP_"

# Built-in tools exposed to a borrowed-identity group turn. Everything else is
# hidden from the model and rejected at the execution gate.
PRAESTO_TAG_EXP_ALLOWED_BUILTIN_TOOLS: frozenset[str] = frozenset(
    {
        "attachment_process",
        "group_memory",
        "kb_change_history",
        "kb_draft",
        "kb_inspect",
        "kb_publish",
        "kb_scope",
        "plan",
        "spawn",
        "tasks",
        "team_knowledge_capture",
        "teams_group_fetch",
        "tools",
    }
)

# Built-ins that exist only for this experiment and must stay hidden on normal
# personal-agent turns even when the experiment is enabled in config.
PRAESTO_TAG_EXP_ONLY_BUILTIN_TOOLS: frozenset[str] = frozenset(
    {
        "kb_change_history",
        "kb_draft",
        "kb_inspect",
        "kb_publish",
        "kb_scope",
        "team_knowledge_capture",
        "teams_group_fetch",
    }
)

# MCP servers exposed to the group turn. Deliberately empty: an MCP server is
# reached with the lending employee's agency credentials and, in the Teams
# case, could not be constrained to the conversation that asked.
PRAESTO_TAG_EXP_ALLOWED_MCP_SERVERS: frozenset[str] = frozenset()

# Experiment skills the group turn may load through the ``tools`` meta-tool.
# Loading a skill returns instructions, not capability — every tool a skill
# names is independently re-gated when it is actually called — so this borrows
# nothing beyond the whitelist above. It exists so the capture stage can hand
# off to the curation stage (and back) inside one turn instead of dead-ending at
# a saved snapshot. Kept explicit rather than introspecting the skill loader;
# a test asserts it stays in sync with the bundled ``praesto-tag-exp-only``
# skills, so adding one here is the only step needed.
PRAESTO_TAG_EXP_ALLOWED_SKILLS: frozenset[str] = frozenset(
    {
        "team-knowledge-capture",
        "team-knowledge-curate",
    }
)

# Built-ins that are safe to run without borrowing additional personal-agent
# permissions. ``tools`` is handled separately because it manages both local
# tools and MCP server connections.
_PRAESTO_TAG_EXP_BORROWED_TOOLS = frozenset(
    {
        "attachment_process",
        "group_memory",
        "kb_change_history",
        "kb_draft",
        "kb_inspect",
        "kb_publish",
        "kb_scope",
        "plan",
        "spawn",
        "tasks",
        "team_knowledge_capture",
        "teams_group_fetch",
    }
)

# Personal tools that must NOT surface in a borrowed-identity group turn: the
# shared employee persists facts via ``group_memory`` (the group's isolated local
# store), never the lending employee's private MEMORY.md / history. Canonical source shared by
# the loop (schema exclusion + prompt guidance) and the ``tools`` meta-tool (so
# it neither lists nor re-activates these behind the exclusion's back).
PRAESTO_TAG_EXP_PERSONAL_TOOLS: frozenset[str] = frozenset({"memory", "search_history"})

# Classification tokens returned to the gate.
PRAESTO_TAG_EXP_ALLOW = "allow"
PRAESTO_TAG_EXP_APPROVE = "approve"
PRAESTO_TAG_EXP_REJECT = "reject"


def praesto_tag_exp_is_active(metadata: dict[str, Any] | None) -> bool:
    """Whether the current turn is a praesto tag exp borrowed-identity turn."""
    return bool((metadata or {}).get(PRAESTO_TAG_EXP_METADATA_KEY))


def _mcp_server_and_raw(tool_name: str) -> tuple[str, str]:
    """Split an ``MCP_<server>_<tool>`` name into ``(server, raw_tool)`` lowered.

    Returns ``("", "")`` for non-MCP (built-in / host) tools.
    """
    if not tool_name or not tool_name.startswith("MCP_"):
        return "", ""
    rest = tool_name[len("MCP_") :]
    server, _, raw = rest.partition("_")
    return server.lower(), raw.lower()


def praesto_tag_exp_tool_is_exposed(tool_name: str) -> bool:
    """Whether a tool may be surfaced or invoked in a borrowed group turn."""
    if tool_name in PRAESTO_TAG_EXP_ALLOWED_BUILTIN_TOOLS:
        return True
    server, _ = _mcp_server_and_raw(tool_name)
    return bool(server) and server in PRAESTO_TAG_EXP_ALLOWED_MCP_SERVERS


def praesto_tag_exp_classify_capability(
    tool_name: str, args: dict[str, Any] | None, *, current_cid: str
) -> str:
    """Classify an exposed tool as allow/approve, or reject an unavailable tool.

    ``current_cid`` is the Teams conversation id of the group this turn came
    from (``metadata["cid"]``). Only the small exposed tool set can run at all.
    Conversation scoping is enforced inside ``teams_group_fetch``, which reads
    the cid from turn metadata rather than from model-supplied arguments — so
    there is nothing for this classifier to second-guess.
    """
    del current_cid  # scoping is structural, not argument-inspected
    args = args or {}
    if not praesto_tag_exp_tool_is_exposed(tool_name):
        return PRAESTO_TAG_EXP_REJECT

    # The group's own shared store is part of the default-borrow surface.
    if tool_name in _PRAESTO_TAG_EXP_BORROWED_TOOLS:
        return PRAESTO_TAG_EXP_ALLOW
    # The ``tools`` meta-tool only manages the LOCAL tool registry (list /
    # describe / enable / disable a built-in tool). That is not a borrowed action
    # — any tool it enables is independently re-gated when called. So don't spam
    # the employee with an approval just to inspect/enable a local tool (e.g. the
    # model poking at group_memory). No MCP server is exposed to this experiment,
    # so any MCP target is refused outright.
    if tool_name == "tools":
        target = str(args.get("name") or "").strip()
        if not target:
            return PRAESTO_TAG_EXP_ALLOW
        if target.startswith(_MCP_PREFIX_FOR_GATE):
            server, _ = _mcp_server_and_raw(target)
            if server and server in PRAESTO_TAG_EXP_ALLOWED_MCP_SERVERS:
                return PRAESTO_TAG_EXP_ALLOW
            return PRAESTO_TAG_EXP_REJECT
        if target in PRAESTO_TAG_EXP_ALLOWED_BUILTIN_TOOLS:
            return PRAESTO_TAG_EXP_ALLOW
        # Loading an experiment skill hands the model text, not permission.
        if target in PRAESTO_TAG_EXP_ALLOWED_SKILLS:
            return PRAESTO_TAG_EXP_ALLOW
        return PRAESTO_TAG_EXP_REJECT
    return PRAESTO_TAG_EXP_REJECT
