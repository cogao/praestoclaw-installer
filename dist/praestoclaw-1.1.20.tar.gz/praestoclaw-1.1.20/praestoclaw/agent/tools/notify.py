"""
Cross-channel notification tool — send messages to any active channel
via the async message bus.

The tool publishes an OutboundMessage to the MessageBus, which routes it
to the appropriate channel handler. Use '*' to broadcast to all channels.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.bus.events import OutboundMessage
from praestoclaw.bus.queue import MessageBus
from praestoclaw.config.schema import ChannelType
from praestoclaw.security.risk import RiskAssessment, RiskScore


class NotifyTool(Tool):
    """Send notifications to active channels through the message bus."""

    risk_range = (0, 0)

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=30)

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="Notification to user")

    def __init__(
        self,
        bus: MessageBus,
        active_channels_fn: Callable[[], list[ChannelType]] | None = None,
    ) -> None:
        self._bus = bus
        self._active_channels_fn = active_channels_fn or (lambda: [ChannelType.CLI])

    # ── Tool ABC ────────────────────────────────────────────────────────

    @property
    def name(self) -> str:
        return "notify"

    @property
    def description(self) -> str:
        return "Push a notification to the user via their active channel."

    @property
    def parameters(self) -> dict[str, Any]:
        channels = self._active_channels_fn()
        return {
            "type": "object",
            "properties": {
                "channel": {
                    "type": "string",
                    "enum": [*channels, "*"],
                    "description": (
                        "Target channel, or '*' for all active channels. "
                        "cloud: Teams bot & Web Chat via Cloud Gateway."
                    ),
                },
                "content": {
                    "type": "string",
                    "description": "Message content.",
                },
                "action_label": {
                    "type": "string",
                    "description": (
                        "Optional. With action_value, render an actionable card: a "
                        "button labelled action_label. Clicking it posts action_value "
                        "back as if the user typed it (lands in the user's own chat "
                        "turn). Use to hand the user a one-click action; omit for a "
                        "plain text notification. Cloud/Teams only."
                    ),
                },
                "action_value": {
                    "type": "string",
                    "description": (
                        "Optional. The text the button sends on click (e.g. a request "
                        "that starts a workflow). Pair with action_label; if either is "
                        "missing, a plain text notification is sent instead."
                    ),
                },
            },
            "required": ["channel", "content"],
        }

    async def execute(self, **kwargs: Any) -> str:
        channel: str = kwargs["channel"]  # from LLM tool call — may be "*" or a channel name
        content: str = kwargs["content"]
        # Registry injects _channel/_channel_id from the current conversation
        current_channel = ChannelType.of(kwargs.get("_channel", ""))
        current_channel_id: str = kwargs.get("_channel_id", "")

        if not content.strip():
            return "Error: message content cannot be empty."

        # Optional actionable card: with action_label + action_value, wrap the
        # message as an imBack card so the user can launch with one click. The
        # click posts action_value back as a normal inbound in the user's OWN
        # session (not this notifier's), so a cron/background job can hand off a
        # one-click launch without running anything in its restricted session.
        # Only the cloud/Teams surface renders the envelope, so gate on a single
        # cloud target — a plain channel or a '*' broadcast sends the plain `content`
        # text (WITHOUT the button/action_value; the one-click action is cloud-only)
        # rather than shipping a raw JSON envelope that CLI/web would show verbatim.
        action_label = str(kwargs.get("action_label") or "").strip()
        action_value = str(kwargs.get("action_value") or "").strip()
        if (
            action_label
            and action_value
            and channel != "*"
            and ChannelType.of(channel) == ChannelType.CLOUD
        ):
            import json

            from praestoclaw.channels.teams_cards import build_action_card, wrap_for_teams

            content = json.dumps(
                wrap_for_teams(build_action_card(content, action_label, action_value)),
                ensure_ascii=False,
            )

        # ``keep_context=True`` marks this as an intermediate side-emit.
        # ``notify`` is never the terminal response of the agent loop
        # (the loop's final assistant turn is); a notify emission must
        # NOT consume a pending synchronous waiter on the carrier
        # channel (e.g. an a2a_task carrier's /chatng response future)
        # or the carrier reply will be silently dropped and the original
        # sender will time out.
        #
        # As a side effect, ``CloudChannel.send()`` only promotes a
        # remembered Teams route to ``push_target="teams"`` when either
        # the carrier waiter is absent OR the emission is flagged
        # intermediate. Setting this flag is therefore also required
        # for a2a_task executor notifies to reach the local owner's
        # Teams surface instead of fan-out to webchat.
        #
        # ``notify_category`` is read by ``CloudChannel._classify_notify_category``
        # to decide whether the configured a2a executor-side filter
        # (``config.channels.a2a.executor_notify_filter``) should drop
        # this emission when it would otherwise land in the executor's
        # own Teams chat on an a2a_task carrier.
        msg_metadata: dict[str, Any] = {
            "keep_context": True,
            "notify_category": "notify_tool",
        }

        # Broadcast to all active channels
        if channel == "*":
            targets = self._active_channels_fn()
            if not targets:
                return "Error: no active channels."
            results: list[str] = []
            for ch in targets:
                try:
                    # Use real channel_id if notifying the current conversation's channel
                    cid = current_channel_id if ch == current_channel and current_channel_id else ch
                    await self._bus.publish_outbound(
                        OutboundMessage(
                            channel=ChannelType.of(ch),
                            channel_id=cid,
                            content=content,
                            metadata=dict(msg_metadata),
                        )
                    )
                    results.append(ch)
                except Exception as exc:
                    logger.error(f"Failed to notify '{ch}': {exc}")
            return f"Notified {len(results)} channels: {', '.join(results)}"

        # Single channel
        cid = current_channel_id if channel == current_channel and current_channel_id else channel
        try:
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=ChannelType.of(channel),
                    channel_id=cid,
                    content=content,
                    metadata=dict(msg_metadata),
                )
            )
            return f"Notified {channel}"
        except Exception as exc:
            logger.error(f"Failed to notify '{channel}': {exc}")
            return f"Error sending to {channel}: {exc}"
