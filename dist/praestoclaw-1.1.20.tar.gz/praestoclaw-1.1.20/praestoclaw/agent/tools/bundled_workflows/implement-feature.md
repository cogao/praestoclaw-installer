---
name: implement-feature
description: Implement a PraestoClaw feature end-to-end from a GitHub issue through a draft PR.
plan: true
metadata:
  # First-turn routing (loop_v2._match_workflow_recipe). These name the recipe's
  # SUBJECT, not execution intent. Whether the user is actually asking for the
  # work is judged by the model from the full turn, because the injected note is
  # neutral -- see loop_v2._recipe_route_block. Keywords alone never route; a
  # recipe opts in by declaring patterns. No \\b around the CJK alternatives:
  # Python treats CJK as word characters, so \\b实现 fails to match inside
  # '帮我实现'.
  activation:
    keywords:
    - implement feature
    - praestoclaw feature
    patterns:
    - "(?i)(?:implement|实现|开发)[^\\n]{0,20}(?:feature|功能|issue)"
    - "(?i)(?:feature|功能)[^\\n]{0,20}(?:issue|#\\d+)"
parameters:
- name: issue_number
  type: string
  required: true
- name: repo_path
  type: string
  required: false
concurrency:
  max_instances: 1
  key_parameters: [issue_number]
limits:
  allowed_tools:
    - shell
    - plan
    - tools
    # read_file / search_files are here for ITERATION cost, not capability: shell
    # can already do everything they do. Without them every file read is a
    # `sed -n 'A,Bp'` window, and a real run spent 67 of its 78 tool calls that
    # way — opening plan.py 32 separate times — then died at 91/90 turns before
    # writing any code. read_file returns all 2614 lines of that file in one
    # call; search_files returns matches with surrounding context, which answers
    # the producer check in a single call instead of grep-then-read.
    # Both assess deterministically as RiskScore(0) on workspace paths, so this
    # is strictly weaker than the `shell` already granted above.
    - read_file
    - search_files
  # NOTE: runtime is NOT the binding budget — agents.default.budget.max_iterations
  # (default 90) is, and a recipe cannot raise it. A real run on issue #672 used
  # 90/90 turns but only 1618s of the 3600s clamp. The Budget section in the body
  # is what actually protects the run.
  # Recipe upper bound. On-demand runs also clamp this to
  # execution.background_task_timeout_seconds (3600s by default);
  # scheduled runs use this value directly.
  max_runtime: 3600
  max_output: 20000
---
Implement PraestoClaw issue #{issue_number} end-to-end, from the issue through a
**draft pull request**.

Resolve the repository in this order and stop at the first one that yields a git
worktree. Record which source won and the command output that proved it:

1. The `repo_path` parameter: `{repo_path}` — use it when non-empty.
2. The current working directory, when `git rev-parse --show-toplevel` succeeds
   there. (Do not expect this to work: a workflow runs in an isolated session
   whose working directory is the agent's scratch workspace, not a checkout.)
3. **The running agent's own source tree.** This workflow's target is
   PraestoClaw itself, so the repository is discoverable from the installation
   that is executing this run:

   ```
   pkg=$(python -c 'import praestoclaw, pathlib; print(pathlib.Path(praestoclaw.__file__).resolve().parent)')
   git -C "$pkg" rev-parse --show-toplevel
   ```

   This is a resolution, not a guess — it reads where the running code actually
   lives. It correctly fails when PraestoClaw was installed from a wheel rather
   than an editable checkout, because then there is no worktree to work in.

Only if all three fail: do not guess a path and do not ask across turns — this
run cannot obtain the value. On the **first** turn that exhausts all three, mark
the **Pick up** item `blocked` with `plan(action='update', id='<the Pick up
item's id>', status='blocked', evidence=...)` — `id` is required; use the item
id exactly as it appears in the Plan, whether you supplied it or PlanTool
auto-generated it — carrying the exact command and output for **each** of the
three, then stop with a reply naming all three. Do not repeat the question on a
later turn.

This is an authorized internal development workflow on the team's own
repository.

## Execution guardrails

**Never push to `main`.** Every change goes on a feature branch and reaches
`main` only through a pull request. This is not negotiable and does not relax
because the repository belongs to the team.

**Never merge.** Merging is a human action. Create the PR and stop.

**Resolve values; never invent them.** Target branch, repository path, issue
content, test commands and check results are read from the repo or the issue.
If a value cannot be read, that is a blocker to record — not a gap to fill with
the most likely-looking value. A fabricated target branch has previously sent a
PR at the wrong base and swept hundreds of unrelated files into it.

**Do not repeat an identical command.** The loop detector warns on the third
identical tool call and terminates the run on the fourth. If you need to observe
something twice, change the command or wait for a different step.

**Stop after the PR exists.** Do not poll CI, do not wait for review comments,
do not loop. Driving the PR to green is a separate workflow that is not built
yet. Hand off and end the run.

**Never touch the resolved checkout.** All work happens in the separate worktree
created in step 1. Do not check out, pull, stash, or commit in the repository you
resolved — it is the running agent's own source tree.

## Budget

You have roughly **90 model turns** for the entire run, and the run is killed at
that point regardless of progress. That is the limit that binds: a real run on
issue #672 used 90/90 turns but only 1618s of its 3600s wall-clock allowance, and
spent every one of them on steps 1–4 without editing a single file.

Wall clock is looser but not free — that run still took 27 minutes, so do not
treat it as unlimited either.

Spend the turns roughly like this:

- steps 1–4 (orient, decide, locate): **≤ 25 turns**
- first substantive edit: by turn **30**
- steps 5–7 (implement, check, PR): the rest

**Where the budget actually goes: reading code.** A later run died at 91/90 turns
having spent 67 of its 78 tool calls on `sed -n 'A,Bp'` windows — it opened one
file 32 separate times. Use `read_file` (whole file, or `offset`/`limit`) and
`search_files` (matches *with* surrounding context) instead of shelling out to
`sed`, `nl` or `grep`. One `read_file` replaces a dozen windows.

Batch what shell work remains — but **not with `&&` or `;`**. This repository
forbids them: VS Code splits on `|`, `;` and `&&` *regardless of quoting* when
evaluating `chat.tools.terminal.autoApprove`, so a chained command breaks
auto-approve and forces a manual prompt that an unattended run cannot answer.
See `.github/copilot-instructions.md` §"Terminal command style" and the test
`test_directive_commands_avoid_vs_code_auto_approve_separators`.

Batch by sending one multi-line script as a single `shell` call instead — put
each command on its own line, as the recipe's own examples do.

You cannot see your own turn counter, so use a proxy you *can* count: **if you
have opened more than ~8 distinct files and step 4 is still not done, your slice
is too big — cut it down** rather than continuing to explore.

## Steps

Create the Plan first, with one item per step below, then work them in order.

### 1. Pick up

Resolve and record, each with the command that produced it:

- **Repository path** — the three-source order at the top of this workflow.
- **Repository slug** — `gh` infers the repo from the current directory's git
  remote, and this session's working directory is **not a checkout**, so every
  bare `gh` call would fail with "unable to determine repository". Resolve the
  slug once from the repository you just found:

  ```
  REPO_SLUG=$(gh repo view "$(git -C <repo> remote get-url origin)" --json nameWithOwner -q .nameWithOwner)
  ```

  Note `gh repo view` takes the repository as a **positional argument** — it has
  no `--repo` flag, unlike `gh issue view` / `gh pr create`, which take `-R` /
  `--repo`. Verified: the positional form returns `gim-home/PraestoClaw`;
  `gh repo view --repo <url>` fails with `unknown flag: --repo`.

  If this yields no slug, that is a blocker — do not proceed with a guess.
- **Target branch** — `gh repo view "$REPO_SLUG" --json defaultBranchRef -q .defaultBranchRef.name`
  (positional again). Do not assume `main` and do not assume `dev`. Whatever this
  returns is the PR base and the branch you start from. If the command fails,
  that is a blocker.
- **Issue** — `gh issue view {issue_number} --repo "$REPO_SLUG" --json number,title,body,labels,state,url`
  (this one *does* take `--repo`). If the issue is closed, stop and say so; do
  not implement a closed issue.
- **`gh` auth** — `gh auth status`, before any mutating `gh` command.

**Never switch the branch of the repository you resolved.** That checkout is the
running agent's own source tree — this very recipe is a file inside it. Checking
out another branch there rewrites the code under the live service and can delete
the recipe that is executing (observed: branching from the default branch removed
`implement-feature.md`, because it had not been merged yet, and the service could
no longer see the workflow at all).

Instead, work in a **separate git worktree**, which shares the repository but has
its own directory and its own branch:

```
BASE=<the default branch you read above>
WT=/tmp/pc-{issue_number}
git -C <repo> fetch origin "$BASE"
git -C <repo> worktree add "$WT" -b "feat/{issue_number}-<short-slug>" "origin/$BASE"
```

From here on, `$WT` is your working directory for every read, edit, check and
commit. The resolved repository is only used for `git -C <repo> worktree ...`.
This also removes any need to inspect or gate on the main checkout's cleanliness:
uncommitted work there cannot reach your branch.

Do not run `git add -A` — the worktree is fresh, but generated or ignored files
can still appear during checks. Stage only the files you edited, by explicit path.

Leave the worktree in place when you finish and report its path; do not remove it
and do not switch the main checkout.

The PR base must be the repository's default branch. This repository's CI only
triggers on the default and `release/**` branches, so a PR stacked on another
feature branch silently runs a fraction of the checks.

### 2. Requirement analysis

From the issue body and comments, write into the Plan item's evidence:

- the problem statement and the intended user- or system-visible outcome;
- explicit non-goals (many issues state these — copy them, do not re-derive);
- the acceptance criteria, one per line, each phrased so it can be checked;
- a **facts vs assumptions** split: what the issue actually says, versus what
  you are inferring. Label every inference as an assumption.

If the acceptance criteria are missing, mutually contradictory, or you had to
invent them, stop and ask — mark the item `blocked` with the specific ambiguity
and the two or more readings you are choosing between. Do not pick the most
convenient reading and proceed.

### 3. Plan the smallest slice

Most issues are larger than one PR. **Your job is not to implement the whole
issue.** Choose the smallest coherent slice that is independently reviewable and
leaves the repository working, then say plainly what you are deferring.

Hard bounds on the slice — if yours exceeds any of them, cut it down:

- **one layer**, not a sliver through every layer. For an issue spanning an
  agent, a transport and a UI, "the agent-side change plus its tests" is a good
  slice; a stub in each of the three is not.
- **one language / one package.** Do not span the Python workspace and the
  npm client in a first slice; their toolchains and test runners differ and
  each one costs turns.
- **at most ~3 source files plus one test file.**

Record only: the behaviour change, the chosen layer, the preliminary file list,
and what you are deferring. Do not write an implementation-steps essay — the
steps are the edits, and you are about to make them.

Stop and ask (mark the item `blocked` with the decision needed and the options)
only when even the smallest useful slice would require a material change to a
public contract, a storage or schema shape, a permission boundary, or a
dependency — or when it needs a product decision you cannot make from the issue.
A large issue by itself is not a reason to stop; it is a reason to narrow.

#### The deliverability test — apply before leaving this step

A slice is only small enough if it is still **deliverable**. Check all three; if
any fails, the slice is wrong and must be re-chosen, not merely noted as a
deferral.

1. **It can be proven by something you did not write.** The slice must admit at
   least one assertion whose input is *produced by the system*, not authored by
   you. Hand-written fixtures fed to your own new code prove only that it agrees
   with itself.

   This is the closest thing this workflow has to the bug-fix red→green rule, and
   it is the one check that cannot be satisfied by accident. If you cannot name
   such an assertion, you are building something with no observable effect.

2. **Both ends of any contract exist.** If your slice reads a field, event or
   message that something else is supposed to emit, confirm a real producer
   exists before choosing the slice.

   **Do not grep for the field name.** A bare key match answers "does this string
   appear somewhere", not "does anything emit this field into this payload", and
   it fails in the direction that hurts: searching `"plan"` in this repository
   returns 13 hits, every one of them a *tool name* in an unrelated test fixture.
   Acting on that count would have approved a slice whose field has no producer
   at all.

   Instead, **find where the payload itself is constructed, and read its
   fields.** Search for the payload's own discriminator — its type tag, class,
   or schema name — then open each hit:

   Call the `search_files` **tool** (not a shell command — there is no
   `search_files` binary) with `mode='content'`, which treats the pattern as a
   regex:

   ```
   pattern:  ['\"]?<key>['\"]?\s*:\s*['\"]<payload type>['\"]
   path:     <source root>
   ```

   **Keep the quoting optional.** Python writes `"type": "x"` or `'type': 'x'`;
   TypeScript object literals write a bare `type: 'x'`. Hardcoding double quotes
   is how this check has already failed twice: on this repository the strict form
   finds 2 sites where the pattern above finds 14, and the missing 12 would be
   reported as **"no producer"**.

   `search_files` returns each match with its surrounding lines, so one call both
   finds the construction sites and shows what they set — no follow-up read.

   Every construction site you find is a producer; read what each one actually
   puts in. If none of them sets your field, **there is no producer**, however
   many times the field name appears elsewhere. Then the slice must either
   include the producer, or be re-chosen as producer-first.

   Also check what gates each producer: a site that sets your field but only runs
   in a mode your feature never hits is not a producer for your purposes.

   A consumer with no producer passes every mechanical check and delivers
   nothing. Never assume a field exists because an issue describes it.

3. **Anything you claim already exists, you can cite.** If you are about to write
   that your slice builds on something "existing", you must have a `file:line`
   for it. No citation means it does not exist.

Record the answer to all three in the item's evidence, with the commands you ran.

### 4. Code understanding

Scoped to the slice you just chose — **not to the issue**. Find and record with
`file_path:line_number`:

- the code that directly controls the behaviour your slice changes;
- one neighbouring implementation you will copy as a pattern;
- the test file you will extend.

Use the `search_files` and `read_file` **tools** — they are tools, not shell
commands. Locate with `search_files`, then read with `read_file`. Do not page through a
file with `sed`; if you find yourself opening the same file a second time, read
it properly the first time.

Then state **one falsifiable hypothesis** about what the change must be, and run
**one cheap check** that could disprove it — record its real output. **Run that
check against a temporary directory or a throwaway data dir, never the live
one:** a previous run's check instantiated PlanTool directly and left two junk
plans in the production plan store.

That is the whole step. Do not map callers, transports or layers you are not
touching in this slice; that is what deferred means. A general tour of the
repository is not a substitute for locating the owning code path, but neither is
an exhaustive map a substitute for making the edit. If you cannot produce
`file:line` for the first item, you have not finished this step.

### 5. Implement

Make the smallest change that satisfies the slice from step 3, following the
patterns you recorded in step 4 and the repository's own instructions
(`CLAUDE.md`, `AGENTS.md`, contributing guides — read the ones that apply to the
directory you are editing).

**Discover the checks; do not assume a toolchain.** This repository is a uv
workspace of Python packages *and* an npm/Electron client, so the right command
depends on which directory you touched. Derive it from evidence —
`pyproject.toml`, `package.json` scripts, `Makefile`, `.github/workflows/*` —
and run only the gates that exist for the code you changed.

**Compiling is not shipping.** Some packages here commit their build output, and
the running service loads the committed artifact, not your source.

**Start from the build scripts, not from a guessed directory.** The output path
is whatever the script says, and it is not always inside the package — in this
repository `apps/client_gui` writes its bundle *into another package*:

```
grep -nE 'outDir|--out-dir|-o ' <package>/package.json      # or Makefile / pyproject
```

Take each output path you find, resolve it relative to the script's own
directory, and ask git whether it is committed:

```
git -C "$WT" ls-files <resolved output path> | head
```

If that lists files, regenerating them is **part of your change**, not a follow
up: run the script whose output path matches, and commit the result with your
source edits. Where a package has several build scripts pointing at different
directories, pick by output path, not by script name — a generic `npm run build`
that compiles to a scratch directory proves only that the code compiles.

Concretely in this repository: `apps/client_gui`'s `build:spa` script writes to
`../client_agent/praestoclaw/web/static/spa`, i.e.
`apps/client_agent/praestoclaw/web/static/spa/` — 23 committed files, and what
`/app/` serves. Looking for `apps/client_gui/dist` instead finds nothing and
would wrongly conclude there is no artifact to rebuild. Editing
`client_gui/src/` without rebuilding that path ships nothing, and no CI check
will catch it — CI here is Python-only.

Run the cheapest relevant check immediately after the first substantive edit,
then fix what your change broke and re-run it. Record the command, the exit
code, and the tail of the output.

**Scope the test run.** Running this repository's entire Python suite in one
process produces mass false failures that have nothing to do with your change.
Run the specific test files that cover your change. If you need a broader
signal, compare against the same command run on the base branch — never against
an assumption of what should pass.

Add or update focused tests when the change warrants it or the repository's
conventions require it. Do not repair unrelated failing tests or test
infrastructure; note them in the report and leave them.

Before pushing, run the repository's lint, format and type gates for the code
you changed and make them pass. Never bypass hooks with `--no-verify`.

### 6. Draft pull request

Commit and push from `$WT` (your worktree), not from the resolved checkout. Then
create the PR — `--repo` for the same reason as step 1, since you should not
rely on `gh` inferring the repository.

Build the body with a heredoc so it contains real newlines — a body assembled
with literal `\n` renders as one unreadable line:

````
gh pr create --draft --repo "$REPO_SLUG" --base "$BASE" --title "..." --body "$(cat <<'EOF'
### Summary
<one line: what this PR does>. Refs #{issue_number}.

### Scope
Implemented: <the slice from step 3>
Deferred: <what the issue asks for that this PR does not do, and why>

### Implementation
<why this is the smallest change that delivers the slice>

### Validation performed by agent
Command: `<command>`
Exit: <code>
```
<tail of output>
```

### Proof this change has an effect
<the assertion whose input the system produced, not a fixture you wrote — and,
if the package commits build output, the command that regenerated it>

### Not run
<every check that exists in this repo and was NOT run, and why>

### Manual validation required
<numbered steps, each with its expected result>

### Risks
- Blast radius: <files changed, who calls them>
- Reversibility: <how to undo>

### Human decisions
<each point where you stopped and asked, and the answer — or "none">
EOF
)"
````

The **Not run** section is mandatory and must be honest. If you ran one test
file, say that, and list the gates you skipped. Writing "all tests pass" when
you ran a subset is a false report, and it is worse than saying nothing.

Record the PR URL in the item's evidence. A local branch, a patch, or drafted PR
text is not a deliverable — only a real PR URL is.

### 7. Hand off

Mark the Plan complete and reply with:

- the PR URL and its draft status;
- the slice implemented and what was deferred;
- every check that ran, with its result, and every check that did not;
- what a human needs to do next.

Then stop. Do not poll CI, do not wait for comments, do not start another cycle.
