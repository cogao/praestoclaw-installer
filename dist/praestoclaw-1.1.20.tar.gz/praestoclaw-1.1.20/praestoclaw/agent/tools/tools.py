"""
Tools — unified tool discovery, inspection, and management.

Merges built-in tool activation (formerly tool_info) and MCP server
management (formerly mcp_connect) into a single entry point:

    tools()                                              → list all
    tools(name="browser")                                → inspect + enable built-in tool
    tools(name="git", action="disable")                  → disable built-in tool
    tools(name="MCP_icm")                                → connect MCP server
    tools(name="MCP_icm", action="describe")             → full MCP capabilities
    tools(name="MCP_icm", action="describe", query="incident") → filtered
    tools(name="MCP_icm", action="disable")              → disconnect MCP server
    tools(name="MCP_icm", action="status")               → server status
    tools(name="MCP_icm", action="resources", query="...") → read resource
    tools(name="MCP_icm", action="prompts", query="...", arguments={...}) → render prompt
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.praesto_tag_exp import (
    PRAESTO_TAG_EXP_ONLY_BUILTIN_TOOLS,
    PRAESTO_TAG_EXP_PERSONAL_TOOLS,
    praesto_tag_exp_is_active,
    praesto_tag_exp_tool_is_exposed,
)
from praestoclaw.security.risk import RiskAssessment, RiskScore

if TYPE_CHECKING:
    from praestoclaw.agent.tools.registry import ToolRegistry
    from praestoclaw.mcp.manager import MCPManager

_MCP_PREFIX = "MCP_"


class ToolsTool(Tool):
    """Unified tool discovery and management for built-in tools, skills, and MCP servers."""

    risk_range = (0, 0)

    def __init__(
        self,
        registry: ToolRegistry,
        mcp_manager: MCPManager | None = None,
        skill_loader: Any | None = None,
    ) -> None:
        self._registry = registry
        self._mcp = mcp_manager
        self._skill_loader = skill_loader  # SkillLoader (import deferred to avoid circular)

    def clone_for_registry(self, registry: ToolRegistry) -> ToolsTool:
        """Return a registry-bound copy without inheriting parent MCP access."""
        skill_loader = (
            self._skill_loader.with_tool_registry(registry) if self._skill_loader else None
        )
        return ToolsTool(registry=registry, skill_loader=skill_loader)

    @property
    def name(self) -> str:
        return "tools"

    @property
    def description(self) -> str:
        return (
            "Discover and enable tools. Inspect details, parameters, and MCP server capabilities."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": (
                        "Tool name or MCP server (prefix MCP_, e.g. 'MCP_icm'). Omit to list all."
                    ),
                },
                "action": {
                    "type": "string",
                    "enum": [
                        "enable",
                        "disable",
                        "describe",
                        "skill",
                        "status",
                        "resources",
                        "prompts",
                    ],
                    "description": (
                        "enable (default) = activate tool or connect MCP server; "
                        "disable = deactivate tool or disconnect MCP server; "
                        "describe = read-only inspection (no activation); "
                        "skill = load a skill's full instructions; "
                        "status = MCP server state; "
                        "resources = read an MCP resource by URI; "
                        "prompts = render an MCP prompt."
                    ),
                },
                "query": {
                    "type": "string",
                    "description": (
                        "Only for describe/resources/prompts. "
                        "Filter keyword, resource URI, or prompt name."
                    ),
                },
                "arguments": {
                    "type": "object",
                    "description": (
                        'enable: only for MCP_server(param) => {"param": "..."}. '
                        "prompts: prompt template arguments. "
                        "Ignored for other actions."
                    ),
                },
            },
            "required": [],
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=150, category="builtin")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="Internal tool management")

    async def execute(self, **kwargs: Any) -> str:
        name = kwargs.get("name", "").strip()
        action = kwargs.get("action", "").strip() or "enable"
        query = kwargs.get("query", "").strip()
        arguments = kwargs.get("arguments") or {}

        # Praesto group turns expose only the experiment's hard tool whitelist.
        # Mirror that restriction here so list/enable/skill/MCP paths cannot
        # rediscover capabilities removed from the function-calling schema.
        metadata = kwargs.get("_metadata") or {}
        praesto_tag_exp_active = praesto_tag_exp_is_active(metadata)
        hidden = (
            PRAESTO_TAG_EXP_PERSONAL_TOOLS
            if praesto_tag_exp_active
            else PRAESTO_TAG_EXP_ONLY_BUILTIN_TOOLS
        )

        # No name → list all
        if not name:
            return self._list_all(hidden=hidden, praesto_tag_exp_active=praesto_tag_exp_active)

        # MCP server path
        if name.startswith(_MCP_PREFIX):
            if praesto_tag_exp_active and not praesto_tag_exp_tool_is_exposed(name):
                server = name[len(_MCP_PREFIX) :]
                return f"MCP server '{server}' is not available in this shared group session."
            server = name[len(_MCP_PREFIX) :]
            return await self._handle_mcp(server, action, query, arguments)

        # Skill path (explicit action or fallback)
        if action == "skill":
            return self._handle_skill(name, praesto_tag_exp_active=praesto_tag_exp_active)

        # Group turn: an experiment skill name reaches _handle_skill even when
        # the model forgot action="skill", which would otherwise be refused by
        # the capability gate as an unexposed tool.
        if (
            praesto_tag_exp_active
            and self._registry.get(name) is None
            and self._skill_loader is not None
        ):
            skill = self._skill_loader.find_by_name(name)
            if skill is not None and skill.praesto_tag_exp_only:
                return self._handle_skill(name, praesto_tag_exp_active=True)

        # Built-in tool path (with skill fallback if tool not found)
        return await self._handle_builtin(
            name,
            action,
            hidden=hidden,
            praesto_tag_exp_active=praesto_tag_exp_active,
        )

    # ── Built-in tool handling ─────────────────────────────────────────

    # ── Skill handling ───────────────────────────────────────────────

    def _handle_skill(self, skill_name: str, *, praesto_tag_exp_active: bool = False) -> str:
        """Load a skill's full instructions by name from the SkillLoader.

        A borrowed-identity group turn may load the experiment's *own* skills
        (``praesto-tag-exp-only``) and nothing else. Those skills drive only the
        experiment's whitelisted tools, so loading one borrows no additional
        permission from the lending employee — whereas a general skill exists to
        drive the personal agent's shell / filesystem / MCP surface, which the
        gate removed from this turn.
        """
        group_refusal = f"Skill '{skill_name}' is not available in this shared group session."
        if not self._skill_loader:
            return group_refusal if praesto_tag_exp_active else "Skills are not configured."
        skill = self._skill_loader.find_by_name(skill_name)
        if skill is None:
            return group_refusal if praesto_tag_exp_active else f"Skill '{skill_name}' not found."
        if praesto_tag_exp_active and not skill.praesto_tag_exp_only:
            return group_refusal
        if skill.disable_model_invocation or self._skill_loader.is_disabled(skill_name):
            return f"Skill '{skill_name}' is not available."
        if skill.praesto_tag_exp_only and not praesto_tag_exp_active:
            return f"Skill '{skill_name}' is only available in a praesto tag exp group session."
        if not skill.is_platform_eligible():
            return f"Skill '{skill_name}' is not available on this platform."
        if skill.is_superseded(self._registry):
            return f"Skill '{skill_name}' is superseded by available tools."
        missing = skill.check_requirements(self._registry)
        if missing:
            return f"Skill '{skill_name}' is unavailable — missing: {', '.join(missing)}"
        return f"[Skill: {skill.name} | path: {skill.source_path}]\n\n{skill.content}"

    # ── Built-in tool handling ─────────────────────────────────────────

    async def _handle_builtin(
        self,
        tool_name: str,
        action: str,
        *,
        hidden: frozenset[str] = frozenset(),
        praesto_tag_exp_active: bool = False,
    ) -> str:
        if tool_name in PRAESTO_TAG_EXP_ONLY_BUILTIN_TOOLS and not praesto_tag_exp_active:
            return f"Tool '{tool_name}' is only available in a praesto tag exp group session."
        # praesto tag exp: refuse to surface/activate a hidden personal tool.
        if tool_name in hidden or (
            praesto_tag_exp_active and not praesto_tag_exp_tool_is_exposed(tool_name)
        ):
            return (
                f"Tool '{tool_name}' is not available in this shared group session. "
                "Use group_memory to save durable group facts."
            )
        tool = self._registry.get(tool_name)
        if tool is None:
            # Fallback: check if it's a skill (LLM forgot action="skill")
            if self._skill_loader:
                skill = self._skill_loader.find_by_name(tool_name)
                if (
                    skill
                    and not skill.disable_model_invocation
                    and not skill.praesto_tag_exp_only
                    and not self._skill_loader.is_disabled(tool_name)
                    and skill.is_platform_eligible()
                    and not skill.is_superseded(self._registry)
                    and not skill.check_requirements(self._registry)
                ):
                    return f"[Skill: {skill.name} | path: {skill.source_path}]\n\n{skill.content}"
            available = [t.name for t in self._registry.list_tools() if t.name not in hidden]
            return f"Unknown tool '{tool_name}'. Available: {', '.join(available)}"

        if action == "disable":
            ok = self._registry.deactivate(tool_name)
            if ok:
                return f"Disabled '{tool_name}'. Use tools(name='{tool_name}') to re-enable."
            return f"Cannot disable '{tool_name}' — core tools are always active."

        # describe → read-only inspection (no activation); enable → activate
        if action == "describe":
            import json

            return (
                f"Tool: {tool.name}\n"
                f"Description: {tool.description}\n\n"
                f"Parameters:\n{json.dumps(tool.parameters, indent=2)}"
            )

        # Anything that isn't enable/disable/describe is the model trying to
        # INVOKE the tool through this meta-tool (e.g. action='add' on
        # group_memory). tools() only manages tools — it does not run them.
        # Redirect so the model calls the tool directly (silently no-op'ing here
        # meant, e.g., a group_memory 'add' saved nothing).
        if action not in ("enable", ""):
            return (
                f"'{action}' is not a tools() action (tools() only enables, "
                f"disables, or describes tools — it never runs them). "
                f"'{tool_name}' is already available: call it DIRECTLY as a "
                f"top-level function, e.g. {tool_name}(action='{action}', ...)."
            )

        activated = self._registry.activate(tool_name)
        if activated:
            return f"Enabled '{tool_name}' — now available for function calling."
        return (
            f"'{tool_name}' is already active — call it DIRECTLY as a top-level "
            f"function (not through tools())."
        )

    # ── MCP server handling ────────────────────────────────────────────

    async def _handle_mcp(
        self, server: str, action: str, query: str, arguments: dict[str, Any]
    ) -> str:
        if self._mcp is None:
            return "MCP is not configured."

        match action:
            case "enable":
                # Connect + register tools (lightweight — no formatting/resources/prompts)
                result = await self._mcp.connect_server(
                    server,
                    auto_describe=False,
                    overrides=arguments or None,
                )
                info = self._mcp.get_server_status(server)
                if not info or info.state.value != "connected":
                    return result
                activated = self._mcp.activate_server_tools(server)
                count = len(activated)
                return f"Connected to MCP_{server} — {count} tool{'s' if count != 1 else ''} now available for function calling."
            case "disable":
                await self._mcp.disconnect_server(server)
                return f"Disconnected from MCP server '{server}'."
            case "describe":
                # Read-only inspection — no activation
                return await self._mcp.describe_server(server, keyword=query or None)
            case "status":
                return self._format_mcp_status(server)
            case "resources":
                if not query:
                    return await self._mcp.describe_server(server)
                return await self._mcp.read_resource(server, query)
            case "prompts":
                if not query:
                    return await self._mcp.describe_server(server)
                return await self._mcp.get_prompt(server, query, arguments)
            case _:
                return (
                    f"Unknown action '{action}'. "
                    "Use: enable, disable, describe, status, resources, prompts."
                )

    def _format_mcp_status(self, server: str) -> str:
        info = self._mcp.get_server_status(server)  # type: ignore[union-attr]
        if info is None:
            return f"Unknown MCP server '{server}'."
        parts = [
            f"Server: {info.name}",
            f"State: {info.state.value}",
            f"Agency: {'yes' if info.is_agency else 'no'}",
            f"Tools registered: {info.tool_count}",
        ]
        if info.protocol_version:
            parts.append(f"Protocol: {info.protocol_version}")
        if info.error:
            parts.append(f"Error: {info.error}")
        return "\n".join(parts)

    # ── List all ───────────────────────────────────────────────────────

    def _list_all(
        self,
        *,
        hidden: frozenset[str] = frozenset(),
        praesto_tag_exp_active: bool = False,
    ) -> str:
        lines: list[str] = []
        active_names = {t.name for t in self._registry.get_active_tools()}

        # Built-in tools grouped by tier, sorted by tier > name. ``hidden`` drops
        # personal tools that are excluded from a borrowed-identity group turn so
        # the model neither sees nor tries to re-enable them.
        builtin_tools = [
            t
            for t in self._registry.list_tools_sorted()
            if t.metadata.category != "mcp"
            and t.name not in hidden
            and (not praesto_tag_exp_active or praesto_tag_exp_tool_is_exposed(t.name))
        ]

        core = [t for t in builtin_tools if t.metadata.tier == "core"]
        standard = [t for t in builtin_tools if t.metadata.tier == "standard"]

        if core:
            lines.append("Core tools (always available):")
            for t in core:
                brief = t.description.split(".")[0]
                status = "[active]" if t.name in active_names else "[inactive]"
                lines.append(f"  {t.name:20s} {status:10s} — {brief}")

        if standard:
            if core:
                lines.append("")
            lines.append("Standard tools (use tools(name='<name>') to enable):")
            for t in standard:
                brief = t.description.split(".")[0]
                status = "[active]" if t.name in active_names else "[inactive]"
                lines.append(f"  {t.name:20s} {status:10s} — {brief}")

        # Skills (from SkillLoader — separate namespace). A borrowed-identity
        # group turn sees only the experiment's own skills; every general skill
        # stays behind the capability gate along with the tools it would drive.
        if self._skill_loader:
            if praesto_tag_exp_active:
                visible = [
                    s
                    for s in self._skill_loader.list_loaded()
                    if s.praesto_tag_exp_only
                    and s.mode == "available"
                    and not s.disable_model_invocation
                    and not self._skill_loader.is_disabled(s.name)
                    and s.is_platform_eligible()
                    and not s.is_superseded(self._registry)
                ]
            else:
                visible = self._skill_loader.get_model_visible()
            eligible = [s for s in visible if not s.check_requirements(self._registry)]
            if eligible:
                lines.append("")
                lines.append("Skills:")
                for s in eligible:
                    brief = (s.description or "").split(".")[0]
                    lines.append(f"  {s.name:20s} — {brief}")
                lines.append("")
                lines.append("Use tools(name='<skill>', action='skill') to load instructions.")

        # MCP servers with status
        if self._mcp:
            from praestoclaw.mcp.defaults import extract_params

            servers = self._mcp.list_servers()
            mcp_lines: list[str] = []
            for s in servers:
                if not s.enabled:
                    continue
                if praesto_tag_exp_active and not praesto_tag_exp_tool_is_exposed(
                    f"{_MCP_PREFIX}{s.name}"
                ):
                    continue
                state = s.state.value  # idle, connected, connecting, etc.
                desc = s.description or ""
                tools_info = f" ({s.tool_count} tools)" if s.tool_count > 0 else ""
                # Hint about required params for idle servers
                param_hint = ""
                if state == "idle":
                    cfg = self._mcp.get_server_config(s.name)
                    if cfg:
                        missing = extract_params(cfg.url, cfg.headers, cfg.env)
                        if missing:
                            param_hint = f" (needs: {', '.join(sorted(missing))})"
                mcp_lines.append(
                    f"  {_MCP_PREFIX}{s.name:16s} [{state}]{tools_info:14s} — {desc}{param_hint}"
                )
            if mcp_lines:
                lines.append("")
                lines.append("MCP servers:")
                lines.extend(mcp_lines)

        if not lines:
            return "No tools registered."

        lines.append("")
        lines.append("Use tools(name='<name>') to enable a tool or connect an MCP server.")
        return "\n".join(lines)
