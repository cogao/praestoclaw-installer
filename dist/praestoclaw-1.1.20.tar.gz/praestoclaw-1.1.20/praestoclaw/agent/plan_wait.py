"""Shared validation for the Plan tool's bounded wait action."""

from __future__ import annotations

from typing import Any

DEFAULT_PLAN_WAIT_SECONDS = 60
MAX_PLAN_WAIT_SECONDS = 300
PLAN_WAIT_SECONDS_PATTERN = r"^0*(?:[1-9]|[1-9][0-9]|[12][0-9]{2}|300)$"


def resolve_plan_wait_seconds(value: Any) -> int | None:
    """Resolve a valid Plan wait duration, including the default."""
    if value is None:
        return DEFAULT_PLAN_WAIT_SECONDS
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        seconds = value
    elif isinstance(value, str):
        if not value.isascii() or not value.isdigit():
            return None
        seconds = int(value)
    else:
        return None
    return seconds if 1 <= seconds <= MAX_PLAN_WAIT_SECONDS else None
