"""Shared tokens for deterministic workflow handoffs."""

SCANNER_SETUP_COMMAND = "setup workflow fix-societas-bug scanner"
