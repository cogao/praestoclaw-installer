"""Hidden task-planning preflight used to decide whether to show a plan card."""

from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass
from typing import Any

from loguru import logger

from praestoclaw.chronicle.textutil import extract_json
from praestoclaw.config.schema import ChannelType
from praestoclaw.providers.base import LLMProvider
from praestoclaw.utils.helpers import truncate_ellipsis

_TEAMS_PLAN_CARD_SOURCES: frozenset[str] = frozenset({"cloud_teams", "teams_bridge"})
_TASK_PREFLIGHT_CLASSIFICATIONS: frozenset[str] = frozenset(
    {"simple", "complex", "clarification", "no_execution"}
)
_TASK_PREFLIGHT_WS_RE = re.compile(r"\s+")
_TASK_PREFLIGHT_MAX_STEPS = 6
_TASK_PREFLIGHT_MAX_STEP_CHARS = 140
_TASK_PREFLIGHT_MAX_REASON_CHARS = 240
_TASK_PREFLIGHT_MAX_RESPONSE_TOKENS = 500
_TASK_PLANNING_PREFLIGHT_SYSTEM_PROMPT = (
    "You are a hidden task-planning preflight for an agent runtime. "
    "Plan the user's request privately before the main agent answers. "
    "Classify the request as one of: simple, complex, clarification, no_execution. "
    "Use complex when the work likely needs 3+ meaningful steps, multiple tools, "
    "a SOP/workflow, code changes plus verification, research plus synthesis, "
    "or long-running/background work. Use simple for 1-2 step tasks. Use "
    "clarification when the agent should ask a blocking question first. Use "
    "no_execution for pure explanations, casual chat, or when the user clearly "
    "asks not to execute. Return only a compact JSON object with this schema: "
    '{"classification":"simple|complex|clarification|no_execution",'
    '"steps":["short imperative step", "..."],'
    '"should_create_visible_plan":true|false,'
    '"reason":"short reason"}. '
    "Set should_create_visible_plan true only for complex tasks with concrete "
    "execution steps."
)


@dataclass(frozen=True)
class TaskPlanningPreflight:
    """Private planning classification for one user turn."""

    classification: str
    steps: tuple[str, ...] = ()
    should_create_visible_plan: bool = False
    reason: str = ""


def should_run_task_planning_preflight(
    *,
    channel: Any,
    channel_id: str | None,
    metadata: dict[str, Any] | None,
    plan_block: str,
    plan_tool_available: bool,
) -> bool:
    """Return True when a hidden plan-card preflight can affect Teams UX."""
    if bool((metadata or {}).get("praesto_tag_exp")):
        # Shared-group experiment turns are driven by their narrow injected
        # capture/curation skills. A generic plan such as "inspect → recommend →
        # report" can contradict the curation contract, which must continue to
        # a staged proposal when an update is warranted.
        logger.debug("event_loop.task_preflight skipped reason=praesto_tag_exp")
        return False
    if str((metadata or {}).get("workflow") or "").strip():
        logger.debug("event_loop.task_preflight skipped reason=workflow_session")
        return False
    if not plan_tool_available:
        logger.debug("event_loop.task_preflight skipped reason=no_plan_tool")
        return False
    if plan_block.strip():
        logger.debug("event_loop.task_preflight skipped reason=active_plan")
        return False
    channel_type = ChannelType.of(channel, default=None)
    if channel_type != ChannelType.CLOUD:
        logger.debug("event_loop.task_preflight skipped reason=channel channel={}", channel)
        return False
    if not channel_id:
        logger.debug("event_loop.task_preflight skipped reason=no_channel_id")
        return False
    source = str((metadata or {}).get("source") or "")
    if source not in _TEAMS_PLAN_CARD_SOURCES:
        logger.debug("event_loop.task_preflight skipped reason=source source={}", source)
        return False
    return True


async def run_task_planning_preflight(
    provider: LLMProvider,
    *,
    model: str,
    user_message: str,
    session_id: str,
    metadata: dict[str, Any] | None,
) -> TaskPlanningPreflight | None:
    """Ask the model to privately plan and classify the task.

    This is intentionally soft-fail: preflight must never block the
    user-visible task path if the provider is unavailable or returns prose.
    """
    source = str((metadata or {}).get("source") or "")
    preflight_user = (
        f"Session: {session_id}\n"
        f"Source: {source or 'unknown'}\n"
        "User task:\n"
        f"{truncate_ellipsis(user_message, 4000)}"
    )
    try:
        response = await provider.complete(
            model=model,
            messages=[
                {"role": "system", "content": _TASK_PLANNING_PREFLIGHT_SYSTEM_PROMPT},
                {"role": "user", "content": preflight_user},
            ],
            tools=None,
            max_tokens=_TASK_PREFLIGHT_MAX_RESPONSE_TOKENS,
            reasoning_effort="low",
        )
    except asyncio.CancelledError:
        raise
    except Exception as exc:  # noqa: BLE001
        logger.debug(
            "event_loop.task_preflight provider_error session={} error={}",
            session_id,
            exc,
        )
        return None

    result = parse_task_planning_preflight(response.content or "")
    if result is None:
        logger.debug(
            "event_loop.task_preflight parse_failed session={} response={}",
            session_id,
            truncate_ellipsis(response.content or "", 300),
        )
        return None
    logger.debug(
        "event_loop.task_preflight result session={} classification={} create={} steps_n={} reason={}",
        session_id,
        result.classification,
        result.should_create_visible_plan,
        len(result.steps),
        result.reason,
    )
    return result


def parse_task_planning_preflight(content: str) -> TaskPlanningPreflight | None:
    data = extract_json(content)
    if not isinstance(data, dict):
        return None

    classification = str(data.get("classification") or "simple").strip().lower()
    if classification not in _TASK_PREFLIGHT_CLASSIFICATIONS:
        classification = "simple"

    steps_raw = data.get("steps")
    steps: list[str] = []
    if isinstance(steps_raw, list):
        for raw in steps_raw:
            step = _clean_preflight_text(raw, _TASK_PREFLIGHT_MAX_STEP_CHARS)
            if not step:
                continue
            steps.append(step)
            if len(steps) >= _TASK_PREFLIGHT_MAX_STEPS:
                break

    should_create = bool(steps) and classification == "complex"
    if should_create:
        should_raw = data.get("should_create_visible_plan")
        should_create = should_raw if isinstance(should_raw, bool) else len(steps) >= 3

    reason = _clean_preflight_text(
        data.get("reason") or "",
        _TASK_PREFLIGHT_MAX_REASON_CHARS,
    )
    return TaskPlanningPreflight(
        classification=classification,
        steps=tuple(steps),
        should_create_visible_plan=should_create,
        reason=reason,
    )


def render_task_planning_preflight_context(
    preflight: TaskPlanningPreflight | None,
    *,
    visible_plan_created: bool,
) -> str:
    if preflight is None:
        return ""
    # Only deterministic, runtime-controlled signal is shared with the main
    # agent. The model-authored ``reason``/``steps`` are seeded from the raw
    # user task, so echoing them into a ``role: system`` message would let
    # user-influenced free text compete at system authority (prompt injection).
    # The created plan card already carries the steps for the user; when no
    # card is created the agent re-plans itself, so nothing is lost here.
    lines = [
        "[Task Planning Preflight - hidden runtime context]",
        f"Classification: {preflight.classification}",
        f"Visible plan card created: {'yes' if visible_plan_created else 'no'}",
    ]
    if visible_plan_created:
        lines.append(
            "A visible plan has already been created for this task. Do not call "
            "plan(action='create') again; use plan(update/report/checkpoint) as work advances."
        )
    elif preflight.should_create_visible_plan:
        lines.append(
            "The task is complex, but no visible plan was created automatically. "
            "Do not retry plan(action='create') solely because of this preflight; "
            "continue the task without exposing this hidden context."
        )
    else:
        lines.append(
            "Do not expose this preflight text. A visible plan card is not needed "
            "unless the task becomes complex during execution."
        )
    return "\n".join(lines)


def insert_task_planning_preflight_context(
    messages: list[dict[str, Any]],
    context: str,
    *,
    after_plan_block: bool,
) -> None:
    insert_at = 2 if after_plan_block and len(messages) > 1 else min(1, len(messages))
    messages.insert(insert_at, {"role": "system", "content": context})


def _clean_preflight_text(value: Any, max_chars: int) -> str:
    text = _TASK_PREFLIGHT_WS_RE.sub(" ", str(value or "")).strip()
    if not text:
        return ""
    return truncate_ellipsis(text, max_chars)
