"""Direct chatsvc client — the messaging API Teams Web itself uses.

Endpoint shape (discovered by recording Teams Web's own traffic; every part of
the obvious guess was wrong)::

    GET https://teams.cloud.microsoft/api/chatsvc/{region}/v1/users/ME/
        conversations/{conversationId}/messages
        ?view=msnp24Equivalent|supportsMessageProperties&pageSize=200
    Authorization:    Bearer <ic3.teams.office.com token>
    behavioroverride: redirectAs404
    x-ms-migration:   True
    clientinfo:       os=windows; ...; clientName=skypeteams; ...

Versus Graph (which the Teams MCP wraps) this returns the *system* events too —
``ThreadActivity/TopicUpdate`` (rename history), ``RichText/Media_CallRecording``
(the transcript pointer), ``Event/Call`` (call boundaries). Graph filters all of
those out, which is precisely why the transcript could not be found through it.

Two error codes matter:

* ``911`` — authentication failed. Either the wrong credential or, far more
  often, an ic3 token that expired between being read and being used.
* ``752`` — "User is in a different cloud". This is an *authorisation success*
  with a routing failure: right token, wrong region. It is what makes region
  discovery possible without guessing blindly.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any
from urllib.parse import quote

import httpx
from loguru import logger

CHATSVC_HOST = "https://teams.cloud.microsoft"
MESSAGE_VIEW = "msnp24Equivalent|supportsMessageProperties"
CLIENT_INFO = (
    "os=windows; osVer=NT 10.0; proc=x86; lcid=en-us; deviceType=1; "
    "country=us; clientName=skypeteams; clientVer=1415/2607260"
)

# Ordered candidates for region discovery. The pilot rings are listed next to
# their base ring because Teams Web was observed using both in one session.
DEFAULT_REGION_CANDIDATES: tuple[str, ...] = (
    "apac-pilot1",
    "apac",
    "amer-pilot1",
    "amer",
    "emea-pilot1",
    "emea",
)

_WRONG_CLOUD_ERROR_CODE = 752
_AUTH_FAILED_ERROR_CODE = 911

DEFAULT_PAGE_SIZE = 200
DEFAULT_MAX_PAGES = 20


class ChatsvcError(Exception):
    """A chatsvc call failed in a way the caller must surface."""


class ChatsvcAuthError(ChatsvcError):
    """The ic3 credential was rejected — re-acquire and retry once."""


@dataclass(slots=True)
class ChatsvcFetchResult:
    """Everything one message pull produced."""

    conversation_id: str
    region: str
    raw_pages: list[dict[str, Any]] = field(default_factory=list)
    messages: list[dict[str, Any]] = field(default_factory=list)
    pages_fetched: int = 0
    reached_start: bool = False
    foreign_messages_dropped: int = 0


def message_time(message: dict[str, Any]) -> str:
    return str(message.get("originalarrivaltime") or message.get("composetime") or "")


# chatsvc emits 7 fractional digits (".5780000"); ``fromisoformat`` accepts at
# most 6. Splitting on "." alone is not enough — the remainder also carries the
# UTC offset, and a naive "strip everything that is not a digit" pass swallows
# the offset's digits too, silently producing a *naive* datetime that is then
# misread as local time.
_FRACTION_RE = re.compile(r"^(?P<head>.*T\d{2}:\d{2}:\d{2})\.(?P<frac>\d+)(?P<rest>.*)$")


def parse_message_time(value: str) -> datetime | None:
    """Parse a chatsvc timestamp into an aware UTC datetime, or None.

    Always returns an aware value: chatsvc timestamps are UTC, and a naive one
    leaking out compares unequal-and-unorderable against every other timestamp
    in this package.
    """
    text = (value or "").strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    match = _FRACTION_RE.match(text)
    if match:
        text = f"{match['head']}.{match['frac'][:6]}{match['rest']}"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)


class TeamsChatsvcClient:
    """Pull messages for exactly one conversation.

    The conversation id is fixed at construction time. There is deliberately no
    method that searches, enumerates chats, or reaches outside it.
    """

    def __init__(
        self,
        conversation_id: str,
        *,
        access_token: str,
        region: str = "",
        timeout: float = 30.0,
    ) -> None:
        conversation_id = (conversation_id or "").strip()
        if not conversation_id:
            raise ValueError("TeamsChatsvcClient requires a conversation id")
        self._cid = conversation_id
        self._token = access_token
        self._region = (region or "").strip()
        self._timeout = timeout

    @property
    def region(self) -> str:
        return self._region

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._token}",
            "Accept": "application/json",
            "behavioroverride": "redirectAs404",
            "x-ms-migration": "True",
            "clientinfo": CLIENT_INFO,
        }

    def _messages_url(self, region: str, *, page_size: int, start_time_ms: int | None) -> str:
        cid = quote(self._cid, safe="")
        url = (
            f"{CHATSVC_HOST}/api/chatsvc/{region}/v1/users/ME/conversations/{cid}/messages"
            f"?view={quote(MESSAGE_VIEW, safe='|')}&pageSize={page_size}"
        )
        if start_time_ms is not None:
            url += f"&startTime={start_time_ms}"
        return url

    async def fetch_messages(
        self,
        *,
        since: datetime | None = None,
        max_pages: int = DEFAULT_MAX_PAGES,
        page_size: int = DEFAULT_PAGE_SIZE,
        region_candidates: tuple[str, ...] = DEFAULT_REGION_CANDIDATES,
    ) -> ChatsvcFetchResult:
        """Page backwards through the conversation until *since* is crossed."""
        async with httpx.AsyncClient(timeout=self._timeout, follow_redirects=False) as client:
            region = self._region or await self._discover_region(
                client, region_candidates, page_size=page_size
            )
            self._region = region

            result = ChatsvcFetchResult(conversation_id=self._cid, region=region)
            url: str | None = self._messages_url(region, page_size=page_size, start_time_ms=None)
            seen: set[str] = set()

            while url and result.pages_fetched < max_pages:
                body = await self._get_json(client, url)
                result.raw_pages.append(body)
                result.pages_fetched += 1

                page_messages = [m for m in (body.get("messages") or []) if isinstance(m, dict)]
                for message in page_messages:
                    # Hard cid scoping: chatsvc is already per-conversation, but a
                    # cached/replayed page must never smuggle another chat in.
                    message_cid = str(message.get("conversationid") or "").strip()
                    if message_cid and message_cid != self._cid:
                        result.foreign_messages_dropped += 1
                        continue
                    message_id = str(message.get("id") or "")
                    if message_id and message_id in seen:
                        continue
                    if message_id:
                        seen.add(message_id)
                    result.messages.append(message)

                if since is not None and page_messages:
                    oldest = min(
                        (
                            t
                            for t in (parse_message_time(message_time(m)) for m in page_messages)
                            if t
                        ),
                        default=None,
                    )
                    if oldest is not None and oldest <= since:
                        result.reached_start = True
                        break

                url = (body.get("_metadata") or {}).get("backwardLink") or body.get("nextLink")

            result.messages.sort(key=message_time)
            if since is not None:
                result.messages = [
                    m
                    for m in result.messages
                    if (parsed := parse_message_time(message_time(m))) is None or parsed >= since
                ]
            if result.foreign_messages_dropped:
                logger.warning(
                    "[teams_web] dropped {} message(s) not belonging to cid={}",
                    result.foreign_messages_dropped,
                    self._cid,
                )
            return result

    async def _discover_region(
        self,
        client: httpx.AsyncClient,
        candidates: tuple[str, ...],
        *,
        page_size: int,
    ) -> str:
        """Find the ring that serves this user, using 752 as the negative signal."""
        errors: list[str] = []
        for candidate in candidates:
            url = self._messages_url(candidate, page_size=1, start_time_ms=None)
            try:
                response = await client.get(url, headers=self._headers())
            except httpx.HTTPError as exc:
                errors.append(f"{candidate}: {exc}")
                continue
            if response.status_code == 200:
                logger.info("[teams_web] chatsvc region resolved to {}", candidate)
                return candidate
            code = _error_code(response)
            if code == _AUTH_FAILED_ERROR_CODE:
                raise ChatsvcAuthError(
                    "chatsvc rejected the ic3 token (errorCode 911); it is expired or wrong."
                )
            errors.append(f"{candidate}: HTTP {response.status_code} errorCode={code}")
        del page_size  # discovery always probes with pageSize=1
        raise ChatsvcError(
            "Could not determine the chatsvc region for this conversation. Tried: "
            + "; ".join(errors)
        )

    async def _get_json(self, client: httpx.AsyncClient, url: str) -> dict[str, Any]:
        try:
            response = await client.get(url, headers=self._headers())
        except httpx.HTTPError as exc:
            raise ChatsvcError(f"chatsvc request failed: {exc}") from exc
        if response.status_code == 200:
            try:
                body = response.json()
            except ValueError as exc:
                raise ChatsvcError("chatsvc returned a non-JSON body") from exc
            return body if isinstance(body, dict) else {}
        code = _error_code(response)
        if code == _AUTH_FAILED_ERROR_CODE or response.status_code == 401:
            raise ChatsvcAuthError(
                "chatsvc rejected the ic3 token (errorCode 911); it is expired or wrong."
            )
        raise ChatsvcError(
            f"chatsvc HTTP {response.status_code} errorCode={code}: {response.text[:300]}"
        )


def _error_code(response: httpx.Response) -> int | None:
    try:
        body = response.json()
    except ValueError:
        return None
    if not isinstance(body, dict):
        return None
    code = body.get("errorCode")
    if isinstance(code, int):
        return code
    inner = body.get("errorDetails") or body.get("error")
    if isinstance(inner, dict) and isinstance(inner.get("code"), int):
        return int(inner["code"])
    return None


def build_message_digest(conversation_id: str, messages: list[dict[str, Any]]) -> dict[str, Any]:
    """Summarise a pull without dumping every body into the model's context."""
    types = Counter(str(m.get("messagetype") or "unknown") for m in messages)
    senders = Counter(
        str(m.get("imdisplayname") or m.get("fromDisplayNameInToken") or "").strip()
        for m in messages
        if (m.get("imdisplayname") or m.get("fromDisplayNameInToken"))
    )
    times = [t for t in (message_time(m) for m in messages) if t]
    return {
        "conversation_id": conversation_id,
        "message_count": len(messages),
        "message_types": dict(types.most_common()),
        "participants": dict(senders.most_common()),
        "first_message_at": min(times) if times else None,
        "last_message_at": max(times) if times else None,
        "topic_history": extract_topic_history(messages),
        "call_events": extract_call_events(messages),
    }


def extract_topic_history(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Rename history, straight out of ``ThreadActivity/TopicUpdate`` events.

    Ground truth: no model inference needed to bridge an old title to a new one.
    """
    history: list[dict[str, Any]] = []
    for message in messages:
        if str(message.get("messagetype") or "") != "ThreadActivity/TopicUpdate":
            continue
        content = str(message.get("content") or "")
        value = re.search(r"<value>(.*?)</value>", content, re.DOTALL)
        event_time = re.search(r"<eventtime>(\d+)</eventtime>", content)
        initiator = re.search(r"<initiator>(.*?)</initiator>", content, re.DOTALL)
        history.append(
            {
                "topic": value.group(1).strip() if value else None,
                "event_time_ms": int(event_time.group(1)) if event_time else None,
                "at": message_time(message),
                "initiator": initiator.group(1).strip() if initiator else None,
            }
        )
    history.sort(key=lambda item: item.get("event_time_ms") or 0)
    return history


def extract_call_events(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Call boundaries, roster and meeting details from ``Event/Call`` messages.

    These carry the participant list with per-person durations and the
    organizer/iCalUid — the closest thing to attendance ground truth available
    without the calendar event, which for a deleted meeting no longer exists.
    """

    def _tag(pattern: str, text: str) -> str | None:
        found = re.search(pattern, text, re.DOTALL)
        return found.group(1).strip() if found else None

    events: list[dict[str, Any]] = []
    for message in messages:
        if str(message.get("messagetype") or "") != "Event/Call":
            continue
        content = str(message.get("content") or "")
        participants = [
            {
                "id": part.group(1),
                "display_name": (_tag(r"<displayName>(.*?)</displayName>", part.group(2)) or ""),
                "duration_s": int(_tag(r"<duration>(\d+)</duration>", part.group(2)) or 0),
            }
            for part in re.finditer(r'<part identity="([^"]*)">(.*?)</part>', content, re.DOTALL)
        ]
        events.append(
            {
                "at": message_time(message),
                "event": _tag(r"<callEventType>(.*?)</callEventType>", content),
                "call_id": _tag(r"<callId>(.*?)</callId>", content),
                "conversation_start_time": _tag(
                    r"<conversationStartTime>(.*?)</conversationStartTime>", content
                ),
                "organizer_upn": _tag(r"<organizerUpn>(.*?)</organizerUpn>", content),
                "meeting_start_time": _tag(r"<startTime>(.*?)</startTime>", content),
                "meeting_end_time": _tag(r"<endTime>(.*?)</endTime>", content),
                "ical_uid": _tag(r"<iCalUid>(.*?)</iCalUid>", content),
                "participants": participants,
            }
        )
    return events


def summarize_message(message: dict[str, Any], *, body_limit: int = 4000) -> dict[str, Any]:
    """Project one raw message down to the fields worth putting in context."""
    content = str(message.get("content") or "")
    truncated = len(content) > body_limit
    raw_properties = message.get("properties")
    properties: dict[str, Any] = raw_properties if isinstance(raw_properties, dict) else {}
    return {
        "id": message.get("id"),
        "time": message_time(message),
        "from": message.get("imdisplayname") or message.get("fromDisplayNameInToken"),
        "from_id": message.get("from"),
        "type": message.get("messagetype"),
        "content": content[:body_limit],
        "content_truncated": truncated,
        "content_full_length": len(content),
        "links": _decode_property(properties.get("links")),
        "mentions": _decode_property(properties.get("mentions")),
        "files": _decode_property(properties.get("files")),
    }


def _decode_property(value: Any) -> Any:
    """chatsvc nests JSON inside ``properties`` as strings; decode when possible."""
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        decoded = json.loads(value)
    except json.JSONDecodeError:
        return value
    return decoded or None
