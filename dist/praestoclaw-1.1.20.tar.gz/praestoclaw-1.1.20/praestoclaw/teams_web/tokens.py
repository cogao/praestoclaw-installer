"""ic3 access-token acquisition for the Teams Web capture chain.

The chatsvc messaging API and the AMS transcript view both authenticate with
the *same* credential: the ``https://ic3.teams.office.com`` access token that a
logged-in Teams Web session keeps in ``localStorage`` (scope
``Teams.AccessAsUser.All``, Teams Web first-party client). It is **not** the
``chatsvcagg`` token and it is not a Graph token — Graph has no chat scopes on
this session at all.

Design constraints learned the hard way (see
``D:\\tmp\\pc-kb-dev\\2026-07-28-deterministic-transcript-and-chat-capture.md``):

* Access tokens live 65–94 min; the browser renews them silently in ~10s from
  the SSO cookie. The binding constraint is the ~24h refresh-token session, not
  the access token.
* A **stale** token is still sitting in ``localStorage`` when the page loads and
  renewal only completes a few seconds later. Taking the first match yields
  ``401 errorCode 911`` — indistinguishable from using the wrong credential.
  So: reject expired entries, prefer the greatest ``exp`` when several share an
  audience, and poll for a while to let MSAL finish renewing.

We cache the token on disk (encrypted at rest, in the private auth dir) with its
issue/expiry timestamps so a group turn does not have to start a browser on
every call. Once the timestamp lapses we start Edge again and re-read it.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import os
import threading
import time
from dataclasses import dataclass
from pathlib import Path

from loguru import logger

from praestoclaw.security.secrets import (
    _atomic_write_file,
    decrypt_at_rest,
    encrypt_at_rest,
)

IC3_AUDIENCE = "ic3.teams.office.com"
TEAMS_URL = "https://teams.microsoft.com"
TOKEN_CACHE_FILENAME = "teams_web_tokens.bin"
CACHE_VERSION = 1

# Treat a token as unusable this long before its real expiry so a capture that
# takes a couple of minutes cannot expire mid-flight.
DEFAULT_SKEW_S = 300

# How long to wait for MSAL's silent renewal after the page loads.
_RENEWAL_POLL_ATTEMPTS = 40
_RENEWAL_POLL_INTERVAL_S = 2.0

# Default browser profile: the one the capture investigation validated, shared
# with the biz-table ``minutes`` skill. Overridable via config.
DEFAULT_PROFILE_DIR = Path.home() / ".playwright" / "teams-graph"

_EDGE_STARTUP_TIMEOUT_S = 20


class TeamsWebTokenError(Exception):
    """No usable Teams Web credential could be produced."""


# Runs *inside* the page. Returns only the token plus its expiry — never dumps
# the whole localStorage, so unrelated credentials stay in the browser.
_TOKEN_PICK_JS = """(audience) => {
  const now = Math.floor(Date.now() / 1000);
  const candidates = [];
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (!key || !key.toLowerCase().includes('accesstoken')) continue;
    let entry;
    try { entry = JSON.parse(localStorage.getItem(key)); } catch { continue; }
    if (!entry || !entry.secret) continue;
    if (!String(entry.target || '').includes(audience)) continue;
    let exp = null;
    try {
      let payload = String(entry.secret).split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
      while (payload.length % 4) payload += '=';
      exp = JSON.parse(atob(payload)).exp;
    } catch { /* fall through to expiresOn */ }
    if (!exp && entry.expiresOn) exp = parseInt(entry.expiresOn, 10);
    if (!exp) continue;
    candidates.push({secret: entry.secret, expiresAt: exp, secondsLeft: exp - now});
  }
  candidates.sort((a, b) => b.expiresAt - a.expiresAt);
  return candidates[0] || null;
}"""


@dataclass(frozen=True, slots=True)
class CachedTeamsWebToken:
    """One audience-scoped bearer plus the timestamps that bound its life."""

    secret: str
    acquired_at: float
    expires_at: float

    def is_fresh(self, *, skew_s: int = DEFAULT_SKEW_S) -> bool:
        return time.time() < self.expires_at - skew_s

    def seconds_left(self) -> int:
        return int(self.expires_at - time.time())


class TeamsWebTokenCache:
    """Encrypted, file-backed store of audience → bearer + timestamps."""

    def __init__(self, path: Path) -> None:
        self._path = path
        self._lock = threading.Lock()
        self._tokens: dict[str, CachedTeamsWebToken] = {}
        self._loaded = False

    @property
    def path(self) -> Path:
        return self._path

    def load(self) -> None:
        with self._lock:
            if self._loaded:
                return
            self._loaded = True
            if not self._path.exists():
                return
            try:
                raw = self._path.read_bytes()
            except OSError as exc:
                logger.debug("[teams_web] token cache read failed: {}", exc)
                return
            decrypted = decrypt_at_rest(raw)
            if not decrypted:
                return
            try:
                doc = json.loads(decrypted.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                logger.warning("[teams_web] token cache parse failed ({}); discarding", exc)
                return
            if not isinstance(doc, dict) or doc.get("version") != CACHE_VERSION:
                return
            for audience, value in (doc.get("tokens") or {}).items():
                if not isinstance(value, dict):
                    continue
                secret = value.get("secret")
                expires_at = value.get("expires_at")
                if not isinstance(secret, str) or not isinstance(expires_at, (int, float)):
                    continue
                self._tokens[str(audience)] = CachedTeamsWebToken(
                    secret=secret,
                    acquired_at=float(value.get("acquired_at") or 0.0),
                    expires_at=float(expires_at),
                )

    def get(self, audience: str, *, skew_s: int = DEFAULT_SKEW_S) -> CachedTeamsWebToken | None:
        self.load()
        with self._lock:
            cached = self._tokens.get(audience)
        if cached and cached.is_fresh(skew_s=skew_s):
            return cached
        return None

    def put(self, audience: str, token: CachedTeamsWebToken) -> None:
        self.load()
        with self._lock:
            self._tokens[audience] = token
        self._persist()

    def clear(self, audience: str | None = None) -> None:
        self.load()
        with self._lock:
            if audience is None:
                self._tokens.clear()
            else:
                self._tokens.pop(audience, None)
        self._persist()

    def _persist(self) -> None:
        with self._lock:
            doc = {
                "version": CACHE_VERSION,
                "tokens": {
                    audience: {
                        "secret": token.secret,
                        "acquired_at": token.acquired_at,
                        "expires_at": token.expires_at,
                    }
                    for audience, token in self._tokens.items()
                },
            }
        try:
            payload = json.dumps(doc, ensure_ascii=False).encode("utf-8")
            _atomic_write_file(self._path, encrypt_at_rest(payload, strict=True))
        except OSError as exc:
            logger.warning("[teams_web] token cache persist failed: {}", exc)


class TeamsWebTokenProvider:
    """Serve a fresh ic3 bearer, re-acquiring through Edge when the cache lapses.

    *profile_dir* is a persistent Edge profile that has already completed an
    interactive Teams sign-in. Nothing here can create that session silently —
    when the SSO session itself has died the caller gets
    :class:`TeamsWebTokenError` with instructions rather than a surprise browser
    window in the middle of someone's group chat, unless *allow_headed_login*
    is enabled.
    """

    def __init__(
        self,
        *,
        cache_path: Path,
        profile_dir: Path | None = None,
        allow_headed_login: bool = False,
        login_timeout_s: int = 180,
        skew_s: int = DEFAULT_SKEW_S,
    ) -> None:
        self._cache = TeamsWebTokenCache(cache_path)
        self._profile_dir = Path(profile_dir) if profile_dir else DEFAULT_PROFILE_DIR
        self._allow_headed_login = allow_headed_login
        self._login_timeout_s = login_timeout_s
        self._skew_s = skew_s
        self._lock = asyncio.Lock()

    @property
    def profile_dir(self) -> Path:
        return self._profile_dir

    @property
    def cache_path(self) -> Path:
        return self._cache.path

    def peek(self, audience: str = IC3_AUDIENCE) -> CachedTeamsWebToken | None:
        """Return the cached token when still fresh. Never launches anything."""
        return self._cache.get(audience, skew_s=self._skew_s)

    async def get_token(
        self, audience: str = IC3_AUDIENCE, *, force_refresh: bool = False
    ) -> CachedTeamsWebToken:
        """Return a usable bearer for *audience*, re-acquiring when stale."""
        async with self._lock:
            if not force_refresh:
                cached = self._cache.get(audience, skew_s=self._skew_s)
                if cached is not None:
                    logger.debug(
                        "[teams_web] token cache hit audience={} left={}s",
                        audience,
                        cached.seconds_left(),
                    )
                    return cached

            token = await self._acquire_via_browser(audience, headless=True)
            if token is None and self._allow_headed_login:
                logger.info("[teams_web] headless acquisition failed; retrying with a window")
                token = await self._acquire_via_browser(audience, headless=False)
            if token is None:
                raise TeamsWebTokenError(
                    f"No valid {audience} token in the Teams Web profile at "
                    f"{self._profile_dir}. The browser session has expired — sign in to "
                    "Teams once in that profile to restore it."
                )
            self._cache.put(audience, token)
            logger.info(
                "[teams_web] acquired {} token, valid for {}s",
                audience,
                token.seconds_left(),
            )
            return token

    async def _acquire_via_browser(
        self, audience: str, *, headless: bool
    ) -> CachedTeamsWebToken | None:
        """Start Edge on the persistent profile and read the freshest token out."""
        # Reuse the m365 auth path's Edge discovery/attach helpers: on managed
        # Windows boxes, Playwright's own launch_persistent_context trips EDR,
        # whereas subprocess + connect_over_cdp looks like a user-run browser.
        from praestoclaw.auth.m365.playwright_session import (
            _find_edge_binary,
            _kill,
            _pick_free_port,
            _wait_for_cdp_ready,
        )

        os.environ.setdefault("NODE_NO_WARNINGS", "1")
        try:
            from playwright.async_api import async_playwright
        except ImportError as exc:  # pragma: no cover - dependency is declared
            raise TeamsWebTokenError("playwright is not installed") from exc

        edge_binary = _find_edge_binary()
        if edge_binary is None:
            raise TeamsWebTokenError(
                "Microsoft Edge was not found; the Teams Web capture chain needs it."
            )

        self._profile_dir.mkdir(parents=True, exist_ok=True)
        port = _pick_free_port(9223)
        argv = [
            edge_binary,
            f"--remote-debugging-port={port}",
            f"--user-data-dir={self._profile_dir}",
            "--no-first-run",
            "--no-default-browser-check",
        ]
        if headless:
            argv.append("--headless=new")
        argv.append(TEAMS_URL)

        import subprocess

        logger.info(
            "[teams_web] launching Edge (headless={} port={} profile={})",
            headless,
            port,
            self._profile_dir,
        )
        proc = subprocess.Popen(  # noqa: S603 — resolved binary, fixed argv
            argv, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        try:
            if not _wait_for_cdp_ready(port, _EDGE_STARTUP_TIMEOUT_S):
                logger.warning("[teams_web] Edge CDP endpoint not ready on port {}", port)
                return None
            async with async_playwright() as pw:
                browser = await pw.chromium.connect_over_cdp(
                    f"http://127.0.0.1:{port}", timeout=30_000
                )
                try:
                    ctx = browser.contexts[0] if browser.contexts else None
                    if ctx is None:
                        return None
                    page = ctx.pages[0] if ctx.pages else await ctx.new_page()
                    if "teams" not in page.url.lower():
                        with contextlib.suppress(Exception):
                            await page.goto(
                                TEAMS_URL, wait_until="domcontentloaded", timeout=90_000
                            )
                    return await self._poll_for_token(page, audience, headless=headless)
                finally:
                    with contextlib.suppress(Exception):
                        cdp = await browser.new_browser_cdp_session()
                        await cdp.send("Browser.close")
                    with contextlib.suppress(Exception):
                        await browser.close()
        except Exception as exc:  # noqa: BLE001 — never let the browser kill a turn
            logger.warning("[teams_web] Edge session failed: {}", exc)
            return None
        finally:
            _kill(proc)

    async def _poll_for_token(
        self, page, audience: str, *, headless: bool
    ) -> CachedTeamsWebToken | None:
        """Wait until MSAL has a *non-expired* token for *audience* in the page."""
        attempts = _RENEWAL_POLL_ATTEMPTS
        if not headless:
            # A headed run may be waiting for a human to complete sign-in.
            attempts = max(attempts, int(self._login_timeout_s / _RENEWAL_POLL_INTERVAL_S))
        for _ in range(attempts):
            await asyncio.sleep(_RENEWAL_POLL_INTERVAL_S)
            try:
                found = await page.evaluate(_TOKEN_PICK_JS, audience)
            except Exception as exc:  # noqa: BLE001 — navigation destroys contexts
                logger.debug("[teams_web] evaluate raised mid-navigation: {}", type(exc).__name__)
                continue
            if not found:
                continue
            seconds_left = int(found.get("secondsLeft") or 0)
            if seconds_left <= self._skew_s:
                logger.debug(
                    "[teams_web] {} token stale (left={}s); waiting for silent renewal",
                    audience,
                    seconds_left,
                )
                continue
            expires_at = float(found["expiresAt"])
            return CachedTeamsWebToken(
                secret=str(found["secret"]),
                acquired_at=time.time(),
                expires_at=expires_at,
            )
        return None


def default_token_cache_path() -> Path:
    """``<data_dir>/auth/teams_web_tokens.bin`` — the private, encrypted sink."""
    from praestoclaw.utils.helpers import get_auth_dir

    return get_auth_dir() / TOKEN_CACHE_FILENAME
