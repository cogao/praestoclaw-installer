"""Team knowledge-base working area inside the PraestoClaw profile.

The knowledge flow has two stages and this package owns the boundary between
them::

    <data_dir>/kb/
        captures/                        stage 1 — verbatim capture snapshots
        repos/<host>__<owner>__<name>/   stage 2 — a real git clone of the KB

Stage 1 (``teams_group_fetch`` + ``team_knowledge_capture``) only ever writes
under ``captures/``. Stage 2 reads a capture, inspects the *live* checkout under
``repos/`` to learn that repository's current rules, and proposes changes
against it.

Keeping both in the profile rather than a scratch directory is what lets the
curation stage run on a different day, in a different session, against the same
unchanged evidence.
"""

from __future__ import annotations

from pathlib import Path


def kb_root() -> Path:
    """``<data_dir>/kb`` — resolved per call so ``--data-dir`` still applies."""
    from praestoclaw.utils.helpers import get_data_dir

    return get_data_dir() / "kb"


def captures_dir() -> Path:
    """Where capture snapshots land (the collection → curation hand-off)."""
    return kb_root() / "captures"


def repos_dir() -> Path:
    """Root holding one git clone per knowledge-base repository."""
    return kb_root() / "repos"


__all__ = ["captures_dir", "kb_root", "repos_dir"]
