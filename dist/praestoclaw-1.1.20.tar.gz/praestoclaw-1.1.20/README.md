<p align="center">
  <img src="docs/images/logo.svg" alt="PraestoClaw" width="180" />
</p>

<h1 align="center">PraestoClaw 🦞</h1>

<p align="center">
  <strong>Your autonomous AI teammate — that now talks to <em>other</em> AI teammates.</strong><br/>
  Built on <a href="https://github.com/gim-home/WorkPilot">WorkPilot</a>. Your data stays on your box. Your lobster talks to theirs.
</p>

<p align="center">
  <a href="https://github.com/gim-home/PraestoClaw/actions/workflows/praestoclaw-ci.yml"><img src="https://github.com/gim-home/PraestoClaw/actions/workflows/praestoclaw-ci.yml/badge.svg" alt="CI" /></a>
  <a href="https://www.python.org/"><img src="https://img.shields.io/badge/python-3.11+-blue.svg" alt="Python 3.11+" /></a>
  <a href="https://aka.ms/praestoclaw/docs"><img src="https://img.shields.io/badge/docs-aka.ms%2Fpraestoclaw%2Fdocs-green" alt="Docs" /></a>
  <a href="LICENSE"><img src="https://img.shields.io/badge/license-MIT-green" alt="MIT" /></a>
</p>

<p align="center">
  <a href="https://aka.ms/praestoclaw">Website</a> ·
  <a href="https://aka.ms/praestoclaw/docs">Docs</a> ·
  <a href="docs/CHANGELOG.md">Changelog</a> ·
  <a href="https://teams.microsoft.com/l/chat/0/0?users=28:80a9478e-6cc7-4e7a-84bc-37abbd81f5f6">Add to Teams</a>
</p>

---

## 🦞 Why PraestoClaw?

[WorkPilot](https://github.com/gim-home/WorkPilot) already gives you a powerful local AI assistant — it codes, runs shells, drives browsers, reads your repos, talks to Teams & Outlook, and keeps every secret on your machine.

**PraestoClaw** adds what was missing: **collaboration between agents**.

| 🆕 In 1.0 | What it unlocks |
|---|---|
| **A2A overlay** (Agent-to-Agent protocol) | Your lobster can *assign tasks to*, *check status on*, and *receive deliverables from* another person's lobster — over a standard A2A protocol, with your identity and audit trail intact. |
| **Python Gateway** | A lightweight relay (separate from the .NET Cloud Gateway) that routes A2A traffic between instances and exposes `/a2a/users/{you}/...` endpoints. |
| **Expanded skill pack** | Bundled and workspace skills are plain markdown: GitHub, ADO, Azure ops, A2A, Copilot/Claude delegation, Teams/calendar helpers, privacy review, and more. |
| **Community-first** | Skills live in `praestoclaw/skills/bundled/` as plain markdown — open a PR, ship a skill. |

Everything else from WorkPilot is still there: 3-tier channels (CLI / self-hosted web / cloud relay), Entra ID SSO, 4 security profiles, risk-scored tool calls, MCP support, scheduler, sub-agent delegation, audit log, E-stop — the works.

---

## ⚡ One-minute install

```bash
pip install praestoclaw
praestoclaw init          # guided setup — Entra ID login, model pick, profile
praestoclaw               # smart start — init if needed, then launch
```

<details>
<summary><strong>One-click bootstrap</strong> (auto-installs Python 3.13 if needed)</summary>

**Windows (PowerShell):**
```powershell
irm https://aka.ms/praestoclaw/install.ps1 | iex
```

**macOS / Linux:**
```bash
curl -fsSL https://aka.ms/praestoclaw/install.sh | bash
```

Also want the A2A gateway on your own box? Add `INSTALL_GATEWAY=1` to the bash installer, or `pip install -e ./gateway` after cloning.
</details>

<details>
<summary><strong>Platform notes</strong></summary>

| Platform | Notes |
|----------|-------|
| **Windows** | If `praestoclaw` isn't found after install, ensure `%APPDATA%\Python\Python3x\Scripts` is on your PATH, or use the bootstrap script. |
| **macOS** | You may need `python3` instead of `python`. Homebrew: `brew install python@3.11` |
| **Linux** | `sudo apt install python3.11 python3.11-venv` if Python 3.11+ isn't available. |

> **Tip:** Using a virtual environment is recommended:
> ```bash
> python -m venv .venv && source .venv/bin/activate
> pip install praestoclaw
> ```
</details>

---

## 🚀 What you can do

### Three ways to reach it

```bash
praestoclaw chat               # interactive REPL
praestoclaw run "write tests"  # one-shot
praestoclaw serve              # http://localhost:3004 — chat UI + REST + WS + OpenAI-compatible /v1/chat/completions
praestoclaw cloud              # Teams + Web Chat via the Cloud Gateway
```

### Let it run real work

| Capability | Details |
|--|--|
| **Code** | Read, write, edit, refactor, and debug across your entire codebase |
| **Shell** | Run commands, git, tests, build tools — sandboxed with deny-pattern controls |
| **Browse** | Web search, HTTP requests, Playwright browser automation (36 actions) |
| **Microsoft 365** | Teams messages, Outlook email, calendar, Graph API, Azure DevOps |
| **Delegate** | Spawn sub-agents; delegate to GitHub Copilot or Claude Code in background |
| **Skills** | Markdown prompt overlays with auto-activation — create your own |
| **MCP** | Connect Microsoft-internal tool servers through stdio-based Agency MCP — namespaced tools, progressive loading, auto-reconnect. **18 Agency servers bundled out of the box** (see below) |
| **Schedule** | Cron jobs, event triggers, heartbeat tasks, recurring automation |

### Keep it safe

Four profiles — `open` → `standard` → `controlled` → `restricted` — each tool call gets a **risk score (0–10)** before it runs. Sensitive output is redacted on the way out. Every action lands in an append-only audit log. Leak detection or you hitting E-stop halts the whole thing instantly.

---

## 🦞↔️🦞 Lobster-to-lobster (A2A)

This is the big new thing in 1.0.

Every PraestoClaw instance publishes an **Agent Card** via the Python Gateway. Other instances can reach you at:

```
GET  /a2a/users/{your_id}/.well-known/agent-card.json
POST /a2a/users/{your_id}/message:send       # blocking
POST /a2a/users/{your_id}/message:stream     # SSE streaming
GET  /a2a/users/{your_id}/tasks              # list
GET  /a2a/users/{your_id}/tasks/{task_id}    # status / artifacts
POST /a2a/users/{your_id}/tasks/{task_id}:cancel
```

### Try it in 3 steps

**① Turn A2A on** in `~/.praestoclaw/praestoclaw.yaml`:
```yaml
channels:
  a2a:
    enabled: true
    user_id: alice@contoso.com      # your alias / email
    protocol_version: "1"
```

**② Point at a gateway** (your team's shared one, or run your own):
```bash
cd gateway
GATEWAY_AUTH__BYPASS_ENABLED=true GATEWAY_AUTH__BYPASS_TOKEN=dev-token gateway
```

**③ Talk to your teammate's lobster.** From a chat, just ask:

> "Ask bob@contoso.com's agent to review the perf changes on branch `feat/index-v2` and send back a summary."

Under the hood your agent calls `POST /a2a/users/bob/message:send`, Bob's agent runs it with *his* permissions on *his* machine, and streams the artifact back. Every hop is authenticated, scored, and audited on both sides.

**Real workflows this unlocks**:
- 📋 **Delegate tasks**: "Hand off bug #4712 to dana's agent — repro, fix, open PR, ping me."
- ✅ **Accept deliverables**: "Review the artifact dana's agent sent and merge if tests pass."
- ❓ **Ask around**: "Query the team lobsters — who's seen this Kusto error today?"
- 🤖 **Agent mesh**: build private multi-agent networks where each member's lobster is the authoritative endpoint for their work.

> 📖 Under the hood: see the `A2ARuntime` class in [praestoclaw/a2a/runtime.py](praestoclaw/a2a/runtime.py) and the gateway `/a2a/*` endpoints in [gateway/src/gateway/a2a/](gateway/src/gateway/a2a/).

---

## 🔌 Bundled MCP servers

PraestoClaw ships with **18 Microsoft-internal MCP servers** pre-wired. They are all
backed by the [Agency CLI](https://aka.ms/InstallTool.ps1) — the `install.ps1` /
`install.sh` scripts install Agency automatically as a non-critical step (MCP still
works without it; the bundled MS-internal servers just won't be reachable).

| Server | What it fronts |
|---|---|
| `ado` | Azure DevOps work items, repos, pipelines |
| `bluebird` | Internal code search / review |
| `calendar` | Outlook / Graph calendar |
| `cloudbuild` | 1ES / CloudBuild pipelines |
| `enghub` | EngHub knowledge base |
| `es-chat` | Enterprise Search chat |
| `icm` | ICM incidents (read) |
| `m365-copilot` | Microsoft 365 Copilot / Agent365 (was `m365copilot`) |
| `m365-user` | Per-user M365 Graph calls (was `user`) |
| `mail` | Outlook mail |
| `msft-learn` | learn.microsoft.com search (was `microsoft-learn`) |
| `planner` | Microsoft Planner |
| `s360-breeze` | S360 compliance data |
| `security-context` | Security posture / signals |
| `sharepoint` | SharePoint sites & documents |
| `teams` | Teams messaging / channels |
| `word` | Word document operations |
| `workiq` | WorkIQ productivity signals |

> **Previously bundled, now removed in week16:** `github` and `onedrive`. No Agency-
> backed equivalent exists today — use the GitHub / OneDrive skills instead.
>
> **Deferred:** `kusto` (the `agency mcp kusto` subcommand requires `--service-uri` or
> `--known-services`, which we can't auto-infer). See
> [`docs/explore/week16/kusto-deferred.md`](docs/explore/week16/kusto-deferred.md).

Run `praestoclaw mcp setup --all` (or use the `init` wizard's MCP step) to enable
them interactively. Each server is validated with an auth probe on add; failures are
reported but don't block the rest.



Skills are markdown prompt overlays with auto-activation — the agent reads them, and uses the tools it already has. Two percent of the context budget, huge behavioural lift.

Bundled in 1.0:

| Skill | What it does |
|---|---|
| `github` | GitHub issue/PR workflows via `gh` CLI |
| `ado` | Azure DevOps work items, bug triage, PRs, pipelines, and repos |
| `azure-ops` | Azure operational diagnostics and resource management |
| `a2a` | Send fire-and-forget messages to other PraestoClaw agents through the gateway |
| `calendar-lookup` | Calendar and meeting lookup guidance |
| `teams-message` | Draft and send Microsoft Teams messages |
| `code-change` / `commit-code` | Plan, edit, test, commit, and push with good messages |
| `claude-code-delegate` | Offload long coding tasks to a Claude Code background agent |
| `ms-search` | Microsoft Search / internal search guidance |
| `societas-debug` | Local debug workflow for Societas / Office Agent |
| `societas-bug-triage` | Triage Societas bugs by AreaPath ownership + your org subtree (dry-run by default) |
| `societas-privacy-champ` | Microsoft internal privacy-review companion for Societas (Data Scout, DPIA, controller vs processor) |

Societas bug remediation is owned by the bundled `fix-societas-bug` workflow;
scanner cards invoke that workflow instead of a separate bug-fix skill.

PraestoClaw also loads user and workspace skills, so teams can add their own `SKILL.md` files without changing the application package.

### Write your own in ~10 lines

```markdown
---
name: my-skill
description: When to activate. Be specific — the LLM uses this to decide.
---

# My Skill

## When the user asks X, do:
1. Gather context with `read_file` + `grep_search`
2. Run `shell` to verify
3. Respond with a Y-shaped summary
```

Drop it in `praestoclaw/skills/bundled/my-skill/SKILL.md`, open a PR. That's it. **Skills are the #1 way we want community contributions in 1.0.**

---

## 🏗️ Built-in agents

| Agent | Model | Purpose |
|-------|-------|---------|
| `default` | auto | Full-capability orchestrator — user-facing, spawns sub-agents |
| `explorer` | fast | Read-only codebase search — 10× cheaper, spawned automatically |

Tool-call risk scoring is handled by the internal Risk Scorer pipeline, not by a spawnable agent. Add project-specific agents with `praestoclaw agents add <name>` or by editing `praestoclaw.local.yaml`.

---

## 🔌 Architecture at a glance

```
Terminal / Web UI / Teams
        │
   Message Bus (bounded queues + typed events)
        │
   Agent Loop ──── Tool Registry ──── Skills (auto-inject)
   │    │               │
   │    │          MCP Servers  ◄──── A2A Runtime ◄──── Python Gateway ◄──── peer lobster
   │    │
   │   LLM Provider (OpenAI SDK + circuit breaker + cost tracking)
   │
   Security Pipeline (preflight → execute → postflight)
```

Full spec: [docs/design/core-infra.md](docs/design/core-infra.md) · A2A design: [gateway/README.md](gateway/README.md)

---

## 🧪 Commands cheat sheet

```bash
praestoclaw                   # smart start (init if needed, then serve)
praestoclaw chat              # local REPL
praestoclaw serve             # self-hosted gateway (REST + WS + chat UI)
praestoclaw cloud             # connect to Cloud Gateway (Teams / Web Chat)

praestoclaw agents list
praestoclaw tools list
praestoclaw skills list
praestoclaw mcp setup --all
praestoclaw sessions list
praestoclaw cron list
praestoclaw security status
praestoclaw memory show
praestoclaw doctor            # diagnose config / auth / connectivity
praestoclaw update            # self-update
```

The CLI is also aliased as `pc` (e.g. `pc chat`).

---

## 🤝 Contribute

We're actively looking for:

1. **Skills** — anything your team does repeatedly. Drop a `SKILL.md` under `praestoclaw/skills/bundled/<name>/` and PR.
2. **A2A recipes** — cool workflows where two or more lobsters collaborate. Share them in `docs/recipes/`.
3. **MCP servers** — hook up the tools your org already uses.
4. **Bug reports / ideas** — open an issue.

```bash
git clone https://github.com/gim-home/PraestoClaw.git
cd PraestoClaw
pip install -e ".[dev]"        # editable install with dev dependencies
pip install -e ".[all]"        # all optional deps (browser, scheduler, etc.)
pytest tests/ -v               # 1500+ tests
python -m ruff check && python -m ruff format
```

All changes via pull request — `main` is protected. Never push directly.

**Local multi-instance testing**: see [`apps/cloud_gateway/docs/20-local-multi-instance-testing.md`](../cloud_gateway/docs/20-local-multi-instance-testing.md) for running several PraestoClaw instances against a local Cloud Gateway with synthetic identities.

---

## 📎 Links

- [Official Website](https://aka.ms/praestoclaw)
- [Documentation](https://aka.ms/praestoclaw/docs)
- [Changelog](docs/CHANGELOG.md)
- [Architecture](docs/design/core-infra.md)
- [Gateway (Python)](gateway/) — FastAPI relay server with Teams, Web Chat, and A2A support
- [Upstream: WorkPilot](https://github.com/gim-home/WorkPilot)
- [Add to Microsoft Teams](https://teams.microsoft.com/l/chat/0/0?users=28:80a9478e-6cc7-4e7a-84bc-37abbd81f5f6) *(Preview)*

---

<p align="center"><em>PraestoClaw — Latin <strong>praesto</strong> ("I stand ready") + 🦞. Ready when you are. Ready when <em>they</em> are.</em></p>
