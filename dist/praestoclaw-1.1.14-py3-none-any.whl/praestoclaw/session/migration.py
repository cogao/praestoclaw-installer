"""JSONL → SQLite session migration utility."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from loguru import logger

from praestoclaw.session.store import SessionStore


@dataclass
class MigrationResult:
    sessions_migrated: int = 0
    messages_migrated: int = 0
    sessions_skipped: int = 0
    errors: list[str] = field(default_factory=list)


async def migrate_jsonl_to_sqlite(jsonl_dir: Path, store: SessionStore) -> MigrationResult:
    """Migrate JSONL session files to SQLite SessionStore."""
    result = MigrationResult()

    if not jsonl_dir.exists():
        return result

    for session_dir in sorted(jsonl_dir.iterdir()):
        if not session_dir.is_dir():
            continue

        messages_file = session_dir / "messages.jsonl"
        if not messages_file.exists():
            logger.debug("Skipping {}: no messages.jsonl", session_dir.name)
            result.sessions_skipped += 1
            continue

        try:
            messages: list[dict] = []
            with open(messages_file) as f:
                for line in f:
                    line = line.strip()
                    if line:
                        messages.append(json.loads(line))

            if not messages:
                logger.debug("Skipping {}: empty messages", session_dir.name)
                result.sessions_skipped += 1
                continue

            # Read meta
            meta_file = session_dir / ".meta.json"
            channel = "cli"
            sender_id = "unknown"
            if meta_file.exists():
                with open(meta_file) as f:
                    meta = json.load(f)
                channel = meta.get("channel", "cli")
                sender_id = meta.get("sender_id", "unknown")

            session_id = await store.get_or_create_session(channel, sender_id)
            for msg in messages:
                await store.add_message(session_id, msg)
                result.messages_migrated += 1

            result.sessions_migrated += 1
            logger.info("Migrated session {} ({} messages)", session_dir.name, len(messages))

        except Exception as exc:
            error_msg = f"Error migrating {session_dir.name}: {exc}"
            logger.error(error_msg)
            result.errors.append(error_msg)

    logger.info(
        "Migration complete: {} sessions, {} messages, {} skipped, {} errors",
        result.sessions_migrated,
        result.messages_migrated,
        result.sessions_skipped,
        len(result.errors),
    )
    return result
