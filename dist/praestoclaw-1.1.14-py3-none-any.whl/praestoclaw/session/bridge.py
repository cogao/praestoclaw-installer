"""Session bridge — sync adapter for v2 async SessionStore.

Provides the same public API as v1's SessionManager but delegates to the
v2 async SessionStore. Used by web handlers, CLI commands, and other sync
callers that reference `rt.session_manager`.

All methods run the async calls in the current event loop using
asyncio.run_coroutine_threadsafe or loop.run_until_complete depending
on context. In an async context (FastAPI), callers should `await` the
async variants directly via `rt._session_store_v2`.
"""

from __future__ import annotations

import asyncio
import uuid
from typing import Any

from loguru import logger


class SessionBridge:
    """Sync-compatible wrapper around the async SessionStore.

    Drop-in replacement for v1 SessionManager so web handlers, CLI session
    commands, and other code that does `rt.session_manager.list_sessions()`
    works unchanged when v2 is active.
    """

    def __init__(self, store: Any) -> None:
        self._store = store  # SessionStore

    def _run(self, coro: Any) -> Any:
        """Run an async coroutine from sync context."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # We're inside an async context (e.g. FastAPI route).
            # Create a new thread to run the coroutine.
            import concurrent.futures

            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(asyncio.run, coro)
                return future.result(timeout=10)
        else:
            return asyncio.run(coro)

    def list_sessions(self, limit: int | None = None) -> list[dict[str, Any]]:
        return self._run(self._store.list_sessions(limit=limit))  # type: ignore[no-any-return]

    def get_or_create_id(self, channel: Any, sender_id: str) -> str:
        return self._run(self._store.get_or_create_session(str(channel), sender_id))  # type: ignore[no-any-return]

    def find_session(self, channel: Any, sender_id: str) -> str | None:
        return self._run(self._store.find_session(str(channel), sender_id))  # type: ignore[no-any-return]

    def get_messages(self, session_id: str, llm_only: bool = False) -> list[dict[str, Any]]:
        msgs: list[dict[str, Any]] = self._run(self._store.get_messages(session_id))
        if llm_only:
            msgs = [m for m in msgs if m.get("role") in ("system", "user", "assistant", "tool")]
        return msgs

    def session_exists(self, session_id: str) -> bool:
        return bool(self._run(self._store.session_exists(session_id)))

    def add_message(self, session_id: str, message: dict[str, Any]) -> None:
        self._run(self._store.add_message(session_id, message))

    def clear(self, session_id: str) -> None:
        self._run(self._store.replace_messages(session_id, []))

    def delete(self, session_id: str) -> None:
        self._run(self._store.delete_session(session_id))

    def replace_messages(self, session_id: str, messages: list[dict[str, Any]]) -> None:
        self._run(self._store.replace_messages(session_id, messages))

    def fork(self, session_id: str) -> str:
        return self._run(self._store.fork(session_id))  # type: ignore[no-any-return]

    def is_loaded(self, session_id: str) -> bool:
        return True  # SQLite always "loaded"

    def generate_id(self) -> str:
        return str(uuid.uuid4())

    def read_meta(self, session_id: str) -> dict[str, Any]:
        sessions: list[dict[str, Any]] = self._run(self._store.list_sessions(limit=None))
        for s in sessions:
            if s.get("id") == session_id:
                return s
        return {}

    def update_meta(self, session_id: str, **fields: Any) -> None:
        # SessionStore manages metadata via the sessions table; explicit meta
        # updates are not supported. Log a warning so callers notice instead
        # of silently losing data.
        if fields:
            logger.warning(
                "SessionBridge.update_meta() is a no-op for SQLite store (session={}, fields={})",
                session_id,
                list(fields.keys()),
            )

    def smart_load_session(
        self,
        session_id: str,
        context_limit: int,
        *,
        reserved_tokens: int = 0,
        full_content_turns: int = 5,
    ) -> list[dict[str, Any]]:
        budget = max(1000, context_limit - reserved_tokens)
        return self._run(self._store.smart_load(session_id, budget))  # type: ignore[no-any-return]

    def trim(self, session_id: str, keep_last: int) -> list[dict[str, Any]]:
        msgs = self.get_messages(session_id)
        if len(msgs) > keep_last:
            trimmed = msgs[:-keep_last]
            kept = msgs[-keep_last:]
            self.replace_messages(session_id, kept)
            return trimmed
        return []

    def maybe_split_session(self, session_id: str) -> bool:
        return False  # SQLite doesn't need file-based splitting

    @property
    def _sessions(self) -> dict[str, list[dict[str, Any]]]:
        """Compatibility shim for code that accesses _sessions directly."""
        sessions = self._run(self._store.list_sessions(limit=None))
        result: dict[str, list[dict[str, Any]]] = {}
        for s in sessions:
            sid = s.get("id", "")
            try:
                result[sid] = self._run(self._store.get_messages(sid))
            except Exception:
                result[sid] = []
        return result
