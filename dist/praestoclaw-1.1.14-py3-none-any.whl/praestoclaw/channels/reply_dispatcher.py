"""Channel-turn outbound dispatcher.

This wrapper keeps final-message and streaming delivery decisions in one
place while the channel stack migrates away from direct bus calls.
"""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any

from praestoclaw.bus.events import OutboundMessage, StreamingChunk
from praestoclaw.bus.queue import MessageBus
from praestoclaw.config.schema import ChannelType

_FINAL_DEDUPE_LIMIT = 2048
_FINAL_DEDUPE_METADATA_KEYS = ("turn_id", "request_id", "message_id")
_FinalDedupeKey = tuple[ChannelType, str, str | None, str | None, str]


@dataclass(slots=True)
class ReplyDispatcher:
    bus: MessageBus
    final_dedupe_limit: int = _FINAL_DEDUPE_LIMIT
    _final_keys: OrderedDict[_FinalDedupeKey, None] = field(default_factory=OrderedDict)

    async def publish_final(
        self,
        *,
        channel: ChannelType,
        channel_id: str,
        content: str,
        thread_id: str | None = None,
        route_hint: str | None = None,
        metadata: dict[str, Any] | None = None,
        dedupe_key: str | None = None,
        dedupe: bool = True,
    ) -> bool:
        if dedupe:
            key = self._final_dedupe_key(
                channel=channel,
                channel_id=channel_id,
                thread_id=thread_id,
                route_hint=route_hint,
                metadata=metadata,
                dedupe_key=dedupe_key,
            )
            if key is not None:
                if key in self._final_keys:
                    self._final_keys.move_to_end(key)
                    return False
                self._final_keys[key] = None
                while len(self._final_keys) > max(0, self.final_dedupe_limit):
                    self._final_keys.popitem(last=False)
        return await self.bus.publish_outbound(
            OutboundMessage(
                channel=channel,
                channel_id=channel_id,
                content=content,
                thread_id=thread_id,
                metadata=metadata or {},
                route_hint=route_hint,
            )
        )

    @staticmethod
    def _final_dedupe_key(
        *,
        channel: ChannelType,
        channel_id: str,
        thread_id: str | None,
        route_hint: str | None,
        metadata: dict[str, Any] | None,
        dedupe_key: str | None,
    ) -> _FinalDedupeKey | None:
        turn_key = ReplyDispatcher._turn_dedupe_key(metadata, dedupe_key)
        if turn_key is None:
            return None
        return (channel, channel_id, thread_id, route_hint, turn_key)

    @staticmethod
    def _turn_dedupe_key(metadata: dict[str, Any] | None, dedupe_key: str | None) -> str | None:
        if isinstance(dedupe_key, str) and dedupe_key.strip():
            return dedupe_key.strip()
        if metadata is None:
            return None
        for key in _FINAL_DEDUPE_METADATA_KEYS:
            value = metadata.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
        return None

    async def publish_intermediate(
        self,
        *,
        channel: ChannelType,
        channel_id: str,
        content: str,
        thread_id: str | None = None,
        route_hint: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        return await self.bus.publish_outbound(
            OutboundMessage(
                channel=channel,
                channel_id=channel_id,
                content=content,
                thread_id=thread_id,
                metadata=metadata or {},
                route_hint=route_hint,
            )
        )

    async def publish_stream_chunk(
        self,
        *,
        channel: ChannelType,
        channel_id: str,
        content: str,
        done: bool = False,
        chunk_type: str = "token",
    ) -> bool:
        return await self.bus.dispatch_outbound(
            StreamingChunk(
                channel=channel,
                channel_id=channel_id,
                content=content,
                done=done,
                chunk_type=chunk_type,
            )
        )
