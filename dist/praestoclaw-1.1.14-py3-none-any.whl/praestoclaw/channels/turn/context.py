from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class PhysicalIngress(StrEnum):
    LOCAL_WEB_PORTAL = "local_web_portal"
    LOCAL_TERMINAL = "local_terminal"
    LOCAL_SCHEDULER = "local_scheduler"
    AGENT_LINK = "agent_link"


@dataclass(frozen=True, slots=True)
class ChannelTurnEnvelope:
    trace_id: str
    physical_ingress: str
    logical_channel: str
    content: str
    sender_id: str
    conversation_id: str
    received_at: str
    attachments: tuple[Any, ...] = ()
    raw_event: object | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class SourceFacts:
    physical_ingress: str
    logical_channel: str
    source_scope: str
    tenant_id: str | None = None


@dataclass(frozen=True, slots=True)
class SenderFacts:
    sender_id: str
    display_name: str | None = None
    upn: str | None = None
    aad_object_id: str | None = None
    roles: tuple[str, ...] = ()
    is_system: bool = False


@dataclass(frozen=True, slots=True)
class ConversationFacts:
    conversation_id: str
    thread_id: str | None = None
    reply_to_id: str | None = None
    chat_kind: str | None = None


@dataclass(frozen=True, slots=True)
class RouteFacts:
    agent_id: str
    session_key: str
    route_identity: str
    delivery_route: dict[str, Any] = field(default_factory=dict)
    cluster_target: str | None = None


@dataclass(frozen=True, slots=True)
class MessageFacts:
    normalized_content: str
    content_format: str = "text"
    attachments: tuple[Any, ...] = ()
    command_text: str | None = None


@dataclass(frozen=True, slots=True)
class ReplyPlanFacts:
    delivery_adapter: str
    logical_channel: str
    supports_streaming: bool = False
    supports_cards: bool = False


@dataclass(frozen=True, slots=True)
class SupervisionFacts:
    initiated_by: str
    human_initiated: bool
    requires_human_visibility: bool
    supervisor_route: dict[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class TurnContext:
    trace_id: str
    source: SourceFacts
    sender: SenderFacts
    conversation: ConversationFacts
    route: RouteFacts
    message: MessageFacts
    reply_plan: ReplyPlanFacts
    supervision: SupervisionFacts
    metadata: dict[str, Any] = field(default_factory=dict)
