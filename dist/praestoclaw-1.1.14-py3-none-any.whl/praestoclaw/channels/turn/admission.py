from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Any, Protocol

from praestoclaw.channels.turn.context import ChannelTurnEnvelope


class AdmissionKind(StrEnum):
    DROP = "drop"
    HANDLED = "handled"
    OBSERVE_ONLY = "observe_only"
    DISPATCH = "dispatch"


@dataclass(frozen=True, slots=True)
class AdmissionDecision:
    kind: AdmissionKind
    reason: str | None = None
    synthetic_reply: Any | None = None

    @classmethod
    def dispatch(cls) -> AdmissionDecision:
        return cls(kind=AdmissionKind.DISPATCH)

    @classmethod
    def drop(cls, reason: str) -> AdmissionDecision:
        return cls(kind=AdmissionKind.DROP, reason=reason)

    @classmethod
    def handled(cls, reason: str, synthetic_reply: Any | None = None) -> AdmissionDecision:
        return cls(kind=AdmissionKind.HANDLED, reason=reason, synthetic_reply=synthetic_reply)

    @classmethod
    def observe_only(cls, reason: str) -> AdmissionDecision:
        return cls(kind=AdmissionKind.OBSERVE_ONLY, reason=reason)


class AdmissionPolicy(Protocol):
    async def decide(self, envelope: ChannelTurnEnvelope) -> AdmissionDecision: ...


class AllowAllAdmissionPolicy:
    async def decide(self, envelope: ChannelTurnEnvelope) -> AdmissionDecision:
        return AdmissionDecision.dispatch()
