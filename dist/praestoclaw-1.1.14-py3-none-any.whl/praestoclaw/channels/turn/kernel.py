from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from agent_gateway_protocol.agent_link.v1 import InitiatedBy, LogicalChannel

from praestoclaw.channels.turn.admission import (
    AdmissionDecision,
    AdmissionKind,
    AdmissionPolicy,
    AllowAllAdmissionPolicy,
)
from praestoclaw.channels.turn.context import (
    ChannelTurnEnvelope,
    ConversationFacts,
    MessageFacts,
    ReplyPlanFacts,
    RouteFacts,
    SenderFacts,
    SourceFacts,
    SupervisionFacts,
    TurnContext,
)
from praestoclaw.host.hook_runner import HookRunner, NoopHookRunner
from praestoclaw.host.runtime_contracts import (
    AgentRuntimeProtocol,
    AgentRuntimeRequest,
    AgentRuntimeResult,
    TurnProvenanceSummary,
)

_RUNTIME_METADATA_ALLOWLIST = frozenset(
    {
        "_task_progress_sender",
        "channel_type",
        "content_format",
        "conversation_id",
        "exclude_tools",
        "execution_lane",
        "interrupt",
        "job_name",
        "message_id",
        "pending_attachments",
        "pending_images",
        "received_at",
        "request_id",
        "requires_human_visibility",
        "sender_name",
        "source",
        "source_scope",
        "supports_cards",
        "supports_streaming",
        "task",
        "task_id",
        "task_sender_id",
        "task_summary",
        "turn_id",
    }
)


class SessionResolver(Protocol):
    def resolve_session_key(self, envelope: ChannelTurnEnvelope) -> str: ...


class DefaultSessionResolver:
    def resolve_session_key(self, envelope: ChannelTurnEnvelope) -> str:
        metadata_session_key = str(envelope.metadata.get("agent_session_key") or "").strip()
        if metadata_session_key:
            return metadata_session_key
        return ":".join(
            [
                envelope.logical_channel,
                envelope.sender_id,
                envelope.conversation_id,
            ]
        )


@dataclass(frozen=True, slots=True)
class ChannelTurnResult:
    admission: AdmissionDecision
    context: TurnContext | None = None
    runtime_request: AgentRuntimeRequest | None = None
    runtime_result: AgentRuntimeResult | None = None


def _hash_session_id(raw: str) -> str:
    """Hash session_key so a Teams thread id never lands in telemetry."""
    import hashlib

    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def _emit_task_completed(
    outcome: str,
    duration_ms: int,
    logical_channel: str,
    turn_id: str | None = None,
    session_id: str | None = None,
    error_type: str | None = None,
) -> None:
    """Fire-and-forget telemetry. Defensive — never raises into the turn kernel."""
    try:
        from praesto_telemetry import Events, emit

        props: dict[str, object] = {
            "outcome": outcome,
            "duration_ms": duration_ms,
            "logical_channel": logical_channel,
        }
        if turn_id:
            props["turn_id"] = turn_id
        if session_id:
            props["session_id"] = session_id
        if error_type:
            props["error_type"] = error_type
        emit(Events.TASK_COMPLETED, **props)
    except Exception:  # pragma: no cover - telemetry must never break the host
        pass


class ChannelTurnKernel:
    def __init__(
        self,
        *,
        agent_id: str,
        runtime: AgentRuntimeProtocol,
        admission_policy: AdmissionPolicy | None = None,
        session_resolver: SessionResolver | None = None,
        hooks: HookRunner | None = None,
    ) -> None:
        self._agent_id = agent_id
        self._runtime = runtime
        self._admission_policy = admission_policy or AllowAllAdmissionPolicy()
        self._session_resolver = session_resolver or DefaultSessionResolver()
        self._hooks = hooks or NoopHookRunner()

    async def process(self, envelope: ChannelTurnEnvelope) -> ChannelTurnResult:
        import asyncio as _asyncio
        import time as _time

        turn_start = _time.monotonic()
        turn_id = envelope.trace_id  # already a UUID per turn
        # Hash session_key so Teams thread ids never reach telemetry.
        session_id_hash = _hash_session_id(self._session_resolver.resolve_session_key(envelope))
        await self._hooks.observe("turn.received", envelope)

        admission = await self._admission_policy.decide(envelope)
        await self._hooks.gate("turn.preflight", admission)
        if admission.kind != AdmissionKind.DISPATCH:
            _emit_task_completed(
                outcome=admission.kind.value,
                duration_ms=int((_time.monotonic() - turn_start) * 1000),
                logical_channel=envelope.logical_channel,
                turn_id=turn_id,
                session_id=session_id_hash,
            )
            return ChannelTurnResult(admission=admission)

        context = self._resolve_context(envelope)
        context = await self._hooks.modify("supervision.plan", context)
        await self._hooks.observe("turn.recorded", context)

        claimed = await self._hooks.claim("turn.before_dispatch", context)
        if claimed is not None:
            _emit_task_completed(
                outcome="claimed",
                duration_ms=int((_time.monotonic() - turn_start) * 1000),
                logical_channel=envelope.logical_channel,
                turn_id=turn_id,
                session_id=session_id_hash,
            )
            return ChannelTurnResult(
                admission=AdmissionDecision.handled("claimed", claimed), context=context
            )

        runtime_request = self._build_runtime_request(context)
        # Thread telemetry ids into runtime metadata so _execute_tools can
        # tag tool_invoked events with the same turn_id / session_id.
        runtime_request.runtime_policy["telemetry_turn_id"] = turn_id
        runtime_request.runtime_policy["telemetry_session_id"] = session_id_hash

        error_type: str | None = None
        runtime_result: AgentRuntimeResult | None = None
        try:
            runtime_result = await self._runtime.run_once(runtime_request)
        except TimeoutError:
            error_type = "timeout"
            raise
        except _asyncio.CancelledError:
            error_type = "cancelled"
            raise
        except Exception as exc:
            error_type = type(exc).__name__
            raise
        finally:
            await self._hooks.observe("turn.finalized", context)
            if error_type:
                outcome = "error"
            elif runtime_result is None:
                outcome = "no_result"
            else:
                outcome = "success"
            _emit_task_completed(
                outcome=outcome,
                duration_ms=int((_time.monotonic() - turn_start) * 1000),
                logical_channel=envelope.logical_channel,
                turn_id=turn_id,
                session_id=session_id_hash,
                error_type=error_type,
            )
        return ChannelTurnResult(
            admission=admission,
            context=context,
            runtime_request=runtime_request,
            runtime_result=runtime_result,
        )

    def _resolve_context(self, envelope: ChannelTurnEnvelope) -> TurnContext:
        session_key = self._session_resolver.resolve_session_key(envelope)
        metadata = dict(envelope.metadata)
        human_channels = {
            LogicalChannel.LOCAL_WEBCHAT.value,
            LogicalChannel.LOCAL_TUI.value,
            LogicalChannel.CLOUD_TUI.value,
            LogicalChannel.TEAMS.value,
        }
        raw_initiated_by = str(metadata.get("initiated_by") or "").strip().lower()
        if raw_initiated_by in {item.value for item in InitiatedBy}:
            initiated_by = raw_initiated_by
            human_initiated = raw_initiated_by == InitiatedBy.HUMAN.value
        else:
            human_initiated = envelope.logical_channel in human_channels
            initiated_by = InitiatedBy.HUMAN.value if human_initiated else InitiatedBy.SYSTEM.value

        source_scope = str(metadata.get("source_scope") or "").strip().lower()
        if not source_scope:
            if envelope.logical_channel in {
                LogicalChannel.LOCAL_WEBCHAT.value,
                LogicalChannel.LOCAL_TUI.value,
            }:
                source_scope = "local"
            else:
                source_scope = "tenant" if human_initiated else "system"

        raw_requires_visibility = metadata.get("requires_human_visibility")
        requires_human_visibility = self._bool_metadata(
            raw_requires_visibility,
            default=not human_initiated,
        )
        return TurnContext(
            trace_id=envelope.trace_id,
            source=SourceFacts(
                physical_ingress=envelope.physical_ingress,
                logical_channel=envelope.logical_channel,
                source_scope=source_scope,
            ),
            sender=SenderFacts(sender_id=envelope.sender_id),
            conversation=ConversationFacts(conversation_id=envelope.conversation_id),
            route=RouteFacts(
                agent_id=self._agent_id,
                session_key=session_key,
                route_identity=str(envelope.metadata.get("connection_id") or session_key),
            ),
            message=MessageFacts(
                normalized_content=envelope.content,
                content_format=str(metadata.get("content_format") or "text"),
                attachments=envelope.attachments,
            ),
            reply_plan=ReplyPlanFacts(
                delivery_adapter=envelope.physical_ingress,
                logical_channel=envelope.logical_channel,
                supports_streaming=self._bool_metadata(
                    metadata.get("supports_streaming"),
                    default=False,
                ),
                supports_cards=self._bool_metadata(
                    metadata.get("supports_cards"),
                    default=False,
                ),
            ),
            supervision=SupervisionFacts(
                initiated_by=initiated_by,
                human_initiated=human_initiated,
                requires_human_visibility=requires_human_visibility,
            ),
            metadata={"envelope_metadata": dict(metadata)},
        )

    @staticmethod
    def _bool_metadata(value: object, *, default: bool) -> bool:
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            normalized = value.strip().lower()
            if normalized in {"1", "true", "yes", "y", "on"}:
                return True
            if normalized in {"0", "false", "no", "n", "off"}:
                return False
        return default

    @staticmethod
    def _build_runtime_request(context: TurnContext) -> AgentRuntimeRequest:
        envelope_metadata = ChannelTurnKernel._sanitize_runtime_metadata(
            dict(context.metadata.get("envelope_metadata", {}))
        )
        exclude_tools = ChannelTurnKernel._str_list_metadata(envelope_metadata.get("exclude_tools"))
        return AgentRuntimeRequest(
            agent_id=context.route.agent_id,
            session_id=context.route.session_key,
            user_content=context.message.normalized_content,
            turn_id=str(
                envelope_metadata.get("turn_id")
                or envelope_metadata.get("message_id")
                or context.trace_id
            ),
            attachments=context.message.attachments,
            runtime_policy={
                "route_identity": context.route.route_identity,
                "physical_ingress": context.source.physical_ingress,
                "logical_channel": context.source.logical_channel,
                "sender_id": context.sender.sender_id,
                "sender_name": envelope_metadata.get("sender_name") or context.sender.sender_id,
                "conversation_id": context.conversation.conversation_id,
                "content_format": context.message.content_format,
                "channel_type": envelope_metadata.get("channel_type"),
                "received_at": envelope_metadata.get("received_at"),
                "message_metadata": envelope_metadata,
            },
            tool_policy={
                "exclude_tools": exclude_tools,
            },
            turn_provenance=TurnProvenanceSummary(
                initiated_by=InitiatedBy(context.supervision.initiated_by),
                human_initiated=context.supervision.human_initiated,
                logical_channel=context.source.logical_channel,
                trust_boundary=context.source.source_scope,
                supervision_required=context.supervision.requires_human_visibility,
                reply_constraints={
                    "supports_streaming": context.reply_plan.supports_streaming,
                    "supports_cards": context.reply_plan.supports_cards,
                },
            ),
            supervision_policy={
                "requires_human_visibility": context.supervision.requires_human_visibility,
                "supervisor_route": context.supervision.supervisor_route,
            },
            memory_context={},
            cancellation_token=None,
            stream_sink=None,
        )

    @staticmethod
    def _str_list_metadata(value: object) -> list[str]:
        if not isinstance(value, list):
            return []
        return [item for item in value if isinstance(item, str)]

    @staticmethod
    def _sanitize_runtime_metadata(metadata: dict[str, object]) -> dict[str, object]:
        sanitized: dict[str, object] = {}
        for key, value in metadata.items():
            if key not in _RUNTIME_METADATA_ALLOWLIST:
                continue
            if key == "_task_progress_sender":
                sanitized[key] = value
                continue
            safe_value = ChannelTurnKernel._json_safe_metadata_value(value)
            if safe_value is not _DROP_METADATA_VALUE:
                sanitized[key] = safe_value
        return sanitized

    @staticmethod
    def _json_safe_metadata_value(value: object) -> object:
        if value is None or isinstance(value, (str, int, float, bool)):
            return value
        if isinstance(value, (tuple, list)):
            safe_items: list[object] = []
            for item in value:
                safe_item = ChannelTurnKernel._json_safe_metadata_value(item)
                if safe_item is not _DROP_METADATA_VALUE:
                    safe_items.append(safe_item)
            return safe_items
        if isinstance(value, dict):
            safe_dict: dict[str, object] = {}
            for raw_key, raw_value in value.items():
                if not isinstance(raw_key, str):
                    continue
                safe_value = ChannelTurnKernel._json_safe_metadata_value(raw_value)
                if safe_value is not _DROP_METADATA_VALUE:
                    safe_dict[raw_key] = safe_value
            return safe_dict
        return _DROP_METADATA_VALUE


_DROP_METADATA_VALUE = object()
