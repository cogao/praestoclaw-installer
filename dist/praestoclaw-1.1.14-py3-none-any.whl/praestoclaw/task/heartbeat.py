"""Executor-side ``task.progress`` heartbeat emitter.

Phase-1 client side of the Task v1 progress loop. When the cloud
channel receives a task-bearing carrier (``content_type=application/
vnd.praestoclaw.task+json``), the agent loop becomes the *executor*
for that ``task_id``. The Gateway only emits coordinator-side
``task.progress`` envelopes for stage transitions (``gating``,
``waiting_approval``, ``executing``, terminal); the executor is the
only place that can tell the original sender "I'm still working on
it" between ``executing`` and the terminal stage.

This emitter ticks once per
:data:`EXECUTING_HEARTBEAT_INTERVAL_MS` (default 30 s, shared with the
Gateway via :mod:`agent_gateway_protocol`) while the agent loop is
processing the carrier turn, and stops as soon as the loop returns.
The Gateway forwards each beat to the original sender and uses
``next_heartbeat_ms`` to extend the executing-stage soft deadline
(spec §5; see issue #181).

The emitter is intentionally tiny and channel-agnostic: it accepts a
``send_event(topic, body)`` callable and an ``asyncio`` clock, so unit
tests can drive it deterministically without booting a CloudChannel.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable, Mapping
from typing import Any, Protocol

from agent_gateway_protocol.gateway_protocol.v1.task import (
    EXECUTING_HEARTBEAT_INTERVAL_MS,
    EXECUTING_HEARTBEAT_NEXT_MS,
    TASK_HARD_CAP_MS,
    TASK_PROGRESS_TOPIC,
)
from loguru import logger


class _EventSender(Protocol):
    """Minimal surface ``TaskHeartbeatEmitter`` needs from the channel.

    Matches :meth:`praestoclaw.gateway_protocol.business.outbound.Outbound.send_event`.
    """

    async def send_event(
        self,
        topic: str,
        body: Mapping[str, Any],
        *,
        headers: Mapping[str, Any] | None = ...,
    ) -> None: ...


# Re-export under heartbeat-local names so callers don't need two imports.
__all__ = [
    "EXECUTING_HEARTBEAT_INTERVAL_MS",
    "EXECUTING_HEARTBEAT_NEXT_MS",
    "TaskHeartbeatEmitter",
    "build_progress_body",
]


def build_progress_body(
    *,
    task_id: str,
    elapsed_ms: int,
    summary: str = "",
    details: Mapping[str, Any] | None = None,
    next_heartbeat_ms: int = EXECUTING_HEARTBEAT_NEXT_MS,
) -> dict[str, Any]:
    """Construct the wire body for a ``task.progress`` heartbeat.

    Shape mirrors the coordinator-emitted progress body (spec §5):
    ``{task_id, stage, elapsed_ms, summary, next_heartbeat_ms, details?}``.
    The Gateway does not interpret ``details``; whatever the pair
    agrees on goes through verbatim.
    """

    body: dict[str, Any] = {
        "task_id": task_id,
        "stage": "executing",
        "elapsed_ms": max(0, int(elapsed_ms)),
        "next_heartbeat_ms": max(0, int(next_heartbeat_ms)),
    }
    if summary:
        body["summary"] = summary
    if details:
        body["details"] = dict(details)
    return body


class TaskHeartbeatEmitter:
    """Periodically emit ``task.progress`` while an executor turn runs.

    Lifecycle is owned by the caller (the agent loop). Use the async
    context-manager form so the heartbeat task is always cancelled,
    even on exceptions::

        async with TaskHeartbeatEmitter(sender, task_id=tid, summary=s):
            await run_agent_turn(...)

    Guarantees:

    * Never emits past :data:`TASK_HARD_CAP_MS` of wall-clock time —
      mirrors the Gateway's hard cap so a runaway executor cannot keep
      the source waiting indefinitely.
    * ``stop()`` is idempotent and never raises.
    * Errors from ``send_event`` are logged and swallowed; a single
      lost heartbeat must not crash the agent loop.
    """

    def __init__(
        self,
        sender: _EventSender,
        *,
        task_id: str,
        summary: str = "",
        interval_ms: int = EXECUTING_HEARTBEAT_INTERVAL_MS,
        next_heartbeat_ms: int = EXECUTING_HEARTBEAT_NEXT_MS,
        hard_cap_ms: int = TASK_HARD_CAP_MS,
        started_at_ms: int | None = None,
        details_provider: Callable[[], Mapping[str, Any] | None] | None = None,
        clock: Callable[[], float] | None = None,
        sleep: Callable[[float], Awaitable[None]] | None = None,
    ) -> None:
        if interval_ms <= 0:
            raise ValueError("interval_ms must be positive")
        if hard_cap_ms <= 0:
            raise ValueError("hard_cap_ms must be positive")

        self._sender = sender
        self._task_id = task_id
        self._summary = summary
        self._interval_s = interval_ms / 1000.0
        self._next_heartbeat_ms = max(0, int(next_heartbeat_ms))
        self._hard_cap_ms = int(hard_cap_ms)
        self._details_provider = details_provider
        self._clock = clock or time.monotonic
        self._sleep = sleep or asyncio.sleep
        self._started_at = (started_at_ms / 1000.0) if started_at_ms is not None else None
        self._task: asyncio.Task[None] | None = None
        self._stopped = asyncio.Event()
        self._beats_emitted = 0

    # ── lifecycle ──────────────────────────────────────────────────

    async def __aenter__(self) -> TaskHeartbeatEmitter:
        self.start()
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        await self.stop()

    def start(self) -> None:
        """Start the heartbeat task. No-op if already running.

        Idempotent so callers can guard with ``if task_id: emitter.start()``
        without checking state.
        """

        if self._task is not None and not self._task.done():
            return
        if self._started_at is None:
            self._started_at = self._clock()
        self._stopped.clear()
        self._task = asyncio.create_task(
            self._run(),
            name=f"task-heartbeat:{self._task_id}",
        )

    async def stop(self) -> None:
        """Cancel the heartbeat task. Idempotent and never raises."""

        self._stopped.set()
        task = self._task
        if task is None:
            return
        self._task = None
        if task.done():
            return
        task.cancel()
        try:
            await task
        except (asyncio.CancelledError, Exception):  # noqa: BLE001
            # Swallow: stop() must never propagate. Cancellation is
            # expected; any other exception was already logged in _run().
            pass

    # ── introspection (for tests) ──────────────────────────────────

    @property
    def beats_emitted(self) -> int:
        return self._beats_emitted

    # ── internals ──────────────────────────────────────────────────

    def _elapsed_ms(self) -> int:
        if self._started_at is None:
            return 0
        return int((self._clock() - self._started_at) * 1000)

    async def _run(self) -> None:
        try:
            while not self._stopped.is_set():
                try:
                    await self._sleep(self._interval_s)
                except asyncio.CancelledError:
                    raise
                if self._stopped.is_set():
                    return
                elapsed_ms = self._elapsed_ms()
                if elapsed_ms >= self._hard_cap_ms:
                    logger.debug(
                        "task heartbeat reached hard cap task_id={} elapsed={}ms",
                        self._task_id,
                        elapsed_ms,
                    )
                    return
                details = None
                if self._details_provider is not None:
                    try:
                        details = self._details_provider()
                    except Exception as exc:  # noqa: BLE001
                        logger.debug(
                            "task heartbeat details_provider failed task_id={}: {}",
                            self._task_id,
                            exc,
                        )
                        details = None
                body = build_progress_body(
                    task_id=self._task_id,
                    elapsed_ms=elapsed_ms,
                    summary=self._summary,
                    details=details,
                    next_heartbeat_ms=self._next_heartbeat_ms,
                )
                try:
                    await self._sender.send_event(TASK_PROGRESS_TOPIC, body)
                    self._beats_emitted += 1
                except asyncio.CancelledError:
                    raise
                except Exception as exc:  # noqa: BLE001
                    # Best-effort: missing one beat is non-fatal, the
                    # Gateway will time the executing stage out if the
                    # whole loop dies. Stay silent at info level.
                    logger.warning(
                        "task heartbeat send failed task_id={}: {}",
                        self._task_id,
                        exc,
                    )
        except asyncio.CancelledError:
            return
