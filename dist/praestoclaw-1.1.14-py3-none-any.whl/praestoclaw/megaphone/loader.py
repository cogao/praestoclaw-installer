"""Megaphone loader — register monitoring cron jobs with the scheduler."""

from __future__ import annotations

import shutil
from typing import TYPE_CHECKING

from loguru import logger

from praestoclaw.megaphone.config import (
    MegaphoneConfig,
    config_path,
    example_config_path,
    load_config,
)

if TYPE_CHECKING:
    from praestoclaw.cron.service import SchedulerService

# Job name prefix — all megaphone jobs start with this
JOB_PREFIX = "megaphone-"
COMMON_EXCLUDED_TOOLS = ["shell", "notify", "search_history", "plan"]
TEAMS_CRON_PROMPT = (
    "megaphone scheduled scan source=teams; follow the Megaphone skill Teams standard flow"
)
EMAIL_CRON_PROMPT = (
    "megaphone scheduled scan source=email; follow the Megaphone skill Email standard flow"
)
CALENDAR_TODAY_PROMPT = (
    "megaphone scheduled scan source=calendar mode=today; "
    "follow the Megaphone skill Calendar standard flow"
)
CALENDAR_TOMORROW_PROMPT = (
    "megaphone scheduled scan source=calendar mode=tomorrow; "
    "follow the Megaphone skill Calendar standard flow"
)


def ensure_config() -> MegaphoneConfig:
    """Load config; if missing, copy example and return disabled config."""
    cfg_path = config_path()
    if not cfg_path.is_file():
        example = example_config_path()
        if example.is_file():
            cfg_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(example, cfg_path)
            logger.info("megaphone: copied example config to {}", cfg_path)
        else:
            logger.warning("megaphone: no example config found at {}", example)
            return MegaphoneConfig(enabled=False)
    return load_config(cfg_path)


def register_megaphone_jobs(
    scheduler: SchedulerService, config: MegaphoneConfig | None = None
) -> list[str]:
    """Register megaphone cron jobs. Returns list of registered job names."""
    if config is None:
        config = ensure_config()

    if not config.enabled:
        logger.info("megaphone: disabled in config, skipping job registration")
        return []

    registered: list[str] = []
    notify = config.notify_channels

    # Teams monitoring
    if config.teams.enabled and config.teams.chats:
        name = f"{JOB_PREFIX}teams"
        schedule = config.teams.schedule or config.schedule
        scheduler.add_job(
            name=name,
            schedule=schedule,
            prompt=TEAMS_CRON_PROMPT,
            notify_channels=notify,
            exclude_tools=[*COMMON_EXCLUDED_TOOLS, "MCP_mail*"],
            dynamic=True,
            session_mode="isolated",
        )
        registered.append(name)
        logger.info("megaphone: registered job '{}' schedule='{}'", name, schedule)

    # Email monitoring
    if config.email.enabled and config.email.rules:
        name = f"{JOB_PREFIX}email"
        schedule = config.email.schedule or config.schedule
        scheduler.add_job(
            name=name,
            schedule=schedule,
            prompt=EMAIL_CRON_PROMPT,
            notify_channels=notify,
            exclude_tools=[*COMMON_EXCLUDED_TOOLS, "MCP_teams*"],
            dynamic=True,
            session_mode="isolated",
        )
        registered.append(name)
        logger.info("megaphone: registered job '{}' schedule='{}'", name, schedule)

    # Calendar monitoring — two daily jobs (today's summary / tomorrow's preview)
    if config.calendar.enabled:
        cal_exclude = [*COMMON_EXCLUDED_TOOLS, "MCP_mail*", "MCP_teams*"]

        today_name = f"{JOB_PREFIX}calendar-today"
        scheduler.add_job(
            name=today_name,
            schedule=config.calendar.schedule_today,
            prompt=CALENDAR_TODAY_PROMPT,
            notify_channels=notify,
            exclude_tools=cal_exclude,
            dynamic=True,
            session_mode="isolated",
        )
        registered.append(today_name)
        logger.info(
            "megaphone: registered job '{}' schedule='{}'",
            today_name,
            config.calendar.schedule_today,
        )

        tomorrow_name = f"{JOB_PREFIX}calendar-tomorrow"
        scheduler.add_job(
            name=tomorrow_name,
            schedule=config.calendar.schedule_tomorrow,
            prompt=CALENDAR_TOMORROW_PROMPT,
            notify_channels=notify,
            exclude_tools=cal_exclude,
            dynamic=True,
            session_mode="isolated",
        )
        registered.append(tomorrow_name)
        logger.info(
            "megaphone: registered job '{}' schedule='{}'",
            tomorrow_name,
            config.calendar.schedule_tomorrow,
        )

    logger.info("megaphone: registered {} jobs: {}", len(registered), registered)

    if not config.auto_enable and registered:
        for name in registered:
            try:
                scheduler.disable(name)
            except Exception as exc:
                logger.warning("megaphone: failed to disable job '{}': {}", name, exc)
        logger.info(
            "megaphone: auto_enable=false — {} jobs registered but disabled. "
            "Trigger manually via agent cron tool (action='run', job_id='megaphone-<source>').",
            len(registered),
        )

    return registered


def unregister_megaphone_jobs(scheduler: SchedulerService) -> list[str]:
    """Remove all megaphone cron jobs. Returns list of removed job names."""
    removed: list[str] = []
    # Get current job names that start with our prefix
    for name in list(scheduler._jobs.keys()):
        if name.startswith(JOB_PREFIX):
            try:
                scheduler.remove_job(name)
                removed.append(name)
            except Exception as exc:
                logger.warning("megaphone: failed to remove job '{}': {}", name, exc)
    if removed:
        logger.info("megaphone: removed {} jobs: {}", len(removed), removed)
    return removed


def maybe_register_megaphone_jobs(
    scheduler: SchedulerService, config: MegaphoneConfig | None = None
) -> list[str]:
    """Convenience: register megaphone jobs only if config exists and is enabled.

    Safe to call during runtime startup — does not fail or raise.
    """
    try:
        cfg = config or load_config()
        if not cfg.enabled:
            return []
        return register_megaphone_jobs(scheduler, cfg)
    except Exception as exc:
        logger.warning("megaphone: failed to register jobs: {}", exc)
        return []
