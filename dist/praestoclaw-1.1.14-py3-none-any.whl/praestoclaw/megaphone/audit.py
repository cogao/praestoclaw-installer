"""Audit helpers for Megaphone cron source-read guards."""

from __future__ import annotations

import json
import re
from collections.abc import Iterator
from datetime import UTC, date, datetime
from pathlib import Path
from typing import Any

_SCHEDULER_SESSION_DATE = re.compile(r"^scheduler_megaphone-[^_]+_(\d{8})T")
_ERROR_PREFIXES = ("Error:", "Exception", "Traceback", "BLOCKED")


def audit_files_for_session(
    data_dir: Path, session_id: str, *, now: datetime | None = None
) -> list[Path]:
    """Return audit JSONL files that can contain entries for *session_id*."""
    current_date = (now or datetime.now(UTC)).date()
    dates: list[date] = []
    match = _SCHEDULER_SESSION_DATE.match(session_id)
    if match:
        dates.append(datetime.strptime(match.group(1), "%Y%m%d").date())
    dates.append(current_date)

    seen: set[date] = set()
    files: list[Path] = []
    for day in dates:
        if day in seen:
            continue
        seen.add(day)
        path = data_dir / "audit" / f"audit-{day.isoformat()}.jsonl"
        if path.exists():
            files.append(path)
    return files


def audit_entry_session_id(entry: dict[str, Any]) -> str:
    """Return the session id recorded on an audit entry, if present."""
    args = entry.get("args") or {}
    return str(entry.get("session_id") or args.get("_session_id") or "")


def audit_entry_is_failure(entry: dict[str, Any]) -> bool:
    """Return true when an audit entry represents a failed tool call."""
    if bool(entry.get("is_error")):
        return True
    preview = str(entry.get("result_preview") or "").lstrip()
    if preview.startswith(_ERROR_PREFIXES):
        return True
    return preview.startswith("MCP server ") or preview.startswith("MCP tool ")


def iter_session_audit_entries(data_dir: Path, session_id: str) -> Iterator[dict[str, Any]]:
    """Yield audit entries for *session_id* from the relevant rotated audit files."""
    for audit_file in audit_files_for_session(data_dir, session_id):
        with audit_file.open("r", encoding="utf-8") as handle:
            for line in handle:
                if session_id not in line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if audit_entry_session_id(entry) == session_id:
                    yield entry
