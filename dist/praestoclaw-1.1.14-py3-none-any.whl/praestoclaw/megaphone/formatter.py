"""Megaphone output formatter — Teams-friendly markdown notifications with deep links.

All timestamps are rendered deterministically in the user's display_timezone
(see MegaphoneConfig.display_timezone). Upstream code is responsible for
attaching aware datetimes to AlertItem.timestamp; this formatter never does
timezone math implicitly — None timestamps simply omit the time prefix.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from loguru import logger


@dataclass
class AlertItem:
    """A single alert item for megaphone notifications."""

    category: str  # 'teams' | 'email' | 'calendar'
    source: str  # channel name / email rule name / repo name
    summary: str  # one-line summary (should NOT contain a timestamp — formatter adds it)
    link: str  # deep link URL
    priority: str = "normal"  # 'high' | 'normal'
    timestamp: datetime | None = field(default=None)
    """Aware datetime of the underlying event (msg received, PR closed, etc.).

    MUST be timezone-aware. Naive datetimes are assumed UTC and a warning is logged.
    The formatter converts this to the user's display_timezone at render time.
    Set to None for items that have no meaningful single timestamp (e.g. a
    multi-event calendar preview).
    """


# ── Constants ──────────────────────────────────────────────────────────────────

CATEGORY_EMOJI: dict[str, str] = {
    "teams": "💬",
    "email": "📧",
    "calendar": "📅",
}

CATEGORY_TITLE: dict[str, dict[str, str]] = {
    "zh-CN": {
        "teams": "Teams 群消息",
        "email": "邮件",
        "calendar": "日历提醒",
    },
    "en": {
        "teams": "Teams Messages",
        "email": "Email",
        "calendar": "Calendar",
    },
}

CATEGORY_ORDER: list[str] = ["teams", "email", "calendar"]

DEFAULT_DISPLAY_TZ = "Asia/Shanghai"

ACTION_LABEL: dict[str, str] = {
    "zh-CN": "打开",
    "en": "Open",
}


# ── Time formatting ────────────────────────────────────────────────────────────


def _resolve_tz(tz_name: str) -> ZoneInfo:
    """Resolve an IANA timezone name, falling back to UTC with a warning."""
    try:
        return ZoneInfo(tz_name)
    except ZoneInfoNotFoundError:
        logger.warning("megaphone: unknown timezone {!r}, falling back to UTC", tz_name)
        return ZoneInfo("UTC")


def _format_timestamp(ts: datetime, tz: ZoneInfo, *, today: date | None = None) -> str:
    """Render an aware datetime in the user's display zone.

    - same calendar day as `today` (in display zone) → "HH:MM"
    - within the previous 6 days → "周三 HH:MM" / "Wed HH:MM" style would need
      locale; we keep it simple: "MM-DD HH:MM"
    - else → "YYYY-MM-DD HH:MM"

    `today` is injected for testability; defaults to current date in `tz`.
    """
    if ts.tzinfo is None:
        logger.warning("megaphone: naive timestamp {!r}, assuming UTC", ts)
        ts = ts.replace(tzinfo=ZoneInfo("UTC"))
    local = ts.astimezone(tz)
    today = today or datetime.now(tz).date()
    if local.date() == today:
        return local.strftime("%H:%M")
    # within last/next ~7 days → drop year for compactness
    if abs((local.date() - today).days) <= 6:
        return local.strftime("%m-%d %H:%M")
    return local.strftime("%Y-%m-%d %H:%M")


def _time_prefix(item: AlertItem, tz: ZoneInfo, today: date) -> str:
    """Return '[HH:MM] ' or empty string."""
    if item.timestamp is None:
        return ""
    return f"[{_format_timestamp(item.timestamp, tz, today=today)}] "


def _markdown_link_suffix(link: str, action_label: str) -> str:
    """Return a markdown action link when a usable URL is present."""
    link = link.strip()
    if not link:
        return ""
    return f"  [{action_label}]({link})"


def _plain_link_suffix(link: str, action_label: str) -> str:
    """Return a plain-text action link when a usable URL is present."""
    link = link.strip()
    if not link:
        return ""
    return f"  {action_label}: {link}"


# ── Notification Formatters ────────────────────────────────────────────────────


def format_notification(
    items: list[AlertItem],
    language: str = "zh-CN",
    display_timezone: str = DEFAULT_DISPLAY_TZ,
) -> str:
    """Format alert items into Teams-friendly markdown notification.

    All `item.timestamp` values are converted to *display_timezone* and prepended
    to each line as `[HH:MM]` (or `[MM-DD HH:MM]` for cross-day items).
    """
    if not items:
        return ""

    titles = CATEGORY_TITLE.get(language, CATEGORY_TITLE["zh-CN"])
    action_label = ACTION_LABEL.get(language, ACTION_LABEL["zh-CN"])
    header = "📢 **小喇叭提醒**" if language != "en" else "📢 **Megaphone Alert**"
    tz = _resolve_tz(display_timezone)
    today = datetime.now(tz).date()

    # Group items by category
    grouped: dict[str, list[AlertItem]] = {}
    for item in items:
        grouped.setdefault(item.category, []).append(item)

    sections: list[str] = [header, ""]

    for cat in CATEGORY_ORDER:
        cat_items = grouped.get(cat)
        if not cat_items:
            continue
        emoji = CATEGORY_EMOJI.get(cat, "📌")
        title = titles.get(cat, cat)
        sections.append(f"{emoji} **{title}**")
        sections.append("")
        for item in cat_items:
            prefix = "🔴 " if item.priority == "high" else "• "
            tprefix = _time_prefix(item, tz, today)
            sections.append(
                f"{prefix}**{item.source}**  {tprefix}{item.summary}"
                f"{_markdown_link_suffix(item.link, action_label)}"
            )
            sections.append("")

    return "\n".join(sections).rstrip()


def format_notification_plain(
    items: list[AlertItem],
    language: str = "zh-CN",
    display_timezone: str = DEFAULT_DISPLAY_TZ,
) -> str:
    """Format alert items into plain text notification (no markdown)."""
    if not items:
        return ""

    titles = CATEGORY_TITLE.get(language, CATEGORY_TITLE["zh-CN"])
    action_label = ACTION_LABEL.get(language, ACTION_LABEL["zh-CN"])
    header = "📢 小喇叭提醒" if language != "en" else "📢 Megaphone Alert"
    tz = _resolve_tz(display_timezone)
    today = datetime.now(tz).date()

    # Group items by category
    grouped: dict[str, list[AlertItem]] = {}
    for item in items:
        grouped.setdefault(item.category, []).append(item)

    sections: list[str] = [header, ""]

    for cat in CATEGORY_ORDER:
        cat_items = grouped.get(cat)
        if not cat_items:
            continue
        emoji = CATEGORY_EMOJI.get(cat, "📌")
        title = titles.get(cat, cat)
        sections.append(f"{emoji} {title}")
        sections.append("")
        for item in cat_items:
            prefix = "🔴 " if item.priority == "high" else "• "
            tprefix = _time_prefix(item, tz, today)
            sections.append(
                f"{prefix}{item.source}  {tprefix}{item.summary}"
                f"{_plain_link_suffix(item.link, action_label)}"
            )
            sections.append("")

    return "\n".join(sections).rstrip()


# ── Deep Link Builders ─────────────────────────────────────────────────────────


def build_teams_message_link(team_id: str, channel_id: str, message_id: str) -> str:
    """Build a deep link to a specific Teams message."""
    return (
        f"https://teams.microsoft.com/l/message/{channel_id}/{message_id}"
        f"?groupId={team_id}&parentMessageId={message_id}"
    )


def build_email_link(message_id: str) -> str:
    """Build a deep link to a specific Outlook email."""
    return f"https://outlook.office365.com/mail/inbox/id/{message_id}"
