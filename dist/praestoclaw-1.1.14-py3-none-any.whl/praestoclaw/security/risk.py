"""
Risk assessment types and policy table for the v2 scoring model.

Defines the core data types (RiskScore, RiskPrompt) and the policy table
that maps (score × profile) → action.  This module is the single source
of truth for policy decisions — all other modules import from here.

Design spec: docs/design/core/security-classification.md
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from praestoclaw.config.schema import SecurityProfile

# ── Assessment types ─────────────────────────────────────────────────────────


@dataclass(frozen=True, slots=True)
class RiskScore:
    """Deterministic risk assessment — LLM is skipped.

    Returned by ``Tool.assess_risk()`` when the outcome is certain
    (e.g. ``rm -rf /`` → score 10), or by the LLM scorer after evaluation.
    """

    score: int | None  # 0-10, or None when unassessable
    reason: str


@dataclass(frozen=True, slots=True)
class RiskPrompt:
    """Ambiguous risk assessment — delegates to LLM scorer.

    Structured format that enables:
    - Conservative fallback computation from ``range``
    - Consistent prompt generation across all tools
    - Machine-readable range, signals, and factors for logging/analytics

    ``context`` describes the operation.  ``range`` is the expected score range
    (lo, hi) for LLM guidance — **required** so the scorer can always compute
    a fallback.  ``factors`` are human-readable scoring lines inserted into the
    prompt as provided; labels may be numeric or textual (e.g. ``"5: description"``,
    ``"Lower: ..."``, ``"Higher: ..."``).  ``signals`` are machine-readable hint
    labels (``"network"``, ``"elevated"``).

    The ``prompt`` property auto-generates the text sent to the LLM scorer,
    matching the format the system prompt expects (Range / Scoring factors).
    """

    context: str
    range: tuple[int, int]
    factors: tuple[str, ...] = ()
    signals: tuple[str, ...] = ()
    exclude_args: frozenset[str] = frozenset()  # arg keys to omit from scorer prompt

    @property
    def prompt(self) -> str:
        """Generate text prompt for LLM scorer."""
        parts: list[str] = [self.context]
        if self.signals:
            parts.append(f"Detected: {', '.join(self.signals)}.")
        parts.append(f"Range: {self.range[0]}~{self.range[1]}")
        if self.factors:
            parts.append("Scoring factors:\n" + "\n".join(f"  {f}" for f in self.factors))
        return "\n".join(parts)


RiskAssessment = RiskScore | RiskPrompt

# ── Policy actions ───────────────────────────────────────────────────────────


class PolicyAction(str, Enum):
    """Actions the policy table can produce."""

    AUTO = "auto"  # execute immediately
    TIMEOUT_AUTO = "timeout_auto"  # notify user; auto-execute after timeout
    HUMAN = "human"  # wait for explicit Approve / Deny
    REJECT = "reject"  # blocked; error returned to agent


# ── Policy table ─────────────────────────────────────────────────────────────
#
# Encodes security-classification.md §2 as code.
#
# Each profile maps to a list of (score_range, action, always_allow_available).
# Ranges are checked in order; first match wins.
# Scores are integers 0-10; None (null) is handled separately.

_A = PolicyAction.AUTO
_T = PolicyAction.TIMEOUT_AUTO
_H = PolicyAction.HUMAN
_R = PolicyAction.REJECT

# (min_score_inclusive, max_score_exclusive, action, always_allow_available)
_Rule = tuple[int, int, PolicyAction, bool]

_PROFILE_RULES: dict[SecurityProfile, list[_Rule]] = {
    # ── open ──────────────────────────────────────────────────────────
    SecurityProfile.OPEN: [
        (0, 1, _A, False),  # [0, 1)  Auto
        (1, 3, _A, False),  # [1, 3)  Auto
        (3, 5, _A, False),  # [3, 5)  Auto
        (5, 7, _A, False),  # [5, 7)  Auto
        (7, 9, _T, True),  # [7, 9)  Timeout-auto  (Always Allow available)
        (9, 10, _H, True),  # [9, 10) Human         (Always Allow available)
        (10, 11, _R, False),  # 10      Reject
    ],
    # ── standard ──────────────────────────────────────────────────────
    SecurityProfile.STANDARD: [
        (0, 1, _A, False),  # [0, 1)  Auto
        (1, 3, _A, False),  # [1, 3)  Auto
        (3, 5, _A, False),  # [3, 5)  Auto
        (
            5,
            6,
            _A,
            False,
        ),  # [5, 6)  Auto          (recoverable: push personal branch, pip install -e)
        (6, 7, _T, True),  # [6, 7)  Timeout-auto  (Always Allow available)
        (7, 9, _H, True),  # [7, 9)  Human         (Always Allow available)
        (9, 10, _H, False),  # [9, 10) Human (1)     (Always Allow hidden)
        (10, 11, _R, False),  # 10      Reject
    ],
    # ── controlled ────────────────────────────────────────────────────
    SecurityProfile.CONTROLLED: [
        (0, 1, _A, False),  # [0, 1)  Auto
        (1, 3, _A, False),  # [1, 3)  Auto
        (3, 5, _T, True),  # [3, 5)  Timeout-auto  (Always Allow available)
        (5, 7, _H, True),  # [5, 7)  Human         (Always Allow available)
        (7, 9, _H, True),  # [7, 9)  Human         (Always Allow available)
        (9, 10, _R, False),  # [9, 10) Reject
        (10, 11, _R, False),  # 10      Reject
    ],
    # ── restricted ────────────────────────────────────────────────────
    SecurityProfile.RESTRICTED: [
        (0, 1, _A, False),  # [0, 1)  Auto
        (1, 3, _T, False),  # [1, 3)  Timeout-auto
        (3, 5, _H, True),  # [3, 5)  Human (+)     (Always Allow available)
        (5, 7, _H, False),  # [5, 7)  Human (1)     (Always Allow hidden)
        (7, 9, _H, False),  # [7, 9)  Human (1)     (Always Allow hidden)
        (9, 10, _R, False),  # [9, 10) Reject
        (10, 11, _R, False),  # 10      Reject
    ],
}

# null score rules per profile (security-classification.md §2.2)
_NULL_RULES: dict[SecurityProfile, tuple[PolicyAction, bool]] = {
    SecurityProfile.OPEN: (_H, True),  # Human, Always Allow available
    SecurityProfile.STANDARD: (_H, True),  # Human, Always Allow available
    SecurityProfile.CONTROLLED: (_H, False),  # Human (1), Always Allow hidden
    SecurityProfile.RESTRICTED: (_H, False),  # Human (1), Always Allow hidden
}


def lookup_policy(
    score: int | None,
    profile: SecurityProfile | str,
) -> tuple[PolicyAction, bool]:
    """Map a risk score and security profile to a policy action.

    Parameters
    ----------
    score:
        Integer 0-10, or ``None`` when the score cannot be assessed.
    profile:
        Security profile (enum or string value).

    Returns
    -------
    tuple[PolicyAction, bool]
        ``(action, always_allow_available)``
    """
    if isinstance(profile, str):
        profile = SecurityProfile(profile)

    # null score — always human, per-profile Always Allow rules
    if score is None:
        return _NULL_RULES[profile]

    # Clamp out-of-range scores (security-classification.md §5.6)
    if score < 0:
        return _NULL_RULES[profile]  # treat as null
    if score > 10:
        score = 10

    rules = _PROFILE_RULES[profile]
    for lo, hi, action, always_allow in rules:
        if lo <= score < hi:
            return action, always_allow

    # Should never reach here, but fail-safe to Human
    return _H, False
