"""
Loader for the bundled ``defaults/STARTER_PROMPTS.yaml`` file.

The same starter prompts feed two surfaces:

* The Web Portal welcome screen renders them as chips.
* The Teams welcome card renders the top N as Adaptive Card actions.

Single source of truth
----------------------
The YAML file holds **one** ``prompts:`` list shared across channels.
Per-channel customisation is opt-in via ``label_<channel>`` overrides
(for cases where Teams' narrow buttons need a shorter label than the
web chips). Example::

    prompts:
      - id: ado_my_bugs
        icon: "\U0001f41e"
        label: "\u67e5\u770b\u6211\u7684 ADO bug"
        label_teams: "\u6211\u7684 ADO bug"   # optional, narrower button
        prompt: "..."
        tag: ado

Channel-specific render limits live next to the loader (Adaptive Cards
cap usefully at ~6 actions; the Web chip strip wraps freely so it has
no default cap).

For back-compat the old nested ``web:`` / ``teams:`` schema is still
accepted; if present, the per-channel section wins over ``prompts:``.

We load once at import time, validate the shape, and return cheap
defensive copies on every call so callers can mutate freely.
"""

from __future__ import annotations

import copy
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml
from loguru import logger

_DEFAULTS_DIR = Path(__file__).resolve().parent
_STARTER_PROMPTS_PATH = _DEFAULTS_DIR / "STARTER_PROMPTS.yaml"

# Required keys per prompt entry.
_REQUIRED_KEYS = ("id", "label", "prompt")
_KNOWN_CHANNELS = ("web", "teams")

# Per-channel render caps applied when the caller doesn't pass ``limit``.
# ``None`` means "no cap" (let the renderer wrap as needed).
#
# Teams Adaptive Cards render the first ~3 actions inline and fold the
# rest into a "More" overflow menu, so 6 is a comfortable maximum that
# still surfaces meaningful breadth on first click.
_CHANNEL_DEFAULT_LIMITS: dict[str, int | None] = {
    "web": None,
    "teams": 6,
}


def _validate_entry(entry: Any) -> dict[str, Any] | None:
    """Return the entry if it has all required keys, else ``None``."""
    if not isinstance(entry, dict):
        return None
    missing = [k for k in _REQUIRED_KEYS if not entry.get(k)]
    if missing:
        logger.warning(
            "starter_prompts: dropping entry missing keys {}: {}",
            missing,
            entry.get("id") or "<no-id>",
        )
        return None
    return entry


@lru_cache(maxsize=1)
def _load_raw() -> dict[str, list[dict[str, Any]]]:
    """Parse the YAML and return ``{channel: [entry, ...]}`` per channel.

    Supports both the new single ``prompts:`` schema and the legacy
    nested ``web:`` / ``teams:`` schema (legacy wins per-channel).
    Per-channel ``label_<channel>`` overrides are folded into ``label``
    here, so callers see a uniform shape.
    """
    if not _STARTER_PROMPTS_PATH.exists():
        logger.warning("starter_prompts: file missing at {}", _STARTER_PROMPTS_PATH)
        return {ch: [] for ch in _KNOWN_CHANNELS}
    try:
        data = yaml.safe_load(_STARTER_PROMPTS_PATH.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        logger.warning("starter_prompts: YAML parse failed ({}): {}", _STARTER_PROMPTS_PATH, exc)
        return {ch: [] for ch in _KNOWN_CHANNELS}

    if not isinstance(data, dict):
        logger.warning("starter_prompts: top-level must be a mapping, got {}", type(data))
        return {ch: [] for ch in _KNOWN_CHANNELS}

    raw_prompts = data.get("prompts")
    shared_raw: list[Any] = raw_prompts if isinstance(raw_prompts, list) else []
    shared: list[dict[str, Any]] = [e for e in (_validate_entry(x) for x in shared_raw) if e]

    out: dict[str, list[dict[str, Any]]] = {}
    for channel in _KNOWN_CHANNELS:
        legacy = data.get(channel)
        if isinstance(legacy, list):
            entries = [e for e in (_validate_entry(x) for x in legacy) if e]
        else:
            entries = shared

        # Fold ``label_<channel>`` overrides into ``label``; strip all
        # ``label_*`` keys from the public view so renderers don't need
        # to know about the override mechanism.
        rendered: list[dict[str, Any]] = []
        override_key = f"label_{channel}"
        for entry in entries:
            view = {k: v for k, v in entry.items() if not k.startswith("label_")}
            override = entry.get(override_key)
            if isinstance(override, str) and override.strip():
                view["label"] = override
            rendered.append(view)
        out[channel] = rendered
    return out


def get_starter_prompts(channel: str, *, limit: int | None = None) -> list[dict[str, Any]]:
    """Return the starter prompts for ``channel`` (defensive deep copy).

    Parameters
    ----------
    channel:
        ``"web"`` or ``"teams"``. Unknown channels return ``[]``.
    limit:
        Cap on how many prompts to return. When ``None`` (the default)
        the per-channel default from ``_CHANNEL_DEFAULT_LIMITS`` applies
        (web = uncapped, teams = 6). Pass an explicit integer to
        override; pass a negative value to disable the default cap.
    """
    if channel not in _KNOWN_CHANNELS:
        return []
    raw = _load_raw().get(channel, [])
    effective_limit = limit if limit is not None else _CHANNEL_DEFAULT_LIMITS.get(channel)
    if effective_limit is not None and effective_limit >= 0:
        raw = raw[:effective_limit]
    return copy.deepcopy(raw)


__all__ = ["get_starter_prompts"]
