"""Project detection — turn an environment snapshot into a ranked project list.

The detector is intentionally split into:

* :class:`DetectionEnv` — a pure-data snapshot of signals (no IO).
* :func:`collect_env` — the IO-touching collector. Cheap and bounded
  (timeouts, depth/count limits) so ``pc init`` stays snappy.
* :func:`detect_projects` — the pure scoring function over the snapshot.

This split keeps unit tests trivial: feed a hand-built ``DetectionEnv`` and
assert which project ids come out, without needing a real filesystem or
subprocess.
"""

from __future__ import annotations

import os
import re
import subprocess
import time
from collections import Counter
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from urllib.parse import unquote, urlparse

from loguru import logger

from praestoclaw.projects.registry import BUILTIN_PROJECTS, Project

# Hard caps so collect_env never becomes a noticeable wizard hang.
_MAX_REPOS_SCANNED = 80
_MAX_SCAN_DEPTH = 4
_PER_GIT_TIMEOUT_S = 1.5
_TOTAL_BUDGET_S = 10.0
# The GitHub org we run targeted activity / repo-candidate queries against.
# Re-exported as ``GITHUB_ACTIVITY_ORG`` so CLI/UX layers can build user-facing
# messages without importing a private name from this module.
_GITHUB_ACTIVITY_ORG = "infinity-microsoft"
GITHUB_ACTIVITY_ORG = _GITHUB_ACTIVITY_ORG
_GITHUB_ACTIVITY_PER_PAGE = 100
_GITHUB_PERSONAL_ACTIVITY_REPO_LIMIT = 10
_GITHUB_PERSONAL_ACTIVITY_LOOKBACK_DAYS = 90
_GITHUB_ACTIVITY_TIMEOUT_S = 1.5
_GITHUB_PERSONAL_ACTIVITY_TIMEOUT_S = 8.0
_GITHUB_CREDENTIAL_TIMEOUT_S = 5.0


@dataclass(frozen=True)
class DetectionEnv:
    """Pure-data snapshot of project-detection signals."""

    # Raw remote URLs from any ``.git/config`` we found, lowercased.
    git_remotes: tuple[str, ...] = ()

    # Lowercased basenames of cwd/recent-cwd/repo dirs we scanned.
    repo_basenames: tuple[str, ...] = ()

    # Absolute filesystem paths of git repos we walked. Ordering is
    # cwd-repo-root first (when cwd is inside a git working tree),
    # followed by repos discovered during the workspace scan in walk
    # order. The list is deduped on resolved absolute path. Note this
    # is *not* index-aligned with ``ado_repos`` — many repos here may
    # have no ADO remote at all (e.g. GitHub clones), and ``ado_repos``
    # is independently deduped on the parsed ``(org, project, repo)``
    # triple. Stored as strings to keep the dataclass trivially
    # picklable / serialisable. Consumers that want to scan
    # ``<repo>/.claude/`` (team-maintained skills, MCP settings) read
    # this instead of re-walking the disk.
    repo_paths: tuple[str, ...] = ()

    # Lowercased ADO org names extracted from configured MCP servers
    # and from git remotes that look like dev.azure.com URLs.
    ado_orgs_seen: tuple[str, ...] = ()

    # Full ADO triples ``(org, project, repo)`` parsed out of every
    # ADO/VSTS git remote we found. Lowercased, ordered most-recent
    # first (cwd before the wider workspace scan). Used by ADO/bluebird
    # MCP setup to fill in defaults without re-running ``git remote``.
    ado_repos: tuple[tuple[str, str, str], ...] = ()

    # Lowercased GitHub organization names extracted from local remotes
    # and from targeted recent-activity discovery. We intentionally do
    # not infer project affinity from org membership alone.
    github_orgs_seen: tuple[str, ...] = ()

    # Lowercased GitHub repo slugs (``owner/repo``) parsed from local git
    # remotes discovered on disk.
    github_repos: tuple[str, ...] = ()

    # Lowercased GitHub repo slugs (``owner/repo``) ranked by authenticated
    # recent activity. Currently targeted to ``infinity-microsoft``.
    github_activity_repos: tuple[str, ...] = ()

    # Lowercased GitHub repo slugs discovered from authenticated user
    # contributions. Repo contents can later be scanned for ``.claude/``
    # assets, but detection should still be driven by explicit activity/local
    # remotes.
    github_candidate_repos: tuple[str, ...] = ()

    # Entra group object IDs from id_token claims (advisory only).
    entra_groups: tuple[str, ...] = ()

    # Free-form extras we keep for the resolver to log "why this project".
    notes: tuple[str, ...] = ()


# ---------------------------------------------------------------------------
# Pure scoring
# ---------------------------------------------------------------------------


def detect_projects(env: DetectionEnv) -> dict[str, list[str]]:
    """Score every built-in project against ``env``.

    Returns a mapping ``{project_id: [signal_strings, ...]}`` containing only
    projects that produced at least one **strong** signal match. The default
    project is always included with an empty signal list so callers can
    surface it as the unconditional baseline.

    Strong signals: git remote pattern, ADO org, GitHub org/repo pattern,
    repo-name pattern.
    Weak signals (Entra group) are recorded but cannot trigger a match
    on their own.
    """
    matches: dict[str, list[str]] = {}

    for project in BUILTIN_PROJECTS:
        if project.is_default:
            matches[project.id] = []
            continue

        signals: list[str] = []
        d = project.detect

        for pat in d.git_remote_patterns:
            needle = pat.lower()
            for remote in env.git_remotes:
                if needle in remote:
                    signals.append(f"git remote: {remote}")
                    break

        for org in d.ado_orgs:
            if org.lower() in env.ado_orgs_seen:
                signals.append(f"ADO org: {org}")

        for org in d.github_orgs:
            org_l = org.lower()
            if org_l in env.github_orgs_seen:
                activity_repo = next(
                    (repo for repo in env.github_activity_repos if repo.startswith(f"{org_l}/")),
                    "",
                )
                local_repo = next(
                    (repo for repo in env.github_repos if repo.startswith(f"{org_l}/")),
                    "",
                )
                if activity_repo:
                    signals.append(f"GitHub recent activity: {activity_repo}")
                elif local_repo:
                    signals.append(f"GitHub remote: {local_repo}")
                else:
                    signals.append(f"GitHub org: {org_l}")

        github_repo_slugs = (*env.github_activity_repos, *env.github_repos)
        for pat in d.github_repo_patterns:
            needle = pat.lower()
            for repo_slug in github_repo_slugs:
                if needle in repo_slug:
                    signals.append(f"GitHub repo: {repo_slug}")
                    break

        for pat in d.repo_name_patterns:
            needle = pat.lower()
            for base in env.repo_basenames:
                if needle in base:
                    signals.append(f"repo: {base}")
                    break

        # Entra group is advisory; it boosts existing matches but can't
        # create one. This guards against an over-eager group-membership
        # rule recommending 200 skills to someone whose machine has no
        # actual Edge / Societas footprint.
        if signals:
            for gid in d.entra_groups:
                if gid in env.entra_groups:
                    signals.append(f"entra group: {gid}")
            # Dedupe while preserving order.
            seen: set[str] = set()
            uniq: list[str] = []
            for s in signals:
                if s not in seen:
                    seen.add(s)
                    uniq.append(s)
            matches[project.id] = uniq

    return matches


# ---------------------------------------------------------------------------
# IO collection
# ---------------------------------------------------------------------------


_GIT_REMOTE_RE = re.compile(r"^\s*url\s*=\s*(\S+)\s*$", re.MULTILINE)
_ADO_HOST_RE = re.compile(
    r"(?:https?://|git@)(?:[^/@]+@)?dev\.azure\.com[/:]([^/]+)/", re.IGNORECASE
)
_ADO_VISUALSTUDIO_RE = re.compile(r"(?:https?://|git@)([^/@.]+)\.visualstudio\.com", re.IGNORECASE)


def _candidate_scan_roots() -> list[Path]:
    """Reasonable places to look for git checkouts on the user's machine.

    Cheap and bounded: we don't recurse into the entire home dir.
    """
    home = Path.home()
    candidates = [
        Path.cwd(),
        home / "src",
        home / "source",
        home / "repos",
        home / "code",
        home / "dev",
        home / "Projects",
        home / "Documents" / "GitHub",
        # ~/edge is the Edge team enlistment parent on macOS/Linux —
        # houses chromium and any sibling repos. Detection is still
        # **per-repo**: each repo's git remote / name is matched
        # independently against the project rules in registry.py, so
        # being inside ~/edge does not automatically tag you as any
        # particular project.
        home / "edge",
    ]
    if os.name == "nt":
        # Generic dev convention.
        candidates.extend([Path("C:/src"), Path("D:/src")])
        # Edge enlistment lives at ``<drive>:\edge`` on Windows. The
        # drive letter varies by user setup (Q: is a common ``subst``
        # to whatever physical drive holds the enlistment). Probe a
        # handful of common letters; non-existent drives are filtered
        # out by the ``p.is_dir()`` pass below at zero cost.
        for drive in ("C", "D", "E", "F", "Q"):
            candidates.append(Path(f"{drive}:/edge"))
    return [p for p in candidates if p.is_dir()]


def _walk_git_dirs(root: Path, *, deadline: float) -> list[Path]:
    """Yield ``.git`` directory paths under ``root`` up to depth 4.

    Stops early when ``deadline`` (a ``time.monotonic`` value) elapses or
    the global cap of repos is hit.
    """
    found: list[Path] = []
    queue: list[tuple[Path, int]] = [(root, 0)]
    while queue:
        if time.monotonic() > deadline or len(found) >= _MAX_REPOS_SCANNED:
            break
        cur, depth = queue.pop(0)
        try:
            entries = list(cur.iterdir())
        except OSError:
            continue
        for entry in entries:
            if not entry.is_dir():
                continue
            name = entry.name
            if name == ".git":
                found.append(entry)
                continue
            if name.startswith(".") or name in {
                "node_modules",
                "__pycache__",
                "venv",
                ".venv",
                "target",
                "build",
                "dist",
            }:
                continue
            if depth + 1 <= _MAX_SCAN_DEPTH:
                queue.append((entry, depth + 1))
    return found


def _read_remotes(git_dir: Path) -> list[str]:
    """Extract ``url = …`` lines from ``<git_dir>/config``."""
    cfg = git_dir / "config"
    try:
        text = cfg.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    return [m.group(1).strip() for m in _GIT_REMOTE_RE.finditer(text)]


def _resolve_git_config_dir(repo: Path) -> Path | None:
    """Locate the git directory to read ``config`` from for ``repo``.

    Handles three on-disk layouts:

    * **normal repo** — ``<repo>/.git`` is a directory (returned as-is);
    * **submodule** — ``<repo>/.git`` is a file ``gitdir: <path>`` pointing at
      ``…/.git/modules/<name>``, which holds ``config`` directly;
    * **worktree** — ``<repo>/.git`` is a file pointing at
      ``…/.git/worktrees/<name>``, whose ``commondir`` locates the shared
      ``.git`` that holds the (worktree-wide) ``config``.

    Returns the best directory to read ``config`` from; for a valid but
    config-less layout it still returns the (real) private git dir so
    basename-based detection keeps working. Returns ``None`` when ``repo`` is
    not a git repo — no ``.git`` entry, or a ``.git`` file whose ``gitdir:``
    pointer is missing, malformed, or does not reference a real git dir.
    """
    git_path = repo / ".git"
    if git_path.is_dir():
        return git_path
    if not git_path.is_file():
        return None

    try:
        pointer = git_path.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return None
    prefix = "gitdir:"
    if not pointer.lower().startswith(prefix):
        return None
    raw = pointer[len(prefix) :].strip()
    if not raw:
        return None

    # A submodule pointer is relative to the submodule (= ``repo``) directory;
    # a worktree pointer is usually absolute. Both resolve the same way.
    git_dir = Path(raw)
    if not git_dir.is_absolute():
        git_dir = repo / git_dir
    try:
        git_dir = git_dir.resolve()
    except (OSError, RuntimeError, ValueError):
        return None
    # ``Path.resolve`` does not require the target to exist, and an existing
    # directory alone is not proof of a git dir. Require a ``HEAD`` file —
    # present in every real git dir, including worktree-private and submodule
    # module dirs — so a stray ``.git`` file (e.g. ``gitdir: /tmp`` or an
    # orphaned worktree) cannot make a non-repo match basename detection.
    if not (git_dir / "HEAD").is_file():
        return None

    # Worktrees keep ``config`` in the shared common dir, located via the
    # ``commondir`` pointer (relative to the private worktree git dir).
    # Submodules have no ``commondir`` and hold ``config`` in ``git_dir``.
    commondir_file = git_dir / "commondir"
    try:
        relative_common = commondir_file.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        relative_common = ""
    if relative_common:
        common_dir = Path(relative_common)
        if not common_dir.is_absolute():
            common_dir = git_dir / common_dir
        try:
            resolved_common = common_dir.resolve()
        except (OSError, RuntimeError, ValueError):
            resolved_common = git_dir
        # Only follow ``commondir`` when it resolves to a real git common dir
        # — one that looks like a git dir (``HEAD`` present) and holds the
        # ``config`` we want to read. A corrupt or foreign pointer otherwise
        # falls back to the valid private git dir.
        if (resolved_common / "HEAD").is_file() and (resolved_common / "config").is_file():
            git_dir = resolved_common
    return git_dir


def detection_env_for_repo(repo: Path) -> DetectionEnv | None:
    """Build a minimal :class:`DetectionEnv` from a single repo path.

    Reads the repo's ``config`` to extract the remote URLs and parses ADO and
    GitHub signals from them. Resolves git worktree and submodule ``.git``
    pointer files (see :func:`_resolve_git_config_dir`) so those layouts are
    detected too. Returns ``None`` if the path is not a git repo. Used by
    callers that need to evaluate ``detect_projects`` against one specific repo
    (e.g. profile-gated ``.claude`` import filtering) without re-running the
    full workspace scan in :func:`get_detection_env`.
    """
    git_dir = _resolve_git_config_dir(repo)
    if git_dir is None:
        return None

    remotes = _read_remotes(git_dir)
    ado_orgs: list[str] = []
    github_orgs: list[str] = []
    github_repos: list[str] = []
    for remote in remotes:
        ado_org = _ado_org_from_remote(remote)
        if ado_org:
            ado_orgs.append(ado_org)
        github_repo = _github_repo_from_remote(remote)
        if github_repo:
            owner, repo_name = github_repo
            github_orgs.append(owner)
            github_repos.append(f"{owner}/{repo_name}")

    return DetectionEnv(
        git_remotes=tuple(r.lower() for r in remotes if r),
        repo_basenames=(repo.name.lower(),),
        ado_orgs_seen=tuple(sorted(set(ado_orgs))),
        github_orgs_seen=tuple(sorted(set(github_orgs))),
        github_repos=tuple(dict.fromkeys(github_repos)),
    )


def _ado_org_from_remote(remote: str) -> str | None:
    """Return the lowercased ADO org if ``remote`` is an Azure DevOps URL."""
    m = _ADO_HOST_RE.search(remote)
    if m:
        return m.group(1).lower()
    m = _ADO_VISUALSTUDIO_RE.search(remote)
    if m:
        return m.group(1).lower()
    return None


def _ado_triple_from_remote(remote: str) -> tuple[str, str, str] | None:
    """Parse a remote URL into ``(org, project, repo)`` if it's ADO-shaped.

    Recognised forms (case-insensitive):

    * ``https://dev.azure.com/<org>/<project>/_git/<repo>``
    * ``https://dev.azure.com/<org>/_git/<repo>`` (collection-default project)
    * ``git@ssh.dev.azure.com:v3/<org>/<project>/<repo>``
    * ``https://<org>.visualstudio.com/<project>/_git/<repo>``
    * ``https://<org>.visualstudio.com/_git/<repo>`` (collection-default project)

    Path segments are URL-decoded so e.g. ``SAN%20SA`` becomes ``san sa``.
    Anything missing is returned as ``""`` (e.g. an org-only URL gives
    ``("contoso", "", "")``) so callers can still pick up the org.
    Returns ``None`` for non-ADO remotes.
    """
    if not remote:
        return None
    r = remote.strip()
    rl = r.lower()

    # https / http
    for prefix in ("https://", "http://"):
        if rl.startswith(prefix):
            tail = r[len(prefix) :]
            # strip optional ``user@`` (PAT-in-URL)
            if "@" in tail.split("/", 1)[0]:
                tail = tail.split("@", 1)[1]
            host, _, path = tail.partition("/")
            host_l = host.lower()
            # URL-decode each segment so e.g. "SAN%20SA" → "san sa".
            parts = [unquote(p) for p in path.split("/") if p]
            if host_l == "dev.azure.com" and parts:
                org = parts[0]
                project, repo = _split_project_repo(parts[1:])
                return (org.lower(), project.lower(), _strip_git_suffix(repo))
            if host_l.endswith(".visualstudio.com"):
                org = host_l.split(".", 1)[0]
                project, repo = _split_project_repo(parts)
                return (org, project.lower(), _strip_git_suffix(repo))
            return None

    # SCP-style: git@ssh.dev.azure.com:v3/org/project/repo
    if "@" in r and ":" in r:
        try:
            _, host_path = r.rsplit("@", 1)
            host, _, path = host_path.partition(":")
        except ValueError:
            return None
        if host.lower() == "ssh.dev.azure.com":
            parts = [unquote(p) for p in path.split("/") if p]
            # Expect: v3, org, project, repo
            if len(parts) >= 2 and parts[0].lower() == "v3":
                org = parts[1].lower() if len(parts) >= 2 else ""
                project = parts[2].lower() if len(parts) >= 3 else ""
                repo = parts[3] if len(parts) >= 4 else ""
                return (org, project, _strip_git_suffix(repo))
    return None


def _github_repo_from_remote(remote: str) -> tuple[str, str] | None:
    """Parse a GitHub remote URL into ``(owner, repo)``.

    Recognised forms (case-insensitive host):

    * ``https://github.com/<owner>/<repo>``
    * ``https://token@github.com/<owner>/<repo>.git``
    * ``git@github.com:<owner>/<repo>.git``
    * ``ssh://git@github.com/<owner>/<repo>.git``
    """
    if not remote:
        return None
    r = remote.strip()
    rl = r.lower()

    if rl.startswith(("https://", "http://", "ssh://")):
        parsed = urlparse(r)
        if (parsed.hostname or "").lower() != "github.com":
            return None
        parts = [unquote(p) for p in parsed.path.split("/") if p]
        if len(parts) < 2:
            return None
        return (parts[0].lower(), _strip_git_suffix(parts[1]))

    # SCP-style SSH: git@github.com:owner/repo.git
    if "@" in r and ":" in r:
        try:
            _, host_path = r.rsplit("@", 1)
            host, _, path = host_path.partition(":")
        except ValueError:
            return None
        if host.lower() != "github.com":
            return None
        parts = [unquote(p) for p in path.split("/") if p]
        if len(parts) < 2:
            return None
        return (parts[0].lower(), _strip_git_suffix(parts[1]))

    return None


def _github_token_for_activity(*, deadline: float | None = None) -> str | None:
    """Return the GitHub token managed by Git Credential Manager, if any.

    No process-level memoization — ``git credential fill`` is sub-100 ms
    when GCM has a credential cached, and the call is invoked at most a
    handful of times per ``pc init`` run (project detection +
    marketplace install + external import). A previous version of this
    function memoized the result for the lifetime of the process, but
    that turned out to be a footgun: when GCM rotated its cached token
    mid-init (e.g. after the marketplace clone hit 401 and triggered a
    fresh OAuth round-trip with a working EMU account), the stale
    cached ``None`` from the first probe would silently break the
    downstream team ``.claude/`` scan. GCM and Windows Credential
    Manager are already the right layer to cache; we just ask them.
    """
    timeout = _GITHUB_CREDENTIAL_TIMEOUT_S
    if deadline is not None:
        remaining = deadline - time.monotonic()
        if remaining <= 0.2:
            return None
        timeout = max(0.2, min(_GITHUB_CREDENTIAL_TIMEOUT_S, remaining))

    return _github_token_from_git_credential(timeout=timeout)


def _github_token_from_git_credential(
    *, timeout: float = _GITHUB_CREDENTIAL_TIMEOUT_S
) -> str | None:
    """Best-effort token lookup from Git Credential Manager without logging it."""
    from praestoclaw.security.github_auth import github_token_from_git_credential

    return github_token_from_git_credential(timeout=timeout)


def _github_remaining_timeout(deadline: float, cap: float) -> float | None:
    remaining = deadline - time.monotonic()
    if remaining <= 0.2:
        return None
    return max(0.2, min(cap, remaining))


def _github_error_message(resp: object) -> str:
    """Best-effort GitHub REST error message without leaking response bodies."""
    try:
        data = resp.json()  # type: ignore[attr-defined]
    except Exception:
        return ""
    if not isinstance(data, dict):
        return ""
    message = data.get("message")
    if not isinstance(message, str) or not message:
        return ""
    return f" ({message[:120]})"


def _collect_github_activity_repos(
    *,
    org: str = _GITHUB_ACTIVITY_ORG,
    deadline: float,
    token: str | None = None,
) -> tuple[list[str], list[str]]:
    """Return ranked ``owner/repo`` slugs from recent GitHub org activity.

    The call is targeted to ``infinity-microsoft`` and uses existing local
    credentials only. Any auth, network, visibility, or rate-limit issue
    returns ``([], [note])`` instead of failing init.

    ``token`` may be supplied by the caller to avoid a duplicate ``git
    credential fill`` subprocess when the credential was already fetched
    upstream (e.g. by ``collect_env`` for its gating decision). When
    omitted, the token is fetched lazily.
    """
    remaining = deadline - time.monotonic()
    if remaining <= 0.2:
        return [], ["GitHub activity skipped: scan budget exceeded"]

    if token is None:
        token = _github_token_for_activity(deadline=deadline)
    if not token:
        return [], []

    remaining = deadline - time.monotonic()
    if remaining <= 0.2:
        return [], ["GitHub activity skipped: scan budget exceeded"]

    timeout = max(0.2, min(_GITHUB_ACTIVITY_TIMEOUT_S, remaining))
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}",
        "User-Agent": "PraestoClaw-FRE",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    org_l = org.lower()

    try:
        import httpx

        with httpx.Client(timeout=timeout, headers=headers) as http:
            user_resp = http.get("https://api.github.com/user")
            if user_resp.status_code in (401, 403):
                return [], [
                    "GitHub activity unavailable: "
                    f"/user HTTP {user_resp.status_code}{_github_error_message(user_resp)}"
                ]
            user_resp.raise_for_status()
            login = user_resp.json().get("login")
            if not isinstance(login, str) or not login:
                return [], ["GitHub activity unavailable: /user missing login"]

            if time.monotonic() >= deadline:
                return [], ["GitHub activity skipped: scan budget exceeded"]

            events_resp = http.get(
                f"https://api.github.com/users/{login}/events/orgs/{org_l}",
                params={"per_page": str(_GITHUB_ACTIVITY_PER_PAGE)},
            )
            if events_resp.status_code in (401, 403, 404):
                return [], [
                    "GitHub activity unavailable: "
                    f"{org_l} events HTTP {events_resp.status_code}"
                    f"{_github_error_message(events_resp)}"
                ]
            events_resp.raise_for_status()
            events = events_resp.json()
    except Exception as exc:
        return [], [f"GitHub activity unavailable: {exc.__class__.__name__}"]

    if not isinstance(events, list):
        return [], ["GitHub activity unavailable: events response was not a list"]

    repo_order: dict[str, int] = {}
    counts: Counter[str] = Counter()
    for idx, event in enumerate(events):
        if not isinstance(event, dict):
            continue
        repo = event.get("repo")
        if not isinstance(repo, dict):
            continue
        name = repo.get("name")
        if not isinstance(name, str):
            continue
        slug = name.strip().lower()
        if not slug.startswith(f"{org_l}/"):
            continue
        counts[slug] += 1
        repo_order.setdefault(slug, idx)

    return (
        sorted(counts, key=lambda slug: (-counts[slug], repo_order[slug])),
        [],
    )


def _collect_github_search_activity_repos(
    http: object,
    *,
    org: str,
    login: str,
    from_date: str,
    deadline: float | None = None,
) -> tuple[list[str], list[str]]:
    """Rank repos from user-specific GitHub search results.

    This is used when org-scoped events/GraphQL contribution APIs are blocked
    but the credential can still search private repos. Queries are explicitly
    scoped to the current user as author/reviewer/commenter, so this is not an
    org-wide recency fallback.
    """
    org_l = org.lower()
    repo_dates: dict[str, str] = {}
    counts: Counter[str] = Counter()
    notes: list[str] = []

    def record(slug: str, when: str) -> None:
        slug_l = slug.strip().lower()
        if not slug_l.startswith(f"{org_l}/") or not when:
            return
        counts[slug_l] += 1
        if when > repo_dates.get(slug_l, ""):
            repo_dates[slug_l] = when

    def request_timeout() -> float | None:
        if deadline is None:
            return None
        return _github_remaining_timeout(deadline, _GITHUB_PERSONAL_ACTIVITY_TIMEOUT_S)

    timeout = request_timeout()
    if deadline is not None and timeout is None:
        return [], ["GitHub search skipped: scan budget exceeded"]

    commit_resp = http.get(  # type: ignore[attr-defined]
        "https://api.github.com/search/commits",
        params={
            "q": f"org:{org_l} author:{login} author-date:>{from_date}",
            "sort": "author-date",
            "order": "desc",
            "per_page": "50",
        },
        timeout=timeout,
    )
    if commit_resp.status_code == 200:
        data = commit_resp.json()
        if isinstance(data, dict):
            for item in data.get("items", []):
                if not isinstance(item, dict):
                    continue
                repo = item.get("repository")
                full_name = repo.get("full_name") if isinstance(repo, dict) else None
                commit = item.get("commit")
                author = commit.get("author") if isinstance(commit, dict) else None
                when = author.get("date") if isinstance(author, dict) else None
                if isinstance(full_name, str) and isinstance(when, str):
                    record(full_name, when)
    elif commit_resp.status_code not in (401, 403, 404, 422):
        notes.append(f"GitHub commit search HTTP {commit_resp.status_code}")

    issue_queries = (
        f"org:{org_l} is:pr author:{login} updated:>{from_date}",
        f"org:{org_l} is:pr reviewed-by:{login} updated:>{from_date}",
        f"org:{org_l} is:pr commenter:{login} updated:>{from_date}",
        f"org:{org_l} is:issue author:{login} updated:>{from_date}",
        f"org:{org_l} is:issue commenter:{login} updated:>{from_date}",
    )
    for query in issue_queries:
        timeout = request_timeout()
        if deadline is not None and timeout is None:
            notes.append("GitHub search skipped: scan budget exceeded")
            break
        resp = http.get(  # type: ignore[attr-defined]
            "https://api.github.com/search/issues",
            params={"q": query, "sort": "updated", "order": "desc", "per_page": "50"},
            timeout=timeout,
        )
        if resp.status_code != 200:
            if resp.status_code not in (401, 403, 404, 422):
                notes.append(f"GitHub issue search HTTP {resp.status_code}")
            continue
        data = resp.json()
        if not isinstance(data, dict):
            continue
        for item in data.get("items", []):
            if not isinstance(item, dict):
                continue
            repo_url = item.get("repository_url")
            when = item.get("updated_at")
            if not isinstance(repo_url, str) or not isinstance(when, str):
                continue
            marker = "/repos/"
            if marker not in repo_url:
                continue
            record(repo_url.rsplit(marker, 1)[-1], when)

    ranked = sorted(repo_dates, key=lambda slug: (repo_dates[slug], counts[slug]), reverse=True)
    return ranked[:_GITHUB_PERSONAL_ACTIVITY_REPO_LIMIT], notes


def _collect_github_candidate_repos(
    *,
    org: str = _GITHUB_ACTIVITY_ORG,
    deadline: float,
    token: str | None = None,
) -> tuple[list[str], list[str]]:
    """Return repos ranked by the authenticated user's recent contributions.

    This intentionally does *not* fall back to org-wide ``updated`` recency.
    The candidate list feeds remote ``.claude/`` import, so ranking must be
    based on activity by the current user: commits, PRs, PR reviews, or issues
    surfaced by GitHub's contributions graph for ``infinity-microsoft``.

    ``token`` may be supplied to avoid a duplicate ``git credential fill``
    subprocess when the credential was already fetched upstream.
    """
    remaining = deadline - time.monotonic()
    if remaining <= 0.2:
        return [], ["GitHub repo candidates skipped: scan budget exceeded"]

    if token is None:
        token = _github_token_for_activity(deadline=deadline)
    if not token:
        return [], []

    remaining = deadline - time.monotonic()
    if remaining <= 0.2:
        return [], ["GitHub repo candidates skipped: scan budget exceeded"]

    timeout = _github_remaining_timeout(deadline, _GITHUB_PERSONAL_ACTIVITY_TIMEOUT_S)
    if timeout is None:
        return [], ["GitHub repo candidates skipped: scan budget exceeded"]
    headers = {
        "Authorization": f"Bearer {token}",
        "User-Agent": "PraestoClaw-FRE",
    }
    org_l = org.lower()
    from_dt = datetime.now(UTC) - timedelta(days=_GITHUB_PERSONAL_ACTIVITY_LOOKBACK_DAYS)
    from_iso = from_dt.isoformat().replace("+00:00", "Z")

    try:
        import httpx

        login: str | None = None
        with httpx.Client(timeout=timeout, headers=headers) as http:
            request_timeout = _github_remaining_timeout(
                deadline, _GITHUB_PERSONAL_ACTIVITY_TIMEOUT_S
            )
            if request_timeout is None:
                return [], ["GitHub repo candidates skipped: scan budget exceeded"]
            user_resp = http.get("https://api.github.com/user", timeout=request_timeout)
            if user_resp.status_code in (401, 403):
                return [], [
                    "GitHub repo candidates unavailable: "
                    f"/user HTTP {user_resp.status_code}{_github_error_message(user_resp)}"
                ]
            user_resp.raise_for_status()
            login = user_resp.json().get("login")
            if not isinstance(login, str) or not login:
                return [], ["GitHub repo candidates unavailable: /user missing login"]

            request_timeout = _github_remaining_timeout(
                deadline, _GITHUB_PERSONAL_ACTIVITY_TIMEOUT_S
            )
            if request_timeout is None:
                return [], ["GitHub repo candidates skipped: scan budget exceeded"]
            org_resp = http.post(
                "https://api.github.com/graphql",
                json={
                    "query": """
                    query($org: String!) {
                      organization(login: $org) { id login }
                      viewer { login }
                    }
                    """,
                    "variables": {"org": org_l},
                },
                timeout=request_timeout,
            )
            if org_resp.status_code in (401, 403):
                search_repos, search_notes = _collect_github_search_activity_repos(
                    http,
                    org=org_l,
                    login=login,
                    from_date=from_iso[:10],
                    deadline=deadline,
                )
                if search_repos:
                    return search_repos, search_notes
                return [], [
                    "GitHub repo candidates unavailable: "
                    f"GraphQL HTTP {org_resp.status_code}{_github_error_message(org_resp)}"
                ] + search_notes
            org_resp.raise_for_status()
            org_data = org_resp.json()
            if not isinstance(org_data, dict) or org_data.get("errors"):
                search_repos, search_notes = _collect_github_search_activity_repos(
                    http,
                    org=org_l,
                    login=login,
                    from_date=from_iso[:10],
                    deadline=deadline,
                )
                if search_repos:
                    return search_repos, search_notes
                return [], [
                    "GitHub repo candidates unavailable: GraphQL org lookup failed"
                ] + search_notes
            org_id = (
                ((org_data.get("data") or {}).get("organization") or {}).get("id")
                if isinstance(org_data.get("data"), dict)
                else None
            )
            if not isinstance(org_id, str) or not org_id:
                search_repos, search_notes = _collect_github_search_activity_repos(
                    http,
                    org=org_l,
                    login=login,
                    from_date=from_iso[:10],
                    deadline=deadline,
                )
                if search_repos:
                    return search_repos, search_notes
                return [], [
                    f"GitHub repo candidates unavailable: {org_l} org id missing"
                ] + search_notes

            request_timeout = _github_remaining_timeout(
                deadline, _GITHUB_PERSONAL_ACTIVITY_TIMEOUT_S
            )
            if request_timeout is None:
                return [], ["GitHub repo candidates skipped: scan budget exceeded"]

            resp = http.post(
                "https://api.github.com/graphql",
                json={
                    "query": """
                    query($orgId: ID!, $from: DateTime!) {
                      viewer {
                        contributionsCollection(organizationID: $orgId, from: $from) {
                          commitContributionsByRepository(maxRepositories: 20) {
                            repository { nameWithOwner }
                            contributions(first: 10) { nodes { occurredAt } }
                          }
                          pullRequestContributionsByRepository(maxRepositories: 20) {
                            repository { nameWithOwner }
                            contributions(first: 10) { nodes { occurredAt } }
                          }
                          pullRequestReviewContributionsByRepository(maxRepositories: 20) {
                            repository { nameWithOwner }
                            contributions(first: 10) { nodes { occurredAt } }
                          }
                          issueContributionsByRepository(maxRepositories: 20) {
                            repository { nameWithOwner }
                            contributions(first: 10) { nodes { occurredAt } }
                          }
                        }
                      }
                    }
                    """,
                    "variables": {"orgId": org_id, "from": from_iso},
                },
                timeout=request_timeout,
            )
            if resp.status_code in (401, 403):
                return [], [
                    "GitHub repo candidates unavailable: "
                    f"GraphQL HTTP {resp.status_code}{_github_error_message(resp)}"
                ]
            resp.raise_for_status()
            data = resp.json()
    except Exception as exc:
        return [], [f"GitHub repo candidates unavailable: {exc.__class__.__name__}"]

    if not isinstance(data, dict):
        return [], ["GitHub repo candidates unavailable: GraphQL response was not an object"]
    if data.get("errors"):
        # Fall back to REST issue/commit search, which works for some private
        # repos where GraphQL org/contribution fields are blocked by scopes.
        try:
            import httpx

            with httpx.Client(timeout=timeout, headers=headers) as http:
                if isinstance(login, str) and login:
                    search_repos, search_notes = _collect_github_search_activity_repos(
                        http,
                        org=org_l,
                        login=login,
                        from_date=from_iso[:10],
                        deadline=deadline,
                    )
                    if search_repos:
                        return search_repos, search_notes
                    return [], [
                        "GitHub repo candidates unavailable: GraphQL contributions query failed"
                    ] + search_notes
        except Exception as exc:
            return [], [f"GitHub repo candidates unavailable: {exc.__class__.__name__}"]
        return [], ["GitHub repo candidates unavailable: GraphQL contributions query failed"]

    collection = (
        ((data.get("data") or {}).get("viewer") or {}).get("contributionsCollection")
        if isinstance(data.get("data"), dict)
        else None
    )
    if not isinstance(collection, dict):
        return [], ["GitHub repo candidates unavailable: contributions missing"]

    repo_dates: dict[str, str] = {}
    counts: Counter[str] = Counter()
    for key in (
        "commitContributionsByRepository",
        "pullRequestContributionsByRepository",
        "pullRequestReviewContributionsByRepository",
        "issueContributionsByRepository",
    ):
        entries = collection.get(key)
        if not isinstance(entries, list):
            continue
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            repo = entry.get("repository")
            full_name = repo.get("nameWithOwner") if isinstance(repo, dict) else None
            if not isinstance(full_name, str):
                continue
            slug = full_name.strip().lower()
            if not slug.startswith(f"{org_l}/"):
                continue
            nodes = (entry.get("contributions") or {}).get("nodes")
            if not isinstance(nodes, list):
                continue
            for node in nodes:
                if not isinstance(node, dict):
                    continue
                occurred_at = node.get("occurredAt")
                if not isinstance(occurred_at, str) or not occurred_at:
                    continue
                counts[slug] += 1
                if occurred_at > repo_dates.get(slug, ""):
                    repo_dates[slug] = occurred_at

    ranked = sorted(repo_dates, key=lambda slug: (repo_dates[slug], counts[slug]), reverse=True)
    if not ranked:
        try:
            import httpx

            with httpx.Client(timeout=timeout, headers=headers) as http:
                if isinstance(login, str) and login:
                    search_repos, search_notes = _collect_github_search_activity_repos(
                        http,
                        org=org_l,
                        login=login,
                        from_date=from_iso[:10],
                        deadline=deadline,
                    )
                    if search_repos:
                        return search_repos, search_notes
        except Exception as exc:
            return [], [f"GitHub repo candidates unavailable: {exc.__class__.__name__}"]
        return [], [
            "GitHub repo candidates unavailable: no personal contributions found "
            f"in {org_l} over the last {_GITHUB_PERSONAL_ACTIVITY_LOOKBACK_DAYS} days"
        ]
    return ranked[:_GITHUB_PERSONAL_ACTIVITY_REPO_LIMIT], []


# Sentinel for "caller probed for a token already and it came back missing".
# Distinguishes that case from "caller didn't probe yet" (token=None default)
# so downstream helpers can skip a redundant ``git credential fill``.
_TOKEN_PROBED_MISSING = ""


def _collect_github_remote_repo_candidates(
    *,
    deadline: float | None = None,
    token: str | None = None,
) -> tuple[list[str], list[str], list[str]]:
    """Return remote GitHub repos for optional team ``.claude/`` import.

    ``token`` semantics:
        * ``None``  \u2014 caller did not probe; we probe once here.
        * ``""``    \u2014 caller probed and found no credential cached;
                      skip downstream helpers (they would also short-circuit).
        * non-empty \u2014 caller pre-fetched a real token; reuse it.

    This protocol guarantees ``git credential fill`` runs at most once per
    call regardless of whether the caller pre-probed.
    """
    scan_deadline = deadline if deadline is not None else (time.monotonic() + _TOTAL_BUDGET_S)
    # Distinguish "deadline exhausted" from "no credential" here so callers
    # still get a diagnostic note in the budget-exceeded path. Without this
    # the wrapper would silently return ``([], [], [])`` on tight budgets,
    # masking the timeout from the wizard's diagnostic line.
    if scan_deadline - time.monotonic() <= 0.2:
        return [], [], ["GitHub remote repo discovery skipped: scan budget exceeded"]
    if token is None:
        token = _github_token_for_activity(deadline=scan_deadline) or _TOKEN_PROBED_MISSING
    if not token:
        # Either the caller passed the explicit "probed and missing"
        # sentinel or our own probe came back empty. Both downstream
        # queries would return ``([], [])`` after their own redundant
        # credential probe, so skip them entirely.
        return [], [], []
    activity_repos, activity_notes = _collect_github_activity_repos(
        deadline=scan_deadline, token=token
    )
    candidate_repos, candidate_notes = _collect_github_candidate_repos(
        deadline=scan_deadline, token=token
    )
    return (
        list(dict.fromkeys(activity_repos)),
        list(dict.fromkeys(candidate_repos)),
        activity_notes + candidate_notes,
    )


def _split_project_repo(segments: list[str]) -> tuple[str, str]:
    """Pull ``(project, repo)`` out of an ADO URL's path segments.

    The canonical separator between them is the literal ``_git`` segment;
    when it appears, project is the segment immediately before it and
    repo is the segment immediately after.  When ``_git`` is the *first*
    segment (collection-default project, e.g.
    ``office.visualstudio.com/_git/Sydney``) project is empty rather than
    being mistakenly set to ``"_git"``.

    The ``_git`` marker is matched case-insensitively (ADO/VSTS URLs are
    case-insensitive end-to-end) so unusual casings like ``_Git`` or
    ``_GIT`` don't accidentally fall through to positional parsing.
    """
    if not segments:
        return ("", "")
    git_idx = next(
        (i for i, seg in enumerate(segments) if seg.lower() == "_git"),
        -1,
    )
    if git_idx >= 0:
        project = segments[git_idx - 1] if git_idx >= 1 else ""
        repo = segments[git_idx + 1] if git_idx + 1 < len(segments) else ""
        return (project, repo)
    # No ``_git`` marker (e.g. ssh-style or partial URLs): fall back to
    # positional reading.
    project = segments[0] if segments else ""
    repo = segments[1] if len(segments) >= 2 else ""
    return (project, repo)


def _strip_git_suffix(repo: str) -> str:
    return repo[:-4].lower() if repo.lower().endswith(".git") else repo.lower()


def _entra_groups_from_claims(claims: dict | None) -> tuple[str, ...]:
    if not isinstance(claims, dict):
        return ()
    raw = claims.get("groups")
    if not isinstance(raw, list):
        return ()
    return tuple(str(g) for g in raw if g)


def _git_remote_for_cwd() -> list[str]:
    """``git remote -v`` for the current directory (best-effort)."""
    try:
        result = subprocess.run(
            ["git", "remote", "-v"],
            capture_output=True,
            text=True,
            timeout=_PER_GIT_TIMEOUT_S,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return []
    if result.returncode != 0:
        return []
    out: list[str] = []
    for line in result.stdout.splitlines():
        parts = line.split()
        if len(parts) >= 2:
            out.append(parts[1])
    return out


def _git_toplevel_for_cwd() -> Path | None:
    """``git rev-parse --show-toplevel`` for the current directory.

    Returns the working-tree root for cwd when cwd is inside a git
    repo (even from a deeply nested subdirectory), or ``None`` when
    cwd is not inside a git repo or git is unavailable. Best-effort:
    same timeout / error swallowing as :func:`_git_remote_for_cwd`,
    so a hung or missing git binary cannot block ``pc init``.
    """
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            timeout=_PER_GIT_TIMEOUT_S,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    line = result.stdout.strip()
    if not line:
        return None
    try:
        return Path(line)
    except (OSError, ValueError):
        return None


def collect_env(*, id_token_claims: dict | None = None) -> DetectionEnv:
    """Gather project-detection signals from the local machine.

    All collection is wall-clock bounded by ``_TOTAL_BUDGET_S``. Errors are
    swallowed — a missing git config is not an init blocker. Pass
    ``id_token_claims`` if you already have them (e.g. from a recent MSAL
    acquire); otherwise group-based detection is simply skipped.
    """
    deadline = time.monotonic() + _TOTAL_BUDGET_S

    remotes: list[str] = []
    repo_bases: list[str] = []
    repo_dirs: list[Path] = []
    ado_orgs: list[str] = []
    github_orgs: list[str] = []
    github_repos: list[str] = []
    github_activity_repos: list[str] = []
    github_candidate_repos: list[str] = []
    notes: list[str] = []

    # 1. cwd (cheapest signal — most likely match for an active developer).
    remotes.extend(_git_remote_for_cwd())
    cwd = Path.cwd()
    repo_bases.append(cwd.name.lower())
    # Find the working-tree root for cwd so consumers (e.g. team
    # .claude/ scan) hit it first. Cheap filesystem check for
    # ``cwd/.git`` first; if that fails (init invoked from a nested
    # subdirectory) fall back to ``git rev-parse --show-toplevel``
    # so the actual repo root — where team ``.claude/`` lives — is
    # still discovered.
    if (cwd / ".git").exists():
        repo_dirs.append(cwd)
    else:
        toplevel = _git_toplevel_for_cwd()
        if toplevel is not None:
            repo_dirs.append(toplevel)
            repo_bases.append(toplevel.name.lower())

    # 2. Walk a few well-known dev roots for ``.git`` configs.
    for root in _candidate_scan_roots():
        if time.monotonic() > deadline:
            notes.append(f"scan budget exceeded at {root}")
            break
        for git_dir in _walk_git_dirs(root, deadline=deadline):
            repo_bases.append(git_dir.parent.name.lower())
            remotes.extend(_read_remotes(git_dir))
            repo_dirs.append(git_dir.parent)

    # 3. Derive ADO and GitHub repo signals from any URL we collected.
    #    ``ordered_remotes`` preserves insertion order (cwd first, then
    #    workspace scan) so the resulting ``ado_repos`` list is roughly
    #    "most relevant first" — the ADO MCP setup picks ``[0]``.
    ado_triples: list[tuple[str, str, str]] = []
    seen_triples: set[tuple[str, str, str]] = set()
    for remote in remotes:
        org = _ado_org_from_remote(remote)
        if org:
            ado_orgs.append(org)
        triple = _ado_triple_from_remote(remote)
        if triple and triple not in seen_triples:
            seen_triples.add(triple)
            ado_triples.append(triple)
        github_repo = _github_repo_from_remote(remote)
        if github_repo:
            owner, repo = github_repo
            github_orgs.append(owner)
            github_repos.append(f"{owner}/{repo}")

    # 4. Targeted GitHub recent activity — best-effort. The network-backed
    # discovery is hard-targeted to Infinity repos, so we only run it when
    # we have *some* signal the user is actually working with that org:
    # either a local Infinity remote exists already, or the user has a
    # github.com credential cached in GCM (i.e. they're a GitHub-EMU user
    # who likely has access to internal repos). The latter condition is
    # the one that matters for first-run init on a fresh machine: there's
    # no local clone yet, but as soon as ``init`` step 6 walks the user
    # through GCM sign-in we have a token to query the org with.
    # Probe the GitHub credential exactly once: reuse the result for both
    # the gating decision below and the activity helpers so we don't
    # spawn ``git credential fill`` 2-3 times per env collection. We
    # convert a missing probe to the ``_TOKEN_PROBED_MISSING`` sentinel
    # so the downstream helper distinguishes "caller already probed and
    # got nothing" from "caller didn't probe" \u2014 otherwise it would
    # silently re-probe and the "exactly once" guarantee would break.
    cached_token = _github_token_for_activity(deadline=deadline) or _TOKEN_PROBED_MISSING
    should_query_github_activity = any(
        slug.startswith(f"{_GITHUB_ACTIVITY_ORG}/") for slug in github_repos
    ) or bool(cached_token)
    if should_query_github_activity:
        activity_repos, candidate_repos, activity_notes = _collect_github_remote_repo_candidates(
            deadline=deadline, token=cached_token
        )
        github_activity_repos.extend(activity_repos)
        github_orgs.extend(slug.split("/", 1)[0] for slug in activity_repos if "/" in slug)
        notes.extend(activity_notes)

        github_candidate_repos.extend(candidate_repos)

    # 5. ADO MCP server config (already-configured user) — best-effort.
    try:
        from praestoclaw.config.loader import load_config

        cfg = load_config(".")
        mcp_servers = getattr(getattr(cfg, "tools", None), "mcp_servers", {}) or {}
        for srv in mcp_servers.values():
            opts = getattr(srv, "options", None) or {}
            org = opts.get("organization") or opts.get("ado_org")
            if isinstance(org, str) and org:
                ado_orgs.append(org.lower())
    except Exception as exc:
        logger.debug("Project detection: skipped ADO MCP config scan ({})", exc)

    # Dedupe + lowercase.
    remotes_lc = tuple(sorted({r.lower() for r in remotes if r}))
    repo_bases_lc = tuple(sorted({b for b in repo_bases if b}))
    ado_orgs_lc = tuple(sorted(set(ado_orgs)))
    github_orgs_lc = tuple(sorted(set(github_orgs)))
    github_repos_lc = tuple(dict.fromkeys(github_repos))
    github_activity_repos_lc = tuple(dict.fromkeys(github_activity_repos))
    github_candidate_repos_lc = tuple(dict.fromkeys(github_candidate_repos))
    entra = _entra_groups_from_claims(id_token_claims)

    # Dedupe repo paths while preserving most-recent-first order.
    seen_paths: set[str] = set()
    repo_paths_str: list[str] = []
    for d in repo_dirs:
        try:
            p = str(d.resolve())
        except OSError:
            p = str(d)
        if p not in seen_paths:
            seen_paths.add(p)
            repo_paths_str.append(p)

    return DetectionEnv(
        git_remotes=remotes_lc,
        repo_basenames=repo_bases_lc,
        repo_paths=tuple(repo_paths_str),
        ado_orgs_seen=ado_orgs_lc,
        ado_repos=tuple(ado_triples),
        github_orgs_seen=github_orgs_lc,
        github_repos=github_repos_lc,
        github_activity_repos=github_activity_repos_lc,
        github_candidate_repos=github_candidate_repos_lc,
        entra_groups=entra,
        notes=tuple(notes),
    )


def detected_project_objects(env: DetectionEnv) -> list[Project]:
    """Convenience: turn :func:`detect_projects` output into ordered :class:`Project`s.

    Default project comes first, then any matched non-default projects in the
    order declared in :data:`BUILTIN_PROJECTS`.
    """
    matches = detect_projects(env)
    out: list[Project] = []
    for project in BUILTIN_PROJECTS:
        if project.id in matches and (project.is_default or matches[project.id]):
            out.append(project)
    return out


# Process-wide memoization so every init substep — MCP setup, project
# subscription, the marketplace resolver — pays for ``collect_env``
# exactly once. ``pc init`` is a single short-lived process so we don't
# need expiry logic; tests can pass ``refresh=True`` to bust the cache.
_CACHED_ENV: DetectionEnv | None = None


def get_detection_env(
    *,
    id_token_claims: dict | None = None,
    refresh: bool = False,
) -> DetectionEnv:
    """Return a memoized :class:`DetectionEnv` for the current process.

    First call runs :func:`collect_env`; later calls return the cached
    snapshot. Pass ``refresh=True`` to force a re-scan (e.g. after the
    user runs ``git clone`` mid-init).
    """
    global _CACHED_ENV
    if refresh or _CACHED_ENV is None:
        _CACHED_ENV = collect_env(id_token_claims=id_token_claims)
    return _CACHED_ENV


def invalidate_detection_env_cache() -> None:
    """Forget any cached ``DetectionEnv`` snapshot.

    The detection env is memoized so multiple ``get_detection_env()``
    callers in the same process share one snapshot. After a mid-init
    credential change (e.g. the GCM popup at the start of step 6) the
    cached env was built without a GitHub token and will therefore
    have empty ``github_activity_repos`` / ``github_candidate_repos``
    lists. Call this so the next ``get_detection_env()`` rebuilds the
    snapshot with the new token.
    """
    global _CACHED_ENV
    _CACHED_ENV = None


__all__ = [
    "DetectionEnv",
    "GITHUB_ACTIVITY_ORG",
    "collect_env",
    "get_detection_env",
    "detect_projects",
    "detected_project_objects",
    "invalidate_detection_env_cache",
]
