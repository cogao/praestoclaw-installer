"""Azure Web PubSub link implementation for Agent-Gateway v2."""

from __future__ import annotations

import time
from collections.abc import Awaitable, Callable, Mapping
from datetime import UTC, datetime
from typing import Any
from urllib.parse import urlsplit, urlunsplit

import httpx
from loguru import logger

from praestoclaw.gateway_protocol.transport import GatewayTransportClient, TransportClientConfig
from praestoclaw.gateway_protocol.v2.transport import V2_WIRE_PROTOCOL

AGENT_GATEWAY_V2_PROTOCOL = "agent_gateway_v2"
AWPS_TRANSPORT = "awps"
DEFAULT_AWPS_WS_PING_INTERVAL_S = 20.0
DEFAULT_AWPS_WS_PING_TIMEOUT_S = 20.0


class AwpsNegotiatingUrlProvider:
    """Fetch and cache AWPS client URLs from the Gateway v2 negotiate endpoint."""

    def __init__(
        self,
        *,
        negotiate_url: str,
        headers_provider: Callable[[], Awaitable[Mapping[str, str]]],
        timeout_s: float,
        refresh_skew_s: float,
    ) -> None:
        self._negotiate_url = negotiate_url
        self._headers_provider = headers_provider
        self._timeout_s = timeout_s
        self._refresh_skew_s = refresh_skew_s
        self._url: str | None = None
        self._expires_at = 0.0

    async def __call__(self) -> str:
        now = time.time()
        if self._url and now < self._expires_at - self._refresh_skew_s:
            return self._url
        headers = await self._headers_provider()
        async with httpx.AsyncClient(timeout=self._timeout_s) as client:
            response = await client.post(
                self._negotiate_url,
                headers=dict(headers),
                json={"protocol": AGENT_GATEWAY_V2_PROTOCOL, "transport": AWPS_TRANSPORT},
            )
            response.raise_for_status()
            body = response.json()
        protocol = body.get("protocol")
        transport = body.get("transport")
        if protocol != AGENT_GATEWAY_V2_PROTOCOL or transport != AWPS_TRANSPORT:
            raise RuntimeError("Gateway negotiate response did not confirm agent_gateway_v2/awps")
        url = body.get("url")
        if not isinstance(url, str) or not url:
            raise RuntimeError("Gateway negotiate response did not include url")
        expires_at = body.get("expires_at")
        self._url = url
        self._expires_at = _parse_epoch_seconds(expires_at) or (now + 300.0)
        logger.info(
            "AWPS negotiate received client URL endpoint={} expires_in={:.0f}s",
            _safe_url_for_log(url),
            max(0.0, self._expires_at - now),
        )
        return url

    def invalidate(self) -> None:
        self._url = None
        self._expires_at = 0.0


class AwpsGatewayTransportClient(GatewayTransportClient):
    """Gateway transport client configured for the v2 AWPS link."""

    wire_protocol = V2_WIRE_PROTOCOL


def awps_transport_config(
    *,
    url: str,
    headers_provider: Callable[[], Awaitable[Mapping[str, str]]],
    negotiate_url: str = "",
    negotiate_timeout_s: float,
    client_url_refresh_skew_s: float,
    reconnect_max_delay_s: float,
) -> TransportClientConfig:
    provider = AwpsNegotiatingUrlProvider(
        negotiate_url=negotiate_url or negotiate_url_from_connect_url(url),
        headers_provider=headers_provider,
        timeout_s=negotiate_timeout_s,
        refresh_skew_s=client_url_refresh_skew_s,
    )
    return TransportClientConfig(
        url=url,
        wire_protocol=V2_WIRE_PROTOCOL,
        url_provider=provider,
        headers={},
        headers_provider=None,
        features=("resume", "ack"),
        reconnect_max_delay_s=reconnect_max_delay_s,
        websocket_ping_interval_s=DEFAULT_AWPS_WS_PING_INTERVAL_S,
        websocket_ping_timeout_s=DEFAULT_AWPS_WS_PING_TIMEOUT_S,
    )


def negotiate_url_from_connect_url(connect_url: str) -> str:
    parts = urlsplit(connect_url)
    scheme = {"ws": "http", "wss": "https"}.get(parts.scheme, parts.scheme)
    return urlunsplit(
        (
            scheme,
            parts.netloc,
            "/agent-gateway/v2/negotiate",
            "",
            "",
        )
    )


def _safe_url_for_log(url: str) -> str:
    parts = urlsplit(url)
    return urlunsplit((parts.scheme, parts.netloc, parts.path, "", ""))


def _parse_epoch_seconds(value: Any) -> float | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.timestamp()
