"""Outbound helpers and correlation tracking for business envelopes."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator, Awaitable, Callable, Mapping
from dataclasses import dataclass
from typing import Any, Protocol

from loguru import logger

from praestoclaw.gateway_protocol.business.debug_log import log_business_envelope_debug
from praestoclaw.gateway_protocol.business.envelope import BusinessError, Envelope, EnvelopeKind


class TransportSender(Protocol):
    """Minimal transport API used by the business layer."""

    async def send(self, payload: Any) -> Any: ...


# Callable that returns the *currently live* transport, or ``None`` if the
# channel is mid-reconnect. Used by ``Outbound`` to survive watchdog-driven
# transport rebuilds: when the dispatcher captured a stale ``Outbound``
# instance whose original transport is now CLOSED, the provider lets the
# next ``send_envelope`` call re-resolve to the freshly built transport.
TransportProvider = Callable[[], "TransportSender | None"]

# Callback invoked when ``send_envelope`` cannot deliver because the
# transport is closed AND no live transport is available via the provider.
# CloudChannel uses it to enqueue the envelope on a deferred outbox that
# gets flushed by the watchdog after a successful rebuild. Return ``True``
# to swallow the error (queued for replay); ``False`` to re-raise.
SendFailureHandler = Callable[[Envelope, BaseException], Awaitable[bool]]


@dataclass
class _PendingUnary:
    future: asyncio.Future[dict[str, Any]]


@dataclass
class _PendingStream:
    queue: asyncio.Queue[Any]


@dataclass(frozen=True)
class _StreamEnd:
    body: dict[str, Any]


class Outbound:
    """Business send helpers over an opaque transport sender.

    Accepts either a fixed ``TransportSender`` or a ``TransportProvider``
    callable. The provider form is required when the owning channel may
    rebuild the underlying transport mid-flight (watchdog reconnect):
    long-running request handlers capture this ``Outbound`` by reference
    and would otherwise keep sending to a CLOSED transport forever.
    """

    def __init__(
        self,
        transport: TransportSender | TransportProvider,
        *,
        send_failure_handler: SendFailureHandler | None = None,
    ) -> None:
        # ``_transport`` may be either a sender instance or a zero-arg
        # callable that returns the current sender (or None). We
        # resolve it on every ``send_envelope`` call.
        self._transport: TransportSender | TransportProvider = transport
        self._send_failure_handler = send_failure_handler
        self._pending: dict[str, _PendingUnary | _PendingStream] = {}

    def _resolve_transport(self) -> TransportSender | None:
        # ``TransportSender`` is a ``Protocol`` (no isinstance check), so
        # we use the presence of ``send`` to decide whether it's a
        # provider callable vs. a static sender. Provider callables are
        # expected to return either a sender or ``None``; if one raises,
        # we treat that as "no live transport" rather than crashing the
        # send path — the failure handler (if any) then decides whether
        # to defer or surface the error.
        candidate = self._transport
        if callable(candidate) and not hasattr(candidate, "send"):
            try:
                return candidate()  # type: ignore[no-any-return,operator]
            except Exception as exc:  # noqa: BLE001 - provider mustn't crash send path
                logger.debug("Outbound transport_provider raised: {}", exc)
                return None
        return candidate  # type: ignore[return-value]

    async def send_envelope(self, envelope: Envelope) -> None:
        transport = self._resolve_transport()
        if transport is None:
            # Mid-reconnect window: no live transport. Defer if a handler
            # accepts the envelope; otherwise surface as a transport
            # error so callers (especially REQUEST/CANCEL with sync
            # waiters) don't hang silently.
            exc = RuntimeError("no live transport available")
            handled = await self._handle_send_failure(envelope, exc)
            if not handled:
                raise exc
            return
        try:
            await transport.send(envelope.to_dict())
        except Exception as exc:  # noqa: BLE001 - handler decides recovery
            # Most callers care specifically about ``TransportClosedError``,
            # but any send failure during a watchdog window is recoverable
            # via the deferred outbox. The handler classifies and either
            # queues (returns True) or re-raises by returning False.
            handled = await self._handle_send_failure(envelope, exc)
            if not handled:
                raise
            return
        log_business_envelope_debug("tx", envelope)

    async def _handle_send_failure(
        self,
        envelope: Envelope,
        exc: BaseException,
    ) -> bool:
        # REQUEST and CANCEL envelopes have a synchronous local waiter
        # (``request()`` / ``stream()`` blocks on a future; ``cancel()``
        # is expected to clean up promptly). Silently deferring them
        # would make the caller hang until ``timeout`` fires, defeating
        # the purpose of the deferred outbox (which is only meaningful
        # for fire-and-forget envelopes — RESPONSE/ERROR/EVENT and the
        # STREAM_ITEM/STREAM_END frames). For REQUEST/CANCEL we always
        # re-raise so the caller can react (retry, fail the operation,
        # etc.).
        if envelope.kind in {EnvelopeKind.REQUEST, EnvelopeKind.CANCEL}:
            return False
        if self._send_failure_handler is None:
            return False
        try:
            return await self._send_failure_handler(envelope, exc)
        except Exception as handler_exc:  # noqa: BLE001
            logger.warning(
                "Outbound send_failure_handler itself failed: {} (original: {})",
                handler_exc,
                exc,
            )
            return False

    async def send_event(
        self,
        topic: str,
        body: Mapping[str, Any],
        *,
        headers: Mapping[str, Any] | None = None,
    ) -> None:
        await self.send_envelope(Envelope.event(topic, body, headers=headers))

    async def send_response(self, correlation_id: str, body: Mapping[str, Any]) -> None:
        await self.send_envelope(Envelope.response(correlation_id, body))

    async def send_stream_item(self, correlation_id: str, body: Mapping[str, Any]) -> None:
        await self.send_envelope(Envelope.stream_item(correlation_id, body))

    async def send_stream_end(
        self,
        correlation_id: str,
        body: Mapping[str, Any] | None = None,
    ) -> None:
        await self.send_envelope(Envelope.stream_end(correlation_id, body))

    async def send_error(self, correlation_id: str, error: BusinessError) -> None:
        await self.send_envelope(Envelope.error(correlation_id, error))

    async def request(
        self,
        topic: str,
        body: Mapping[str, Any],
        *,
        headers: Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        envelope = Envelope.request(topic, body, headers=headers)
        loop = asyncio.get_running_loop()
        future: asyncio.Future[dict[str, Any]] = loop.create_future()
        self._pending[envelope.id] = _PendingUnary(future)
        try:
            await self.send_envelope(envelope)
            return await asyncio.wait_for(future, timeout=timeout)
        except TimeoutError:
            await self.cancel(envelope.id, reason="timeout")
            raise
        finally:
            self._pending.pop(envelope.id, None)

    async def stream(
        self,
        topic: str,
        body: Mapping[str, Any],
        *,
        headers: Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        envelope = Envelope.request(topic, body, headers=headers)
        queue: asyncio.Queue[Any] = asyncio.Queue()
        self._pending[envelope.id] = _PendingStream(queue)
        try:
            await self.send_envelope(envelope)
            while True:
                item = await asyncio.wait_for(queue.get(), timeout=timeout)
                if isinstance(item, _StreamEnd):
                    break
                if isinstance(item, BusinessError):
                    raise item
                yield item
        except TimeoutError:
            await self.cancel(envelope.id, reason="timeout")
            raise
        finally:
            self._pending.pop(envelope.id, None)

    async def cancel(self, correlation_id: str, *, reason: str | None = None) -> None:
        await self.send_envelope(Envelope.cancel(correlation_id, reason=reason))

    async def fail_pending(self, error: BusinessError) -> None:
        """Fail all locally pending requests, usually after `resumed:false`."""

        pending_items = list(self._pending.items())
        self._pending.clear()
        for _, pending in pending_items:
            if isinstance(pending, _PendingUnary):
                if not pending.future.done():
                    pending.future.set_exception(error)
            else:
                await pending.queue.put(error)

    async def handle_incoming(self, envelope: Envelope) -> bool:
        """Resolve a pending request/stream if this envelope is a reply."""

        if envelope.kind not in {
            EnvelopeKind.RESPONSE,
            EnvelopeKind.STREAM_ITEM,
            EnvelopeKind.STREAM_END,
            EnvelopeKind.ERROR,
        }:
            return False
        if envelope.correlation_id is None:
            return False

        pending = self._pending.get(envelope.correlation_id)
        if pending is None:
            return False

        if isinstance(pending, _PendingUnary):
            self._resolve_unary(pending, envelope)
        else:
            await self._resolve_stream(pending, envelope)
        return True

    def _resolve_unary(self, pending: _PendingUnary, envelope: Envelope) -> None:
        if pending.future.done():
            return
        if envelope.kind is EnvelopeKind.RESPONSE:
            pending.future.set_result(dict(envelope.body))
        elif envelope.kind is EnvelopeKind.ERROR:
            pending.future.set_exception(BusinessError.from_body(envelope.body))
        else:
            pending.future.set_exception(
                BusinessError(
                    "invalid_envelope",
                    f"unexpected {envelope.kind.value} for unary request",
                    retryable=False,
                )
            )

    async def _resolve_stream(self, pending: _PendingStream, envelope: Envelope) -> None:
        if envelope.kind is EnvelopeKind.STREAM_ITEM:
            await pending.queue.put(dict(envelope.body))
        elif envelope.kind is EnvelopeKind.STREAM_END:
            await pending.queue.put(_StreamEnd(dict(envelope.body)))
        elif envelope.kind is EnvelopeKind.ERROR:
            await pending.queue.put(BusinessError.from_body(envelope.body))
        elif envelope.kind is EnvelopeKind.RESPONSE:
            await pending.queue.put(
                BusinessError(
                    "invalid_envelope",
                    "unexpected response for streaming request",
                    retryable=False,
                )
            )
