"""
Message bus event types — decoupled communication between channels and agent.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from praestoclaw.config.schema import ChannelType

# ── Message types ────────────────────────────────────────────────────────────


@dataclass
class InboundMessage:
    """Message received from a channel, headed to the agent."""

    logical_channel: ChannelType | str
    physical_ingress: str
    delivery_route_id: str
    sender_id: str
    content: str
    content_format: str = "text"
    sender_name: str = ""
    conversation_id: str | None = None
    turn_id: str | None = None
    agent_session_key: str | None = None
    attachments: list[Any] | None = None
    timestamp: str | None = None  # ISO format
    metadata: dict[str, Any] = field(default_factory=dict)
    # metadata may contain: source, tenant_id, injection, interrupt
    # Optional precise-routing target for unsolicited push (a2a notify,
    # scheduler reminders, etc.). When set, channels SHOULD prefer this
    # value over ``channel_id`` for picking a per-connection destination,
    # falling back to the channel's normal ``channel_id``-based lookup
    # (and then to broadcast / drop) when no precise destination matches.
    # ``channel_id`` itself stays untouched so existing channel-side
    # branching on synthetic ids (e.g. ``a2a:notify:<pid>``) keeps working.
    route_hint: str | None = None


@dataclass
class OutboundMessage:
    """Message from the agent, headed to a channel."""

    channel: ChannelType
    channel_id: str
    content: str
    thread_id: str | None = None
    reply_to: str | None = None
    attachments: list[Any] | None = None
    format: str = "markdown"
    metadata: dict[str, Any] = field(default_factory=dict)
    # See :class:`InboundMessage.route_hint`. Agent-loop callers should
    # forward ``InboundMessage.route_hint`` onto the responding
    # OutboundMessage so the channel layer can route precisely back to
    # the originating connection.
    route_hint: str | None = None


@dataclass
class StreamingChunk:
    """Incremental content fragment during streaming responses."""

    channel: ChannelType
    channel_id: str
    content: str
    chunk_type: str = "token"  # "token" | "tool_progress" | "status"
    done: bool = False


# ── Typed events for cross-subsystem coordination ───────────────────────────


class EventType(str, Enum):
    """Typed events emitted via EventBus for cross-subsystem coordination."""

    # Message lifecycle
    MESSAGE_RECEIVED = "message.received"
    MESSAGE_SENT = "message.sent"
    # Tool execution
    TOOL_EXECUTED = "tool.executed"
    TOOL_FAILED = "tool.failed"
    TOOL_APPROVED = "tool.approved"
    TOOL_DENIED = "tool.denied"
    # Mid-execution progress signal (streaming tools — web_fetch download
    # percentage, shell stdout lines, browser navigation). Payload:
    # ``{tool_call_id, tool_name, text, session_id, channel, channel_id,
    # metadata}``. Subscribed by ToolStatusCard to surface live status
    # under the current 🔧 running row on the Teams per-turn card.
    TOOL_PROGRESS = "tool.progress"
    # Approval workflow
    APPROVAL_REQUESTED = "approval.requested"
    APPROVAL_RESOLVED = "approval.resolved"
    # Security
    SECURITY_ALERT = "security.alert"
    SECURITY_ESTOP = "security.estop"
    SECURITY_LEAK = "security.leak"
    # Cost
    COST_WARNING = "cost.warning"
    # Health
    HEALTH_DEGRADED = "health.degraded"
    HEALTH_RECOVERED = "health.recovered"
    # Agent
    AGENT_ITERATION = "agent.iteration"
    # Memory
    MEMORY_CONSOLIDATED = "memory.consolidated"
    # Session
    SESSION_CREATED = "session.created"
    # Channel lifecycle
    CHANNEL_CONNECTED = "channel.connected"
    # Typing indicators
    TYPING_STARTED = "typing.started"
    TYPING_STOPPED = "typing.stopped"
