"""Heartbeat — periodic background maintenance task.

Uses a persistent session (single JSONL file on disk for audit) with
in-memory history cleared before each run, so the LLM starts with a
clean context. Cross-run context is managed via a state file with
time-decayed detail:

- **today**: per-run log with timestamps (last 48 entries)
- **recent** (7 days): per-day summaries with notable events
- **older** (8 weeks): weekly run counts only
- **notable**: persistent list of rare events (leaks, updates, skill
  changes) that survive the 7-day window

The state is prepended to the HEARTBEAT.md prompt as a
``## Prior Heartbeat Activity`` section, giving the LLM ~1-2KB of
structured context instead of ~42KB of repeated conversations.

**Pre-flight optimisation**: before invoking the LLM, Python-side
checks determine which prompt sections actually need work.  When every
section can be skipped, the run short-circuits with ``HEARTBEAT_OK``
and no LLM call is made — saving ~90 % of daily token cost.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger

from praestoclaw.utils.defaults import load_default

# ── Constants ────────────────────────────────────────────────────────────────

JOB_NAME = "__heartbeat__"
STATE_FILENAME = "heartbeat_state.json"

_TODAY_LOG_MAX = 48  # one day at 30-min intervals
_RECENT_DAYS_MAX = 7
_OLDER_WEEKS_MAX = 8
_NOTABLE_MAX = 20
_CONTEXT_TODAY_LOG = 10  # last N log entries shown to LLM
_DAY_EVENTS_MAX = 5
_RECENT_EVENTS_SHOWN = 3

# Pre-flight thresholds — controls when each section triggers an LLM call
_UPDATE_CHECK_HOURS = 18
_UPDATE_CHECK_START = 7.5  # 7:30
_UPDATE_CHECK_END = 19.5  # 19:30
_USER_PROFILE_DAYS = 7
_SKILLS_HOURS = 6


_OK_RESPONSES = ("HEARTBEAT_OK", "")


def is_heartbeat_ok(result: str | None) -> bool:
    """Return True if the heartbeat result indicates nothing to report."""
    return result is not None and (not result or result.strip() in _OK_RESPONSES)


# ── Pre-flight checks ────────────────────────────────────────────────────────


@dataclass
class SectionStatus:
    """Pre-flight result for one heartbeat section."""

    active: bool
    reason: str


def _file_age(path: Path, unit: float = 3600) -> float | None:
    """Return file age in *unit* seconds, or None if missing/inaccessible."""
    try:
        if not path.is_file():
            return None
        return (time.time() - path.stat().st_mtime) / unit
    except OSError:
        return None


def preflight_check() -> dict[str, SectionStatus]:
    """Evaluate which heartbeat sections need to run, without an LLM call.

    Returns a dict mapping section names to their status.
    When every section is inactive, the caller can skip the LLM entirely.
    """
    from praestoclaw.utils.helpers import get_data_dir

    data_dir = get_data_dir()
    results: dict[str, SectionStatus] = {}

    # ── System: update check ────────────────────────────────────────
    now_local = datetime.now()
    local_hour = now_local.hour + now_local.minute / 60
    if local_hour < _UPDATE_CHECK_START or local_hour > _UPDATE_CHECK_END:
        results["update"] = SectionStatus(False, "outside work hours")
    else:
        age_h = _file_age(data_dir / ".last_update_check")
        if age_h is None:
            results["update"] = SectionStatus(True, "never checked")
        elif age_h < _UPDATE_CHECK_HOURS:
            results["update"] = SectionStatus(False, f"checked {age_h:.0f}h ago")
        else:
            results["update"] = SectionStatus(True, f"last check {age_h:.0f}h ago")

    # ── Security: secret scan on MEMORY.md ──────────────────────────
    memory_path = data_dir / "MEMORY.md"
    if not memory_path.is_file():
        results["security"] = SectionStatus(False, "no MEMORY.md")
    else:
        try:
            from praestoclaw.security.leak import detect_credentials

            findings = detect_credentials(memory_path.read_text(encoding="utf-8"))
            if findings:
                types = ", ".join(t for t, _ in findings[:3])
                results["security"] = SectionStatus(True, f"found: {types}")
            else:
                results["security"] = SectionStatus(False, "clean")
        except Exception:
            results["security"] = SectionStatus(True, "scan error, needs LLM review")

    # ── User Profile: USER.md freshness ─────────────────────────────
    age_d = _file_age(data_dir / "USER.md", unit=86400)
    if age_d is None:
        results["user_profile"] = SectionStatus(True, "USER.md missing")
    elif age_d < _USER_PROFILE_DAYS:
        results["user_profile"] = SectionStatus(False, f"{age_d:.0f}d old")
    else:
        results["user_profile"] = SectionStatus(True, f"{age_d:.0f}d old, due refresh")

    # ── Skills: .last_updated freshness ─────────────────────────────
    age_h = _file_age(data_dir / "skills" / ".last_updated")
    if age_h is None:
        results["skills"] = SectionStatus(True, "never scanned")
    elif age_h < _SKILLS_HOURS:
        results["skills"] = SectionStatus(False, f"scanned {age_h:.0f}h ago")
    else:
        results["skills"] = SectionStatus(True, f"last scan {age_h:.0f}h ago")

    return results


_SECTION_LABELS = {
    "update": "Check for updates",
    "security": "Scan MEMORY.md for leaked secrets",
    "user_profile": "Refresh USER.md (preferences)",
    "skills": "Discover / maintain skills from session history",
}


def build_preflight_section(statuses: dict[str, SectionStatus]) -> str:
    """Build a ``## Pre-flight`` section to inject into the prompt.

    Tells the LLM which sections to run and which to skip, so it does
    not waste tool-call rounds re-checking timestamps itself.
    """
    now_str = datetime.now(UTC).strftime("%Y-%m-%d %H:%M UTC")
    lines = [f"## Pre-flight — {now_str}", ""]
    for key, label in _SECTION_LABELS.items():
        s = statuses.get(key)
        if s is None:
            continue
        tag = "RUN" if s.active else "SKIP"
        lines.append(f"- **{label}**: {tag} — {s.reason}")
    lines.append("")
    lines.append(
        "Execute only RUN sections. Do not change RUN/SKIP decisions."
        " All file timestamps and scans have already been verified —"
        " do not use tools or shell commands just to re-check these pre-flight conditions."
    )
    lines.append("")
    return "\n".join(lines)


# ── Prompt building ──────────────────────────────────────────────────────────


def load_heartbeat_prompt(
    state: dict[str, Any],
    statuses: dict[str, SectionStatus] | None = None,
) -> str | None:
    """Load HEARTBEAT.md and prepend prior-activity + pre-flight context.

    Returns None if HEARTBEAT.md is empty (nothing to do).
    """
    prompt = load_default("HEARTBEAT.md", allow_empty_override=True)
    if not prompt:
        return None

    parts: list[str] = []
    ctx = build_context(state)
    if ctx:
        parts.append(ctx)
    if statuses:
        parts.append(build_preflight_section(statuses))
    parts.append(prompt)
    return "".join(parts)


# ── State I/O ────────────────────────────────────────────────────────────────


def state_file_path() -> Path:
    from praestoclaw.utils.helpers import get_data_dir

    return get_data_dir() / STATE_FILENAME


def read_state() -> dict[str, Any]:
    """Read heartbeat state file, or return default structure."""
    try:
        path = state_file_path()
        if path.is_file():
            data: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
            return data
    except (json.JSONDecodeError, OSError):
        pass
    return {"today": {}, "recent": [], "older": [], "notable": []}


def write_state(state: dict[str, Any]) -> None:
    """Persist heartbeat state to disk."""
    try:
        path = state_file_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError as exc:
        logger.debug("Failed to write heartbeat state: {}", exc)


# ── Context building ─────────────────────────────────────────────────────────


def build_context(state: dict[str, Any]) -> str:
    """Build a ``## Prior Heartbeat Activity`` section from state.

    Example output::

        ## Prior Heartbeat Activity

        ### Today (2026-03-24) — 5 runs, 0 failed
        - 08:00 HEARTBEAT_OK
        - 09:00 update_available: v0.12.0, notified user

        ### Recent Days
        - 2026-03-23: 47 runs, 1 failed | skill_created: git-pr-review

        ### Notable Events
        - 2026-03-23 New version v0.12.0 available, user notified
    """
    sections: list[str] = []

    # Today
    today_data = state.get("today", {})
    if today_data.get("runs"):
        runs = today_data["runs"]
        failed = today_data.get("failed", 0)
        header = f"### Today ({today_data.get('date', '?')}) — {runs} runs, {failed} failed"
        lines = [header]
        for entry in today_data.get("log", [])[-_CONTEXT_TODAY_LOG:]:
            lines.append(f"- {entry}")
        sections.append("\n".join(lines))

    # Recent days
    recent = state.get("recent", [])
    if recent:
        lines = ["### Recent Days"]
        for day in recent[:_RECENT_DAYS_MAX]:
            date = day.get("date", "?")
            r, f = day.get("runs", 0), day.get("failed", 0)
            entry = f"- {date}: {r} runs, {f} failed"
            events = day.get("events", [])
            if events:
                entry += " | " + "; ".join(events[:_RECENT_EVENTS_SHOWN])
            lines.append(entry)
        sections.append("\n".join(lines))

    # Notable events
    notable = state.get("notable", [])
    if notable:
        lines = ["### Notable Events"]
        for event in notable[-_CONTEXT_TODAY_LOG:]:
            lines.append(f"- {event}")
        sections.append("\n".join(lines))

    if not sections:
        return ""
    return "## Prior Heartbeat Activity\n\n" + "\n\n".join(sections) + "\n\n"


# ── State update ─────────────────────────────────────────────────────────────


def update_state(
    state: dict[str, Any],
    result: str | None,
    daily_counts: dict[str, Any] | None = None,
) -> None:
    """Update heartbeat state after a run.

    Handles day rollover (today → recent), week rollover
    (recent → older), and notable event detection.

    Parameters
    ----------
    state:
        Mutable state dict (read via ``read_state()``).
    result:
        LLM result string, or None if the run failed.
    daily_counts:
        Optional daily run counts from SchedulerService._daily_counts
        for error tracking.
    """
    now = datetime.now(UTC)
    today = now.strftime("%Y-%m-%d")
    time_str = now.strftime("%H:%M")

    today_data = state.setdefault("today", {})
    recent: list[dict[str, Any]] = state.setdefault("recent", [])
    older: list[dict[str, Any]] = state.setdefault("older", [])
    notable: list[str] = state.setdefault("notable", [])

    # ── Day rollover: archive today → recent ─────────────────────────
    if today_data.get("date") and today_data["date"] != today:
        day_summary: dict[str, Any] = {
            "date": today_data["date"],
            "runs": today_data.get("runs", 0),
            "failed": today_data.get("failed", 0),
        }
        # Extract notable events from today's log
        events = [e for e in today_data.get("log", []) if not e.endswith("HEARTBEAT_OK")]
        if events:
            day_summary["events"] = events[:_DAY_EVENTS_MAX]
        recent.insert(0, day_summary)

        # ── Week rollover: recent[7+] → older ────────────────────────
        from datetime import date as _date

        week_index = {b["week"]: b for b in older if "week" in b}
        while len(recent) > _RECENT_DAYS_MAX:
            old_day = recent.pop()
            try:
                d = _date.fromisoformat(old_day["date"])
                week_key = f"{d.isocalendar()[0]}-W{d.isocalendar()[1]:02d}"
            except (ValueError, KeyError):
                week_key = "unknown"

            bucket = week_index.get(week_key)
            if bucket is None:
                bucket = {"week": week_key, "runs": 0, "failed": 0}
                older.append(bucket)
                week_index[week_key] = bucket

            bucket["runs"] += old_day.get("runs", 0)
            bucket["failed"] += old_day.get("failed", 0)

        older[:] = older[-_OLDER_WEEKS_MAX:]
        today_data.clear()

    # ── Update today ──────────────────────────────────────────────────
    today_data["date"] = today
    today_data["runs"] = today_data.get("runs", 0) + 1

    is_error = result is None
    is_ok = is_heartbeat_ok(result)

    if is_error:
        today_data["failed"] = today_data.get("failed", 0) + 1
        error_msg = "unknown"
        if daily_counts and daily_counts.get("last_error"):
            error_msg = daily_counts["last_error"][:100]
        today_data.setdefault("log", []).append(f"{time_str} ERROR: {error_msg}")
    elif is_ok:
        today_data.setdefault("log", []).append(f"{time_str} HEARTBEAT_OK")
    else:
        # Notable: result is not HEARTBEAT_OK — something happened
        preview = (result or "")[:200].replace("\n", " ").strip()
        today_data.setdefault("log", []).append(f"{time_str} {preview}")
        notable.append(f"{today} {preview}")

    # Cap lists
    log = today_data.get("log", [])
    if len(log) > _TODAY_LOG_MAX:
        today_data["log"] = log[-_TODAY_LOG_MAX:]
    if len(notable) > _NOTABLE_MAX:
        notable[:] = notable[-_NOTABLE_MAX:]

    write_state(state)
