"""Tiny helper: infer the gateway environment label from a cloud URL.

Used by client-side telemetry to tag A2A events with the gateway they were
sent through, so dashboards can split client_agent's A2A success rate by
staging vs production without back-correlating URLs.
"""

from __future__ import annotations


def infer_gateway_env(cloud_url: str | None) -> str:
    """Return ``"staging" | "production" | "local" | "unknown"``.

    Recognises the Azure App Service hostnames used by the PraestoClaw
    gateway deployments and the loopback URLs used in dev / multi-instance
    testing.
    """
    if not cloud_url:
        return "unknown"
    url = cloud_url.lower()
    if "praestoclawgatewaystaging" in url:
        return "staging"
    if "praestoclawgatewayproduction" in url:
        return "production"
    if "localhost" in url or "127.0.0.1" in url or url.startswith("ws://0."):
        return "local"
    return "unknown"
