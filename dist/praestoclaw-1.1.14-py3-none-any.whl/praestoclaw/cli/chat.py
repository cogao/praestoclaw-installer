"""praestoclaw chat — interactive agent REPL, with web server attach support."""

from __future__ import annotations

import asyncio

import typer
from rich.console import Console

from praestoclaw.cli._banners import print_sandbox_banner
from praestoclaw.runtime import Runtime

console = Console()


# ── Web server auth resolution ────────────────────────────────────────────────


def _resolve_web_auth(rt: Runtime) -> dict[str, str]:
    """Return WebSocket headers for web server auth.

    Priority: api_key > Entra token (web server config) > empty.
    """
    web_cfg = rt.config.channels.web
    if web_cfg.api_key:
        return {"X-API-Key": web_cfg.api_key.get_secret_value()}

    # Gate on gateway's own Entra config, not cloud channel defaults
    if web_cfg.entra_tenant_id and web_cfg.entra_client_id:
        try:
            from praestoclaw.utils.auth import acquire_entra_token

            token = acquire_entra_token(
                tenant_id=web_cfg.entra_tenant_id,
                client_id=web_cfg.entra_client_id,
            )
            if token:
                return {"Authorization": f"Bearer {token}"}
            console.print(
                "[yellow]Entra ID login cancelled or failed — connecting without auth.[/yellow]"
            )
        except Exception as exc:
            console.print(f"[yellow]Entra ID auth failed: {exc}[/yellow]")

    return {}


# ── WebSocket REPL (attach to running web server) ────────────────────────────


async def _ws_chat_repl(port: int, *, auth_headers: dict[str, str] | None = None) -> None:
    """Connect to a running web server via WebSocket and run an interactive REPL."""
    import json as _json

    import websockets  # type: ignore[import]

    url = f"ws://localhost:{port}/api/ws"
    console.print(
        f"[dim]Connected to running web server (port {port}). "
        f"Type /new to clear session, Ctrl+C to exit.[/dim]\n"
    )
    # Reuse prompt_toolkit session for history + autocomplete (fallback to input())
    try:
        import os

        from prompt_toolkit import PromptSession
        from prompt_toolkit.history import FileHistory

        from praestoclaw.channels.cli import _SlashCompleter
        from praestoclaw.utils.helpers import get_data_dir

        _history_path = get_data_dir() / "cli_history"
        if os.name == "posix":
            try:
                if not _history_path.exists():
                    fd = os.open(_history_path, os.O_CREAT | os.O_WRONLY, 0o600)
                    os.close(fd)
                else:
                    os.chmod(_history_path, 0o600)
            except OSError:
                pass
        _ws_session: PromptSession[str] = PromptSession(
            "you> ",
            completer=_SlashCompleter(),
            complete_while_typing=True,
            history=FileHistory(str(_history_path)),
        )
        _get_input = lambda: _ws_session.prompt()  # noqa: E731
    except ImportError:
        console.print("[dim](basic input mode — autocomplete/history unavailable)[/dim]")
        _get_input = lambda: input("you> ")  # noqa: E731

    async with websockets.connect(url, additional_headers=auth_headers or {}) as ws:
        # Single dedicated reader: the server multiplexes solicited replies
        # (kind=response or no kind) and unsolicited push frames (kind=push,
        # e.g. a2a inbound notify, scheduler) on the same socket. We must
        # drain pushes immediately even while the user is idle at the prompt
        # — otherwise they pile up in the recv buffer and (because push
        # frames also carry a "response" key) get misread as the next
        # prompt's reply once the user finally types something.
        response_q: asyncio.Queue[dict] = asyncio.Queue()

        async def _reader() -> None:
            from rich.markdown import Markdown

            while True:
                try:
                    data = _json.loads(await ws.recv())
                except Exception:
                    await response_q.put({"__closed__": True})
                    return
                kind = data.get("kind")
                if kind == "push":
                    # Render immediately, regardless of REPL state.
                    msg = data.get("response") or data.get("content") or ""
                    console.print("\n[dim][push][/dim] ", end="")
                    console.print(Markdown(str(msg)))
                elif "error" in data:
                    await response_q.put(data)
                else:
                    await response_q.put(data)

        reader_task = asyncio.create_task(_reader())
        try:
            while True:
                try:
                    prompt = await asyncio.get_running_loop().run_in_executor(None, _get_input)
                except (EOFError, KeyboardInterrupt):
                    break

                if not prompt.strip():
                    continue

                # Slash commands handled locally
                if prompt.strip() == "/exit":
                    break

                await ws.send(_json.dumps({"prompt": prompt}, ensure_ascii=False))

                # Wait for the next non-push frame (the reader has already
                # filtered push frames out into stdout).
                data = await response_q.get()
                if data.get("__closed__"):
                    console.print("[red]Connection closed by server.[/red]")
                    break
                if "error" in data:
                    console.print(f"[red]{data['error']}[/red]")
                    continue
                from rich.markdown import Markdown

                console.print(Markdown(str(data.get("response", ""))))
        finally:
            reader_task.cancel()
            try:
                await reader_task
            except (asyncio.CancelledError, Exception):
                pass


# ── Command entry point ──────────────────────────────────────────────────────


def chat(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
    local: bool = typer.Option(
        True,
        "--local/--cloud",
        help="Use the local agent host-backed TUI or connect as a Cloud Gateway TUI client.",
    ),
    instance_id: str | None = typer.Option(
        None,
        "--instance-id",
        help=(
            "Local dev instance identifier; sets cloud bypass_token to "
            "'dev-<instance-id>' for Cloud Gateway TUI testing."
        ),
    ),
    cloud_url: str | None = typer.Option(
        None,
        "--cloud-url",
        help=(
            "Override channels.cloud.url at runtime "
            "(e.g. ws://localhost:5000 for a local v2 gateway)."
        ),
    ),
    a2a_user_id: str | None = typer.Option(
        None,
        "--a2a-user-id",
        help="Set local dev A2A user identity on the loaded config.",
    ),
    target_agent_id: str | None = typer.Option(
        None,
        "--target-agent-id",
        help="Cloud TUI target agent_id. Defaults to the authenticated user's master agent.",
    ),
    data_dir: str | None = typer.Option(
        None,
        "--data-dir",
        help=(
            "Override data directory (default: ~/.praestoclaw/ or "
            "$PRAESTOCLAW_DATA_DIR). Use a unique path per instance for "
            "multi-instance testing."
        ),
    ),
) -> None:
    """Start an interactive agent REPL session.

    If 'praestoclaw serve' is already running, connects to it directly instead
    of starting a new Runtime instance.
    """
    # MUST be the very first thing — _check_web_running() and Runtime resolve
    # state via get_data_dir(); the override has to land before any of that.
    from praestoclaw.utils.helpers import set_data_dir

    set_data_dir(data_dir)

    from praestoclaw.cli.commands import _check_web_running, _get_runtime, _load_config_safe

    if not local:
        try:
            from praestoclaw.cli.dev_overrides import apply_local_dev_cloud_overrides

            cfg = _load_config_safe(config, profile)
            apply_local_dev_cloud_overrides(
                cfg,
                instance_id=instance_id,
                cloud_url=cloud_url,
                a2a_user_id=a2a_user_id,
                log_prefix="chat",
            )
            rt = Runtime(cfg)
            print_sandbox_banner(rt.sandbox, console)
            asyncio.run(rt.run_chat(local=False, target_agent_id=target_agent_id))
        except KeyboardInterrupt:
            pass
        except Exception as exc:
            console.print(f"[red]Cloud TUI connection failed:[/red] {exc}")
            raise typer.Exit(1)
        console.print("\nGoodbye!")
        return

    running = _check_web_running()
    if running:
        _, port = running
        console.print(f"[dim]Web server running on port {port} — connecting...[/dim]")
        try:
            rt = _get_runtime(config, profile)
            headers = _resolve_web_auth(rt)
            asyncio.run(_ws_chat_repl(port, auth_headers=headers))
        except KeyboardInterrupt:
            pass
        except Exception as exc:
            console.print(f"[red]Web server connection failed:[/red] {exc}")
            raise typer.Exit(1)
        console.print("\nGoodbye!")
        return

    try:
        if instance_id is not None or cloud_url is not None or a2a_user_id is not None:
            from praestoclaw.cli.dev_overrides import apply_local_dev_cloud_overrides

            cfg = _load_config_safe(config, profile)
            apply_local_dev_cloud_overrides(
                cfg,
                instance_id=instance_id,
                cloud_url=cloud_url,
                a2a_user_id=a2a_user_id,
                log_prefix="chat",
            )
            rt = Runtime(cfg)
        else:
            rt = _get_runtime(config, profile)
        print_sandbox_banner(rt.sandbox, console)
        asyncio.run(rt.run_chat(local=True))
    except KeyboardInterrupt:
        console.print("\nGoodbye!")
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)
