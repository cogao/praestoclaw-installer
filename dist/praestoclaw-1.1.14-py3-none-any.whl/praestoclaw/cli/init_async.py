"""
Async helpers for the ``praestoclaw init`` wizard.

Conservative scope: the wizard keeps a deterministic sync question flow (so the user
sees a deterministic flow) but the *executions* of slow / network-bound
work fan out to background threads. Each fan-out:

1. Records a ``pending`` entry in the FRE state file before starting.
2. Updates that entry to ``running`` → ``done`` / ``failed`` from inside
   the worker thread.
3. Logs *only* on failure to keep the wizard output clean.

Consumers (the web portal and the Teams bot) read ``.fre-state.json`` to
show progress and offer "retry" buttons. See ``utils/fre_state.py``.

Design notes
------------
* Threads are daemon threads so a hung worker can never wedge process
  exit. Before the wizard returns, ``init`` calls
  :func:`await_outstanding` which **bounded-joins** every spawned
  thread (typically ~30–60 s). Fast workers therefore finish cleanly;
  slow ones stay daemonic and will be killed at exit but are surfaced
  as ``failed`` by the web server's stale-pending sweep so the user can
  retry from the Portal.
* The worker functions catch ``BaseException`` because we never want a
  background error to surface as an unhandled exception in the user's
  shell. Errors are persisted to ``pending[<key>].error`` instead.
* Importing heavy modules (``praestoclaw.cli.teams``, MCP, …) is
  deferred into the worker bodies so wizard startup stays fast.
"""

from __future__ import annotations

import threading
import time
from collections.abc import Callable

from loguru import logger

from praestoclaw.utils import fre_state as fs

# Track every worker thread we spawn so :func:`await_outstanding` can
# bounded-join them right before the wizard exits. Without this the
# workers (daemon=True) get killed mid-clone when ``pc init`` returns,
# leaving ``pending.*.status == "running"`` permanently in the FRE state
# file and the Portal status bar spinning forever.
_OUTSTANDING: list[threading.Thread] = []
_OUTSTANDING_LOCK = threading.Lock()

# Serializes background read-modify-write of ``praestoclaw.local.yaml``
# across init-async workers (marketplace install + external import). The
# main init thread's final ``save_yaml`` happens before any worker that
# touches the same file is spawned (see ``init.py``), so the lock only
# needs to cover concurrent worker writes.
_CONFIG_WRITE_LOCK = threading.Lock()


def _spawn(name: str, target: Callable[[], None]) -> threading.Thread:
    """Start ``target`` on a daemon thread named ``init-async/<name>``.

    The thread is registered with :data:`_OUTSTANDING` so callers can
    bounded-join all in-flight workers via :func:`await_outstanding`.
    Threads stay daemonic so a hung worker can never block process exit
    past the join budget.
    """
    thread = threading.Thread(target=target, name=f"init-async/{name}", daemon=True)
    with _OUTSTANDING_LOCK:
        _OUTSTANDING.append(thread)
    thread.start()
    return thread


def has_outstanding() -> bool:
    """True iff any spawned worker is still alive.

    Cheap predicate the caller can use to decide whether to render a
    spinner while waiting on :func:`await_outstanding`. Avoids putting
    a spinner up when there's nothing to wait for (the common case
    where init had no background work to fire).
    """
    with _OUTSTANDING_LOCK:
        return any(t.is_alive() for t in _OUTSTANDING)


def await_outstanding(timeout: float) -> tuple[int, int]:
    """Join all in-flight workers up to a total ``timeout`` seconds.

    Returns ``(joined, still_alive)``: how many threads completed within
    the budget vs. how many are still running when we gave up. The
    survivors stay daemonic and will be killed at process exit — but by
    that point :func:`mark_stale_pending_as_failed` (called from the web
    server) will surface them as ``failed`` so the user can retry.

    Used by ``pc init`` between the final summary and process exit so
    that fast workers (MCP cache warm-up, small marketplaces) finish
    cleanly while slow ones remain visible / retryable.
    """
    deadline = time.monotonic() + max(0.0, timeout)
    with _OUTSTANDING_LOCK:
        threads = list(_OUTSTANDING)
    for t in threads:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        if t.is_alive():
            t.join(remaining)
    joined = sum(1 for t in threads if not t.is_alive())
    still_alive = sum(1 for t in threads if t.is_alive())
    return joined, still_alive


def fire_teams_sideload() -> threading.Thread:
    """Fan-out: install the PraestoClaw Teams personal app via Graph.

    The sync version of this took 5–15 s on a typical corporate network
    because Teams provisioning involves several Graph round-trips. By
    moving it to a background thread the wizard's "[4/7] Cloud" step
    completes in ~50 ms; the user's status bar in the Web Portal (and
    Teams welcome card, when it eventually opens) reflects progress.
    """
    fs.update_pending(fs.PENDING_TEAMS_SIDELOAD, status="pending")

    def _worker() -> None:
        fs.update_pending(fs.PENDING_TEAMS_SIDELOAD, status="running")
        try:
            # Defer heavy imports until we're on the worker thread.
            from praestoclaw.cli.teams import is_teams_installed, teams_install

            if is_teams_installed():
                fs.update_pending(
                    fs.PENDING_TEAMS_SIDELOAD,
                    status="done",
                    extra={"reason": "already_installed"},
                )
                return

            # ``teams_install`` raises typer.Exit on success/skip with code 0
            # and on real failures with a non-zero code; both paths are
            # already handled defensively by the upstream caller.
            try:
                teams_install(package=None, open_teams=False, quiet=True)
                fs.update_pending(fs.PENDING_TEAMS_SIDELOAD, status="done")
            except SystemExit as exc:  # typer.Exit subclasses SystemExit
                code = getattr(exc, "code", 1)
                if not isinstance(code, int):
                    code = 1
                if code == 0:
                    fs.update_pending(fs.PENDING_TEAMS_SIDELOAD, status="done")
                else:
                    fs.update_pending(
                        fs.PENDING_TEAMS_SIDELOAD,
                        status="failed",
                        error=f"teams_install exited with code {code}",
                    )
        except BaseException as exc:  # noqa: BLE001 — see module docstring
            logger.debug("teams sideload background task failed: {}", exc)
            fs.update_pending(
                fs.PENDING_TEAMS_SIDELOAD,
                status="failed",
                error=f"{type(exc).__name__}: {str(exc)[:200]}",
            )

    return _spawn("teams_sideload", _worker)


def fire_mcp_silent_acquire(client_ids: list[str]) -> threading.Thread:
    """Fan-out: warm the MSAL cache for each MCP server's client_id.

    Every MCP server eventually calls :func:`acquire_token_silent` from
    its own first request. Doing those acquires upfront — in parallel —
    means the user's first chat message doesn't block on a cold cache.
    Failures are non-fatal: the per-request path will simply re-acquire
    on demand.
    """
    fs.update_pending(
        fs.PENDING_MCP_SILENT,
        status="pending",
        extra={"client_count": len(client_ids)},
    )

    def _worker() -> None:
        fs.update_pending(fs.PENDING_MCP_SILENT, status="running")
        warmed = 0
        failures: list[str] = []
        try:
            from praestoclaw.mcp.auth import _acquire_msal_token

            for cid in client_ids:
                try:
                    # Use ``.default`` so we don't have to know the per-server scopes.
                    token = _acquire_msal_token(cid, [f"{cid}/.default"])
                    if token:
                        warmed += 1
                except Exception as exc:  # noqa: BLE001
                    failures.append(f"{cid[:8]}: {type(exc).__name__}")
            fs.update_pending(
                fs.PENDING_MCP_SILENT,
                status="done",
                extra={"warmed": warmed, "failures": failures or None},
            )
        except BaseException as exc:  # noqa: BLE001
            logger.debug("mcp silent acquire background task failed: {}", exc)
            fs.update_pending(
                fs.PENDING_MCP_SILENT,
                status="failed",
                error=f"{type(exc).__name__}: {str(exc)[:200]}",
            )

    return _spawn("mcp_silent_acquire", _worker)


def fire_marketplace_install(
    selected_ids: list[str],
    *,
    local_config_path: str | None = None,
) -> threading.Thread:
    """Fan-out: clone & install the given marketplace ids in the background.

    Used by ``pc init --quick`` (and the install.ps1 / install.sh paths
    that drive it) so the wizard's [6/7] step can return in ~50 ms while
    the actual ``git clone`` for ~230 skills proceeds without blocking
    the user. Progress and per-bundle counts land in
    ``pending.marketplace_install`` and the Web Portal status bar polls
    ``/api/fre/state`` to render them.

    ``local_config_path``: optional path to ``praestoclaw.local.yaml`` so
    the worker can register the cloned repos under ``skills.marketplaces``
    after installation. When omitted the marketplaces are still installed
    (skills become usable) but the Portal's marketplace list won't show
    them until next ``pc init`` run \u2014 acceptable trade-off for retries
    fired from the Portal where we don't have the original config path.
    """
    fs.update_pending(
        fs.PENDING_MARKETPLACE,
        status="pending",
        extra={"selected": list(selected_ids), "installed": 0, "errors": 0},
    )

    def _worker() -> None:
        fs.update_pending(fs.PENDING_MARKETPLACE, status="running")
        installed_total = 0
        error_total = 0
        per_bundle: dict[str, dict[str, int]] = {}
        try:
            # Heavy imports deferred onto the worker thread.
            import shutil as _shutil

            from praestoclaw.skills.marketplace import (
                BUILTIN_MARKETPLACES,
                bulk_install_from_source,
                clone_or_update_github_repo,
                get_install_dir,
                get_marketplace_cache_dir,
            )

            if _shutil.which("git") is None:
                fs.update_pending(
                    fs.PENDING_MARKETPLACE,
                    status="failed",
                    error="git not installed",
                )
                return

            cache_dir = get_marketplace_cache_dir()
            install_dir = get_install_dir()
            wanted = set(selected_ids)

            # Process in BUILTIN_MARKETPLACES order so the Portal sees
            # bundles complete in a deterministic, user-visible order.
            for m in BUILTIN_MARKETPLACES:
                if m.id not in wanted:
                    continue
                bundle_stats = {"installed": 0, "skipped": 0, "errors": 0}
                per_bundle[m.id] = bundle_stats
                # Surface "currently working on …" via the extras so the
                # Portal status bar can render a sub-label.
                fs.update_pending(
                    fs.PENDING_MARKETPLACE,
                    status="running",
                    extra={
                        "current": m.id,
                        "current_label": m.label,
                        "per_bundle": per_bundle,
                        "installed": installed_total,
                        "errors": error_total,
                    },
                )
                try:
                    repo_path = clone_or_update_github_repo(m.repo, cache_dir)
                except Exception as exc:  # noqa: BLE001
                    bundle_stats["errors"] = 1
                    error_total += 1
                    logger.debug("marketplace clone failed for {}: {}", m.repo, exc)
                    continue

                source_path = repo_path / m.subpath if m.subpath else repo_path
                if not source_path.is_dir():
                    bundle_stats["errors"] = 1
                    error_total += 1
                    source_path = repo_path

                try:
                    installed, skipped, errors = bulk_install_from_source(
                        source_path,
                        m.id,
                        m.label,
                        m.format,
                        install_dir,
                        skill_file=m.skill_file,
                        recommended=m.recommended,
                    )
                except Exception as exc:  # noqa: BLE001
                    bundle_stats["errors"] += 1
                    error_total += 1
                    logger.debug("bulk_install failed for {}: {}", m.id, exc)
                    continue
                bundle_stats["installed"] = installed
                bundle_stats["skipped"] = skipped
                bundle_stats["errors"] += len(errors)
                installed_total += installed
                error_total += len(errors)

                # Best-effort: register the source in praestoclaw.local.yaml
                # so the Portal's Skills > Marketplace page lists it.
                if local_config_path:
                    try:
                        _register_marketplace_in_local_config(
                            local_config_path,
                            m.id,
                            m.label,
                            str(source_path),
                            m.format,
                        )
                    except Exception as exc:  # noqa: BLE001
                        logger.debug(
                            "register marketplace in local config failed for {}: {}", m.id, exc
                        )

            fs.update_pending(
                fs.PENDING_MARKETPLACE,
                status="done",
                extra={
                    "installed": installed_total,
                    "errors": error_total,
                    "per_bundle": per_bundle,
                    "current": None,
                    "current_label": None,
                },
            )
        except BaseException as exc:  # noqa: BLE001
            logger.debug("marketplace install background task failed: {}", exc)
            fs.update_pending(
                fs.PENDING_MARKETPLACE,
                status="failed",
                error=f"{type(exc).__name__}: {str(exc)[:200]}",
                extra={
                    "installed": installed_total,
                    "errors": error_total,
                    "per_bundle": per_bundle,
                },
            )

    return _spawn("marketplace_install", _worker)


def fire_external_import(
    local_config: dict,
    *,
    subscribed_projects: list[str],
    local_config_path: str | None = None,
) -> threading.Thread:
    """Fan-out: import external/profile-scoped skills in the background."""
    fs.update_pending(
        fs.PENDING_EXTERNAL_IMPORT,
        status="pending",
        extra={"subscribed_projects": list(subscribed_projects), "imported": 0},
    )
    import copy

    config_snapshot = copy.deepcopy(local_config)

    def _worker() -> None:
        fs.update_pending(fs.PENDING_EXTERNAL_IMPORT, status="running")
        try:
            from pathlib import Path as _Path

            import yaml

            from praestoclaw.cli.import_external import run_import_setup
            from praestoclaw.config.loader import LOCAL_CONFIG_HEADER, save_yaml

            summary = run_import_setup(
                config_snapshot,
                quick=True,
                subscribed_projects=subscribed_projects,
                step_number=None,
                silent=True,
            )
            if local_config_path:
                path = _Path(local_config_path)
                with _CONFIG_WRITE_LOCK:
                    try:
                        existing = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
                    except (OSError, yaml.YAMLError):
                        existing = {}
                    if not isinstance(existing, dict):
                        existing = {}
                    existing.setdefault("skills", {}).setdefault("marketplaces", {}).update(
                        (config_snapshot.get("skills") or {}).get("marketplaces", {})
                    )
                    save_yaml(path, existing, header=LOCAL_CONFIG_HEADER)
            extra: dict[str, object] = {
                "imported": int(summary.get("skills_imported", 0)),
                "skipped": int(summary.get("skills_skipped", 0)),
                "errors": (
                    int(summary.get("discovery_errors", 0)) + int(summary.get("install_errors", 0))
                ),
            }
            install_error_samples = summary.get("install_error_samples")
            if install_error_samples:
                extra["install_error_samples"] = list(install_error_samples)
            fs.update_pending(
                fs.PENDING_EXTERNAL_IMPORT,
                status="done",
                extra=extra,
            )
        except BaseException as exc:  # noqa: BLE001 — see module docstring
            logger.debug("external import background task failed: {}", exc)
            fs.update_pending(
                fs.PENDING_EXTERNAL_IMPORT,
                status="failed",
                error=f"{type(exc).__name__}: {str(exc)[:200]}",
            )

    return _spawn("external_import", _worker)


def _register_marketplace_in_local_config(
    local_config_path: str,
    source_id: str,
    label: str,
    source_path: str,
    fmt: str,
) -> None:
    """Read-modify-write ``praestoclaw.local.yaml`` to register a marketplace.

    The wizard's main thread also writes this file at end-of-init. The
    background install runs concurrently so this helper does its own
    read-merge-write to avoid clobbering simultaneous wizard edits. We
    accept last-write-wins on conflicting top-level keys; the marketplace
    block is small and rarely touched by humans. The :data:`_CONFIG_WRITE_LOCK`
    serialises this against the external-import worker so the two background
    workers never race on the same file.
    """
    from pathlib import Path as _Path

    import yaml

    from praestoclaw.config.loader import LOCAL_CONFIG_HEADER, save_yaml

    path = _Path(local_config_path)
    with _CONFIG_WRITE_LOCK:
        try:
            existing = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        except (OSError, yaml.YAMLError):
            existing = {}
        if not isinstance(existing, dict):
            existing = {}
        mp_section = existing.setdefault("skills", {}).setdefault("marketplaces", {})
        mp_section[source_id] = {"label": label, "path": source_path, "format": fmt}
        save_yaml(path, existing, header=LOCAL_CONFIG_HEADER)


def capture_user_from_msal(client_id: str) -> dict[str, str] | None:
    """Pull the user's Entra claims from the MSAL cache and persist them.

    Called immediately after :func:`_cloud_login_if_needed` succeeds so
    the FRE state has ``user.first_name`` etc. available to the Teams
    welcome card. Returns the canonical user dict on success, ``None``
    when no cached account is found or any step fails (silent — we do
    not want first-run to block on identity capture).
    """
    try:
        import msal  # noqa: F401  (imported here to keep wizard startup fast)

        from praestoclaw.mcp.auth import _load_msal_cache
        from praestoclaw.utils.idtoken import decode_jwt_payload

        cache, _ = _load_msal_cache(client_id)
        # Pull claims directly from cached id_tokens — no network needed.
        # MSAL stores id_tokens under CredentialType.ID_TOKEN.
        from msal import TokenCache

        for entry in cache.search(TokenCache.CredentialType.ID_TOKEN):
            secret = entry.get("secret") if isinstance(entry, dict) else None
            if not secret:
                continue
            claims = decode_jwt_payload(str(secret))
            if claims:
                return fs.update_user_from_idtoken(claims)
        return None
    except Exception as exc:  # noqa: BLE001
        logger.debug("capture_user_from_msal failed: {}", exc)
        return None


def capture_user_from_m365_cache() -> dict[str, str] | None:
    """Fallback identity capture for the M365 OS-account-picker path.

    The ``auth/m365/`` strategy stores RT + per-scope access tokens in
    ``m365_auth_cache_<tenant[:8]>.bin`` files keyed by tenant_id, not
    client_id. Microsoft access tokens are JWTs that carry the user's
    ``oid`` / ``name`` / ``preferred_username`` claims so we can decode
    any one of them to populate the FRE state.

    Returns the canonical user dict on success, ``None`` otherwise.
    """
    try:
        import json as _json

        from praestoclaw.security.secrets import decrypt_at_rest
        from praestoclaw.utils.helpers import get_auth_dir
        from praestoclaw.utils.idtoken import decode_jwt_payload

        auth_dir = get_auth_dir()
        # Match both the per-tenant filename and the legacy unprefixed one.
        candidates = sorted(auth_dir.glob("m365_auth_cache*.bin"))
        for path in candidates:
            try:
                raw = path.read_bytes()
            except OSError:
                continue
            decrypted = decrypt_at_rest(raw)
            if not decrypted:
                continue
            try:
                doc = _json.loads(decrypted.decode("utf-8"))
            except (UnicodeDecodeError, _json.JSONDecodeError):
                continue
            if not isinstance(doc, dict):
                continue
            ats = doc.get("access_tokens") or {}
            if not isinstance(ats, dict):
                continue
            for entry in ats.values():
                if not isinstance(entry, dict):
                    continue
                token = entry.get("token")
                if not token:
                    continue
                claims = decode_jwt_payload(str(token))
                if claims and (claims.get("oid") or claims.get("preferred_username")):
                    captured = fs.update_user_from_idtoken(claims)
                    # If this token's audience is Graph, reuse it for
                    # role detection. ``aud`` is set on every Entra
                    # access token; we accept either the GUID form
                    # (00000003-0000-0000-c000-000000000046) or the
                    # URL form (https://graph.microsoft.com).
                    aud = str(claims.get("aud") or "")
                    if (
                        "graph.microsoft.com" in aud
                        or aud == "00000003-0000-0000-c000-000000000046"
                    ):
                        try:
                            from praestoclaw.utils.role_detector import detect_role_via_graph

                            result = detect_role_via_graph(str(token), timeout=5.0)
                            if result is not None:
                                role, signals = result
                                fs.set_user_role(
                                    role,
                                    source="graph",
                                    job_title=signals.get("job_title", ""),
                                    department=signals.get("department", ""),
                                )
                        except Exception as exc:  # noqa: BLE001
                            logger.debug("[role] m365 detect_role_via_graph: {}", exc)
                    return captured
        return None
    except Exception as exc:  # noqa: BLE001
        logger.debug("capture_user_from_m365_cache failed: {}", exc)
        return None


def capture_user_from_azure_cli() -> dict[str, str] | None:
    """Fallback identity capture for the ``azure_cli`` auth provider.

    The Azure CLI strategy doesn't write MSAL token caches — tokens
    come from ``az account get-access-token`` on demand. To populate
    the FRE state we either:

    1. Mint a Graph access token (which is itself a JWT carrying full
       claims: ``oid``, ``preferred_username``, ``given_name``, ``tid``)
       and decode it. Cached, so essentially free after ``az login``.
    2. Fall back to ``az account show`` (UPN + tenantId only) when the
       token mint fails — still enough for the welcome card to greet
       by UPN local-part.

    Returns the canonical user dict on success, ``None`` otherwise.
    """
    try:
        import json as _json
        import subprocess

        from praestoclaw.auth.azure_cli.login import _resolve_az
        from praestoclaw.utils.idtoken import decode_jwt_payload

        az = _resolve_az()
        if az is None:
            return None

        # 1) Try a Graph token — its JWT carries the richest claims.
        try:
            tok_proc = subprocess.run(
                [
                    az,
                    "account",
                    "get-access-token",
                    "--resource",
                    "https://graph.microsoft.com",
                    "--output",
                    "json",
                ],
                check=False,
                capture_output=True,
                timeout=15,
            )
            if tok_proc.returncode == 0 and tok_proc.stdout:
                payload = _json.loads(tok_proc.stdout.decode("utf-8", errors="replace"))
                token = str(payload.get("accessToken") or "")
                if token:
                    claims = decode_jwt_payload(token)
                    if claims and (claims.get("oid") or claims.get("preferred_username")):
                        captured = fs.update_user_from_idtoken(claims)
                        # Best-effort role detection — same Graph token we
                        # just decoded. Failures (network, throttling,
                        # tenant-blocked /me) leave role as "unknown".
                        try:
                            from praestoclaw.utils.role_detector import detect_role_via_graph

                            result = detect_role_via_graph(token, timeout=5.0)
                            if result is not None:
                                role, signals = result
                                fs.set_user_role(
                                    role,
                                    source="graph",
                                    job_title=signals.get("job_title", ""),
                                    department=signals.get("department", ""),
                                )
                        except Exception as exc:  # noqa: BLE001
                            logger.debug("[role] azure_cli detect_role_via_graph: {}", exc)
                        return captured
        except (subprocess.TimeoutExpired, _json.JSONDecodeError, OSError) as exc:
            logger.debug("[azure_cli capture] get-access-token failed: {}", exc)

        # 2) Fallback: synthesise minimal claims from `az account show`.
        try:
            show_proc = subprocess.run(
                [az, "account", "show", "--output", "json"],
                check=False,
                capture_output=True,
                timeout=10,
            )
            if show_proc.returncode != 0 or not show_proc.stdout:
                return None
            account = _json.loads(show_proc.stdout.decode("utf-8", errors="replace"))
            user = account.get("user") or {}
            upn = str(user.get("name") or "").strip()
            tid = str(account.get("tenantId") or account.get("homeTenantId") or "").strip()
            if not upn:
                return None
            synth = {"preferred_username": upn, "tid": tid}
            return fs.update_user_from_idtoken(synth)
        except (subprocess.TimeoutExpired, _json.JSONDecodeError, OSError) as exc:
            logger.debug("[azure_cli capture] account show failed: {}", exc)
            return None
    except Exception as exc:  # noqa: BLE001
        logger.debug("capture_user_from_azure_cli failed: {}", exc)
        return None


__all__ = [
    "fire_teams_sideload",
    "fire_mcp_silent_acquire",
    "fire_marketplace_install",
    "await_outstanding",
    "has_outstanding",
    "capture_user_from_msal",
    "capture_user_from_m365_cache",
    "capture_user_from_azure_cli",
    "try_capture_user_best_effort",
]


def try_capture_user_best_effort(
    *,
    auth_provider: str | None = None,
    cloud_client_id: str | None = None,
) -> dict[str, str] | None:
    """Run all known identity-capture paths in order, stop on first hit.

    This is the single entry point used by every code site that wants
    to populate ``.fre-state.json -> user`` from whatever credentials
    happen to already exist on the machine. Designed to be called from:

    * ``praestoclaw init`` (interactive *and* ``--quick`` modes — the
      latter is what ``install.ps1`` runs, so without this hook the
      Web Portal / Teams welcome card greeting would never trigger
      for one-click installs).
    * ``praestoclaw teams install`` — right after the MOS3 token mint,
      since that's the first time many users actually log into Entra
      on a fresh machine.
    * The cloud channel's first-message hook — last-ditch fallback for
      users who skipped init entirely.

    None of the underlying readers ever raise; they return ``None`` on
    failure. Persistence into the FRE state happens inside each reader,
    so calling this multiple times is cheap and idempotent.

    Parameters
    ----------
    auth_provider:
        When known (``"azure_cli"``, ``"m365"`` …) we try the matching
        cache first to minimise wasted probes. Optional.
    cloud_client_id:
        The cloud channel's configured client_id, used to find an
        MSAL cache file at ``auth/token_cache_<client_id[:8]>.bin``.
        Optional — when missing we still try the shared MCP client_id
        and the Teams Toolkit client_id.

    Returns
    -------
    dict | None
        Canonical user dict on success, ``None`` if every path failed.
    """
    # Provider-specific fast path.
    if auth_provider == "azure_cli":
        captured = capture_user_from_azure_cli()
        if captured:
            return captured
    if auth_provider == "m365":
        captured = capture_user_from_m365_cache()
        if captured:
            return captured

    # MSAL caches: try the cloud channel's client_id, the shared MCP
    # app ID, and the Teams Toolkit ID. The Toolkit ID is what
    # ``praestoclaw teams install`` writes after a fresh machine's
    # first browser-based MSAL sign-in, so it's frequently the
    # only cache that exists on day-one installs.
    try:
        from praestoclaw.mcp.defaults import SHARED_ENTRA_CLIENT_ID
    except Exception:  # noqa: BLE001
        SHARED_ENTRA_CLIENT_ID = ""
    try:
        from praestoclaw.cli.teams import _TOOLKIT_CLIENT_ID  # type: ignore[attr-defined]
    except Exception:  # noqa: BLE001
        _TOOLKIT_CLIENT_ID = ""

    seen: set[str] = set()
    for cid in (cloud_client_id, SHARED_ENTRA_CLIENT_ID, _TOOLKIT_CLIENT_ID):
        if not cid or cid in seen:
            continue
        seen.add(cid)
        captured = capture_user_from_msal(cid)
        if captured:
            return captured

    # M365 OS-picker cache — works for the OS-account-picker path even
    # when ``auth_provider`` was unset.
    captured = capture_user_from_m365_cache()
    if captured:
        return captured

    # Last-ditch: ``az`` may be signed in for other work (Dev Box,
    # corporate scripts) even when the user picked a different
    # PraestoClaw provider.
    return capture_user_from_azure_cli()
