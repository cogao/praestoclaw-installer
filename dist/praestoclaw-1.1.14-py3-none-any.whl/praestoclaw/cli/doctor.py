"""praestoclaw doctor — health diagnostics command."""

from __future__ import annotations

import sys

import typer
from rich.panel import Panel

from praestoclaw.config.loader import load_config
from praestoclaw.config.schema import AppConfig


def doctor(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """Run health diagnostics and report issues."""
    from praestoclaw.cli.commands import console

    console.print(
        Panel("[bold]PraestoClaw Doctor[/bold]", title="Diagnostics", border_style="blue")
    )
    issues: list[str] = []
    warnings: list[str] = []

    # 1. Python version
    py_version = sys.version_info
    if py_version >= (3, 11):
        console.print(
            f"  [green]PASS[/green]  Python {py_version.major}.{py_version.minor}.{py_version.micro}"
        )
    else:
        msg = f"Python >= 3.11 required, found {py_version.major}.{py_version.minor}"
        console.print(f"  [red]FAIL[/red]  {msg}")
        issues.append(msg)

    # 2. Config validity
    try:
        cfg = load_config(config, profile)
        console.print("  [green]PASS[/green]  Configuration valid")
    except Exception as exc:
        msg = f"Config error: {exc}"
        console.print(f"  [red]FAIL[/red]  {msg}")
        issues.append(msg)
        # Cannot continue most checks without config
        _doctor_summary(issues, warnings)
        return

    # 3. LLM provider connectivity
    with console.status("[dim]Checking LLM provider\u2026[/dim]"):
        _doctor_check_provider(cfg, issues, warnings)

    # 4. Required packages
    _doctor_check_packages(cfg, issues, warnings)

    # 5. Tool availability
    _doctor_check_tools(cfg, issues, warnings)

    # 6. Credentials
    _doctor_check_credentials(cfg, issues, warnings)

    # 7. Secret store
    with console.status("[dim]Checking secret store\u2026[/dim]"):
        _doctor_check_secret_store(cfg, issues, warnings)

    # 8. Agency CLI (for bundled MCP servers)
    _doctor_check_agency(cfg, issues, warnings)

    # 9. Cloud auth tenant alignment
    _doctor_check_cloud_tenant(cfg, issues, warnings)

    _doctor_summary(issues, warnings)


def _doctor_check_provider(cfg: AppConfig, issues: list[str], warnings: list[str]) -> None:
    """Check whether the LLM provider keys are set."""
    import os

    from praestoclaw.cli.commands import console
    from praestoclaw.security.secrets import get_secret

    github_token = (
        get_secret("GITHUB_COPILOT_TOKEN")
        or get_secret("GITHUB_TOKEN")
        or os.environ.get("GITHUB_TOKEN")
    )
    openai_key = (
        get_secret("OPENAI_API_KEY")
        or get_secret("AZURE_API_KEY")
        or os.environ.get("OPENAI_API_KEY")
        or os.environ.get("AZURE_API_KEY")
    )

    has_key = any(k for k in [github_token, openai_key])

    if has_key:
        console.print("  [green]PASS[/green]  LLM provider API key found")
    else:
        msg = (
            "No LLM API key found. Run: pc secrets set GITHUB_COPILOT_TOKEN "
            "or pc secrets set OPENAI_API_KEY"
        )
        console.print(f"  [yellow]WARN[/yellow]  {msg}")
        warnings.append(msg)


def _doctor_check_packages(cfg: AppConfig, issues: list[str], warnings: list[str]) -> None:
    """Check optional dependency packages."""
    from praestoclaw.cli.commands import console

    optional_deps: list[tuple[str, str, bool]] = [
        ("fastapi", "web server", cfg.channels.web.enabled),
        ("uvicorn", "web server", cfg.channels.web.enabled),
        ("apscheduler", "cron service", cfg.cron.enabled),
        ("playwright", "browser tool", cfg.tools.browser.enabled),
    ]
    for pkg, purpose, needed in optional_deps:
        try:
            __import__(pkg)
            console.print(f"  [green]PASS[/green]  {pkg} installed")
        except ImportError:
            if needed:
                msg = f"{pkg} not installed (required for {purpose}): pip install {pkg}"
                console.print(f"  [red]FAIL[/red]  {msg}")
                issues.append(msg)
            else:
                console.print(f"  [dim]SKIP[/dim]  {pkg} (not needed — {purpose} disabled)")


def _doctor_check_tools(cfg: AppConfig, issues: list[str], warnings: list[str]) -> None:
    """Check that configured tools are known."""
    from praestoclaw.agent.tools.registry import PROTECTED_TOOLS
    from praestoclaw.cli.commands import console

    # tools=None means "all registered tools" — nothing to validate for those agents
    has_auto = cfg.agents.default.tools is None
    agent_tools: set[str] = set(cfg.agents.default.tools or [])
    for _name, ag in cfg.agents.agents.items():
        if ag.tools is None:
            has_auto = True
        else:
            agent_tools.update(ag.tools)

    unknown = agent_tools - PROTECTED_TOOLS
    if unknown:
        msg = f"Unknown tools referenced in agent config: {', '.join(sorted(unknown))}"
        console.print(f"  [yellow]WARN[/yellow]  {msg}")
        warnings.append(msg)
    else:
        auto_note = " (some agents use auto-populated tools)" if has_auto else ""
        console.print(
            f"  [green]PASS[/green]  All configured tools are valid ({len(agent_tools)} explicit tools){auto_note}"
        )


def _doctor_check_credentials(_cfg: AppConfig, _issues: list[str], _warnings: list[str]) -> None:
    """Check credential provider setup."""
    from praestoclaw.cli.commands import console

    console.print("  [green]PASS[/green]  Credential provider: env")


def _doctor_check_secret_store(cfg: AppConfig, issues: list[str], warnings: list[str]) -> None:
    """Check secret store backend status and master key source."""
    from praestoclaw.cli.commands import console

    try:
        from praestoclaw.security.secrets import get_secret_store

        store = get_secret_store(cfg)
        console.print(f"  [green]PASS[/green]  Secret store: {store.backend_info()}")
    except Exception as exc:
        msg = f"Secret store unavailable: {exc}"
        console.print(f"  [yellow]WARN[/yellow]  {msg}")
        warnings.append(msg)

    # Master key source
    from praestoclaw.security.secrets import (
        _try_master_key_from_env,
        _try_master_key_from_file,
        _try_master_key_from_keyring,
    )

    if _try_master_key_from_keyring():
        console.print("  [green]PASS[/green]  Master key: OS keyring")
    elif _try_master_key_from_env():
        console.print("  [green]PASS[/green]  Master key: environment variable")
    elif _try_master_key_from_file():
        console.print(
            "  [yellow]WARN[/yellow]  Master key: plain file (install keyring for better security)"
        )
        warnings.append("Master key stored as plain file")
    else:
        console.print(
            "  [dim]INFO[/dim]  Master key: not initialized (run `pc secrets set` to create)"
        )

    # Auth directory
    from praestoclaw.utils.helpers import get_auth_dir

    auth_dir = get_auth_dir()
    if auth_dir.is_dir():
        console.print(f"  [green]PASS[/green]  Auth directory: {auth_dir}")
    else:
        console.print(f"  [dim]INFO[/dim]  Auth directory not yet created: {auth_dir}")


def _doctor_check_agency(cfg: AppConfig, issues: list[str], warnings: list[str]) -> None:
    """Check that the `agency` CLI is installed when bundled MCP servers need it."""
    import shutil
    import sys as _sys

    from praestoclaw.cli.commands import console

    needed = [
        name
        for name, srv in cfg.tools.mcp_servers.items()
        if srv.command == "agency" and srv.enabled is not False
    ]
    count = len(needed)

    if count == 0:
        console.print(
            "  [dim]SKIP[/dim]  Agency CLI not needed (no agency-backed MCP servers enabled)"
        )
        return

    path = shutil.which("agency")
    if path:
        console.print(
            f"  [green]PASS[/green]  Agency CLI found at {path} (serves {count} bundled MCP servers)"
        )
    else:
        msg = f"Agency CLI not installed — {count} bundled MCP servers will not work."
        console.print(f"  [red]FAIL[/red]  {msg}")
        issues.append(msg)
        if _sys.platform == "win32":
            hint = 'iex "& { $(irm https://aka.ms/InstallTool.ps1) } agency"'
        else:
            hint = "curl -sSfL https://aka.ms/InstallTool.sh | bash -s agency"
        console.print(f"          [dim]Install:[/dim] {hint}")


def _doctor_check_cloud_tenant(cfg: AppConfig, issues: list[str], warnings: list[str]) -> None:
    """Warn when the cloud auth provider would mint a token for the wrong tenant.

    Catches the common foot-gun where the default ``auth_provider=azure_cli``
    silently reuses an ``az login`` session that belongs to a personal MSA
    or a different work tenant. The cloud WebSocket still connects (gateway
    accepts any Entra-issued token with an ``oid``), but Teams messages —
    routed by the configured tenant — never reach this agent.

    Read-only: shells out to ``az account show`` and compares the returned
    ``tenantId`` with ``channels.cloud.tenant_id``. Skips silently when az
    is not installed or no session exists; that is not a doctor failure.
    """
    import json
    import shutil
    import subprocess

    from praestoclaw.cli.commands import console

    cloud_cfg = cfg.channels.cloud
    if not cloud_cfg.enabled or not cloud_cfg.url or not cloud_cfg.tenant_id:
        return

    provider = (getattr(cloud_cfg, "auth_provider", "azure_cli") or "azure_cli").lower()
    if provider != "azure_cli":
        return

    az = shutil.which("az")
    if az is None:
        return

    try:
        result = subprocess.run(
            [az, "account", "show", "--output", "json"],
            check=False,
            capture_output=True,
            timeout=10,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return
    if result.returncode != 0 or not result.stdout:
        return

    try:
        info = json.loads(result.stdout.decode("utf-8", errors="replace"))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return

    az_tid = str(info.get("tenantId") or "").strip().lower()
    az_user = str((info.get("user") or {}).get("name") or "").strip()
    cfg_tid = cloud_cfg.tenant_id.strip().lower()
    if not az_tid or az_tid == cfg_tid:
        if az_tid:
            console.print(
                f"  [green]PASS[/green]  Cloud auth tenant matches `az` session ({az_user})"
            )
        return

    msg = (
        f"`az` is signed in as {az_user or '?'} (tenant {az_tid}), but cloud expects {cfg_tid}. "
        f"Teams will show this agent as OFFLINE. Fix: set "
        f"`channels.cloud.auth_provider: browser` in praestoclaw.local.yaml, then "
        f"re-run `pc cloud --login browser` to sign in with the correct account."
    )
    console.print(f"  [yellow]WARN[/yellow]  {msg}")
    warnings.append(msg)


def _doctor_summary(issues: list[str], warnings: list[str]) -> None:
    """Print the doctor summary."""
    from praestoclaw.cli.commands import console

    console.print()
    if not issues and not warnings:
        console.print(Panel("[green]All checks passed![/green]", border_style="green"))
    elif not issues:
        console.print(
            Panel(
                f"[yellow]{len(warnings)} warning(s)[/yellow], 0 errors",
                border_style="yellow",
            )
        )
    else:
        console.print(
            Panel(
                f"[red]{len(issues)} error(s)[/red], [yellow]{len(warnings)} warning(s)[/yellow]",
                border_style="red",
            )
        )
