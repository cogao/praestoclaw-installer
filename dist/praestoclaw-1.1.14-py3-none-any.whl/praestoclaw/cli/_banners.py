"""Startup banners surfaced once per CLI entry point.

Right now the only banner is for the OS sandbox — the loguru WARNING that
``Sandbox._rebuild_os_sandbox`` emits is easy to miss in mixed log output,
so we render a colored rich Panel after Runtime init so users actually
notice whether kernel-level protection is in effect.

Only entry points that start the agent loop (``chat`` / ``serve`` /
``cloud`` / the default launch) should call this — helper subcommands
like ``status`` / ``mcp list`` are not real launches and don't need the
banner noise.
"""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel

from praestoclaw.security.sandbox import Sandbox

_TITLES = {
    "active": "[bold green]🔒 Sandbox active[/bold green]",
    "inactive": "[bold yellow]⚠ Sandbox INACTIVE[/bold yellow]",
    "disabled": "[bold cyan]🔓 Sandbox off — kernel isolation available[/bold cyan]",
    "danger": "[bold red]☠ Sandbox DISABLED (danger_full_access)[/bold red]",
}

_BORDERS = {
    "active": "green",
    "inactive": "yellow",
    "disabled": "cyan",
    "danger": "red",
}

# Onboarding pointer shown in the disabled banner — the feature is opt-in by
# default and users won't discover it from CLI flags alone. Mention the YAML
# field and the kill-switch env var so they know both how to turn it on and
# how to turn it back off if it bites.
_DISABLED_ONBOARDING = (
    "[bold]Enable kernel-level sandboxing[/bold] — wraps every shell/git "
    "subprocess so the OS enforces filesystem + network isolation regardless "
    "of what the LLM tries to run.\n"
    "\n"
    "Set this in [cyan]~/.praestoclaw/praestoclaw.local.yaml[/cyan]:\n"
    "[dim]security:\n"
    "  os_sandbox:\n"
    "    enabled: true\n"
    "    mode: workspace_write   # read_only | workspace_write[/dim]\n"
    "\n"
    "Platforms: macOS (Seatbelt), Linux & WSL2 (bubblewrap). Native Windows "
    "is a follow-up. Override at runtime with "
    "[cyan]PRAESTOCLAW_OS_SANDBOX_DISABLE=1[/cyan]."
)


def print_sandbox_banner(sandbox: Sandbox, console: Console) -> None:
    """Render the sandbox status as a rich Panel.

    All four states render a Panel — ``disabled`` is intentionally NOT
    silent because the feature is opt-in by default and users would never
    discover it otherwise. The disabled banner is cyan (neutral, not a
    warning) and includes the YAML snippet needed to turn the sandbox on.
    """
    status = sandbox.startup_status

    body_lines = [status.summary]
    if status.state == "disabled":
        body_lines.append("")
        body_lines.append(_DISABLED_ONBOARDING)
    elif status.hint:
        body_lines.append("")
        body_lines.append(status.hint)
    if status.state == "inactive":
        body_lines.append("")
        body_lines.append("[dim]Set PRAESTOCLAW_OS_SANDBOX_DISABLE=1 to silence this banner.[/dim]")

    console.print(
        Panel(
            "\n".join(body_lines),
            title=_TITLES[status.state],
            border_style=_BORDERS[status.state],
        )
    )
