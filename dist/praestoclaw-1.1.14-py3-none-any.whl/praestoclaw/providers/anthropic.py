"""
Anthropic provider backend — native Claude API integration.

Uses the anthropic SDK (optional dependency) to call Claude models
via the Messages API with support for cache control and thinking.
"""

from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator
from typing import Any

from praestoclaw.providers.base import LLMChunk, LLMProvider, LLMResponse, ToolCallRequest

try:
    import anthropic
    from anthropic import AsyncAnthropic
except ImportError:
    anthropic = None  # type: ignore[assignment]
    AsyncAnthropic = None  # type: ignore[assignment,misc]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _separate_system(
    messages: list[dict[str, Any]],
) -> tuple[str | None, list[dict[str, Any]]]:
    """Extract system messages and return (system_text, remaining_messages)."""
    system_parts: list[str] = []
    others: list[dict[str, Any]] = []
    for m in messages:
        if m["role"] == "system":
            system_parts.append(m["content"])
        else:
            others.append(m)
    system = "\n\n".join(system_parts) if system_parts else None
    return system, others


def _merge_consecutive_roles(
    messages: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Merge consecutive messages with the same role (Anthropic requirement)."""
    if not messages:
        return []
    merged: list[dict[str, Any]] = [messages[0].copy()]
    for m in messages[1:]:
        if m["role"] == merged[-1]["role"]:
            merged[-1]["content"] += "\n\n" + m["content"]
        else:
            merged.append(m.copy())
    return merged


def _convert_tool_schema(tool: dict[str, Any]) -> dict[str, Any]:
    """Convert OpenAI tool schema to Anthropic format."""
    func = tool["function"]
    return {
        "name": func["name"],
        "description": func.get("description", ""),
        "input_schema": func.get("parameters", {"type": "object", "properties": {}}),
    }


# ---------------------------------------------------------------------------
# Provider
# ---------------------------------------------------------------------------


class AnthropicProvider(LLMProvider):
    """Native Anthropic Messages API provider."""

    def __init__(self, *, api_key: str, base_url: str | None = None) -> None:
        if anthropic is None:
            raise ImportError(
                "The 'anthropic' package is required for AnthropicProvider. "
                "Install it with: pip install anthropic"
            )
        self._api_key = api_key
        self._base_url = base_url
        self._client: AsyncAnthropic | None = None  # type: ignore[assignment]

    def _get_client(self) -> AsyncAnthropic:  # type: ignore[return]
        if self._client is None:
            kwargs: dict[str, Any] = {"api_key": self._api_key}
            if self._base_url:
                kwargs["base_url"] = self._base_url
            self._client = AsyncAnthropic(**kwargs)
        return self._client  # type: ignore[return-value]

    @property
    def supports_cache_control(self) -> bool:
        return True

    @property
    def supports_thinking(self) -> bool:
        return True

    @property
    def api_mode(self) -> str:
        return "anthropic_messages"

    async def complete(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> LLMResponse:
        system, msgs = _separate_system(messages)
        msgs = _merge_consecutive_roles(msgs)

        kwargs: dict[str, Any] = {
            "model": model,
            "messages": msgs,
            "max_tokens": max_tokens or 4096,
        }
        if system is not None:
            kwargs["system"] = system
        if tools:
            kwargs["tools"] = [_convert_tool_schema(t) for t in tools]
        if temperature is not None:
            kwargs["temperature"] = temperature

        t0 = time.monotonic()
        client = self._get_client()
        response = await client.messages.create(**kwargs)
        duration_ms = (time.monotonic() - t0) * 1000

        # Parse response
        content_parts: list[str] = []
        tool_calls: list[ToolCallRequest] = []
        reasoning_content: str | None = None

        for block in response.content:
            if block.type == "text":
                content_parts.append(block.text)
            elif block.type == "tool_use":
                tool_calls.append(
                    ToolCallRequest(
                        id=block.id,
                        name=block.name,
                        arguments=block.input
                        if isinstance(block.input, dict)
                        else json.loads(block.input),
                    )
                )
            elif block.type == "thinking":
                reasoning_content = block.thinking

        return LLMResponse(
            content="\n".join(content_parts),
            tool_calls=tool_calls,
            finish_reason="tool_use" if tool_calls else "stop",
            model=response.model,
            prompt_tokens=response.usage.input_tokens,
            completion_tokens=response.usage.output_tokens,
            duration_ms=duration_ms,
            reasoning_content=reasoning_content,
        )

    async def stream(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> AsyncIterator[LLMChunk]:
        system, msgs = _separate_system(messages)
        msgs = _merge_consecutive_roles(msgs)

        kwargs: dict[str, Any] = {
            "model": model,
            "messages": msgs,
            "max_tokens": max_tokens or 4096,
        }
        if system is not None:
            kwargs["system"] = system
        if tools:
            kwargs["tools"] = [_convert_tool_schema(t) for t in tools]
        if temperature is not None:
            kwargs["temperature"] = temperature

        client = self._get_client()
        async with client.messages.stream(**kwargs) as stream:
            async for event in stream:
                if event.type == "content_block_delta":
                    if event.delta.type == "text_delta":
                        yield LLMChunk(content=event.delta.text)
                    elif event.delta.type == "input_json_delta":
                        # Tool input streaming - accumulate in caller
                        yield LLMChunk(content="")
                elif event.type == "message_stop":
                    yield LLMChunk(finish_reason="stop")
