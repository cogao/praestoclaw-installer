"""Structured API error classifier.

13-category error taxonomy with a 7-stage classification pipeline.
Used by FailoverProvider to determine recovery actions.
"""

from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass
from enum import Enum


class APIErrorKind(str, Enum):
    """Exhaustive API error categories."""

    AUTH = "auth"
    AUTH_PERMANENT = "auth_permanent"
    BILLING = "billing"
    RATE_LIMIT = "rate_limit"
    OVERLOADED = "overloaded"
    SERVER_ERROR = "server_error"
    TIMEOUT = "timeout"
    CONTEXT_OVERFLOW = "context_overflow"
    PAYLOAD_TOO_LARGE = "payload_too_large"
    MODEL_NOT_FOUND = "model_not_found"
    FORMAT_ERROR = "format_error"
    THINKING_SIGNATURE = "thinking_signature"
    UNKNOWN = "unknown"


@dataclass
class ClassifiedError:
    """Result of error classification with recovery hints."""

    kind: APIErrorKind
    status_code: int | None = None
    provider: str | None = None
    model: str | None = None
    message: str = ""
    retryable: bool = True
    should_compress: bool = False
    should_rotate_credential: bool = False
    should_fallback: bool = False


# --- Pattern tables ---

_THINKING_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"thinking.*signature", re.IGNORECASE),
    re.compile(r"signature.*thinking", re.IGNORECASE),
]

_CONTEXT_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"context.length", re.IGNORECASE),
    re.compile(r"maximum.*token", re.IGNORECASE),
    re.compile(r"too many tokens", re.IGNORECASE),
    re.compile(r"content.*too large", re.IGNORECASE),
]

_RATE_LIMIT_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"rate.limit", re.IGNORECASE),
    re.compile(r"too many requests", re.IGNORECASE),
    re.compile(r"try again later", re.IGNORECASE),
    re.compile(r"quota.*exceeded", re.IGNORECASE),
]

_AUTH_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"unauthorized", re.IGNORECASE),
    re.compile(r"invalid.*api.key", re.IGNORECASE),
    re.compile(r"authentication", re.IGNORECASE),
]

_BILLING_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"billing", re.IGNORECASE),
    re.compile(r"payment.*required", re.IGNORECASE),
    re.compile(r"insufficient.*funds", re.IGNORECASE),
]

_MODEL_NOT_FOUND_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"model.*not.*found", re.IGNORECASE),
    re.compile(r"does not exist", re.IGNORECASE),
]


def _get_message(error: BaseException) -> str:
    msg = getattr(error, "message", None)
    if isinstance(msg, str):
        return msg
    return str(error)


def _get_status(error: BaseException) -> int | None:
    code = getattr(error, "status_code", None)
    if isinstance(code, int):
        return code
    return None


def _matches(patterns: list[re.Pattern[str]], text: str) -> bool:
    return any(p.search(text) for p in patterns)


def classify_api_error(
    error: BaseException,
    *,
    provider: str | None = None,
    model: str | None = None,
    context_ratio: float = 0.0,
) -> ClassifiedError:
    """Classify an API error through a 7-stage pipeline."""
    msg = _get_message(error)
    status = _get_status(error)

    def _result(kind: APIErrorKind, **kw: object) -> ClassifiedError:
        return ClassifiedError(
            kind=kind,
            status_code=status,
            provider=provider,
            model=model,
            message=msg,
            **kw,  # type: ignore[arg-type]
        )

    # Stage 1: Thinking signature patterns
    if _matches(_THINKING_PATTERNS, msg):
        return _result(APIErrorKind.THINKING_SIGNATURE, retryable=False)

    # Stage 2: HTTP status code mapping
    if status is not None:
        if status == 401:
            return _result(APIErrorKind.AUTH, retryable=False)
        if status == 402:
            if _matches(_RATE_LIMIT_PATTERNS, msg):
                return _result(APIErrorKind.RATE_LIMIT)
            return _result(APIErrorKind.BILLING, retryable=False)
        if status == 404:
            return _result(APIErrorKind.MODEL_NOT_FOUND, retryable=False, should_fallback=True)
        if status == 413:
            return _result(APIErrorKind.PAYLOAD_TOO_LARGE, retryable=False)
        if status == 429:
            return _result(APIErrorKind.RATE_LIMIT, should_rotate_credential=True)
        if status == 400:
            if _matches(_CONTEXT_PATTERNS, msg):
                return _result(APIErrorKind.CONTEXT_OVERFLOW, should_compress=True)
            return _result(APIErrorKind.FORMAT_ERROR, retryable=False)
        if status in (500, 502):
            return _result(APIErrorKind.SERVER_ERROR)
        if status in (503, 529):
            return _result(APIErrorKind.OVERLOADED, should_fallback=True)

    # Stage 3: Message pattern matching
    if _matches(_CONTEXT_PATTERNS, msg):
        return _result(APIErrorKind.CONTEXT_OVERFLOW, should_compress=True)
    if _matches(_RATE_LIMIT_PATTERNS, msg):
        return _result(APIErrorKind.RATE_LIMIT)
    if _matches(_AUTH_PATTERNS, msg):
        return _result(APIErrorKind.AUTH, retryable=False)
    if _matches(_BILLING_PATTERNS, msg):
        return _result(APIErrorKind.BILLING, retryable=False)
    if _matches(_MODEL_NOT_FOUND_PATTERNS, msg):
        return _result(APIErrorKind.MODEL_NOT_FOUND, retryable=False, should_fallback=True)

    # Stage 4: Connection error + large session
    if isinstance(error, (ConnectionError, OSError)) and context_ratio > 0.6:
        return _result(APIErrorKind.CONTEXT_OVERFLOW, should_compress=True)

    # Stage 5: Transport errors
    if isinstance(error, (asyncio.TimeoutError, TimeoutError)):
        return _result(APIErrorKind.TIMEOUT)

    # Stage 6: OSError
    if isinstance(error, OSError):
        return _result(APIErrorKind.SERVER_ERROR)

    # Stage 7: Fallback
    return _result(APIErrorKind.UNKNOWN)
