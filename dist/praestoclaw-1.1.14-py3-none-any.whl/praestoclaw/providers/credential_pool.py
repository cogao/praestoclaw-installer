from __future__ import annotations

import secrets
import time
from dataclasses import dataclass
from typing import Literal

SelectionStrategy = Literal["fill_first", "round_robin", "random"]


@dataclass
class PooledCredential:
    id: str
    provider: str
    api_key: str | None = None
    base_url: str | None = None
    priority: int = 0
    exhausted_until: float | None = None
    request_count: int = 0

    @property
    def is_available(self) -> bool:
        return self.exhausted_until is None or time.monotonic() >= self.exhausted_until


class CredentialPool:
    def __init__(
        self,
        credentials: list[PooledCredential],
        strategy: SelectionStrategy = "fill_first",
    ) -> None:
        self._credentials = list(credentials)
        self._strategy = strategy
        self._index = 0

    @property
    def size(self) -> int:
        return len(self._credentials)

    def _available(self) -> list[PooledCredential]:
        return [c for c in self._credentials if c.is_available]

    def select(self) -> PooledCredential | None:
        if not self._credentials:
            return None

        if self._strategy == "fill_first":
            idx = self._index % len(self._credentials)
            cred = self._credentials[idx]
            if cred.is_available:
                return cred
            for c in self._credentials:
                if c.is_available:
                    return c
            return None

        if self._strategy == "round_robin":
            idx = self._index % len(self._credentials)
            cred = self._credentials[idx]
            return cred if cred.is_available else None

        # random
        avail = self._available()
        return secrets.choice(avail) if avail else None

    def select_and_advance(self) -> PooledCredential | None:
        cred = self.select()
        if cred is not None:
            cred.request_count += 1
            if self._strategy == "round_robin":
                self._index = (self._index + 1) % len(self._credentials)
        return cred

    def rotate(self, *, cooldown_seconds: int = 3600) -> PooledCredential | None:
        if not self._credentials:
            return None

        idx = self._index % len(self._credentials)
        self._credentials[idx].exhausted_until = time.monotonic() + cooldown_seconds

        self._index = (idx + 1) % len(self._credentials)

        # Find next available
        for _ in range(len(self._credentials)):
            cand = self._credentials[self._index % len(self._credentials)]
            if cand.is_available:
                return cand
            self._index = (self._index + 1) % len(self._credentials)
        return None
