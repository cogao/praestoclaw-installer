"""Packaged PraestoClaw runtime assets."""
