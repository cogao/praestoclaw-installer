"""Runtime info store — generic JSON dict in ``~/.praestoclaw/runtime_info.json``.

Holds runtime-owned, machine-managed bookkeeping that is not user
configuration and not a one-shot marker. Today this is just the
``version`` field consumed by
:meth:`Runtime._notify_version_change_if_any`, but the file is shaped
as a free-form dict so future additions (last seen channel ids, last
heartbeat tick, etc.) don't require new files.

Design notes
------------
* JSON, not YAML — same reasoning as ``.fre-state.json``: the runtime
  rewrites this on every boot, so user-visible formatting / comments
  are not a goal. Atomic ``os.replace`` keeps reads consistent.
* Separate from ``.fre-state.json`` on purpose: that file mixes user
  identity, project subscriptions, and FRE wizard progress. Mixing
  pure runtime state into it would conflate human-edited fields with
  machine-rewritten ones.
* Ephemeral one-shot markers (``.update_pending``, ``.last_update_check``)
  stay as bare files because their semantics are "exists vs not".
"""

from __future__ import annotations

import json
import os
import tempfile
import threading
from pathlib import Path
from typing import Any

from loguru import logger

_FILENAME = "runtime_info.json"

# Process-wide lock — runtime_info is touched on every daemon startup
# and could theoretically race with future writers.
_save_lock = threading.Lock()


def _path() -> Path:
    # Lazy import keeps this re-entrant under ``patch("praestoclaw.utils.helpers.
    # get_data_dir", ...)`` in tests — module-level rebinding wouldn't take effect.
    from praestoclaw.utils.helpers import get_data_dir

    return get_data_dir() / _FILENAME


def load_runtime_info() -> dict[str, Any]:
    """Read the runtime info file. Missing/corrupt → empty dict."""
    path = _path()
    try:
        if not path.exists():
            return {}
        raw = path.read_text(encoding="utf-8")
        if not raw.strip():
            return {}
        data = json.loads(raw)
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning("runtime_info unreadable ({}): {} — treating as empty", path, exc)
        return {}
    if not isinstance(data, dict):
        return {}
    return data


def save_runtime_info(state: dict[str, Any]) -> None:
    """Atomically replace ``runtime_info.json`` with ``state``.

    On Windows, antivirus / Defender may briefly hold the target file while
    scanning the newly-written temp file, causing ``os.replace`` to raise
    ``PermissionError``. We retry a few times (same strategy as
    ``config.loader.save_yaml``) so a transient scan lock doesn't result in
    a missed version record — which would otherwise fire spurious repeated
    version-change notifications on every subsequent startup.
    """
    import time

    path = _path()
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(state, indent=2, sort_keys=True)
    with _save_lock:
        # Write to a temp file in the same dir, then os.replace for atomicity.
        fd, tmp_path_str = tempfile.mkstemp(
            prefix=".runtime_info.", suffix=".tmp", dir=str(path.parent)
        )
        tmp_path = Path(tmp_path_str)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fp:
                fp.write(payload)
            # Retry os.replace on Windows PermissionError (AV/Defender scan).
            last_exc: OSError | None = None
            for attempt in range(5):
                try:
                    os.replace(tmp_path, path)
                    return
                except PermissionError as exc:
                    last_exc = exc
                    time.sleep(0.05 * (attempt + 1))
            logger.warning(
                "Could not persist runtime_info after retries "
                "(Windows AV/Defender may be scanning the temp file): {}",
                last_exc,
            )
            # Best-effort direct write so the version is not lost entirely.
            try:
                path.write_text(payload, encoding="utf-8")
            except OSError:
                pass
        except OSError as exc:
            logger.warning("Could not persist runtime_info: {}", exc)
        finally:
            try:
                if tmp_path.exists():
                    tmp_path.unlink()
            except OSError:
                pass


def get_last_known_version() -> str | None:
    """Version string from the last successful daemon startup, if any."""
    val = load_runtime_info().get("version")
    return val if isinstance(val, str) and val else None


def set_last_known_version(version: str) -> None:
    """Persist the running version so the next startup can detect upgrades."""
    state = load_runtime_info()
    state["version"] = version
    save_runtime_info(state)
