"""Channel resolver — production vs staging.

Channel is decided by the entry-point invoked (``pc`` vs ``pc-staging``);
``main_staging()`` in :mod:`praestoclaw.cli.commands` calls :func:`set_channel`
before delegating to the shared Typer app. All channel-aware code paths
(data dir routing, cloud URL overlay, mirror branch selection) read from
:func:`get_channel`.
"""

from __future__ import annotations

from typing import Literal

Channel = Literal["production", "staging"]

_channel: Channel = "production"


def set_channel(channel: Channel) -> None:
    global _channel
    _channel = channel


def get_channel() -> Channel:
    return _channel


def is_staging() -> bool:
    return _channel == "staging"
