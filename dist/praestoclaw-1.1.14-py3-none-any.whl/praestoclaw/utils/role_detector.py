"""User role detection — best-effort inference from Microsoft Graph.

Role complements the *project* concept (see :mod:`praestoclaw.projects`):

* **Project** answers "which product/team are you on?" — drives which
  skill marketplace gets installed (edge-skills, societas-skills, …).
* **Role** answers "what kind of work do you do?" — used by marketplaces
  to *rank* / *filter* skills inside a marketplace (e.g. surface
  PM-friendly skills first when ``role == "pm"``). It never decides
  which marketplace gets installed.

The two axes are deliberately orthogonal so we don't fall into a
combinatorial explosion of marketplaces (``microsoft-skills-pm`` /
``microsoft-skills-dev`` …). A single ``microsoft-skills`` marketplace
just tags each skill with the roles it's relevant for.

Detection
---------

Roles are detected from the ``jobTitle`` field on the user's Microsoft
Graph ``/me`` profile. ``jobTitle`` is set by the directory admin
(HR/People Ops at Microsoft, for example) so it's a much better signal
than anything we could scrape from local repos.

We deliberately keep the role taxonomy small (~6 buckets) — the goal is
"which broad audience does this skill speak to?", not "what's this
person's exact title?". When the title doesn't match any pattern we
return ``"other"``; when there's no jobTitle at all we return
``"unknown"`` so consumers can tell the two cases apart.

Privacy
-------

All Graph data we cache is what the user's tenant already publishes in
the directory. We persist only the inferred role bucket and the raw
``jobTitle`` string (so users can audit what we matched on); department
and other PII fields are read but **not** persisted.
"""

from __future__ import annotations

import re
from typing import Any

import httpx
from loguru import logger

# ---------------------------------------------------------------------------
# Role taxonomy
# ---------------------------------------------------------------------------

#: All roles we're prepared to recognise. ``unknown`` is reserved for
#: "we couldn't infer anything"; ``other`` for "we got a title but it
#: didn't match any of our buckets". Consumers should treat unrecognised
#: values as ``unknown``.
KNOWN_ROLES: tuple[str, ...] = (
    "dev",
    "pm",
    "designer",
    "research",
    "data",
    "support",
    "manager",
    "other",
    "unknown",
)

# Patterns are checked in order; first match wins. Each pattern is a
# case-insensitive substring/regex. Keep them broad — Microsoft's
# directory uses dozens of variants for what's effectively the same role.
_TITLE_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    # Engineering / dev — order matters; we check this before "manager"
    # so "Engineering Manager" lands in dev (people-management of devs
    # still benefits from dev skills more than from generic-manager
    # skills).
    (
        "dev",
        re.compile(
            r"\b(software\s*engineer|swe|sde|developer|programmer|architect|"
            r"engineering\s*(?:manager|lead|director)|"
            r"principal\s*engineer|staff\s*engineer|"
            r"site\s*reliability|sre|devops|"
            r"applied\s*scientist)\b",
            re.I,
        ),
    ),
    # Data / ML
    (
        "data",
        re.compile(
            r"\b(data\s*(?:scientist|analyst|engineer)|"
            r"machine\s*learning|ml\s*engineer|"
            r"research\s*scientist)\b",
            re.I,
        ),
    ),
    # Product management
    (
        "pm",
        re.compile(
            r"\b(product\s*manager|program\s*manager|"
            r"technical\s*program\s*manager|tpm|pm\b|"
            r"product\s*owner)\b",
            re.I,
        ),
    ),
    # User research — checked *before* designer so "UX Researcher"
    # doesn't get caught by designer's bare "ux" substring.
    (
        "research",
        re.compile(
            r"\b(user\s*researcher|ux\s*researcher|"
            r"researcher)\b",
            re.I,
        ),
    ),
    # Design
    (
        "designer",
        re.compile(
            r"\b(designer|ux|ui\s*designer|"
            r"user\s*experience|user\s*research\s*designer|"
            r"creative\s*director)\b",
            re.I,
        ),
    ),
    # Customer support / success
    (
        "support",
        re.compile(
            r"\b(support|customer\s*success|"
            r"technical\s*account\s*manager|tam|"
            r"customer\s*engineer)\b",
            re.I,
        ),
    ),
    # Generic management — only matches if nothing more specific did
    ("manager", re.compile(r"\b(manager|director|vice\s*president|vp|chief)\b", re.I)),
)

GRAPH_ME_URL = "https://graph.microsoft.com/v1.0/me"
GRAPH_ME_SELECT = "id,jobTitle,department,officeLocation"

#: Beta endpoint that exposes :class:`workPosition` with structured
#: ``detail.role`` (= "discipline" in Microsoft tenant parlance — e.g.
#: ``Software Engineering``, ``Applied Sciences``, ``Program
#: Management``). This is the *primary* signal we now use; the v1.0
#: ``jobTitle`` regex is only a fallback for tenants where positions is
#: empty or ``detail.role`` is a string we don't recognise.
GRAPH_PROFILE_BETA_URL = "https://graph.microsoft.com/beta/me/profile"
GRAPH_PROFILE_SELECT = "positions"

#: Map Graph beta ``positionDetail.role`` enum → role bucket.
#: Microsoft tenants populate this with a small fixed vocabulary that
#: maps cleanly to our buckets — far more reliable than regex on
#: free-form jobTitle. Keys are normalised to lowercase before lookup.
#: Anything missing falls through to the jobTitle regex path.
_PROFILE_ROLE_MAP: dict[str, str] = {
    # Engineering
    "software engineering": "dev",
    "hardware engineering": "dev",
    "engineering": "dev",
    "site reliability engineering": "dev",
    # Data / ML / research-science
    "applied sciences": "data",
    "data sciences": "data",
    "data science": "data",
    "data engineering": "data",
    "machine learning": "data",
    # Product / program
    "program management": "pm",
    "product management": "pm",
    "product marketing": "pm",
    "technical program management": "pm",
    # Design
    "design": "designer",
    "product design": "designer",
    "user experience": "designer",
    # User research (separate bucket — different skill needs)
    "user research": "research",
    "research": "research",
    # Customer-facing
    "customer success": "support",
    "customer service": "support",
    "service engineering": "support",
    "support engineering": "support",
}


# ---------------------------------------------------------------------------
# Pure inference
# ---------------------------------------------------------------------------


def infer_role_from_job_title(title: str | None) -> str:
    """Map a free-form ``jobTitle`` string to one of :data:`KNOWN_ROLES`.

    Returns ``"unknown"`` if ``title`` is empty/None, ``"other"`` if a
    title is present but no bucket matches.
    """
    if not title or not isinstance(title, str):
        return "unknown"
    cleaned = title.strip()
    if not cleaned:
        return "unknown"
    for role, pattern in _TITLE_PATTERNS:
        if pattern.search(cleaned):
            return role
    return "other"


def infer_role_from_profile_role(role_value: str | None) -> str | None:
    """Map a Graph beta ``positionDetail.role`` string → role bucket.

    Returns ``None`` if the value is empty or doesn't match a known
    enum — caller should fall back to ``infer_role_from_job_title``.
    """
    if not role_value or not isinstance(role_value, str):
        return None
    key = role_value.strip().lower()
    if not key:
        return None
    return _PROFILE_ROLE_MAP.get(key)


def _pick_current_position(positions: list[Any]) -> dict[str, Any] | None:
    """Pick the most relevant entry from a ``positions`` collection.

    Prefers ``isCurrent == True``; falls back to the first dict-shaped
    entry. Returns ``None`` if the list is empty or contains no usable
    entries.
    """
    if not positions:
        return None
    for p in positions:
        if isinstance(p, dict) and p.get("isCurrent") is True:
            return p
    for p in positions:
        if isinstance(p, dict):
            return p
    return None


# ---------------------------------------------------------------------------
# Microsoft Graph
# ---------------------------------------------------------------------------


def fetch_user_profile_from_graph(
    access_token: str,
    *,
    timeout: float = 5.0,
) -> dict[str, str] | None:
    """Fetch the current user's ``/me`` profile from Microsoft Graph.

    Parameters
    ----------
    access_token:
        A valid Microsoft Graph access token (audience
        ``https://graph.microsoft.com``). The caller is responsible for
        acquiring/refreshing it; this function does no auth itself.
    timeout:
        Per-request timeout in seconds. Init blocks on this so we keep
        it short — a 5s budget covers normal network conditions and
        fails fast on captive portals / VPN issues.

    Returns
    -------
    dict | None
        ``{"job_title": str, "department": str, "office_location": str,
        "graph_id": str}`` on success, ``None`` on any failure (network
        error, non-200, malformed JSON). Empty Graph fields are
        normalised to empty strings so callers can treat the dict shape
        as stable.
    """
    if not access_token or not isinstance(access_token, str):
        return None
    try:
        resp = httpx.get(
            GRAPH_ME_URL,
            params={"$select": GRAPH_ME_SELECT},
            headers={"Authorization": f"Bearer {access_token}"},
            timeout=timeout,
        )
    except (httpx.HTTPError, OSError) as exc:
        logger.debug("[role] Graph /me request failed: {}", exc)
        return None
    if resp.status_code != 200:
        logger.debug("[role] Graph /me returned {}: {}", resp.status_code, resp.text[:200])
        return None
    try:
        data: Any = resp.json()
    except ValueError as exc:
        logger.debug("[role] Graph /me returned non-JSON: {}", exc)
        return None
    if not isinstance(data, dict):
        return None
    return {
        "graph_id": str(data.get("id") or ""),
        "job_title": str(data.get("jobTitle") or "").strip(),
        "department": str(data.get("department") or "").strip(),
        "office_location": str(data.get("officeLocation") or "").strip(),
    }


def fetch_user_positions_from_graph(
    access_token: str,
    *,
    timeout: float = 5.0,
) -> list[dict[str, Any]] | None:
    """Fetch ``/beta/me/profile?$select=positions``.

    Returns the raw ``positions`` list on success, ``None`` on any
    failure (network, non-200, malformed JSON, missing key). The beta
    endpoint is stable in practice — Outlook profile cards have used
    it for years — but we still treat 4xx/5xx as a soft fallback
    rather than a hard error so init keeps moving.
    """
    if not access_token or not isinstance(access_token, str):
        return None
    try:
        resp = httpx.get(
            GRAPH_PROFILE_BETA_URL,
            params={"$select": GRAPH_PROFILE_SELECT},
            headers={"Authorization": f"Bearer {access_token}"},
            timeout=timeout,
        )
    except (httpx.HTTPError, OSError) as exc:
        logger.debug("[role] Graph beta /me/profile failed: {}", exc)
        return None
    if resp.status_code != 200:
        logger.debug(
            "[role] Graph beta /me/profile returned {}: {}",
            resp.status_code,
            resp.text[:200],
        )
        return None
    try:
        data: Any = resp.json()
    except ValueError as exc:
        logger.debug("[role] Graph beta /me/profile returned non-JSON: {}", exc)
        return None
    if not isinstance(data, dict):
        return None
    positions = data.get("positions")
    if not isinstance(positions, list):
        return None
    return positions


def detect_role_via_graph(
    access_token: str,
    *,
    timeout: float = 5.0,
) -> tuple[str, dict[str, str]] | None:
    """Two-tier role detection: beta ``positions[].detail.role`` → v1.0 jobTitle regex.

    Order of attempts:

    1. **Beta** ``/me/profile?$select=positions`` — pick the current
       position, look up ``detail.role`` in :data:`_PROFILE_ROLE_MAP`.
       This is the most reliable signal because ``detail.role`` is a
       small fixed enum populated by HR, not free-form text.
    2. **v1.0** ``/me?$select=jobTitle,department,…`` — apply the
       jobTitle regex. Used when (a) beta returned ``[]``, (b)
       ``detail.role`` was unmapped, or (c) beta failed entirely.

    Returns ``(role, signals)`` or ``None`` if both paths fail.
    ``signals`` always carries ``job_title``, ``department``,
    ``profile_role`` so callers can persist them for audit / UI.
    """
    job_title = ""
    department = ""
    profile_role = ""

    # ---- Tier 1: beta profile.positions[].detail.role -----------------
    positions = fetch_user_positions_from_graph(access_token, timeout=timeout)
    if positions is not None:
        pos = _pick_current_position(positions)
        if pos is not None and isinstance(pos.get("detail"), dict):
            detail = pos["detail"]
            profile_role = str(detail.get("role") or "").strip()
            job_title = str(detail.get("jobTitle") or "").strip()
            mapped = infer_role_from_profile_role(profile_role)
            if mapped is not None:
                return mapped, {
                    "job_title": job_title,
                    "department": department,
                    "profile_role": profile_role,
                }

    # ---- Tier 2: v1.0 /me jobTitle regex ------------------------------
    profile = fetch_user_profile_from_graph(access_token, timeout=timeout)
    if profile is None:
        # If beta gave us *something* (just unmapped), still emit "other"
        # so the rest of init has a stable signal to log.
        if profile_role or job_title:
            return "other", {
                "job_title": job_title,
                "department": department,
                "profile_role": profile_role,
            }
        return None
    # Prefer beta's job_title if we got one; otherwise use v1.0's.
    if not job_title:
        job_title = profile.get("job_title", "")
    department = profile.get("department", "")
    role = infer_role_from_job_title(job_title)
    return role, {
        "job_title": job_title,
        "department": department,
        "profile_role": profile_role,
    }


__all__ = [
    "KNOWN_ROLES",
    "GRAPH_ME_URL",
    "GRAPH_PROFILE_BETA_URL",
    "infer_role_from_job_title",
    "infer_role_from_profile_role",
    "fetch_user_profile_from_graph",
    "fetch_user_positions_from_graph",
    "detect_role_via_graph",
]
