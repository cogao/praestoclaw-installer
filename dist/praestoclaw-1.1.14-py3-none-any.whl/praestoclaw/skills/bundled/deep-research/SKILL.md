---
name: deep-research
description: |
  Structured research: questions → sources → synthesis → draft → citation check.
  Activates for "research", "compare", "survey", "investigate technology X" requests.
metadata:
  activation:
    keywords: [research, survey, compare, investigate, 调研, 对比, 综述]
    patterns:
      - "(?i)\\b(research|survey|compare|evaluate)\\b.*\\b(options|approaches|tools|frameworks)\\b"
      - "(?i)\\bwrite\\s+a\\s+report\\b"
  workflow:
    phases: [questions, sources, synthesize, draft, cite_check]
    requires_user_confirm: [questions]
    max_turns: 100
---
## Deep Research SOP

### Step 0 — Plan first

```
plan(action="create", workflow="deep-research", items=[
  {title: "Frame research questions + scope",
   acceptance: "Numbered list of specific, answerable questions"},
  {title: "Collect sources (≥3 per major question)",
   acceptance: "Source list with URL/title/author/date for each"},
  {title: "Synthesize findings per question",
   acceptance: "Structured notes: each question answered with cited evidence"},
  {title: "Draft report with sections + executive summary",
   acceptance: "Full draft with sections + 5-bullet exec summary"},
  {title: "Citation + claim check",
   acceptance: "Every non-trivial claim traces back to a listed source"}
])
```

### Rules

1. **Confirm questions first.** `checkpoint(ask_user=true)` after framing — don't burn tokens researching the wrong question.
2. **Cite as you go.** Every fact in the draft must point to an entry in the sources list.
3. **Distinguish fact from speculation.** Mark inferences explicitly.
4. **Acknowledge gaps.** If you can't find sources, note it — never invent.
