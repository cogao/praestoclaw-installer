# Sources — Societas Privacy Champ

Traceability file: what raw materials exist, what was reviewed, and key conclusions per source.

---

## 1. Raw source inventory

### Training transcripts (VTT)

| Source | Topic | Key conclusions |
|---|---|---|
| Champs 101 Intro (March 2024) | Champ intro, pre-review, 1CS basics, low-risk signoff | 1CS Assessment = ADO User Story; generated items = Tasks; additional training needed for low-risk signoff |
| Champs 102 1CS Assessment (Feb 2024) | 1CS workflow, task handling, evidence | Pre-review improves completeness; durable evidence > fragile links; questions must be answered fully |
| Champs 103 The Privacy Review (March 2024) | Consult vs review, triggers, timing | Consult = early/no 1CS; review = mature/artifacts; new features + annual timing = triggers |
| Champs 110 Data Scout (January 2024) | Data Scout, data inventory | Data Scout = data inventory; PM compares Data Scout + DFD + DSR plan |
| DPIA Task - For Champs (Final Draft) | DPIA updates, role boundaries | DPIA update triggered by privacy-impacting changes; handled by L3 or PM |
| L3 Champs Closing Low Risk Privacy Reviews | Low-risk signoff, L3 scope | L3 can sign off low-risk; Low tag = low-risk; medium/high → PM |

### Internal privacy pages (reviewed)

| Page | Key point |
|---|---|
| M365-Privacy-Review-Process | Legacy page → points to newer guidance |
| Privacy-Reviews--When-and-How | When and how to initiate reviews |
| Trust-Data-Access-Request-vs.-Privacy-Review | DAR ≠ Privacy Review; different processes |
| M365-Trust-Privacy-Champs | Champ role and responsibilities |
| Training-and-Resource-Library | Training materials index |
| Privacy-Review-3.0 | Current review process (aka.ms/PrivacyReview3) |
| M365-Trust-Privacy-Office-Hours | Office hours for questions |
| Who-is-my-Privacy-POC | Finding your Privacy Manager |

### Taxonomy / data handling documents (reviewed via M365)

| Document | Type | Role | Version/Date | Key conclusions |
|---|---|---|---|---|
| Enterprise Data Taxonomy (Asset Classification Standard).pdf | PDF | Processor-side taxonomy | v3.94, 2025-04-30 | All data must be classified; mixed datasets = highest sensitivity; inferred data keeps source classification; NOT for controller scenarios |
| Data Handling Standards.xlsx | Excel | Handling obligations by taxonomy class | V5 (current tab) | Maps taxonomy → retention, storage, transmission, controller/processor use; model retains training data classification; V5 = current, older tabs = history |
| Controller Data Taxonomy Guide.docx | DOCX | Controller-side data type definitions | 2025-11-17 | Definitions only — use with Data Use Framework; does NOT replace privacy review; distinct from enterprise taxonomy |
| Controller Data Use Framework.xlsx | Excel | Controller data use rules | 2025-08-14 | Maps data types × 11 use categories; legal basis codes (1-6, A/B/X); Credentials Data restricted to Provide only |
| Controller Data Use Framework - old.xlsx | Excel | Historical controller framework | 7/2023 | Explicitly old; use as historical grounding only |

### Not yet mapped

- PPT / training deck files: no privacy-specific training decks reviewed yet

---

## 2. Conclusion → source traceability

| Conclusion | Source types |
|---|---|
| DAR ≠ Privacy Review | Internal pages (Trust-Data-Access-Request-vs.-Privacy-Review) |
| Consult and review are different stages | Transcripts (Champs 103) + internal pages |
| 1CS Assessment = User Story, follow-ups = Tasks | Transcripts (Champs 101) |
| Pre-review = completeness check, not approval | Transcripts (Champs 102) |
| Data Scout aligns with DFD + DSR plan | Transcripts (Champs 110) |
| DPIA updates triggered by privacy-impacting changes | Transcripts (DPIA Task) |
| Low-risk signoff by L3 champs | Transcripts (L3 Champs, Champs 101) |
| New features + annual timing = review triggers | Transcripts (Champs 103) + internal pages |
| Enterprise taxonomy ≠ controller taxonomy | Taxonomy docs (Enterprise PDF + Controller DOCX) |
| Controller taxonomy defines types; Data Use Framework defines allowed uses | Controller DOCX + Controller DUF Excel |
| Derived/model data inherits source classification | Enterprise PDF + DHS Excel V5 |
| V5 = current handling matrix; older tabs = history | DHS Excel |
