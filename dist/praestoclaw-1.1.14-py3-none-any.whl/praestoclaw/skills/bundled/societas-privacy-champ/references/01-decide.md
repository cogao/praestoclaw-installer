# Stage 0 — Decide

> **Entry:** You're considering a new feature, a change, or it's been a while since your last review.
> **Goal:** Decide whether to do nothing, a consult, or a formal review.
> **Exit:** You know which path you're on. If "review" → go to `02-kickoff.md`. If "consult" → talk to your champ.

---

## Step 1 — Check triggers

Any **one** of these means you should at least do a consult:

- New feature, service, or release
- Change to an existing feature or service
- New or changed personal data processing
- New purpose for existing data
- Notice or consent changes
- Cookies, sharing, biometrics, location, profiling, AI/ML
- ~1 year since last privacy review (annual cadence is itself a trigger)

**No triggers?** → Nothing to do now. Set a ~1-year reminder.

## Step 2 — Consult or review?

| Your situation | Path |
|---|---|
| Design still forming, ideas not locked | **Consult** first. No 1CS Assessment needed yet. |
| Feature is concrete, implementation planned | **Formal review**. Start 1CS Assessment. (`02-kickoff.md`) |
| Unsure | **Consult first.** It's lightweight and may save rework. |

**Consult ≠ review.** Consult is an informal conversation with a champ / Privacy Manager to shape the design. Formal review produces artifacts and signoff.

## Step 3 — Decide which side you're on (Controller vs Processor)

Before you engage further, know which framework applies:

- **MSA users** (consumer) → Controller side
- **AAD / Entra ID users** (enterprise) → Processor side
- **Dual-identity** → decide per data flow
- **Unclear** → ask your champ

This determines the taxonomy you'll use later. See `classification/decision-guide.md` for details.

## Step 4 — What to bring to the consult

If you're doing a consult, prepare:

- One-paragraph feature description
- What personal data is involved (rough)
- Who the users are (MSA / AAD / both)
- What's changing vs. today
- Any AI/ML, consent changes, new data sharing

---

## Common decide-stage questions

| Question | Answer |
|---|---|
| "We reviewed this a year ago, do we need another?" | Yes, annual cadence is itself a trigger. If the feature or its data use also changed, even more so. |
| "Is DAR the same as privacy review?" | No. Data Access Request is a separate process; does not replace privacy review. |
| "Is taxonomy classification enough?" | No. Classification ≠ review. Review determines the concrete outcome. |
| "Old workbook or new V5?" | Prefer V5 (current). Old is historical context only. |

More edge cases → `scenarios.md`.
