# Stage 1 — Kickoff

> **Entry:** You've decided a formal review is needed (from `01-decide.md`).
> **Goal:** Submit the 1CS Privacy Assessment and get the ADO User Story + Tasks generated.
> **Exit:** Assessment submitted, User Story created, Tasks auto-generated and assigned. Move to `03-execute.md`.

---

## Step 1 — Find your people

Before filling any forms, know who you're working with:

| Role | Why |
|---|---|
| **Privacy Champ** (regular) | Day-to-day help, answers your questions |
| **L3 Champ** | Can sign off low-risk reviews + advanced tasks (e.g., DPIA updates) |
| **Privacy Manager** | Final signoff for medium/high/novel reviews |

Don't know who yours is? Ask your manager or check team wiki. If your team has no champ, that itself is a problem to raise.

> Template ask:
> *"Who is our team's Privacy Champ (and L3 champ)? I'm starting a privacy review for `<feature>`."*

## Step 2 — Find the tools

| Tool | For what | Where |
|---|---|---|
| **1CS Privacy Assessment** (O365 Trust) | The questionnaire that starts the review | `https://o365trustcompliance.visualstudio.com/Trust/_compliance/product/0f2370dc-d3cc-2e07-4604-540a…` → **Assessments → Compliance** |
| **Data Scout** | Data inventory / classification | `<TODO: Data Scout entry>` |
| **ADO privacy area path** | Where User Story + Tasks live | `<TODO: your team's area path>` |
| **Team privacy wiki** | Local FAQs, templates, past reviews | `<TODO: wiki link>` |

> If you don't yet have access to the 1CS portal, request it via **`aka.ms/o365Trustaccess`**. How to get the request approved / who owns approval is **outside the scope of this skill** — follow your org's standard access-request process.

If you can't access any of these, see `ops-permissions.md` before continuing.

## Step 3 — Submit the 1CS Privacy Assessment

1. Open the 1CS tool
2. Create a new assessment for your feature
3. **Answer questions accurately** — answers drive which Tasks get generated. Wrong answers = wrong Tasks = rework at pre-review.
4. Submit → creates an **ADO User Story** automatically
5. Tasks appear under the User Story, each usually mapped to an artifact you must produce

### What the Assessment asks (high level)

- Feature description, scope, user base (MSA / AAD / both)
- Personal data involved: types, source, purpose, flow
- Storage, retention, sharing, export, model usage
- Consent / notice handling
- AI/ML involvement, profiling
- Risk level self-assessment

### Common kickoff mistakes

- ❌ Rushing through the form "to get past it" → wrong Tasks generated
- ❌ Confusing MSA vs AAD context → wrong taxonomy baked in
- ❌ Listing data types from memory without checking `classification/` → inconsistencies discovered at pre-review
- ❌ Skipping consult when design was still fuzzy → review bounces

## Step 4 — Sanity check after submission

Confirm you got:

- [ ] ADO **User Story** created in the right area path
- [ ] **Tasks** auto-generated under the User Story
- [ ] Risk level assigned (Low / Medium / High)
- [ ] Champ has visibility on the User Story
- [ ] You (as owner) have edit rights

If any of these are missing → see `ops-permissions.md` or ask your champ.

---

## Kickoff-stage FAQs

| Question | Answer |
|---|---|
| "What if I answer a question wrong?" | You can edit until signoff. But wrong answers may have generated wrong Tasks — check with champ. |
| "Who can edit the Assessment?" | Typically creator + champs on the User Story. See `ops-permissions.md`. |
| "What if my feature crosses teams?" | One team owns the primary Assessment; others contribute artifacts. Clarify ownership **before** kickoff. See `ops-permissions.md`. |
| "Can I start artifacts before submitting?" | Yes, but the Tasks list may surprise you — recommended to submit first, then work from Tasks. |

More → `scenarios.md`.
