---
name: commit-code
description: Smart commit assistant — analyze staged changes, generate conventional commit messages, push to remote with platform-aware auth
metadata:
  activation:
    keywords: [commit code, commit changes, 提交代码, commit my code]
    patterns:
      - "(?i)\\bcommit\\s+(my\\s+)?(code|changes)\\b"
      - "(?i)\\b提交(代码|更改)\\b"
---
# Smart Commit Assistant

Analyze staged changes and generate clear, well-structured commit messages following Conventional Commits format.

## Modes

This skill operates in two modes:

### Interactive mode (default)
Triggered by user commands like "commit code", "/commit-code". Follows all safety boundaries and prompts for user input on ambiguous situations.

### Orchestrated mode
When invoked by another skill (e.g. `societas-bug-fix`), the caller passes `orchestrated: true` context. In this mode:
- **Skip safety boundaries**: the orchestrator is responsible for staging files (`git add`) before invoking this skill
- **Skip hook failure prompt**: on pre-commit hook failure, apply the remediation strategy below instead of asking the user
- **Skip branch naming check**: the orchestrator has already created the branch

**Hook failure remediation (orchestrated mode):**
1. Inspect the hook error output
2. Determine if the issue was **introduced by the current changes** (e.g. new lint errors, new test failures, new secret patterns in files that were modified)
3. If **yes — introduced by current changes**: report back to the orchestrator with `needs_fix: true` and the error details. The orchestrator will re-dispatch Claude Code to fix the issues, then retry commit
4. If **no — pre-existing issue** (e.g. existing lint warnings in untouched files, flaky hooks, infra issues): silently bypass with `--no-verify` and proceed

## Safety boundaries

**These apply in interactive mode only.** In orchestrated mode, the caller handles staging and the boundaries below are skipped.

Only work with what the user has already staged via `git add`. This prevents accidental inclusion of unfinished work, secrets, or large binaries that the user didn't intend to commit.

- Never run `git add`, `git reset --hard`, or any command that modifies the working tree
- Never use `--no-verify` on your own — only use it when the user explicitly chooses to bypass hooks (see "Hook failure handling" below)
- If nothing is staged, tell the user to stage files first and stop

## Workflow

### 0. Check branch naming

**Skip in orchestrated mode** — the orchestrator has already created the branch.

Verify the current branch follows the standardized naming format `users/<user-alias>/<changes-feature>`. A branch starting with `users/` is considered compliant. If not, create a new branch with this format based on user git config information before proceeding.

To extract `<user-alias>`: run `git config user.name`, take the **first word**, and convert to **lowercase** (e.g., "Huiting Chen" → "huiting").

### 1. Inspect staged changes

```bash
git status
git diff --staged
```

If there are unstaged changes, mention them informally ("I also see unstaged changes in X, Y — let me know if you want to include those") but do not act on them.

### 2. Understand the changes

Read each file's diff carefully. Figure out:
- What changed and why (feature, bugfix, refactor, chore, etc.)
- Which module/component is affected (this becomes the scope)
- Whether multiple unrelated concerns are mixed (suggest splitting if so)

### 3. Generate the commit message

Follow Conventional Commits with optional emoji:

```
<type>(<scope>): <emoji> <short description>

<body — what and why, not how>

- <emoji> <change point 1>
- <emoji> <change point 2>
```

Rules:
- **English only** for all commit messages — this is a hard requirement
- Title line: imperative mood ("Add feature" not "Added feature"), max 100 chars
- Body: max 4000 chars total (Azure DevOps / GitHub limit)
- If content is too long, keep the most important points and trim the rest

Type → emoji mapping:
- `feat` ✨ | `fix` 🐛 | `docs` 📝 | `style` 💄 | `refactor` ♻️
- `perf` ⚡️ | `test` ✅ | `chore` 🔧 | `security` 🔒 | `build` 🔨
- `ci` 👷 | `revert` ⏪ | `remove` 🗑️

Scope should name the affected module (e.g., `feat(auth)`, `fix(api)`). Use `*` or omit scope when changes span many modules.

### 4. Commit

Before committing, consider:
- If changes touch **5+ files** or **3+ unrelated features**, ask whether to split into multiple commits
- Check if the project has AGENTS.md or similar conventions to follow

Use HEREDOC for multi-line messages to preserve formatting:

```bash
git commit -m "$(cat <<'EOF'
<title line>

<body>
EOF
)"
```

### 5. Push to remote

After a successful commit, push the current branch to the remote. Get the current branch name via `git branch --show-current`.

First, detect the remote platform by inspecting the remote URL:

```bash
git remote get-url origin
```

- **Azure DevOps** (URL contains `dev.azure.com` or `visualstudio.com`): use token authentication:

  ```bash
  # 499b84ac-... is the well-known Azure DevOps resource ID (not tenant-specific)
  git -c http.extraHeader="Authorization: Bearer $(az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798 --query accessToken -o tsv)" push origin <current-branch-name>
  ```

- **Other platforms** (GitHub, GitLab, Bitbucket, etc.): push directly:

  ```bash
  git push origin <current-branch-name>
  ```

- If the push fails due to authentication or network issues, show the error and let the user decide how to proceed
- Do NOT skip this step — pushing is part of the commit workflow

### 6. Hook failure handling

If the commit fails due to a pre-commit hook:

**Orchestrated mode:** Follow the "Hook failure remediation" in the Modes section above.

**Interactive mode:** Do NOT silently retry or add `--no-verify`. Instead, use `AskUserQuestion` to let the user decide:

- **Option 1: "Skip hooks (--no-verify)"** — re-run the same commit with `--no-verify`. Describe this as a conscious bypass, not a default.
- **Option 2: "Wait for me to fix"** — stop and let the user fix the issue themselves, then re-run `/commit` when ready.

Show the hook error output so the user can make an informed choice. The default recommendation should lean toward fixing, since hooks exist for a reason — but sometimes a known-flaky hook or a false positive makes bypassing the right call, and that's the user's judgment to make.
