"""Deterministic renderer for Societas Shiproom current/view.html.

This module intentionally hard-codes the page structure and CSS so different
agents cannot invent different dashboard layouts during /sr-prep.

================================================================================
HARD FORMATTING RULES (do not relax without updating prep.md §6.2)
================================================================================

These rules govern the ① To Do action-item table rendered from
``current/updates/1-todo.md``. They exist because Loop's innerText dump is
noisy (person chips emit both an "RY" avatar token and a "Rick Yang" full
name, dates appear in mixed locales, etc.). The parser must always normalize
to the canonical forms below — any new ETA / owner format spotted in the
wild MUST be added to ``_ETA_PAT`` / ``_normalize_eta`` / ``_NAME_PAT`` /
``_dedupe_owners`` rather than papered over downstream.

Owner column
------------
* Always render **full names only** (e.g. "Wenbiao Ding / Rick Yang").
* Drop bare initials ("RY", "WD") when at least one full name exists in the
  same chunk. Initials are only kept as a last-resort fallback when no full
  name is available, so we never show an empty Owner cell.
* Multiple owners are joined with " / ", deduped, original order preserved.
* Full-name detection: an English token with a space ("Rick Yang") or any
  CJK characters (``[\u4e00-\u9fa5]``) counts as a full name. Pure 2–4
  uppercase letters are treated as initials.

ETA column
----------
* Always render as ``YYYY-MM-DD``. Never leak Loop's raw strings into the
  table.
* Accepted input formats (extend ``_normalize_eta`` when you see new ones):
    - ``2026-05-26``
    - ``2026年5月26日`` / ``2026年5月26日周二``
    - ``May 26, 2026`` / ``Tue, May 26, 2026`` / ``May 26 2026``
    - ``5月26日`` (no year → assume current year)
    - ``5/26``   (no year → assume current year)
* If parsing fails, the original string is kept verbatim — that's a signal
  to add a new branch to ``_normalize_eta``, not to leave it broken.

Item / Notes columns
--------------------
* Anything in the chunk before the progress cell that is neither an ETA
  match nor a name match is treated as **item continuation** and joined to
  the item description with " — " (Loop frequently splits long titles
  across two rows).
* Notes is everything after the progress cell, space-joined.

Progress column
---------------
* Detected by exact (case-insensitive) match against
  ``{"in progress", "completed", "not started"}``.

Prep-summary prose
------------------
* Top Risks list and each section's intro bullets come from
  ``0-meeting-prep-summary.md`` and pass through this renderer **verbatim**.
  Full-name / no-initials enforcement for that prose lives in
  ``framework/rules/prep.md`` §6.1.1 rule 6, not here — do not try to
  rewrite owner names downstream.
"""
from __future__ import annotations

import datetime as dt
import html
import re
from dataclasses import dataclass


SECTION_SOURCES = {
    "todo": "current/updates/1-todo.md",
    "data": "current/updates/2-data.md",
    "ocv": "current/updates/3-ocv.md",
    "release": "current/updates/4-release.md",
    "mythos": "current/updates/5-mythos.md",
    "deep_worker": "current/updates/6-deep-worker.md",
    "others": "current/updates/7-others.md",
    "prep_summary": "current/updates/0-meeting-prep-summary.md",
    "loop": "current/currentloop.md",
    "live_notes": "current/live-notes.md",
}


@dataclass
class ViewInput:
    texts: dict[str, str]
    generated_at: dt.datetime | None = None
    archive_cutoff: dt.datetime | None = None  # set by render-view CLI from current/.last-archive


CSS = """
body{margin:0;background:#fff;color:#17212b;font:14px/1.55 "Segoe UI",Arial,sans-serif}
.page{max-width:1180px;margin:0 auto;padding:28px 32px 56px}
.toc{position:sticky;top:0;background:#fff;border-bottom:1px solid #c9d6e4;padding:10px 0;z-index:2}
.toc a{color:#0969da;text-decoration:none;margin-right:10px;white-space:nowrap}
h1{font-size:32px;margin:32px 0 8px}.meta{font-size:12px;color:#5f6b7a;border-bottom:1px solid #c9d6e4;padding-bottom:16px}
.top-risk{border:1px solid #f3c38c;background:#fff8f0;border-radius:6px;padding:16px 18px;margin:24px 0 34px}.top-risk h2{font-size:24px;margin:0 0 10px}
.section{border-top:3px solid #0969da;margin-top:36px;padding-top:24px}.section h2{background:#0969da;color:#fff;border-radius:4px;padding:10px 14px;margin:0 0 18px;font-size:24px}
h3{font-size:18px;margin:22px 0 10px;color:#0969da}
table{width:100%;border-collapse:collapse;margin:14px 0 22px}th,td{border:1px solid #d0d7de;padding:8px 10px;vertical-align:top}th{background:#f6f8fa;text-align:left}
.compact th,.compact td{font-size:13px;padding:5px 8px}
ul,ol{padding-left:24px}li{margin:6px 0}.warn{color:#b54708;font-weight:600}.bad{color:#cf222e;font-weight:600}.done,.good{color:#1a7f37;font-weight:600}.small{font-size:12px;color:#5f6b7a}.note{background:#f6f8fa;border-left:4px solid #8c959f;padding:10px 12px;margin:12px 0 18px}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin:14px 0}
.metric{border:1px solid #d0d7de;border-radius:8px;padding:10px 12px;background:#fbfcfe}
.metric h4{margin:0 0 8px;font-size:14px;color:#0969da}
.metric table{margin:0}
.loop-links{background:#f6f8fa;border:1px solid #d0d7de;border-radius:6px;padding:10px 12px;margin:12px 0 18px}.loop-links a{display:inline-block;margin:3px 12px 3px 0;color:#0969da;text-decoration:none}.loop-links a:hover{text-decoration:underline}
.loop-images{margin:14px 0 22px}.loop-images img{display:block;max-width:100%;height:auto;border:1px solid #d0d7de;border-radius:4px;margin:10px 0;background:#fff}.loop-images figure{margin:0 0 14px}.loop-images figcaption{font-size:12px;color:#5f6b7a;margin-top:4px}
code{background:#eff1f3;padding:1px 5px;border-radius:3px;font-size:13px}
td.owner{color:#0969da;font-weight:600;white-space:nowrap}
td.notes-cell{background:#fcfdff;cursor:text;min-width:240px}
td.notes-cell:focus{outline:2px solid #0969da;outline-offset:-2px;background:#fff}
td.notes-cell.edited{background:#fff8e1}
td.notes-cell.edited::after{content:" ✏";color:#b54708;font-size:11px}
.notes-meta{display:flex;justify-content:space-between;align-items:center;font-size:12px;color:#5f6b7a;margin:-6px 0 14px}
.notes-meta button{font:inherit;color:#0969da;background:none;border:none;cursor:pointer;padding:2px 6px}
.notes-meta button:hover{text-decoration:underline}
.live-notes{border:1px solid #d0d7de;border-radius:6px;background:#fbfcfe;padding:12px;margin:18px 0 4px}.live-notes h3{margin:0 0 8px;font-size:16px;color:#17212b}.live-notes textarea{box-sizing:border-box;width:100%;min-height:82px;resize:vertical;border:1px solid #d0d7de;border-radius:4px;padding:8px 10px;font:14px/1.45 "Segoe UI",Arial,sans-serif}.live-notes textarea:focus{outline:2px solid #0969da;outline-offset:1px}.live-notes-actions{display:flex;gap:10px;align-items:center;margin-top:8px}.live-notes-actions button{background:#0969da;color:#fff;border:0;border-radius:4px;padding:6px 12px;cursor:pointer;font:inherit}.live-notes-actions button:disabled{background:#8c959f;cursor:not-allowed}.live-notes-status{font-size:12px;color:#5f6b7a}.saved-live-notes{background:#f6f8fa;border-left:4px solid #0969da;padding:8px 12px;margin:0 0 10px}.saved-live-notes h4{margin:0 0 6px;font-size:13px;color:#0969da}.saved-live-notes p{margin:5px 0}
.sync-all{display:flex;gap:10px;align-items:center;background:#f6f8fa;border:1px solid #d0d7de;border-radius:6px;padding:10px 12px;margin:16px 0 24px}.sync-all button{background:#0969da;color:#fff;border:0;border-radius:4px;padding:7px 14px;cursor:pointer;font:inherit}.sync-all button:disabled{background:#8c959f;cursor:not-allowed}.sync-all-status{font-size:12px;color:#5f6b7a}
@media (max-width:780px){.grid{grid-template-columns:1fr}.toc{position:static}}
""".strip()


def render_view(payload: ViewInput) -> str:
    """Top-level wrapper. Per project policy: NEVER raise. If anything breaks
    we fall back to dumping the raw markdown so the user at least sees the
    real source content rather than a template page."""
    try:
        return _render_view_impl(payload)
    except Exception as exc:  # pragma: no cover - safety net
        return _render_view_fallback(payload, exc)


def _render_view_impl(payload: ViewInput) -> str:
    generated_at = payload.generated_at or dt.datetime.now().astimezone()
    texts = payload.texts
    title_date = generated_at.date().isoformat()
    cutoff = payload.archive_cutoff or _this_week_start()
    # Stash on a module global so legacy call sites (extract_manual_entries)
    # can read it without changing every signature.
    global _ACTIVE_CUTOFF
    _ACTIVE_CUTOFF = cutoff
    top_risk = render_top_risk(texts.get("prep_summary", ""), texts)
    body = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Shiproom {title_date}</title>
<style>{CSS}</style>
</head>
<body>
<main class="page">
<nav class="toc">
  <a href="#risk">Top Risk</a>
  <a href="#todo">①Todo</a>
  <a href="#data">②Data</a>
  <a href="#ocv">③OCV</a>
  <a href="#release">④Release</a>
    <a href="#deep-work">⑤Deep Work</a>
    <a href="#mythos">⑥Mythos Security Bugs</a>
</nav>

<h1>Shiproom {html.escape(title_date)}</h1>
<p class="meta">Source: current Loop / Data / OCV files under SharePoint current/. Generated {html.escape(generated_at.isoformat(timespec="minutes"))}.</p>

<section id="risk" class="top-risk">
  <h2>Top Risk</h2>
  {top_risk}
</section>

{render_section("todo", "1. Todo", render_todo(texts.get("todo", ""), texts.get("prep_summary", "")), texts.get("live_notes", ""))}
{render_section("data", "2. Data", render_data(texts.get("data", ""), texts.get("prep_summary", ""), texts.get("loop", "")), texts.get("live_notes", ""))}
{render_section("ocv", "3. OCV", render_ocv(texts.get("ocv", ""), texts.get("prep_summary", "")), texts.get("live_notes", ""))}
{render_section("release", "4. Release", render_release(texts.get("release", ""), texts.get("prep_summary", "")), texts.get("live_notes", ""))}
{render_section("deep-work", "5. Deep Work", render_deep_worker(texts.get("deep_worker", ""), texts.get("prep_summary", "")), texts.get("live_notes", ""))}
{render_section("mythos", "6. Mythos Security Bugs", render_mythos(texts.get("mythos", ""), texts.get("prep_summary", "")), texts.get("live_notes", ""))}

<div class="sync-all"><button type="button" id="shiproom-sync-all-notes">Sync all notes to SharePoint</button><span class="sync-all-status">Todo Notes and section Live notes autosave locally until synced.</span></div>

{render_live_notes_script()}

</main>
</body>
</html>
"""
    return body


def _render_view_fallback(payload: ViewInput, exc: Exception) -> str:
    """Last-resort renderer used only if _render_view_impl raises. Dumps every
    raw source markdown verbatim. The user sees real content, not template
    waste text."""
    generated_at = payload.generated_at or dt.datetime.now().astimezone()
    title_date = generated_at.date().isoformat()
    sections = []
    for key, path in SECTION_SOURCES.items():
        raw = (payload.texts or {}).get(key, "") or ""
        if not raw.strip():
            continue
        sections.append(
            f'<section class="section"><h2>{html.escape(key)} ({html.escape(path)})</h2>'
            f'<pre style="white-space:pre-wrap;font:13px/1.45 Consolas,monospace;">'
            f'{html.escape(raw)}</pre></section>'
        )
    return (
        f'<!doctype html><html><head><meta charset="utf-8"><title>Shiproom {title_date} (raw)</title>'
        f'<style>{CSS}</style></head><body><main class="page">'
        f'<h1>Shiproom {html.escape(title_date)} <span class="small">(raw fallback)</span></h1>'
        f'<p class="note">Structured renderer failed: <code>{html.escape(type(exc).__name__)}: {html.escape(str(exc))}</code>. '
        f'Showing raw source markdown so the meeting can still proceed.</p>'
        + "".join(sections) +
        "</main></body></html>"
    )


def render_section(anchor: str, title: str, content: str, live_notes_md: str = "") -> str:
    notes = "" if anchor == "todo" else render_live_notes_panel(anchor, title, live_notes_md)
    return f'<section id="{anchor}" class="section">\n<h2>{html.escape(title)}</h2>\n{content}\n{notes}\n</section>'


def render_live_notes_panel(anchor: str, title: str, live_notes_md: str) -> str:
    existing = render_saved_live_notes(title, live_notes_md)
    textarea_id = f"live-note-{anchor}"
    return f"""
<div class="live-notes" data-section="{html.escape(anchor)}">
    <h3>Live notes</h3>
    {existing}
    <textarea id="{html.escape(textarea_id)}" placeholder="Record meeting notes for {html.escape(title)}..."></textarea>
    <div class="live-notes-actions">
        <span class="live-notes-status">Autosaved locally. Use Sync all notes at the top when ready.</span>
    </div>
</div>
""".strip()


def render_saved_live_notes(title: str, live_notes_md: str) -> str:
    if not live_notes_md.strip():
        return ""
    title_re = re.escape(title)
    match = re.search(rf"^##\s+{title_re}\s*$", live_notes_md, re.M)
    if not match:
        return ""
    tail = live_notes_md[match.end():]
    stop = re.search(r"^##\s+", tail, re.M)
    block = tail[:stop.start()] if stop else tail
    block = block.strip()
    if not block:
        return ""
    return '<div class="saved-live-notes"><h4>Saved notes</h4>' + markdown_to_html(block) + '</div>'


def render_live_notes_script() -> str:
    return r"""
<script>
(function(){
    const NS = 'shiproom.liveNotes.v1.';
    const TODO_NS = 'shiproom.todoNotes.v1.';
    const SERVER = 'http://127.0.0.1:8765/notes';
    document.querySelectorAll('.live-notes').forEach(panel => {
        const section = panel.dataset.section;
        const textarea = panel.querySelector('textarea');
        const status = panel.querySelector('.live-notes-status');
        const key = NS + section;
        const saved = localStorage.getItem(key);
        if (saved) textarea.value = saved;
        textarea.addEventListener('input', () => {
            localStorage.setItem(key, textarea.value);
            status.textContent = 'Autosaved locally. Use Sync all notes at the top when ready.';
        });
    });
    async function postNote(section, text){
        const res = await fetch(SERVER, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({section, text})
        });
        const payload = await res.json();
        if (!res.ok || !payload.ok) throw new Error(payload.error || ('HTTP ' + res.status));
        return payload;
    }
    document.getElementById('shiproom-sync-all-notes')?.addEventListener('click', async (event) => {
        const button = event.currentTarget;
        const status = document.querySelector('.sync-all-status');
        const jobs = [];
        document.querySelectorAll('td.notes-cell.edited').forEach(td => {
            const text = td.innerText.trim();
            if (!text) return;
            jobs.push({
                section: 'todo',
                text: `Todo: ${td.dataset.item || '(item)'}\n\n${text}`,
                cleanup: () => {
                    localStorage.removeItem(TODO_NS + td.dataset.key);
                    td.dataset.default = td.innerHTML.trim();
                    td.classList.remove('edited');
                }
            });
        });
        document.querySelectorAll('.live-notes').forEach(panel => {
            const section = panel.dataset.section;
            const textarea = panel.querySelector('textarea');
            const text = textarea.value.trim();
            if (!text) return;
            jobs.push({
                section,
                text,
                cleanup: () => {
                    localStorage.removeItem(NS + section);
                    textarea.value = '';
                    const panelStatus = panel.querySelector('.live-notes-status');
                    if (panelStatus) panelStatus.textContent = 'Synced. Refresh page to show saved note.';
                }
            });
        });
        if (!jobs.length) { status.textContent = 'No notes to sync.'; return; }
        button.disabled = true;
        status.textContent = `Syncing ${jobs.length} note(s)...`;
        try {
            for (const job of jobs) {
                await postNote(job.section, job.text);
                job.cleanup();
            }
            status.textContent = `Synced ${jobs.length} note(s) to SharePoint. Refresh page to show saved notes.`;
        } catch (err) {
            status.textContent = 'Sync failed. Start live_notes_server.py and retry. ' + err.message;
        } finally {
            button.disabled = false;
        }
    });
})();
</script>
""".strip()


def render_top_risk(summary: str, texts: dict[str, str]) -> str:
    # Prep summary heading is e.g. "## 🚨 Top Risks (...)"; older variants used
    # "Top callout". Try both, fall back to generic guidance.
    items = extract_list_after_heading(summary, "Top Risks", limit=6)
    if not items:
        items = extract_list_after_heading(summary, "Top callout", limit=6)
    if has_current_data_report(texts.get("data", "")):
        items = [item for item in items if not is_stale_data_missing_risk(item)]
    if not items:
        # No matchable Top Risk heading. Rather than emit template waste text,
        # surface whatever bullets exist at the top of prep_summary so the user
        # at least sees real content. If even that is empty, return raw dump.
        items = _first_bullets_anywhere(summary, limit=6)
    if not items:
        if summary.strip():
            return f'<pre style="white-space:pre-wrap;font:13px/1.5 Consolas,monospace;">{html.escape(summary[:2000])}</pre>'
        return '<p class="note">prep_summary 为空，跑 <code>/sr-prep</code> 后再渲染。</p>'
    return "<ol>" + "".join(f"<li>{inline_md(item)}</li>" for item in items[:6]) + "</ol>"


def _first_bullets_anywhere(text: str, limit: int = 6) -> list[str]:
    out: list[str] = []
    for line in text.splitlines():
        m = re.match(r"\s*(?:\d+\.|[-*])\s+(.*)", line)
        if m:
            item = m.group(1).strip()
            if item:
                out.append(item)
                if len(out) >= limit:
                    break
    return out


def has_current_data_report(data_md: str) -> bool:
    return "Executive Overview" in data_md and "Key Takeaways" in data_md


def is_stale_data_missing_risk(item: str) -> bool:
    lowered = item.lower()
    return (
        "2-data 缺失" in item
        or "data 缺失" in item
        or "尚未上传" in item
        or "还没贴 usage" in item
        or "has not uploaded" in lowered
        or "missing data" in lowered
    )


def render_todo(todo_md: str, summary: str) -> str:
    links = render_loop_links(extract_source_links(todo_md))
    text = clean_markdown(todo_md)
    intro = section_summary(summary, "1")
    rows = parse_todo_rows(text)
    if rows:
        table = _render_todo_table(rows)
    else:
        table = markdown_to_html(text)
    manual = extract_manual_entries(todo_md)
    return _intro_html(intro) + links + table + manual


def _render_todo_table(rows: list[list[str]]) -> str:
    """Render the Todo table with:
      - Owner cells styled blue (``td.owner``).
      - Notes cells made editable + persisted to ``localStorage`` keyed by a
        stable hash of the item text, so users can amend / annotate notes and
        their edits survive future re-renders. A small toolbar lets them
        revert all edits.
    """
    headers = ["#", "Item", "Owner", "ETA", "Progress", "Notes / meeting ask"]
    head = "".join(f"<th>{inline_md(h)}</th>" for h in headers)
    body: list[str] = []
    import hashlib
    for row in rows:
        padded = (row + [""] * 6)[:6]
        num, item, owner, eta, progress, notes = padded
        key = hashlib.sha1(item.strip().encode("utf-8")).hexdigest()[:12]
        notes_html = inline_md(notes)
        body.append(
            "<tr>"
            f"<td>{inline_md(num)}</td>"
            f"<td>{inline_md(item)}</td>"
            f'<td class="owner">{inline_md(owner)}</td>'
            f"<td>{inline_md(eta)}</td>"
            f"<td>{inline_md(progress)}</td>"
            f'<td class="notes-cell" contenteditable="true" spellcheck="false" '
            f'data-key="{key}" data-item="{html.escape(item, quote=True)}" data-default="{html.escape(notes_html, quote=True)}">'
            f"{notes_html}</td>"
            "</tr>"
        )
    table = (
        f"<table><thead><tr>{head}</tr></thead>"
        f"<tbody>{''.join(body)}</tbody></table>"
    )
    toolbar = (
        '<div class="notes-meta">'
        '<span>✏ Notes 列可直接编辑，修改会自动保存在本地浏览器（localStorage），下次打开仍在。</span>'
        '<button type="button" onclick="shiproomResetNotes()">重置所有编辑</button>'
        "</div>"
    )
    script = """
<script>
(function(){
  const NS = 'shiproom.todoNotes.v1.';
  const cells = document.querySelectorAll('td.notes-cell');
  cells.forEach(td => {
    const key = NS + td.dataset.key;
    const saved = localStorage.getItem(key);
    if (saved !== null && saved !== td.dataset.default){
      td.innerHTML = saved;
      td.classList.add('edited');
    }
        td.addEventListener('input', () => {
            const cur = td.innerHTML.trim();
            if (cur === td.dataset.default){
                localStorage.removeItem(key);
                td.classList.remove('edited');
            } else {
                localStorage.setItem(key, cur);
                td.classList.add('edited');
            }
        });
    td.addEventListener('blur', () => {
      const cur = td.innerHTML.trim();
      if (cur === td.dataset.default){
        localStorage.removeItem(key);
        td.classList.remove('edited');
      } else {
        localStorage.setItem(key, cur);
        td.classList.add('edited');
      }
    });
    td.addEventListener('keydown', e => {
      // Esc reverts current cell to the freshly-loaded default.
      if (e.key === 'Escape'){
        td.innerHTML = td.dataset.default;
        localStorage.removeItem(key);
        td.classList.remove('edited');
        td.blur();
      }
    });
  });
  window.shiproomResetNotes = function(){
    if (!confirm('清除本页 Notes 列的所有本地编辑？')) return;
    cells.forEach(td => {
      localStorage.removeItem(NS + td.dataset.key);
      td.innerHTML = td.dataset.default;
      td.classList.remove('edited');
    });
  };
})();
</script>
""".strip()
    return toolbar + table + script


def render_data(data_md: str, summary: str = "", loop_md: str = "") -> str:
    # Data now comes straight from the SharePoint weekly brief (2-data.md); the
    # Loop "Business Metrics" block is no longer maintained, so we do not render
    # its links / "Key Metrics Definition Overview" / stray "(" ")" text.
    intro = section_summary(summary, "2")
    overview = extract_between(data_md, r"##\s*.*Executive Overview", r"\n##\s+Slide\s+2\b")
    if not overview.strip():
        # No Executive Overview block — dump raw data_md so user sees real content.
        raw = clean_markdown(data_md)
        if raw.strip():
            return _intro_html(intro) + markdown_to_html(raw)
        return _intro_html(intro) + '<p class="note">2-data.md 为空。</p>'
    overview = re.sub(r"<!--\s*TAKEAWAYS:START\s*-->|<!--\s*TAKEAWAYS:END\s*-->", "", overview)
    grid_html = render_data_grid(overview)
    takeaways = extract_between(overview, r"###?\s+.*Key Takeaways", r"\n##\s+|\Z")
    takeaways_html = ""
    if takeaways.strip():
        takeaways_html = "<h3>Key Takeaways</h3>" + markdown_to_html(takeaways)
    if grid_html:
        # Key Takeaways first, then Executive Overview grid.
        return _intro_html(intro) + f"{takeaways_html}<h3>Executive Overview</h3>{grid_html}"
    return _intro_html(intro) + markdown_to_html(overview)


def render_business_metrics(loop_md: str, data_md: str = "") -> str:
    block = extract_loop_block(loop_md, ["Business Metrics"], ["Customer Voice - OCV", "OCV feedback", "Consumer Release status"])
    if not block.strip():
        return ""
    links = render_loop_links(extract_source_links(block))
    images = render_loop_images(extract_source_images(block))
    text = strip_sr_image_markers(strip_sr_link_markers(block)).strip()
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    rows: list[tuple[str, str]] = []
    idx = 0
    if lines and lines[0] == "(":
        idx += 1
    if idx < len(lines) and "Key Metrics Definition Overview" in lines[idx]:
        idx += 1
    if idx < len(lines) and lines[idx] == ")":
        idx += 1
    while idx < len(lines):
        line = lines[idx]
        if line.startswith("Highlights:"):
            rows.append(("Highlights", line.split(":", 1)[1].strip()))
        elif line.startswith("Lowlights:"):
            rows.append(("Lowlights", line.split(":", 1)[1].strip()))
        elif line.startswith("Report"):
            value = line.split(":", 1)[1].strip() if ":" in line else ""
            rows.append(("Report", value))
        elif rows and rows[-1][0] == "Report":
            label, value = rows[-1]
            rows[-1] = (label, (value + " " + line).strip())
        idx += 1
    if rows:
        body = "".join(f"<p><strong>{html.escape(label)}:</strong> {inline_md(value)}</p>" for label, value in rows)
    else:
        body = markdown_to_html(text)
    overview = extract_between(data_md, r"##\s*.*Executive Overview", r"\n##\s+Slide\s+2\b")
    overview = re.sub(r"<!--\s*TAKEAWAYS:START\s*-->|<!--\s*TAKEAWAYS:END\s*-->", "", overview)
    grid_html = render_data_grid(overview) if overview.strip() else ""
    takeaways = extract_between(overview, r"###?\s+.*Key Takeaways", r"\n##\s+|\Z")
    takeaways_html = ""
    if takeaways.strip():
        takeaways_html = "<h3>Key Takeaways</h3>" + markdown_to_html(takeaways)
    report_html = ""
    if grid_html:
        report_html = f"<h3>Executive Overview</h3>{grid_html}{takeaways_html}"
    return links + body + images + report_html


def render_business_metric_links(loop_md: str) -> str:
    links = extract_business_metric_links(loop_md)
    if not links:
        return ""
    return render_loop_links(links)


def extract_business_metric_links(loop_md: str) -> list[tuple[str, str]]:
    wanted = [
        "Key Metrics Definition Overview",
        "Office Agent - Your Generalist AI Agent",
    ]
    out: list[tuple[str, str]] = []
    for label in wanted:
        url = ""
        markdown_pat = re.compile(r"\[" + re.escape(label) + r"\]\((https?://[^)]+)\)")
        marker_pat = re.compile(re.escape(label) + r"[^\n]*\[SR_LINK:\s*(https?://[^\]\s]+)\]")
        for pat in (markdown_pat, marker_pat):
            m = pat.search(loop_md)
            if m:
                url = m.group(1).strip()
                break
        if url:
            out.append((label, url))
    return out


SR_LINK_RE = re.compile(r"\s*\[SR_LINK:\s*(https?://[^\]\s]+)\]")
SR_IMAGE_RE = re.compile(r"\s*\[SR_IMAGE:\s*(https?://[^\]|\s]+)\s*(?:\|\s*([^\]]+))?\]")


def extract_loop_block(loop_md: str, start_headings: list[str], end_headings: list[str]) -> str:
    lines = loop_md.splitlines()
    start = None
    for idx, line in enumerate(lines):
        if any(_heading_line_matches(line, heading) for heading in start_headings):
            start = idx + 1
            break
    if start is None:
        return ""
    end = len(lines)
    for idx in range(start, len(lines)):
        if any(_heading_line_matches(lines[idx], heading) for heading in end_headings):
            end = idx
            break
    return "\n".join(lines[start:end]).strip()


def _heading_line_matches(line: str, heading: str) -> bool:
    stripped = re.sub(r"^\s*(?:[•●◦\-*]|\d+(?:\.\d+)*\.?)\s*", "", line).strip().lower()
    target = heading.strip().lower()
    return stripped == target or (stripped.startswith(target) and len(stripped) > len(target) and not stripped[len(target)].isalnum())


def render_loop_links(links: list[tuple[str, str]]) -> str:
    if not links:
        return ""
    anchors = "".join(
        f'<a href="{html.escape(url, quote=True)}" target="_blank" rel="noopener noreferrer">{html.escape(label)}</a>'
        for label, url in links
    )
    return f'<p class="loop-links"><strong>Loop links:</strong> {anchors}</p>'


def render_loop_images(images: list[tuple[str, str]]) -> str:
    if not images:
        return ""
    figures = []
    for url, label in images:
        caption = f"<figcaption>{html.escape(label)}</figcaption>" if label and label != "Loop image" else ""
        figures.append(
            f'<figure><img src="{html.escape(url, quote=True)}" alt="{html.escape(label, quote=True)}" loading="lazy">{caption}</figure>'
        )
    return '<div class="loop-images">' + "".join(figures) + "</div>"


def extract_source_links(text: str, limit: int = 12) -> list[tuple[str, str]]:
    links: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for line in text.splitlines():
        marker = SR_LINK_RE.search(line)
        if marker:
            url = marker.group(1).strip()
            label = SR_LINK_RE.sub("", line).strip()
            label = re.sub(r"^#+\s*", "", label)
            label = re.sub(r"_\(from Loop[^_]*\)_", "", label).strip()
            if label and (label, url) not in seen:
                links.append((label, url))
                seen.add((label, url))
        for label, url in re.findall(r"\[([^\]]+)\]\((https?://[^)]+)\)", line):
            pair = (label.strip(), url.strip())
            if pair[0] and pair not in seen:
                links.append(pair)
                seen.add(pair)
        if len(links) >= limit:
            break
    return links[:limit]


def extract_source_images(text: str, limit: int = 6) -> list[tuple[str, str]]:
    images: list[tuple[str, str]] = []
    seen: set[str] = set()
    for match in SR_IMAGE_RE.finditer(text):
        url = match.group(1).strip()
        label = (match.group(2) or "Loop image").strip()
        if url not in seen:
            images.append((url, label))
            seen.add(url)
        if len(images) >= limit:
            break
    return images


def strip_sr_link_markers(text: str) -> str:
    return SR_LINK_RE.sub("", text)


def sr_links_to_markdown(text: str) -> str:
    pat = re.compile(r"(?P<label>[^\s\[][^\[]*?)\s*\[SR_LINK:\s*(?P<url>https?://[^\]\s]+)\]")
    return pat.sub(lambda m: f"[{m.group('label').strip()}]({m.group('url')})", text)


def strip_sr_image_markers(text: str) -> str:
    return SR_IMAGE_RE.sub("", text)


def render_data_grid(overview_md: str) -> str:
    """Pick out the 4 'COLUMN N: <name>' tables and lay them out as a 2x2 grid
    of metric cards. Returns empty string if the layout cannot be detected."""
    col_pat = re.compile(r"COLUMN\s+\d+[:：]\s*([^\n]+?)\n(.*?)(?=COLUMN\s+\d+[:：]|##\s|\Z)",
                          re.S | re.I)
    cards: list[str] = []
    for m in col_pat.finditer(overview_md):
        title = re.sub(r"^[^A-Za-z\u4e00-\u9fa5]+", "", m.group(1).strip()).strip()
        body_md = m.group(2).strip()
        # Drop ad-hoc notes lines (start with ⚠ / NOTE) before the table.
        body_md = re.sub(r"^[^\n|]*$\n", "", body_md, count=1, flags=re.M)
        table = first_markdown_table(body_md)
        if not table:
            continue
        headers, rows = table
        # Re-render the table compactly with status-colored cell where possible.
        thead = "<tr>" + "".join(f"<th>{html.escape(h)}</th>" for h in headers) + "</tr>"
        body_rows = []
        for row in rows:
            # Color the WoW cell based on the row's Status emoji (🔴 / 🟢),
            # because for negative metrics (failure rates) a "+" is BAD.
            row_text = " ".join(row)
            row_cls = ""
            if "🔴" in row_text or re.search(r"\bdown\b", row_text, re.I):
                row_cls = "bad"
            elif "🟢" in row_text or re.search(r"\bup\b|goal|completed", row_text, re.I):
                row_cls = "good"
            cells_html = []
            for idx, cell_val in enumerate(row):
                hl = headers[idx].lower() if idx < len(headers) else ""
                cls = ""
                if hl in {"wow", "status"} and row_cls:
                    cls = f" class=\"{row_cls}\""
                cells_html.append(f"<td{cls}>{html.escape(cell_val)}</td>")
            body_rows.append("<tr>" + "".join(cells_html) + "</tr>")
        compact_table = (
            f"<table class=\"compact\"><thead>{thead}</thead>"
            f"<tbody>{''.join(body_rows)}</tbody></table>"
        )
        cards.append(f"<div class=\"metric\"><h4>{html.escape(title)}</h4>{compact_table}</div>")
    if len(cards) < 2:
        return ""
    return "<div class=\"grid\">" + "".join(cards) + "</div>"


def render_ocv(ocv_md: str, summary: str = "") -> str:
    intro = section_summary(summary, "3")
    links = render_loop_links(extract_source_links(ocv_md))
    text = clean_markdown(ocv_md)
    table = first_markdown_table(text)
    rows_html = ""
    if table:
        headers, rows = table
        col = {name.lower(): idx for idx, name in enumerate(headers)}
        wanted = []
        for row in rows:
            row_type = cell(row, col, "type")
            title = cell(row, col, "title")
            if "problem" in row_type.lower() or "error" in title.lower() or "busy" in title.lower():
                wanted.append([
                    cell(row, col, "items"),
                    cell(row, col, "trend"),
                    title,
                    f"{cell(row, col, 'type')} / {cell(row, col, 'state')}",
                    cell(row, col, "bugs") or cell(row, col, "comments"),
                ])
        rows_html = table_html(["Items", "Trend", "Title", "Type / State", "Bug ID / note"], wanted[:8])
    if not rows_html:
        rows_html = markdown_to_html(text)
    return _intro_html(intro) + links + rows_html


def render_release(release_md: str, summary: str = "") -> str:
    links = render_loop_links(filter_release_links(extract_source_links(release_md)))
    text = clean_markdown(release_md)
    html_parts = [links]
    consumer_html = render_release_text_block(text, "Consumer Release")
    if consumer_html:
        html_parts.append("<h3>Consumer Release Status (Qun Mi)</h3>" + consumer_html)
    lab_html = render_release_text_block(text, "Lab Release plan")
    if lab_html:
        html_parts.append("<h3>Lab Release Plan (Rick Yang)</h3>" + lab_html)
    pending_html = render_pending_release_table(text)
    if pending_html:
        html_parts.append("<h3>Pending Release</h3>" + pending_html)
    if not consumer_html and not lab_html and text.strip():
        html_parts.append(markdown_to_html(text))
    return "".join(html_parts)


def render_pending_release_table(text: str) -> str:
    """Render the Loop 'Pending release' block as a proper table.

    The Loop innerText dumps each cell on its own line, so the old flat
    paragraph rendering scattered Features/Owner/Status/Timeline/Comments into
    standalone <p> lines. Reuse the numbered-row parser instead; fall back to
    the flat rendering only when no numbered rows are found so content is never
    silently dropped.
    """
    block = extract_release_section(text, "Pending release")
    block = re.sub(r"_\(from Loop[^_]*\)_", "", block)
    block = strip_sr_image_markers(block).strip()
    if not block:
        return ""
    table = render_lab_release("", block)
    if table.strip():
        return table
    return render_release_plan_notes(block)


def filter_release_links(links: list[tuple[str, str]]) -> list[tuple[str, str]]:
    filtered: list[tuple[str, str]] = []
    for label, url in links:
        lowered = label.strip().lower()
        if lowered.startswith("lab/") or lowered.startswith("feature lists"):
            continue
        filtered.append((label, url))
    return filtered


def render_release_text_block(text: str, heading: str) -> str:
    block = extract_release_section(text, heading)
    if not block.strip():
        return ""
    block = re.split(r"\n###\s+Pending release|\nPending release:?\s*\n", block, maxsplit=1, flags=re.I)[0]
    block = re.sub(r"_\(from Loop[^_]*\)_", "", block)
    block = strip_sr_image_markers(block).strip()
    if heading.lower().startswith("consumer"):
        return render_consumer_release_notes(block)
    return render_release_plan_notes(block)


def render_release_plan_notes(block: str) -> str:
    block = strip_loop_chip_noise(block)
    lines = [ln.strip() for ln in block.splitlines() if ln.strip()]
    out: list[str] = []
    skip_next_lab_link = False
    for line in lines:
        if line.lower().startswith("feature lists"):
            skip_next_lab_link = True
            continue
        if skip_next_lab_link and re.match(r"^Lab/\d+", line, re.I):
            skip_next_lab_link = False
            continue
        skip_next_lab_link = False
        out.append(line)
    return markdown_to_html("\n".join(out))


def render_consumer_release_notes(block: str) -> str:
    block = strip_loop_chip_noise(block)
    lines = [ln.strip() for ln in block.splitlines() if ln.strip()]
    html_parts: list[str] = []
    idx = 0
    while idx < len(lines):
        line = lines[idx]
        if re.match(r"^Release\s+\S+", line, re.I):
            html_parts.append(f"<p>{inline_md(line)}</p>")
            idx += 1
            bullets: list[str] = []
            while idx < len(lines) and not re.match(r"^Release\s+\S+", lines[idx], re.I) and not lines[idx].lower().startswith("note:"):
                cur = lines[idx]
                if ":" in cur:
                    key, val = cur.split(":", 1)
                    bullets.append(f"<li><strong>{html.escape(key.strip())}:</strong> {inline_md(val.strip())}</li>")
                else:
                    bullets.append(f"<li>{inline_md(cur)}</li>")
                idx += 1
            if bullets:
                html_parts.append("<ul>" + "".join(bullets) + "</ul>")
            continue
        if line.lower().startswith("note:"):
            note = line
            idx += 1
            while idx < len(lines) and not re.match(r"^Release\s+\S+", lines[idx], re.I):
                note += " " + lines[idx]
                idx += 1
            note_text = note.split(":", 1)[1].strip() if ":" in note else note
            html_parts.append(f"<p><strong>Note:</strong> {inline_md(note_text)}</p>")
            continue
        html_parts.append(f"<p>{inline_md(line)}</p>")
        idx += 1
    return "".join(html_parts)


def extract_release_section(text: str, heading: str) -> str:
    pat = re.compile(rf"^###\s+{re.escape(heading)}[^\n]*\n", re.I | re.M)
    match = pat.search(text)
    if not match:
        return ""
    tail = text[match.end():]
    stop = re.search(r"^###\s+(?:Consumer Release|Lab Release plan|Pending release)", tail, re.I | re.M)
    return tail[:stop.start()] if stop else tail


def render_consumer_release(text: str) -> str:
    text = text.strip()
    if not text:
        return ""
    bug_pat = re.compile(r"Bug\s+(\d+):\s*(.+)", re.I)
    bugs = bug_pat.findall(text)
    status_match = re.search(r"Status:\s*([^\n]+)", text, re.I)
    release_match = re.search(r"Release\s+(\S+)", text)
    feature_match = re.search(r"Feature list:\s*([^\n]+)", text, re.I)
    status = status_match.group(1).strip() if status_match else "-"
    release = release_match.group(1).strip() if release_match else "-"
    feature = feature_match.group(1).strip() if feature_match else "-"
    summary = (
        f"<p>Consumer Release <strong>{html.escape(release)}</strong> 当前 <strong>{html.escape(status)}</strong>；"
        f"主 feature: {html.escape(feature)}。下列 bug 待收口，需在会上确认是否阻塞发版。</p>"
    )
    if not bugs:
        return summary
    rows = "".join(
        f"<tr><td>Bug {html.escape(bid)}</td><td>Open</td><td>{html.escape(desc.strip())}</td></tr>"
        for bid, desc in bugs
    )
    table = (
        "<table><thead><tr><th>Bug</th><th>Status</th><th>Title</th></tr></thead>"
        f"<tbody>{rows}</tbody></table>"
    )
    return summary + table


def render_lab_release(intro_text: str, pending_text: str) -> str:
    intro_text = intro_text.strip()
    parts: list[str] = []
    if intro_text:
        cleaned = re.sub(r"_\(from Loop[^_]*\)_", "", intro_text)
        cleaned = re.sub(r"\s+", " ", cleaned).strip()
        if cleaned:
            parts.append(f"<p>{html.escape(cleaned)}</p>")
    rows = parse_pending_release_blocks(pending_text)
    if rows:
        body = "".join(
            "<tr>"
            f"<td>{html.escape(r['num'])}</td>"
            f"<td>{html.escape(r['feature'])}</td>"
            f"<td>{html.escape(r['owner'])}</td>"
            f"<td>{html.escape(r['status'])}</td>"
            f"<td>{html.escape(r['timeline'])}</td>"
            f"<td>{html.escape(r['comments'])}</td>"
            "</tr>"
            for r in rows
        )
        parts.append(
            "<table><thead><tr><th>#</th><th>Feature</th><th>Owner</th>"
            "<th>Status</th><th>Timeline</th><th>Comments</th></tr></thead>"
            f"<tbody>{body}</tbody></table>"
        )
    return "".join(parts)


def parse_pending_release_blocks(text: str) -> list[dict]:
    text = text.strip()
    if not text:
        return []
    paras = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    rows: list[dict] = []
    i = 0
    # Skip leading column headers (Features / Owner / Status / Timeline / Comments)
    while i < len(paras) and not re.fullmatch(r"\d+", paras[i]):
        i += 1
    while i < len(paras):
        if not re.fullmatch(r"\d+", paras[i]):
            i += 1
            continue
        num = paras[i]
        j = i + 1
        chunks: list[str] = []
        while j < len(paras) and not re.fullmatch(r"\d+", paras[j]):
            chunks.append(paras[j])
            j += 1
        feature = squash(chunks[0]) if chunks else ""
        owner = collapse_owner(chunks[1]) if len(chunks) > 1 else ""
        status = ""
        timeline = ""
        comments_parts: list[str] = []
        for c in chunks[2:]:
            cs = squash(c)
            if not status and re.match(r"progress\s*:", cs, re.I):
                status = re.sub(r"^progress\s*:\s*", "", cs, flags=re.I)
            elif not timeline and re.search(r"ETA|Branch|Graph API|Tech investigation|spec confirmed|In testing", cs, re.I):
                timeline = cs
            else:
                comments_parts.append(cs)
        rows.append({
            "num": num,
            "feature": feature,
            "owner": owner,
            "status": status or "-",
            "timeline": timeline or "-",
            "comments": " · ".join(comments_parts) or "-",
        })
        i = j
    return rows


def squash(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def collapse_owner(text: str) -> str:
    # Loop alias dumps owners as initials + full name interleaved on separate lines.
    # Keep just the full names.
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    names: list[str] = []
    for ln in lines:
        if re.fullmatch(r"[A-Z]{2,3}", ln):
            continue
        names.append(ln)
    seen = []
    for n in names:
        if n not in seen:
            seen.append(n)
    return ", ".join(seen)


def render_deep_worker(deep_md: str, summary: str = "") -> str:
    links = render_loop_links(extract_source_links(deep_md))
    images = render_loop_images(extract_source_images(deep_md))
    text = clean_markdown(deep_md)
    manual = extract_manual_entries(deep_md)
    return links + render_grouped_deep_work(text) + images + manual


def render_grouped_deep_work(text: str) -> str:
    text = strip_loop_chip_noise(text)
    out: list[str] = []
    bullets: list[str] = []

    def flush() -> None:
        if bullets:
            out.append("<ul>" + "".join(f"<li>{inline_md(item)}</li>" for item in bullets) + "</ul>")
            bullets.clear()

    heading_patterns = (
        r"^PPT to DeepWork$",
        r"^工程侧进展[:：]",
        r"^Quality 侧进展[:：]",
        r"^分析case发现的一些问题$",
        r"^模型升级$",
    )
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            flush()
            continue
        if line.startswith("### "):
            flush()
            out.append(f"<h3>{inline_md(line[4:].strip())}</h3>")
            continue
        if line in {"_(empty)_", "_(no matching section found in currentloop.md)_"}:
            continue
        if any(re.search(pat, line, re.I) for pat in heading_patterns):
            flush()
            out.append(f"<p><strong>{inline_md(line)}</strong></p>")
            continue
        bullets.append(line)
    flush()
    return "\n".join(out) or "<p><em>本周无更新。</em></p>"


def render_bulleted_prose(text: str) -> str:
    text = strip_loop_chip_noise(text)
    out: list[str] = []
    bullets: list[str] = []

    def flush() -> None:
        if bullets:
            out.append("<ul>" + "".join(f"<li>{inline_md(item)}</li>" for item in bullets) + "</ul>")
            bullets.clear()

    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            flush()
            continue
        if line.startswith("### "):
            flush()
            out.append(f"<h3>{inline_md(line[4:].strip())}</h3>")
            continue
        if line.startswith("## "):
            flush()
            out.append(f"<h3>{inline_md(line[3:].strip())}</h3>")
            continue
        if line in {"_(empty)_", "_(no matching section found in currentloop.md)_"}:
            continue
        bullets.append(line)
    flush()
    return "\n".join(out) or "<p><em>本周无更新。</em></p>"


def render_mythos(mythos_md: str, summary: str = "") -> str:
    links = render_loop_links(extract_source_links(mythos_md))
    images = render_loop_images(extract_source_images(mythos_md))
    text = clean_markdown(mythos_md)
    manual = extract_manual_entries(mythos_md)
    intro = section_summary(summary, "6")
    body = render_bulleted_prose(text)
    return _intro_html(intro) + links + body + images + manual


def render_others(others_md: str, summary: str = "") -> str:
    links = render_loop_links(extract_source_links(others_md))
    text = clean_markdown(others_md)
    text = remove_heading_block(text, "Excel agent")
    intro = section_summary(summary, "7")
    if not text.strip():
        return _intro_html(intro) + links + "<p><em>本周无其他更新。</em></p>"
    return _intro_html(intro) + links + markdown_to_html(text)


def _intro_html(intro: str) -> str:
    """Emit intro markup. Never emit template waste.
    - empty/whitespace → nothing
    - already-built `<ul>...</ul>` (multi-bullet case from section_summary) → passthrough
    - single-line text → wrap as `<p>`
    """
    if not intro or not intro.strip():
        return ""
    if intro.lstrip().startswith("<ul>"):
        return intro
    return f"<p>{inline_md(intro)}</p>"


def clean_markdown(text: str) -> str:
    # Strip everything after the LOOP-SYNC end marker — that region is owned by
    # extract_manual_entries() (which applies a freshness filter). Keeping it
    # here would double-render manual updates AND bypass the freshness filter.
    if "<!-- END LOOP-SYNC -->" in text:
        text = text.split("<!-- END LOOP-SYNC -->", 1)[0]
    lines = []
    in_comment = False
    for line in text.replace("\r\n", "\n").split("\n"):
        stripped = line.strip()
        if in_comment:
            if "-->" in stripped:
                in_comment = False
            continue
        if stripped in {"<!-- BEGIN LOOP-SYNC -->", "<!-- END LOOP-SYNC -->"}:
            continue
        if stripped.startswith("<!--"):
            if "-->" not in stripped:
                in_comment = True
            continue
        if stripped.startswith("_Source:"):
            continue
        if stripped.startswith("# "):
            continue
        lines.append(strip_sr_image_markers(strip_sr_link_markers(line)))
    return "\n".join(lines).strip()


def extract_manual_entries(text: str) -> str:
    """Pull entries written after the LOOP-SYNC block (these come from
    `/sr-update`). Filters out blocks dated before this ISO week's Monday so
    last-week notes don't bleed into this week's view (this is the carry-forward
    archive safety net — see prep.md / archive.md)."""
    if "<!-- END LOOP-SYNC -->" not in text:
        return ""
    tail = text.split("<!-- END LOOP-SYNC -->", 1)[1].strip()
    if not tail:
        return ""
    fresh = _filter_fresh_manual_blocks(tail)
    if not fresh.strip():
        return ""
    return '<h3>Manual updates</h3>' + markdown_to_html(fresh)


def _this_week_start() -> dt.datetime:
    today = dt.date.today()
    monday = today - dt.timedelta(days=today.weekday())
    return dt.datetime.combine(monday, dt.time.min)


# Set by _render_view_impl before any extract_manual_entries call. Defaults to
# this week's Monday so unit tests / legacy callers still work.
_ACTIVE_CUTOFF: dt.datetime = _this_week_start()


_MANUAL_HEAD_RE = re.compile(r"^###\s+@\S+\s+·\s+(\S+)\s*$", re.M)


def _filter_fresh_manual_blocks(text: str) -> str:
    """Split tail on `### @user · ISO` headings; keep only blocks whose ISO
    timestamp is >= the active cutoff (last `/sr-archive` time, or this week's
    Monday if no archive marker exists). Blocks without a parseable timestamp
    are kept (conservative — prefer showing too much over hiding fresh content).
    """
    cutoff = _ACTIVE_CUTOFF
    cutoff_naive = cutoff.replace(tzinfo=None) if cutoff.tzinfo else cutoff
    matches = list(_MANUAL_HEAD_RE.finditer(text))
    if not matches:
        return text
    kept_chunks: list[str] = []
    if matches[0].start() > 0:
        preamble = text[:matches[0].start()].strip()
        if preamble:
            kept_chunks.append(preamble)
    for idx, m in enumerate(matches):
        ts_raw = m.group(1)
        end = matches[idx + 1].start() if idx + 1 < len(matches) else len(text)
        block = text[m.start():end].rstrip()
        try:
            ts = dt.datetime.fromisoformat(ts_raw.replace("Z", "+00:00"))
            ts_naive = ts.replace(tzinfo=None) if ts.tzinfo else ts
            if ts_naive < cutoff_naive:
                continue  # stale: older than the last archive cutoff — drop
        except ValueError:
            pass  # unparseable — keep, don't silently lose content
        kept_chunks.append(block)
    return "\n\n".join(kept_chunks)


def extract_list_after_heading(text: str, heading: str, limit: int = 5) -> list[str]:
    pattern = re.compile(rf"^##+\s+.*{re.escape(heading)}.*$", re.I | re.M)
    match = pattern.search(text)
    if not match:
        return []
    tail = text[match.end():]
    stop = re.search(r"^##\s+", tail, re.M)
    block = tail[:stop.start()] if stop else tail
    items = []
    for line in block.splitlines():
        m = re.match(r"\s*(?:\d+\.|[-*])\s+(.*)", line)
        if m:
            items.append(m.group(1).strip())
            if len(items) >= limit:
                break
    return items


_CIRCLED = {"1": "①", "2": "②", "3": "③", "4": "④", "5": "⑤", "6": "⑥", "7": "⑦"}


def section_summary(summary: str, section_number: str, fallback: str = "") -> str:
    """Find the per-section block in the prep summary and return an intro
    snippet for the dashboard. Supports `### 1 — Title`, `## ① Title (1-todo)`,
    and `## ... (1-todo)` heading shapes.

    Output rules (per project policy — NEVER emit template waste text):
      * 0 bullets / 0 paragraph found  → return fallback (default empty string).
      * 1 bullet                       → return that bullet as plain string
                                          (rendered as `<p>` by _intro_html).
      * ≥2 bullets                     → return a sentinel string starting with
                                          "<ul>" so each bullet is its own list
                                          item (avoids dense one-paragraph dump).
    """
    circled = _CIRCLED.get(section_number, "")
    patterns = [
        rf"^###\s+{re.escape(section_number)}\s+[—-].*$",
        rf"^##\s+{re.escape(circled)}\s+.*$" if circled else None,
        rf"^##\s+{re.escape(circled)}\s+.*\({section_number}-[\w-]+\).*$" if circled else None,
        rf"^##\s+.*\({section_number}-[\w-]+\).*$",
    ]
    match = None
    for pat in patterns:
        if not pat:
            continue
        match = re.search(pat, summary, re.M)
        if match:
            break
    if not match:
        return fallback
    tail = summary[match.end():]
    stop = re.search(r"^##\s+|^###\s+\d+\s+[—-]", tail, re.M)
    block = tail[:stop.start()] if stop else tail
    bullets = extract_bullets(block)
    if len(bullets) >= 2:
        return "<ul>" + "".join(f"<li>{inline_md(b)}</li>" for b in bullets) + "</ul>"
    if len(bullets) == 1:
        return bullets[0]
    for para in re.split(r"\n\s*\n", block.strip()):
        para = para.strip()
        if para and not para.startswith("|") and not para.startswith("#"):
            return re.sub(r"\s+", " ", para)
    return fallback


def extract_bullets(block: str) -> list[str]:
    out = []
    for line in block.splitlines():
        m = re.match(r"\s*[-*]\s+(.*)", line)
        if m:
            out.append(m.group(1).strip())
    return out


def extract_between(text: str, start_pat: str, end_pat: str) -> str:
    start = re.search(start_pat, text, re.I | re.M)
    if not start:
        return ""
    tail = text[start.end():]
    end = re.search(end_pat, tail, re.I | re.M)
    return tail[:end.start()] if end else tail


def extract_heading_block(text: str, heading: str) -> str:
    match = re.search(rf"^###\s+{re.escape(heading)}(?:\s+.*)?$", text, re.I | re.M)
    if not match:
        return ""
    tail = text[match.end():]
    stop = re.search(r"^###\s+", tail, re.M)
    return tail[:stop.start()] if stop else tail


def remove_heading_block(text: str, heading: str) -> str:
    pattern = re.compile(rf"^###\s+{re.escape(heading)}\s*$", re.I | re.M)
    match = pattern.search(text)
    if not match:
        return text
    tail = text[match.end():]
    stop = re.search(r"^###\s+", tail, re.M)
    end = match.end() + (stop.start() if stop else len(tail))
    return text[:match.start()] + text[end:]


# Be strict: every alternative must include at least one digit or a
# CJK "today/tomorrow/this-week" phrase. We MUST NOT match plain words
# like "ETA" or "May" that appear in notes prose.
_ETA_PAT = re.compile(
    r"\d{4}年|\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}|\d{1,2}月\d{1,2}日|"
    r"周[一二三四五六日天]|今天|明天|昨天|后天|本周|下周|"
    r"\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2}\b|"
    r"\b\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\b",
    re.I,
)
# Owner heuristic: pasted Loop mention chips arrive as a 2-line block per
# person — a 2–4 letter initials avatar ("RY") and a full name ("Rick Yang"
# or "Jianjun Chen (Societas)" or CJK "周伟伟"). Anything that doesn't fit
# either shape is treated as item continuation.
_NAME_PAT = re.compile(
    r"^[A-Z]{2,4}$"                                             # initials
    r"|^[A-Z][A-Za-z'.\-]+(?:\s+[A-Z][A-Za-z'.\-]+){0,3}"       # English full name (1–4 tokens)
    r"(?:\s*\([^)]+\))?$"                                       # optional " (Societas)" suffix
    r"|^[\u4e00-\u9fa5]{2,4}(?:\s*\([^)]+\))?$"                 # CJK full name
)


def parse_todo_rows(text: str) -> list[list[str]]:
    # Loop's heading is sometimes literally "Action Items", sometimes the
    # weekly page is just "Shiproom Current" / "Items / Owner / ETA /
    # Progress / Notes" with no inline heading. Try the explicit heading
    # first; fall back to the whole text so we still parse the table.
    items_block = (
        extract_between(text, r"###\s+Action Items", r"\n###\s+|\Z")
        or extract_between(text, r"###\s+Shiproom Current", r"\n###\s+|\Z")
        or text
    )
    lines = [ln.strip() for ln in items_block.splitlines() if ln.strip()]
    # Drop the column-header preamble ("Items / Owner / ETA / Progress /
    # Notes") so it doesn't get mistaken for the first row's item text.
    header_tokens = {"items", "owner", "eta", "progress", "notes"}
    while lines and lines[0].lower() in header_tokens:
        lines.pop(0)
    starts = [idx for idx, ln in enumerate(lines) if re.fullmatch(r"\d+", ln)]
    progress_words = {"in progress", "completed", "not started"}
    # Defense in depth: even with the loop_fetch placeholder blacklist, the
    # Loop UI may surface new empty-cell prompts. Treat these as empty.
    ui_placeholders = {
        "选择日期", "选择人员", "选择状态", "添加日期", "添加人员",
        "核对清单",  # Loop checklist widget label, leaks as a CJK 4-char chip
        "pick a date", "add a date", "select date", "select person",
        "add person", "select status",
    }
    rows = []
    for pos, start in enumerate(starts):
        end = starts[pos + 1] if pos + 1 < len(starts) else len(lines)
        chunk = lines[start + 1:end]
        if not chunk:
            continue
        # Position-independent classification: Loop renders Progress and
        # ETA as chip elements whose innerText is often empty, so we can't
        # rely on a fixed column order. Instead, walk every line in the
        # chunk and bucket it by shape (progress / eta / name / other).
        item_parts: list[str] = []
        owners: list[str] = []
        eta = ""
        progress = ""
        notes_parts: list[str] = []
        seen_anchor = False  # flips True once we hit progress or an ETA
        for val in chunk:
            low = val.lower()
            if val.strip() in ui_placeholders or low in ui_placeholders:
                continue
            if not progress and low in progress_words:
                progress = val
                seen_anchor = True
            elif not eta and len(val) <= 40 and _ETA_PAT.search(val):
                # ETA chips render as short standalone lines (e.g.
                # "2026-05-26", "5/26", "周二"). Reject long prose that
                # merely *contains* a date-ish substring (e.g.
                # "(5/11切换后支持1M)" inside a notes paragraph).
                eta = val
                seen_anchor = True
            elif _NAME_PAT.match(val):
                owners.append(val)
                # First owner also anchors the row: in weeks where ETA /
                # Progress chips are empty, subsequent non-name lines are
                # notes prose, not more item title.
                seen_anchor = True
            elif not seen_anchor:
                # Anything before the first anchor that isn't a name is
                # part of the item title (Loop frequently splits long
                # titles across multiple lines).
                item_parts.append(val)
            else:
                notes_parts.append(val)
        if not item_parts and chunk:
            # Pathological case: first line was a name/eta/progress. Keep
            # raw chunk[0] as item so the row isn't empty.
            item_parts = [chunk[0]]
        item = " — ".join(p for p in item_parts if p).strip(" —") or "-"
        owners = _dedupe_owners(owners)
        owner = " / ".join(owners) if owners else "-"
        eta = _normalize_eta(eta) if eta else "-"
        progress = progress or "-"
        notes = " ".join(notes_parts).strip()
        rows.append([str(len(rows) + 1), item, owner, eta, progress, notes])
    return rows


def _dedupe_owners(owners: list[str]) -> list[str]:
    """Keep only full names; drop bare initials (e.g. "WD"). If nothing left,
    fall back to initials so we don't lose owner info entirely."""
    full = [o for o in owners if " " in o or re.search(r"[\u4e00-\u9fa5]", o)]
    pool = full if full else owners
    seen: list[str] = []
    for o in pool:
        if o not in seen:
            seen.append(o)
    return seen


_MONTHS = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
    "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
}


def _normalize_eta(raw: str) -> str:
    """Normalize ETA strings like '2026年5月26日周二' or 'Tue, May 26, 2026'
    to 'YYYY-MM-DD'. Returns the original string when no date can be parsed."""
    s = raw.strip()
    # 2026-05-26
    m = re.search(r"(\d{4})-(\d{1,2})-(\d{1,2})", s)
    if m:
        y, mo, d = map(int, m.groups())
        return f"{y:04d}-{mo:02d}-{d:02d}"
    # 2026年5月26日
    m = re.search(r"(\d{4})年(\d{1,2})月(\d{1,2})日", s)
    if m:
        y, mo, d = map(int, m.groups())
        return f"{y:04d}-{mo:02d}-{d:02d}"
    # May 26, 2026 / May 26 2026
    m = re.search(
        r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+(\d{1,2})(?:st|nd|rd|th)?[,\s]+(\d{4})",
        s, re.I,
    )
    if m:
        mo = _MONTHS[m.group(1).lower()]
        d = int(m.group(2))
        y = int(m.group(3))
        return f"{y:04d}-{mo:02d}-{d:02d}"
    # 5月26日 (no year) -> assume current year
    m = re.search(r"(\d{1,2})月(\d{1,2})日", s)
    if m:
        from datetime import date
        mo, d = int(m.group(1)), int(m.group(2))
        return f"{date.today().year:04d}-{mo:02d}-{d:02d}"
    # 5/26 (no year)
    m = re.fullmatch(r"\s*(\d{1,2})/(\d{1,2})\s*", s)
    if m:
        from datetime import date
        mo, d = int(m.group(1)), int(m.group(2))
        return f"{date.today().year:04d}-{mo:02d}-{d:02d}"
    return s


def markdown_to_html(text: str) -> str:
    text = strip_loop_chip_noise(text)
    lines = text.strip().splitlines()
    out: list[str] = []
    paragraph: list[str] = []
    idx = 0
    while idx < len(lines):
        line = lines[idx]
        if is_table_start(lines, idx):
            flush_paragraph(out, paragraph)
            headers, rows, consumed = parse_table_at(lines, idx)
            out.append(table_html(headers, rows))
            idx += consumed
            continue
        stripped = line.strip()
        if not stripped:
            flush_paragraph(out, paragraph)
        elif stripped.startswith("### "):
            flush_paragraph(out, paragraph)
            out.append(f"<h3>{inline_md(stripped[4:].strip())}</h3>")
        elif stripped.startswith("## "):
            flush_paragraph(out, paragraph)
            out.append(f"<h3>{inline_md(stripped[3:].strip())}</h3>")
        elif re.match(r"^[-*]\s+", stripped):
            flush_paragraph(out, paragraph)
            bullets = []
            while idx < len(lines) and re.match(r"^\s*[-*]\s+", lines[idx].strip()):
                bullets.append(re.sub(r"^[-*]\s+", "", lines[idx].strip()))
                idx += 1
            out.append("<ul>" + "".join(f"<li>{inline_md(b)}</li>" for b in bullets) + "</ul>")
            continue
        else:
            paragraph.append(stripped)
        idx += 1
    flush_paragraph(out, paragraph)
    return "\n".join(out) or "<p><em>本周无更新。</em></p>"


_LOOP_PERSON_CHIP_LINES = {
    "&",
    "QM", "Qun Mi", "ZW", "Zhengda Wang",
    "RY", "Rick Yang", "SW", "Scott Wei", "JT", "Jie Tang",
    "JC", "Jianjun Chen", "Jianjun Chen (Societas)",
    "LS", "Linjun Shou", "WD", "Wenbiao Ding", "JG", "Jie Gao",
    "JH", "Jinyong", "Jinyong Huang", "Wenbiao", "WJ", "Wenkai JIANG",
    "CG", "Coraline Gao", "HC", "Huiting Chen", "SD", "Summer Deng",
    "XZ", "Xiaochun Zhao", "Xian Zhang", "SL", "Siyang Liu",
    "AY", "Alex Yuan", "Alex Yuan (PM)",
}


def strip_loop_chip_noise(text: str) -> str:
    """Drop standalone Loop avatar/person-chip lines from prose sections.

    This is intentionally applied at markdown rendering time rather than in
    clean_markdown(), because Todo's table parser still needs owner lines.
    """
    lines: list[str] = []
    for raw in text.splitlines():
        stripped = raw.strip()
        if stripped in _LOOP_PERSON_CHIP_LINES:
            continue
        if stripped in {"- BLOCKED"}:
            continue
        fixed = re.sub(r"^to update\s*", "", stripped, flags=re.I)
        fixed = re.sub(r"^update\s*", "", fixed, flags=re.I)
        fixed = fixed.replace("工程侧进展]", "工程侧进展：")
        fixed = fixed.replace("quality侧进展：", "Quality 侧进展：")
        lines.append(fixed if fixed != stripped else raw)
    return "\n".join(lines)


def flush_paragraph(out: list[str], paragraph: list[str]) -> None:
    if paragraph:
        out.extend(f"<p>{inline_md(line)}</p>" for line in paragraph if line.strip())
        paragraph.clear()


def inline_md(text: str) -> str:
    text = strip_sr_image_markers(sr_links_to_markdown(text))
    escaped = html.escape(text)
    escaped = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", escaped)
    escaped = re.sub(r"`([^`]+)`", r"<code>\1</code>", escaped)
    escaped = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', escaped)
    return escaped


def first_markdown_table(text: str) -> tuple[list[str], list[list[str]]] | None:
    lines = text.splitlines()
    for idx in range(len(lines)):
        if is_table_start(lines, idx):
            headers, rows, _ = parse_table_at(lines, idx)
            return headers, rows
    return None


def is_table_start(lines: list[str], idx: int) -> bool:
    return idx + 1 < len(lines) and lines[idx].lstrip().startswith("|") and re.match(r"^\s*\|?\s*:?-{3,}:?", lines[idx + 1]) is not None


def parse_table_at(lines: list[str], idx: int) -> tuple[list[str], list[list[str]], int]:
    headers = split_table_row(lines[idx])
    rows: list[list[str]] = []
    consumed = 2
    for line in lines[idx + 2:]:
        if not line.lstrip().startswith("|"):
            break
        rows.append(split_table_row(line))
        consumed += 1
    return headers, rows, consumed


def split_table_row(line: str) -> list[str]:
    line = line.strip().strip("|")
    return [cell.strip() for cell in line.split("|")]


def table_html(headers: list[str], rows: list[list[str]]) -> str:
    if not rows:
        return ""
    head = "".join(f"<th>{inline_md(h)}</th>" for h in headers)
    body = []
    for row in rows:
        padded = row + [""] * max(0, len(headers) - len(row))
        body.append("<tr>" + "".join(f"<td>{inline_md(c)}</td>" for c in padded[:len(headers)]) + "</tr>")
    return f"<table><thead><tr>{head}</tr></thead><tbody>{''.join(body)}</tbody></table>"


def cell(row: list[str], col: dict[str, int], name: str) -> str:
    idx = col.get(name)
    if idx is None or idx >= len(row):
        return ""
    return row[idx]