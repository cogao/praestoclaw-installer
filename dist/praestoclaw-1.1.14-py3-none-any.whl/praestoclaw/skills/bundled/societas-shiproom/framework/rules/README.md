# Rules Map

The agent reads these playbooks when handling slash commands. Each file
explains *how to behave* for a specific command family — it does not contain
executable code.

| File | Used by |
|---|---|
| [`update.md`](update.md) | `/sr-update` — decision tree, section classifier, adaptive FYI/actionable follow-up, confirmation contract, idempotency. |
| [`prep.md`](prep.md) | `/sr-prep` — host pre-meeting orchestration (6 steps: checklist → fetch-loop → data → OCV → read this week's content → generate summary + view.html). |
| [`archive.md`](archive.md) | `/sr-archive` — host post-meeting close-out (status → fetch-notes → confirm → archive → clear `current/`). |
| [`ask.md`](ask.md) | `/sr-ask` — search + citation rules across `current/` and `history/`. |

The top-level [`AGENT.md`](../../AGENT.md) registers the slash commands and
links each one back to the playbook here.

## Drift guard

`AGENT.md` §2.x quick-ref blocks and the per-command playbooks here are
both hand-maintained. To catch silent drift, run:

```bash
python framework/scripts/check_quickref_consistency.py
```

It extracts CLI subcommands, `cloud.*()` calls, and `current/` / `history/`
paths from each `AGENT.md` quick-ref section and verifies they all appear in
the matching playbook. Exit code 1 if drift is detected — wire it into your
pre-commit / CI to keep both sides in sync.
