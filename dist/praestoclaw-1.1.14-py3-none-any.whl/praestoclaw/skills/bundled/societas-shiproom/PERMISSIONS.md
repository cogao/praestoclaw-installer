---
title: Societas Shiproom — Permission Model
version: 2.0
date: 2026-05-11
audience: humans + LLM agents
---

# 权限边界

> 这个文档定义 **谁能做什么**。Agent（LLM）在执行任何命令前 **必须** 先读这一节。

Shiproom 的数据**不在 Git**，在 SharePoint。权限由 **SharePoint ACL + Azure AD** 强制执行 —— 不是 GitHub CODEOWNERS，不是 Markdown 约定。Agent 不需要自己做权限检查；Graph API 会替你拒绝越权请求。

---

## 1. 两类角色

| 角色 | 怎么判定 | 数据面权限 | 代码面权限 |
|---|---|---|---|
| **Member**（团队成员） | Azure AD 属于 Societas Teams 团队 | 读写 SharePoint `Shiproom/` 全部文件 | 只读 Git 仓库 |
| **Maintainer**（仓库 owner） | GitHub 仓库 owner | 同 Member | 可改 `societas-shiproom/` 内的代码、配置、规则 |

Agent 通过 MSAL 拿到的 JWT 里的 `upn` / `preferred_username` 就是当前用户身份。所有写入操作会以这个身份签名（`@handle` + UTC 时间戳）。

---

## 2. 数据面（SharePoint）

所有 Member 对以下路径**等权读写**，由 SharePoint 团队权限强制：

```
Shiproom/
├── current/                          ← 本周工作区
│   ├── currentloop.md                ✏️ /sr-fetch-loop 自动写（LOOP-SYNC 块源文件）
│   ├── currentloop.pdf               ✏️ host /sr-upload-loop 写（fallback）
│   ├── notes.md                      ✏️ 任何人 /sr-notes 追加 + /sr-fetch-notes 自动写入
│   ├── notes.pdf                     ✏️ host /sr-upload-notes 写（fallback）
│   └── updates/                      ✏️ member /sr-update 写自己的章节
│       ├── 0-meeting-prep-summary.md ✏️ agent /sr-prep 写
│       ├── 1-todo.md
│       ├── 2-data.md                 ✏️ Claire /sr-upload-md 写 LOOP-SYNC 块
│       ├── 3-ocv.md                  ✏️ /sr-fetch-ocv 写 LOOP-SYNC 块
│       ├── 4-release.md
│       ├── 5-mythos.md
│       ├── 6-deep-worker.md
│       └── 7-others.md
└── history/<YYYY-MM-DD>/             📦 归档(建议只读,技术上可写)
```

**规则**：
- **追加优先**：所有 `/sr-update` 走追加并签名（`@handle · timestamp`），不覆盖别人的内容。
- **不删除别人内容**：Agent 收到"删掉 X 说的话"这种请求时**必须拒绝**，让用户去 SharePoint 网页手动操作。
- **归档不可逆**：`/sr-archive` 会先抓最新 Teams meeting notes，再把 `current/` 整个搬到 `history/<date>/` 并清空。仅 host 在会后执行。

---

## 3. 代码面（Git 仓库）

仓库 `tajie_microsoft/Societas-Shiproom` 里的所有内容都是**只读的**对普通 member 而言。

| 路径 | 含义 | 谁可改 |
|---|---|---|
| `societas-shiproom/SKILL.md` `AGENT.md` `README.md` | skill 入口和契约 | maintainer |
| `societas-shiproom/framework/rules/*.md` | update/ask/analysis 策略 | maintainer |
| `societas-shiproom/framework/scripts/*.py` | cloud_io / cloud_cli | maintainer |
| `societas-shiproom/shiproom-config.yaml` | 默认配置（agenda、SharePoint ID） | maintainer |
| `shiproom-config.yaml`（仓库根，可选） | 工作区覆盖配置 | 任何 fork 该仓库的人 |

Member 如果想改规则/脚本/agenda：**提 Issue 或 PR**，由 maintainer 评审合并。

---

## 4. 命令矩阵

| 命令 | 谁能跑 | 写到哪 | 是否签名 |
|---|---|---|---|
| `/sr-whoami` | 任何人 | — | — |
| `/sr-status` | 任何人 | — | — |
| `/sr-ask` | 任何人 | — | — |
| `/sr-update <section> <text>` | member | `current/updates/<section>.md` 追加 | ✅ |
| `/sr-notes <text>` | 任何人(会中) | `current/notes.md` 追加 | ✅ |
| `/sr-upload-loop <pdf>` `/sr-upload-notes <pdf>` | host | `current/currentloop.pdf` / `notes.pdf` | — |
| `/sr-prep` | host(按惯例) | `current/updates/*` + `currentloop.pdf` | ✅ |
| `/sr-archive` | host（会后） | 先抓最新 Teams meeting notes，再 `current/` → `history/<date>/`，然后清空 | ✅ |

> "host 按惯例" = SharePoint 没有强制限制，但团队约定由当周会议主持人执行 prep / archive。Agent 在跑 archive 前**应该确认用户身份**（"你是本周 host 吗？"）。

---

## 5. Agent 行为契约

LLM agent 在执行任何写入或归档前 **必须**：

1. **确认身份**：从 `cloud_cli.py whoami` 或 JWT 拿到 `@handle`，并在用户面前显示一次（"以 @tajie 身份提交"）。
2. **追加不覆盖**：写入 `current/` 任何文件都用 `append_signed_entry`，永不 `write_text` 覆盖（除非用户明确要求并且是自己上一条的修订）。
3. **archive 必须先取 notes**: 归档前 agent **必须** 先 `/sr-status` 检查 `current/notes.md` 是否存在且 fresh；不在则默认调 `/sr-fetch-notes` 自动抓取（silent → headed → 给 URL 三层 fallback）。只有在三层都失败且 host 明确说 "archive without notes" 时才能跳过。同时提醒 host: `current/notes.md` 里的 `/sr-notes` 速记会一并归档。最后再显式确认 "归档 YYYY-MM-DD 并清空 current/?"。详见 [`framework/rules/archive.md`](framework/rules/archive.md)。
4. **越权请求拒绝**：
   - "帮我改一下 Alice 的 update" → 拒绝，建议联系 Alice 本人或在 SharePoint 网页编辑。
   - "把 history/2026-04-14 删掉" → 拒绝，让用户走 SharePoint 回收站流程。
   - "改一下 agenda 浮动主题" → 这是代码面改动，引导提 PR。
5. **失败即停**：Graph API 返回 403/401 时不要重试，直接报告给用户并提示重新登录（`cloud_cli.py whoami` 会触发交互登录）。

---

## 6. Maintainer 操作

```bash
# 改规则 / 脚本 / 默认配置
git checkout -b fix/<topic>
# 改 societas-shiproom/ 内的文件
git commit -m "..."; git push
# 自合并或走 PR

# 重打 skill zip 发布给新 IDE 用户
Compress-Archive -Path societas-shiproom -DestinationPath societas-shiproom-skill.zip
```

---

## 7. 不再适用的旧约定

迁移到 SharePoint 之前的版本曾经依赖 GitHub PR + CODEOWNERS 控制数据写入。这些已废弃:

- ❌ `.github/CODEOWNERS` —— 数据已搬云,无需 GitHub 层级权限。
- ❌ "data PR 走 GitHub" —— 数据从来不进 Git。
- ❌ `data/current-week/` 这种本地路径 —— 现在全部在 SharePoint `Shiproom/current/`。

如果在旧文档里见到上述路径,以本文件为准。`/sr-notes` 命令仍然有效,见 §4。
