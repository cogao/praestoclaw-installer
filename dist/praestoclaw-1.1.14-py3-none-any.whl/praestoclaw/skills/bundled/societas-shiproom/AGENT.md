---
title: Societas Shiproom Agent Integration Guide
audience: AI Agents (Copilot, Cloud Code, PM Studio, etc.)
version: 2.0
last_updated: 2026-05-11
backend: sharepoint
---

# Societas Shiproom — Agent Integration Guide

**This document is for Agents, not humans.** It defines:
- What to do when user types `/sr-*` commands
- How to call scripts and process outputs
- How to handle errors and edge cases
- Standard communication with users

## 0. Storage Backend

All meeting data lives in a **Teams channel SharePoint folder**, not the repo:

- **Team**: `Societas`
- **Channel**: `Shiproom`
- **Folder**: `Shiproom/` (under the channel's document library)
  - `current/` — active week (host uploads PDFs, anyone appends updates)
  - `history/<YYYY-MM-DD>/` — archived past meetings

IDs are configured in [`shiproom-config.yaml`](../shiproom-config.yaml) under `storage.sharepoint`.

Authentication is automatic via MSAL (uses Azure CLI client_id, broad Graph scopes consented tenant-wide). First run pops a one-time sign-in window per host; subsequent runs are silent. Identity for signing updates is parsed from the access token (`upn` claim).

**Agent never reads or writes local files under `societas-shiproom/data/`** — that path is gitignored and not used by the cloud backend. All file I/O goes through `framework/scripts/cloud_cli.py` or directly through `framework/scripts/cloud_io.ShiproomCloud`.

---

## 1. Command Registry

### 1.0 First contact — MANDATORY greeting (overrides host install messages)

**Trigger (fire ONCE per chat session, whichever comes first):**
- Skill just installed / reinstalled / updated / enabled / activated AND any user message follows (even bare "好" / "好的" / "ok" / "继续" / "试试" / "下一步").
- User mentions installing/enabling/updating/applying this skill ("安装一下这个 skill"、"更新到最新"、"装好了"、"重新安装").
- User types `/sr-help` / `/sr` / `/shiproom` / bare `shiproom`.
- ANY first substantive user turn after the skill becomes available, if not yet greeted in this session.

**Hard rules — the quoted block IS the WHOLE reply:**
- Nothing before. Nothing after. No "✅ 已安装" / "已重新安装为最新版本" / "skill is installed and applied" wrapper — those are HOST installer messages, replace them with the greeting.
- No "下一步建议：试试 /sr-prep 或 /sr-update" tail — the greeting already ends with a path-picker.
- No tool calls first. No workspace search first.
- After sent once, mark greeted; subsequent turns proceed normally.

> ✅ **Societas Shiproom 已就绪。**
>
> 这个 skill 让你直接在 IDE 里跑团队的每周 shiproom，所有数据都在 SharePoint 上（[Societas / Shiproom channel / Files / Shiproom/](https://microsoftapc.sharepoint.com/teams/Societas/Shared%20Documents/Shiproom)），不用本地存数据。
>
> **你能做什么：**
> - 🟢 **会前** —— 任何成员用 `/sr-update` 提交自己负责的章节；host 用 `/sr-prep` 把 Loop、数据快照、OCV 快照和会前总结一起准备到 `current/`。
> - 🟡 **会中** —— 用 `/sr-notes` 实时记录决策，自动签上你的名字。
> - 🔵 **会后** —— host 用 `/sr-archive` 先从 Teams meeting/chat 抓最新 notes，再把 `current/` 归档到 `history/<日期>/` 并清空，准备下一周。
> - 🔎 **任何时候** —— 用 `/sr-ask` 提问，我会从 `current/` 和 `history/*/` 里翻答案。
>
> 想从哪一步开始？告诉我 `update` / `prep` / `notes` / `archive` / `ask` 中的任意一个，或者直接描述你要做的事。

### 1.1 Routing table

All user commands starting with `/sr-` or their aliases must be routed to corresponding actions. **Default backend is SharePoint** — every command below maps to a `cloud_cli.py` subcommand.

| Command | Aliases | Handler | Mode |
|---|---|---|---|
| `/sr-status` | `/status` | `cloud_cli.py status` | Read |
| `/sr-whoami` | — | `cloud_cli.py whoami` | Read |
| `/sr-prep` | — | `cloud_cli.py prep` then agent orchestrates checklist + uploads | Interactive |
| `/sr-update <section> <content>` | `/update` | AI classifies → `cloud_cli.py update <section> <text>` | Interactive |
| `/sr-notes <content>` | `/notes` | `cloud_cli.py notes <text>` | Write |
| `/sr-upload-loop <pdf>` | — | `cloud_cli.py upload-loop <path>` | Upload |
| `/sr-upload-notes <pdf>` | — | `cloud_cli.py upload-notes <path>` (fallback when `/sr-fetch-notes` fails) | Upload |
| `/sr-upload-md <local> <remote>` | — | `cloud_cli.py upload-md <local> <remote>` | Upload |
| `/sr-fetch-loop` | — | `cloud_cli.py fetch-loop` (headless Chrome -> `current/currentloop.md`, then auto-splits sections into 1-todo / 4-release / 5-mythos / 6-deep-worker / 7-others between LOOP-SYNC markers, preserving human entries) | Refresh |
| `/sr-fetch-notes` | — | `cloud_cli.py fetch-notes` (scans Teams chat for the latest Facilitator summary, fetches the embedded Notes Loop -> `current/notes.md`; silent by default, opens visible browser only on first-time access to a new organizer's OneDrive) | Refresh |
| `/sr-split-loop` | — | `cloud_cli.py split-loop` (re-run the splitter on existing `current/currentloop.md`) | Refresh |
| `/sr-fetch-ocv` | — | `cloud_cli.py fetch-ocv` (reads `ocv_source.remote_path` workbook via Graph -> uploads `3-ocv.md`) | Refresh |
| `/sr-archive [<YYYY-MM-DD>]` | — | `cloud_cli.py archive [<date>]` | Execute |
| `/sr-url [<path>]` | — | `cloud_cli.py url [<path>]` | Read |
| `/sr-ask <question>` | `/ask` | `cloud_cli.py list-history` + `cloud_cli.py read <path>` → answer | Search |
| `/sr-download <remote> <local>` | — | `cloud_cli.py download <remote> <local>` | Download |

**Legacy local commands** (only when `storage.backend: local` in config — not the default):
None ship with this skill. The cloud backend is the only supported path. If a host needs an offline workflow they must bring their own data scripts and write into `current/` via `cloud_cli upload-md`.

---

## 2. Execution Model

All commands invoke `framework/scripts/cloud_cli.py <subcommand> [args]` from the workspace root.

**Common pattern:**
```bash
python societas-shiproom/framework/scripts/cloud_cli.py <subcommand> [args] \
  --config shiproom-config.yaml
```

**Identity:** signed in via MSAL. Each entry written by `update` / `notes` is auto-signed with the current user's UPN handle (everything before `@`) and an ISO timestamp. The agent does not need to ask the user for their name.

**Idempotency:** appended entries are timestamped per write — re-running the same `/sr-update` produces a second timestamped entry. Agent should warn the user if the same text was just submitted (compare against last 3 entries in the file).

### 2.1 `/sr-status` — inspect current week

```bash
python framework/scripts/cloud_cli.py status
```

Lists all files in `current/` and `current/updates/` with sizes. Use this to:
- show the user what's already in this week's folder
- decide whether `/sr-upload-loop` is still needed (look for `currentloop.pdf`)
- decide whether `/sr-archive` is safe to run

### 2.2 `/sr-update <section> <text>` — append a signed entry

**See [`framework/rules/update.md`](framework/rules/update.md) for the full playbook** (decision tree, section classifier, two-layer follow-up logic, confirmation contract, idempotency rules). That file is the source of truth; this section just summarises.

Quick reference:

- **Case A.1** — content + explicit section → trust user, skip section confirm, run Q ladder, write, confirm.
- **Case A.2** — content + no section → classify by keyword, confirm section with user, then Q ladder, write, confirm.
- **Case B** — no content yet ("我想 update" / "/sr-update" / 类似空开场) → give the user as much **context** as possible before asking which section. Best-effort, not strict:
  1. Try to fetch and surface whichever of these are available (skip silently if missing):
     - `current/view.html` URL (this week's dashboard — most useful if `/sr-prep` already ran)
     - `current/currentloop.md` URL (this week's raw loop)
   - latest `history/<date>/view.html` URL (last archived dashboard — especially after `/sr-archive` cleared `current/`)
   - latest `history/<date>/updates/0-meeting-prep-summary.md` URL
   - latest `history/<date>/currentloop.md` or `.pdf` URL (last archived Loop, found via `cloud_cli.py list-history`)
  2. List whatever you found, then offer the section menu. Example:
     > 本周的 dashboard：&lt;view.html url&gt;
     > 上周（2026-05-04）的 Loop：&lt;url&gt;
     >
     > 想 update 哪个 section？(1-todo / 2-data / 3-ocv / 4-release / 5-mythos / 6-deep-worker / 7-others)
     > 或者直接把内容发我，我帮你归类。
   3. 什么上下文都拿不到 → 直接上 section 菜单，不要卡住。
   4. Archive-cleared `current/` must NOT weaken follow-up behavior: once user provides content, still run the full Q ladder below. History context is for recall only; it does not replace owner/ETA/branch/status/decision-readiness questions.

Q ladder has **two layers**, max one round-trip each:

1. **Decision-readiness** — agent asks as a shiproom attendee: "what do you want from the room?" (skip if text is resolved/past-tense, already framed as an ask, `#fyi`-tagged, or section is `2-data` / `3-ocv`).
2. **Field completeness** — Owner / ETA / Branch / Status, max 2 Qs (skip if Layer 1 ended in `#fyi`, fields already present, or section is `2-data` / `3-ocv`).

Mandatory confirmation after every successful write (路径本身就是 SharePoint 超链接，不要再单独起一行 🔗 link)：
```
✅ 已写入 [current/updates/<section>.md](<SharePoint URL>)（signed @<user>）
内容：<final text>
```

Human entries always live OUTSIDE the `<!-- BEGIN LOOP-SYNC --> ... <!-- END LOOP-SYNC -->` block in each file, so they survive every `fetch-loop` / `upload-loop` / `fetch-ocv` / `upload-md` re-run.

### 2.3 `/sr-notes <text>` — append meeting notes

```bash
python framework/scripts/cloud_cli.py notes "<text>"
```

Writes a signed line to `current/notes.md`. Use during the meeting for live transcript / decisions.

### 2.4 `/sr-upload-loop <pdf>` — host uploads Current Loop PDF

The host exports `Shiproom Current.loop` to PDF (Print to PDF in browser), then:
```bash
python framework/scripts/cloud_cli.py upload-loop ./Shiproom-Current.pdf
```
Uploaded as `current/currentloop.pdf` (overwrites previous).

Use this only when `/sr-fetch-loop` (§2.4a) fails or the host wants the high-fidelity PDF.

### 2.4a `/sr-fetch-loop` — auto-fetch Current Loop as markdown

```bash
python framework/scripts/cloud_cli.py fetch-loop
```

Launches headless Chrome (or Edge / bundled chromium as fallback), opens the
Loop URL from `loop_source.url` (or `references.loop_current`), clicks the
`...` → `打印和 PDF 导出` menu item, captures the popup's full innerText, and
uploads it as `current/currentloop.md` (markdown-ish text).

**Default in `/sr-prep`**: this is tried FIRST.

**Three-tier fallback** (built into `fetch-loop`):

1. **Silent headless** (default) — host sees no window. Works whenever the
   persistent Playwright profile already has a SharePoint cookie for this URL.
2. **Headed (visible) browser** — if the silent attempt raises `LoopFetchError`
   (typically: profile is fresh, or this URL points at a OneDrive site the
   profile has never accessed), the script reopens the same URL in a visible
   Chrome window so the host can sign in / approve any "request access" prompt
   once, then presses ENTER in the terminal to trigger the capture. Subsequent
   runs are silent again.
3. **Manual PDF** — if even the headed flow fails, the script prints the Loop
   URL and asks the host to export to PDF and run `/sr-upload-loop`.

**Auto-split into team update files** (after a successful fetch): the script
reads `loop_sync.targets` from config and slices the loop content by the
listed section headings. Each slice is injected into the matching
`current/updates/<file>.md` between markers:

```
<!-- BEGIN LOOP-SYNC -->
... auto-extracted from currentloop.md ...
<!-- END LOOP-SYNC -->
```

Anything OUTSIDE those markers (i.e. all `/sr-update` signed entries) is
preserved verbatim. On every re-run the block is replaced in place; the
human section grows untouched. Default targets:

| Loop heading(s) | Synced into |
|---|---|
| `Action Items` | `current/updates/1-todo.md` |
| `Pending release`, `Lab Release plan`, `Consumer Release ...` | `current/updates/4-release.md` |
| `Mythos Security Bugs` | `current/updates/5-mythos.md` |
| `Digital Worker & Quality`, `Deep Worker` | `current/updates/6-deep-worker.md` |

To re-run the splitter without re-fetching (e.g. after editing the keyword
list): `python framework/scripts/cloud_cli.py split-loop`.

**On fetch failure**, the script exits non-zero and prints the Loop URL.
The agent MUST relay that URL verbatim to the host so they can click it
directly:

> Auto-fetch failed (<reason from stderr>). Please open the Loop page below,
> use "Print & PDF export" in the `...` menu to save it as PDF, then drop
> the PDF into this chat (or run `/sr-upload-loop <path>`):
>
> <loop_url>

The host can then attach the PDF directly in the conversation; the agent
saves it locally and runs `cloud_cli.py upload-loop <saved-path>`.

> ⚠️ When the host falls back to PDF upload, **`/sr-upload-loop` ALSO runs
> the auto-split** (via `pdfminer.six`). The PDF heading prefixes like
> `3.1 Lab Release plan` are tolerated by the matcher.

### 2.5 `/sr-upload-notes <pdf>` — host uploads Notes Loop PDF after meeting

Same as above but writes `current/notes.pdf`. Use this only when `/sr-fetch-notes` (§2.5a) fails or the host wants the high-fidelity PDF in addition to the auto-extracted markdown.

### 2.5a `/sr-fetch-notes` — auto-fetch latest meeting Notes Loop

```bash
python framework/scripts/cloud_cli.py fetch-notes
```

Scans the configured Teams group chat (`notes_source.teams_chat_topic`) for the
Facilitator bot's most recent post-meeting summary message ("各位，会议结束了" /
"that's a wrap"), extracts the embedded Loop URL, and runs the same
print-popup capture flow as `/sr-fetch-loop` to upload the rendered text as
`current/notes.md`.

**Default behavior (silent)**: headless Chrome — host sees no window. Works
on every subsequent run after the persistent Playwright profile has accessed
that organizer's OneDrive once.

**First-time access fallback**: if the silent fetch fails (typically because
the Loop file lives in a coworker's OneDrive that this machine has never
opened), the script reopens the same URL in a **visible** Chrome window so
the host can sign in / approve "request access" once, then presses ENTER to
trigger the capture. Subsequent runs are silent again.

**Final fallback**: if even the headed flow fails, the script prints the
Loop URL and asks the host to export to PDF and run `/sr-upload-notes`.

**Default in `/sr-archive`**: this is tried FIRST. Only if it fails does the
agent fall back to asking the host for a PDF.

### 2.6 `/sr-archive [<YYYY-MM-DD>]` — close out the week

```bash
python framework/scripts/cloud_cli.py archive          # uses today
python framework/scripts/cloud_cli.py archive 2026-05-15
```

Copies all of `current/` to `history/<date>/`, then clears `current/` (folder remains, contents removed). Refuses if `history/<date>/` already exists.

**See [`framework/rules/archive.md`](framework/rules/archive.md) for the full playbook** (status check → fetch-notes with three-tier fallback → date confirmation → explicit yes/no → archive; plus idempotency / failure rules). That file is the source of truth; this section just summarises.

Quick reference:

1. Run `/sr-status`. If `current/` is empty, do NOT archive — surface the state.
2. Pick the target date. Default = today, but if the latest meeting-notes timestamp in Teams is earlier, ask the host explicitly which to use.
3. Ensure `current/notes.md` is fresh — run `/sr-fetch-notes` if missing or stale; relay any PDF-fallback URL verbatim.
4. Show `notes.md` size + `/sr-notes` count. Ask whether to add a final summary.
5. Explicit yes/no confirm. Wait for `yes`. Then run `cloud_cli.py archive [<date>]`.
6. Confirm with the standard ✅ block (see archive.md §五).

### 2.7 `/sr-ask <question>` — answer from current + history

List history dates via `cloud_cli.py list-history` (or `status` for current). Pull `notes.md` and the relevant `updates/*.md` from matching dates. Agent picks 1-3 relevant dates by question keywords, reads them, synthesizes the answer, and cites the SharePoint URL via `cloud_cli.py url <path>`.

```bash
# Show available archives
python framework/scripts/cloud_cli.py list-history

# Pull a specific past meeting
python framework/scripts/cloud_cli.py read history/2026-04-29/notes.md
python framework/scripts/cloud_cli.py read history/2026-04-29/updates/1-todo.md

# Or pull current week
python framework/scripts/cloud_cli.py read current/updates/4-release.md
```

See [framework/rules/ask.md](framework/rules/ask.md) for the full ranking / scoring playbook.

### 2.8 `/sr-prep` — host pre-meeting orchestration

This is **agent-orchestrated**, not a single script. `cloud_cli.py prep` prints a categorized checklist (`refresh` / `accumulate` / `generate`); the agent uses it as a worklist.

#### Categories — what the agent must understand

| Kind | Examples | Lifetime | Action |
|---|---|---|---|
| `refresh` | `currentloop.{md,pdf}`, `2-data.md`, `3-ocv.md` | **One meeting cycle.** Usually stale when `mtime < cutoff` or `>48h`; `2-data.md` is special-cased to inspect declared data period (plus near-archive grace) to avoid false stale. | **Always re-fetch from the live source at the start of every `/sr-prep`**, even if the file already exists in `current/`. The checklist will mark stale files `[STALE]`. |
| `accumulate` | `1-todo.md`, `4-release.md`, `5-mythos.md`, `6-deep-worker.md`, `7-others.md` | Whole week. Built up by team `/sr-update` calls + LOOP-SYNC blocks from `fetch-loop`. Cleared by `/sr-archive`. | Confirm presence; if `cloud_cli.py prep` marks one `[LEFT]` (mtime before this ISO week's Monday), it's leftover from a meeting that was never archived — see §2.8 step 1.5. |
| `generate` | `0-meeting-prep-summary.md` | One meeting cycle. | Agent writes this **last**, after refresh + read of all the above. Always regenerate from scratch — never reuse last week's summary. |

> ⚠️ **Common bug to avoid**: a `refresh` file existing in `current/` does NOT mean it is current. If `cloud_cli.py prep` prints `[OK]` because today is Monday morning but the file's mtime is from last Tuesday, that's a script bug — file an issue. If `[STALE]`, you MUST re-fetch.

#### Orchestration steps

0. **Announce the plan to the host** (one short message before any tool call) so they know what's about to happen and roughly how long it takes:
   > 收到。我现在开始准备会议，会按下面步骤走：
   >
   > 1. 跑 checklist，看哪些文件需要刷新。
   > 2. 抓最新 Loop，并切分到各个 section。
   > 3. 检查 Data 快照是否已上传/是否新鲜。
   > 4. 重抓 OCV 快照。
   > 5. 读取本周所有 sections 的内容。
   > 6. 生成 prep summary 和 view.html。
   > 7. 给出 SharePoint 链接并确认完成。
   > 大概需要 1–2 分钟，如果哪一步需要你输入（例如 Loop 抓失败要你传 PDF）我会停下来问你。

   Each subsequent step should print its own one-liner status (`✅ Step 2: Loop 抓取成功，9033 chars` / `⚠️ Step 3: 2-data.md 是上周的，已提醒 Claire`) so the host sees progress in chat, not just in a terminal scroll-back.

1. **Run the checklist**:
   ```bash
   python framework/scripts/cloud_cli.py prep
   ```
   Read its `Next steps` section. Items marked `REFRESH` or `FETCH` of kind `refresh` MUST be done first; do not skip just because the file exists.

   **If you see `[LEFT]` rows** (kind `accumulate`, mtime before this ISO week's Monday): last meeting was never archived. STOP the prep flow and ask the host:
   > I see `1-todo.md` etc. are still from last cycle (e.g. 2026-05-04). Looks like last meeting wasn't archived. Should I archive `<last meeting date>` first, then start this week's prep clean? (yes / no / let me check)

   - **yes** → run `cloud_cli.py archive <last date>`, then re-run `prep`.
   - **no, those entries are still relevant** → ask the host to re-touch each file (e.g. `/sr-update 1-todo "carry forward: <summary>"`) so it's stamped this week.

   Do not silently proceed and reuse last week's content as if it were this week's.

2. **Loop content** (`refresh`): try auto-fetch FIRST, even if a previous file exists.

   ```bash
   python framework/scripts/cloud_cli.py fetch-loop
   ```
   On success: writes `current/currentloop.md` (full Loop innerText) AND
   auto-splits sections into `current/updates/{1-todo,4-release,5-mythos,6-deep-worker,7-others}.md`
   between `<!-- BEGIN LOOP-SYNC --> ... <!-- END LOOP-SYNC -->` markers.
   Human `/sr-update` entries (outside the markers) are preserved on every
   re-run. Done.

   On failure (exit 3 or 1): `fetch-loop` will have printed the Loop URL on
   stderr. The agent MUST surface that URL to the host like this:

   > Auto-fetch failed: <reason>. Please open the Loop page below, use the `...`
   > menu → `Print & PDF export` → Save as PDF, then drop the PDF into this
   > chat (I'll upload it):
   >
   > <loop_url>

   When the host attaches the PDF in chat, save it locally and run
   `cloud_cli.py upload-loop <saved-path>` — do NOT make the host run the CLI.
   `upload-loop` will extract the PDF text and run the same section splitter,
   so 1-todo / 4-release / 5-mythos / 6-deep-worker / 7-others get refreshed too.

3. **Data snapshot** (`refresh`): the data file `current/updates/2-data.md` is **uploaded by Claire** every week before the meeting (she runs the usage-analysis report and saves the markdown directly to SharePoint).
   - The auto-source content lives between `<!-- BEGIN LOOP-SYNC --> ... <!-- END LOOP-SYNC -->` markers; **human `/sr-update 2-data` entries below the block are preserved** on every re-upload (e.g. someone flags a data anomaly: `/sr-update 2-data "WAU 5/10 looks 30% off vs last week, double-check"`).
   - If `prep` shows `[STALE]` for `2-data.md`: ping Claire to re-run the report. The agent can also do `python framework/scripts/cloud_cli.py upload-md <local> current/updates/2-data.md` -- this auto-merges the new snapshot into the LOOP-SYNC block without touching human entries.
   - `prep` now checks `2-data.md` period text before using pure mtime; same-cycle uploads that happened before `/sr-archive` should remain `[OK]`.

4. **OCV snapshot** (`refresh`): **always re-fetch.** Run:
   ```bash
   python framework/scripts/cloud_cli.py fetch-ocv
   ```
   Reads the workbook at `ocv_source.remote_path` (under `Shiproom/`) via Graph, picks the latest sheet (config: `ocv_source.sheet_pick`), and merges a markdown summary into `current/updates/3-ocv.md`'s LOOP-SYNC block. **Human `/sr-update 3-ocv` entries below the block are preserved** (e.g. `/sr-update 3-ocv "TopComplaint #1234 reproduces locally on Edge canary -- assigned WD"`).

   - If `ocv_source.remote_path` is empty or the file is missing, exit 2: ask host to fix the config or upload the workbook into `Shiproom/`.

5. **Read all `accumulate` sections** for context:
   ```bash
   python framework/scripts/cloud_cli.py read current/updates/1-todo.md
   python framework/scripts/cloud_cli.py read current/updates/4-release.md
   python framework/scripts/cloud_cli.py read current/updates/5-mythos.md
   python framework/scripts/cloud_cli.py read current/updates/6-deep-worker.md
   python framework/scripts/cloud_cli.py read current/updates/7-others.md
   ```
   Plus the freshly refreshed `2-data.md` and `3-ocv.md`.

6. **Generate prep summary AND view.html** (default — do NOT ask):
   - Synthesize key data movements, OCV themes, action items at risk, suggested discussion order. Write to a temp file and upload:
     ```bash
     python framework/scripts/cloud_cli.py upload-md /tmp/prep-summary.md current/updates/0-meeting-prep-summary.md
     ```
     Always regenerate; never copy last week's summary forward.
   - The prep summary **must** follow [`framework/rules/prep.md`](framework/rules/prep.md) §6.1.1 + §6.1.1.a + §6.1.1.b:
      - include the exact heading schema for Top Risks + ①–⑦ sections
      - include a valid `<!-- SR_VIEW_JSON:START --> ... <!-- SR_VIEW_JSON:END -->` block on every `/sr-prep` run
      - keep `SR_VIEW_JSON.top_risks` and `SR_VIEW_JSON.sections.*` aligned with the human-readable bullets below
      - default summary language is Simplified Chinese, while product names / model names / bug IDs / owners may remain in English
      - if the JSON block is missing, treat prep summary generation as incomplete rather than "good enough"
   - Render the HTML dashboard with the hard-coded renderer. Do NOT hand-write or redesign HTML in the agent response:
    ```bash
    python framework/scripts/cloud_cli.py render-view --local ./view.html
    ```
    **Must follow [`framework/rules/prep.md`](framework/rules/prep.md) §6.2**:
       - UI = old blue section style + sticky nav. Use the HTML/CSS skeleton in `prep.md` §6.2. Do NOT generate compact card dashboards, gray-background card stacks, emoji headers, or one-screen executive-summary pages. Layout = title/meta → **Top Risk** (3–5 business callouts) → 7 sections in fixed order: ① To Do (`1-todo`) → ② Data (`2-data`) → ③ OCV (`3-ocv`) → ④ Release (`4-release`) → ⑤ Deep Worker (`6-deep-worker`) → ⑥ Mythos Security Bugs (`5-mythos`) → ⑦ Others (`7-others`). Deep Worker BEFORE Mythos. Others is mandatory.
       - Every section starts with a business summary, never with generation/rule text such as "保留一段总结" / "这里不展示" / "本节用于".
       - To Do: show current Action Items table + manual updates. Data: Executive Overview four metric groups + Key Takeaways only; no Selected Report Tables / slide dump. OCV: one summary + one problem table. Release: Consumer Release Status + Lab Release Plan (Rick Yang). Deep Worker: summary + key details, about one page. Mythos Security Bugs: dashboard summary (total / critical counts, per-owner breakdown, SLA risk). Others lists remaining uncovered topics.
       - Keep concrete numbers, owners, ETAs, bug IDs, @handles; AI may summarize/merge wording but must not change facts. Strip `<!-- BEGIN/END LOOP-SYNC -->` comments.
   - Final message to host (SharePoint link is the primary deliverable; local path is just a side note):
     > ✅ [view.html](<SharePoint URL>) 已生成。
     > （也下载了一份到本地 `./view.html`，在 IDE 里双击能预览。）

**Failure handling**: every step is independent. Surface errors plainly and ask the host to supply data manually.

---

## 3. Error Handling

### 3.1 Auth failures

First-time run on a host pops a sign-in window. If the user reports it failed:
- ensure the host is signed into Windows with their `@microsoft.com` work account
- ensure they have access to the `Societas` Teams team
- delete `%LOCALAPPDATA%\.IdentityService\msal.cache.bin3` and retry

### 3.2 SharePoint 403 / 404

- 403: user is not a member of the Societas team. Ask them to request membership.
- 404 on `current/<file>`: file hasn't been uploaded this week. Suggest `/sr-upload-loop` or `/sr-update`.
- 404 on `history/<date>/`: that meeting wasn't archived (or wrong date). Run `cloud_cli.py status` to see available dates.

### 3.3 Archive conflict

If `cloud_cli.py archive <date>` errors with "history/<date>/ already exists":
- ask user to confirm they want to overwrite, then either pick a different date suffix or manually delete the old folder via SharePoint web first
- agent should NOT auto-delete history folders

## 4. File I/O Contracts

### 4.1 Cloud Layout

All data lives under the Societas team's `Shiproom/` SharePoint folder. The Python helper `cloud_io.ShiproomCloud` exposes path-style access using parts:

```
Shiproom/                                  ← cloud.base_path
├── current/                              ← cloud.current_dir
│   ├── currentloop.md                     /sr-fetch-loop 自动抓取
│   ├── currentloop.pdf                    /sr-upload-loop 兑底上传
│   ├── notes.md                           /sr-fetch-notes + /sr-notes 追加
│   ├── notes.pdf                          /sr-upload-notes 兑底上传
│   └── updates/
│       ├── 0-meeting-prep-summary.md      agent in /sr-prep
│       ├── 1-todo.md                      /sr-update 1-todo + LOOP-SYNC from fetch-loop
│       ├── 2-data.md                      /sr-update 2-data + LOOP-SYNC from Claire's upload
│       ├── 3-ocv.md                       /sr-update 3-ocv + LOOP-SYNC from /sr-fetch-ocv
│       ├── 4-release.md                   /sr-update 4-release + LOOP-SYNC from fetch-loop
│       ├── 5-mythos.md                    /sr-update 5-mythos + LOOP-SYNC from fetch-loop
│       ├── 6-deep-worker.md               /sr-update 6-deep-worker + LOOP-SYNC from fetch-loop
│       └── 7-others.md                    /sr-update 7-others + LOOP-SYNC from fetch-loop
└── history/
    └── <YYYY-MM-DD>/                     created by /sr-archive
        ├── currentloop.pdf
        ├── notes.md
        ├── notes.pdf
        └── updates/...
```

**Repo layout (no data, only code):**

```
workspace_root/
├── shiproom-config.yaml                  ← backend + sharepoint IDs
└── societas-shiproom/
    ├── SKILL.md, README.md, AGENT.md
    └── framework/
        ├── config/themes.yaml
        ├── rules/*.md                    ← strategy notes (ask / update / analysis)
        └── scripts/
            ├── cloud_io.py               ← SharePoint client + MSAL identity
            ├── cloud_cli.py              ← agent-facing CLI (all /sr-* commands)
            └── requirements.txt
```

Cloud-first: agent never touches local files outside the workspace tmp dir. All I/O goes through `cloud_cli.py`.

### 4.2 Append protocol

When the agent appends to `current/updates/<n>-<theme>.md` via `/sr-update`, the underlying `cloud_io.append_signed_entry()` writes:

```markdown
### @<user-handle> · <ISO timestamp>

<body>
```

The file is created with header `# <section>` if it doesn't exist. Existing content is preserved — entries are appended to the end.

Agent should NOT pre-format the body with the verbose 10-field template (Entry ID, Owner, Due, etc.) anymore. Keep it short and natural.

### 4.3 Config file usage

`cloud_cli.py` resolves `shiproom-config.yaml` in this order (first hit wins):

1. `--config <path>` on the command line.
2. `<workspace-root>/shiproom-config.yaml` \u2014 team override, sits next to the `societas-shiproom/` skill folder.
3. `<skill-root>/shiproom-config.yaml` \u2014 bundled default that ships in the zip.

For Societas users the bundled default is correct, so unzipping the skill anywhere works out of the box. Teams that want different agenda names / SharePoint folders can drop a `shiproom-config.yaml` at the workspace root to override.

**Agent MUST:**
1. Trust the resolved config; do not re-implement the lookup.
2. Parse YAML to extract:
   - `storage.sharepoint.*` (passed to `ShiproomCloud.from_config(cfg)`)
   - `agenda.fixed[*].name` and `agenda.floating_slots[*].name` \u2014 for `/sr-update` section classification
3. Re-read on every command (config may change).

**Agent must NOT:**
- Modify `shiproom-config.yaml` programmatically (humans edit this).
- Cache config between commands.

---

## 5. Interaction Patterns

### 5.1 Happy path \u2014 update

```
User: /sr-update We deployed v2.1 to lab on Friday
Agent:
  Routed to: 4-release
  Q: Any blockers? Owner for follow-up?
User: All green, owner @alice.
Agent runs: cloud_cli.py update 4-release "Deployed v2.1 to lab on Friday. All green. Owner @alice."
Agent replies:
  \u2705 Added to current/updates/4-release.md
  \ud83d\udd17 https://microsoftapc.sharepoint.com/.../4-release.md
```

### 5.2 Host pre-meeting

```
User: /sr-upload-loop ./Shiproom-Current.pdf
Agent runs: cloud_cli.py upload-loop ./Shiproom-Current.pdf
Agent replies:
  \u2705 Uploaded as current/currentloop.pdf
  \ud83d\udd17 <url>
  \u23ed\ufe0f  Suggest the team to start posting /sr-update entries before the meeting.
```

### 5.3 Host post-meeting archive

```
User: /sr-archive
Agent: Let me check current/ first → runs cloud_cli.py status
Agent: I don't see current/notes.md yet — fetching the latest meeting notes
       Loop from the Stride Shiproom Teams chat ...
Agent runs: cloud_cli.py fetch-notes
          🔍 Scanning Teams chat 'Stride Shiproom' for the latest meeting notes ...
             found 1 candidate(s); latest = 2026-05-08T03:17:33Z
          📥 Fetching Loop content (headless) ...
          ✅ Fetched meeting notes -> current/notes.md (5134 chars)
Agent: I also see current/notes.md has 7 inline /sr-notes entries — they'll be
       archived too. Any final summary to add? (reply skip to continue)
User: skip
Agent: Archive current → history/2026-05-15/, then clear current/. Continue?
User: yes
Agent runs: cloud_cli.py archive 2026-05-15
  ✅ 已归档到 [history/2026-05-15/](<SharePoint URL>)
```

---

## 6. Behavioral Rules

### 6.1 Idempotency

- `/sr-update` writes a fresh timestamped entry every time. If the user submits the same text within ~1 minute, agent should warn and ask for confirmation before re-sending.
- `/sr-archive` refuses if `history/<date>/` already exists (script-enforced).

### 6.2 Timestamps & Identity

- All entries are signed by `cloud_io` with `@<upn-handle> · <ISO timestamp>` automatically. Agent does not prepend its own.
- Archive folder uses the **local date** the operator passes in (or today's date if omitted).

### 6.3 Confirmation pattern

**原则**：所有反馈里的“产出”（文件路径、view.html、归档目录等）本身就是 SharePoint 超链接，不要另起一行 "🔗 url" 或 "on SharePoint"。也不要主推本地路径 —— SharePoint 链接是主体。

```
✅ 已<action> [<产出路径或名称>](<SharePoint URL>)
⏭️  <suggested next step>
```

SharePoint URL 统一从 `cloud_cli.py` stdout 拿（所有 write 类 subcommand 都返回 webUrl），拿不到就 fallback 到 `cloud_cli.py url <path>`。

Before destructive actions (`/sr-archive`):
```
⚠️ About to archive current → history/2026-05-15/, then clear current/.
This is reversible only by manual SharePoint operations.
Continue? (y/n)
```

### 6.4 Permissions & Safety

> Full permission model lives in [`PERMISSIONS.md`](PERMISSIONS.md) (bundled in this skill).
> The agent MUST consult it whenever a write, delete, or archive operation is requested.

- Agent may READ/WRITE everything under `Shiproom/current/` and READ `Shiproom/history/`.
- Agent must NOT delete or overwrite `history/<date>/` folders.
- Agent must NOT modify `framework/` files (rules, scripts).
- Agent must REFUSE cross-user edits ("delete what Alice wrote") and direct the user to SharePoint web UI.
- Before `/sr-archive`, agent MUST ensure `current/notes.md` is fresh — default to running `/sr-fetch-notes` (silent), only ask the host for a PDF if both the silent and headed-fallback flows fail.
- Credentials are never stored in files — MSAL handles them via the OS keychain / WAM broker.

### 6.5 Saving cloud files locally (Windows pitfall)

**Never** use shell redirection to save `cloud_cli read` output to a file:

```powershell
# WRONG — PowerShell `>` re-encodes the stream to UTF-16 LE,
# which silently corrupts the file. A subsequent `upload-md` will
# push the corrupted bytes back to SharePoint.
python framework/scripts/cloud_cli.py read current/updates/2-data.md > snap.md
```

Always use the dedicated subcommand, which writes raw bytes:

```bash
python framework/scripts/cloud_cli.py download current/updates/2-data.md ./snap.md
```

If you need the content in-memory in Python, call `ShiproomCloud.read_text(...)` directly \u2014 it auto-detects UTF-16 / BOM / CRLF and returns clean LF-normalized utf-8.

---

## 7. Configuration & Environment

### 7.1 Required setup per host

1. Copy the `societas-shiproom/` folder into the host's skills directory (no `git clone` needed — this is a self-contained skill bundle, not a repo).
2. First time running any `cloud_cli.py` command pops a Microsoft sign-in window. Sign in with your `@microsoft.com` work account.
3. Confirm membership in the `Societas` Teams team (otherwise SharePoint returns 403).

No environment variables are required for the cloud backend.

### 7.2 Optional environment variables

- `MICROSOFT_TENANT_ID` \u2014 override default `microsoft.com` tenant.

---

## 8. Version

- **AGENT.md version**: 2.2 (2026-05-12) — cloud-first; auto fetch-loop + fetch-notes; six-step prep with merged summary+view.html; archive playbook extracted.

---

**End of Agent Integration Guide**
