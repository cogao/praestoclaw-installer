---
name: societas-bug-fix
description: Unattended 24/7 workflow for fixing Azure DevOps bugs — auto-fetch bug queue, prioritize, delegate fix to Claude Code, test, create PR, update work item. Designed for cron/scheduler invocation.
metadata:
  activation:
    keywords: [fix bug, fix ado bug, ado bug fix, fix work item, bug fix ado]
    patterns:
      - "(?i)\\bfix\\s+(ado|azure\\s+devops)\\s+bug\\b"
      - "(?i)\\b(ado|azure\\s+devops)\\s+bug\\s+fix\\b"
      - "(?i)\\bfix\\s+work\\s*item\\s+#?\\d+"
      - "(?i)\\bfix\\s+bug\\s+#?\\d+"
    context:
      git-remote: ["dev\\.azure\\.com", "visualstudio\\.com"]
  requires:
    bins: [az]
    tools: [claude_code]
---
## ADO Bug Fix Workflow

Designed for **unattended 24/7 operation** via cron/scheduler. Each invocation picks the highest-priority actionable bug, fixes it, and creates a PR — no human interaction required.

**Delegates to other skills** — this skill is the orchestrator:
- ADO CLI commands → follow patterns from the `ado` skill (auth, `-o json`, REST API fallbacks)
- Commit + push → handled by PraestoClaw using the `commit-code` skill (NOT by Claude Code)
- Code fix + test → delegated to Claude Code (code changes only, no commit/push)

Flow: pre-flight → load config → concurrency check → fetch bug queue → select bug → branch → delegate fix to Claude Code (code + test only) → verify → commit + push (via commit-code) → PR → update work item → clean up → report.

### Step 0 — Load project settings

Use `config_praestoclaw(action="show")` and read `agents.default.metadata`:

| Key | Description |
|-----|-------------|
| `ado_bug_query` | WIQL query or ADO saved-query URL for fetching assigned bugs |
| `ado_repo_local_path` | Absolute path to the local git clone |
| `ado_pr_target_branch` | Branch PRs should target (e.g. `main`, `develop`) |

If **any** are missing → **abort**. Send notification:
> [societas-bug-fix] BLOCKED: project settings incomplete. Run manually once to configure: `config_praestoclaw(action="patch", values={...})`

(First-time setup requires a manual interactive run to provide these values.)

### Step 1 — Pre-flight checks

Run all three checks **in parallel** (they are independent):
```
shell: git config user.name
shell: git config user.email
shell: az account show -o json
shell: cd {ado_repo_local_path} && git status --porcelain
```

Abort conditions (check all results together):
- git identity empty → abort. Notify: `[societas-bug-fix] BLOCKED: git identity not configured. Run git config --global user.name/email to fix.`
- az CLI fails → abort. Notify: `[societas-bug-fix] BLOCKED: az CLI not authenticated. Run az login.`
- working tree not clean → abort. Notify: `[societas-bug-fix] BLOCKED: working tree is dirty at {ado_repo_local_path}. Stash or commit pending changes.`

Derive `{alias}` using the same rule as the `commit-code` skill (first word of `user.name`, lowercase). Used for branch names: `users/{alias}/bug-{WORK_ITEM_ID}`.

### Step 2 — Concurrency check (single-task lock)

Call `claude_code_status()`. If any task with status `RUNNING` or `PENDING` exists → **skip this run silently** (the scheduler will retry next cycle). No notification needed.

### Step 3 — Fetch and prioritize bug queue

**If the user provided a specific work item ID**, fetch it directly using `az boards work-item show` (see `ado` skill for command patterns).

**Otherwise (autonomous mode)**, query the full bug backlog sorted by priority using `az boards query --wiql` (see `ado` skill for WIQL patterns). The query should:
- Filter: `AssignedTo = @Me`, `WorkItemType = 'Bug'`, `State <> 'Closed'`, `State <> 'Resolved'`
- Select: Id, Title, State, Description, ReproSteps, Priority, AcceptanceCriteria
- Order by: `Priority ASC, CreatedDate ASC` (1=Critical first)

### Step 4 — Select an actionable bug

Iterate through the query results and evaluate each bug for actionability. A bug is **actionable** if it has:
- A non-empty `System.Description` or `Microsoft.VSTS.TCM.ReproSteps` — enough context to understand the problem
- Sufficient technical detail for code-level investigation (not just "it's broken")

**Skip criteria** — move to the next bug if any of these apply:
- Description and ReproSteps are both empty or trivially short (< 20 characters)
- The bug is purely about UI/UX design, infrastructure, or requires manual/physical action
- A branch for this bug already exists locally or on the remote (already attempted)

Check for existing branches — fetch the full branch list **once** before iterating (avoid per-bug shell calls):
```
shell: cd {ado_repo_local_path} && git branch -a
```
Then filter locally: skip any bug whose ID appears in a branch matching `*bug-{WORK_ITEM_ID}*`.

If **no actionable bug** is found in the entire queue → **end this run**. Send notification:
> [societas-bug-fix] No actionable bugs in queue. All bugs either lack sufficient description or have already been attempted.

### Step 5 — Update work item to Active

Use `az boards work-item update` to set state to "Active" (see `ado` skill for command patterns).

### Step 6 — Prepare git branch

Branch name: `users/{alias}/bug-{WORK_ITEM_ID}` (extends the `commit-code` skill's `users/<alias>/...` convention, using `{alias}` from Step 1).

Always start from a clean, up-to-date target branch:
```
shell: cd {ado_repo_local_path} && git checkout {ado_pr_target_branch} && git pull origin {ado_pr_target_branch}
shell: cd {ado_repo_local_path} && git checkout -b users/{alias}/bug-{WORK_ITEM_ID}
```

### Step 7 — Delegate fix to Claude Code

Claude Code is responsible for **code changes and testing only** — it does NOT commit or push. Commit and push are handled by PraestoClaw in Step 9 using the `commit-code` skill.

```
claude_code(
    task=(
        "Fix ADO Bug #{WORK_ITEM_ID}: {TITLE}\n\n"
        "Description:\n{DESCRIPTION}\n\n"
        "Repro Steps:\n{REPRO_STEPS}\n\n"
        "Acceptance Criteria:\n{ACCEPTANCE_CRITERIA}\n\n"
        "Instructions:\n"
        "1. Identify the root cause in the codebase\n"
        "2. Implement the minimal fix\n"
        "3. Run existing tests to verify nothing is broken\n"
        "4. Add or update tests covering this bug\n"
        "5. Do NOT commit or push — leave changes unstaged. The orchestrator will handle commit and push.\n"
    ),
    task_type="code",
    mode="background",
    model="opus",
    cwd="{ado_repo_local_path}"
)
```

Monitor with `claude_code_status()`. Wait for completion.

### Step 8 — Verify result

Check Claude Code's output for test results.

**If tests failed or Claude Code failed:**
- Discard uncommitted changes and clean up the local branch:
  ```
  shell: cd {ado_repo_local_path} && git checkout -- . && git clean -fd
  shell: cd {ado_repo_local_path} && git checkout {ado_pr_target_branch} && git branch -D users/{alias}/bug-{WORK_ITEM_ID} 2>/dev/null || true
  ```
- Revert the work item state back to its original state (e.g. "New") using `az boards work-item update`
- Add a comment on the work item explaining the failure:
  ```
  shell: az boards work-item update --id {WORK_ITEM_ID} --discussion "[PraestoClaw] Automated fix attempted but failed. Reason: {FAILURE_REASON}. Leaving for manual investigation." -o json
  ```
- Send notification and **do not proceed** to commit/push/PR.

### Step 9 — Commit and push (via commit-code skill, orchestrated mode)

After Claude Code succeeds, PraestoClaw handles staging, then invokes the `commit-code` skill in **orchestrated mode**:

1. Stage the changed files: review what Claude Code changed with `git status`, then `git add <specific files>` (never `git add -A`)
2. Invoke the `commit-code` skill with `orchestrated: true` context:
   - commit-code will generate a conventional commit message with `AB#{WORK_ITEM_ID}` linking
   - commit-code will push using platform-aware auth (ADO bearer token if applicable)
   - Branch naming check is skipped (branch already created in Step 6)

**If commit-code reports `needs_fix: true`** (pre-commit hook failed due to issues introduced by current changes):
- Re-dispatch Claude Code to fix the hook errors:
  ```
  claude_code(
      task="Fix the following pre-commit hook errors in the current changes:\n{HOOK_ERROR_OUTPUT}\n\nDo NOT commit or push — just fix the code issues.",
      task_type="code",
      mode="background",
      model="opus",
      cwd="{ado_repo_local_path}"
  )
  ```
- After Claude Code completes, re-stage and retry commit-code (orchestrated mode). Allow **at most 2 retries** to avoid infinite loops.
- If still failing after retries → treat as a failed fix (go to Step 8 failure path).

**If commit-code silently bypassed with `--no-verify`** (pre-existing issue, not introduced by current changes) → proceed normally.

**If commit-code reports push failure** → go to error handling (delete local + remote branch, revert work item, notify).

### Step 10 — Create PR

The branch has been pushed in Step 9. Now create the PR using `az repos pr create` (see `ado` skill for command patterns):
- `--source-branch users/{alias}/bug-{WORK_ITEM_ID}`
- `--target-branch {ado_pr_target_branch}`
- `--title "fix: {BUG_TITLE} (AB#{WORK_ITEM_ID})"`
- `--description "Fixes AB#{WORK_ITEM_ID}\n\n## Summary\n{SUMMARY_OF_CHANGES}\n\n---\n_Automated fix by PraestoClaw societas-bug-fix skill_"`
- `--work-items {WORK_ITEM_ID}` — links PR to the bug

### Step 11 — Update work item to Resolved

Use `az boards work-item update` to set state to "Resolved".

### Step 12 — Clean up local branch

After PR is created, switch back to target branch and delete the local fix branch:
```
shell: cd {ado_repo_local_path} && git checkout {ado_pr_target_branch} && git branch -D users/{alias}/bug-{WORK_ITEM_ID}
```

This keeps the workspace clean for the next scheduled run.

### Step 13 — Report

Send notification with:
- Bug ID and title
- Priority level
- Branch name: `users/{alias}/bug-{WORK_ITEM_ID}`
- PR link (from `az repos pr create` output)
- Work item state: Resolved
- Test results: passed

### Error handling (unattended mode)

In unattended mode, errors must **not block future runs**. Always clean up and move on.

| Scenario | Action |
|----------|--------|
| Config settings missing | Abort run. Notify: "run interactive setup first" |
| `az` auth expired | Abort run. Notify: "az login required" |
| Git identity missing | Abort run. Notify: "git config required" |
| Dirty working tree | Abort run. Notify: "stash or commit pending changes" |
| Concurrency conflict | Skip silently. Next scheduler cycle will retry |
| `git pull` merge conflict | Abort run. Notify: "merge conflict on target branch" |
| No actionable bugs in queue | End silently. Nothing to do |
| Bug description insufficient | Skip bug, try next in queue |
| Branch already exists for bug | Skip bug, try next in queue |
| Claude Code task fails | Discard changes, delete local branch, revert work item state, add comment, notify |
| Tests fail | Discard changes, delete local branch, revert work item state, add comment, notify |
| Pre-commit hook fails (new issues) | Re-dispatch Claude Code to fix, retry commit (max 2 retries), then fail path |
| Pre-commit hook fails (pre-existing) | Silently bypass with `--no-verify`, continue |
| Commit/push fails (Step 9) | Delete local + remote branch, revert work item state, notify |
| PR creation fails | Keep remote branch (code is pushed). Notify |

### Guidelines
- **No human interaction** — this skill is designed for cron/scheduler. Never prompt for confirmation.
- **One bug per run** — process exactly one bug per invocation. The scheduler handles repetition.
- **Priority order** — always pick the highest-priority (lowest Priority number) actionable bug.
- **Clean workspace** — always return the working tree to target branch with no leftover fix branches.
- **Clean up both local and remote** — on failure after push, delete both branches to avoid "already attempted" false positives on retry.
- **Fail fast, fail safe** — on any error, clean up and abort. Don't leave half-finished state.
- **Notify on action** — send notifications only when something was done or when blocked. Skip silently when idle.
- **Delegate, don't duplicate** — use `ado` skill for ADO CLI patterns, `commit-code` skill for commit + push, Claude Code for code changes + testing only.
- Never push directly to the target branch — always use `users/{alias}/bug-{WORK_ITEM_ID}` branch.
