---
name: feedback
description: File a GitHub issue against gim-home/PraestoClaw with logs, environment, and recent conversation when the user reports a problem with PraestoClaw itself
metadata:
  activation:
    keywords: [feedback, 反馈, report bug, 报告问题, file issue, 提 issue, /feedback, praestoclaw bug]
    patterns:
      - "(?i)^/feedback\\b"
      - "(?i)\\b(file|report|submit|open)\\s+(a\\s+)?(bug|issue|feedback)\\b"
      - "(?i)(报告|反馈|提交|提个).*?(问题|bug|issue)"
---

# Feedback Assistant

Help the user file a GitHub issue against `gim-home/PraestoClaw` when they hit a bug or rough edge in PraestoClaw itself.

## When to use

- The user said `/feedback ...`
- The user expressed frustration about PraestoClaw's behavior and asked to report it (e.g. "this is broken, file a bug", "帮我反馈一下")
- The user explicitly asked to open an issue against the PraestoClaw repo

**Do NOT use** for:
- Bugs in the user's own code (use `bug-investigate` instead)
- Feature requests in third-party tools / MCP servers (those have their own repos)
- Generic Q&A about how PraestoClaw works (just answer)

## Workflow

This is a **confirmation-gated** flow. Always build and show the user a preview, and get their explicit approval of that exact preview before filing — never file without confirmation (a filed issue is public and cannot be unredacted). This skill does **not** prescribe *how* the confirmation is collected: just require it before submitting, and the runtime will surface the appropriate confirmation gate.

### Two separate artifacts — keep them separate

Throughout this skill you maintain **two** versions of the issue content:

1. **Full body** — the raw, complete content that will be submitted to GitHub. Contains the **full** sanitized log tail (~200 lines), full recent conversation, full environment block. **Never summarize, paraphrase, or shorten** any field here. This is what a human developer will use to debug.
2. **Preview** — a chat-friendly rendering shown to the user for confirmation. Logs and conversation may be collapsed for readability (see step 6).

**Critical**: when the user approves, you submit the **full body**, not the preview. Write the full body to the temp file used by `gh issue create`. Do not regenerate or re-summarize the content at submit time — that's how data drifts between what the user approved and what got filed.

Recommended approach: build the full body string first (steps 1–5), then derive the preview from it (step 6). Keep both in mind through confirmation and submit.

### Image attachments (screenshots from Teams)

The agent runtime cannot see image bytes — there's no multimodal pipeline. But when the user pasted screenshots, the gateway uploaded them to a public image host on ingest and the **URLs are already in your prompt** under an `[attachments: N image(s)...]` block, one URL per line.

Treat the attachments as ordinary content: for each URL, append `![screenshot N](url)` to the **full body** under a new `## Screenshots` section, render the same section in the preview (so the user can see the images they're filing), and proceed with the normal preview → confirmation → submit flow below. No special opt-in keyword is required.

If the attachments block reports upload failures (e.g. `(1 upload(s) failed)`), include a `_screenshot N: upload failed at gateway_` note in the body so the developer sees the context exists, and at submit time use step 8c (`--web`) so the user can drag the missing screenshots into the browser issue form.

### Gather context and show the draft

1. **Read the user's complaint** from the current message (everything after `/feedback`, or the natural-language description). If the description is empty or just `/feedback`, ask one short follow-up: "What's the issue you'd like to report?" and stop.

2. **Collect environment** in parallel where possible:
   - `praestoclaw version` — version string
   - `python --version` and `uname -srm` (or `ver` on Windows) — OS / Python
   - `pwd` — current working directory
   - List active MCP servers and loaded skills from the **current conversation context** (you already know them — no extra tool call needed)

3. **Collect log tail**:
   ```bash
   praestoclaw logs -n 200
   ```
   If this prints "No log file configured" or "Log file not found", note it as `_log unavailable_` in the draft instead of failing.

4. **Sanitize before showing the draft.** Apply these substitutions to log tail and recent-conversation text:
   - Home directory paths → `~` (e.g. `/Users/alice/foo` → `/Users/~/foo`, `C:\Users\bob\…` → `C:\Users\~\…`)
   - Email / UPN addresses → `[email]`
   - Anything that looks like a token, key, or secret → `[redacted]` (the platform's leak detector will also scrub tool output, but be defensive in what you put in the issue body)

   Credential redaction is automatic on tool output; the items above are your responsibility because they come from filesystem paths and conversation text.

5. **Generate a title**: `[Feedback] <≤80 char summary>`. Imperative, specific, no trailing punctuation.
   - Good: `[Feedback] Agent drops attachments larger than 5MB silently`
   - Bad: `[Feedback] something broken`

6. **Show the draft to the user** as a chat reply. The preview is a **rendering** of the full body — it must show enough that the user knows what they're agreeing to submit, but logs can be visually collapsed.

   Format:

   ```markdown
   **Preview — issue to be filed at `gim-home/PraestoClaw`**

   **Title:** <generated title>
   **Labels:** bug

   ---
   ## Description
   <full description from the full body — do NOT shorten>

   ## Environment
   - OS: <os>
   - Python: <python version>
   - PraestoClaw: <version>
   - Channel: <cli | teams | webchat | cloud>
   - CWD: <sanitized cwd>
   - MCP servers (<n>): <comma-separated names>
   - Skills loaded (<n>): <comma-separated names>

   ## Recent log tail
   _<N> lines collected (showing first 5 + last 5 below; full log will be in the issue)_
   ```
   <first 5 sanitized log lines>
   ...
   <last 5 sanitized log lines>
   ```

   ## Recent conversation
   **user**: <message, truncated to ~300 chars in the preview only>
   **assistant**: <message, truncated to ~300 chars in the preview only>
   ... (last ~10 turns, sanitized, tool calls folded as `[tool: name1, name2]`)
   ---
   ```

   The **only** parts that get visually compressed in the preview are:
   - Log tail: show first 5 + last 5 lines + a line count, **but keep all 200 lines in the full body**
   - Per-message truncation in "Recent conversation": ~300 chars in preview, ~600 chars in full body

   Everything else (title, labels, description, environment, MCP/skill lists) is identical between preview and full body.

7. **Require the user's explicit approval of this exact preview before filing.** Do not run `gh` until the user has confirmed. Do not decide *how* to collect that confirmation — just require it; the runtime turns a required confirmation into the right gate. Never file on your own initiative.

### On approval — submit

When the user approves the preview, submit the **full body** (step 8). If the user rejects, asks to change something, or gives a fresh problem description, do not file — revise the draft from the new input (keep environment/log/conversation as-is) or stop, as they direct. If they change the subject entirely, drop the pending draft and respond to what they actually asked.

**Fail-safe**: never submit on ambiguous or absent approval. The cost of a missed submission is "the user confirms again"; the cost of a wrong submission is a public, unredactable issue on the repo.

### 8. Submit (only after the user approves)

Filing an issue is a write action — the standard approval pipeline will show the user an Adaptive Card / CLI prompt before `gh` actually runs. That is the second checkpoint; trust it, don't try to add your own.

Go to step 8a by default. Use step 8c (`--web`) only if `gh` is not installed, or as the fall-through when the gateway reported per-image upload errors.

#### 8a. Submit headlessly with `gh issue create`

**Step 1 — Write the full body to a per-feedback file in `~/.praestoclaw/feedbacks/`.**

The full body contains all ~200 log lines, untruncated conversation turns, and — when screenshots were attached — a `## Screenshots` section with `![screenshot N](url)` lines.

Use the `Write` tool (not a shell heredoc) to write the body to:

```
<data-dir>/feedbacks/<YYYY-MM-DDTHHMM>-<title-slug>.md
```

Where:
- `<data-dir>` is `~/.praestoclaw/` on most setups (or `~/.praestoclaw-staging/` when running against staging, or `$PRAESTOCLAW_DATA_DIR` when set). Resolve it with `python -c "from praestoclaw.utils.helpers import get_feedback_dir; print(get_feedback_dir())"` and capture the path; `get_feedback_dir()` creates the directory on demand.
- `<YYYY-MM-DDTHHMM>` is the current UTC time (e.g. `2026-06-12T1224`). Use precision to the minute — collisions across two `/feedback` calls in the same minute are tolerable, the slug disambiguates.
- `<title-slug>` is derived from the issue title: strip `[Feedback] ` prefix, lowercase, replace runs of non-alphanumeric chars with `-`, trim to 40 chars. Example: `[Feedback] Agent drops attachments larger than 5MB` → `agent-drops-attachments-larger-than-5mb`.

**Why a persistent dir, not `tempfile.gettempdir()` or `/tmp`:**
- Bash heredoc (`cat > /tmp/foo <<EOF`) doesn't work in Windows PowerShell or cmd.exe. The `Write` tool + a Python-resolved path is the only thing that works on every platform without depending on which shell the agent's `shell` tool happens to invoke.
- The OS may clean tempdirs on a schedule. `~/.praestoclaw/feedbacks/` is persistent so users can revisit drafts of past reports.
- Locating the dir next to `logs/` and `sessions/` matches the rest of the data layout.

**Never** delete the file after submission — the agent doesn't own these any more than it owns log files. Users may want to look back at what they reported.

**Step 2 — Submit with `gh issue create`:**

Substitute the absolute path you wrote in Step 1 wherever you see `${BODY_FILE}` below. Do **NOT** pass the literal string `${BODY_FILE}` to `gh` — it must be replaced with the actual path before the command runs.

```bash
gh issue create \
  --repo gim-home/PraestoClaw \
  --title "<title from preview>" \
  --body-file "${BODY_FILE}" \
  --label bug
```

The command prints the new issue URL on success. **Remember the issue number/URL for this turn** so you can act on follow-ups. Reply to the user:

```
✅ Submitted: <url>
   (draft saved at ${BODY_FILE})
```

Then, in the **same reply**, offer the follow-up in the user's language: they can keep going and ask you to amend *this* issue — e.g. "add this screenshot to the issue" / "把这张截图补到 issue" / "补充这段信息到 issue" — and you'll update it for them (see **Amending a filed issue** below). Keep it to one short, natural line.

If `gh issue create` fails despite passing pre-flight (token revoked, network drop, repo-not-found): do **not** retry, do **not** try to re-auth. Fall through to **8c Path 2** below — the body file is already on disk, just build the URL from its contents and tell the user where the local copy lives.

#### 8c. Fallback — `gh` not installed / not signed in / image upload failed

Two entry conditions:

- **`gh` is missing or `gh auth status` fails** → predominantly a fresh-install case. Build a pre-filled URL and ask the user to open it in a browser.
- **Screenshots were attached but the gateway reported upload errors** (and `gh` is available) → run `gh issue create --web` so the pre-filled new-issue page opens in their browser and they can drag-drop the screenshots.

**Path 1 — `gh` available, image upload failed → `--web`:**

Write the full body to `<feedback_dir>/<timestamp>-<slug>.md` exactly as in 8a Step 1 (Write tool, never heredoc) — call this absolute path `${BODY_FILE}`. Include a note `_Screenshots: gateway upload failed — please drag attachments into the issue body before submitting_` in the body. Then substitute `${BODY_FILE}` with that actual path:

```bash
gh issue create \
  --repo gim-home/PraestoClaw \
  --title "<title from preview>" \
  --body-file "${BODY_FILE}" \
  --label bug \
  --web
```

Reply:

```
🌐 Image upload unavailable — opened the pre-filled issue in your browser. Drag your screenshots into the body and click Submit.
   (draft saved at ${BODY_FILE})
```

**Path 2 — `gh` unavailable / not signed in / 8a failed → pre-filled URL:**

Two entry conditions:

- `gh` CLI is missing entirely (`gh --version` fails).
- `gh` is installed but `gh auth status` fails. Do **NOT** try to drive `gh auth login` inline — see [github skill pre-flight](github.md). Tell the user once and fall through to the URL.
- 8a / 8c-Path-1 ran and `gh issue create` failed unexpectedly (token revoked, network drop, repo-not-found). Do **not** retry, do **not** try to re-auth — fall through to this path.

Build a URL the user can open manually:

```
https://github.com/gim-home/PraestoClaw/issues/new?title=<urlencoded title>&body=<urlencoded body>&labels=bug
```

GitHub's URL length is roughly capped around 8KB. If your URL exceeds ~6500 chars, truncate the **end of the body** and append `_[truncated — paste the rest from your local log]_` before urlencoding. Reply with one of these, depending on why we landed here:

If `gh` is missing:
```
🌐 Open this URL in your browser to file the issue:
<url>

(Tip: install GitHub CLI and run `gh auth login` in your shell to file directly next time, no browser hop needed.)
```

If `gh` is present but not signed in:
```
🌐 `gh` CLI isn't signed in — open this URL in your browser to file the issue:
<url>

(Tip: run `gh auth login` once in your shell to file directly next time. PraestoClaw won't sign in to gh for you.)
```

If 8a failed despite passing pre-flight:
```
🌐 Submission failed (`<short error>`) — open this URL in your browser to file the issue:
<url>
```

## Amending a filed issue (follow-ups)

After you file an issue **this turn**, you remember its number/URL — so handle follow-ups directly, with no new `/feedback`. Common asks: "add this screenshot to the issue", "补充这段信息到 issue", "fix the title".

- **Add information or a screenshot → comment** (preferred for additions):
  - Write the comment body with the `Write` tool (same rules as the issue body; never heredoc). Screenshots the user pastes in the follow-up are already uploaded — their URLs are in your prompt under the `[attachments: …]` block; append `![screenshot](url)` to the comment body.
  - `gh issue comment <number> --repo gim-home/PraestoClaw --body-file "${COMMENT_FILE}"`
- **Correct the original body or title → edit**:
  - `gh issue edit <number> --repo gim-home/PraestoClaw --body-file "${BODY_FILE}"` (or `--title "<new title>"`).

Notes:
- Prefer **comment** for additions; reserve **edit** for fixing what was already filed.
- These are write actions — the standard approval card fires before `gh` runs, exactly like the initial submit.
- Use the issue number from the URL you just filed. If the user references an issue you did **not** file this session, ask for the issue number or URL first.
- Same sanitization applies to comment/edit bodies (redact home paths, emails, secrets).

## Safety boundaries

- **Never submit without explicit user approval of the preview.** Even if the user says `/feedback yes please file this immediately`, still show the draft and require approval first — the runtime surfaces the confirmation gate. Filing a public issue is irreversible.
- **Never include unredacted home-directory paths or emails** in the body. If you're unsure whether a string is sensitive, redact it.
- **Never use `--no-edit` with `gh issue create`** — it bypasses behavior we rely on. (`--web` IS allowed, but only in step 8c.)
- **Only ever pass `--label bug`.** `gh` atomically rejects the whole command if any label is unknown — including "obvious" ones like `feedback`, `user-report`, `channel-teams`. Adding extras causes the issue to fail to create, the LLM retries, and the user sees a second approval card for the same intent. If you think a richer taxonomy is needed, ask the user to create the labels in the repo first.
- **Do not pre-fill the user's GitHub username, org membership, or any identifier they didn't explicitly volunteer.**

## Pitfalls

- **Don't submit the preview rendering — submit the full body.** The preview compresses logs (first 5 + last 5) and truncates messages for readability. The issue body must contain all ~200 log lines and full (≤600 char) message turns. When in doubt, re-check: "is the file I'm about to pass to `--body-file` the full body, or the chat preview?"
- Don't paste the raw `praestoclaw logs` output without sanitizing — log lines often contain absolute paths under `/Users/<name>` and occasional emails from MCP responses.
- Don't truncate the **middle** of a log; the tail is what matters for debugging. Truncate from the front if needed.
- Don't try to `gh issue create` from the body string directly — large bodies break shell quoting. Always go through `--body-file`.
- **Don't write the body file with a shell heredoc** (`cat > /tmp/foo <<EOF`). It fails on Windows PowerShell / cmd.exe and depends on `/tmp` existing. Use the `Write` tool with a path under `~/.praestoclaw/feedbacks/` (resolved via `get_feedback_dir()`) — Python paths work on every platform regardless of which shell the agent's `shell` tool happens to invoke.
- **Don't delete the body file after submission.** It lives next to logs/sessions on purpose so users can revisit what they reported. The agent doesn't own it.
- During the initial draft, don't block on attachments. If the user wants to add a screenshot or more context **after** filing, amend the issue with a follow-up comment (see **Amending a filed issue**).
- If the user runs `/feedback` again before confirming the previous draft, treat that as **restart** — replace the pending draft, don't stack them.
