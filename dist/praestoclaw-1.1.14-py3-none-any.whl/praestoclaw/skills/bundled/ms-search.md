---
name: ms-search
description: |
  Search across Microsoft internal systems — M365, SharePoint, ADO, EngHub, ICM,
  CloudBuild, Kusto, ES Chat, Bluebird — to answer questions about internal projects,
  services, incidents, documentation, and team resources.
  Also: given a repo URL, analyze the codebase and produce a multi-perspective
  knowledge base (frontend, backend, testing, CI/CD, requirements, compliance, etc.).
metadata:
  activation:
    keywords:
      - 内部搜索
      - 内部查询
      - 搜一下
      - 搜索一下
      - 帮我搜
      - 帮我查
      - 查一下
      - 查找
      - 找一下
      - 找找
      - internal search
      - search internal
      - find internal
      - look up
      - search for
      - eng.ms
      - ServiceTree
      - TSG
      - runbook
      - 分析仓库
      - 分析repo
      - 分析代码库
      - repo知识库
      - 知识沉淀
      - 知识提炼
      - 项目分析
      - analyze repo
      - repo knowledge
      - codebase analysis
      - 重新分析
      - refresh repo
      - update repo
      - 分析过的项目
      - analyzed repos
      - 知识库搜索
      - which repos
      - 哪些项目
      - 哪些仓库
    patterns:
      # English: questions about internal projects, services, or teams
      - "(?i)\\b(what|where|who|how|find|search|look\\s*up|any\\s+info)\\b.{0,60}\\b(project|service|team|org|repo|wiki|document|spec|tsg|runbook|incident|icm|pipeline|release|deployment|build|sprint|backlog)\\b"
      - "(?i)\\b(project|service|incident|icm|pipeline|build|deployment)\\b.{0,40}\\b(status|detail|info|owner|doc|history|log)\\b"
      - "(?i)\\b(search|find|look\\s*up|query)\\b.{0,40}\\b(across|in|from|on)\\s+(sharepoint|ado|devops|eng\\.ms|enghub|teams|confluence|wiki)\\b"
      - "(?i)\\beng\\.ms\\b"
      # Repo analysis: URL + analysis intent
      - "(?i)(analyze|分析|提炼|沉淀|了解|总结).{0,40}(repo|仓库|代码库|codebase|repository)"
      - "(?i)(repo|仓库|代码库|codebase|repository).{0,40}(知识|knowledge|分析|analyze|总结|summary)"
      - "(?i)(dev\\.azure\\.com|github\\.com|visualstudio\\.com)/[\\w.-]+/[\\w.-]+"
      # KB management: refresh, list, cross-repo search
      - "(?i)(refresh|update|重新分析|刷新).{0,30}(repo|仓库|知识|analysis|KB)"
      - "(?i)(list|列出|有哪些|show).{0,30}(analyzed|分析过|知识库|repo.{0,5}KB)"
      - "(?i)(which|哪些).{0,20}(repo|项目|仓库).{0,20}(use|用了|采用|包含)"
      # Chinese: questions about internal projects, services
      - "(?i)(有没有|有什么|哪个|哪些|谁负责|什么是|怎么找|在哪|在哪里|帮我(找|查|搜)).{0,40}(项目|服务|文档|设计文档|wiki|TSG|运维|流水线|部署|构建|团队|组织|事件|incident)"
      - "(?i)(这个|那个|关于).{0,20}(项目|服务|repo|仓库|文档).{0,20}(信息|详情|文档|wiki|负责人|owner|状态)"
      - "(?i)(了解|查看|搜索|搜一下|查一下).{0,30}(内部|公司|组织|部门)"
  requires:
    tools: [MCP_m365-copilot]
---

# Microsoft Internal Search

When the user asks about an internal project, service, incident, document, or team resource,
search across all available Microsoft internal MCP servers to gather comprehensive results.

## Strategy

### 1. Understand the query

Classify what the user is looking for:

| Category | Primary sources | Fallback sources |
|---|---|---|
| Documents / specs / design docs | M365 Copilot, SharePoint | EngHub, ADO Wiki |
| Code / repos / PRs | ADO (repos, PRs), Bluebird | — |
| Work items / bugs / tasks | ADO (work items) | — |
| Incidents / outages | ICM | ES Chat |
| Build / pipeline / deployment | CloudBuild | ADO (pipelines) |
| TSGs / runbooks / eng docs | EngHub | M365 Copilot, SharePoint |
| Service info / ServiceTree | EngHub | — |
| People / org / team | M365 User | — |
| Telemetry / data queries | Kusto | CloudBuild (Kusto) |
| S360 action items | S360 Breeze | — |
| General knowledge / how-to | Microsoft Learn | M365 Copilot |

### 2. Connect MCP servers

Before calling any MCP tool, ensure the server is connected. Use `tools(name='MCP_<server>')` to load tools for each server you plan to query.

Required servers (always try first):
- `MCP_m365-copilot` — broadest coverage: documents, emails, chats, sites, files

Additional servers (connect based on query category):
- `MCP_ado` — work items, repos, PRs, wikis, pipelines
- `MCP_sharepoint` — SharePoint sites, lists, document libraries
- `MCP_enghub` — eng.ms docs, TSGs, ServiceTree
- `MCP_icm` — incidents
- `MCP_cloudbuild` — builds, deployments, Kusto queries
- `MCP_kusto` — direct Kusto queries
- `MCP_es-chat` — ES Chat conversations
- `MCP_bluebird` — Engineering Copilot (repo-aware)
- `MCP_s360-breeze` — S360 compliance items
- `MCP_msft-learn` — Microsoft Learn documentation
- `MCP_m365-user` — user/org/manager info

### 3. Execute searches — fan out

Search **at least 2 sources** in parallel for breadth. Prioritize by category above.

Typical search flow:
1. **Always**: `MCP_m365-copilot` search (covers email, docs, chats, SharePoint in one call)
2. **If code/work items**: `MCP_ado` — search repos, query work items (WIQL)
3. **If incidents**: `MCP_icm` — get incidents by team or keyword
4. **If eng docs/TSG**: `MCP_enghub` — search eng.ms
5. **If builds/deploy**: `MCP_cloudbuild` — list builds, query status
6. **If data/telemetry**: `MCP_kusto` — execute Kusto query
7. **If people/org**: `MCP_m365-user` — look up user, manager, reports

### 4. Synthesize results

Combine results from all sources into a **single organized response**:

- **Deduplicate**: same document from M365 Copilot and SharePoint → show once
- **Group by type**: Documents, Work Items, Incidents, Code, People — use headers
- **Include links**: always include URLs/links so the user can navigate directly
- **Cite source**: tag each result with its source (e.g., `[SharePoint]`, `[ADO]`, `[ICM]`)
- **Rank by relevance**: most relevant results first within each group
- **Summarize**: provide a brief summary of each result, not just titles

### 5. Follow up

If initial search yields few results:
- Broaden the query (remove specific terms, try synonyms)
- Try additional MCP servers not yet queried
- Ask the user for clarification (org, project name, time range)

### 6. Repo discovery — proactively offer deep analysis

When search results mention or relate to a **code repository**, attempt to locate the repo
and offer the user a deeper analysis:

**When to trigger**: The user is searching for a project/service by name (not already providing a repo URL).

**How to find the repo**:
1. Check search results — M365 Copilot, SharePoint, EngHub results often contain repo URLs
2. `MCP_ado` — `repo_get_repositories` or search by project/repo name
3. `MCP_bluebird` — may return repo context
4. `MCP_enghub` — ServiceTree entries often link to source repos
5. Heuristic: try `dev.azure.com/{likely_org}/{project_name}/_git/{project_name}`

**Decision flow**:
```
Search results returned
  │
  ├─ Any repo URL found in results?
  │   ├─ Yes → Check if KB already exists (Step 0 in Part 2)
  │   │   ├─ KB exists → Mention: "该项目已有知识库 (上次分析: {date})，可直接查询"
  │   │   └─ KB not found → Ask: "我找到了该项目的代码仓库 {URL}，是否需要我分析代码库并生成知识库？"
  │   └─ No → Try to locate repo via MCP_ado / MCP_enghub
  │       ├─ Found → Ask: "我找到了可能相关的仓库 {URL}，要分析吗？"
  │       └─ Not found → Skip (just return search results)
  │
  └─ User confirms → Proceed to Part 2 (Repo KB analysis)
```

**Ask format** (append to search results):

```
---
🔍 我在搜索结果中发现了该项目的代码仓库：
   {repo_url}
   是否需要我深入分析代码库，生成多视角知识库？（架构、前后端、测试、CI/CD、合规等）
   回复"分析"即可开始。
```

**Do NOT auto-analyze** — always ask first, because full analysis consumes significant tool calls.

## Example interactions

**User**: "帮我查一下 Project Foo 的相关文档"
→ Search M365 Copilot for "Project Foo" + SharePoint search + ADO wiki search
→ Return grouped results: design docs, wiki pages, related work items
→ Found repo URL in results → Ask: "我找到了 Project Foo 的仓库，要分析吗？"

**User**: "Find any TSGs related to the Auth service"
→ Search EngHub for "Auth service TSG" + M365 Copilot for "Auth TSG"
→ Return TSG documents with links

**User**: "What incidents has the Payments team had this month?"
→ ICM query by team "Payments" + date filter
→ Return incident list with severity, status, and links

**User**: "搜一下关于 XYZ 服务的部署流水线"
→ CloudBuild search + ADO pipelines search for "XYZ"
→ Return pipeline definitions, recent runs, and status
→ Found repo via ADO → Ask: "发现 XYZ 的代码仓库，需要深入分析吗？"

## Important notes

- All searches are **read-only** — no modifications to any system
- If an MCP server is unavailable, skip it and search remaining sources
- Do NOT hallucinate results — only return what the MCP servers actually return
- Respect data classification — do not copy sensitive content into responses verbatim; summarize and link instead

## Response source label (REQUIRED)

**Every answer MUST include a source label** so the user knows where the information came from
and how fresh it is. Place the label at the end of the response, before any follow-up prompts.

| Source | Label format | When used |
|---|---|---|
| Real-time MCP search | `📡 来源：实时搜索 (MCP: {servers used})` | Part 1 API search results |
| KB cache (no MCP call) | `📋 来源：本地知识库 (上次分析: {_index.json.updated_at}, commit: {last_commit[:7]})` | Step 7 Tier 1–4 answers |
| KB + live code deep dive | `📋+📡 来源：知识库定位 + 实时代码读取 (代码读取时间: {now})` | Step 8 deep dive |
| Fresh analysis | `🔬 来源：实时代码分析 (commit: {HEAD[:7]}, {now})` | Steps 1–5 first-time analysis |
| Incremental update | `🔄 来源：增量更新 (旧commit: {old[:7]} → 新commit: {new[:7]}, 更新视角: {N}个)` | Step 6 update |

### Staleness warning

When answering from KB cache (📋), if `_index.json.updated_at` is older than 7 days,
append a warning:

```
⚠️ 该知识库已 {N} 天未更新，信息可能与最新代码不一致。说"刷新"可更新。
```

---

# Repo Knowledge Base — Analyze, Persist, Search

When the user provides a repo URL (ADO or GitHub) and asks to analyze, understand, or extract knowledge from it,
systematically explore the codebase, produce a **multi-perspective knowledge base**, persist it locally,
and support future searches directly from the knowledge base.

## Routing — detect intent

| Signal | Action |
|---|---|
| Repo URL + "分析" / "analyze" / "知识库" / "knowledge" | Full analysis → persist |
| Repo name (no URL) + analysis intent | Search first (Part 1), then offer to analyze |
| Question about a previously analyzed repo (general) | Search KB files (Step 7) |
| Question about specific feature/implementation in a repo | KB → deep dive into code (Step 8) |
| "重新分析" / "refresh" / "update" + repo | Incremental update (Step 6) |
| "搜" / "search" / "查" + knowledge base | Cross-repo KB search (Step 7) |

## Step 0: Check existing KB (always do first)

Before analyzing from scratch, check if a KB already exists for this repo.

**NOTE**: KB files live in `~/.praestoclaw/repo-kb/` which is outside the workspace sandbox.
Use the `shell` tool to read/check these files — `read_file` and `search_files` cannot access them.

```bash
# Check if KB exists
cat ~/.praestoclaw/repo-kb/{org}/{repo}/_index.json
```
```powershell
# Windows
Get-Content "$env:USERPROFILE\.praestoclaw\repo-kb\{org}\{repo}\_index.json" -ErrorAction SilentlyContinue
```

| Result | Action |
|---|---|
| File exists, `last_commit` matches current HEAD | KB is fresh → read perspectives directly, skip analysis |
| File exists, `last_commit` differs or `age > 7 days` | KB is stale → incremental update (Step 6) |
| File not found | No KB yet → full analysis (Steps 1–5) |

When the user asks a question about a previously analyzed repo, search the KB files
instead of re-analyzing (Step 7).

## Step 1: Identify repo source and connect tools

| URL pattern | Source | Tools to connect |
|---|---|---|
| `dev.azure.com/{org}/{project}/_git/{repo}` | ADO | `MCP_ado` (repos, wiki, pipelines, work items) |
| `{org}.visualstudio.com/{project}/_git/{repo}` | ADO (legacy) | `MCP_ado` |
| `github.com/{owner}/{repo}` | GitHub | `MCP_github` or `shell` (gh CLI) |

Also connect supporting tools:
- `MCP_cloudbuild` — build/release pipeline info
- `MCP_enghub` — ServiceTree, eng.ms documentation
- `MCP_m365-copilot` — related docs, design specs, emails
- `MCP_bluebird` — Engineering Copilot context for the repo

## Step 2: Explore the codebase (code-first, large-repo aware)

### Core principle: CODE IS GROUND TRUTH

Docs (`README.md`, wiki) are useful for **intent and context**, but often stale.
**Always prioritize reading actual source code** over documentation.
When docs and code disagree, **trust the code** and flag the discrepancy in the KB.

### Size assessment first

Before deep-diving, get the repo stats to calibrate exploration depth:

- **File count & languages** — ADO: `repo_get_repository` → stats; GitHub: repo API → languages
- **Directory tree** — list root, then top 2 levels only

### Exploration budget by repo size

| Repo size | Max files to read | Depth | Strategy |
|---|---|---|---|
| Small (< 50 files) | All | Full tree | Read all source files |
| Medium (50–500 files) | 60 | 3 levels | Structure + all routes/models/services + samples |
| Large (500–5K files) | 80 | 3 levels | Structure + all routes/models + key services |
| Huge (> 5K files) | 80 | 2 levels | Structure + routes/models of core modules; sample others |

### What to read (prioritized — code before docs)

**Tier 1 — Source code structure** (always read):
- Directory tree of `src/`, `lib/`, `app/`, `packages/` (top 3 levels)
- Entry points: `main.*`, `app.*`, `index.*`, `startup.*`, `Program.*`, `server.*`
- **ALL route/controller files**: files with `route`, `controller`, `handler`, `endpoint`, `api`, `view` in name or path — read every one, extract every endpoint
- **ALL model/schema files**: files with `model`, `schema`, `entity`, `type`, `dto` in name or path — read every one, extract fields and relationships
- **ALL service/logic files**: files in `services/`, `usecases/`, `logic/`, `domain/` — at least list exports, read key ones
- Root build files: `package.json`, `pyproject.toml`, `Cargo.toml`, `.csproj`, `go.mod`, `pom.xml`
- Config: `appsettings.json`, `.env.example`, `config/`, `settings.*`

**Tier 2 — Frontend specifics** (if frontend exists):
- **ALL page/view files**: `pages/`, `views/`, `screens/`, `app/` (Next.js/Nuxt) — read every page to get the full page inventory
- **ALL component files**: at minimum list every component; read key shared components
- Router config: `router.*`, `routes.*`, `App.tsx`, `_app.*`, `layout.*`
- State stores: `store/`, `stores/`, `redux/`, `context/`, `atoms/`
- API client layer: `api/`, `services/`, `hooks/use*.ts`

**Tier 3 — Infrastructure & CI** (read if within budget):
- CI/CD: `.github/workflows/*.yml`, `azure-pipelines.yml`, `.azure-pipelines/` — read every pipeline file, extract all stages/jobs
- `Dockerfile`, `docker-compose.yml`, `k8s/`, `helm/`, `terraform/`, `bicep/`
- Test config: `jest.config.*`, `pytest.ini`, `conftest.py`
- Test files: at least list all test files; read a few to understand patterns

**Tier 4 — Docs (supplementary, not authoritative)**:
- `README.md`, `CONTRIBUTING.md` — read for intent/context, **cross-check with code**
- `docs/`, `doc/` — skim for architecture diagrams, API contracts
- ADO wiki pages — useful for historical decisions
- **Flag any doc-code discrepancy** found

**Tier 5 — Metadata via MCP** (no file reading needed):
- ADO work items linked to repo (WIQL query)
- Related design docs (M365 Copilot search)
- Pipeline run history (CloudBuild / ADO pipelines)

## Step 3: Produce multi-perspective knowledge base

Organize findings into **perspectives** (视角). Skip any perspective with no relevant information.

### Each perspective MUST include:

1. **Summary** — high-level description of this aspect (2–5 sentences)
2. **Key facts** — concrete findings derived from **reading actual code** (not just docs)
3. **File map** — list of key source files and what they contain, so deep-dive is possible later:
   ```
   ## File Map
   - `src/api/routes/auth.py` — authentication endpoints (login, logout, token refresh)
   - `src/api/routes/users.py` — user CRUD API
   - `src/services/auth_service.py` — auth logic, JWT token generation, MSAL integration
   - `src/models/user.py` — User SQLAlchemy model, relationships
   - `src/middleware/rbac.py` — role-based access control middleware
   ```
4. **Doc-code discrepancies** — flag any mismatches found between docs and actual code:
   ```
   ## ⚠️ Doc-Code Gaps
   - README says "MongoDB" but code uses PostgreSQL (see `src/db/engine.py`)
   - CONTRIBUTING.md mentions `npm test` but actual test command is `pytest` (see `pyproject.toml`)
   ```

### Perspective detail requirements

Each perspective below lists the **minimum detail level** for first-time analysis.
Do not just summarize — enumerate concrete items (routes, pages, models, etc.).

#### 📐 Architecture Overview
- System type: monolith / microservice / monorepo / serverless
- **Module/package list** with one-line description each
- Inter-module dependencies (who calls whom)
- External service integrations (list each: DB, cache, queue, third-party APIs)
- Deployment topology if inferable (e.g., frontend → CDN, API → App Service, worker → AKS)

#### 🖥️ Frontend
- Framework + version (e.g., React 18, Next.js 14, Angular 17)
- **Complete page inventory** — every page/route with path and purpose:
  ```
  | Route | Page file | Purpose |
  |---|---|---|
  | `/` | `pages/index.tsx` | Landing/dashboard |
  | `/login` | `pages/login.tsx` | User login |
  | `/settings` | `pages/settings/index.tsx` | User settings |
  | `/projects/:id` | `pages/projects/[id].tsx` | Project detail |
  ```
- **Shared component list** — at least name + purpose for every component in `components/`
- State management: what tool + which stores/slices exist
- API client: how frontend talks to backend (fetch wrapper, axios instance, generated client)
- Styling approach + design system/component library if any
- Build config: bundler, output targets, env variable handling

#### ⚙️ Backend
- Language + framework + version
- **Complete API endpoint inventory** — every route with method, path, handler file, and purpose:
  ```
  | Method | Path | Handler file | Purpose |
  |---|---|---|---|
  | POST | `/api/auth/login` | `routes/auth.py` | User login, returns JWT |
  | GET | `/api/users/:id` | `routes/users.py` | Get user by ID |
  | PUT | `/api/projects/:id` | `routes/projects.py` | Update project |
  ```
- **Service layer** — list each service class/module with its responsibilities
- Middleware chain: list in order (auth, RBAC, rate limit, error handler, etc.)
- Auth flow: token type, issuer, validation logic, refresh mechanism
- Background jobs / workers if any

#### 🗄️ Data & Storage
- Database type + connection config file
- **Complete model/entity inventory** — every model with key fields:
  ```
  | Model | File | Key fields | Relationships |
  |---|---|---|---|
  | User | `models/user.py` | id, email, role, created_at | has_many Orders |
  | Order | `models/order.py` | id, user_id, status, total | belongs_to User |
  ```
- Migrations: tool (Alembic, EF, Prisma) + latest migration name/date
- Cache: what's cached, TTL strategy, cache keys
- Message queues: topics/queues, producers, consumers
- Seed data / fixtures if any

#### 🧪 Testing
- Framework(s) + config file locations
- **Test file inventory** — list all test files with what they test:
  ```
  | Test file | Type | Tests |
  |---|---|---|
  | `tests/test_auth.py` | unit | login, logout, token refresh |
  | `tests/e2e/test_checkout.py` | e2e | full checkout flow |
  ```
- Coverage config + current threshold (if in config)
- Mocking strategy: what's mocked, mock library
- Fixtures / test data setup approach
- CI test stage: where tests run, parallelization

#### 🚀 CI/CD & DevOps
- **Complete pipeline inventory** — every pipeline/workflow file with stages:
  ```
  | Pipeline | File | Trigger | Stages |
  |---|---|---|---|
  | CI | `.github/workflows/ci.yml` | push, PR | lint → test → build |
  | Deploy | `.github/workflows/deploy.yml` | tag v* | build → staging → prod |
  ```
- Per-stage detail: what each stage does, key commands
- Deployment targets: service type, region, resource names if visible
- Environment variables / secrets referenced in pipelines
- Feature flags system if any
- Rollback strategy if documented

#### 📦 Dependencies
- Package manager + lock file
- **Key dependency list** with version and purpose (not all, but top 15–20):
  ```
  | Package | Version | Purpose |
  |---|---|---|
  | fastapi | 0.104 | Web framework |
  | sqlalchemy | 2.0 | ORM |
  | msal | 1.28 | Microsoft auth |
  ```
- Internal/private packages (list each with source)
- Dev-only dependencies worth noting (linter, formatter, test tools)
- Update strategy: Dependabot/Renovate config if present

#### 🔒 Security & Compliance
- Auth mechanism: protocol, library, config file
- Secret management: where secrets are stored, how referenced
- **Security tool inventory**: CodeQL, Guardian, TSA, SAST/DAST configs
- CORS config: allowed origins
- Rate limiting: config and thresholds
- Input validation: approach (schema validation, middleware)
- License: type + any third-party license concerns
- Known security anti-patterns found in code

#### 📋 Requirements & Planning
- **Linked work item summary**: list active epics/features with state:
  ```
  | ID | Type | Title | State |
  |---|---|---|---|
  | #1234 | Epic | Auth Overhaul | Active |
  | #1235 | Feature | OAuth2 PKCE | In Progress |
  ```
- Current sprint/iteration name + dates
- Backlog size: count by type (bug/feature/task)
- Related design docs found (title + link)

#### 📖 Developer Experience
- Local setup: exact commands to get running (from README or Makefile)
- **Dev scripts inventory**: every script in package.json/Makefile/Taskfile:
  ```
  | Script | Command | Purpose |
  |---|---|---|
  | `dev` | `next dev` | Start dev server |
  | `test` | `pytest -v` | Run tests |
  | `lint` | `ruff check .` | Lint |
  ```
- Code style: linter + formatter + config files
- Pre-commit hooks if configured
- Documentation: what's documented, what's missing
- Onboarding friction: estimate (low/medium/high) with reasons
| 📖 Developer Experience | Setup instructions, contribution guide, linting, docs quality |

The **file map** is critical — it turns the KB into a **navigation index** that enables
on-demand deep-dives (Step 8) without re-scanning the entire repo.

## Step 4: Persist to local knowledge base

### Storage layout

```
~/.praestoclaw/repo-kb/
└── {org}/
    └── {repo}/
        ├── _index.json              # Metadata & perspective registry
        ├── architecture.md          # 📐 Architecture Overview
        ├── frontend.md              # 🖥️ Frontend
        ├── backend.md               # ⚙️ Backend
        ├── data-storage.md          # 🗄️ Data & Storage
        ├── testing.md               # 🧪 Testing
        ├── cicd-devops.md           # 🚀 CI/CD & DevOps
        ├── dependencies.md          # 📦 Dependencies
        ├── security-compliance.md   # 🔒 Security & Compliance
        ├── requirements.md          # 📋 Requirements & Planning
        └── developer-experience.md  # 📖 Developer Experience
```

### `_index.json` schema

```json
{
  "repo_url": "https://dev.azure.com/org/project/_git/repo",
  "org": "org",
  "repo": "repo",
  "source": "ado",
  "persisted": true,
  "created_at": "2026-04-26T10:00:00Z",
  "updated_at": "2026-04-26T10:00:00Z",
  "last_commit": "abc123def456",
  "default_branch": "main",
  "languages": ["python", "typescript"],
  "stack_summary": "FastAPI + React + PostgreSQL",
  "repo_size": "medium",
  "file_count": 320,
  "perspectives": [
    {"name": "architecture", "file": "architecture.md", "size_bytes": 2400, "updated_at": "2026-04-26T10:00:00Z"},
    {"name": "backend", "file": "backend.md", "size_bytes": 3100, "updated_at": "2026-04-26T10:00:00Z"}
  ],
  "tags": ["fastapi", "react", "postgresql", "azure-app-service"]
}
```

### Per-perspective file format

Each `.md` file is self-contained with a YAML header for searchability:

```markdown
---
repo: org/repo
perspective: backend
updated_at: 2026-04-26T10:00:00Z
tags: [python, fastapi, sqlalchemy, postgresql]
source: code
---

# Backend — org/repo

## Language & Framework
Python 3.12 + FastAPI (confirmed from `pyproject.toml` + `src/app.py`)

## API Design
REST API with OpenAPI spec at `/docs`
- Auth endpoints: `src/api/routes/auth.py` (login, logout, refresh)
- User CRUD: `src/api/routes/users.py`
- Webhook handlers: `src/api/routes/webhooks.py`

## Key Modules
- `src/app.py` — FastAPI app factory, middleware registration
- `src/api/routes/` — all route handlers (8 files)
- `src/services/` — business logic layer (auth, user, billing)
- `src/models/` — SQLAlchemy models (User, Order, Payment)
- `src/middleware/` — RBAC, rate limiting, error handling

## File Map
| File | Purpose | Key exports/classes |
|---|---|---|
| `src/app.py` | App factory | `create_app()` |
| `src/api/routes/auth.py` | Auth API | `/login`, `/logout`, `/refresh` |
| `src/services/auth_service.py` | Auth logic | `AuthService`, `verify_token()` |
| `src/models/user.py` | User model | `User`, `UserRole` |
| `src/db/engine.py` | DB connection | `get_engine()`, `SessionLocal` |

## ⚠️ Doc-Code Gaps
- README says "SQLite for dev" but `docker-compose.yml` always uses PostgreSQL
- API docs at `docs/api.md` lists `/v1/billing` but endpoint is `/v2/billing` in code
```

### Why per-perspective files?

- **Large repo handling**: Each perspective is 1–5 KB; total KB stays under 50 KB even for huge repos
- **Granular updates**: Only re-write the perspectives that changed
- **Fast search**: `search_files` can grep across all perspective files efficiently
- **Human-readable**: Users can browse `~/.praestoclaw/repo-kb/` directly

### Write procedure

**IMPORTANT**: The `write_file` tool is sandboxed to the workspace directory and CANNOT write
to `~/.praestoclaw/`. You MUST use the `shell` tool to write KB files:

```bash
# 1. Create directory
mkdir -p ~/.praestoclaw/repo-kb/{org}/{repo}/

# 2. Write each perspective file (use heredoc or echo)
cat > ~/.praestoclaw/repo-kb/{org}/{repo}/backend.md << 'KBEOF'
---
repo: org/repo
perspective: backend
...
KBEOF

# 3. Write _index.json LAST (acts as commit marker)
cat > ~/.praestoclaw/repo-kb/{org}/{repo}/_index.json << 'KBEOF'
{ ... }
KBEOF
```

On Windows, use PowerShell:
```powershell
# 1. Create directory
New-Item -ItemType Directory -Force -Path "$env:USERPROFILE\.praestoclaw\repo-kb\{org}\{repo}"

# 2. Write files
Set-Content -Path "$env:USERPROFILE\.praestoclaw\repo-kb\{org}\{repo}\backend.md" -Value @"
---
repo: org/repo
perspective: backend
...
"@

# 3. Write _index.json LAST
Set-Content -Path "$env:USERPROFILE\.praestoclaw\repo-kb\{org}\{repo}\_index.json" -Value '{ ... }'
```

**Do NOT use `write_file`** for KB persistence — it will write to the workspace instead of the data directory.
**Only execute this after user confirms persistence in Step 5.**

## Step 5: Present results and ask about persistence

After analysis, show the knowledge base to the user **first**, then ask about persistence.
**Do NOT persist automatically — always ask.**

### 5a. Show results

Present the multi-perspective analysis results directly in the conversation.

### 5b. Ask about persistence and auto-update

After showing results, ask the user **in a single prompt**:

```
---
以上是对 {repo} 的分析结果。

💾 是否保存到本地知识库？
   保存后，下次你问起这个项目时可以直接从本地查询，无需重新分析。
   存储路径: ~/.praestoclaw/repo-kb/{org}/{repo}/

   回复：
   - "保存" → 保存到本地
   - "保存并每天更新" → 保存 + 每天自动检查更新
   - "保存并每周更新" → 保存 + 每周自动检查更新
   - "不用" → 仅本次查看，不保存
```

### 5c. Execute based on user response

| User response | Action |
|---|---|
| "保存" / "save" / "是" | Write KB files (Step 4) |
| "保存并每天更新" / "save + daily" | Write KB files + register daily cron (Step 6 auto-update) |
| "保存并每周更新" / "save + weekly" | Write KB files + register weekly cron (Step 6 auto-update) |
| "不用" / "no" / "不需要" | Do nothing — results remain in conversation only |
| User ignores / continues with other question | Do nothing — treat as "不用" |

### 5d. Confirmation after save

If user chose to save:

```
---
💾 已保存到 ~/.praestoclaw/repo-kb/{org}/{repo}/
   {N} 个视角 | {size} KB | commit {HEAD[:7]}
   下次你问起这个项目，我会直接从知识库查询。
   说"刷新"可手动更新。
```

If user also chose auto-update, append:

```
🔄 已设置{每天/每周}自动更新。说"停止自动更新 {repo}"可取消。
```

## Step 6: Incremental update (stale KB)

Triggered when: KB exists but `last_commit` differs from current HEAD, or `age > 7 days`,
or user explicitly says "重新分析" / "refresh" / "update".

### Update procedure

1. **Get current HEAD** — fetch latest commit SHA from repo
2. **Diff detection** — compare `_index.json.last_commit` vs current HEAD:
   - ADO: `repo_get_commits(top=20, from=last_commit)` → changed file paths
   - GitHub: compare API or `git log --name-only`
3. **Classify changes** — map changed file paths to affected perspectives:

   | Changed path pattern | Affected perspectives |
   |---|---|
   | `src/`, `lib/`, `app/` | architecture, backend/frontend (by content) |
   | `*.test.*`, `tests/`, `__tests__/` | testing |
   | `Dockerfile`, `k8s/`, `helm/`, `infra/` | cicd-devops |
   | `package.json`, `pyproject.toml`, `*.lock` | dependencies |
   | `.github/workflows/`, `azure-pipelines.yml` | cicd-devops |
   | `SECURITY.md`, `tsa.config`, `guardian/` | security-compliance |
   | `README.md`, `CONTRIBUTING.md`, `docs/` | developer-experience |
   | ADO work item changes | requirements |

4. **Re-analyze only affected perspectives** — re-read relevant files, regenerate those `.md` files
5. **Update `_index.json`** — bump `updated_at`, `last_commit`, per-perspective timestamps
6. **Skip unchanged perspectives** — don't re-read or re-write them

### Force full refresh

If user says "完全重新分析" / "full refresh" → delete the entire `{org}/{repo}/` directory and re-run Steps 1–5.

### Auto-update via cron (opt-in)

Registered only when user explicitly chooses "保存并每天/每周更新" in Step 5b,
or later requests "给 myrepo 设置自动更新".

#### Register cron job

Use the `cron` tool to create a scheduled job:

```
cron(
  name="repo-kb-update-{org}-{repo}",
  schedule="interval",
  interval=86400,                          # 24h (daily) or 604800 (weekly)
  message="Incremental update repo KB for {org}/{repo}: check HEAD of {repo_url}, compare with last_commit in ~/.praestoclaw/repo-kb/{org}/{repo}/_index.json, if different run incremental update (Step 6).",
  session_mode="isolated"
)
```

- **`interval`**: `86400` for daily, `604800` for weekly (based on user choice)
- **`session_mode: isolated`**: each run gets a fresh context (no pollution between runs)
- **Job logic**: the cron message instructs the agent to:
  1. Read `_index.json` → get `last_commit`
  2. Fetch current HEAD from repo (via `MCP_ado` or `MCP_github`)
  3. If same → skip (no output)
  4. If different → run incremental update (Step 6)
  5. Notify user via `notify(message="Repo KB updated for {org}/{repo}: N perspectives refreshed")`

#### Track cron in `_index.json`

When a cron job is registered, add to `_index.json`:

```json
{
  "auto_update": {
    "enabled": true,
    "interval": 86400,
    "cron_job_name": "repo-kb-update-myorg-myrepo"
  }
}
```

#### Manage auto-update

| User says | Action |
|---|---|
| "停止自动更新 myrepo" / "stop auto-update" | `cron` tool → disable the job; set `auto_update.enabled=false` in `_index.json` |
| "改成每周更新" / "change to weekly" | `cron` tool → update interval; update `_index.json` |
| "哪些repo有自动更新" / "which repos auto-update" | Scan all `_index.json` → show repos with `auto_update.enabled=true` |

## Step 7: Search across knowledge base

When the user asks a question that may be answered by existing KB content, search the persisted files
**before** making MCP calls.

### Search tiers

**NOTE**: KB files are outside the workspace sandbox. Use `shell` tool for all KB reads/searches.

**Tier 1 — Specific repo query** ("ProjectX 的后端用什么框架?"):
1. `shell("cat ~/.praestoclaw/repo-kb/{org}/{repo}/backend.md")` — read the perspective directly
2. Answer from the file content; no MCP calls needed

**Tier 2 — Keyword search within one repo** ("ProjectX 里有用到 Redis 吗?"):
1. `shell("grep -rl 'Redis' ~/.praestoclaw/repo-kb/{org}/{repo}/")` (or `Select-String` on Windows)
2. Read matched files, return excerpts with perspective context

**Tier 3 — Cross-repo search** ("哪些项目用了 FastAPI?" / "which repos use Kubernetes?"):
1. `shell("grep -rl 'FastAPI' ~/.praestoclaw/repo-kb/")` — search across all KB files
2. Group hits by repo, read `_index.json` for each matched repo
3. Return: repo name, stack, matched perspective, relevant excerpt

**Tier 4 — Tag-based discovery** ("有哪些 Python 项目?" / "list all analyzed repos"):
1. `shell("find ~/.praestoclaw/repo-kb -name '_index.json'")` (or `Get-ChildItem -Recurse` on Windows)
2. Read each `_index.json` → collect `languages`, `tags`, `stack_summary`
3. Present as a table

### Search decision flow

```
User question about a repo
  │
  ├─ Repo name/URL recognized?
  │   ├─ Yes → KB exists for this repo? (check _index.json)
  │   │   ├─ Yes → Is this a specific/detailed question? (e.g., "how does feature X work")
  │   │   │   ├─ Yes → On-demand deep dive (Step 8)
  │   │   │   └─ No → Search KB files (Tier 1 or 2)
  │   │   │       └─ Answer found? → Return answer
  │   │   │       └─ Not found? → Fall through to deep dive (Step 8)
  │   │   └─ No → MCP search (Part 1), then offer to analyze
  │   └─ No → Cross-repo search (Tier 3 or 4)
  │       └─ Matches found? → Return results
  │       └─ No matches? → Fall through to MCP search (Part 1)
```

## Step 8: On-demand deep dive (KB → Code)

The KB stores **summaries + file maps**, not full code. When the user asks a detailed question
about a specific feature, module, or implementation detail:

### When to trigger

- User asks "how does X work?" / "X 是怎么实现的?"
- User asks about a specific API endpoint, data flow, or algorithm
- User asks "show me the code for X" / "X 的代码在哪?"
- KB search (Step 7) finds relevant perspective but lacks detail to answer

### Deep dive procedure

1. **Locate via KB file map** — read the relevant perspective `.md` file, find the files
   listed in the File Map that relate to the user's question
2. **Read actual code from repo** — use `MCP_ado` (`repo_get_file_content`) or `MCP_github`
   (`get_file_contents`) to read the specific source files identified in step 1
3. **Trace the code path** — if the question is about a flow (e.g., "how does login work?"),
   follow the call chain: route handler → service → model → external calls
4. **Answer from code** — explain the implementation based on **actual code read**,
   not from the KB summary
5. **Auto-enrich KB** — since KB exists (user already consented to persistence),
   automatically append the deep-dive findings to the relevant perspective file:
   - Add newly discovered files to the File Map
   - Add implementation details under a `## Deep Dives` section
   - Fix any doc-code gaps found
   - Update `_index.json` timestamps
   - **No need to ask again** — user's initial save consent covers all future enrichments

### Example deep-dive flow

User: "myrepo 的 auth token refresh 是怎么实现的?"

1. Read `~/.praestoclaw/repo-kb/myorg/myrepo/backend.md`
   → File Map shows: `src/api/routes/auth.py` (has `/refresh`), `src/services/auth_service.py`
2. `MCP_ado` → `repo_get_file_content(path="src/api/routes/auth.py")` — read the refresh endpoint
3. See it calls `auth_service.refresh_token()` → read `src/services/auth_service.py`
4. See it uses `msal.ConfidentialClientApplication` → explain the full flow
5. Answer: "Token refresh uses MSAL's `acquire_token_by_refresh_token()`, validates expiry
   in `auth_service.py:45`, and returns new access+refresh pair. Here's the code path: ..."

### Key principle

> **KB = map, Code = territory.** The KB tells you *where* to look.
> The code tells you *how it actually works*. Always read code for specific questions.

### Auto-enrich rule

Once a repo has `_index.json` (user consented to persist in Step 5), **all subsequent
interactions that produce new knowledge automatically write back to the KB**:

| Interaction | Auto-enrich action |
|---|---|
| Deep dive into a feature (Step 8) | Append to perspective `.md` under `## Deep Dives` |
| Discover new files during Q&A | Add to File Map in relevant perspective |
| Find doc-code gap | Update `## ⚠️ Doc-Code Gaps` section |
| Answer cross-cutting question | May create/update multiple perspectives |
| Incremental update (Step 6) | Re-write affected perspective files |

This means **the KB gets richer over time** — each question the user asks about the repo
contributes new details. The user never needs to re-confirm save permission.

## Example interactions

**User**: "分析一下这个repo https://dev.azure.com/myorg/myproject/_git/myrepo"
→ Check KB → not found → full analysis (Steps 1–5)
→ Read actual code (entry points, routes, models) + cross-check with docs
→ Persist 10 perspective files (with file maps) + `_index.json`
→ Show knowledge base + "已保存到本地"

**User**: "myrepo 的后端用什么框架?"
→ Check KB → found → read `backend.md` → answer directly (no MCP)

**User**: "myrepo 的 token refresh 是怎么实现的?"
→ Check KB → found → read `backend.md` → File Map shows `auth.py`, `auth_service.py`
→ Deep dive (Step 8): read actual code from repo via MCP_ado
→ Answer from code: "uses MSAL acquire_token_by_refresh_token() in auth_service.py:45..."

**User**: "哪些项目用了 PostgreSQL?"
→ Cross-repo search → grep "PostgreSQL" across all KB files
→ Return: "3 repos use PostgreSQL: repo-A (backend), repo-B (data-storage), repo-C (backend)"

**User**: "重新分析 myrepo"
→ Check KB → found, stale → incremental update (Step 6)
→ Only re-analyze changed perspectives → update files

**User**: "列出所有分析过的项目"
→ Scan `~/.praestoclaw/repo-kb/*/_index.json` (Tier 4)
→ Table: repo, stack, languages, last updated
