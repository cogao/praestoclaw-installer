"""
templates.py — Markdown document templates for the repo-analysis skill.

All template strings use Python's str.format_map() convention: {key} placeholders
are replaced at render time. Literal braces in code blocks are escaped as `{{` and `}}`.
"""

from __future__ import annotations

import json
from typing import Any

# ---------------------------------------------------------------------------
# README template  (kb/README.md)
# ---------------------------------------------------------------------------

README_TEMPLATE = """\
# {repo_name} 知识库

> 最后更新：{analyzed_at} | 模块数：{module_count} | 分析 commit：{commit_short}

## 仓库概览

{overview_text}

## PM 视角

{pm_overview}

## Developer 视角

{developer_overview}

## Tester 视角

{tester_overview}

## Team Lead 视角

{team_lead_overview}

## Designer / UX 视角

{designer_overview}

## Product Marketing / GTM 视角

{marketing_overview}

## Security / Compliance 视角

{security_overview}

## SRE / DevOps 视角

{sre_overview}

## Data / Analytics 视角

{data_overview}

## 模块导航

| 模块 | 类型 | 简介 | 角色文档 |
|------|------|------|----------|
{module_table_rows}

## 快速入口

- [角色化代码索引](code_index.md)
- [问答缓存](qa_cache.md)
"""

# ---------------------------------------------------------------------------
# modules/<name>/pm.md
# ---------------------------------------------------------------------------

PM_TEMPLATE = """\
# {module_name} - PM 视角

> 模块路径：`{module_paths}`
> 最后分析：{analyzed_at}

## 用户价值

{user_value}

## 产品行为

{product_behavior}

## 关键用户流程

{key_flows}

## 数据与指标

{metrics}

## PM 需要追问

{pm_questions}
"""

# ---------------------------------------------------------------------------
# modules/<name>/developer.md
# ---------------------------------------------------------------------------

DEVELOPER_TEMPLATE = """\
# {module_name} - Developer 视角

> 模块路径：`{module_paths}`
> 最后分析：{analyzed_at}

## 代码入口

{entry_points}

## 核心实现

{implementation}

## 关键依赖与接口

{dependencies}

## 扩展点与边界

{extension_points}

## 开发风险

{developer_risks}
"""

# ---------------------------------------------------------------------------
# modules/<name>/tester.md
# ---------------------------------------------------------------------------

TESTER_TEMPLATE = """\
# {module_name} - Tester 视角

> 模块路径：`{module_paths}`
> 最后分析：{analyzed_at}

## 测试范围

{test_scope}

## 关键场景

{critical_scenarios}

## 测试数据与环境

{test_data}

## 回归风险

{regression_risks}

## 测试缺口

{test_gaps}
"""

# ---------------------------------------------------------------------------
# modules/<name>/team_lead.md
# ---------------------------------------------------------------------------

TEAM_LEAD_TEMPLATE = """\
# {module_name} - Team Lead 视角

> 模块路径：`{module_paths}`
> 最后分析：{analyzed_at}

## 职责与边界

{ownership}

## 复杂度与维护成本

{complexity}

## 交付风险

{delivery_risks}

## 跨团队依赖

{cross_team_dependencies}

## 建议行动

{recommended_actions}

## 变更历史

{change_history}
"""

# Backward-compatible aliases for callers that still import the old names.
OVERVIEW_TEMPLATE = PM_TEMPLATE
TECHNICAL_TEMPLATE = DEVELOPER_TEMPLATE
TESTING_TEMPLATE = TESTER_TEMPLATE
# ``SECURITY_TEMPLATE`` is defined further down, after ``SECURITY_AUDIT_TEMPLATE``
# itself exists — defining it here would be a forward reference.

# ---------------------------------------------------------------------------
# modules/<name>/designer.md  (Designer / UX)
# ---------------------------------------------------------------------------

DESIGNER_TEMPLATE = """\
# {module_name} - Designer / UX 视角

> 模块路径：`{module_paths}`
> 最后分析：{analyzed_at}

## 用户旅程与触达点

{user_journey}

## 关键界面与组件

{key_surfaces}

## 设计系统与令牌

{design_system}

## 可达性与本地化

{accessibility}

## 设计债与改进点

{design_debt}
"""

# ---------------------------------------------------------------------------
# modules/<name>/marketing.md  (Product Marketing / GTM)
# ---------------------------------------------------------------------------

MARKETING_TEMPLATE = """\
# {module_name} - Product Marketing / GTM 视角

> 模块路径：`{module_paths}`
> 最后分析：{analyzed_at}

## 目标用户与场景

{target_audience}

## 价值主张与定位

{value_proposition}

## 关键卖点

{key_selling_points}

## 上市材料缺口

{collateral_gaps}

## 竞品与差异化提示

{competitive_notes}
"""

# ---------------------------------------------------------------------------
# modules/<name>/security.md  (Security / Compliance)
# ---------------------------------------------------------------------------

SECURITY_AUDIT_TEMPLATE = """\
# {module_name} - Security / Compliance 视角

> 模块路径：`{module_paths}`
> 最后分析：{analyzed_at}

## 敏感数据流

{sensitive_data}

## 认证与授权点

{authn_authz}

## 外部依赖与信任边界

{external_dependencies}

## 合规与审计要求

{compliance_requirements}

## 修复优先级

{remediation_priorities}
"""

SECURITY_TEMPLATE = SECURITY_AUDIT_TEMPLATE

# ---------------------------------------------------------------------------
# modules/<name>/sre.md  (SRE / DevOps)
# ---------------------------------------------------------------------------

SRE_TEMPLATE = """\
# {module_name} - SRE / DevOps 视角

> 模块路径：`{module_paths}`
> 最后分析：{analyzed_at}

## 部署与发布单元

{deploy_units}

## 可观测性现状

{observability}

## SLO / 告警 / 容量

{slo_alerting}

## 依赖与故障域

{failure_domains}

## 运维负担与自动化机会

{operational_burden}
"""

# ---------------------------------------------------------------------------
# modules/<name>/data.md  (Data / Analytics)
# ---------------------------------------------------------------------------

DATA_TEMPLATE = """\
# {module_name} - Data / Analytics 视角

> 模块路径：`{module_paths}`
> 最后分析：{analyzed_at}

## 数据生产与消费

{data_flows}

## 关键事件与埋点

{telemetry_events}

## 指标定义

{metric_definitions}

## 数据契约与下游

{data_contracts}

## 分析缺口

{analytics_gaps}
"""

# ---------------------------------------------------------------------------
# Role metadata
# ---------------------------------------------------------------------------

AUDIENCE_DOCS: dict[str, dict[str, str]] = {
    "pm": {"label": "PM", "file": "pm.md"},
    "developer": {"label": "Developer", "file": "developer.md"},
    "tester": {"label": "Tester", "file": "tester.md"},
    "team_lead": {"label": "Team Lead", "file": "team_lead.md"},
    "designer": {"label": "Designer / UX", "file": "designer.md"},
    "marketing": {"label": "Product Marketing / GTM", "file": "marketing.md"},
    "security": {"label": "Security / Compliance", "file": "security.md"},
    "sre": {"label": "SRE / DevOps", "file": "sre.md"},
    "data": {"label": "Data / Analytics", "file": "data.md"},
}

# ---------------------------------------------------------------------------
# kb/code_index.md
# ---------------------------------------------------------------------------

CODE_INDEX_TEMPLATE = """\
# Code Index

> 最后更新：{updated_at}

## 产品入口

| 功能名称 | 路由/触发 | 入口文件 | 主要受众 | 模块 |
|---------|---------|---------|---------|------|
{product_entry_rows}

## Developer 代码入口

{module_file_sections}

## Tester 测试入口

{test_entry_sections}

## Team Lead 关注点

{leadership_sections}
"""

# ---------------------------------------------------------------------------
# kb/qa_cache.md
# ---------------------------------------------------------------------------

QA_CACHE_TEMPLATE = """\
# 问答缓存

> 记录用户问过的问题和答案，加速重复查询。

---

"""

QA_CACHE_ENTRY_TEMPLATE = """\
## Q: {question}
**日期**: {date}
**相关模块**: {module}
**答案**:
{answer}

**来源**: {source} ({analysis_type})

---

"""

# ---------------------------------------------------------------------------
# Placeholder document (analysis failure fallback)
# ---------------------------------------------------------------------------

PLACEHOLDER_TEMPLATE = """\
# {module_name} - 分析失败

> 最后尝试：{analyzed_at}

自动分析失败，请手动补充或重新执行分析。

错误信息：{error_message}
"""

# ---------------------------------------------------------------------------
# Change history entry (appended to team_lead.md)
# ---------------------------------------------------------------------------

CHANGE_HISTORY_ENTRY_TEMPLATE = """\
### {date} (commit {commit_short})
- 变更文件：{changed_files}
- 变更摘要：{change_summary}
"""

# ---------------------------------------------------------------------------
# .state.json schema (as a Python TypedDict-compatible structure)
# ---------------------------------------------------------------------------

STATE_SCHEMA: dict[str, Any] = {
    "last_commit": "",  # Full commit SHA of last analysis
    "analyzed_at": "",  # ISO 8601 timestamp
    "module_count": 0,
    "modules": [
        # {
        #   "name": "auth",
        #   "paths": ["src/auth/"],
        #   "type": "feature",       # feature|service|lib|config|infra|test
        #   "description": "...",
        #   "doc_path": "modules/auth/"
        # }
    ],
    "config": {
        "max_concurrency": 20,
        "layer2_batch_size": 20,
        "layer2_file_char_limit": 4000,
        "layer3_file_char_limit": 4000,
        "retry_max_attempts": 3,
        "retry_base_delay_ms": 2000,
        "skip_patterns": [
            "vendor/",
            "node_modules/",
            ".git/",
            "dist/",
            "build/",
            "__pycache__/",
            "*.lock",
            "*.generated.*",
            "*.pb.go",
            "*.pb.py",
            "*.min.js",
        ],
        "large_repo_module_limit": 50,
    },
}

# ---------------------------------------------------------------------------
# Default config (matches STATE_SCHEMA["config"])
# ---------------------------------------------------------------------------

DEFAULT_CONFIG: dict[str, Any] = dict(STATE_SCHEMA["config"])


def render_template(template: str, context: dict[str, Any]) -> str:
    """Safely render a template string with the given context dict.

    Missing keys substitute the placeholder text ``<key>`` (rather than
    raising ``KeyError`` or silently dropping the placeholder), so partial
    renders degrade gracefully and the missing slot stays visible.
    """

    class _DefaultDict(dict):  # type: ignore[type-arg]
        def __missing__(self, key: str) -> str:
            return f"<{key}>"

    return template.format_map(_DefaultDict(context))


def state_to_json(state: dict[str, Any]) -> str:
    """Serialize a state dict to pretty-printed JSON."""
    return json.dumps(state, ensure_ascii=False, indent=2)


def config_to_json(config: dict[str, Any]) -> str:
    """Serialize a config dict to pretty-printed JSON."""
    return json.dumps(config, ensure_ascii=False, indent=2)
