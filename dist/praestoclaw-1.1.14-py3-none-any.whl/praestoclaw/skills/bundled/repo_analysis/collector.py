"""Deterministic repository fact collection for repo-analysis.

This module deliberately does not call an LLM. It gathers stable facts that
can be reused by the layered analyzer and tested without provider wiring.
"""

from __future__ import annotations

import fnmatch
import subprocess
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

_KEY_FILES = (
    "README.md",
    "README",
    "README.rst",
    "CONTRIBUTING.md",
    "CHANGELOG.md",
    "pyproject.toml",
    "package.json",
    "requirements.txt",
    "setup.py",
    "Cargo.toml",
    "go.mod",
    "Dockerfile",
    "docker-compose.yml",
    "docker-compose.yaml",
    "Makefile",
    "CLAUDE.md",
)

_KEY_GLOBS = (
    ".github/workflows/*.yml",
    ".github/workflows/*.yaml",
    "docs/**/*.md",
)


@dataclass(slots=True)
class RepoFacts:
    """Deterministically collected facts about a repository."""

    repo_root: Path
    files: list[Path]
    dir_tree: str
    compact_dir_tree: str
    file_stats: dict[str, int]
    key_files: dict[str, str] = field(default_factory=dict)
    git_activity: str = ""
    large_repo: bool = False

    def tree_for_prompt(self) -> str:
        """Return the directory tree shape appropriate for the repo size."""
        return self.compact_dir_tree if self.large_repo else self.dir_tree

    def prompt_summary(self, *, max_key_files: int = 8) -> str:
        """Return a compact fact pack for LLM prompts."""
        stats = ", ".join(f"{ext}: {count}" for ext, count in list(self.file_stats.items())[:12])
        key_file_names = ", ".join(list(self.key_files)[:max_key_files]) or "无"
        git_summary = self.git_activity.strip()[:1200] or "无最近 git 活动摘要"
        return (
            f"文件总数：{len(self.files)}\n"
            f"主要文件类型：{stats or '未识别'}\n"
            f"关键项目文件：{key_file_names}\n"
            f"最近 git 活动：\n{git_summary}"
        )


def collect_repo_facts(
    repo_root: Path,
    skip_patterns: list[str],
    *,
    large_repo_threshold: int = 2000,
    key_file_char_limit: int = 3000,
) -> RepoFacts:
    """Collect deterministic repo facts used by full and incremental analysis."""
    repo_root = Path(repo_root)
    files = _collect_files(repo_root, skip_patterns)
    return RepoFacts(
        repo_root=repo_root,
        files=files,
        dir_tree=_build_dir_tree(repo_root, files, max_dirs=300),
        compact_dir_tree=_build_dir_tree(repo_root, files, max_depth=3, max_dirs=300),
        file_stats=_file_stats(files),
        key_files=_collect_key_files(repo_root, key_file_char_limit),
        git_activity=_git_activity(repo_root),
        large_repo=len(files) > large_repo_threshold,
    )


def _collect_files(repo_root: Path, skip_patterns: list[str]) -> list[Path]:
    files: list[Path] = []
    for path in sorted(repo_root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(repo_root).as_posix()
        if _should_skip(rel, skip_patterns):
            continue
        files.append(path)
    return files


def _should_skip(path_str: str, skip_patterns: list[str]) -> bool:
    for pattern in skip_patterns:
        if fnmatch.fnmatch(path_str, f"*{pattern}*") or path_str.startswith(pattern):
            return True
    return False


def _build_dir_tree(
    repo_root: Path,
    files: list[Path],
    *,
    max_depth: int | None = None,
    max_dirs: int = 300,
) -> str:
    dirs: set[str] = set()
    for file_path in files:
        rel = file_path.relative_to(repo_root).as_posix()
        parts = rel.split("/")
        limit = len(parts) if max_depth is None else min(len(parts), max_depth + 1)
        for index in range(1, limit):
            dirs.add("/".join(parts[:index]))
    return "\n".join(sorted(dirs)[:max_dirs])


def _file_stats(files: list[Path]) -> dict[str, int]:
    counts: Counter[str] = Counter()
    for file_path in files:
        suffix = file_path.suffix.lower() or "(no ext)"
        if file_path.name in {"Dockerfile", "Makefile"}:
            suffix = file_path.name
        counts[suffix] += 1
    return dict(counts.most_common(30))


def _collect_key_files(repo_root: Path, char_limit: int) -> dict[str, str]:
    key_files: dict[str, str] = {}
    paths: list[Path] = []
    for name in _KEY_FILES:
        path = repo_root / name
        if path.is_file():
            paths.append(path)
    for pattern in _KEY_GLOBS:
        paths.extend(sorted(repo_root.glob(pattern))[:20])

    for path in paths:
        rel = path.relative_to(repo_root).as_posix()
        if rel in key_files:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        key_files[rel] = text[:char_limit]
    return key_files


def _git_activity(repo_root: Path) -> str:
    try:
        result = subprocess.run(
            [
                "git",
                "-C",
                str(repo_root),
                "log",
                "--oneline",
                "--since=60 days ago",
                "--stat",
                "--max-count=30",
            ],
            capture_output=True,
            text=False,
            timeout=30,
        )
    except Exception:
        return ""

    stdout = result.stdout or b""
    if isinstance(stdout, bytes):
        return stdout.decode("utf-8", errors="replace")[:5000]
    return stdout[:5000]
