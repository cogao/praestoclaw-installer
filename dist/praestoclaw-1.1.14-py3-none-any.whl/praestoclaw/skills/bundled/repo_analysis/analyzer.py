"""
analyzer.py — Core analysis engine for the repo-analysis skill.

Architecture
------------
- FullAnalyzer     : Three-layer full analysis (Layer 1 structure → Layer 2
                     interface → Layer 3 implementation).
- IncrementalUpdater: Detect changed files since last_commit, re-analyse only
                     the affected modules.
- OnDemandDeepener : Answer ad-hoc user questions by deep-reading specific
                     source files on demand, and write-back knowledge to kb/.

All LLM calls are routed through a caller-supplied ``LLMCaller`` async callable
so the engine stays decoupled from any specific provider SDK.  The caller is
responsible for wiring this to the active LLM session — do NOT instantiate a
provider inside this module.  The ``__main__`` CLI entry point at the bottom
of this file is the only place that creates a provider (via
``praestoclaw.config.load_config`` + ``praestoclaw.providers.resolver.get_provider``)
and wraps it as a ``LLMCaller`` for standalone invocation.

Concurrency
-----------
A shared asyncio.Semaphore (default ``AnalysisConfig.max_concurrency=20``) gates
every LLM call. Retry logic applies exponential back-off with jitter on
rate-limit / timeout errors (see _llm_call_with_retry).
"""

from __future__ import annotations

import asyncio
import json
import logging
import math
import os
import random
import re
import shutil
import subprocess
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, cast

from .collector import RepoFacts, collect_repo_facts
from .templates import (
    AUDIENCE_DOCS,
    CHANGE_HISTORY_ENTRY_TEMPLATE,
    CODE_INDEX_TEMPLATE,
    DATA_TEMPLATE,
    DEFAULT_CONFIG,
    DESIGNER_TEMPLATE,
    DEVELOPER_TEMPLATE,
    MARKETING_TEMPLATE,
    PLACEHOLDER_TEMPLATE,
    PM_TEMPLATE,
    QA_CACHE_ENTRY_TEMPLATE,
    QA_CACHE_TEMPLATE,
    README_TEMPLATE,
    SECURITY_AUDIT_TEMPLATE,
    SRE_TEMPLATE,
    TEAM_LEAD_TEMPLATE,
    TESTER_TEMPLATE,
    render_template,
    state_to_json,
)

logger = logging.getLogger(__name__)

_ALL_AUDIENCES = tuple(AUDIENCE_DOCS.keys())

_AUDIENCE_SCHEMAS: dict[str, str] = {
    "pm": (
        '  "pm": {\n'
        '    "user_value": "...",\n'
        '    "product_behavior": "...",\n'
        '    "key_flows": ["..."],\n'
        '    "metrics": ["..."],\n'
        '    "open_questions": ["..."]\n'
        "  }"
    ),
    "developer": (
        '  "developer": {\n'
        '    "entry_points": ["path:function"],\n'
        '    "implementation": "...",\n'
        '    "dependencies": ["..."],\n'
        '    "extension_points": ["..."],\n'
        '    "risks": ["..."]\n'
        "  }"
    ),
    "tester": (
        '  "tester": {\n'
        '    "test_scope": "...",\n'
        '    "critical_scenarios": ["..."],\n'
        '    "test_data": ["..."],\n'
        '    "regression_risks": ["..."],\n'
        '    "gaps": ["..."]\n'
        "  }"
    ),
    "team_lead": (
        '  "team_lead": {\n'
        '    "ownership": "...",\n'
        '    "complexity": "...",\n'
        '    "delivery_risks": ["..."],\n'
        '    "cross_team_dependencies": ["..."],\n'
        '    "recommended_actions": ["..."],\n'
        '    "change_history": "..."\n'
        "  }"
    ),
    "designer": (
        '  "designer": {\n'
        '    "user_journey": "...",\n'
        '    "key_surfaces": ["..."],\n'
        '    "design_system": "...",\n'
        '    "accessibility": ["..."],\n'
        '    "design_debt": ["..."]\n'
        "  }"
    ),
    "security": (
        '  "security": {\n'
        '    "sensitive_data": ["..."],\n'
        '    "authn_authz": ["..."],\n'
        '    "external_dependencies": ["..."],\n'
        '    "compliance_requirements": ["..."],\n'
        '    "remediation_priorities": ["..."]\n'
        "  }"
    ),
    "data": (
        '  "data": {\n'
        '    "data_flows": ["..."],\n'
        '    "telemetry_events": ["..."],\n'
        '    "metric_definitions": ["..."],\n'
        '    "data_contracts": ["..."],\n'
        '    "analytics_gaps": ["..."]\n'
        "  }"
    ),
    "marketing": (
        '  "marketing": {\n'
        '    "target_users": ["..."],\n'
        '    "value_props": ["..."],\n'
        '    "differentiators": ["..."],\n'
        '    "launch_assets": ["..."],\n'
        '    "gtm_risks": ["..."]\n'
        "  }"
    ),
    "sre": (
        '  "sre": {\n'
        '    "deployment_topology": "...",\n'
        '    "observability": ["..."],\n'
        '    "slo_targets": ["..."],\n'
        '    "failure_domains": ["..."],\n'
        '    "runbooks": ["..."]\n'
        "  }"
    ),
}

# ---------------------------------------------------------------------------
# Type alias kept for backwards compatibility (deprecated)
# ---------------------------------------------------------------------------

#: Async callable: (system_prompt: str, user_content: str) -> str
#: Callers must supply this — the analyzers never create their own provider.
LLMCaller = Callable[[str, str], Awaitable[str]]


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class RateLimitError(Exception):
    """Raised when the LLM provider signals a rate limit (HTTP 429)."""

    def __init__(self, message: str = "", retry_after: float | None = None) -> None:
        super().__init__(message)
        self.retry_after = retry_after  # seconds, from Retry-After header


class AnalysisError(Exception):
    """General analysis failure (non-recoverable after retries)."""


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class ModuleInfo:
    """Metadata for a single detected module."""

    name: str
    paths: list[str]
    description: str = ""
    module_type: str = "feature"  # feature|service|lib|config|infra|test
    doc_path: str = ""  # Relative path within kb/
    audience_focus: dict[str, str] = field(default_factory=dict)


@dataclass
class AnalysisConfig:
    """Runtime configuration for the analyzer (mirrors kb/.config.json)."""

    max_concurrency: int = 20
    retry_max_attempts: int = 3
    retry_base_delay_ms: int = 2000
    layer2_batch_size: int = 20
    layer2_file_char_limit: int = 4000
    layer3_file_char_limit: int = 4000
    skip_patterns: list[str] = field(default_factory=lambda: list(DEFAULT_CONFIG["skip_patterns"]))
    large_repo_module_limit: int = 50

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> AnalysisConfig:
        # User-supplied kb/.config.json is untrusted; coerce skip_patterns to a
        # list[str] (falling back to defaults) so a `null` or wrong-type value
        # doesn't blow up _should_skip at runtime.
        raw_patterns = d.get("skip_patterns")
        if isinstance(raw_patterns, list):
            skip_patterns = [str(p) for p in raw_patterns]
        else:
            skip_patterns = list(DEFAULT_CONFIG["skip_patterns"])

        def _pos_int(key: str, default: int, minimum: int = 1) -> int:
            # Untrusted JSON may give us str / float / null / negative; clamp
            # to a sane positive int so e.g. asyncio.Semaphore(max_concurrency)
            # doesn't raise ValueError at construction.
            raw = d.get(key, default)
            try:
                value = int(raw)
            except (TypeError, ValueError):
                return default
            return value if value >= minimum else minimum

        return cls(
            max_concurrency=_pos_int("max_concurrency", 20),
            retry_max_attempts=_pos_int("retry_max_attempts", 3),
            retry_base_delay_ms=_pos_int("retry_base_delay_ms", 2000, minimum=0),
            layer2_batch_size=_pos_int("layer2_batch_size", 20),
            layer2_file_char_limit=_pos_int("layer2_file_char_limit", 4000),
            layer3_file_char_limit=_pos_int("layer3_file_char_limit", 4000),
            skip_patterns=skip_patterns,
            large_repo_module_limit=_pos_int("large_repo_module_limit", 50),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "max_concurrency": self.max_concurrency,
            "retry_max_attempts": self.retry_max_attempts,
            "retry_base_delay_ms": self.retry_base_delay_ms,
            "layer2_batch_size": self.layer2_batch_size,
            "layer2_file_char_limit": self.layer2_file_char_limit,
            "layer3_file_char_limit": self.layer3_file_char_limit,
            "skip_patterns": self.skip_patterns,
            "large_repo_module_limit": self.large_repo_module_limit,
        }


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


# --- Windows-safe directory name helper ---
# Characters illegal in Windows file/directory names.
_ILLEGAL_PATH_CHARS = re.compile(r'[<>:"/\\|?*]')
# Reserved device names on Windows: mkdir() fails for these even with an
# extension (e.g. CON.txt) and even with admin privileges.
_WINDOWS_RESERVED_NAMES = (
    {"CON", "PRN", "AUX", "NUL"}
    | {f"COM{i}" for i in range(1, 10)}
    | {f"LPT{i}" for i in range(1, 10)}
)


def _safe_dir_name(name: str) -> str:
    """Sanitize a module name so it is safe as a Windows directory component.

    Replaces characters that are illegal in Windows paths (``<>:"/\\|?*``) with
    ``_``, collapses runs of whitespace/underscore into ``_`` (spaces in the
    URL portion of generated Markdown links would otherwise be parsed as a
    title separator), and strips leading/trailing dots/underscores. Windows
    reserved device names (CON/PRN/AUX/NUL/COM1…/LPT1…) are also rejected
    even when followed by an extension — mkdir on those names fails on
    Windows even with admin privileges — by appending a ``_`` suffix.
    """
    safe = _ILLEGAL_PATH_CHARS.sub("_", name)
    safe = re.sub(r"[\s_]+", "_", safe).strip("._")
    if not safe:
        return "unnamed"
    stem = safe.split(".", 1)[0].upper()
    if stem in _WINDOWS_RESERVED_NAMES:
        safe = f"{safe}_"
    return safe


def _git_head_sha(repo_root: Path) -> str | None:
    """Return HEAD commit SHA or None if git is unavailable."""
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_root), "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            check=True,
            timeout=10,
        )
        return result.stdout.strip()
    except Exception:
        return None


def _git_diff_files(repo_root: Path, from_sha: str) -> list[str]:
    """Return list of changed files between *from_sha* and HEAD."""
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_root), "diff", f"{from_sha}..HEAD", "--name-only"],
            capture_output=True,
            text=True,
            check=True,
            timeout=30,
        )
        return [f for f in result.stdout.splitlines() if f.strip()]
    except Exception:
        return []


def _pid_is_running(pid: int) -> bool:
    """Return True if *pid* appears to be alive on the current platform."""
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            result = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
                capture_output=True,
                text=True,
                timeout=5,
            )
        except Exception:
            return True
        # tasklist /NH /FO CSV emits rows like
        #   "python.exe","12345","Console","1","45,678 K"
        # Match the quoted PID column to avoid substring collisions
        # (pid 12 matching 1200, or hits in memory/session columns).
        for line in result.stdout.splitlines():
            parts = [p.strip().strip('"') for p in line.split(",")]
            if len(parts) >= 2 and parts[1] == str(pid):
                return True
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _read_json_file(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


class AnalysisRunLock:
    """Atomic lock file guarding one full analysis per KB directory."""

    def __init__(self, kb_path: Path, repo_root: Path, run_id: str | None = None) -> None:
        self.kb_path = Path(kb_path)
        self.repo_root = Path(repo_root)
        self.path = self.kb_path / ".run.lock"
        self.run_id = run_id or f"{datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}-{os.getpid()}"

    def acquire(self) -> None:
        self.kb_path.mkdir(parents=True, exist_ok=True)
        payload = {
            "run_id": self.run_id,
            "pid": os.getpid(),
            "repo_root": str(self.repo_root),
            "kb_path": str(self.kb_path),
            "started_at": _now_iso(),
        }
        encoded = (json.dumps(payload, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
        for attempt in range(2):
            try:
                fd = os.open(str(self.path), os.O_WRONLY | os.O_CREAT | os.O_EXCL)
            except FileExistsError:
                existing = _read_json_file(self.path)
                pid = int(existing.get("pid") or 0)
                if attempt == 0 and pid and not _pid_is_running(pid):
                    self.path.unlink(missing_ok=True)
                    continue
                raise AnalysisError(
                    "Repo analysis is already running for this KB path: "
                    f"{self.kb_path} (pid={pid or 'unknown'}, "
                    f"run_id={existing.get('run_id', 'unknown')})"
                ) from None
            with os.fdopen(fd, "wb") as handle:
                handle.write(encoded)
            return

    def release(self) -> None:
        existing = _read_json_file(self.path)
        if existing.get("run_id") == self.run_id:
            self.path.unlink(missing_ok=True)


def _should_skip(path_str: str, skip_patterns: list[str]) -> bool:
    """Return True if *path_str* matches any skip pattern.

    Skip patterns use POSIX separators (e.g. ``node_modules/``). Callers
    sometimes pass paths built via ``str(Path.relative_to(...))`` which on
    Windows produces backslashes; normalise both sides to forward slashes
    so patterns like ``.git/`` and ``node_modules/`` still match on
    Windows.
    """
    import fnmatch

    normalised = path_str.replace("\\", "/")
    for pat in skip_patterns:
        normalised_pat = pat.replace("\\", "/")
        if fnmatch.fnmatch(normalised, f"*{normalised_pat}*") or normalised.startswith(
            normalised_pat
        ):
            return True
    return False


def _collect_files(repo_root: Path, skip_patterns: list[str]) -> list[Path]:
    """Collect all non-skipped files under *repo_root*."""
    files: list[Path] = []
    for p in sorted(repo_root.rglob("*")):
        if not p.is_file():
            continue
        rel = str(p.relative_to(repo_root))
        if _should_skip(rel, skip_patterns):
            continue
        files.append(p)
    return files


def _read_head(path: Path, max_lines: int = 100, max_chars: int = 12000) -> str:
    """Read a bounded prefix of a file.

    Both line count and character count are enforced because some generated
    files store megabytes of JSON or JavaScript on a single line.
    """
    try:
        lines = []
        chars_read = 0
        with path.open(encoding="utf-8", errors="replace") as fh:
            for i, line in enumerate(fh):
                if i >= max_lines:
                    break
                remaining = max_chars - chars_read
                if remaining <= 0:
                    break
                if len(line) > remaining:
                    lines.append(line[:remaining])
                    break
                lines.append(line)
                chars_read += len(line)
        return "".join(lines)
    except OSError:
        return ""


# Per-language skeleton extractors. Each entry maps a file suffix to a list of
# compiled regexes matched against full lines. A line is kept if any pattern
# matches. The goal is to retain imports / exports / top-level declarations /
# public method signatures while dropping bodies and noise.
_SKELETON_PATTERNS: dict[str, list[re.Pattern[str]]] = {
    ".py": [
        re.compile(r"^\s*(import|from)\s+\S"),
        re.compile(r"^\s*(async\s+)?def\s+\w"),
        re.compile(r"^\s*class\s+\w"),
        re.compile(r"^\s*@\w"),
        re.compile(r"^\s*[A-Z_][A-Z0-9_]*\s*[:=]"),  # module-level constants
    ],
    ".ts": [
        re.compile(r"^\s*(import|export)\s"),
        re.compile(
            r"^\s*export\s+(default\s+)?(async\s+)?(function|class|interface|type|enum|const|let|var|abstract)\s"
        ),
        re.compile(r"^\s*(public|protected|private|static|async|readonly)\s"),
        re.compile(r"^\s*(class|interface|type|enum|namespace|abstract\s+class)\s+\w"),
        re.compile(r"^\s*(function|const|let|var)\s+\w"),
        re.compile(r"^\s*@\w"),
    ],
    ".tsx": None,  # populated below
    ".js": None,
    ".jsx": None,
    ".mjs": None,
    ".cs": [
        re.compile(r"^\s*using\s+\S"),
        re.compile(r"^\s*namespace\s+\S"),
        re.compile(r"^\s*\[\w"),  # attributes
        re.compile(
            r"^\s*(public|internal|protected|private|static|abstract|sealed|virtual|override|async|partial|readonly)\s+\S"
        ),
        re.compile(r"^\s*(class|interface|record|struct|enum|delegate)\s+\w"),
    ],
    ".go": [
        re.compile(r"^\s*(package|import)\s"),
        re.compile(r"^\s*(func|type|var|const)\s+\w"),
        re.compile(r"^\s*\}?\s*//\s*\+build"),
    ],
    ".java": [
        re.compile(r"^\s*(package|import)\s+\S"),
        re.compile(r"^\s*@\w"),
        re.compile(r"^\s*(public|protected|private|static|abstract|final|synchronized)\s+\S"),
        re.compile(r"^\s*(class|interface|enum|record)\s+\w"),
    ],
    ".rs": [
        re.compile(r"^\s*(use|mod|extern|pub)\s"),
        re.compile(r"^\s*(pub\s+)?(async\s+)?fn\s+\w"),
        re.compile(r"^\s*(pub\s+)?(struct|enum|trait|impl|type|const|static)\s+\w"),
        re.compile(r"^\s*#\["),
    ],
}
# JS-family share the TS patterns.
for _suffix in (".tsx", ".js", ".jsx", ".mjs"):
    _SKELETON_PATTERNS[_suffix] = _SKELETON_PATTERNS[".ts"]

_SKELETON_MAX_BYTES = 200_000  # never read more than 200KB for skeleton extraction


def _read_skeleton(path: Path, max_chars: int = 4000) -> str:
    """Return a code "skeleton" emphasizing imports, exports, and signatures.

    Falls back to ``_read_head`` for unsupported languages or empty results.
    """
    patterns = _SKELETON_PATTERNS.get(path.suffix.lower())
    if patterns is None:
        return _read_head(path, max_lines=100, max_chars=max_chars)

    try:
        with path.open(encoding="utf-8", errors="replace") as fh:
            raw = fh.read(_SKELETON_MAX_BYTES)
    except OSError:
        return ""

    if not raw.strip():
        return ""

    kept: list[str] = []
    chars = 0
    truncated = False
    for line in raw.splitlines(keepends=True):
        # Always keep the file's leading docstring/comment header (first ~10 lines)
        # if it looks like a comment, to preserve module-level intent.
        stripped = line.lstrip()
        is_comment_header = len(kept) < 10 and (
            stripped.startswith("#")
            or stripped.startswith("//")
            or stripped.startswith("/*")
            or stripped.startswith("*")
            or stripped.startswith('"""')
            or stripped.startswith("'''")
        )
        if is_comment_header or any(p.match(line) for p in patterns):
            if chars + len(line) > max_chars:
                truncated = True
                break
            kept.append(line)
            chars += len(line)

    if not kept:
        # No patterns matched (e.g. data file with .py suffix). Fall back to head.
        return _read_head(path, max_lines=100, max_chars=max_chars)
    if truncated:
        kept.append("… (skeleton truncated)\n")
    return "".join(kept)


def _chunks(lst: list[Any], n: int) -> list[list[Any]]:
    """Split *lst* into sublists of at most *n* items."""
    return [lst[i : i + n] for i in range(0, len(lst), n)]


def _norm_path(path: str) -> str:
    return path.replace("\\", "/").strip("/")


def _build_path_to_module_lookup(
    module_map: list[ModuleInfo],
) -> list[tuple[str, str]]:
    """Return (prefix, module_name) pairs sorted by prefix length (desc).

    Longest-prefix wins when multiple modules claim overlapping paths.
    """
    pairs: list[tuple[str, str]] = []
    for m in module_map:
        for p in m.paths:
            prefix = _norm_path(p)
            if prefix:
                pairs.append((prefix, m.name))
    pairs.sort(key=lambda x: len(x[0]), reverse=True)
    return pairs


def _lookup_module(path: str, lookup: list[tuple[str, str]]) -> str | None:
    norm = _norm_path(path)
    if not norm:
        return None
    for prefix, name in lookup:
        if norm == prefix or norm.startswith(prefix + "/"):
            return name
    return None


def _is_test_path(path: str) -> bool:
    return any(
        marker in path
        for marker in (
            "tests/",
            "test/",
            "spec/",
            "__tests__/",
            "test_",
            "_test.",
            ".test.",
            ".spec.",
        )
    )


def _is_doc_path(path: str) -> bool:
    return path.endswith((".md", ".rst", ".txt")) or any(
        marker in path for marker in ("readme", "docs/", "changelog", "contributing")
    )


def _is_product_surface_path(path: str) -> bool:
    return any(
        marker in path
        for marker in (
            "cli/",
            "web/",
            "channels/",
            "templates/",
            "routes/",
            "endpoints/",
            "ui/",
            "components/",
        )
    )


def _is_config_or_infra_path(path: str) -> bool:
    return any(
        marker in path
        for marker in (
            ".github/",
            "dockerfile",
            "docker-compose",
            "pyproject.toml",
            "package.json",
            "requirements",
            "config/",
            "terraform/",
            "k8s/",
            "azure-pipelines",
        )
    )


def _is_source_suffix(suffix: str) -> bool:
    return suffix in {
        ".py",
        ".js",
        ".ts",
        ".tsx",
        ".jsx",
        ".go",
        ".rs",
        ".java",
        ".cs",
        ".rb",
        ".php",
        ".sh",
    }


# ---------------------------------------------------------------------------
# Retry wrapper
# ---------------------------------------------------------------------------


async def _llm_call_with_retry(
    llm: LLMCaller,
    system_prompt: str,
    user_content: str,
    config: AnalysisConfig,
) -> str:
    """Call *llm* with automatic retry on rate-limit / timeout errors.

    Implements: exponential back-off (2**attempt * base_delay) + ±20% jitter.
    Respects the ``retry_after`` attribute on RateLimitError when present.
    """
    max_attempts = config.retry_max_attempts
    base_delay_s = config.retry_base_delay_ms / 1000.0

    for attempt in range(max_attempts):
        try:
            return await llm(system_prompt, user_content)

        except RateLimitError as exc:
            if attempt == max_attempts - 1:
                raise
            delay = base_delay_s * (2**attempt)
            jitter = random.SystemRandom().uniform(0, delay * 0.2)
            wait = delay + jitter
            if exc.retry_after:
                wait = max(wait, exc.retry_after)
            logger.warning(
                "Rate limit (attempt %d/%d), waiting %.1fs…",
                attempt + 1,
                max_attempts,
                wait,
            )
            await asyncio.sleep(wait)

        except TimeoutError:
            if attempt == max_attempts - 1:
                raise
            wait = base_delay_s * (2**attempt)
            logger.warning("LLM timeout (attempt %d/%d), retrying…", attempt + 1, max_attempts)
            await asyncio.sleep(wait)

    # Should not be reached
    raise AnalysisError("Unexpected exit from retry loop")


# ---------------------------------------------------------------------------
# FullAnalyzer
# ---------------------------------------------------------------------------


class FullAnalyzer:
    """Three-layer full analysis of a code repository.

    Layers
    ------
    1. Structure (serial)   — discover module boundaries via LLM
    2. Interface (parallel) — extract import lists and exported symbols
    3. Implementation (parallel) — deep-analyse each module

    All parallel layers share a single ``asyncio.Semaphore`` sized by
    ``AnalysisConfig.max_concurrency`` (default 20) for backpressure.
    Finalise — write kb/README.md, code_index.md, .state.json
    """

    def __init__(
        self,
        repo_root: Path,
        kb_path: Path,
        llm: LLMCaller | None = None,
        config: AnalysisConfig | None = None,
        resume: bool = False,
    ) -> None:
        self.repo_root = Path(repo_root)
        self.kb_path = Path(kb_path)
        if llm is None:
            raise ValueError(
                "FullAnalyzer requires an 'llm' LLMCaller.  "
                "Pass the active session's LLM callable instead of letting the "
                "skill create its own provider."
            )
        self.llm = llm
        self.config = config or AnalysisConfig()
        self._semaphore = asyncio.Semaphore(self.config.max_concurrency)
        self._warnings: list[str] = []
        self._run_id = ""
        self.resume = resume

    # ------------------------------------------------------------------
    # Entry point
    # ------------------------------------------------------------------

    async def run(self) -> dict[str, Any]:
        """Execute the full three-layer analysis.

        Returns:
            Summary dict with module_count, doc_count, warnings, etc.
        """
        resume_checkpoint = self._load_resume_checkpoint() if self.resume else {}
        checkpoint_run_id = str(resume_checkpoint.get("run_id") or "") or None
        run_lock = AnalysisRunLock(self.kb_path, self.repo_root, run_id=checkpoint_run_id)
        run_lock.acquire()
        self._run_id = run_lock.run_id
        start = asyncio.get_running_loop().time()
        self._write_progress("starting", "running")

        try:
            if (
                resume_checkpoint.get("stage") == "completed"
                and (self.kb_path / ".state.json").exists()
            ):
                result: dict[str, Any] = {
                    "status": "already_completed",
                    "run_id": self._run_id,
                    "message": "checkpoint 已完成，无需继续",
                }
                self._write_progress("completed", "completed", **result)
                return result

            if resume_checkpoint:
                self._write_progress(
                    "resuming",
                    "running",
                    checkpoint_stage=resume_checkpoint.get("stage"),
                    completed_modules=len(resume_checkpoint.get("completed_modules", [])),
                )
            else:
                self._prepare_full_analysis_output()

            # ── Layer 1 ──────────────────────────────────────────────────
            logger.info("[全量分析] Layer 1/3：识别模块结构…")
            self._write_progress("collecting_facts", "running")
            repo_facts = collect_repo_facts(self.repo_root, self.config.skip_patterns)
            all_files = repo_facts.files
            large_repo = repo_facts.large_repo

            module_map = self._modules_from_checkpoint(resume_checkpoint)
            if module_map:
                logger.info("[全量分析] 从 checkpoint 恢复模块结构：%d 个模块", len(module_map))
                self._write_progress(
                    "layer1", "completed", module_count=len(module_map), resumed=True
                )
            else:
                self._write_progress(
                    "layer1",
                    "running",
                    total_files=len(all_files),
                    large_repo=large_repo,
                )
                module_map = await self._layer1_discover_modules(all_files, large_repo, repo_facts)
                logger.info("[全量分析] Layer 1/3 完成：发现 %d 个模块", len(module_map))
                self._write_checkpoint("layer1_completed", module_map)
                self._write_progress("layer1", "completed", module_count=len(module_map))

            # ── Layer 2 ──────────────────────────────────────────────────
            code_index_draft = resume_checkpoint.get("code_index_draft")
            resumed_partial_l2 = resume_checkpoint.get("stage") == "layer2_running" and isinstance(
                code_index_draft, dict
            )
            if isinstance(code_index_draft, dict) and not resumed_partial_l2:
                logger.info("[全量分析] 从 checkpoint 恢复 Layer 2 code index draft")
                self._write_progress("layer2", "completed", resumed=True)
            else:
                if resumed_partial_l2:
                    logger.info(
                        "[全量分析] Layer 2/3：从 checkpoint 续跑 (已扫描 %d 个文件)…",
                        len(code_index_draft.get("modules", {}))
                        if isinstance(code_index_draft, dict)
                        else 0,
                    )
                else:
                    logger.info("[全量分析] Layer 2/3：扫描接口层…")
                self._write_progress("layer2", "running")
                code_index_draft = await self._layer2_extract_interfaces(
                    all_files,
                    large_repo,
                    module_map=module_map,
                    partial_code_index=code_index_draft if resumed_partial_l2 else None,
                )
                logger.info("[全量分析] Layer 2/3 完成")
                self._write_checkpoint(
                    "layer2_completed", module_map, code_index_draft=code_index_draft
                )
                try:
                    self._write_code_index(code_index_draft, module_map, _now_iso())
                except Exception as exc:
                    logger.warning("[全量分析] code_index 写入失败（忽略，继续 Layer 3）：%s", exc)
                self._write_progress("layer2", "completed")

            # ── Layer 3 ──────────────────────────────────────────────────
            logger.info("[全量分析] Layer 3/3：深度分析模块…")
            existing_results = self._analyzed_modules_from_checkpoint(resume_checkpoint)
            completed_modules = {
                name
                for name in resume_checkpoint.get("completed_modules", [])
                if isinstance(name, str) and name in existing_results
            }
            self._write_progress(
                "layer3",
                "running",
                total_modules=len(module_map),
                completed_modules=len(completed_modules),
                resumed=bool(completed_modules),
            )
            analyzed_modules = await self._layer3_analyze_modules(
                module_map,
                write_module_docs=True,
                skip_completed_modules=completed_modules,
                existing_results=existing_results,
                code_index_draft=code_index_draft,
            )
            logger.info("[全量分析] Layer 3/3 完成")
            self._write_checkpoint(
                "layer3_completed",
                module_map,
                completed_modules=sorted(analyzed_modules),
                analyzed_modules=analyzed_modules,
                code_index_draft=code_index_draft,
            )
            self._write_progress("layer3", "completed", completed_modules=len(module_map))

            # ── Finalise ─────────────────────────────────────────────────
            self._write_progress("finalising", "running")
            await self._finalise(
                module_map,
                analyzed_modules,
                code_index_draft,
                repo_facts,
                write_module_docs=False,
            )

            elapsed = asyncio.get_running_loop().time() - start
            summary_result: dict[str, Any] = {
                "module_count": len(module_map),
                "doc_count": len(module_map) * len(AUDIENCE_DOCS) + 3,
                "elapsed_seconds": elapsed,
                "warnings": self._warnings,
                "run_id": self._run_id,
            }
            self._write_progress("completed", "completed", **summary_result)
            return summary_result
        except Exception as exc:
            self._write_progress("failed", "failed", error=str(exc))
            raise
        finally:
            run_lock.release()

    # ------------------------------------------------------------------
    # Layer 1: Structure discovery
    # ------------------------------------------------------------------

    async def _layer1_discover_modules(
        self,
        all_files: list[Path],
        large_repo: bool,
        repo_facts: RepoFacts | None = None,
    ) -> list[ModuleInfo]:
        """Identify module boundaries from the directory tree."""
        if repo_facts is not None:
            tree_str = repo_facts.tree_for_prompt()
            fact_summary = repo_facts.prompt_summary()
        else:
            tree_str = (
                self._build_dir_tree_compact(all_files)
                if large_repo
                else self._build_dir_tree(all_files)
            )
            fact_summary = "未提供仓库事实摘要"

        system = (
            "你是一个代码仓库分析助手。"
            "给定目录树，识别出独立功能模块，并说明不同角色为什么需要理解这些模块。"
        )
        audience_keys = ", ".join(AUDIENCE_DOCS.keys())
        user = (
            f"给定以下目录结构，识别出独立功能模块。\n"
            f"每个模块是一个目录或一组密切相关的目录。\n"
            f"输出严格的 JSON 数组，每项包含字段：name, paths(数组), description, type, audience_focus。\n"
            f"type 可选值：feature | service | lib | config | infra | test\n\n"
            f"audience_focus 是对象，必须包含这 {len(AUDIENCE_DOCS)} 个键：{audience_keys}，"
            "分别用一句话说明该角色为什么关心这个模块。"
            "如果某角色对该模块没有特殊关注点，留空字符串。\n\n"
            f"仓库事实摘要：\n{fact_summary}\n\n"
            f"目录结构：\n{tree_str}"
        )

        raw = await _llm_call_with_retry(self.llm, system, user, self.config)
        modules = self._parse_module_map(raw)

        if not modules:
            self._warn("Layer 1: LLM 未能识别模块，降级为按顶层目录分模块")
            modules = self._fallback_modules(all_files)

        # Enforce large_repo limit
        if large_repo and len(modules) > self.config.large_repo_module_limit:
            modules = self._merge_small_modules(modules, self.config.large_repo_module_limit)

        # Assign doc paths (sanitize to match on-disk dir created via _safe_dir_name)
        for m in modules:
            m.doc_path = f"modules/{_safe_dir_name(m.name)}/"

        return modules

    def _build_dir_tree(self, files: list[Path]) -> str:
        dirs: set[str] = set()
        for f in files:
            rel = str(f.relative_to(self.repo_root))
            parts = Path(rel).parts
            for i in range(1, len(parts)):
                dirs.add("/".join(parts[:i]))
        lines = sorted(dirs)[:300]  # cap at 300 dirs
        return "\n".join(lines)

    def _build_dir_tree_compact(self, files: list[Path]) -> str:
        """Compact tree: only top-3 directory levels."""
        dirs: set[str] = set()
        for f in files:
            rel = str(f.relative_to(self.repo_root))
            parts = Path(rel).parts
            for i in range(1, min(len(parts), 4)):
                dirs.add("/".join(parts[:i]))
        return "\n".join(sorted(dirs))

    def _parse_module_map(self, raw: str) -> list[ModuleInfo]:
        """Parse LLM JSON output into ModuleInfo list."""
        try:
            # Extract JSON array from possibly surrounding text
            start = raw.find("[")
            end = raw.rfind("]") + 1
            if start == -1 or end == 0:
                return []
            data = json.loads(raw[start:end])
            modules = []
            for item in data:
                if not isinstance(item, dict):
                    continue
                name = item.get("name", "unknown")
                paths = item.get("paths", [])
                if not isinstance(paths, list):
                    paths = [str(paths)]
                modules.append(
                    ModuleInfo(
                        name=str(name),
                        paths=[str(p) for p in paths],
                        description=str(item.get("description", "")),
                        module_type=str(item.get("type", "feature")),
                        audience_focus=self._normalize_audience_map(item.get("audience_focus", {})),
                    )
                )
            return modules
        except (json.JSONDecodeError, TypeError, KeyError):
            return []

    def _fallback_modules(self, files: list[Path]) -> list[ModuleInfo]:
        """Create one module per top-level directory."""
        top_dirs: set[str] = set()
        for f in files:
            rel = f.relative_to(self.repo_root)
            top_dirs.add(rel.parts[0] if len(rel.parts) > 1 else "_root")
        return [
            ModuleInfo(name=d, paths=[d + "/"], description="", module_type="feature")
            for d in sorted(top_dirs)
        ]

    @staticmethod
    def _normalize_audience_map(value: Any) -> dict[str, str]:
        if not isinstance(value, dict):
            value = {}
        return {audience: str(value.get(audience, "")).strip() for audience in AUDIENCE_DOCS}

    @staticmethod
    def _merge_small_modules(modules: list[ModuleInfo], limit: int) -> list[ModuleInfo]:
        """Merge modules with fewest paths until count ≤ limit."""
        while len(modules) > limit:
            # Find the two smallest and merge them
            modules.sort(key=lambda m: len(m.paths))
            a, b = modules[0], modules[1]
            # Preserve per-audience focus hints so Layer 3 prompts and the
            # README still describe why each audience cares about the merged
            # area; otherwise the merged module loses all role-specific
            # context Layer 1 produced.
            merged_focus: dict[str, str] = {}
            for key in set(a.audience_focus) | set(b.audience_focus):
                parts = [
                    p.strip()
                    for p in (a.audience_focus.get(key, ""), b.audience_focus.get(key, ""))
                    if p and p.strip()
                ]
                merged_focus[key] = "; ".join(parts)
            merged = ModuleInfo(
                name=f"{a.name}_{b.name}",
                paths=a.paths + b.paths,
                description=f"{a.description}; {b.description}",
                module_type=a.module_type,
                audience_focus=merged_focus,
            )
            modules = [merged] + modules[2:]
        return modules

    # ------------------------------------------------------------------
    # Layer 2: Interface extraction
    # ------------------------------------------------------------------

    async def _layer2_extract_interfaces(
        self,
        all_files: list[Path],
        large_repo: bool,
        module_map: list[ModuleInfo] | None = None,
        partial_code_index: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Extract imports, exports, and entry points for all files.

        If ``partial_code_index`` is supplied, files already present in it are
        skipped (resume-after-crash). When ``module_map`` is supplied, a
        ``layer2_running`` checkpoint is written every 50 batches so a crash
        mid-L2 does not lose all progress.

        Returns a draft code index dict.
        """
        batch_size = self.config.layer2_batch_size
        if large_repo:
            batch_size = max(3, batch_size // 2)

        # Group files by directory
        dir_to_files: dict[Path, list[Path]] = {}
        for f in all_files:
            d = f.parent
            dir_to_files.setdefault(d, []).append(f)

        code_index: dict[str, Any] = {
            "product_entries": [],
            "modules": {},
        }
        if isinstance(partial_code_index, dict):
            for entry in partial_code_index.get("product_entries", []) or []:
                if isinstance(entry, dict):
                    code_index["product_entries"].append(entry)
            partial_modules = partial_code_index.get("modules", {}) or {}
            if isinstance(partial_modules, dict):
                for k, v in partial_modules.items():
                    if isinstance(k, str) and isinstance(v, dict):
                        code_index["modules"][k] = v
        already_seen: set[str] = set(code_index["modules"].keys())
        total_batches = sum(math.ceil(len(fs) / batch_size) for fs in dir_to_files.values())
        completed = 0

        async def process_batch(batch: list[Path]) -> None:
            nonlocal completed
            items = []
            for fp in batch:
                rel = str(fp.relative_to(self.repo_root))
                if rel in already_seen:
                    continue
                head = _read_skeleton(fp, self.config.layer2_file_char_limit)
                if not head.strip():
                    continue
                items.append({"path": rel, "content": head})

            if not items:
                completed += 1
                return

            system = (
                "你是代码分析助手，专注提取文件接口信息。输出严格 JSON 数组，与输入文件一一对应。"
            )
            user = (
                "以下是一批文件的内容（仅前100行），提取每个文件的：\n"
                "1. PM 需要知道的产品入口或用户行为（pm_surface）\n"
                "2. Developer 需要知道的导入、导出符号和代码职责（import_list, exports, purpose）\n"
                "3. Tester 需要知道的测试入口、关键场景或风险（tester_surface）\n"
                "4. Team Lead 需要知道的所有权、风险或跨团队依赖（leadership_signal）\n"
                "5. 是否为产品入口（is_entry: bool）\n"
                "输出 JSON 数组，与输入文件数量相同，每项含 path/import_list/exports/purpose/"
                "is_entry/pm_surface/tester_surface/leadership_signal。\n\n"
                f"文件列表：\n{json.dumps(items, ensure_ascii=False)}"
            )

            try:
                raw = await _llm_call_with_retry(self.llm, system, user, self.config)
                self._merge_code_index(code_index, raw, batch)
            except Exception as exc:
                self._warn(f"Layer 2 批次处理失败: {exc}")
            finally:
                completed += 1
                self._write_progress(
                    "layer2",
                    "running",
                    completed_batches=completed,
                    total_batches=total_batches,
                )
                if completed % 10 == 0 or completed == total_batches:
                    logger.info(
                        "[全量分析] Layer 2/3：扫描接口层 (%d/%d 批次)…",
                        completed,
                        total_batches,
                    )
                if module_map is not None and completed % 50 == 0 and completed < total_batches:
                    try:
                        self._write_checkpoint(
                            "layer2_running",
                            module_map,
                            code_index_draft=code_index,
                            layer2_completed_batches=completed,
                            layer2_total_batches=total_batches,
                        )
                    except Exception as exc:
                        self._warn(f"Layer 2 checkpoint 写入失败（忽略）：{exc}")

        # Bounded worker pool so a giant repo doesn't materialize thousands of
        # asyncio.Task objects up front; the semaphore only gates execution.
        queue: asyncio.Queue[list[Path]] = asyncio.Queue()
        for files_in_dir in dir_to_files.values():
            for batch in _chunks(files_in_dir, batch_size):
                queue.put_nowait(batch)

        async def worker() -> None:
            while True:
                try:
                    batch = queue.get_nowait()
                except asyncio.QueueEmpty:
                    return
                try:
                    await self._sem_wrap(process_batch, batch)
                finally:
                    queue.task_done()

        worker_count = max(1, min(self.config.max_concurrency, queue.qsize()))
        workers = [asyncio.create_task(worker()) for _ in range(worker_count)]
        await asyncio.gather(*workers)
        return code_index

    async def _sem_wrap(self, coro_fn: Callable[..., Awaitable[Any]], *args: Any) -> Any:
        async with self._semaphore:
            return await coro_fn(*args)

    def _merge_code_index(
        self,
        code_index: dict[str, Any],
        raw: str,
        batch: list[Path],
    ) -> None:
        try:
            start = raw.find("[")
            end = raw.rfind("]") + 1
            if start == -1 or end == 0:
                return
            data = json.loads(raw[start:end])
        except json.JSONDecodeError:
            return

        for item in data:
            if not isinstance(item, dict):
                continue
            path = item.get("path", "")
            # LLM is untrusted: skip entries where path isn't a non-empty
            # string. Otherwise non-string keys leak into
            # code_index["modules"] and break downstream lookups and JSON
            # serialization. Normalise whitespace + backslashes so
            # "src/a.py", " src/a.py", and "src\\a.py" collapse to one key.
            if not isinstance(path, str):
                continue
            path = path.strip().replace("\\", "/")
            if not path:
                continue
            if item.get("is_entry"):
                code_index["product_entries"].append(
                    {
                        "path": path,
                        "purpose": item.get("purpose", ""),
                        "pm_surface": item.get("pm_surface", ""),
                    }
                )
            code_index["modules"].setdefault(path, {}).update(
                {
                    "imports": item.get("import_list", []),
                    "exports": item.get("exports", []),
                    "purpose": item.get("purpose", ""),
                    "pm_surface": item.get("pm_surface", ""),
                    "tester_surface": item.get("tester_surface", ""),
                    "leadership_signal": item.get("leadership_signal", ""),
                }
            )

    # ------------------------------------------------------------------
    # Layer 3: Module implementation analysis
    # ------------------------------------------------------------------

    async def _layer3_analyze_modules(
        self,
        module_map: list[ModuleInfo],
        audiences: set[str] | None = None,
        focus_files_by_module: dict[str, list[str]] | None = None,
        write_module_docs: bool = False,
        skip_completed_modules: set[str] | None = None,
        existing_results: dict[str, dict[str, Any]] | None = None,
        code_index_draft: dict[str, Any] | None = None,
    ) -> dict[str, dict[str, Any]]:
        """Deep-analyse each module; return {module_name: analysis_result}."""
        results: dict[str, dict[str, Any]] = dict(existing_results or {})
        skip_completed_modules = skip_completed_modules or set()
        total = len(module_map)
        completed_count = len(skip_completed_modules)
        # Expose code_index_draft to _analyse_module → _select_core_files for
        # import-degree-based ranking. Cleared in `finally` below.
        self._current_code_index_draft = code_index_draft

        async def analyse_one(module: ModuleInfo) -> None:
            nonlocal completed_count
            if module.name in skip_completed_modules:
                self._write_progress(
                    "layer3",
                    "running",
                    completed_modules=completed_count,
                    total_modules=total,
                    current_module=module.name,
                    resumed=True,
                )
                return
            # NOTE: do NOT acquire the outer semaphore here. _analyse_module
            # fans out into 1+1+N LLM calls and each one acquires the
            # semaphore individually via self._sem_wrap. Holding the
            # semaphore around the whole module would serialise modules
            # and break parallelism.
            try:
                result = await self._analyse_module(
                    module,
                    audiences=audiences,
                    focus_files=(focus_files_by_module or {}).get(module.name),
                )
                results[module.name] = result
            except Exception as exc:
                self._warn(f"模块 {module.name} 分析失败: {exc}")
                results[module.name] = {"_error": str(exc)}
            finally:
                if write_module_docs:
                    module_dir = self.kb_path / "modules" / _safe_dir_name(module.name)
                    module_dir.mkdir(parents=True, exist_ok=True)
                    self._write_module_docs(
                        module,
                        results.get(module.name, {}),
                        module_dir,
                        _now_iso(),
                        audiences=audiences,
                    )
                completed_count += 1
                if write_module_docs:
                    self._write_checkpoint(
                        "layer3_running",
                        module_map,
                        completed_modules=sorted(results),
                        analyzed_modules=results,
                        code_index_draft=code_index_draft,
                    )
                self._write_progress(
                    "layer3",
                    "running",
                    completed_modules=completed_count,
                    total_modules=total,
                    current_module=module.name,
                )
                logger.info(
                    "[全量分析] Layer 3/3：深度分析模块 (%d/%d) %s",
                    completed_count,
                    total,
                    module.name,
                )

        pending_modules = [
            module for module in module_map if module.name not in skip_completed_modules
        ]
        try:
            await asyncio.gather(*[analyse_one(m) for m in pending_modules])
        finally:
            self._current_code_index_draft = None
        return results

    async def _analyse_module(
        self,
        module: ModuleInfo,
        audiences: set[str] | None = None,
        focus_files: list[str] | None = None,
    ) -> dict[str, Any]:
        """Three-step deep analysis:

        1. LLM picks the core files to read from the module's full inventory.
        2. One LLM call extracts a shared structured `facts` JSON from those files.
        3. Per-audience LLM calls in parallel render `facts` into each role's view.

        Each leaf LLM call is wrapped with the shared semaphore so concurrency
        stays bounded across all in-flight modules.
        """
        target_audiences = self._normalize_audience_set(audiences)
        code_index_draft = getattr(self, "_current_code_index_draft", None)

        # Step 1 - core file selection
        core_files = await self._pick_core_files_via_llm(
            module,
            focus_files=focus_files,
            code_index_draft=code_index_draft,
        )
        if not core_files:
            return {}

        content_parts: list[str] = []
        for fp in core_files:
            full_path = self.repo_root / fp
            if not full_path.exists():
                continue
            head = _read_skeleton(full_path, self.config.layer3_file_char_limit)
            if head.strip():
                content_parts.append(f"=== {fp} ===\n{head}")
        if not content_parts:
            return {}
        # Generous budget for the single facts pass (audience passes don't re-read code).
        code_blob = "\n\n".join(content_parts)[:24000]

        # Step 2 - extract shared facts (one call)
        facts = await self._sem_wrap(self._extract_module_facts, module, code_blob, core_files)
        if not isinstance(facts, dict) or not facts:
            self._warn(f"模块 {module.name} facts 抽取为空，跳过角色渲染")
            return {}

        # Step 3 - per-audience rendering in parallel
        async def render_one(aud: str) -> tuple[str, Any]:
            try:
                view = await self._sem_wrap(self._render_audience_view, module, facts, aud)
            except Exception as exc:
                self._warn(f"模块 {module.name} 角色 {aud} 渲染失败: {exc}")
                view = {}
            return aud, view

        rendered = await asyncio.gather(*(render_one(a) for a in target_audiences))
        merged: dict[str, Any] = {}
        for aud, view in rendered:
            if view:
                merged[aud] = view
        return merged

    # ------------------------------------------------------------------
    # Layer 3 helpers (core-file picking, facts extraction, audience render)
    # ------------------------------------------------------------------

    def _enumerate_module_files(self, module: ModuleInfo) -> list[str]:
        """All non-skipped files under module.paths, relative to repo root."""
        seen: set[str] = set()
        out: list[str] = []
        for module_path in module.paths:
            search_root = self.repo_root / module_path.rstrip("/")
            if not search_root.exists():
                continue
            for fp in sorted(search_root.rglob("*")):
                if not fp.is_file():
                    continue
                rel = str(fp.relative_to(self.repo_root))
                if _should_skip(rel, self.config.skip_patterns):
                    continue
                if rel in seen:
                    continue
                seen.add(rel)
                out.append(rel)
        return out

    async def _pick_core_files_via_llm(
        self,
        module: ModuleInfo,
        focus_files: list[str] | None = None,
        code_index_draft: dict[str, Any] | None = None,
    ) -> list[str]:
        """Have the LLM pick core files from the module's full inventory.

        Falls back to the heuristic `_select_core_files` if:
          - the module has <= 8 files (just use all of them),
          - the inventory is too large to fit in one prompt (> 400 files),
          - the LLM call fails or returns garbage.
        """
        all_files = self._enumerate_module_files(module)
        focus_set = {f for f in (focus_files or []) if self._file_belongs_to_module(f, module)}

        if len(all_files) <= 8:
            return list(focus_set) + [f for f in all_files if f not in focus_set]

        if len(all_files) > 400:
            self._warn(f"模块 {module.name} 文件数 {len(all_files)} > 400，回退启发式选取核心文件")
            return self._select_core_files(
                module,
                max_files=25,
                focus_files=focus_files,
                code_index_draft=code_index_draft,
            )

        files_meta: dict[str, Any] = {}
        if isinstance(code_index_draft, dict):
            files_meta = code_index_draft.get("modules") or {}

        inventory_lines: list[str] = []
        for rel in all_files:
            meta = files_meta.get(rel) or {}
            purpose = (meta.get("purpose") or "").replace("\n", " ").strip()[:120]
            exports = meta.get("exports") or []
            export_names: list[str] = []
            for e in exports[:3]:
                if isinstance(e, dict):
                    nm = e.get("name") or ""
                else:
                    nm = str(e)
                if nm:
                    export_names.append(str(nm))
            line = f"- {rel}"
            if export_names:
                line += f" :: {','.join(export_names)}"
            if purpose:
                line += f" — {purpose}"
            inventory_lines.append(line)

        inventory_blob = "\n".join(inventory_lines)
        system = (
            "你是代码仓库分析专家。给定一个模块及其全部文件清单（含每个文件的导出符号和职责摘要），"
            "请挑出最值得深入阅读的核心文件，覆盖：入口 / 核心业务逻辑 / 关键类接口 / 典型扩展点 / 重要测试。"
            "文件数清单越小选越少，越大可多选些（参考区间 15-30）。只输出 JSON 数组（每项一个相对路径字符串），不要解释。"
        )
        user = (
            f"[模块名]: {module.name}\n"
            f"[模块路径]: {', '.join(module.paths)}\n"
            f"[文件总数]: {len(all_files)}\n"
            f"[必须包含]: {sorted(focus_set) or '无'}\n\n"
            f"[文件清单]:\n{inventory_blob}\n\n"
            '输出格式：["path/to/file1", "path/to/file2", ...]'
        )

        try:
            raw = await self._sem_wrap(_llm_call_with_retry, self.llm, system, user, self.config)
            start = raw.find("[")
            end = raw.rfind("]") + 1
            if start == -1 or end == 0:
                raise ValueError("no JSON array in response")
            picks = json.loads(raw[start:end])
            allowed = set(all_files)
            chosen = [str(p) for p in picks if isinstance(p, str) and p in allowed]
        except Exception as exc:
            self._warn(f"模块 {module.name} 核心文件 LLM 选取失败，回退启发式: {exc}")
            return self._select_core_files(
                module,
                max_files=15,
                focus_files=focus_files,
                code_index_draft=code_index_draft,
            )

        # Always include explicit focus files (changed files in incremental mode).
        for f in focus_set:
            if f not in chosen:
                chosen.insert(0, f)

        # Hard cap to keep facts-pass within token budget.
        return chosen[:30]

    async def _extract_module_facts(
        self, module: ModuleInfo, code_blob: str, core_files: list[str]
    ) -> dict[str, Any]:
        """Single LLM call → structured facts JSON shared by every audience view."""
        system = (
            "你是资深代码审阅员。基于给定模块的核心代码，抽取一份结构化事实清单 (facts)，"
            "后续会被多个角色 (PM/Dev/Tester/Lead/Designer/Security/Data) 共用。"
            "facts 必须忠于代码，避免泛泛之论；如代码未体现某项，留空数组或空串。"
        )
        user = (
            f"[模块名]: {module.name}\n"
            f"[模块路径]: {', '.join(module.paths)}\n"
            f"[已选核心文件]: {core_files}\n\n"
            f"[代码内容]:\n{code_blob}\n\n"
            "输出严格 JSON：\n"
            "{\n"
            '  "summary": "一段话描述这个模块在做什么",\n'
            '  "entry_points": [{"path": "...", "symbol": "...", "purpose": "..."}],\n'
            '  "key_classes": [{"name": "...", "file": "...", "role": "..."}],\n'
            '  "key_flows": ["核心数据或控制流，每条一句话"],\n'
            '  "external_dependencies": ["第三方包或服务名"],\n'
            '  "internal_dependencies": ["仓库内其他模块或包"],\n'
            '  "extension_points": ["可扩展位置 + 扩展方式"],\n'
            '  "risks_and_smells": ["从代码看到的隐患、坏味、TODO/FIXME、deprecated 标记"],\n'
            '  "auth_and_security": ["代码中可见的认证/授权/加密/校验点"],\n'
            '  "sensitive_data": ["代码中处理的敏感数据类别"],\n'
            '  "telemetry_and_metrics": ["可见的日志/埋点/指标"],\n'
            '  "test_signals": ["测试覆盖到的关键场景或缺失"],\n'
            '  "user_facing_behaviors": ["可观察的用户可见行为或对外 API"],\n'
            '  "ui_surfaces": ["前端组件、页面、设计 token 等 设计/UX 相关"],\n'
            '  "open_questions": ["仅从代码无法回答、需要确认的问题"]\n'
            "}"
        )
        raw = await _llm_call_with_retry(self.llm, system, user, self.config)
        return self._parse_json_response(raw)

    async def _render_audience_view(
        self, module: ModuleInfo, facts: dict[str, Any], audience: str
    ) -> dict[str, Any]:
        """Render facts JSON into a single audience-specific JSON section."""
        schema = _AUDIENCE_SCHEMAS.get(audience, "")
        if not schema:
            return {}
        audience_label = AUDIENCE_DOCS.get(audience, {}).get("label", audience)
        focus = module.audience_focus.get(audience, "") if module.audience_focus else ""
        system = (
            f"你是面向 {audience_label} 的技术写作助手。基于给定的模块 facts JSON，"
            f"输出严格按目标 schema 的 JSON 片段。只写该角色为了完成工作必须知道的信息；"
            "如某项 facts 不支持，留空数组或空串，不要编造。"
        )
        user = (
            f"[模块名]: {module.name}\n"
            f"[模块路径]: {', '.join(module.paths)}\n"
            f"[目标角色]: {audience_label}\n"
            f"[角色关注点提示]: {focus or '无特别提示'}\n\n"
            f"[facts]:\n{json.dumps(facts, ensure_ascii=False, indent=2)}\n\n"
            f"[输出 schema]:\n{{\n{schema}\n}}"
        )
        raw = await _llm_call_with_retry(self.llm, system, user, self.config)
        parsed = self._parse_json_response(raw)
        # Accept either { audience: {...} } or the inner dict directly.
        inner = parsed.get(audience) if isinstance(parsed, dict) else None
        if isinstance(inner, dict):
            return inner
        return parsed if isinstance(parsed, dict) else {}

    def _select_core_files(
        self,
        module: ModuleInfo,
        max_files: int = 5,
        focus_files: list[str] | None = None,
        code_index_draft: dict[str, Any] | None = None,
    ) -> list[str]:
        """Select the most informative files for a module.

        Ranking (lower bucket = higher priority):
          0  focus_files explicitly requested
          1  entry-name files (index/main/__init__/mod)
          2  files whose stem contains the module name
          3  import hubs (referenced by other files in this module). Within
             this bucket, higher import-degree wins.
          5  other files, larger size wins
         10  test files (always last)
        """
        # Pre-compute the module's file set + an import-degree map so hubs
        # bubble up. The map is keyed by *relative path string* but we also
        # match on filename stem because LLM-extracted import strings rarely
        # contain full paths.
        module_files: list[str] = []
        for module_path in module.paths:
            search_root = self.repo_root / module_path.rstrip("/")
            if not search_root.exists():
                continue
            for fp in sorted(search_root.rglob("*")):
                if not fp.is_file():
                    continue
                rel = str(fp.relative_to(self.repo_root))
                if _should_skip(rel, self.config.skip_patterns):
                    continue
                module_files.append(rel)

        import_degree: dict[str, int] = {}
        if code_index_draft:
            files_meta = (
                (code_index_draft.get("modules") or {})
                if isinstance(code_index_draft, dict)
                else {}
            )
            module_file_set = set(module_files)
            # Pre-extract import strings for every module file once
            imports_by_file: dict[str, list[str]] = {}
            for rel in module_file_set:
                meta = files_meta.get(rel) or {}
                raw_imports = meta.get("imports") or []
                imports_by_file[rel] = [str(x) for x in raw_imports if isinstance(x, (str, int))]
            # For each candidate file, count how many *other* module files
            # mention its stem in their import strings.
            for rel in module_file_set:
                stem = Path(rel).stem
                if len(stem) < 3:
                    continue  # avoid noisy 1-2 char matches
                count = 0
                for other_rel, imps in imports_by_file.items():
                    if other_rel == rel:
                        continue
                    if any(stem in s for s in imps):
                        count += 1
                if count:
                    import_degree[rel] = count

        candidates: list[tuple[int, int, str]] = []  # (bucket, secondary_sort_key, rel)
        entry_names = {"index", "main", "__init__", "mod"}

        for rel in focus_files or []:
            if self._file_belongs_to_module(rel, module):
                candidates.append((0, 0, rel))

        for rel in module_files:
            stem = Path(rel).stem.lower()
            if stem in entry_names:
                candidates.append((1, 0, rel))
                continue
            if module.name.lower() in stem:
                candidates.append((2, 0, rel))
                continue
            if "test" in rel.lower():
                candidates.append((10, 0, rel))
                continue
            degree = import_degree.get(rel, 0)
            if degree > 0:
                # Higher degree → smaller (more negative) secondary → sorts first
                candidates.append((3, -degree, rel))
                continue
            try:
                size = (self.repo_root / rel).stat().st_size
            except OSError:
                size = 0
            candidates.append((5, -size, rel))

        seen: set[str] = set()
        result: list[str] = []
        for _bucket, _sec, rel in sorted(candidates):
            if rel not in seen:
                seen.add(rel)
                result.append(rel)
            if len(result) >= max_files:
                break
        return result

    @staticmethod
    def _normalize_audience_set(audiences: set[str] | None) -> list[str]:
        if not audiences:
            return list(_ALL_AUDIENCES)
        selected = [audience for audience in _ALL_AUDIENCES if audience in audiences]
        return selected or list(_ALL_AUDIENCES)

    @staticmethod
    def _analysis_schema_for_audiences(audiences: list[str]) -> str:
        return "{\n" + ",\n".join(_AUDIENCE_SCHEMAS[audience] for audience in audiences) + "\n}"

    @staticmethod
    def _file_belongs_to_module(file_path: str, module: ModuleInfo) -> bool:
        # Module paths are always recorded with POSIX separators; on Windows,
        # callers often build file_path via str(Path.relative_to(...)) which
        # yields backslashes. Normalise both sides so module membership and
        # focus_files routing work on Windows.
        normalised_file = file_path.replace("\\", "/")
        for module_path in module.paths:
            normalized = module_path.replace("\\", "/").rstrip("/")
            if normalised_file == normalized or normalised_file.startswith(f"{normalized}/"):
                return True
        return False

    @staticmethod
    def _parse_module_analysis(raw: str) -> dict[str, Any]:
        try:
            start = raw.find("{")
            end = raw.rfind("}") + 1
            if start == -1 or end == 0:
                return {}
            return cast(dict[str, Any], json.loads(raw[start:end]))
        except json.JSONDecodeError:
            return {}

    # ------------------------------------------------------------------
    # Finalise
    # ------------------------------------------------------------------

    async def _finalise(
        self,
        module_map: list[ModuleInfo],
        analyzed: dict[str, dict[str, Any]],
        code_index_draft: dict[str, Any],
        repo_facts: RepoFacts | None = None,
        write_module_docs: bool = True,
    ) -> None:
        """Write all kb/ files: module docs, README, code_index, state."""
        now = _now_iso()
        head_sha = _git_head_sha(self.repo_root) or "unknown"

        # Write module docs
        if write_module_docs:
            for module in module_map:
                analysis = analyzed.get(module.name, {})
                module_dir = self.kb_path / "modules" / _safe_dir_name(module.name)
                module_dir.mkdir(parents=True, exist_ok=True)
                self._write_module_docs(module, analysis, module_dir, now)

        # Generate README
        await self._write_readme(module_map, analyzed, head_sha, now, repo_facts)

        # Write code_index.md
        self._write_code_index(code_index_draft, module_map, now)

        # Init qa_cache.md if absent
        qa_cache = self.kb_path / "qa_cache.md"
        if not qa_cache.exists():
            from .templates import QA_CACHE_TEMPLATE

            qa_cache.write_text(QA_CACHE_TEMPLATE, encoding="utf-8")

        # Write .state.json
        state = {
            "last_commit": head_sha,
            "analyzed_at": now,
            "module_count": len(module_map),
            "modules": [
                {
                    "name": m.name,
                    "paths": m.paths,
                    "type": m.module_type,
                    "description": m.description,
                    "doc_path": m.doc_path,
                    "audience_focus": m.audience_focus,
                }
                for m in module_map
            ],
            "config": self.config.to_dict(),
        }
        (self.kb_path / ".state.json").write_text(state_to_json(state), encoding="utf-8")
        self._write_checkpoint(
            "completed",
            module_map,
            completed_modules=sorted(analyzed),
            analyzed_modules=analyzed,
            code_index_draft=code_index_draft,
            state_written=True,
        )

        # Write warnings log
        if self._warnings:
            (self.kb_path / ".warnings.log").write_text("\n".join(self._warnings), encoding="utf-8")

    def _write_module_docs(
        self,
        module: ModuleInfo,
        analysis: dict[str, Any],
        module_dir: Path,
        now: str,
        audiences: set[str] | None = None,
    ) -> None:
        """Write the four role-specific per-module markdown files."""
        target_audiences = set(self._normalize_audience_set(audiences))
        if "_error" in analysis:
            placeholder = render_template(
                PLACEHOLDER_TEMPLATE,
                {
                    "module_name": module.name,
                    "analyzed_at": now,
                    "error_message": analysis["_error"],
                },
            )
            for audience, meta in AUDIENCE_DOCS.items():
                if audience not in target_audiences:
                    continue
                (module_dir / meta["file"]).write_text(placeholder, encoding="utf-8")
            return

        pm = self._as_dict(analysis.get("pm"))
        developer = self._as_dict(analysis.get("developer"))
        tester = self._as_dict(analysis.get("tester"))
        team_lead = self._as_dict(analysis.get("team_lead"))
        designer = self._as_dict(analysis.get("designer"))
        marketing = self._as_dict(analysis.get("marketing"))
        security = self._as_dict(analysis.get("security"))
        sre = self._as_dict(analysis.get("sre"))
        data = self._as_dict(analysis.get("data"))

        ctx_base = {
            "module_name": module.name,
            "module_paths": ", ".join(module.paths),
            "analyzed_at": now,
        }

        if "pm" in target_audiences:
            (module_dir / "pm.md").write_text(
                render_template(
                    PM_TEMPLATE,
                    {
                        **ctx_base,
                        "user_value": self._text(pm.get("user_value")),
                        "product_behavior": self._text(pm.get("product_behavior")),
                        "key_flows": self._markdown_list(pm.get("key_flows")),
                        "metrics": self._markdown_list(pm.get("metrics")),
                        "pm_questions": self._markdown_list(pm.get("open_questions")),
                    },
                ),
                encoding="utf-8",
            )

        if "developer" in target_audiences:
            (module_dir / "developer.md").write_text(
                render_template(
                    DEVELOPER_TEMPLATE,
                    {
                        **ctx_base,
                        "entry_points": self._markdown_list(developer.get("entry_points")),
                        "implementation": self._text(developer.get("implementation")),
                        "dependencies": self._markdown_list(developer.get("dependencies")),
                        "extension_points": self._markdown_list(developer.get("extension_points")),
                        "developer_risks": self._markdown_list(developer.get("risks")),
                    },
                ),
                encoding="utf-8",
            )

        if "tester" in target_audiences:
            (module_dir / "tester.md").write_text(
                render_template(
                    TESTER_TEMPLATE,
                    {
                        **ctx_base,
                        "test_scope": self._text(tester.get("test_scope")),
                        "critical_scenarios": self._markdown_list(tester.get("critical_scenarios")),
                        "test_data": self._markdown_list(tester.get("test_data")),
                        "regression_risks": self._markdown_list(tester.get("regression_risks")),
                        "test_gaps": self._markdown_list(tester.get("gaps")),
                    },
                ),
                encoding="utf-8",
            )

        if "team_lead" in target_audiences:
            (module_dir / "team_lead.md").write_text(
                render_template(
                    TEAM_LEAD_TEMPLATE,
                    {
                        **ctx_base,
                        "ownership": self._text(team_lead.get("ownership")),
                        "complexity": self._text(team_lead.get("complexity")),
                        "delivery_risks": self._markdown_list(team_lead.get("delivery_risks")),
                        "cross_team_dependencies": self._markdown_list(
                            team_lead.get("cross_team_dependencies")
                        ),
                        "recommended_actions": self._markdown_list(
                            team_lead.get("recommended_actions")
                        ),
                        "change_history": self._text(team_lead.get("change_history")),
                    },
                ),
                encoding="utf-8",
            )

        if "designer" in target_audiences:
            (module_dir / "designer.md").write_text(
                render_template(
                    DESIGNER_TEMPLATE,
                    {
                        **ctx_base,
                        "user_journey": self._text(designer.get("user_journey")),
                        "key_surfaces": self._markdown_list(designer.get("key_surfaces")),
                        "design_system": self._text(designer.get("design_system")),
                        "accessibility": self._markdown_list(designer.get("accessibility")),
                        "design_debt": self._markdown_list(designer.get("design_debt")),
                    },
                ),
                encoding="utf-8",
            )

        if "marketing" in target_audiences:
            (module_dir / "marketing.md").write_text(
                render_template(
                    MARKETING_TEMPLATE,
                    {
                        **ctx_base,
                        "target_audience": self._markdown_list(marketing.get("target_users")),
                        "value_proposition": self._markdown_list(marketing.get("value_props")),
                        "key_selling_points": self._markdown_list(marketing.get("differentiators")),
                        "collateral_gaps": self._markdown_list(marketing.get("launch_assets")),
                        "competitive_notes": self._markdown_list(marketing.get("gtm_risks")),
                    },
                ),
                encoding="utf-8",
            )

        if "security" in target_audiences:
            (module_dir / "security.md").write_text(
                render_template(
                    SECURITY_AUDIT_TEMPLATE,
                    {
                        **ctx_base,
                        "sensitive_data": self._markdown_list(security.get("sensitive_data")),
                        "authn_authz": self._markdown_list(security.get("authn_authz")),
                        "external_dependencies": self._markdown_list(
                            security.get("external_dependencies")
                        ),
                        "compliance_requirements": self._markdown_list(
                            security.get("compliance_requirements")
                        ),
                        "remediation_priorities": self._markdown_list(
                            security.get("remediation_priorities")
                        ),
                    },
                ),
                encoding="utf-8",
            )

        if "sre" in target_audiences:
            (module_dir / "sre.md").write_text(
                render_template(
                    SRE_TEMPLATE,
                    {
                        **ctx_base,
                        "deploy_units": self._text(sre.get("deployment_topology")),
                        "observability": self._markdown_list(sre.get("observability")),
                        "slo_alerting": self._markdown_list(sre.get("slo_targets")),
                        "failure_domains": self._markdown_list(sre.get("failure_domains")),
                        "operational_burden": self._markdown_list(sre.get("runbooks")),
                    },
                ),
                encoding="utf-8",
            )

        if "data" in target_audiences:
            (module_dir / "data.md").write_text(
                render_template(
                    DATA_TEMPLATE,
                    {
                        **ctx_base,
                        "data_flows": self._markdown_list(data.get("data_flows")),
                        "telemetry_events": self._markdown_list(data.get("telemetry_events")),
                        "metric_definitions": self._markdown_list(data.get("metric_definitions")),
                        "data_contracts": self._markdown_list(data.get("data_contracts")),
                        "analytics_gaps": self._markdown_list(data.get("analytics_gaps")),
                    },
                ),
                encoding="utf-8",
            )

    @staticmethod
    def _as_dict(value: Any) -> dict[str, Any]:
        return value if isinstance(value, dict) else {}

    @staticmethod
    def _text(value: Any) -> str:
        if value is None:
            return "未从代码中识别到需要该角色关注的内容。"
        if isinstance(value, list):
            return "\n".join(f"- {item}" for item in value if str(item).strip()) or (
                "未从代码中识别到需要该角色关注的内容。"
            )
        text = str(value).strip()
        return text or "未从代码中识别到需要该角色关注的内容。"

    @classmethod
    def _markdown_list(cls, value: Any) -> str:
        if isinstance(value, list):
            items = [str(item).strip() for item in value if str(item).strip()]
        elif value:
            items = [str(value).strip()]
        else:
            items = []
        return "\n".join(f"- {item}" for item in items) if items else "- 暂未识别"

    async def _write_readme(
        self,
        module_map: list[ModuleInfo],
        analyzed: dict[str, dict[str, Any]],
        head_sha: str,
        now: str,
        repo_facts: RepoFacts | None = None,
    ) -> None:
        summaries = []
        for m in module_map:
            a = analyzed.get(m.name, {})
            summaries.append(
                json.dumps(
                    {
                        "module": m.name,
                        "description": m.description,
                        "audience_focus": m.audience_focus,
                        "pm": self._as_dict(a.get("pm")),
                        "developer": self._as_dict(a.get("developer")),
                        "tester": self._as_dict(a.get("tester")),
                        "team_lead": self._as_dict(a.get("team_lead")),
                        "designer": self._as_dict(a.get("designer")),
                        "marketing": self._as_dict(a.get("marketing")),
                        "security": self._as_dict(a.get("security")),
                        "sre": self._as_dict(a.get("sre")),
                        "data": self._as_dict(a.get("data")),
                    },
                    ensure_ascii=False,
                )
            )

        system = "你是代码仓库知识库编辑，按角色生成仓库级摘要。"
        user = (
            "基于以下模块摘要，生成严格 JSON。不要生成 Markdown。"
            "字段：overview, pm, developer, tester, team_lead, designer, marketing, security, sre, data。"
            "每个字段写 1-3 段，只包含该角色需要知道的仓库级信息。"
            "如果某角色没有可写内容，对应字段写一句『该仓库对此角色无明显关注点』。\n\n"
            + "\n".join(summaries)
        )
        if repo_facts is not None:
            user = f"仓库事实摘要：\n{repo_facts.prompt_summary()}\n\n" + user
        try:
            raw = await _llm_call_with_retry(self.llm, system, user, self.config)
            parsed = self._parse_json_response(raw)
            overview_text = self._text(parsed.get("overview"))
            pm_overview = self._text(parsed.get("pm"))
            developer_overview = self._text(parsed.get("developer"))
            tester_overview = self._text(parsed.get("tester"))
            team_lead_overview = self._text(parsed.get("team_lead"))
            designer_overview = self._text(parsed.get("designer"))
            marketing_overview = self._text(parsed.get("marketing"))
            security_overview = self._text(parsed.get("security"))
            sre_overview = self._text(parsed.get("sre"))
            data_overview = self._text(parsed.get("data"))
        except Exception:
            fallback = "（自动生成失败，请手动补充）"
            overview_text = fallback
            pm_overview = fallback
            developer_overview = fallback
            tester_overview = fallback
            team_lead_overview = fallback
            designer_overview = fallback
            marketing_overview = fallback
            security_overview = fallback
            sre_overview = fallback
            data_overview = fallback

        module_table_rows = "\n".join(
            "| {name} | {mtype} | {desc} | {links} |".format(
                name=m.name,
                mtype=m.module_type,
                desc=m.description[:50],
                links=" · ".join(
                    f"[{meta['label']}]({m.doc_path}{meta['file']})"
                    for meta in AUDIENCE_DOCS.values()
                ),
            )
            for m in module_map
        )

        readme = render_template(
            README_TEMPLATE,
            {
                "repo_name": self.repo_root.name,
                "analyzed_at": now,
                "module_count": len(module_map),
                "commit_short": head_sha[:8],
                "overview_text": overview_text,
                "pm_overview": pm_overview,
                "developer_overview": developer_overview,
                "tester_overview": tester_overview,
                "team_lead_overview": team_lead_overview,
                "designer_overview": designer_overview,
                "marketing_overview": marketing_overview,
                "security_overview": security_overview,
                "sre_overview": sre_overview,
                "data_overview": data_overview,
                "module_table_rows": module_table_rows,
            },
        )
        (self.kb_path / "README.md").write_text(readme, encoding="utf-8")

    def _write_code_index(self, draft: dict, module_map: list[ModuleInfo], now: str) -> None:
        path_to_module = _build_path_to_module_lookup(module_map)

        def _module_for(path: str) -> str:
            return _lookup_module(path, path_to_module) or "—"

        product_entry_rows = (
            "\n".join(
                "| {desc} | — | {path} | PM | {mod} |".format(
                    desc=(e.get("pm_surface") or e.get("purpose", ""))
                    if isinstance(e, dict)
                    else str(e),
                    path=(e.get("path", "") if isinstance(e, dict) else ""),
                    mod=_module_for(e.get("path", "") if isinstance(e, dict) else ""),
                )
                for e in draft.get("product_entries", [])
            )
            or "| — | — | — | — | — |"
        )

        module_file_sections = ""
        test_entry_sections = ""
        leadership_sections = ""
        # ``code_index.md`` is the navigational backbone for deep-read and the
        # README's per-module index, so every module the LLM extracted in
        # Layer 2 must appear here — silently dropping entries makes the KB
        # incomplete with no signal to the caller. Render the full set; the
        # output is plain Markdown so size scales linearly with module count.
        # Sort by path so the generated file is deterministic — Layer 2
        # populates ``draft['modules']`` from concurrent tasks, so dict
        # insertion order would otherwise vary across runs and produce noisy
        # diffs in committed kb snapshots.
        for path, info in sorted(draft.get("modules", {}).items()):
            module_name = _lookup_module(path, path_to_module)
            module_tag = f" — *{module_name}*" if module_name else ""
            exports = info.get("exports", [])
            if exports:
                # Normalize exports to a list (LLM may return a dict instead of list)
                if isinstance(exports, dict):
                    exports = [f"{k}: {v}" for k, v in list(exports.items())[:5]]
                else:
                    exports = list(exports)[:5]
                module_file_sections += f"\n### {Path(path).parent.name}\n\n"
                module_file_sections += "| Purpose | Path | Exports |\n"
                module_file_sections += "|---------|------|---------|\n"
                module_file_sections += f"| {info.get('purpose', '')} | {path}{module_tag} | "
                module_file_sections += (
                    ", ".join(
                        (e.get("name", "") if isinstance(e, dict) else str(e)) for e in exports
                    )
                    + " |\n"
                )
            if info.get("tester_surface"):
                test_entry_sections += f"- `{path}`{module_tag}: {info.get('tester_surface')}\n"
            if info.get("leadership_signal"):
                leadership_sections += f"- `{path}`{module_tag}: {info.get('leadership_signal')}\n"

        code_index = render_template(
            CODE_INDEX_TEMPLATE,
            {
                "updated_at": now,
                "product_entry_rows": product_entry_rows,
                "module_file_sections": module_file_sections or "_暂无_",
                "test_entry_sections": test_entry_sections or "_暂无_",
                "leadership_sections": leadership_sections or "_暂无_",
            },
        )
        (self.kb_path / "code_index.md").write_text(code_index, encoding="utf-8")

    @staticmethod
    def _parse_json_response(raw: str) -> dict[str, Any]:
        try:
            start = raw.find("{")
            end = raw.rfind("}") + 1
            if start == -1 or end == 0:
                return {}
            data = json.loads(raw[start:end])
            return data if isinstance(data, dict) else {}
        except json.JSONDecodeError:
            return {}

    def _load_resume_checkpoint(self) -> dict[str, Any]:
        """Load a compatible incomplete checkpoint for --resume."""
        checkpoint = _read_json_file(self.kb_path / ".checkpoint.json")
        if not checkpoint:
            return {}
        if str(checkpoint.get("repo_root") or "") != str(self.repo_root):
            return {}
        if str(checkpoint.get("kb_path") or "") != str(self.kb_path):
            return {}
        if checkpoint.get("stage") == "completed":
            return checkpoint
        if not isinstance(checkpoint.get("modules"), list):
            return {}
        return checkpoint

    def _modules_from_checkpoint(self, checkpoint: dict[str, Any]) -> list[ModuleInfo]:
        modules = checkpoint.get("modules")
        if not isinstance(modules, list):
            return []
        restored: list[ModuleInfo] = []
        for item in modules:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or "").strip()
            paths = item.get("paths")
            if not name or not isinstance(paths, list):
                continue
            restored.append(
                ModuleInfo(
                    name=name,
                    paths=[str(path) for path in paths],
                    description=str(item.get("description") or ""),
                    module_type=str(item.get("type") or "feature"),
                    doc_path=f"modules/{_safe_dir_name(name)}/",
                    audience_focus=self._normalize_audience_map(item.get("audience_focus", {})),
                )
            )
        return restored

    @staticmethod
    def _analyzed_modules_from_checkpoint(
        checkpoint: dict[str, Any],
    ) -> dict[str, dict[str, Any]]:
        analyzed = checkpoint.get("analyzed_modules")
        if not isinstance(analyzed, dict):
            return {}
        return {
            str(module_name): cast(dict[str, Any], result)
            for module_name, result in analyzed.items()
            if isinstance(module_name, str) and isinstance(result, dict)
        }

    def _warn(self, msg: str) -> None:
        logger.warning(msg)
        self._warnings.append(msg)

    def _write_progress(self, stage: str, status: str, **extra: Any) -> None:
        """Write inspectable run progress for status checks and debugging."""
        self.kb_path.mkdir(parents=True, exist_ok=True)
        progress = {
            "run_id": self._run_id,
            "pid": os.getpid(),
            "repo_root": str(self.repo_root),
            "kb_path": str(self.kb_path),
            "stage": stage,
            "status": status,
            "updated_at": _now_iso(),
            "warnings": self._warnings,
            **extra,
        }
        progress_path = self.kb_path / ".progress.json"
        tmp_path = progress_path.with_suffix(".json.tmp")
        tmp_path.write_text(json.dumps(progress, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp_path.replace(progress_path)

    def _write_checkpoint(
        self,
        stage: str,
        module_map: list[ModuleInfo],
        **extra: Any,
    ) -> None:
        """Write partial run state that can be inspected before finalise."""
        self.kb_path.mkdir(parents=True, exist_ok=True)
        checkpoint = {
            "run_id": self._run_id,
            "pid": os.getpid(),
            "repo_root": str(self.repo_root),
            "kb_path": str(self.kb_path),
            "stage": stage,
            "updated_at": _now_iso(),
            "module_count": len(module_map),
            "modules": [
                {
                    "name": module.name,
                    "paths": module.paths,
                    "type": module.module_type,
                    "description": module.description,
                    "doc_path": module.doc_path,
                    "audience_focus": module.audience_focus,
                }
                for module in module_map
            ],
            "config": self.config.to_dict(),
            **extra,
        }
        checkpoint_path = self.kb_path / ".checkpoint.json"
        tmp_path = checkpoint_path.with_suffix(".json.tmp")
        tmp_path.write_text(
            json.dumps(checkpoint, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        tmp_path.replace(checkpoint_path)

    def _prepare_full_analysis_output(self) -> None:
        """Clear generated full-analysis output while preserving user config."""
        self.kb_path.mkdir(parents=True, exist_ok=True)
        modules_dir = self.kb_path / "modules"
        if modules_dir.exists():
            shutil.rmtree(modules_dir)

        for file_name in (
            "README.md",
            "code_index.md",
            "qa_cache.md",
            ".state.json",
            ".warnings.log",
            ".progress.json",
            ".checkpoint.json",
        ):
            path = self.kb_path / file_name
            if path.exists():
                path.unlink()


# ---------------------------------------------------------------------------
# AnalysisStatusReader
# ---------------------------------------------------------------------------


class AnalysisStatusReader:
    """Read full-analysis progress from KB status files without starting analysis."""

    def __init__(self, kb_path: Path) -> None:
        self.kb_path = Path(kb_path)

    def snapshot(self) -> dict[str, Any]:
        """Return a machine-readable status snapshot for user progress questions."""
        progress = _read_json_file(self.kb_path / ".progress.json")
        checkpoint = _read_json_file(self.kb_path / ".checkpoint.json")
        lock = _read_json_file(self.kb_path / ".run.lock")
        state = _read_json_file(self.kb_path / ".state.json")

        lock_pid = int(lock.get("pid") or 0) if lock else 0
        lock_active = bool(lock_pid and _pid_is_running(lock_pid))
        stage = str(progress.get("stage") or checkpoint.get("stage") or "unknown")
        status = str(progress.get("status") or ("running" if lock_active else "unknown"))
        completed_modules = self._int_from(progress, checkpoint, "completed_modules")
        total_modules = self._int_from(progress, checkpoint, "total_modules") or self._int_from(
            progress, checkpoint, "module_count"
        )
        completed_batches = self._int_from(progress, checkpoint, "completed_batches")
        total_batches = self._int_from(progress, checkpoint, "total_batches")
        percent = self._percent(
            completed_modules or completed_batches,
            total_modules or total_batches,
        )
        generated_docs = (
            len(list((self.kb_path / "modules").rglob("*.md")))
            if (self.kb_path / "modules").exists()
            else 0
        )

        snapshot: dict[str, Any] = {
            "status": self._overall_status(status, stage, lock_active, checkpoint, state),
            "stage": stage,
            "run_id": progress.get("run_id") or checkpoint.get("run_id") or lock.get("run_id"),
            "pid": progress.get("pid") or checkpoint.get("pid") or lock.get("pid"),
            "lock_active": lock_active,
            "updated_at": progress.get("updated_at") or checkpoint.get("updated_at"),
            "started_at": lock.get("started_at"),
            "repo_root": progress.get("repo_root")
            or checkpoint.get("repo_root")
            or lock.get("repo_root"),
            "kb_path": str(self.kb_path),
            "completed_modules": completed_modules,
            "total_modules": total_modules,
            "completed_batches": completed_batches,
            "total_batches": total_batches,
            "percent": percent,
            "generated_module_docs": generated_docs,
            "has_readme": (self.kb_path / "README.md").exists(),
            "has_code_index": (self.kb_path / "code_index.md").exists(),
            "has_state": bool(state),
            "warnings": progress.get("warnings") or [],
            "summary": "",
        }
        snapshot["summary"] = self.render_summary(snapshot)
        return snapshot

    @staticmethod
    def render_summary(snapshot: dict[str, Any]) -> str:
        """Render a concise Chinese answer suitable for user-facing progress replies."""
        status = snapshot.get("status")
        stage = snapshot.get("stage") or "unknown"
        run_id = snapshot.get("run_id") or "unknown"
        updated_at = snapshot.get("updated_at") or "unknown"
        if status == "not_started":
            return "没有找到 repo-analysis 的进度文件；看起来还没有针对这个 KB 跑过 full analysis。"
        if status == "completed":
            return f"repo-analysis 已完成。run_id={run_id}，最后更新时间={updated_at}。"
        if status == "failed":
            return (
                f"repo-analysis 失败在 {stage} 阶段。run_id={run_id}，最后更新时间={updated_at}。"
            )
        if status == "stale_checkpoint":
            completed = snapshot.get("completed_modules") or 0
            total = snapshot.get("total_modules") or 0
            return (
                f"repo-analysis 有未完成 checkpoint，但当前没有活跃进程。run_id={run_id}，"
                f"阶段={stage}，模块进度={completed}/{total}；可以用 --resume 继续。"
            )

        pieces = [f"repo-analysis 正在运行，run_id={run_id}，阶段={stage}"]
        percent = snapshot.get("percent")
        completed = snapshot.get("completed_modules") or snapshot.get("completed_batches")
        total = snapshot.get("total_modules") or snapshot.get("total_batches")
        if completed is not None and total:
            pieces.append(
                f"进度={completed}/{total}" + (f" ({percent}%)" if percent is not None else "")
            )
        pieces.append(f"已写出 module 文档数={snapshot.get('generated_module_docs', 0)}")
        pieces.append(f"最后更新时间={updated_at}")
        return "，".join(pieces) + "。"

    @staticmethod
    def _int_from(progress: dict[str, Any], checkpoint: dict[str, Any], key: str) -> int | None:
        for source in (progress, checkpoint):
            value = source.get(key)
            if isinstance(value, int):
                return value
            if isinstance(value, list):
                return len(value)
        return None

    @staticmethod
    def _percent(done: int | None, total: int | None) -> float | None:
        if done is None or not total:
            return None
        return round(min(done / total, 1.0) * 100, 1)

    @staticmethod
    def _overall_status(
        status: str,
        stage: str,
        lock_active: bool,
        checkpoint: dict[str, Any],
        state: dict[str, Any],
    ) -> str:
        if status == "failed" or stage == "failed":
            return "failed"
        if status == "completed" or checkpoint.get("stage") == "completed" or state:
            return "completed"
        if lock_active:
            return "running"
        if checkpoint:
            return "stale_checkpoint"
        return "not_started"


# ---------------------------------------------------------------------------
# IncrementalUpdater
# ---------------------------------------------------------------------------


class IncrementalUpdater:
    """Update the knowledge base incrementally based on git diff.

    Only modules whose files have changed since ``last_commit`` are
    re-analysed.  Falls back to prompting for full analysis when:

    - .state.json is missing
    - last_commit not found in history
    - More than 5 modules are affected (large refactor heuristic)
    """

    def __init__(
        self,
        repo_root: Path,
        kb_path: Path,
        llm: LLMCaller | None = None,
        config: AnalysisConfig | None = None,
    ) -> None:
        self.repo_root = Path(repo_root)
        self.kb_path = Path(kb_path)
        if llm is None:
            raise ValueError(
                "IncrementalUpdater requires an 'llm' LLMCaller.  "
                "Pass the active session's LLM callable."
            )
        self.llm = llm
        self.config = config or AnalysisConfig()
        self._semaphore = asyncio.Semaphore(self.config.max_concurrency)

    async def run(self) -> dict[str, Any]:
        """Execute incremental update; return summary dict."""
        active_run = self._active_full_analysis()
        if active_run:
            return {
                "status": "full_analysis_running",
                "reason": "同一个 KB 目录正在运行 full analysis，暂不执行增量更新",
                "pid": active_run.get("pid"),
                "run_id": active_run.get("run_id"),
            }

        checkpoint = _read_json_file(self.kb_path / ".checkpoint.json")
        if checkpoint and checkpoint.get("stage") != "completed":
            return {
                "status": "resume_full_analysis",
                "reason": "存在未完成的 full analysis checkpoint，请先用 --resume 补齐",
                "run_id": checkpoint.get("run_id"),
                "checkpoint_stage": checkpoint.get("stage"),
                "completed_modules": checkpoint.get("completed_modules", []),
            }

        state = self._load_state()
        if state is None:
            return {"status": "need_full_analysis", "reason": ".state.json 不存在"}

        last_commit = state.get("last_commit", "")
        if not last_commit:
            return {"status": "need_full_analysis", "reason": "last_commit 为空"}

        changed_files = _git_diff_files(self.repo_root, last_commit)
        if not changed_files:
            return {"status": "up_to_date", "message": "知识库已是最新"}

        module_map = [
            ModuleInfo(
                **{
                    "name": m["name"],
                    "paths": m["paths"],
                    "description": m.get("description", ""),
                    "module_type": m.get("type", "feature"),
                    "doc_path": f"modules/{_safe_dir_name(m['name'])}/",
                    "audience_focus": FullAnalyzer._normalize_audience_map(
                        m.get("audience_focus", {})
                    ),
                }
            )
            for m in state.get("modules", [])
        ]

        affected = self._map_files_to_modules(changed_files, module_map)
        if len(affected) > 5:
            return {
                "status": "suggest_full_analysis",
                "reason": f"变更涉及 {len(affected)} 个模块，建议全量重建",
                "affected_modules": [m.name for m in affected],
            }

        now = _now_iso()
        head_sha = _git_head_sha(self.repo_root) or "unknown"

        focus_files_by_module = {
            module.name: self._changed_files_for_module(module, changed_files)
            for module in affected
        }

        # Re-analyse affected modules and rewrite only role docs touched by the change.
        analyzer = FullAnalyzer(self.repo_root, self.kb_path, llm=self.llm, config=self.config)
        re_analyzed: dict[str, dict[str, Any]] = {}

        async def reanalyse_module(module: ModuleInfo) -> None:
            module_changes = focus_files_by_module.get(module.name, [])
            audiences = self._determine_affected_audiences(module_changes or changed_files)
            # _analyse_module fans out internally; do not double-wrap with the semaphore.
            re_analyzed[module.name] = await analyzer._analyse_module(
                module,
                audiences,
                module_changes,
            )

        await asyncio.gather(*(reanalyse_module(module) for module in affected))

        for module in affected:
            analysis = re_analyzed.get(module.name, {})
            module_changes = focus_files_by_module.get(module.name, [])
            audiences = self._determine_affected_audiences(module_changes or changed_files)
            module_dir = self.kb_path / "modules" / _safe_dir_name(module.name)
            module_dir.mkdir(parents=True, exist_ok=True)
            analyzer._write_module_docs(module, analysis, module_dir, now, audiences=audiences)
            # Append change history
            self._append_change_history(module, changed_files, analysis, now, head_sha)

        # Update state
        state["last_commit"] = head_sha
        state["analyzed_at"] = now
        (self.kb_path / ".state.json").write_text(state_to_json(state), encoding="utf-8")

        return {
            "status": "updated",
            "affected_modules": [m.name for m in affected],
            "changed_files": changed_files,
        }

    def _load_state(self) -> dict[str, Any] | None:
        state_path = self.kb_path / ".state.json"
        if not state_path.exists():
            return None
        try:
            return cast(dict[str, Any], json.loads(state_path.read_text(encoding="utf-8")))
        except (json.JSONDecodeError, OSError):
            return None

    def _active_full_analysis(self) -> dict[str, Any]:
        lock = _read_json_file(self.kb_path / ".run.lock")
        pid = int(lock.get("pid") or 0) if lock else 0
        if pid and _pid_is_running(pid):
            return lock
        return {}

    def _map_files_to_modules(
        self, changed_files: list[str], module_map: list[ModuleInfo]
    ) -> list[ModuleInfo]:
        affected: dict[str, ModuleInfo] = {}
        for file_path in changed_files:
            module = self._find_module_for_file(file_path, module_map)
            if module and module.name not in affected:
                affected[module.name] = module
        return list(affected.values())

    def _changed_files_for_module(self, module: ModuleInfo, changed_files: list[str]) -> list[str]:
        return [
            file_path
            for file_path in changed_files
            if FullAnalyzer._file_belongs_to_module(file_path, module)
        ]

    @staticmethod
    def _determine_affected_audiences(changed_files: list[str]) -> set[str]:
        """Map changed file paths to role docs that need regeneration."""
        if len(changed_files) >= 20:
            return set(_ALL_AUDIENCES)

        audiences: set[str] = {"team_lead"}
        for file_path in changed_files:
            lowered = file_path.lower()
            suffix = Path(lowered).suffix

            if _is_test_path(lowered):
                audiences.add("tester")
                continue
            if _is_doc_path(lowered):
                audiences.update({"pm", "team_lead", "marketing"})
            if _is_product_surface_path(lowered):
                audiences.update({"pm", "tester", "designer", "marketing"})
            if _is_config_or_infra_path(lowered):
                audiences.update({"developer", "team_lead", "sre"})
            if _is_source_suffix(suffix):
                audiences.update({"developer", "tester", "team_lead"})
            if any(
                marker in lowered
                for marker in (
                    "auth",
                    "security",
                    "secret",
                    "crypto",
                    "permission",
                    "policy",
                )
            ):
                audiences.add("security")
            if any(
                marker in lowered
                for marker in (
                    "telemetry",
                    "analytics",
                    "metric",
                    "event",
                    "tracing",
                    "log",
                )
            ):
                audiences.add("data")

        if audiences == {"team_lead"} and changed_files:
            audiences.add("developer")
        return audiences

    @staticmethod
    def _find_module_for_file(file_path: str, module_map: list[ModuleInfo]) -> ModuleInfo | None:
        for module in module_map:
            if FullAnalyzer._file_belongs_to_module(file_path, module):
                return module
        for module in module_map:
            if module.name.lower() in file_path.lower():
                return module
        return None

    def _append_change_history(
        self,
        module: ModuleInfo,
        changed_files: list[str],
        analysis: dict[str, Any],
        now: str,
        head_sha: str,
    ) -> None:
        team_lead_path = self.kb_path / "modules" / _safe_dir_name(module.name) / "team_lead.md"
        if not team_lead_path.exists():
            return
        relevant = [
            f for f in changed_files if any(f.startswith(p.rstrip("/")) for p in module.paths)
        ]
        if not relevant:
            return
        entry = render_template(
            CHANGE_HISTORY_ENTRY_TEMPLATE,
            {
                "date": now[:10],
                "commit_short": head_sha[:7],
                "changed_files": ", ".join(f"`{f}`" for f in relevant),
                "change_summary": (analysis.get("team_lead", {}) or {}).get("change_history")
                or "（自动分析）",
            },
        )
        content = team_lead_path.read_text(encoding="utf-8")
        if "## 变更历史" in content:
            content = content.replace("## 变更历史\n", f"## 变更历史\n\n{entry}", 1)
        else:
            content += f"\n\n## 变更历史\n\n{entry}"
        team_lead_path.write_text(content, encoding="utf-8")


# ---------------------------------------------------------------------------
# OnDemandDeepener
# ---------------------------------------------------------------------------


class OnDemandDeepener:
    """Answer ad-hoc questions by deep-reading source files and writing back.

    Workflow
    --------
    1. Check qa_cache.md for a cached answer (Jaccard similarity > 0.8)
    2. Grep kb/ for relevant snippets
    3. If still insufficient, locate target code and do a deep LLM read
    4. Write new knowledge back to the appropriate module document
    5. Cache the Q&A in qa_cache.md
    """

    CACHE_THRESHOLD = 0.8

    def __init__(
        self,
        repo_root: Path,
        kb_path: Path,
        llm: LLMCaller | None = None,
        config: AnalysisConfig | None = None,
    ) -> None:
        self.repo_root = Path(repo_root)
        self.kb_path = Path(kb_path)
        if llm is None:
            raise ValueError(
                "OnDemandDeepener requires an 'llm' LLMCaller.  "
                "Pass the active session's LLM callable."
            )
        self.llm = llm
        self.config = config or AnalysisConfig()

    async def answer(self, question: str) -> str:
        """Answer *question* using the KB, with deep-read fallback."""
        from .searcher import KBSearcher

        searcher = KBSearcher(self.kb_path)

        # Step 1: QA cache lookup
        cache_hits = searcher.search_qa_cache(question)
        if cache_hits and cache_hits[0].score >= self.CACHE_THRESHOLD:
            best = cache_hits[0]
            return f"{best.answer}\n\n_来源：{best.source}（缓存命中）_"

        # Step 2: KB search
        kb_results = searcher.search(question)
        context_snippets = "\n\n".join(
            f"[{r.doc_path}:{r.line_no}]\n{r.snippet}" for r in kb_results[:5]
        )

        if context_snippets:
            system = "你是代码知识库问答助手，基于知识库文档回答问题。"
            user = (
                f"用户问题：{question}\n\n"
                f"知识库相关内容：\n{context_snippets}\n\n"
                "请基于上述内容回答问题。如果内容不足以精确回答，请说明。"
                '以 JSON 格式输出：{{"answer": "...", "sufficient": true/false, '
                '"target_doc": "..."}}'
            )
            raw = await _llm_call_with_retry(self.llm, system, user, self.config)
            parsed = self._parse_json_response(raw)
            answer = str(parsed.get("answer") or raw)
            sufficient = parsed.get("sufficient", True)

            if sufficient:
                await self._cache_qa(
                    question, answer, "kb_search", kb_results[0].doc_path if kb_results else ""
                )
                return answer

        # Step 3: Deep read
        return await self._deep_read_answer(question)

    async def _deep_read_answer(self, question: str) -> str:
        """Locate and deep-read relevant source files to answer the question."""
        # Ask LLM to identify relevant files from code_index
        code_index_path = self.kb_path / "code_index.md"
        code_index = ""
        if code_index_path.exists():
            code_index = code_index_path.read_text(encoding="utf-8")[:3000]

        system = "你是代码库导航助手，根据问题找到相关源文件路径。"
        user = (
            f"问题：{question}\n\n代码索引摘要：\n{code_index}\n\n"
            '输出 JSON：{"files": ["path/to/file", ...], "module": "模块名"}\n'
            "最多列出5个最相关的文件路径。"
        )
        raw = await _llm_call_with_retry(self.llm, system, user, self.config)
        parsed = self._parse_json_response(raw)
        raw_files = parsed.get("files", [])
        target_files = raw_files[:5] if isinstance(raw_files, list) else []
        module_name = str(parsed.get("module") or "unknown")

        # Read target files. ``target_files`` originates from LLM output
        # and cannot be trusted: reject anything that is not a relative
        # string path, and verify the resolved location stays inside
        # ``self.repo_root`` so absolute paths or ``..`` segments cannot
        # read arbitrary files off the host.
        repo_root_resolved = self.repo_root.resolve()
        content_parts = []
        for fp in target_files:
            if not isinstance(fp, str) or not fp:
                continue
            candidate = Path(fp)
            if candidate.is_absolute():
                continue
            try:
                full = (self.repo_root / candidate).resolve()
            except OSError:
                continue
            if not full.is_relative_to(repo_root_resolved):
                continue
            if not full.exists():
                continue
            try:
                text = full.read_text(encoding="utf-8", errors="replace")[:5000]
                content_parts.append(f"=== {fp} ===\n{text}")
            except OSError:
                pass

        if not content_parts:
            return "知识库暂无此信息，请查看源代码或运行全量分析。"

        combined = "\n\n".join(content_parts)
        system2 = "你是代码分析专家，基于源代码按用户角色精确回答问题。"
        user2 = (
            f"用户问题：{question}\n\n相关源代码：\n{combined}\n\n"
            "请判断这个问题主要服务哪个角色：pm/developer/tester/team_lead。"
            "回答问题，并将可复用知识点提炼为该角色文档的片段。\n"
            '以 JSON 格式输出：{{"answer": "...", "doc_fragment": "...", '
            '"target_doc_path": "modules/{module}/developer.md"}}'
        )
        raw2 = await _llm_call_with_retry(self.llm, system2, user2, self.config)
        parsed2 = self._parse_json_response(raw2)
        answer = str(parsed2.get("answer") or raw2)
        doc_fragment = str(parsed2.get("doc_fragment") or "")
        target_doc = str(parsed2.get("target_doc_path") or "")
        if doc_fragment and not target_doc and module_name != "unknown":
            # Match the on-disk directory layout, which uses _safe_dir_name;
            # otherwise _write_back_fragment rejects the path and the fragment
            # is silently dropped.
            target_doc = f"modules/{_safe_dir_name(module_name)}/developer.md"

        # Write back knowledge
        if doc_fragment and target_doc:
            self._write_back_fragment(doc_fragment, target_doc)

        await self._cache_qa(question, answer, "deep_analysis", target_doc)
        addendum = f"\n\n_已将此知识沉淀到 `{target_doc}`_" if target_doc else ""
        return answer + addendum

    def _write_back_fragment(self, fragment: str, target_doc: str) -> None:
        # target_doc originates from LLM output; restrict writes to
        # ``modules/<safe-module>/<role>.md`` and additionally verify the
        # resolved path stays inside self.kb_path so a path-traversal
        # ``..`` segment can never escape the KB root.
        allowed_files = {meta["file"] for meta in AUDIENCE_DOCS.values()}
        parts = Path(target_doc).parts
        if (
            len(parts) != 3
            or parts[0] != "modules"
            or parts[2] not in allowed_files
            or parts[1] != _safe_dir_name(parts[1])
        ):
            logger.warning(
                "拒绝 write-back：target_doc 不在允许的 modules/<m>/<role>.md 模式: %s",
                target_doc,
            )
            return
        kb_root = self.kb_path.resolve()
        doc_path = (self.kb_path / target_doc).resolve()
        try:
            doc_path.relative_to(kb_root)
        except ValueError:
            logger.warning("拒绝 write-back：target_doc 解析后退出 kb 根: %s", target_doc)
            return
        if not doc_path.exists():
            return
        content = doc_path.read_text(encoding="utf-8")
        content += f"\n\n---\n\n<!-- 按需深化追加 -->\n{fragment}\n"
        doc_path.write_text(content, encoding="utf-8")

    async def _cache_qa(self, question: str, answer: str, analysis_type: str, source: str) -> None:
        from datetime import date

        # When source is a non-path sentinel like "kb_search", Path(source).parent.name
        # collapses to ""; fall back to "unknown" so the QA cache stays readable.
        module_name = Path(source).parent.name if source else ""
        if not module_name:
            module_name = "unknown"
        entry = render_template(
            QA_CACHE_ENTRY_TEMPLATE,
            {
                "question": question,
                "date": date.today().isoformat(),
                "module": module_name,
                "answer": answer,
                "source": source or "kb_search",
                "analysis_type": analysis_type,
            },
        )
        cache_path = self.kb_path / "qa_cache.md"
        if not cache_path.exists():
            # Lazily create on first cache so --action ask works before any
            # full analysis has materialised the file.
            cache_path.write_text(QA_CACHE_TEMPLATE, encoding="utf-8")
        existing = cache_path.read_text(encoding="utf-8")
        cache_path.write_text(existing + entry, encoding="utf-8")

    @staticmethod
    def _parse_json_response(raw: str) -> dict[str, Any]:
        try:
            start = raw.find("{")
            end = raw.rfind("}") + 1
            if start == -1 or end == 0:
                return {}
            return cast(dict[str, Any], json.loads(raw[start:end]))
        except json.JSONDecodeError:
            return {}


# ---------------------------------------------------------------------------
# Repo lifecycle helpers (auto-clone + safe sync)
# ---------------------------------------------------------------------------


def _lookup_clone_url(repo_basename: str) -> str | None:
    """Look up a project's ``clone_url`` from the registry by basename.

    Match is case-insensitive against the last URL segment of each
    project's ``clone_url``. Used by ``_ensure_repo_present`` when the
    target directory does not yet exist on disk.
    """
    try:
        from praestoclaw.projects import BUILTIN_PROJECTS
    except Exception:  # pragma: no cover - registry import failure is fatal upstream
        return None
    name_lower = repo_basename.lower()
    for project in BUILTIN_PROJECTS:
        url = getattr(project, "clone_url", "")
        if not url:
            continue
        url_base = url.rstrip("/").rsplit("/", 1)[-1].lower()
        if url_base == name_lower:
            return url
    return None


def _ensure_repo_present(repo_path: Path) -> None:
    """Clone *repo_path* from the project registry if it doesn't exist.

    Behaviour:
      * Path exists and contains ``.git`` → no-op (already a git repo).
      * Path exists but is not a git repo → raise ``RuntimeError``
        (refuse to overwrite an unrelated directory).
      * Path does not exist → look up ``clone_url`` via
        ``_lookup_clone_url`` and run ``git clone <url> <path>``.
        If no URL is registered the function raises ``RuntimeError``.

    Failures from the clone subprocess propagate as ``RuntimeError`` so
    the analyzer surfaces the error to the operator instead of silently
    analysing nothing.
    """
    repo_path = repo_path.resolve()
    if repo_path.exists():
        if not repo_path.is_dir():
            raise RuntimeError(
                f"repo_path {repo_path} exists but is not a directory; refusing to clone over it"
            )
        if (repo_path / ".git").exists():
            return
        if any(repo_path.iterdir()):
            raise RuntimeError(
                f"repo_path {repo_path} exists and is not empty but has no .git; refusing to clone over it"
            )
    url = _lookup_clone_url(repo_path.name)
    if not url:
        raise RuntimeError(
            f"repo_path {repo_path} does not exist and no clone_url is registered for project '{repo_path.name}'"
        )
    repo_path.parent.mkdir(parents=True, exist_ok=True)
    logger.info("repo-analysis: cloning %s into %s", url, repo_path)
    result = subprocess.run(
        ["git", "clone", "--", url, str(repo_path)],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        stderr = (result.stderr or "").strip() or (result.stdout or "").strip()
        raise RuntimeError(f"git clone failed for {url}: {stderr}")
    logger.info("repo-analysis: clone complete | repo=%s", repo_path)


def _safe_sync_repo(repo_path: Path) -> None:
    """Fast-forward *repo_path* to its upstream branch when safe.

    Safety rules:
      * Working tree must be clean (``git status --porcelain`` empty).
        Dirty trees → log WARNING and skip; analysis proceeds against
        the current HEAD as-is.
      * Sync is fast-forward only (``git merge --ff-only``). Non-ff
        situations (diverged history, force-pushed upstream) → log
        WARNING and skip. The analyzer never runs destructive commands
        such as ``git reset --hard`` or ``git checkout -f``.
      * Any subprocess failure logs a warning and returns; sync errors
        must not block the actual analysis.
    """
    repo_path = repo_path.resolve()
    try:
        dirty = subprocess.run(
            ["git", "-C", str(repo_path), "status", "--porcelain"],
            capture_output=True,
            text=True,
            check=False,
        )
        if dirty.returncode != 0:
            logger.warning(
                "repo-analysis: git status failed for %s: %s",
                repo_path,
                (dirty.stderr or dirty.stdout).strip(),
            )
            return
        if dirty.stdout.strip():
            logger.warning(
                "repo-analysis: working tree dirty at %s; skipping sync, analysing current HEAD",
                repo_path,
            )
            return
        upstream = subprocess.run(
            ["git", "-C", str(repo_path), "rev-parse", "--abbrev-ref", "@{u}"],
            capture_output=True,
            text=True,
            check=False,
        )
        upstream_ref = upstream.stdout.strip()
        if upstream.returncode != 0 or not upstream_ref:
            logger.warning(
                "repo-analysis: no upstream tracking branch at %s; skipping sync",
                repo_path,
            )
            return
        # Fetch the remote that actually backs @{u} — could be ``upstream`` or
        # any other name, not just ``origin``. Without this the merge below
        # uses a stale ref and the "sync" silently does nothing.
        remote_name = upstream_ref.split("/", 1)[0] if "/" in upstream_ref else "origin"
        fetch = subprocess.run(
            ["git", "-C", str(repo_path), "fetch", "--quiet", remote_name],
            capture_output=True,
            text=True,
            check=False,
        )
        if fetch.returncode != 0:
            logger.warning(
                "repo-analysis: git fetch %s failed for %s: %s",
                remote_name,
                repo_path,
                (fetch.stderr or fetch.stdout).strip(),
            )
            return
        merge = subprocess.run(
            ["git", "-C", str(repo_path), "merge", "--ff-only", upstream_ref],
            capture_output=True,
            text=True,
            check=False,
        )
        if merge.returncode != 0:
            logger.warning(
                "repo-analysis: ff-only merge of %s failed at %s: %s",
                upstream_ref,
                repo_path,
                (merge.stderr or merge.stdout).strip(),
            )
            return
        logger.info(
            "repo-analysis: synced %s to %s",
            repo_path,
            upstream_ref,
        )
    except OSError as exc:
        logger.warning("repo-analysis: safe-sync error at %s: %s", repo_path, exc)


# ---------------------------------------------------------------------------
# CLI entry point — standalone invocation via ``python -m``
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    """CLI entry point for standalone invocation.

    This is the ONLY place in this module that creates an LLM provider.
    It loads PraestoClaw config, builds an OpenAIProvider, and wraps it as a
    LLMCaller that is passed into the analyser classes.

    Usage:
        python -m praestoclaw.skills.bundled.repo_analysis.analyzer \\
            --action full|incremental|ask|status \
            --repo /path/to/repo \\
            --kb-path /path/to/kb \\
            [--model auto] \\
            [--resume] \
            [--question "..."]   # required for --action ask
    """
    import argparse
    import sys

    # Force UTF-8 on stdout/stderr. When this module is spawned by cron with
    # ``start /b python ... > some.log``, Windows defaults the redirected
    # streams to the system ANSI codepage (cp1252 / 936). The JSON we print
    # with ``ensure_ascii=False`` contains module names + Chinese prompts and
    # would crash with UnicodeEncodeError. ``errors="replace"`` keeps a stray
    # un-mappable char from killing the process.
    for _stream in (sys.stdout, sys.stderr):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]
        except (AttributeError, ValueError):
            pass

    parser = argparse.ArgumentParser(description="Repo Analysis skill — standalone runner")
    parser.add_argument(
        "--action",
        choices=["full", "incremental", "ask", "status", "schedule", "unschedule"],
        required=True,
    )
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument(
        "--kb-path",
        type=Path,
        default=None,
        help=(
            "Directory to store the knowledge base. "
            "Defaults to ~/.praestoclaw/kb/<repo-name>/ so the kb lives "
            "in PraestoClaw's own data directory, not inside the analysed repo."
        ),
    )
    parser.add_argument("--model", default="auto")
    parser.add_argument(
        "--resume",
        action="store_true",
        help="For --action full, continue from kb/.checkpoint.json when available.",
    )
    parser.add_argument("--question", default="")
    parser.add_argument(
        "--interval-hours",
        type=float,
        default=2.0,
        help="For --action schedule: refresh cadence in hours (default 2).",
    )
    parser.add_argument(
        "--no-bootstrap",
        action="store_true",
        help="For --action schedule: skip the one-shot initial run (only register the recurring job).",
    )
    parser.add_argument(
        "--notify",
        action="store_true",
        help="For --action schedule: deliver run results to the user's channels (default: silent).",
    )
    args = parser.parse_args()

    # Resolve default kb-path: <data-dir>/kb/<repo-name>
    # Honours $PRAESTOCLAW_DATA_DIR / set_data_dir() so isolated test envs
    # and staging instances write to their own data dir.
    if args.kb_path is None:
        from praestoclaw.utils.helpers import get_data_dir

        repo_name = Path(args.repo).resolve().name
        args.kb_path = get_data_dir() / "kb" / repo_name

    # ---- observability: send loguru + stdlib logging to <kb>/.run.log ----
    # Run as a standalone subprocess we'd otherwise lose all logs (stderr is
    # often redirected to a single shared file by the spawning cron prompt).
    # The sink captures run-level events (start, layer transitions, completion,
    # crash) and per-module warnings (`self._warn(...)` -> logger.warning).
    from loguru import logger as _loguru_logger

    class _InterceptHandler(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            try:
                level = _loguru_logger.level(record.levelname).name
            except ValueError:
                level = record.levelno  # type: ignore[assignment]
            frame, depth = logging.currentframe(), 2
            while frame and frame.f_code.co_filename == logging.__file__:
                frame = frame.f_back
                depth += 1
            _loguru_logger.opt(depth=depth, exception=record.exc_info).log(
                level, record.getMessage()
            )

    args.kb_path.mkdir(parents=True, exist_ok=True)
    _loguru_logger.remove()
    _loguru_logger.add(sys.stderr, level="INFO")
    _loguru_logger.add(
        args.kb_path / ".run.log",
        level="INFO",
        rotation="10 MB",
        retention=5,
        backtrace=True,
        diagnose=False,
        enqueue=False,
    )
    logging.basicConfig(handlers=[_InterceptHandler()], level=logging.INFO, force=True)
    _loguru_logger.info(
        "analyzer start | action={} repo={} kb={} resume={}",
        args.action,
        args.repo,
        args.kb_path,
        getattr(args, "resume", False),
    )

    if args.action == "status":
        import json as _json

        print(
            _json.dumps(
                AnalysisStatusReader(args.kb_path).snapshot(),
                ensure_ascii=False,
                indent=2,
            )
        )
        sys.exit(0)

    if args.action == "schedule":
        from praestoclaw.skills.bundled.repo_analysis.auto_trigger import (
            schedule_kb_updates,
        )

        interval_seconds = max(60, int(args.interval_hours * 3600))
        # Pass "auto" by default so repeated schedule invocations don't
        # re-trigger redundant bootstrap runs once the KB exists; only
        # honour an explicit --no-bootstrap as a hard False.
        bootstrap_arg: bool | str = False if args.no_bootstrap else "auto"
        recurring, bootstrap = schedule_kb_updates(
            args.repo,
            interval_seconds=interval_seconds,
            bootstrap=bootstrap_arg,
            silent=not args.notify,
            # Honour --kb-path so the scheduled prompts (and the
            # ``kb_already_initialized`` check) point at the same directory
            # the operator passed on the CLI — otherwise the cron job would
            # read/write the default location instead of the custom one.
            kb_path=args.kb_path,
        )
        import json as _json

        print(
            _json.dumps(
                {
                    "scheduled": True,
                    "repo": str(args.repo.resolve()),
                    "interval_seconds": interval_seconds,
                    "recurring_job": recurring,
                    "bootstrap_job": bootstrap,
                    "silent": not args.notify,
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        sys.exit(0)

    if args.action == "unschedule":
        from praestoclaw.skills.bundled.repo_analysis.auto_trigger import (
            unschedule_kb_updates,
        )

        removed = unschedule_kb_updates(args.repo)
        import json as _json

        print(
            _json.dumps(
                {"unscheduled": True, "removed": removed},
                ensure_ascii=False,
                indent=2,
            )
        )
        sys.exit(0)

    # Auto-clone missing repos for known projects, and fast-forward existing
    # ones to upstream when safe. Both are no-ops for already-cloned-and-clean
    # repos. ``ask`` only needs the working tree present; ``full`` /
    # ``incremental`` additionally try to sync so analysis sees the latest
    # commit. Sync failures (dirty tree, diverged history) log a warning and
    # fall through so analysis can still run against the current HEAD.
    try:
        _ensure_repo_present(args.repo)
    except RuntimeError as exc:
        _loguru_logger.error("analyzer abort | {}", exc)
        sys.exit(2)
    if args.action in {"full", "incremental"}:
        _safe_sync_repo(args.repo)

    # Load PraestoClaw config and build a provider — happens here, not in the lib.
    from praestoclaw.config import load_config
    from praestoclaw.providers.resolver import get_provider

    app_config = load_config()
    provider = get_provider(app_config.providers)
    model_name = args.model

    async def _llm_caller(system_prompt: str, user_content: str) -> str:
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ]
        response = await provider.complete(model=model_name, messages=messages)
        return response.content

    # Load per-kb overrides from kb/.config.json if present.
    cfg_path = args.kb_path / ".config.json"
    user_config: AnalysisConfig | None = None
    if cfg_path.is_file():
        try:
            import json as _json

            user_config = AnalysisConfig.from_dict(
                _json.loads(cfg_path.read_text(encoding="utf-8"))
            )
            print(
                f"[repo-analysis] loaded overrides from {cfg_path} "
                f"(concurrency={user_config.max_concurrency}, "
                f"batch_size={user_config.layer2_batch_size}, "
                f"skip_patterns={len(user_config.skip_patterns)})",
                file=sys.stderr,
            )
        except Exception as exc:
            print(f"[repo-analysis] WARNING: failed to load {cfg_path}: {exc}", file=sys.stderr)

    async def _main() -> None:
        if args.action == "full":
            analyzer = FullAnalyzer(
                args.repo, args.kb_path, llm=_llm_caller, config=user_config, resume=args.resume
            )
            result = await analyzer.run()
            # Suggest periodic updates so the user knows the option exists.
            # The agent surfaces this verbatim — keep it short and actionable.
            if isinstance(result, dict) and result.get("status") != "error":
                result.setdefault(
                    "followup_prompt",
                    (
                        "知识库已建好。要让我每隔几小时自动增量更新一次吗？"
                        "告诉我间隔（默认 6 小时）就行，"
                        "我会用 repo-analysis skill 的 schedule action 注册定时任务。"
                    ),
                )
            import json as _json

            print(_json.dumps(result, ensure_ascii=False, indent=2))
        elif args.action == "incremental":
            updater = IncrementalUpdater(
                args.repo, args.kb_path, llm=_llm_caller, config=user_config
            )
            result = await updater.run()
            import json as _json

            print(_json.dumps(result, ensure_ascii=False, indent=2))
        elif args.action == "ask":
            if not args.question:
                print("ERROR: --question is required for --action ask", file=sys.stderr)
                sys.exit(1)
            deepener = OnDemandDeepener(
                args.repo, args.kb_path, llm=_llm_caller, config=user_config
            )
            answer = await deepener.answer(args.question)
            print(answer)

    try:
        asyncio.run(_main())
    except KeyboardInterrupt:
        _loguru_logger.warning("analyzer interrupted by user (KeyboardInterrupt)")
        raise
    except Exception:
        _loguru_logger.exception("analyzer crashed with unhandled exception")
        raise
    else:
        _loguru_logger.info("analyzer exit ok | action={}", args.action)
