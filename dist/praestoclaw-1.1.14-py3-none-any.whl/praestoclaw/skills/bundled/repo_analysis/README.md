# repo-analysis Skill

> 面向开发者的使用说明

## 概述

`repo-analysis` 是 PraestoClaw 的内置 Skill，负责将代码仓库的知识沉淀为结构化 Markdown
知识库（`kb/` 目录），并支持自然语言问答。生成内容按角色拆分，避免把 PM、Developer、
Tester、Team Lead 需要的信息混在同一份泛化文档里。

## 文件结构

```
praestoclaw/skills/bundled/repo_analysis/
├── SKILL.md          # Skill 元数据与触发规则（Agent 加载）
├── __init__.py       # 公开 API 导出
├── analyzer.py       # 核心分析引擎
├── searcher.py       # 知识库搜索
├── templates.py      # Markdown 文档模板
└── README.md         # 本文件
```

## 快速上手

### 1. 全量分析

```python
from pathlib import Path
from praestoclaw.skills.bundled.repo_analysis import FullAnalyzer, AnalysisConfig

# llm_caller 是一个 async callable: (system_prompt, user_content) -> str
# 在 PraestoClaw 中，你可以从 agent loop 的 provider 实例构造它

async def my_llm(system: str, user: str) -> str:
    response = await provider.complete(
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]
    )
    return response.content

analyzer = FullAnalyzer(
    repo_root=Path("/path/to/repo"),
    kb_path=Path("/path/to/repo/kb"),
    llm=my_llm,
    config=AnalysisConfig(max_concurrency=3),
)
result = await analyzer.run()
print(f"完成：{result['module_count']} 模块，耗时 {result['elapsed_seconds']:.1f}s")

# 如果上一次 full analysis 异常退出，可沿用 kb/.checkpoint.json 继续：
resumed = FullAnalyzer(
    repo_root=Path("/path/to/repo"),
    kb_path=Path("/path/to/repo/kb"),
    llm=my_llm,
    resume=True,
)
result = await resumed.run()
```

### 2. 增量更新

```python
from praestoclaw.skills.bundled.repo_analysis import IncrementalUpdater

updater = IncrementalUpdater(
    repo_root=Path("/path/to/repo"),
    kb_path=Path("/path/to/repo/kb"),
    llm=my_llm,
)
result = await updater.run()
# result["status"] 可能是 "updated" | "up_to_date" | "need_full_analysis" |
# "full_analysis_running" | "resume_full_analysis"
```

### 3. 自然语言问答

```python
from praestoclaw.skills.bundled.repo_analysis import OnDemandDeepener

deepener = OnDemandDeepener(
    repo_root=Path("/path/to/repo"),
    kb_path=Path("/path/to/repo/kb"),
    llm=my_llm,
)
answer = await deepener.answer("auth 模块是如何处理 token 刷新的？")
print(answer)
```

### 4. 查询分析进度

```python
from pathlib import Path
from praestoclaw.skills.bundled.repo_analysis import AnalysisStatusReader

status = AnalysisStatusReader(Path("/path/to/repo/kb")).snapshot()
print(status["summary"])
```

### 5. 搜索知识库

```python
from praestoclaw.skills.bundled.repo_analysis import KBSearcher

searcher = KBSearcher(kb_path=Path("/path/to/repo/kb"))
results = searcher.search("authentication flow")
for r in results[:3]:
    print(f"[{r.score:.2f}] {r.doc_path}:{r.line_no}\n{r.snippet}\n")

# 按模块查找
module_dir = searcher.find_module("auth")
```

## LLM 调用接口

`LLMCaller` 类型签名：

```python
async def my_llm(system_prompt: str, user_content: str) -> str: ...
```

`FullAnalyzer` / `IncrementalUpdater` / `OnDemandDeepener` 均接受此 callable，
不依赖具体 provider SDK，方便测试和替换。

## 确定性事实收集

`collector.py` 在调用 LLM 前收集可复现的仓库事实：文件列表、目录树、文件类型统计、关键项目文件和最近 git 活动。
这些 facts 会进入 Layer 1 模块识别和仓库级 README 摘要，让 LLM 基于稳定输入分析，而不是直接猜测仓库结构。

## 增量更新路由

增量更新先将 changed files 映射到受影响模块，再按文件类型判断需要更新的角色文档：

- 测试文件 → `tester.md` + `team_lead.md`
- 文档/README → `pm.md` + `team_lead.md`
- CLI/Web/API 入口 → `pm.md` + `tester.md` + `team_lead.md`
- 源码实现 → `developer.md` + `tester.md` + `team_lead.md`
- 配置/构建/部署 → `developer.md` + `team_lead.md`

Team Lead 文档仍会沉淀变更历史；大范围变更会回退为更新全部角色文档。

## 运行状态与防重复

Full analysis 启动时会在 KB 目录写入 `.run.lock` 和 `.progress.json`：

- `.run.lock` 防止同一个 KB 目录同时运行多轮 full analysis。
- `.progress.json` 记录 `run_id`、`pid`、当前 stage、完成批次/模块数和更新时间，状态查询应读取它，而不是重新启动分析。
- `.checkpoint.json` 记录已发现模块、Layer 2 draft、已完成模块和模块分析 JSON，用于同 run_id 断点继续。

如果进程异常退出，下一次启动会检测 lock 中的 pid；pid 已不存在时会自动清理 stale lock。

Full analysis 会分阶段落盘：Layer 1 完成后写 checkpoint，Layer 2 完成后立即写 `code_index.md`，Layer 3 每完成一个 module 就写 `modules/<module>/pm.md`、`developer.md`、`tester.md`、`team_lead.md`。最终阶段再生成仓库级 `README.md` 和正式 `.state.json`。

使用 `resume=True` 或 CLI `--resume` 时，full analysis 会读取 `.checkpoint.json`，沿用其中的 `run_id`，跳过已完成且有结构化 `analyzed_modules` 的 module，只补未完成部分。增量更新在发现 `.run.lock` 活跃或 checkpoint 未完成时不会写 KB，而是返回 `full_analysis_running` 或 `resume_full_analysis`，避免和未完成 full analysis 交叉写同一批文档。

当用户询问“分析跑到哪里了 / 还在跑吗 / 完成了吗”时，应使用 `AnalysisStatusReader.snapshot()` 或 CLI `--action status`，根据 `.progress.json`、`.checkpoint.json`、`.run.lock` 和已写出的 KB 文件回答；不要为了查询进度启动新的 full analysis。

## 配置项

| 字段 | 默认值 | 说明 |
|------|--------|------|
| `max_concurrency` | 20 | 最大并发 LLM 调用数 |
| `retry_max_attempts` | 3 | 最大重试次数 |
| `retry_base_delay_ms` | 2000 | 首次退避基础延迟 (ms) |
| `layer2_batch_size` | 20 | Layer 2 每批文件数 |
| `layer2_file_char_limit` | 4000 | Layer 2 每个文件最多送入 LLM 的字符数 |
| `layer3_file_char_limit` | 4000 | Layer 3 每个核心文件最多送入 LLM 的字符数 |
| `skip_patterns` | `["vendor/", ...]` | 跳过路径模式 |
| `large_repo_module_limit` | 50 | 大仓库模块数上限 |

也可在 `kb/.config.json` 中覆盖（由 `FullAnalyzer` 自动读取）。

## 生成的知识库结构

```
kb/
├── README.md          # 全局概览
├── code_index.md      # 功能/文件/符号索引
├── qa_cache.md        # 问答缓存
├── .checkpoint.json   # full analysis 断点续跑状态
├── .progress.json     # full analysis 可观测进度
├── .run.lock          # full analysis 并发锁（运行中存在）
├── .state.json        # 分析状态（last_commit 等）
├── .config.json       # 用户配置（可选）
├── .warnings.log      # 警告日志（如有）
└── modules/
    └── <module>/
        ├── pm.md         # PM 视角：用户价值、产品行为、流程、指标
        ├── developer.md  # Developer 视角：代码入口、实现、依赖、扩展点
        ├── tester.md     # Tester 视角：测试范围、关键场景、回归风险、缺口
        ├── team_lead.md  # Team Lead 视角：职责边界、维护成本、交付风险
        ├── designer.md   # Designer 视角：用户旅程、关键界面、设计系统、a11y
        ├── marketing.md  # Product Marketing / GTM 视角：目标用户、价值主张、卖点、上市材料
        ├── security.md   # Security / Compliance 视角：敏感数据、认证授权、合规、修复优先级
        ├── sre.md        # SRE / DevOps 视角：部署拓扑、可观测性、SLO、故障域、运维负担
        └── data.md       # Data / Analytics 视角：数据流、埋点、指标定义、数据契约
```

## 注意事项

1. **Python 3.11+** 必须。
2. **git** 命令需在 PATH 中（增量更新依赖）。
3. LLM 调用通过 `asyncio.Semaphore` 并发控制，避免触发 rate limit。
4. 分析失败的模块会写入占位文档，不中断整体流程，失败信息记录在 `.warnings.log`。
5. 大仓库（>2000 文件）自动启用降级策略（更小批次、更少核心文件）。
