"""Chronicle loader — register the daily cron job and the chronicle tools.

The single cron runs in *tool mode* (deterministic, no LLM loop):
- ``chronicle-daily`` @ 06:00 local → ``chronicle_run(from='cron')``: collect
  the latest data and, on workdays, summarize the previous-workday→today window
  into the full report and return the markdown, which the scheduler delivers to
  ``notify_channels=["cloud"]`` (the user's Teams). On non-workdays / when paused
  it still collects but returns "" so nothing is delivered.

Completely decoupled from megaphone — depends only on platform infrastructure
(cron service, MCP manager, tool registry).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from loguru import logger

from praestoclaw.chronicle.config import ChronicleConfig, load_config
from praestoclaw.chronicle.tools import (
    ChronicleRunTool,
    ChronicleSearchTool,
    ChronicleSettingsTool,
)

if TYPE_CHECKING:
    from praestoclaw.agent.tools.registry import ToolRegistry
    from praestoclaw.cron.service import SchedulerService
    from praestoclaw.mcp.manager import MCPManager

JOB_PREFIX = "chronicle-"
DAILY_JOB = f"{JOB_PREFIX}daily"
# Legacy job names from the old two-cron design, removed on registration so they
# don't linger as ghosts in the dynamic jobs store after an upgrade.
_LEGACY_JOBS = (f"{JOB_PREFIX}nightly", f"{JOB_PREFIX}morning")


def register_chronicle_tools(tool_registry: ToolRegistry, mcp_manager: MCPManager | None) -> None:
    """Register the chronicle tools (idempotent — re-register replaces).

    ``mcp_manager`` may still be None at startup; the run tool resolves the live
    manager lazily from the registry at execute time.
    """
    tool_registry.register(ChronicleRunTool(tool_registry=tool_registry))
    tool_registry.register(ChronicleSettingsTool())
    tool_registry.register(ChronicleSearchTool())
    logger.info("chronicle: registered tools chronicle_run, chronicle_settings, chronicle_search")


def register_chronicle_jobs(scheduler: SchedulerService, config: ChronicleConfig) -> list[str]:
    """Register the single daily cron job. Returns registered job names."""
    # Drop any leftover jobs from the old two-cron design.
    for legacy in _LEGACY_JOBS:
        try:
            scheduler.remove_job(legacy)
            logger.info("chronicle: removed legacy job {}", legacy)
        except Exception:  # noqa: BLE001 - not registered → nothing to remove
            pass

    scheduler.add_job(
        name=DAILY_JOB,
        schedule=config.schedule,
        tool="chronicle_run",
        arguments={"from": "cron"},
        notify_channels=[config.notify_channel],  # deliver the assembled report
        timezone=config.timezone,
        description=(
            "Chronicle 日报：工作日每天 06:00 采集数据并投递每日工作日报（前一个工作日0点→运行时刻）。"
            "Collect data and deliver the daily report (workdays). "
            "用户要求「现在跑一份日报/生成日报」时，直接调用 chronicle_run(from='manual')，"
            "不要用 cron(action='run')。"
        ),
    )

    logger.info(
        "chronicle: registered job {} ({}) tz={}",
        DAILY_JOB,
        config.schedule,
        config.timezone,
    )
    return [DAILY_JOB]


def maybe_register_chronicle(
    scheduler: SchedulerService | None,
    tool_registry: ToolRegistry,
    mcp_manager: MCPManager | None = None,
    config: ChronicleConfig | None = None,
) -> list[str]:
    """Register chronicle tools (+ the daily cron job when a scheduler exists).

    The tools are registered whenever Chronicle is enabled so the user can run
    and search it on demand; the scheduled daily job is only added when a
    ``scheduler`` is available (cron may be disabled). Safe to call at startup.
    """
    try:
        cfg = config or load_config()
        if not cfg.enabled:
            logger.info("chronicle: disabled in config, skipping registration")
            return []
        register_chronicle_tools(tool_registry, mcp_manager)
        if scheduler is None:
            logger.info(
                "chronicle: no scheduler (cron disabled); tools registered, daily job skipped"
            )
            return []
        return register_chronicle_jobs(scheduler, cfg)
    except Exception as exc:  # noqa: BLE001 - never break startup
        logger.warning("chronicle: failed to register: {}", exc)
        return []
