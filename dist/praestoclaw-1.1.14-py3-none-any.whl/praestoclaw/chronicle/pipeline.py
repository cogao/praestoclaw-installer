"""Chronicle pipeline — orchestrates collection and report generation.

- :func:`run_collect` — pull every enabled source into the archive, advancing
  each source's watermark only on success (so partial failures re-pull).
- :func:`run_daily` — the single scheduled operation: top-up collect, then on a
  workday summarize the [previous workday 00:00, now) window into the full
  four-section report, splice in today's calendar, and persist + return it.

Each stage is isolated: one source failing degrades gracefully without aborting
the others, and progress is recorded in the ``runs`` / ``run_stages`` tables.
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import UTC, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from loguru import logger

from praestoclaw.chronicle import collectors
from praestoclaw.chronicle.config import ChronicleConfig, region_cache_path
from praestoclaw.chronicle.identity import Identity
from praestoclaw.chronicle.mcp_caller import McpCaller
from praestoclaw.chronicle.region import resolve_country_code
from praestoclaw.chronicle.store import ChronicleStore
from praestoclaw.chronicle.summarize import (
    assemble_report,
    summarize_calendar_section,
    summarize_day,
)
from praestoclaw.chronicle.workday import (
    ReportWindow,
    compute_report_window,
    is_workday,
    local_day_bounds,
)


async def run_collect(
    caller: McpCaller,
    store: ChronicleStore,
    identity: Identity,
    cfg: ChronicleConfig,
    *,
    until: datetime | None = None,
    since_override: datetime | None = None,
) -> dict[str, Any]:
    """Collect all enabled sources into the archive. Returns per-source stats."""
    until = until or datetime.now(UTC)
    run_id = f"collect-{uuid.uuid4().hex[:8]}"
    store.start_run(run_id, "collect", until.date().isoformat())
    stats: dict[str, Any] = {"run_id": run_id, "sources": {}}
    retries = cfg.collect_retries
    backoff = cfg.collect_retry_backoff_seconds

    def _since(source: str) -> datetime:
        if since_override is not None:
            return since_override
        wm = store.get_watermark(source)
        if wm is not None:
            return wm
        return until - timedelta(hours=cfg.fallback_hours)

    # Teams
    if cfg.sources.teams:
        await _stage(
            store,
            run_id,
            "teams",
            stats,
            lambda: collectors.collect_teams(
                caller,
                store,
                identity,
                since=_since("teams"),
                until=until,
                tenant_id=None,
            ),
            commit_watermark=("teams", until),
            retries=retries,
            backoff=backoff,
        )

    # GitHub
    if cfg.sources.github:
        await _stage(
            store,
            run_id,
            "github",
            stats,
            lambda: collectors.collect_github(
                store,
                since=_since("github"),
                until=until,
            ),
            commit_watermark=("github", until),
            retries=retries,
            backoff=backoff,
        )

    # Azure DevOps — PRs, work items, manual pipeline runs. Empty org/project
    # disables the source (collect_ado would no-op), so skip the stage entirely:
    # running it would record a no-op run and advance the ADO watermark, which
    # would then block backfill once the user actually configures org/project.
    if cfg.sources.ado and cfg.ado.org and cfg.ado.project:
        await _stage(
            store,
            run_id,
            "ado",
            stats,
            lambda: collectors.collect_ado(
                store,
                identity,
                since=_since("ado"),
                until=until,
                org=cfg.ado.org,
                project=cfg.ado.project,
            ),
            commit_watermark=("ado", until),
            retries=retries,
            backoff=backoff,
        )

    # Email
    if cfg.sources.email:
        await _stage(
            store,
            run_id,
            "email",
            stats,
            lambda: collectors.collect_email(
                caller,
                store,
                identity,
                since=_since("email"),
                until=until,
            ),
            commit_watermark=("email", until),
            retries=retries,
            backoff=backoff,
        )

    # Calendar — archive the collection window's events
    if cfg.sources.calendar:

        async def _cal() -> dict[str, Any]:
            s, _ = await collectors.collect_calendar(
                caller, store, start=_since("calendar"), end=until, tz=cfg.timezone, archive=True
            )
            return s

        await _stage(
            store,
            run_id,
            "calendar",
            stats,
            _cal,
            commit_watermark=("calendar", until),
            retries=retries,
            backoff=backoff,
        )

    # Meetings — archive the spoken layer (Copilot recap / transcript)
    if cfg.sources.meetings:
        await _stage(
            store,
            run_id,
            "meetings",
            stats,
            lambda: collectors.collect_meetings(
                caller,
                store,
                identity,
                since=_since("meetings"),
                until=until,
                tz=cfg.timezone,
            ),
            commit_watermark=("meetings", until),
            retries=retries,
            backoff=backoff,
        )

    store.finish_run(run_id, status="done", stats=stats["sources"])
    return stats


async def _stage(
    store: ChronicleStore,
    run_id: str,
    name: str,
    stats: dict[str, Any],
    fn: Any,
    *,
    commit_watermark: tuple[str, datetime] | None = None,
    retries: int = 0,
    backoff: float = 0.0,
) -> None:
    """Run one source's collect step, isolating its failures from other sources.

    On exception the step is retried up to ``retries`` extra times with
    exponential backoff (``backoff * 2**attempt``) before being recorded as
    failed — a transient
    MCP/Graph timeout should not lose the source (and, for core sources, the
    whole report). The watermark is committed only on success, so a step that
    ultimately fails re-pulls its window on the next run.
    """
    store.set_stage(run_id, name, "running")
    last_exc: Exception | None = None
    for attempt in range(retries + 1):
        try:
            result = await fn()
            stats["sources"][name] = result
            # A collector can return normally while still recording per-item
            # failures in result["errors"] (e.g. a few chats we could not pull
            # even after its own retries). Treat that as a partial success:
            # honor the "watermark advances only on fully-successful collection"
            # contract by NOT committing the watermark, so the next run re-pulls
            # the same window (idempotent via UNIQUE(source, external_id) dedup)
            # rather than silently skipping past the un-pulled items.
            partial = isinstance(result, dict) and bool(result.get("errors"))
            store.set_stage(run_id, name, "partial" if partial else "done")
            if commit_watermark and not partial:
                store.set_watermark(*commit_watermark)
            return
        except Exception as exc:  # noqa: BLE001 - isolate source failures
            last_exc = exc
            if attempt < retries:
                delay = backoff * (2**attempt)
                logger.warning(
                    "chronicle.pipeline: stage {} attempt {}/{} failed: {}; retrying in {}s",
                    name,
                    attempt + 1,
                    retries + 1,
                    exc,
                    delay,
                )
                if delay > 0:
                    await asyncio.sleep(delay)
            else:
                logger.warning(
                    "chronicle.pipeline: stage {} failed after {} attempt(s): {}",
                    name,
                    retries + 1,
                    exc,
                )
    stats["sources"][name] = {"error": str(last_exc)}
    store.set_stage(run_id, name, "failed", error=str(last_exc))


def _validate_core(core_md: str) -> None:
    """Reject empty/truncated core output (sections 一/二/四)."""
    if not core_md or not core_md.strip():
        raise RuntimeError("chronicle: core report generation returned empty output.")
    missing = [h for h in ("## 一", "## 二", "## 四") if h not in core_md]
    if missing:
        raise RuntimeError(
            f"chronicle: core report looks truncated (missing {missing}); not saving."
        )


# Sources whose data feeds the report core (sections 一/二/四). If any of these
# fail during collection we must NOT advance coverage, or their backfill
# on a later run would land inside an already-reported window and be lost.
_CORE_SOURCES = ("teams", "meetings", "email", "github", "ado")


def _core_collect_failures(cfg: ChronicleConfig, stats: dict[str, Any]) -> list[str]:
    """Return enabled core sources that errored (fully or partially) this run.

    A source is flagged on a full failure (``error`` set by ``_stage`` after all
    retries) *or* a partial one (a non-empty ``errors`` list returned by a
    collector that otherwise succeeded). This feeds a visibility-only warning
    log, so partials must be included or the log can wrongly claim a clean run.
    """
    sources = stats.get("sources", {})
    failed = []
    for name in _CORE_SOURCES:
        if not getattr(cfg.sources, name, False):
            continue
        s = sources.get(name)
        if isinstance(s, dict) and (s.get("error") or s.get("errors")):
            failed.append(name)
    return failed


async def run_daily(
    caller: McpCaller,
    store: ChronicleStore,
    identity: Identity,
    cfg: ChronicleConfig,
    provider: Any,
    *,
    now: datetime | None = None,
    force: bool = False,
    window: ReportWindow | None = None,
    manual: bool = False,
) -> str:
    """Single daily job (default 06:00 local): always collect the latest data,
    and on workdays summarize the window [previous workday 00:00 → now) into
    the full four-section report and return its markdown to deliver.

    Returns "" when there is nothing to deliver (report paused, non-workday,
    already delivered today, or an empty window), so cron tool-mode skips
    delivery. Collection still happens in every case — the user only perceives
    the report, not the collection.

    The daily job never hard-fails *during collection*: collection retries
    transient timeouts and a source that still fails is logged and re-pulled next
    run (its watermark is not advanced), while the report is built best-effort
    from the archive. Report *assembly* is the one exception — if the LLM output
    is truncated or a required section is missing, the integrity checks raise
    rather than persist a corrupt digest, so cron surfaces the failure.

    ``manual`` marks an on-demand run (the user said "跑日报") as opposed to the
    scheduled cron. A manual run bypasses the pause / workday / already-delivered
    guards so it always produces the report. A windowless manual run persists the
    standard-span digest (``source="cron"``), so a manual run done before 06:00
    intentionally satisfies that day's dedup and the scheduled job won't re-push.

    Pass an explicit ``window`` (see :func:`manual_report_window`) for a manual
    test/preview run over a custom span: it overrides the computed span, bypasses
    the same guards, and its markdown is returned for delivery but NOT persisted,
    so it never clobbers the canonical daily digest.
    """
    now = now or datetime.now(UTC)
    custom_window = window is not None
    # Both an explicit custom window and an on-demand manual run bypass the
    # pause / workday / already-delivered guards.
    bypass = manual or custom_window
    stats = await run_collect(caller, store, identity, cfg, until=now)

    # Report paused: keep collecting, deliver nothing. A manual run (on-demand
    # or custom-window test/backfill) bypasses the pause.
    if cfg.report_paused and not bypass:
        logger.info("chronicle: report paused; collected only")
        return ""

    if window is not None:
        # Caller asked for an exact span → skip workday/holiday gating and the
        # already-delivered guard entirely.
        delivery_date = window.delivery_date
    else:
        # Resolve the user's holiday region so workday/holiday detection reflects
        # where they actually are. A pinned ``holiday_region`` always wins;
        # otherwise auto-detect from the M365 profile (cached, best-effort —
        # failures fall back to the cache and then to weekday-only behaviour).
        if cfg.auto_holiday_region and not cfg.holiday_region:
            code = await resolve_country_code(caller, region_cache_path())
            if code:
                cfg.holiday_region = code
                logger.info("chronicle: holiday region resolved to {}", code)

        today_local = now.astimezone(_local_tz(cfg)).date()
        delivery_date = today_local.isoformat()

        # The scheduled cron path is gated on workday + already-delivered; an
        # on-demand manual run skips both so it always produces a report.
        if not bypass:
            if not is_workday(today_local, cfg):
                logger.info("chronicle: {} is not a workday; collected only", delivery_date)
                return ""

            existing = store.get_digest(delivery_date)
            if existing and existing.get("source") == "cron" and not force:
                logger.info("chronicle: report for {} already delivered; skipping", delivery_date)
                return ""

        # The report covers [previous workday 00:00, now) — the start spans the
        # previous workday (plus any intervening non-workdays); the end is the run
        # time, so work already done earlier today is included. Never a catch-up
        # of missed runs (those stay in the archive, just unreported).
        window = compute_report_window(now, cfg)
        if window is None:
            logger.info("chronicle: empty window for {}; nothing to report", delivery_date)
            return ""

    # Collection is a resilient long task: each source already retries on
    # transient MCP/Graph timeouts (see ``_stage``) and only advances its
    # watermark on success, so a source that still failed this run re-pulls its
    # window next time — nothing is lost from the archive. The report itself is
    # built from whatever is already archived for the window, so a failed source
    # never aborts the job or blocks delivery (the daily job must not hard-fail).
    # We only log which sources degraded this run for visibility.
    failures = _core_collect_failures(cfg, stats)
    if failures:
        logger.warning(
            "chronicle: core sources {} failed to collect this run; delivering "
            "best-effort report from the archive (their data re-pulls next run).",
            failures,
        )

    # Sections 一/二/四 from the work window.
    items = store.items_in_range(window.since, window.until)
    core_md = await summarize_day(
        provider,
        cfg.model,
        items=items,
        preferences=cfg.preferences,
        identity=identity,
        language=cfg.language,
        investigate=cfg.investigate,
        target_date=delivery_date,
        summary_date=window.label,
        timezone=cfg.timezone,
    )
    _validate_core(core_md)

    # Today's calendar → section 三. Skip the MCP call entirely when the calendar
    # source is disabled (summarize_calendar_section still emits the 三 heading
    # with an empty agenda, so the section-presence guard below stays satisfied).
    today_events: list[dict[str, Any]] = []
    if cfg.sources.calendar:
        t_start, t_end = local_day_bounds(cfg, now)
        _, today_events = await collectors.collect_calendar(
            caller, store, start=t_start, end=t_end, tz=cfg.timezone, archive=False
        )
    section3 = await summarize_calendar_section(
        provider,
        cfg.model,
        calendar_events=today_events,
        identity=identity,
        language=cfg.language,
        timezone=cfg.timezone,
    )
    markdown = assemble_report(core_md, section3)

    missing = [h for h in ("## 一", "## 二", "## 三", "## 四") if h not in markdown]
    if missing:
        raise RuntimeError(f"chronicle: assembled report missing sections {missing}; not saving.")

    # A custom-window run is a preview/test over an arbitrary span: return its
    # markdown for delivery but do NOT persist it. Digests are keyed by
    # target_date (ON CONFLICT replaces), so saving it under today's date would
    # clobber and relabel the canonical daily digest. A windowless run (cron or
    # on-demand manual) DOES persist the standard-span digest as source="cron",
    # so a manual run intentionally counts as that day's delivery.
    if not custom_window:
        store.save_digest(
            delivery_date,
            markdown,
            cfg.model,
            period_start=window.since,
            period_end=window.until,
            covered_dates=window.covered_dates,
            status="delivered",
            source="cron",
        )
    return markdown


def _local_tz(cfg: ChronicleConfig) -> ZoneInfo:
    try:
        return ZoneInfo(cfg.timezone)
    except Exception:  # noqa: BLE001 - bad tz string falls back to UTC
        return ZoneInfo("UTC")
