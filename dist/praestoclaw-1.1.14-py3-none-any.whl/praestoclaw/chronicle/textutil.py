"""Small text helpers for Chronicle: HTML stripping, Teams deep links, parsing."""

from __future__ import annotations

import html
import json
import re
from datetime import UTC, datetime
from typing import Any
from urllib.parse import quote

_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"[ \t]*\n[ \t\n]*")
_MENTION_RE = re.compile(r"<at[^>]*>(.*?)</at>", re.IGNORECASE | re.DOTALL)


def strip_html(content: str | None) -> str:
    """Convert a Teams/Graph HTML message body to readable plain text.

    Preserves ``<at>`` mention display names and collapses whitespace.
    """
    if not content:
        return ""
    text = _MENTION_RE.sub(lambda m: "@" + _TAG_RE.sub("", m.group(1)).strip(), content)
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"</p\s*>", "\n", text, flags=re.IGNORECASE)
    text = _TAG_RE.sub("", text)
    text = html.unescape(text)
    text = _WS_RE.sub("\n", text)
    return text.strip()


def teams_message_link(chat_id: str, message_id: str, tenant_id: str | None = None) -> str:
    """Construct a Teams deep link to a specific chat message.

    Format (already in production use by megaphone):
        https://teams.microsoft.com/l/message/{chatId}/{messageId}?context=...
    """
    ctx = quote(json.dumps({"contextType": "chat"}, separators=(",", ":")))
    url = f"https://teams.microsoft.com/l/message/{chat_id}/{message_id}?context={ctx}"
    if tenant_id:
        url += f"&tenantId={tenant_id}"
    return url


def classify_chat_type(chat_id: str) -> str:
    """Infer chat type from the chat id format."""
    if chat_id.startswith("19:meeting_"):
        return "meeting"
    if chat_id.endswith("@unq.gbl.spaces"):
        return "oneOnOne"
    return "group"


def parse_iso(value: str | None) -> datetime | None:
    """Parse an ISO-8601 timestamp (tolerating a trailing ``Z``)."""
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)
        return dt
    except (ValueError, TypeError):
        return None


def extract_json(text: str) -> Any:
    """Extract the first JSON object/array from a noisy LLM/MCP text response.

    MCP tools often prepend a human preamble before the JSON payload; LLMs may
    wrap JSON in fenced code blocks. This finds the first balanced JSON value
    and parses it. Returns ``None`` on failure.
    """
    if not text:
        return None
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL)
    if fenced:
        try:
            return json.loads(fenced.group(1).strip())
        except json.JSONDecodeError:
            pass
    for opener, closer in (("{", "}"), ("[", "]")):
        start = text.find(opener)
        if start == -1:
            continue
        depth = 0
        in_str = False
        esc = False
        for i in range(start, len(text)):
            ch = text[i]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == opener:
                depth += 1
            elif ch == closer:
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(text[start : i + 1])
                    except json.JSONDecodeError:
                        break
    return None
