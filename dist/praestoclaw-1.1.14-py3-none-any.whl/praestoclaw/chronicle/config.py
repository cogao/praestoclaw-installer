"""Chronicle configuration (Pydantic v2).

Loaded from ``<data_dir>/chronicle/chronicle.yaml`` (independent of megaphone).
"""

from __future__ import annotations

import contextlib
import os
import tempfile
from pathlib import Path

import yaml
from pydantic import BaseModel, Field

from praestoclaw.utils.helpers import get_data_dir


class SourcesConfig(BaseModel):
    teams: bool = True
    github: bool = True
    email: bool = True
    calendar: bool = True
    meetings: bool = True
    ado: bool = True


class ChroniclePreference(BaseModel):
    """A single daily-report personalization rule.

    Preferences are report-layer filters only — they never affect what gets
    archived. They live in ``chronicle.yaml`` (not the SQLite archive) because
    the report pipeline consumes the whole list wholesale into the LLM prompt;
    there is no query/JOIN that would benefit from a table. Matched/removed by
    content (scope/directive/target), not by a numeric id.
    """

    scope: str  # chat | person | topic | source | section | global
    directive: str  # exclude | hard_mute | highlight | focus | ignore_topic | verbosity | language | section_toggle
    target_id: str | None = None
    target_name: str | None = None
    value: str | None = None
    raw_text: str | None = None


class AdoConfig(BaseModel):
    """Azure DevOps source settings (queried via the ``az`` CLI / AAD token).

    Leave ``org``/``project`` empty to disable the source. ``org`` is the full
    organization URL (e.g. ``https://o365exchange.visualstudio.com``).
    """

    org: str = Field(default="")
    project: str = Field(default="")


class ChronicleConfig(BaseModel):
    """Top-level Chronicle configuration."""

    model_config = {"populate_by_name": True}

    enabled: bool = Field(default=False)
    language: str = Field(default="zh-CN")
    timezone: str = Field(default="Asia/Shanghai")

    # User-facing "daily report" switch. When paused, the daily job STILL
    # collects (the user never perceives collection) but skips summarizing and
    # delivers nothing. Toggled at runtime by the bot via the chronicle_settings
    # tool — read fresh on every cron run, so it takes effect without a restart
    # and survives restarts (config is the single source of truth; the cron job
    # itself stays registered and enabled).
    report_paused: bool = Field(default=False)

    # One daily cron (local time, ``timezone`` above). At ``schedule`` the job
    # always collects the latest data, and on workdays summarizes the window
    # [previous reported workday 00:00 → run time) into the full report and
    # delivers it. Default 06:00 local.
    schedule: str = Field(default="0 6 * * *")

    # Workday calendar — data is collected every day, but the report is only
    # delivered on workdays. The first workday after a weekend/holiday gap
    # summarizes everything since the last reported workday.
    # ``workdays`` uses Python's weekday() numbering (Mon=0 … Sun=6).
    workdays: list[int] = Field(default_factory=lambda: [0, 1, 2, 3, 4])
    holidays: list[str] = Field(default_factory=list)  # YYYY-MM-DD non-workdays
    extra_workdays: list[str] = Field(default_factory=list)  # YYYY-MM-DD makeup workdays (调休)
    # Region code (ISO 3166-1 alpha-2, e.g. "CN", "US") for the ``holidays``
    # package, used to recognise public holidays so the report is not delivered
    # on them. Manual ``holidays``/``extra_workdays`` always take priority.
    # Leave empty to auto-detect from the signed-in user's M365 profile (see
    # ``auto_holiday_region``); set it explicitly to pin a region and skip
    # detection.
    holiday_region: str = Field(default="")
    # When ``holiday_region`` is empty, resolve the user's region dynamically
    # from their Microsoft 365 profile (Graph ``usageLocation``) at each run,
    # cached on disk for offline/transient-failure runs. A non-empty
    # ``holiday_region`` is treated as an explicit pin and is never overwritten.
    auto_holiday_region: bool = Field(default=True)

    # Fallback lookback when no watermark exists yet.
    fallback_hours: int = Field(default=24, ge=1)

    # Transient-failure resilience for collection. Each source's collect step is
    # retried up to this many extra times on exception (e.g. an MCP/Graph
    # ``tools/call`` timeout) with linear backoff before being recorded as
    # failed. Reliability matters more than speed here — a single 06:00 Teams
    # timeout should not lose the whole day's report.
    collect_retries: int = Field(default=2, ge=0)
    collect_retry_backoff_seconds: float = Field(default=5.0, ge=0)

    sources: SourcesConfig = Field(default_factory=SourcesConfig)

    # Azure DevOps work surface (PRs, work items, manual pipeline runs).
    ado: AdoConfig = Field(default_factory=AdoConfig)

    # Investigate new tech / OSS mentioned by colleagues. LLM decides per-topic.
    investigate: bool = Field(default=True)

    # Deliver the daily report through this notify channel.
    notify_channel: str = Field(default="cloud")

    # Model alias for summarization (resolved against the app provider chain).
    model: str = Field(default="auto")

    # Daily-report personalization rules (focus/exclude a chat/topic, etc.).
    # Consumed wholesale into the summarizer prompt; managed at runtime by the
    # bot via the chronicle_settings tool. Report-layer only — never affects
    # what gets archived.
    preferences: list[ChroniclePreference] = Field(default_factory=list)


def chronicle_dir() -> Path:
    return get_data_dir() / "chronicle"


def config_path() -> Path:
    return chronicle_dir() / "chronicle.yaml"


def db_path() -> Path:
    return chronicle_dir() / "chronicle.db"


def identity_cache_path() -> Path:
    return chronicle_dir() / "identity.json"


def region_cache_path() -> Path:
    return chronicle_dir() / "region.txt"


def load_config(path: Path | None = None) -> ChronicleConfig:
    cfg_path = path or config_path()
    if not cfg_path.is_file():
        return ChronicleConfig()
    try:
        raw = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
    except (yaml.YAMLError, OSError):
        return ChronicleConfig()
    return ChronicleConfig.model_validate(raw)


def update_config(updates: dict[str, object], path: Path | None = None) -> ChronicleConfig:
    """Patch top-level keys in chronicle.yaml and return the reloaded config.

    Reads the existing YAML (preserving keys we don't touch), applies ``updates``,
    validates, and writes it back. Used by the bot to flip runtime switches such
    as ``report_paused`` without a restart. Comments are not preserved.
    """
    cfg_path = path or config_path()
    raw: dict[str, object] = {}
    if cfg_path.is_file():
        try:
            raw = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
        except (yaml.YAMLError, OSError):
            raw = {}
    raw.update(updates)
    cfg = ChronicleConfig.model_validate(raw)  # validate before persisting
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    text = yaml.safe_dump(raw, allow_unicode=True, sort_keys=False)
    # Atomic write: a crash mid-write must not leave chronicle.yaml truncated,
    # since cron reads it on every run and the bot toggles it at runtime.
    fd, tmp_name = tempfile.mkstemp(dir=str(cfg_path.parent), prefix=".chronicle-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_name, cfg_path)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(tmp_name)
        raise
    return cfg


def add_preference(pref: ChroniclePreference, path: Path | None = None) -> ChronicleConfig:
    """Append a preference to chronicle.yaml and return the reloaded config."""
    cfg = load_config(path)
    prefs = [*cfg.preferences, pref]
    return update_config({"preferences": [p.model_dump() for p in prefs]}, path)


def remove_preferences(
    *,
    scope: str | None = None,
    directive: str | None = None,
    target: str | None = None,
    path: Path | None = None,
) -> tuple[ChronicleConfig, int]:
    """Remove preferences matching ALL of the given criteria (content match).

    ``target`` is matched case-insensitively as a substring of ``target_name``
    or ``target_id``. At least one criterion should be supplied by the caller —
    with no criteria every preference matches (a deliberate "clear all").
    Returns the reloaded config and the number removed.
    """
    cfg = load_config(path)
    needle = target.strip().lower() if target else None

    def _matches(p: ChroniclePreference) -> bool:
        if scope and p.scope != scope:
            return False
        if directive and p.directive != directive:
            return False
        if needle:
            haystacks = [h.lower() for h in (p.target_name, p.target_id) if h]
            if not any(needle in h for h in haystacks):
                return False
        return True

    kept = [p for p in cfg.preferences if not _matches(p)]
    removed = len(cfg.preferences) - len(kept)
    cfg = update_config({"preferences": [p.model_dump() for p in kept]}, path)
    return cfg, removed
