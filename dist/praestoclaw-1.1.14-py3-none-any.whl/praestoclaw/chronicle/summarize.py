"""Chronicle summarization — map-reduce LLM pipeline producing the daily report.

To stay within context limits when message volume is large, summarization runs
in two stages:
- MAP   : each Teams chat thread is compressed into a compact JSON digest
          (topic, key points with links, action items for me). Runs concurrently.
- REDUCE: the chat digests + my GitHub/email activity + calendar + user
          preferences are assembled into the final four-section daily report.

Only the LLM summarizes; all collection is deterministic code upstream.
"""

from __future__ import annotations

import asyncio
import json
import re
from collections import Counter
from typing import Any
from urllib.parse import unquote

from loguru import logger

from praestoclaw.chronicle.config import ChroniclePreference
from praestoclaw.chronicle.identity import Identity
from praestoclaw.chronicle.textutil import extract_json

_MAP_CONCURRENCY = 8
_MAX_MSGS_PER_CHAT = 80
_MAX_TEXT = 400
_MAX_MEETING_CHARS = 18000

# Caps on how many already-distilled digests/events the REDUCE prompt embeds.
# The MAP step compresses each chat/meeting to a small summary, so these bound
# the serialized context to a predictable size WITHOUT slicing the JSON string
# (which could cut a token mid-way and yield invalid JSON). Generous enough that
# a normal day is unaffected.
_MAX_REDUCE_CHAT_DIGESTS = 80
_MAX_REDUCE_MEETING_DIGESTS = 40
_MAX_REDUCE_CALENDAR_EVENTS = 60

# Placeholder the "core" pass (sections 一/二/四) leaves where section 三 (today's
# calendar) gets spliced in by the separate calendar pass. Kept on its own line
# so it can be matched/replaced deterministically.
_SECTION_3_MARKER = "<!--CHRONICLE_SECTION_3-->"

_GITHUB_REPO_RE = re.compile(r"github\.com/([^/]+/[^/]+)/")
_ADO_REPO_RE = re.compile(r"/_git/([^/]+)/")


def _ensure_section_marker(core_md: str) -> str:
    """Guarantee exactly one section-三 marker sits between sections 二 and 四.

    The marker stands in for the ENTIRE section 三 (heading included), which the
    calendar pass supplies via :func:`assemble_report`. The LLM is asked to emit
    only the marker, but we don't trust it to: we strip any stray ``## 三``
    heading it added and collapse to a single, well-placed marker.
    """
    # Drop any section-三 block the model emitted (heading AND body, up to the
    # next "## " heading or EOF). The calendar pass brings its own complete
    # section 三; leaving a stray body here would duplicate it after assembly.
    core_md = re.sub(r"(?ms)^## *三[、,]?.*?(?=^## |\Z)", "", core_md)
    if _SECTION_3_MARKER in core_md:
        # Collapse any duplicates to the first occurrence.
        first, _, rest = core_md.partition(_SECTION_3_MARKER)
        return first + _SECTION_3_MARKER + rest.replace(_SECTION_3_MARKER, "")
    # Marker missing → insert it just before the "## 四" heading, else append.
    m = re.search(r"(?m)^## *四[、,]?", core_md)
    if m:
        return core_md[: m.start()] + _SECTION_3_MARKER + "\n\n" + core_md[m.start() :]
    return core_md.rstrip() + "\n\n" + _SECTION_3_MARKER + "\n"


def assemble_report(core_md: str, section3_md: str) -> str:
    """Splice the calendar pass's section 三 into the core (一/二/四) report."""
    body = section3_md.strip()
    if _SECTION_3_MARKER in core_md:
        return core_md.replace(_SECTION_3_MARKER, body, 1)
    m = re.search(r"(?m)^## *四[、,]?", core_md)
    if m:
        return core_md[: m.start()] + body + "\n\n" + core_md[m.start() :]
    return core_md.rstrip() + "\n\n" + body + "\n"


def _known_entities(items: list[dict[str, Any]], me: str) -> dict[str, list[str]]:
    """Derive real project/repo, group, and people names from the archived data.

    Instead of hard-coding a single product name, we surface the actual entities
    present in the day's data so the LLM can (a) normalize speech-to-text garble
    to the nearest real project/repo/group name and (b) unify each person under
    one canonical display name.
    """
    repos: dict[str, None] = {}
    groups: dict[str, None] = {}
    people: Counter[str] = Counter()
    for it in items:
        link = it.get("link") or ""
        m = _GITHUB_REPO_RE.search(link)
        if m:
            full = m.group(1)  # e.g. gim-home/PraestoClaw
            repos.setdefault(full, None)
            repos.setdefault(full.split("/")[-1], None)  # short name
        m = _ADO_REPO_RE.search(link)
        if m:
            repos.setdefault(unquote(m.group(1)), None)
        if it.get("chat_type") in ("group", "meeting") or it.get("source") == "meeting":
            topic = (it.get("chat_topic") or it.get("title") or "").strip()
            if topic and topic.lower() not in ("(meeting)", "(none)"):
                groups.setdefault(topic, None)
        name = (it.get("author_name") or "").strip()
        if name and name != me:
            people[name] += 1
    return {
        "repos": list(repos)[:20],
        "groups": list(groups)[:30],
        "people": [n for n, _ in people.most_common(40)],
    }


def _format_glossary(entities: dict[str, list[str]], me: str) -> str:
    """Build a data-driven normalization note injected into every LLM prompt."""
    parts = [
        "KNOWN ENTITIES (derived from today's actual data — use them to normalize "
        "speech-to-text garble and to keep names consistent):"
    ]
    if entities.get("repos"):
        parts.append("- Projects / code repositories: " + "; ".join(entities["repos"]))
    if entities.get("groups"):
        parts.append("- Teams groups & meeting names: " + "; ".join(entities["groups"]))
    if entities.get("people"):
        parts.append("- People (canonical display names): " + "; ".join(entities["people"]))
    parts.append(
        "NORMALIZATION RULES: Teams speech-to-text frequently garbles names. When a "
        "spoken product/project name is clearly a mangled form of one of the KNOWN "
        "projects/repositories above (e.g. it sounds like the repo name but with wrong "
        "spacing/spelling), write the real project name as it appears in that list — "
        "infer it from the known repo/group names, do NOT invent a brand. For people, "
        "use ONE consistent display name per person taken from the People list; if the "
        "same person is referred to by a translated or alternate spelling, unify it to "
        "the canonical display name."
    )
    return "\n".join(parts) + "\n"


async def _llm(
    provider: Any,
    model: str,
    system: str,
    user: str,
    *,
    max_tokens: int = 2000,
    reasoning_effort: str | None = None,
) -> str:
    resp = await provider.complete(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        temperature=0.3,
        max_tokens=max_tokens,
        reasoning_effort=reasoning_effort,
    )
    return resp.content or ""


async def _map_chat(
    provider: Any, model: str, chat: dict[str, Any], language: str, glossary: str
) -> dict[str, Any]:
    """Compress one chat thread into a digest dict."""
    lines = []
    for m in chat["messages"][:_MAX_MSGS_PER_CHAT]:
        who = "ME" if m["is_me"] else (m["author"] or "?")
        text = (m["text"] or "").replace("\n", " ")[:_MAX_TEXT]
        lines.append(f"- [{m['time']}] {who}: {text}  <link>{m['link']}</link>")
    convo = "\n".join(lines)
    system = (
        "You compress one Microsoft Teams chat thread into a compact JSON digest. "
        "Be faithful; do not invent. Use the provided <link> values verbatim when citing. "
        "Do NOT assume the direction of a conversation: if a colleague asked ME a question "
        "and I answered, describe it that way (I answered their question), not the reverse. "
        "Only attribute something to ME when the line is labeled 'ME'. Preserve specific "
        "identifiers (branch names, PR numbers, file names) verbatim; never generalize a "
        "branch link into a 'repo link'. "
        + glossary
        + f"Write all natural-language text in {language}."
    )
    user = (
        f"Chat type: {chat['chat_type']}\nTopic: {chat['topic'] or '(none)'}\n"
        f"Messages (oldest→newest):\n{convo}\n\n"
        "Return ONLY JSON with this shape:\n"
        "{\n"
        '  "topic": "short topic label",\n'
        '  "summary": "2-4 sentence neutral summary of what was discussed",\n'
        '  "my_contributions": ["what ME actually said/did, faithful to direction; empty if none"],\n'
        '  "action_items_for_me": [{"text": "a task I must personally do", "due": "ISO date or empty", "link": "msg link"}],\n'
        '  "key_points": [{"text": "notable point / decision / question", "link": "msg link"}],\n'
        '  "tech_or_oss": ["new technologies, tools, or open-source projects mentioned, empty if none"]\n'
        "}"
    )
    try:
        raw = await _llm(provider, model, system, user, max_tokens=1200)
        parsed = extract_json(raw)
        if isinstance(parsed, list):
            parsed = parsed[0] if parsed and isinstance(parsed[0], dict) else None
        digest = parsed if isinstance(parsed, dict) else {}
    except Exception as exc:  # noqa: BLE001 - one bad thread shouldn't kill the run
        logger.warning("chronicle.summarize: map failed for chat {}: {}", chat["chat_id"], exc)
        digest = {}
    digest.setdefault("topic", chat["topic"] or chat["chat_type"])
    digest["chat_id"] = chat["chat_id"]
    digest["chat_type"] = chat["chat_type"]
    # Time span of the thread (UTC ISO) so the reduce step can order todos
    # chronologically against meetings and other activity.
    times = [m["time"] for m in chat["messages"] if m.get("time")]
    if times:
        digest["first_msg_time"] = min(times)
        digest["last_msg_time"] = max(times)
    return digest


async def _map_meeting(
    provider: Any,
    model: str,
    meeting: dict[str, Any],
    language: str,
    me_name: str,
    glossary: str,
) -> dict[str, Any]:
    """Compress one meeting transcript into a digest dict (the spoken layer).

    Strictly faithful: only the user's own utterances count as their contributions,
    and tasks owned by other people are kept separate from the user's own todos.
    """
    body = (meeting["body"] or "")[:_MAX_MEETING_CHARS]
    system = (
        "You distill a meeting transcript into a compact JSON digest, strictly from the "
        f"perspective of the signed-in user, whose name in the transcript is '{me_name}'. "
        "Transcript lines are formatted 'Speaker: utterance'. Be rigorously faithful: "
        "NEVER invent, NEVER guess who proposed something, and NEVER claim the user "
        "hosted, organized, drove, or led the meeting unless the transcript explicitly "
        "shows it. Attribute a statement to the user ONLY when its speaker label is "
        f"exactly '{me_name}'. Preserve specific identifiers (branch names, PR numbers, "
        "file names, feature flags) verbatim; never generalize them (e.g. do not turn a "
        f"branch link into 'repo link'). Be concise: consolidate granular, repetitive, "
        "or back-and-forth utterances into a few substantive points — do NOT transcribe "
        "every sentence as its own bullet; keep only what matters for a daily report. "
        + glossary
        + f"Write all natural-language text in {language}."
    )
    user = (
        f"Meeting subject: {meeting['subject']}\n"
        f"You appear in the transcript as the speaker: {me_name}\n"
        f"Transcript ('Speaker: text' lines):\n{body}\n\n"
        "Return ONLY JSON with this shape (keep each list SHORT and merged, not a "
        "play-by-play):\n"
        "{\n"
        '  "summary": "2-3 neutral sentences on what the meeting was about",\n'
        f'  "my_contributions": ["AT MOST 4 consolidated points {me_name} personally made '
        "(from lines labeled with their name); merge related remarks; empty if they spoke "
        'little or not at all — do NOT put group conclusions here"],\n'
        '  "decisions": ["AT MOST 5 of the most important group decisions/conclusions, '
        "stated neutrally WITHOUT attributing to a specific person unless explicit; empty "
        'if none"],\n'
        f'  "action_items_for_me": [{{"text": "a concrete task {me_name} must personally '
        'do", "due": "ISO date or empty"}],\n'
        '  "action_items_others": [{"text": "a task owned by someone else", "owner": '
        '"that person\'s name", "due": "ISO date or empty"}],\n'
        '  "key_points": ["other notable points worth remembering"]\n'
        "}\n"
        "If you are unsure whether an action item is the user's own responsibility, put "
        "it in action_items_others with the real owner — NEVER in action_items_for_me."
    )
    try:
        raw = await _llm(provider, model, system, user, max_tokens=3000)
        parsed = extract_json(raw)
        if isinstance(parsed, list):
            parsed = parsed[0] if parsed and isinstance(parsed[0], dict) else None
        digest = parsed if isinstance(parsed, dict) else {}
        # If JSON parsing failed (e.g. truncation), keep the raw text so the
        # meeting's content still reaches the reduce step instead of vanishing.
        if not digest and raw.strip():
            digest = {"summary": raw.strip()[:1500]}
    except Exception as exc:  # noqa: BLE001 - one bad meeting shouldn't kill the run
        logger.warning(
            "chronicle.summarize: map failed for meeting {}: {}", meeting["subject"], exc
        )
        digest = {}
    digest["subject"] = meeting["subject"]
    digest["source_kind"] = meeting["kind"]
    digest["link"] = meeting.get("link")
    digest["start"] = meeting.get("start")
    return digest


def _group_meetings(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for it in items:
        if it["source"] != "meeting":
            continue
        out.append(
            {
                "subject": it.get("chat_topic") or it.get("title") or "(meeting)",
                "kind": it.get("kind"),
                "body": it.get("body_text"),
                "link": it.get("link"),
                # Meeting start (UTC ISO) — lets the reduce step order todos by
                # time of day and detect a morning task closed out in the afternoon.
                "start": it.get("created_at"),
            }
        )
    return out


def _group_teams(items: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    chats: dict[str, dict[str, Any]] = {}
    for it in items:
        if it["source"] != "teams":
            continue
        cid = it["chat_id"]
        chat = chats.setdefault(
            cid,
            {
                "chat_id": cid,
                "chat_type": it.get("chat_type"),
                "topic": it.get("chat_topic") or "",
                "messages": [],
            },
        )
        chat["messages"].append(
            {
                "time": it.get("created_at"),
                "author": it.get("author_name"),
                "is_me": bool(it.get("is_me")),
                "text": it.get("body_text"),
                "link": it.get("link"),
            }
        )
    # _map_chat tells the model the messages are oldest→newest; guarantee that
    # invariant here so the helper stays correct even if a caller ever passes
    # items in a different order.
    for chat in chats.values():
        chat["messages"].sort(key=lambda m: m.get("time") or "")
    return chats


def _preferences_text(preferences: list[ChroniclePreference]) -> str:
    soft = [
        p
        for p in preferences
        if p.directive in ("highlight", "focus", "ignore_topic", "verbosity", "language")
    ]
    if not soft:
        return ""
    lines = [f"- {p.directive}: {p.raw_text or p.value or p.target_name}" for p in soft]
    return "User preferences to honor when writing the report:\n" + "\n".join(lines)


async def summarize_day(
    provider: Any,
    model: str,
    *,
    items: list[dict[str, Any]],
    preferences: list[ChroniclePreference],
    identity: Identity,
    language: str,
    investigate: bool,
    target_date: str,
    summary_date: str,
    timezone: str,
) -> str:
    """Produce the core daily-report markdown (sections 一/二/四).

    Section 三 (today's calendar) is not produced here: a
    ``CHRONICLE_SECTION_3_MARKER`` placeholder is emitted in its place, and the
    separate calendar pass (:func:`summarize_calendar_section`) drops today's
    calendar in via :func:`assemble_report`. ``summary_date`` may be a single
    date or a multi-day range label (e.g. ``"06-13 ~ 06-15"``) covering a holiday
    gap.
    """
    excluded = {
        p.target_id
        for p in preferences
        if p.scope == "chat" and p.directive in ("exclude", "hard_mute") and p.target_id
    }

    me_name = identity.display_name or identity.mail or "me"
    glossary = _format_glossary(_known_entities(items, me_name), me_name)

    # MAP: compress teams threads (skip excluded chats — report-layer filter).
    chats = {cid: c for cid, c in _group_teams(items).items() if cid not in excluded}
    sem = asyncio.Semaphore(_MAP_CONCURRENCY)

    async def _bounded(chat: dict[str, Any]) -> dict[str, Any]:
        async with sem:
            return await _map_chat(provider, model, chat, language, glossary)

    digests = await asyncio.gather(*[_bounded(c) for c in chats.values()]) if chats else []

    # MAP: distill the spoken layer of meetings (Copilot recap / transcript).
    meetings = _group_meetings(items)

    async def _bounded_meeting(m: dict[str, Any]) -> dict[str, Any]:
        async with sem:
            return await _map_meeting(provider, model, m, language, me_name, glossary)

    meeting_digests = (
        await asyncio.gather(*[_bounded_meeting(m) for m in meetings]) if meetings else []
    )

    # My direct activity (PRs authored on GitHub + Azure DevOps, emails I sent, etc.).
    my_prs = [
        {"title": it["title"], "link": it["link"]}
        for it in items
        if it["source"] in ("github", "ado") and it["kind"] == "pr"
    ]
    review_requests = [
        {"title": it["title"], "link": it["link"]}
        for it in items
        if it["kind"] == "pr_review_requested"
    ]
    # Azure DevOps PRs I reviewed and approved (merged in window or pending merge).
    my_approved_prs = [
        {"title": it["title"], "link": it["link"], "author": it.get("author_name")}
        for it in items
        if it["source"] == "ado" and it["kind"] == "pr_approved"
    ]
    # Azure DevOps work items assigned to me (state decides done vs todo).
    my_work_items = [
        {"title": it["title"], "link": it["link"], "type": it.get("chat_topic")}
        for it in items
        if it["source"] == "ado" and it["kind"] == "work_item"
    ]
    # Pipeline runs I manually triggered (a failed one is a follow-up).
    my_pipeline_runs = [
        {"title": it["title"], "link": it["link"]}
        for it in items
        if it["source"] == "ado" and it["kind"] == "pipeline_run"
    ]
    flagged_email = [
        {"title": it["title"], "link": it["link"], "from": it.get("author_name")}
        for it in items
        if it["source"] == "email"
        and (it.get("raw_json") and '"flag": "flagged"' in (it["raw_json"] or ""))
    ]
    emails = [
        {"title": it["title"], "from": it.get("author_name"), "link": it["link"]}
        for it in items
        if it["source"] == "email"
    ]

    context = {
        "delivery_date": target_date,
        "summary_date": summary_date,
        "timezone": timezone,
        "me": identity.display_name or identity.mail,
        "meeting_digests": meeting_digests[:_MAX_REDUCE_MEETING_DIGESTS],
        "teams_digests": digests[:_MAX_REDUCE_CHAT_DIGESTS],
        "my_pull_requests": my_prs,
        "my_approved_prs": my_approved_prs,
        "pr_review_requests": review_requests,
        "my_work_items": my_work_items,
        "my_pipeline_runs": my_pipeline_runs,
        "emails_received": emails[:30],
        "flagged_emails": flagged_email,
    }

    system = (
        "You are Chronicle, a personal work assistant. From the structured JSON context "
        "you write a clear, well-organized daily report. Be faithful and concrete; never "
        "fabricate, never overclaim. Do NOT claim the user hosted, drove, or led a meeting "
        "unless the context explicitly says so. Do NOT present group conclusions or other "
        "people's tasks as the user's own work or todos. Preserve specific identifiers "
        "(branch names, PR numbers, file names) verbatim. Preserve and use the provided "
        "links as clickable markdown links. "
        "Never announce that a category, sub-item, or direction is empty — do NOT write "
        "'无'/'没有'/'none'/'no records'/'未提交'/'未触发' or similar for an empty bucket; just "
        "OMIT it silently and move on. Only an entire top-level H2 section that is "
        "completely empty may carry one short note saying so. "
        + glossary
        + f"Write the ENTIRE report in {language}."
    )
    investigate_note = (
        "If colleagues discussed a notable new technology or open-source project (see "
        "'tech_or_oss' in digests), add a brief 1-2 sentence note explaining what it is. "
        if investigate
        else ""
    )
    pref_text = _preferences_text(preferences)
    user = (f"{pref_text}\n\n" if pref_text else "") + (
        f"Start the report with this exact H1 title line: '# {target_date} 晨报（{identity.display_name or identity.mail}）'.\n"
        "Then write EXACTLY these four sections with markdown H2 headings:\n\n"
        f"## 一、{summary_date} 我完成了什么 (What I did)\n"
        f"This section is ONLY about {summary_date}. Cover the user's OWN concrete work. "
        "Lead with a brief PR/work roundup, then the meetings. For the PR/work roundup, "
        "report each of the following categories THAT HAS CONTENT — OMIT any empty "
        "category entirely (do NOT write a line like '无'/'none'/'no records'; just skip "
        "it):\n"
        "- PRs they AUTHORED ('my_pull_requests'; ADO titles carry an [active]/[completed] "
        "status prefix) — separate the ones they COMPLETED/merged in the window from the "
        "ones still [active] (ongoing).\n"
        "- PRs they REVIEWED AND APPROVED ('my_approved_prs'; titles carry "
        "[approved·merged] or [approved·pending]) — i.e. how many PRs they approved, with "
        "the author and link.\n"
        "- Azure DevOps work items they MOVED FORWARD or RESOLVED/CLOSED ('my_work_items' "
        "whose state is Resolved/Closed/Completed/Done/Fixed).\n"
        "- Pipeline runs they manually triggered ('my_pipeline_runs') and the outcome.\n"
        "- Notable emails they received or flagged ('emails_received'/'flagged_emails') "
        "that reflect work they handled or replied to (the archive captures received "
        "mail, not sent mail).\n"
        "Then, for each meeting the user took part in (a meeting digest with non-empty "
        "'my_contributions'), include it here: briefly state the meeting's main "
        "conclusions/decisions ('decisions'/'key_points') AND clearly mark what the USER "
        "personally contributed or committed to ('my_contributions'). Be concise — keep "
        "each meeting to roughly 3-4 bullets for the user's contributions and 3-4 for the "
        "conclusions; merge minor or repetitive points rather than listing every remark. "
        "Frame attendance honestly (e.g. '参加 X 会议' / '在 X 会议中我…'); never say the "
        "user hosted, organized, or drove a meeting unless the context states it. Be "
        "faithful about direction (if someone asked the user and the user answered, say "
        "so). Preserve specific identifiers (branch/PR/file names) verbatim.\n\n"
        "## 二、待办与需要我跟进的事项 (Todos / needs my action)\n"
        "FIRST consolidate across the whole day. The SAME underlying task can surface "
        "several times — a morning meeting raises it, an afternoon chat or PR closes it. "
        "Merge all evidence about ONE task into a SINGLE entry; never list it twice as if "
        "it were several separate open todos. Build each task's timeline in chronological "
        "order using the digests' time fields (meeting 'start', chat 'first_msg_time'/"
        "'last_msg_time') together with the section-一 activity, and report only its LATEST "
        "state. If a task was already completed or pushed forward LATER THE SAME DAY (a "
        "later meeting/chat/PR/commit, a resolved work item, or a sent email shows it done "
        "or progressed), show it as 已完成/进行中 with a one-line progression (e.g. "
        f"'上午 X 会议提出 → 下午已完成') so {me_name} sees the final progress — do NOT present a "
        "task that was already finished that day as still outstanding. Treat these time "
        "fields as ISO UTC for ORDERING ONLY; do not print them as clock times.\n"
        "Then split the remaining items into TWO clearly labeled groups:\n"
        "**A. 需要我 take action（owner = 我）**: items the user must personally do — each "
        "teams digest's 'action_items_for_me', each meeting digest's 'action_items_for_me', "
        "PRs awaiting my review ('pr_review_requests'), Azure DevOps work items assigned to "
        "me that are still open ('my_work_items' whose state is New/Active/Committed/In "
        "Progress/Approved), my own still-[active] PRs that need attention, and any FAILED "
        "manual pipeline run ('my_pipeline_runs' with a failed/canceled result). Include "
        "due dates and links; sort by urgency.\n"
        "**B. 我在跟进 / 等待他人**: tasks owned by OTHER people (each meeting digest's "
        "'action_items_others') — show the owner's name. These are NOT my todos; never "
        "reword them as if I must do them. If group B has no items, omit the **B.** label "
        "entirely — do NOT write '无' under it.\n\n"
        "For section 三, output EXACTLY this single placeholder line and NOTHING "
        "else (no heading, no content — it is filled in later):\n"
        f"{_SECTION_3_MARKER}\n\n"
        "## 四、同事们在讨论什么 (What colleagues are discussing)\n"
        "Summarize the teams_digests and any meetings the user did NOT actively take part "
        "in, organized by topic, to surface what colleagues are working on. For meetings "
        "already covered in section 一, do not repeat them here unless there is additional "
        "cross-team context worth noting. For each topic give a short summary and attach "
        "the most relevant message/meeting link(s). " + investigate_note + "\n\n"
        "If an ENTIRE H2 section has no content, note that in one short line; never tag "
        "individual categories or buckets as empty. Keep it skimmable with bullet points.\n\n"
        "Context JSON:\n```json\n" + json.dumps(context, ensure_ascii=False, default=str) + "\n```"
    )
    # The reduce step is structured writing over already-distilled digests, not a
    # reasoning-heavy task. Keep reasoning_effort low so the model spends its
    # (provider-capped ~16k) output budget on the report text rather than burning
    # it on thinking — at higher effort + large inputs the text was getting
    # truncated to almost nothing.
    core = await _llm(provider, model, system, user, max_tokens=16000, reasoning_effort="low")
    return _ensure_section_marker(core)


async def summarize_calendar_section(
    provider: Any,
    model: str,
    *,
    calendar_events: list[dict[str, Any]],
    identity: Identity,
    language: str,
    timezone: str,
) -> str:
    """Generate section 三 (今日日程) alone, for the calendar pass to splice in."""
    heading = "## 三、今日日程 (Today's calendar)"
    if not calendar_events:
        empty = "今天没有日程安排。" if language.startswith("zh") else "No events scheduled today."
        return f"{heading}\n{empty}"

    system = (
        "You are Chronicle, a personal work assistant. Summarize today's calendar "
        "faithfully and concisely; never fabricate. Preserve and use the provided links "
        f"as clickable markdown links. Write the ENTIRE output in {language}."
    )
    user = (
        f"Write ONLY this section, starting with the exact H2 heading line:\n{heading}\n\n"
        "Summarize 'today_calendar'. Each event's 'start_display'/'end_display' are ALREADY "
        f"in the user's local time ({timezone}); show those times and, if you label a "
        "timezone, label it as local time — NEVER label them UTC and never convert them. "
        "Flag meetings that need focus or preparation (external attendees, decisions, "
        "reviews) and say what to prepare. Keep it skimmable with bullet points.\n\n"
        "Context JSON:\n```json\n"
        + json.dumps(
            {"today_calendar": calendar_events[:_MAX_REDUCE_CALENDAR_EVENTS]},
            ensure_ascii=False,
            default=str,
        )
        + "\n```"
    )
    out = await _llm(provider, model, system, user, max_tokens=4000, reasoning_effort="low")
    out = out.strip()
    if not out.lstrip().startswith("## "):
        out = f"{heading}\n{out}"
    return out
