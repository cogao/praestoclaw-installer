"""MCP caller abstraction for Chronicle.

Chronicle collectors call MCP tools (Teams, mail, calendar, m365-user) through a
small async protocol so the same collector code works in two contexts:

- ``StdioMcpCaller`` — spawns ``agency mcp <server> --transport stdio`` as a
  subprocess and speaks JSON-RPC. Used for standalone runs / tests, and as a
  self-contained fallback. Keeps one persistent process per server.
- ``ManagerMcpCaller`` — wraps the live ``MCPManager`` owned by the running
  agent runtime. Used in production so we reuse the agent's already-authenticated
  MCP connections instead of spawning duplicates.

Both implement :class:`McpCaller`. Collectors depend only on the protocol, never
on a concrete transport — this keeps Chronicle decoupled and testable.
"""

from __future__ import annotations

import asyncio
import json
import subprocess
import threading
import time
from typing import Any, Protocol, cast, runtime_checkable

from loguru import logger


class McpError(RuntimeError):
    """Raised when an MCP tool call fails at the protocol level."""


@runtime_checkable
class McpCaller(Protocol):
    """Minimal async interface Chronicle collectors need from MCP."""

    async def call_tool(
        self, server: str, tool: str, arguments: dict[str, Any], *, timeout: float = 120.0
    ) -> str:
        """Invoke ``tool`` on ``server`` and return the text result payload."""
        ...

    async def aclose(self) -> None:
        """Release any resources (subprocesses, connections)."""
        ...


# ---------------------------------------------------------------------------
# Stdio transport (standalone / fallback)
# ---------------------------------------------------------------------------


class _StdioServer:
    """One persistent ``agency mcp <server>`` subprocess + JSON-RPC plumbing.

    Uses the *synchronous* :mod:`subprocess` module with a background reader
    thread rather than :func:`asyncio.create_subprocess_exec`. On Windows the
    asyncio ``ProactorEventLoop`` corrupts subprocess stdout pipes once more than
    one child has been spawned and torn down (the second child's stdout returns
    immediate EOF -> "connection closed"). The sync + thread model — proven by the
    standalone pull scripts — sidesteps that entirely. Blocking calls are wrapped
    in :func:`asyncio.to_thread` so the public interface stays async.
    """

    def __init__(self, server: str) -> None:
        self.server = server
        self._proc: subprocess.Popen[str] | None = None
        self._reader: threading.Thread | None = None
        self._lock = threading.Lock()
        self._responses: dict[int, dict[str, Any]] = {}
        self._id = 0
        self._init_lock = asyncio.Lock()
        self._initialized = False
        self._closed = False

    # -- thread-side (blocking) helpers ------------------------------------

    def _read_loop(self) -> None:
        proc = self._proc
        assert proc is not None and proc.stdout is not None
        try:
            for line in proc.stdout:
                line = line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    continue
                mid = msg.get("id")
                if mid is not None:
                    with self._lock:
                        self._responses[mid] = msg
        except (ValueError, OSError):  # pragma: no cover - pipe closed on shutdown
            pass

    def _write(self, payload: dict[str, Any]) -> None:
        proc = self._proc
        assert proc is not None and proc.stdin is not None
        proc.stdin.write(json.dumps(payload) + "\n")
        proc.stdin.flush()

    def _request_blocking(
        self, method: str, params: dict[str, Any], timeout: float
    ) -> dict[str, Any]:
        with self._lock:
            self._id += 1
            rid = self._id
            # Hold the lock across the write so concurrent callers can't interleave
            # bytes on the shared stdin pipe and corrupt the JSON-RPC stream.
            self._write({"jsonrpc": "2.0", "id": rid, "method": method, "params": params})
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            with self._lock:
                if rid in self._responses:
                    return self._responses.pop(rid)
            if self._proc is not None and self._proc.poll() is not None:
                raise McpError(f"{self.server}: connection closed")
            time.sleep(0.1)
        raise McpError(f"{self.server}.{method}: timed out after {timeout}s")

    def _start_blocking(self) -> None:
        self._proc = subprocess.Popen(
            ["agency", "mcp", self.server, "--transport", "stdio"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
        )
        self._reader = threading.Thread(target=self._read_loop, daemon=True)
        self._reader.start()
        self._request_blocking(
            "initialize",
            {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "chronicle", "version": "0.1.0"},
            },
            timeout=30.0,
        )
        self._write({"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}})

    def _call_blocking(self, tool: str, arguments: dict[str, Any], timeout: float) -> str:
        resp = self._request_blocking(
            "tools/call", {"name": tool, "arguments": arguments}, timeout=timeout
        )
        if "error" in resp:
            err = resp["error"]
            raise McpError(f"{self.server}.{tool}: [{err.get('code')}] {err.get('message')}")
        content = resp.get("result", {}).get("content", [])
        parts = [
            c.get("text", "") for c in content if isinstance(c, dict) and c.get("type") == "text"
        ]
        return "\n".join(parts) if parts else json.dumps(resp.get("result", {}))

    def _close_blocking(self) -> None:
        proc = self._proc
        if proc is None:
            return
        with __import__("contextlib").suppress(Exception):
            if proc.stdin:
                proc.stdin.close()
        if proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(timeout=5.0)
            except (subprocess.TimeoutExpired, OSError):
                with __import__("contextlib").suppress(OSError):
                    proc.kill()

    # -- async surface -----------------------------------------------------

    async def ensure_started(self) -> None:
        async with self._init_lock:
            if self._initialized:
                return
            await asyncio.to_thread(self._start_blocking)
            self._initialized = True

    async def call_tool(self, tool: str, arguments: dict[str, Any], *, timeout: float) -> str:
        await self.ensure_started()
        return await asyncio.to_thread(self._call_blocking, tool, arguments, timeout)

    async def aclose(self) -> None:
        if self._closed:
            return
        self._closed = True
        await asyncio.to_thread(self._close_blocking)


class StdioMcpCaller:
    """Spawns and reuses one stdio MCP subprocess per server name."""

    def __init__(self) -> None:
        self._servers: dict[str, _StdioServer] = {}
        self._lock = asyncio.Lock()

    async def _get(self, server: str) -> _StdioServer:
        async with self._lock:
            srv = self._servers.get(server)
            if srv is None:
                srv = _StdioServer(server)
                self._servers[server] = srv
            return srv

    async def call_tool(
        self, server: str, tool: str, arguments: dict[str, Any], *, timeout: float = 120.0
    ) -> str:
        srv = await self._get(server)
        return await srv.call_tool(tool, arguments, timeout=timeout)

    async def aclose(self) -> None:
        for srv in self._servers.values():
            await srv.aclose()
        self._servers.clear()


# ---------------------------------------------------------------------------
# Manager-backed transport (production, reuses runtime's MCP connections)
# ---------------------------------------------------------------------------


class ManagerMcpCaller:
    """Calls MCP tools via the runtime's live :class:`MCPManager`."""

    def __init__(self, manager: Any) -> None:
        self._manager = manager

    async def call_tool(
        self, server: str, tool: str, arguments: dict[str, Any], *, timeout: float = 120.0
    ) -> str:
        error = await self._manager.connect_server(server)
        client = self._manager.get_client(server)
        if client is None:
            raise McpError(f"{server}: not connected ({error or 'unknown error'})")
        result = await client.call_tool(tool, arguments, timeout=timeout)
        if isinstance(result, str) and result.startswith("MCP error"):
            raise McpError(f"{server}.{tool}: {result}")
        return cast(str, result)

    async def aclose(self) -> None:  # pragma: no cover - manager owns lifecycle
        # The runtime owns the manager lifecycle; nothing to release here.
        logger.debug("ManagerMcpCaller.aclose() is a no-op; runtime owns the manager")
