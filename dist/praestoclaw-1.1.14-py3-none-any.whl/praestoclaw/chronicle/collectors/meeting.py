"""Meeting collector — archives the *spoken* layer of meetings via transcripts.

Teams chat collection only captures what people *typed* in a meeting's chat tab.
The actual verbal discussion — the user's status updates, decisions, follow-ups
said out loud — lives in the meeting transcript. This collector pulls that layer
so the daily report can reflect what was actually discussed and committed to.

Why transcripts (not Copilot AI recap): the ``GetOnlineMeetingAiInsights`` tool
only returns insight *record stubs* (id/createdDateTime/contentCorrelationId) with
no retrievable note/action-item body, so it can't feed the report. Transcripts
carry the real content and are speaker-attributed, which lets us detect whether
the signed-in user actually participated.

Access & relevance gating (no extra permissions needed):
  * meetings the user can't access (didn't organize / no transcript-sharing right)
    return ``403 Forbidden`` — naturally skipped;
  * broadcasts / sessions the user merely had on their calendar but didn't speak in
    are dropped by the *participation* check (their display name must appear as a
    transcript speaker);
  * recurring-series ``joinUrl``s resolve ``meeting.startDateTime`` to the series
    base occurrence, so we gate on the returned transcript's own
    ``createdDateTime`` (via ``_same_occurrence``) to keep the right daily
    occurrence while dropping a stale/foreign recap.

Best-effort: one meeting failing must not abort the others.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from loguru import logger

from praestoclaw.chronicle.identity import Identity
from praestoclaw.chronicle.mcp_caller import McpCaller, McpError
from praestoclaw.chronicle.store import ChronicleStore, SourceItem
from praestoclaw.chronicle.textutil import extract_json, parse_iso, strip_html

_MAX_MEETINGS = 25
_MAX_BODY_CHARS = 40000
_OCCURRENCE_TOLERANCE = timedelta(hours=12)
# The calendar MCP interprets query bounds as UTC but returns event dateTimes as
# naive mailbox-local wall-clock; widen the query so the precise local filtering
# in ``_select_candidates`` can't miss an edge occurrence.
_QUERY_PAD = timedelta(hours=12)
_VOICE_TAG = re.compile(r"<v\s+([^>]+?)>", re.IGNORECASE)


def _graph_dt(dt: datetime) -> str:
    return dt.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%S")


async def collect_meetings(
    caller: McpCaller,
    store: ChronicleStore,
    identity: Identity,
    *,
    since: datetime,
    until: datetime,
    tz: str = "UTC",
) -> dict[str, Any]:
    """Archive transcripts for meetings the user attended in [since, until)."""
    stats: dict[str, Any] = {
        "considered": 0,
        "transcripts": 0,
        "no_access": 0,
        "not_participated": 0,
        "wrong_occurrence": 0,
        "skipped": 0,
        "errors": [],
    }
    try:
        local_tz: Any = ZoneInfo(tz)
    except Exception:  # noqa: BLE001 - bad tz string falls back to system local
        local_tz = None

    args = {
        "startDateTime": _graph_dt(since - _QUERY_PAD),
        "endDateTime": _graph_dt(until + _QUERY_PAD),
        "orderby": "start/dateTime",
        "select": "subject,start,end,organizer,isOnlineMeeting,onlineMeeting,isCancelled,responseStatus",
        "top": 100,
    }
    try:
        raw = await caller.call_tool("calendar", "ListCalendarView", args, timeout=120.0)
    except McpError as exc:
        logger.warning("chronicle.meeting: ListCalendarView failed: {}", exc)
        stats["errors"].append(str(exc))
        return stats

    candidates = _select_candidates(_as_list(extract_json(raw)), since, until, local_tz)
    stats["considered"] = len(candidates)

    for subject, start_dt, join_url in candidates[:_MAX_MEETINGS]:
        try:
            body, reason = await _fetch_transcript(caller, join_url, start_dt, identity)
        except McpError as exc:
            logger.warning("chronicle.meeting: '{}' transcript failed: {}", subject, exc)
            stats["errors"].append(f"{subject}: {exc}")
            continue
        if not body:
            stats[reason] = stats.get(reason, 0) + 1
            continue

        store.upsert_item(
            SourceItem(
                source="meeting",
                external_id=f"{join_url}::{start_dt.date().isoformat()}::transcript",
                kind="meeting_transcript",
                chat_type="meeting",
                chat_topic=subject,
                created_at=start_dt.isoformat(),
                title=subject,
                body_text=body[:_MAX_BODY_CHARS],
                link=join_url,
                share_scope="personal",
                raw={"join_url": join_url, "kind": "meeting_transcript"},
            )
        )
        stats["transcripts"] += 1

    store.commit()
    return stats


def _select_candidates(
    events: list[dict[str, Any]],
    since: datetime,
    until: datetime,
    local_tz: Any = None,
) -> list[tuple[str, datetime, str]]:
    """Return (subject, start_dt, join_url) for ended online meetings to inspect.

    We keep every online meeting in the window except cancelled or explicitly
    declined ones. Real attendance/relevance is decided later by transcript access
    (403 → no access) and the participation check, because at large orgs people
    routinely attend meetings they never RSVP'd to. ``start_dt`` is returned as a
    true UTC instant so the occurrence gate compares like-for-like.
    """
    out: list[tuple[str, datetime, str]] = []
    seen: set[str] = set()
    for ev in events:
        if ev.get("isCancelled") or not ev.get("isOnlineMeeting"):
            continue
        response = ((ev.get("responseStatus") or {}).get("response") or "").strip().lower()
        if response == "declined":
            continue
        join_url = (ev.get("onlineMeeting") or {}).get("joinUrl")
        if not join_url:
            continue
        start_dt = _event_dt_utc(ev.get("start"), local_tz)
        end_dt = _event_dt_utc(ev.get("end"), local_tz) or start_dt
        if start_dt is None or start_dt < since or start_dt >= until:
            continue
        if end_dt and end_dt > until:  # hasn't ended within the window yet
            continue
        key = f"{join_url}::{start_dt.date().isoformat()}"
        if key in seen:
            continue
        seen.add(key)
        out.append((ev.get("subject") or "(no subject)", start_dt, join_url))
    return out


async def _fetch_transcript(
    caller: McpCaller,
    join_url: str,
    start_dt: datetime,
    identity: Identity,
) -> tuple[str, str]:
    """Return (body_text, reason). Empty body means nothing usable; reason explains why."""
    try:
        raw = await caller.call_tool(
            "calendar", "GetOnlineMeetingTranscripts", {"joinWebUrl": join_url}, timeout=180.0
        )
    except McpError as exc:
        logger.debug("chronicle.meeting: transcript call failed: {}", exc)
        return "", "no_access"
    if not raw or not isinstance(raw, str) or raw.lstrip().startswith("Error"):
        return "", "no_access"

    payload = extract_json(raw)
    if not isinstance(payload, dict):
        return "", "skipped"

    vtt, occurrence_dt = _pick_transcript(payload)
    if not vtt.strip():
        return "", "skipped"

    # A recurring series' joinUrl resolves ``meeting.startDateTime`` to the series
    # base occurrence (e.g. the first day), NOT the day we want. The transcript we
    # actually got back carries its own ``createdDateTime`` — gate on THAT so the
    # right daily occurrence passes while a stale/foreign recap is still rejected.
    if occurrence_dt is None:
        occurrence_dt = parse_iso((payload.get("meeting") or {}).get("startDateTime"))
    if not _same_occurrence(occurrence_dt, start_dt):
        return "", "wrong_occurrence"

    if not _user_participated(vtt, identity):
        return "", "not_participated"
    return _render_transcript(vtt), "transcripts"


def _same_occurrence(meeting_start: datetime | None, target_start: datetime) -> bool:
    """True if the transcript's meeting is (near) the target occurrence in time.

    Recurring-series joinUrls can resolve a transcript from a different (often the
    first) occurrence; a wide time tolerance accepts the right one while rejecting
    a recap from months/years away. Naive datetimes are treated as UTC (both
    sources — Graph meeting start and the calendar occurrence — emit UTC).
    """
    if meeting_start is None:
        return True  # tool didn't echo a start; accept rather than drop
    ms = meeting_start if meeting_start.tzinfo else meeting_start.replace(tzinfo=UTC)
    ts = target_start if target_start.tzinfo else target_start.replace(tzinfo=UTC)
    return abs(ms - ts) <= _OCCURRENCE_TOLERANCE


def _user_participated(text: str, identity: Identity) -> bool:
    """True if the signed-in user appears as a transcript speaker."""
    name = (identity.display_name or "").strip()
    if not name:
        return True  # can't tell; don't drop
    if name in text:
        return True
    parts = name.split()
    if len(parts) >= 2 and f"{parts[-1]}, {parts[0]}" in text:  # "Cheng, Rui"
        return True
    return False


def _pick_transcript(payload: dict[str, Any]) -> tuple[str, datetime | None]:
    """Return (vtt_text, occurrence_dt) for the transcript whose content we have.

    The MCP tool fills ``content`` only on ``selectedTranscript`` (the latest
    occurrence for a recurring series); ``allTranscripts`` entries are metadata
    stubs without bodies. We return that content plus its ``createdDateTime`` so
    the caller can verify it really is the occurrence we're after.
    """
    sel = payload.get("selectedTranscript")
    if isinstance(sel, dict):
        content = _dict_text(sel)
        if content.strip():
            return content, parse_iso(sel.get("createdDateTime"))
    # Legacy / alternate shapes: a transcript carrying inline content.
    for t in payload.get("allTranscripts") or []:
        if isinstance(t, dict):
            content = _dict_text(t)
            if content.strip():
                return content, parse_iso(t.get("createdDateTime"))
    # Last resort: plain-string transcript bodies (no occurrence date available).
    if isinstance(sel, str) and sel.strip():
        return sel, None
    allt = payload.get("allTranscripts")
    if isinstance(allt, list):
        for t in allt:
            if isinstance(t, str) and t.strip():
                return t, None
    return "", None


def _dict_text(node: dict[str, Any]) -> str:
    for key in ("content", "transcript", "vtt", "text"):
        val = node.get(key)
        if isinstance(val, str) and val.strip():
            return val
    return ""


def _render_transcript(vtt: str) -> str:
    """Turn WEBVTT into ``Speaker: utterance`` lines, dropping timestamps/cues."""
    # Convert voice tags <v Speaker>text</v> into a "Speaker: " prefix.
    text = _VOICE_TAG.sub(lambda m: f"\n{m.group(1).strip()}: ", vtt)
    text = text.replace("</v>", "")
    out: list[str] = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line == "WEBVTT" or "-->" in line or line.isdigit():
            continue
        out.append(strip_html(line))
    # Merge wrapped lines that belong to the previous speaker turn.
    merged: list[str] = []
    for line in out:
        if re.match(r"^[^:]{1,60}: ", line):
            merged.append(line)
        elif merged:
            merged[-1] += " " + line
        else:
            merged.append(line)
    return "\n".join(merged)


def _event_dt_utc(node: Any, local_tz: Any = None) -> datetime | None:
    """Parse a calendar event start/end node into a true UTC instant.

    The MCP returns ``dateTime`` as naive mailbox-local wall-clock paired with a
    ``timeZone`` name; we interpret a naive value as ``local_tz`` (the user's
    configured timezone) so comparisons against true-UTC bounds are correct.
    """
    if isinstance(node, dict):
        value = node.get("dateTime")
    else:
        value = node if isinstance(node, str) else None
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=local_tz) if local_tz is not None else dt.astimezone()
    return dt.astimezone(UTC)


def _as_list(payload: Any) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        return payload if isinstance(payload, list) else []
    for key in ("value", "events"):
        val = payload.get(key)
        if isinstance(val, list):
            return val
    return []
