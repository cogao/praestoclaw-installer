"""Teams collector — pulls all 1:1 / group / meeting chat messages in a window.

Two-stage algorithm (verified against a real 839-chat mailbox):
1. ``ListChats(fetchAllPages=true)`` → the user's full chat roster, then filter
   to chats whose ``lastMessagePreview`` is at/after the cutoff (cheap, no
   per-chat calls). This is complete: any chat active in the window is "recent"
   and therefore present.
2. For each active chat, page ``ListChatMessages`` newest-first via ``nextLink``
   until messages fall before the cutoff, archiving each into L1.

The Teams MCP has no server-side date filter, so filtering is client-side.
"""

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import Any

from loguru import logger

from praestoclaw.chronicle.identity import Identity
from praestoclaw.chronicle.mcp_caller import McpCaller
from praestoclaw.chronicle.store import ChronicleStore, SourceItem
from praestoclaw.chronicle.textutil import (
    classify_chat_type,
    extract_json,
    parse_iso,
    strip_html,
    teams_message_link,
)

_MAX_PAGES_PER_CHAT = 20
_MAX_RETRY_ROUNDS = 2  # extra passes over chats that fail (transient MCP timeouts)
_RETRY_BACKOFF_S = 5.0
_TEAMS_CONCURRENCY = 4  # parallel per-chat message pulls (MCP calls are rid-multiplexed)
_PAGE_TIMEOUT_S = 60.0  # per ListChatMessages call; a hung call is retried, not waited out


def _as_list(payload: Any, *keys: str) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        return []
    for key in keys:
        val = payload.get(key)
        if isinstance(val, list):
            return val
    return []


def _next_link(payload: Any) -> str | None:
    if not isinstance(payload, dict):
        return None
    return payload.get("nextLink") or payload.get("@odata.nextLink")


def _author(msg: dict[str, Any]) -> tuple[str | None, str | None]:
    frm = msg.get("from") or {}
    user = frm.get("user") or frm
    if not isinstance(user, dict):
        return None, None
    return user.get("id"), user.get("displayName")


async def collect_teams(
    caller: McpCaller,
    store: ChronicleStore,
    identity: Identity,
    *,
    since: datetime,
    until: datetime,
    tenant_id: str | None = None,
    skip_chat_ids: set[str] | None = None,
) -> dict[str, Any]:
    """Collect Teams messages in [since, until) into the archive.

    ``skip_chat_ids`` are hard-muted chats to not archive at all (rare); normal
    report-layer exclusions do NOT belong here — everything else is archived.
    """
    skip_chat_ids = skip_chat_ids or set()
    stats: dict[str, Any] = {"chats_total": 0, "chats_active": 0, "messages": 0, "errors": []}

    raw = await caller.call_tool("teams", "ListChats", {"fetchAllPages": True}, timeout=180.0)
    chats = _as_list(extract_json(raw), "chats", "value")
    stats["chats_total"] = len(chats)

    active: list[dict[str, Any]] = []
    for chat in chats:
        cid = chat.get("id")
        if not cid or cid in skip_chat_ids:
            continue
        preview = chat.get("lastMessagePreview") or {}
        dt = parse_iso(preview.get("createdDateTime"))
        if dt and dt >= since:
            active.append(chat)
    stats["chats_active"] = len(active)

    # Collect each active chat; retry chats that fail (e.g. MCP timeouts) across a
    # few rounds with backoff so transient flakiness doesn't drop messages. Within
    # each round, chats are pulled concurrently (bounded) — the MCP transport
    # multiplexes calls by request id, so this is safe and much faster than serial.
    sem = asyncio.Semaphore(_TEAMS_CONCURRENCY)

    async def _collect_one(chat: dict[str, Any]) -> tuple[dict[str, Any], int, str | None]:
        cid = chat["id"]
        ctype = classify_chat_type(cid)
        topic = chat.get("topic") or ""
        async with sem:
            try:
                count = await _collect_chat(
                    caller, store, identity, cid, ctype, topic, since, until, tenant_id
                )
                return chat, count, None
            except Exception as exc:  # noqa: BLE001 - isolate one chat's failure to stats["errors"]
                return chat, 0, str(exc)

    pending = active
    failed: dict[str, str] = {}
    for round_idx in range(_MAX_RETRY_ROUNDS + 1):
        results = await asyncio.gather(*[_collect_one(c) for c in pending])
        still_failed: list[dict[str, Any]] = []
        for chat, count, err in results:
            cid = chat["id"]
            if err is None:
                stats["messages"] += count
                failed.pop(cid, None)
            else:
                still_failed.append(chat)
                failed[cid] = err
        if not still_failed:
            break
        if round_idx < _MAX_RETRY_ROUNDS:
            logger.info(
                "chronicle.teams: {} chat(s) failed; retrying (round {}/{}) after backoff",
                len(still_failed),
                round_idx + 2,
                _MAX_RETRY_ROUNDS + 1,
            )
            await asyncio.sleep(_RETRY_BACKOFF_S * (round_idx + 1))
        pending = still_failed
    stats["errors"] = [{"chat_id": cid, "error": err} for cid, err in failed.items()]
    store.commit()
    return stats


async def _collect_chat(
    caller: McpCaller,
    store: ChronicleStore,
    identity: Identity,
    chat_id: str,
    chat_type: str,
    topic: str,
    since: datetime,
    until: datetime,
    tenant_id: str | None,
) -> int:
    args: dict[str, Any] = {"chatId": chat_id, "include": "reactions"}
    collected = 0
    for _ in range(_MAX_PAGES_PER_CHAT):
        raw = await caller.call_tool("teams", "ListChatMessages", args, timeout=_PAGE_TIMEOUT_S)
        page = extract_json(raw)
        messages = _as_list(page, "messages", "value")
        reached_old = False
        for msg in messages:
            dt = parse_iso(msg.get("createdDateTime"))
            if dt is None:
                continue
            if dt < since:
                reached_old = True
                continue
            if dt >= until:
                continue
            body_text = strip_html((msg.get("body") or {}).get("content"))
            author_id, author_name = _author(msg)
            # Skip empty system/event messages (membership changes, etc.)
            if not body_text and not author_id:
                continue
            msg_id = str(msg.get("id") or "")
            store.upsert_item(
                SourceItem(
                    source="teams",
                    external_id=f"{chat_id}/{msg_id}",
                    kind="teams_message",
                    chat_id=chat_id,
                    chat_type=chat_type,
                    chat_topic=topic,
                    thread_id=chat_id,
                    author_id=author_id,
                    author_name=author_name,
                    is_me=identity.is_me(author_id=author_id),
                    created_at=dt.isoformat(),
                    modified_at=msg.get("lastModifiedDateTime"),
                    title=topic or None,
                    body_text=body_text,
                    link=teams_message_link(chat_id, msg_id, tenant_id),
                    share_scope="personal" if chat_type == "oneOnOne" else "shareable",
                    raw=msg,
                )
            )
            collected += 1
        nxt = _next_link(page)
        if reached_old or not nxt:
            break
        args = {"chatId": chat_id, "nextLink": nxt}
    return collected
