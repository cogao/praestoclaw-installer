"""Azure DevOps collector — archives the user's ADO work surface via ``az`` CLI.

Uses the ``az`` CLI (azure-devops extension) with the ambient AAD login, so no
PAT is needed. Captures the scenarios the signed-in user actually works on:

  * **PRs they authored** — active (ongoing) plus any completed within the window
    → "what I did" / ongoing work;
  * **PRs awaiting their review** → todo signal;
  * **work items assigned to them** that changed in the window → done (if
    resolved/closed) or todo (if active/new);
  * **pipeline runs they manually triggered** in the window → build outcomes worth
    noticing (a failed manual run becomes a follow-up).

Best-effort: each query is isolated so one failing must not abort the others, and
the whole source no-ops gracefully when ``org``/``project`` are unconfigured.

Event-time note: ``items_in_range`` filters the report by ``created_at``, so
"current state" rows (active PRs, review requests) are stamped with ``until`` to
always surface in the latest report, while "completed in window" rows (closed
PRs, finished pipeline runs, changed work items) use their real event time.
"""

from __future__ import annotations

import asyncio
import json
import os
from datetime import datetime
from typing import Any
from urllib.parse import quote

from loguru import logger

from praestoclaw.chronicle.store import ChronicleStore, SourceItem
from praestoclaw.chronicle.textutil import parse_iso

_PR_CAP = 60
_WORKITEM_CAP = 100
_PIPELINE_SCAN = 80


async def _az_json(args: list[str], *, timeout: float = 90.0) -> Any:
    """Run an ``az`` command and parse its JSON stdout (best-effort).

    On Windows ``az`` is a ``.cmd`` shim that ``CreateProcess`` can't launch
    directly, so route through the command interpreter which resolves PATHEXT.
    """
    if os.name == "nt":
        comspec = os.environ.get("COMSPEC", "cmd.exe")
        argv = [comspec, "/c", "az", *args]
    else:
        argv = ["az", *args]
    proc = await asyncio.create_subprocess_exec(
        *argv, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except TimeoutError as exc:
        proc.kill()
        raise RuntimeError(f"az {' '.join(args[:3])}: timed out") from exc
    if proc.returncode != 0:
        raise RuntimeError(f"az {' '.join(args[:3])}: {err.decode('utf-8', 'replace')[:200]}")
    text = out.decode("utf-8", "replace").strip()
    return json.loads(text) if text else []


def _in_window(value: str | None, since: datetime, until: datetime) -> bool:
    dt = parse_iso(value)
    return dt is not None and since <= dt < until


def _iso(value: str | None) -> str:
    """ISO-normalize a timestamp the caller already gated on ``_in_window``.

    Returns "" if unparseable (callers only reach here for in-window values, so
    this is just to keep the return type non-optional for the type checker).
    """
    dt = parse_iso(value)
    return dt.isoformat() if dt else ""


def _my_vote(pr: dict[str, Any], me: str, display_name: str | None) -> int:
    """Return the signed-in user's reviewer vote on a PR (10/5 approve, 0 none,
    -5 waiting, -10 rejected); 0 if not found.
    """
    me_l = (me or "").lower()
    dn_l = (display_name or "").lower()
    for rv in pr.get("reviewers") or []:
        if not isinstance(rv, dict):
            continue
        uniq = (rv.get("uniqueName") or "").lower()
        disp = (rv.get("displayName") or "").lower()
        if (me_l and me_l == uniq) or (dn_l and dn_l == disp):
            try:
                return int(rv.get("vote") or 0)
            except (TypeError, ValueError):
                return 0
    return 0


async def collect_ado(
    store: ChronicleStore,
    identity: Any,
    *,
    since: datetime,
    until: datetime,
    org: str,
    project: str,
) -> dict[str, Any]:
    """Collect the user's Azure DevOps activity in [since, until)."""
    stats: dict[str, Any] = {
        "authored_prs": 0,
        "approved_prs": 0,
        "review_requests": 0,
        "work_items": 0,
        "pipeline_runs": 0,
        "errors": [],
    }
    if not org or not project:
        stats["skipped"] = "ado org/project not configured"
        return stats

    me = (getattr(identity, "mail", "") or "").strip()
    proj_q = quote(project)

    def _pr_link(repo: str, pr_id: Any) -> str:
        return f"{org}/{proj_q}/_git/{quote(repo)}/pullrequest/{pr_id}"

    base = ["--org", org, "--project", project, "-o", "json"]

    # 1) PRs I authored: active (ongoing) + completed within the window.
    if me:
        try:
            prs = await _az_json(
                [
                    "repos",
                    "pr",
                    "list",
                    *base,
                    "--creator",
                    me,
                    "--status",
                    "all",
                    "--top",
                    str(_PR_CAP),
                ]
            )
            for pr in prs if isinstance(prs, list) else []:
                status = (pr.get("status") or "").lower()
                pr_id = pr.get("pullRequestId")
                repo = (pr.get("repository") or {}).get("name", "")
                created = pr.get("creationDate")
                closed = pr.get("closedDate")
                if status == "active":
                    event_at = until.isoformat()
                elif status == "completed" and _in_window(closed, since, until):
                    event_at = _iso(closed)
                else:
                    continue  # abandoned, or completed outside the window
                store.upsert_item(
                    SourceItem(
                        source="ado",
                        external_id=f"pr:{pr_id}",
                        kind="pr",
                        author_name="me",
                        is_me=True,
                        created_at=event_at,
                        modified_at=closed or created,
                        title=f"[{status}] PR {pr_id}: {pr.get('title', '')}",
                        body_text=f"[{repo}] PR {pr_id} ({status}): {pr.get('title', '')}",
                        link=_pr_link(repo, pr_id),
                        chat_topic=repo,
                        share_scope="shareable",
                        raw=pr,
                    )
                )
                stats["authored_prs"] += 1
        except (RuntimeError, json.JSONDecodeError) as exc:
            logger.warning("chronicle.ado: authored PR list failed: {}", exc)
            stats["errors"].append(f"authored_prs: {exc}")

    # 2) PRs where I'm a reviewer (status all): split by my vote into
    #    - approved by me (vote >= 5): "what I did" — merged in window or still open;
    #    - still awaiting my review (active, no vote): a todo signal.
    if me:
        try:
            prs = await _az_json(
                [
                    "repos",
                    "pr",
                    "list",
                    *base,
                    "--reviewer",
                    me,
                    "--status",
                    "all",
                    "--top",
                    str(_PR_CAP),
                ]
            )
            for pr in prs if isinstance(prs, list) else []:
                pr_id = pr.get("pullRequestId")
                repo = (pr.get("repository") or {}).get("name", "")
                author = (pr.get("createdBy") or {}).get("displayName", "")
                if author == identity.display_name:  # my own PR, not a review task
                    continue
                status = (pr.get("status") or "").lower()
                closed = pr.get("closedDate")
                my_vote = _my_vote(pr, me, identity.display_name)
                if my_vote >= 5:  # approved / approved-with-suggestions
                    if status == "completed":
                        if not _in_window(closed, since, until):
                            continue
                        event_at = _iso(closed)
                        body = f"[{repo}] PR {pr_id} by {author} — I approved, merged: {pr.get('title', '')}"
                        title = f"[approved·merged] PR {pr_id}: {pr.get('title', '')}"
                    elif status == "active":
                        event_at = until.isoformat()
                        body = f"[{repo}] PR {pr_id} by {author} — I approved, pending merge: {pr.get('title', '')}"
                        title = f"[approved·pending] PR {pr_id}: {pr.get('title', '')}"
                    else:
                        continue
                    store.upsert_item(
                        SourceItem(
                            source="ado",
                            external_id=f"pr-approved:{pr_id}",
                            kind="pr_approved",
                            author_name=author,
                            is_me=True,
                            created_at=event_at,
                            modified_at=closed or pr.get("creationDate"),
                            title=title,
                            body_text=body,
                            link=_pr_link(repo, pr_id),
                            chat_topic=repo,
                            share_scope="shareable",
                            raw=pr,
                        )
                    )
                    stats["approved_prs"] += 1
                elif status == "active" and my_vote == 0:  # still needs my review
                    store.upsert_item(
                        SourceItem(
                            source="ado",
                            external_id=f"pr-review:{pr_id}",
                            kind="pr_review_requested",
                            author_name=author,
                            created_at=until.isoformat(),
                            title=f"Review requested: PR {pr_id}",
                            body_text=f"[{repo}] PR {pr_id} by {author} awaiting your review: {pr.get('title', '')}",
                            link=_pr_link(repo, pr_id),
                            chat_topic=repo,
                            share_scope="shareable",
                            raw=pr,
                        )
                    )
                    stats["review_requests"] += 1
        except (RuntimeError, json.JSONDecodeError) as exc:
            logger.warning("chronicle.ado: reviewer PR list failed: {}", exc)
            stats["errors"].append(f"review_requests: {exc}")

    # 3) Work items assigned to me, changed within the window.
    try:
        since_date = since.date().isoformat()
        wiql = (
            "SELECT [System.Id], [System.Title], [System.State], [System.WorkItemType], "  # noqa: S608
            "[System.ChangedDate] FROM WorkItems WHERE [System.AssignedTo] = @Me "
            f"AND [System.ChangedDate] >= '{since_date}' "
            "ORDER BY [System.ChangedDate] DESC"
        )
        rows = await _az_json(
            ["boards", "query", "--org", org, "--project", project, "--wiql", wiql, "-o", "json"]
        )
        for row in (rows if isinstance(rows, list) else [])[:_WORKITEM_CAP]:
            fields = row.get("fields") or {}
            wid = fields.get("System.Id") or row.get("id")
            changed = fields.get("System.ChangedDate")
            if not _in_window(changed, since, until):
                continue
            wtype = fields.get("System.WorkItemType", "Work Item")
            state = fields.get("System.State", "")
            title = fields.get("System.Title", "")
            store.upsert_item(
                SourceItem(
                    source="ado",
                    external_id=f"wi:{wid}",
                    kind="work_item",
                    is_me=True,
                    created_at=_iso(changed),
                    modified_at=changed,
                    title=f"{wtype} #{wid} [{state}]: {title}",
                    body_text=f"{wtype} #{wid} ({state}) assigned to me: {title}",
                    link=f"{org}/{proj_q}/_workitems/edit/{wid}",
                    chat_topic=wtype,
                    share_scope="personal",
                    raw=fields,
                )
            )
            stats["work_items"] += 1
    except (RuntimeError, json.JSONDecodeError) as exc:
        logger.warning("chronicle.ado: work-item query failed: {}", exc)
        stats["errors"].append(f"work_items: {exc}")

    # 4) Pipeline runs I MANUALLY triggered within the window.
    if me:
        try:
            runs = await _az_json(
                [
                    "pipelines",
                    "runs",
                    "list",
                    *base,
                    "--query-order",
                    "FinishTimeDesc",
                    "--top",
                    str(_PIPELINE_SCAN),
                ]
            )
            for run in runs if isinstance(runs, list) else []:
                if (run.get("reason") or "").lower() != "manual":
                    continue
                req = (run.get("requestedFor") or {}).get("uniqueName", "")
                if me.lower() not in (req or "").lower():
                    continue
                finished = run.get("finishTime") or run.get("startTime") or run.get("queueTime")
                if not _in_window(finished, since, until):
                    continue
                run_id = run.get("id")
                defn = (run.get("definition") or {}).get("name", "pipeline")
                result = run.get("result") or run.get("status") or ""
                branch = run.get("sourceBranch", "")
                store.upsert_item(
                    SourceItem(
                        source="ado",
                        external_id=f"run:{run_id}",
                        kind="pipeline_run",
                        is_me=True,
                        created_at=_iso(finished),
                        modified_at=finished,
                        title=f"Pipeline '{defn}' [{result}]",
                        body_text=f"Manual run of '{defn}' on {branch}: {result}",
                        link=f"{org}/{proj_q}/_build/results?buildId={run_id}",
                        chat_topic=defn,
                        share_scope="personal",
                        raw=run,
                    )
                )
                stats["pipeline_runs"] += 1
        except (RuntimeError, json.JSONDecodeError) as exc:
            logger.warning("chronicle.ado: pipeline runs list failed: {}", exc)
            stats["errors"].append(f"pipeline_runs: {exc}")

    store.commit()
    return stats
