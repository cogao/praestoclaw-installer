"""Chronicle collectors — code-driven, deterministic data collection.

Each collector pulls from one source into the L1 archive (``source_items``),
deduplicating by ``(source, external_id)``. Collectors are watermark-driven and
best-effort: a failure in one source must not abort the others (the pipeline
isolates them).
"""

from __future__ import annotations

__all__ = [
    "collect_teams",
    "collect_github",
    "collect_email",
    "collect_calendar",
    "collect_meetings",
    "collect_ado",
]

from praestoclaw.chronicle.collectors.ado import collect_ado
from praestoclaw.chronicle.collectors.calendar import collect_calendar
from praestoclaw.chronicle.collectors.github import collect_github
from praestoclaw.chronicle.collectors.mail import collect_email
from praestoclaw.chronicle.collectors.meeting import collect_meetings
from praestoclaw.chronicle.collectors.teams import collect_teams
