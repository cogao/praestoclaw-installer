"""Calendar collector — archives calendar events via the ``calendar`` MCP server.

``ListCalendarView`` expands recurring events into instances, which is what we
want for "today's meetings". Used both to archive yesterday's events and to fetch
today's agenda for the morning report.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any
from zoneinfo import ZoneInfo

from loguru import logger

from praestoclaw.chronicle.mcp_caller import McpCaller, McpError
from praestoclaw.chronicle.store import ChronicleStore, SourceItem
from praestoclaw.chronicle.textutil import extract_json, strip_html


def _event_dt_utc(node: Any, local_tz: ZoneInfo | None) -> datetime | None:
    """Parse a calendar event ``start``/``end`` node into a true UTC instant.

    ``ListCalendarView`` returns ``dateTime`` as a naive mailbox-local wall clock
    paired with a ``timeZone`` name. We interpret a naive value as ``local_tz``
    (the user's configured timezone) and convert to UTC so the stored ``created_at``
    is a real instant and UTC range queries in ``items_in_range`` are correct.
    """
    if isinstance(node, dict):
        value = node.get("dateTime")
    else:
        value = node if isinstance(node, str) else None
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=local_tz) if local_tz is not None else dt.astimezone()
    return dt.astimezone(UTC)


async def collect_calendar(
    caller: McpCaller,
    store: ChronicleStore,
    *,
    start: datetime,
    end: datetime,
    tz: str | None = None,
    archive: bool = True,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Fetch calendar events in [start, end).

    ``tz`` is the user's IANA timezone, used to interpret mailbox-local event
    timestamps and to render local-time display strings. Returns (stats, events).
    When ``archive`` is True the events are also written to L1; the returned event
    dicts are always available for the report stage.
    """
    local_tz: ZoneInfo | None = None
    if tz:
        try:
            local_tz = ZoneInfo(tz)
        except Exception:  # noqa: BLE001 - bad tz string falls back to system local
            logger.warning("chronicle.calendar: bad timezone {!r}, using system local", tz)
    stats: dict[str, Any] = {"events": 0, "errors": []}
    # The calendar MCP interprets query bounds as UTC (matching the meeting
    # collector); send UTC explicitly so the window is correct on non-UTC hosts.
    args = {
        "startDateTime": start.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%S"),
        "endDateTime": end.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%S"),
        "orderby": "start/dateTime",
        "select": "subject,start,end,organizer,attendees,location,bodyPreview,"
        "webLink,isOnlineMeeting,onlineMeeting,isCancelled,responseStatus",
        "top": 100,
    }
    try:
        raw = await caller.call_tool("calendar", "ListCalendarView", args, timeout=120.0)
    except McpError as exc:
        logger.warning("chronicle.calendar: ListCalendarView failed: {}", exc)
        stats["errors"].append(str(exc))
        return stats, []

    payload = extract_json(raw)
    events = _as_list(payload)
    out: list[dict[str, Any]] = []
    for event in events:
        start_dt = _event_dt_utc(event.get("start"), local_tz)
        if start_dt is None:
            continue
        organizer = (event.get("organizer") or {}).get("emailAddress") or {}
        attendees = [
            (a.get("emailAddress") or {}).get("name", "")
            for a in (event.get("attendees") or [])
            if isinstance(a, dict)
        ]
        location = (event.get("location") or {}).get("displayName", "")
        join_url = (event.get("onlineMeeting") or {}).get("joinUrl", "")
        end_dt = _event_dt_utc(event.get("end"), local_tz) or start_dt
        # start_dt/end_dt are true UTC instants (used for storage + range queries);
        # render the display strings back in the user's local timezone.
        start_local = start_dt.astimezone(local_tz) if local_tz else start_dt.astimezone()
        end_local = end_dt.astimezone(local_tz) if local_tz else end_dt.astimezone()
        # Label the timezone with the one the display strings are actually
        # rendered in (the configured IANA tz, or the host's local zone), not the
        # Graph payload's start.timeZone (often "UTC") — otherwise downstream
        # formatting mislabels local times as UTC.
        tz_label = tz if local_tz is not None else (start_local.tzname() or "")
        summary = {
            "subject": event.get("subject"),
            "start": start_dt.isoformat(),
            "end": end_dt.isoformat(),
            "start_display": start_local.strftime("%Y-%m-%d %H:%M"),
            "end_display": end_local.strftime("%H:%M"),
            "timezone": tz_label,
            "organizer": organizer.get("name", ""),
            "attendees": attendees,
            "location": location,
            "join_url": join_url,
            "is_online": event.get("isOnlineMeeting"),
            "body": strip_html(event.get("bodyPreview", "")),
            "link": event.get("webLink"),
        }
        out.append(summary)
        if archive:
            store.upsert_item(
                SourceItem(
                    source="calendar",
                    external_id=str(
                        event.get("id") or f"{event.get('subject')}/{start_dt.isoformat()}"
                    ),
                    kind="calendar_event",
                    author_name=organizer.get("name", ""),
                    created_at=start_dt.isoformat(),
                    title=event.get("subject"),
                    body_text=(
                        f"{event.get('subject', '')}\n"
                        f"{start_local.strftime('%Y-%m-%d %H:%M')} @ {location}\n"
                        f"organizer: {organizer.get('name', '')}; "
                        f"attendees: {', '.join(a for a in attendees if a)}\n"
                        f"{strip_html(event.get('bodyPreview', ''))}"
                    ),
                    link=event.get("webLink"),
                    share_scope="personal",
                    raw=summary,
                )
            )
            stats["events"] += 1
    store.commit()
    return stats, out


def _as_list(payload: Any) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        return payload if isinstance(payload, list) else []
    for key in ("value", "events"):
        val = payload.get(key)
        if isinstance(val, list):
            return val
    return []
