"""GitHub collector — archives the user's PR activity via the ``gh`` CLI.

Uses ``gh`` (already authenticated in this environment) rather than an MCP
server. Captures PRs the user authored/updated in the window (for "what I did")
and PRs awaiting the user's review (for the todo list).
"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime
from typing import Any

from loguru import logger

from praestoclaw.chronicle.store import ChronicleStore, SourceItem


async def _gh_json(args: list[str], *, timeout: float = 60.0) -> Any:
    proc = await asyncio.create_subprocess_exec(
        "gh", *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except TimeoutError as exc:
        proc.kill()
        raise RuntimeError(f"gh {' '.join(args)}: timed out") from exc
    if proc.returncode != 0:
        raise RuntimeError(f"gh {' '.join(args)}: {err.decode('utf-8', 'replace')[:200]}")
    text = out.decode("utf-8", "replace").strip()
    return json.loads(text) if text else []


async def collect_github(
    store: ChronicleStore, *, since: datetime, until: datetime
) -> dict[str, Any]:
    """Collect the user's GitHub PR activity in [since, until)."""
    stats: dict[str, Any] = {"authored": 0, "review_requested": 0, "errors": []}
    since_date = since.date().isoformat()
    fields = "number,title,url,updatedAt,createdAt,state,repository,isDraft"

    # PRs I authored and touched in the window.
    try:
        prs = await _gh_json(
            [
                "search",
                "prs",
                "--author=@me",
                f"--updated=>={since_date}",
                "--limit=50",
                "--json",
                fields,
            ]
        )
        for pr in prs:
            updated = pr.get("updatedAt")
            dt = _parse(updated)
            if dt is None or not (since <= dt < until):
                continue
            repo = (pr.get("repository") or {}).get("nameWithOwner", "")
            num = pr.get("number")
            store.upsert_item(
                SourceItem(
                    source="github",
                    external_id=f"{repo}#{num}",
                    kind="pr",
                    author_name="me",
                    is_me=True,
                    created_at=dt.isoformat(),
                    modified_at=updated,
                    title=f"PR #{num}: {pr.get('title', '')}",
                    body_text=f"[{repo}] PR #{num} ({pr.get('state')}): {pr.get('title', '')}",
                    link=pr.get("url"),
                    chat_topic=repo,
                    share_scope="shareable",
                    raw=pr,
                )
            )
            stats["authored"] += 1
    except (RuntimeError, json.JSONDecodeError) as exc:
        logger.warning("chronicle.github: authored search failed: {}", exc)
        stats["errors"].append(str(exc))

    # PRs awaiting my review (open) — todo signal, archived as of "now".
    try:
        prs = await _gh_json(
            [
                "search",
                "prs",
                "--review-requested=@me",
                "--state=open",
                "--limit=50",
                "--json",
                fields,
            ]
        )
        for pr in prs:
            repo = (pr.get("repository") or {}).get("nameWithOwner", "")
            num = pr.get("number")
            store.upsert_item(
                SourceItem(
                    source="github",
                    external_id=f"review-req:{repo}#{num}",
                    kind="pr_review_requested",
                    is_me=False,
                    created_at=until.isoformat(),
                    title=f"Review requested: PR #{num}",
                    body_text=f"[{repo}] PR #{num} awaiting your review: {pr.get('title', '')}",
                    link=pr.get("url"),
                    chat_topic=repo,
                    share_scope="shareable",
                    raw=pr,
                )
            )
            stats["review_requested"] += 1
    except (RuntimeError, json.JSONDecodeError) as exc:
        logger.warning("chronicle.github: review-requested search failed: {}", exc)
        stats["errors"].append(str(exc))

    store.commit()
    return stats


def _parse(value: str | None) -> datetime | None:
    from praestoclaw.chronicle.textutil import parse_iso

    return parse_iso(value)
