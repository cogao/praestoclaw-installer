"""Email collector — archives recent mail via the ``mail`` MCP server.

Best-effort: pulls messages received in the window using an OData filter. Email
is one of three sources; a failure here must not block Teams/GitHub collection.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from loguru import logger

from praestoclaw.chronicle.identity import Identity
from praestoclaw.chronicle.mcp_caller import McpCaller, McpError
from praestoclaw.chronicle.store import ChronicleStore, SourceItem
from praestoclaw.chronicle.textutil import extract_json, parse_iso, strip_html

_MAX_PAGES = 5


def _graph_dt(dt: datetime) -> str:
    # Graph's OData filter compares against UTC; the trailing "Z" marks the
    # value as UTC, so normalize to UTC regardless of the host timezone (a naive
    # datetime is assumed to already be UTC, matching how watermarks are stored).
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


async def collect_email(
    caller: McpCaller,
    store: ChronicleStore,
    identity: Identity,
    *,
    since: datetime,
    until: datetime,
) -> dict[str, Any]:
    """Collect emails received in [since, until) into the archive."""
    stats: dict[str, Any] = {"messages": 0, "errors": []}
    flt = (
        f"?$filter=receivedDateTime ge {_graph_dt(since)}"
        f"&$orderby=receivedDateTime desc&$top=15"
        f"&$select=id,subject,from,receivedDateTime,bodyPreview,webLink,isRead,flag,importance"
    )
    args: dict[str, Any] = {"queryParameters": flt, "preferTextBody": True}
    for _ in range(_MAX_PAGES):
        try:
            raw = await caller.call_tool(
                "mail", "SearchMessagesQueryParameters", args, timeout=120.0
            )
        except McpError as exc:
            logger.warning("chronicle.email: search failed: {}", exc)
            stats["errors"].append(str(exc))
            break
        if raw.lstrip().startswith("Error"):
            logger.warning("chronicle.email: mail server returned error: {}", raw[:200])
            stats["errors"].append(raw[:200])
            break
        page = extract_json(raw)
        page = _unwrap(page)
        messages = _as_list(page)
        reached_old = False
        for msg in messages:
            dt = parse_iso(msg.get("receivedDateTime"))
            if dt is None:
                continue
            if dt < since:
                reached_old = True
                continue
            if dt >= until:
                continue
            sender = (msg.get("from") or {}).get("emailAddress") or {}
            sender_addr = sender.get("address", "")
            flag = (msg.get("flag") or {}).get("flagStatus")
            body = (
                msg.get("bodyPreview") or msg.get("body", {}).get("content", "")
                if isinstance(msg.get("body"), dict)
                else (msg.get("bodyPreview") or "")
            )
            store.upsert_item(
                SourceItem(
                    source="email",
                    external_id=str(msg.get("id") or ""),
                    kind="email",
                    author_id=sender_addr,
                    author_name=sender.get("name", sender_addr),
                    is_me=identity.is_me(email=sender_addr),
                    created_at=dt.isoformat(),
                    title=msg.get("subject"),
                    body_text=strip_html(body),
                    link=msg.get("webLink"),
                    share_scope="personal",
                    raw={
                        "isRead": msg.get("isRead"),
                        "flag": flag,
                        "importance": msg.get("importance"),
                        "subject": msg.get("subject"),
                    },
                )
            )
            stats["messages"] += 1
        nxt = page.get("@odata.nextLink") if isinstance(page, dict) else None
        if reached_old or not nxt:
            break
        args = {"nextLink": nxt, "preferTextBody": True}
    store.commit()
    return stats


def _unwrap(payload: Any) -> Any:
    """Some mail MCP tools wrap the Graph response as ``{"rawResponse": "<json>"}``."""
    if isinstance(payload, dict) and isinstance(payload.get("rawResponse"), str):
        inner = extract_json(payload["rawResponse"])
        if inner is not None:
            return inner
    return payload


def _as_list(payload: Any) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        return payload if isinstance(payload, list) else []
    for key in ("value", "messages"):
        val = payload.get(key)
        if isinstance(val, list):
            return val
    return []
