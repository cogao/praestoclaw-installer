"""MCP health monitor - periodic ping and auto-reconnect with backoff."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from loguru import logger

from praestoclaw.mcp.types import ConnectionState

if TYPE_CHECKING:
    from praestoclaw.mcp.manager import MCPManager


class MCPHealthMonitor:
    """Monitors MCP server connections and auto-reconnects on failure."""

    def __init__(
        self,
        manager: MCPManager,
        *,
        interval: int = 300,
        max_reconnect_attempts: int = 5,
        backoff_base: float = 2.0,
        ping_timeout: float = 10.0,
    ) -> None:
        self._manager = manager
        self._interval = interval
        self._max_reconnect_attempts = max_reconnect_attempts
        self._backoff_base = backoff_base
        self._ping_timeout = ping_timeout
        self._tasks: dict[str, asyncio.Task[None]] = {}
        self._reconnect_tasks: dict[str, asyncio.Task[None]] = {}
        self._reconnect_attempts: dict[str, int] = {}
        self._wake_events: dict[str, asyncio.Event] = {}

    async def start_monitoring(self, name: str) -> None:
        """Start health monitoring for a connected server."""
        existing = self._tasks.get(name)
        if existing is not None and not existing.done():
            return
        # Clean up stale (done/failed) task before restarting
        self._tasks.pop(name, None)
        self._reconnect_attempts[name] = 0
        # Persistent wake event for this server — reused across loop iterations
        # so trigger_reconnect() signals are never lost in the window between
        # one event being cleared and the next being stored.
        self._wake_events[name] = asyncio.Event()
        task = asyncio.create_task(self._monitor_loop(name))
        self._tasks[name] = task
        logger.debug(f"Health monitor started for '{name}'")

    def stop_monitoring(self, name: str) -> None:
        """Stop health monitoring and any in-progress reconnect for a server."""
        try:
            current = asyncio.current_task()
        except RuntimeError:
            current = None

        task = self._tasks.get(name)
        if task is not None:
            if task.done():
                self._tasks.pop(name, None)
            elif task is not current:
                self._tasks.pop(name, None)
                task.cancel()

        rtask = self._reconnect_tasks.get(name)
        if rtask is not None:
            if rtask.done():
                self._reconnect_tasks.pop(name, None)
            elif rtask is not current:
                self._reconnect_tasks.pop(name, None)
                rtask.cancel()

        self._reconnect_attempts.pop(name, None)
        self._wake_events.pop(name, None)

    def trigger_reconnect(self, name: str) -> None:
        """Wake the monitor loop immediately (skip remaining sleep interval).

        Called by MCPClient._receive_loop when it detects an unexpected
        connection loss, so reconnect begins right away rather than waiting
        up to 300 s for the next scheduled health-check ping.

        The wake event is persistent (created once per server in start_monitoring)
        so this signal is never lost in the window between loop iterations.
        """
        event = self._wake_events.get(name)
        if event is not None:
            event.set()

    def reconnect_now(self, name: str) -> None:
        """Bypass health-check ping and reconnect immediately.

        Called by MCPClient.probe_and_reconnect after confirming the server is
        unresponsive (probe already did a 5 s list_tools that timed out).
        Skips the redundant check_server ping that trigger_reconnect would
        cause, and spawns a dedicated reconnect task so the monitor loop is not
        involved (avoids self-cancellation).

        Live tool adapters are unpublished immediately so the LLM cannot call
        them while the server is being reconnected. The manager preserves the
        user's desired-active MCP tools and restores them after a successful
        reconnect.
        """
        if self._manager._states.get(name) != ConnectionState.CONNECTED:
            return  # Already reconnecting/failed — nothing to do
        logger.warning(f"MCP probe failed for '{name}', reconnecting immediately")
        self._manager._states[name] = ConnectionState.RECONNECTING

        # Unregister tools immediately — before the reconnect task runs —
        # so the LLM's function-calling schema no longer includes them.
        # connect_server(force=True) will also call unregister_prefix, but
        # that happens seconds later; clearing here closes the gap.
        self._manager.unpublish_server_tools(name, remember_desired=True)

        # Cancel the monitor loop explicitly. If it's inside check_server()
        # (up to 10 s wait), relying on the state re-check after check_server
        # returns is racy: if reconnect completes fast, state goes back to
        # CONNECTED before the old loop re-checks, causing a second reconnect.
        # Cancelling guarantees the old loop exits immediately.
        task = self._tasks.pop(name, None)
        if task and not task.done():
            task.cancel()
        task = asyncio.create_task(self._reconnect_task(name), name=f"mcp-reconnect-{name}")
        self._reconnect_tasks[name] = task

    async def _reconnect_task(self, name: str) -> None:
        """Standalone reconnect task spawned by reconnect_now (probe path).

        Reconnect restores both the server process and any MCP tools the user
        had already exposed through tools(name="MCP_<server>").
        """
        try:
            success = await self._reconnect(name)
            if not success:
                self._manager._states[name] = ConnectionState.FAILED
                logger.error(
                    f"MCP server '{name}' failed after {self._max_reconnect_attempts} reconnect attempts"
                )
        except asyncio.CancelledError:
            pass
        finally:
            self._reconnect_tasks.pop(name, None)

    def stop_all(self) -> None:
        """Stop all health monitors and in-progress reconnects."""
        # Union of both dicts: a probe reconnect may have popped the server
        # from _tasks while _reconnect_tasks still has an active task.
        for name in list(set(self._tasks) | set(self._reconnect_tasks)):
            self.stop_monitoring(name)

    async def check_server(self, name: str) -> bool:
        """Ping a server. Returns True if healthy."""
        client = self._manager._clients.get(name)
        if client is None or not client.is_connected:
            return False
        try:
            await asyncio.wait_for(client.list_tools(), timeout=self._ping_timeout)
            return True
        except Exception:
            # If the client was replaced while we were waiting (a probe-triggered
            # reconnect completed during our 10 s ping), treat the server as
            # healthy — a reconnect already happened, starting another would
            # kill the process that was just created.
            if self._manager._clients.get(name) is not client:
                return True
            return False

    async def _monitor_loop(self, name: str) -> None:
        """Background loop: periodically check server health."""
        try:
            while True:
                # Sleep for the health-check interval using the persistent wake
                # event (created in start_monitoring). Reusing one event instead
                # of creating a new one each iteration eliminates the race window
                # where trigger_reconnect() fires between the old event being
                # removed and the new one being registered.
                wake = self._wake_events.get(name)
                if wake is None:
                    break  # monitor was stopped externally
                wake.clear()
                try:
                    await asyncio.wait_for(wake.wait(), timeout=self._interval)
                    # Woken early by trigger_reconnect — skip straight to check.
                except TimeoutError:
                    pass

                if self._manager._states.get(name) != ConnectionState.CONNECTED:
                    break

                healthy = await self.check_server(name)
                if healthy:
                    self._reconnect_attempts[name] = 0
                    continue

                # Re-check state: reconnect_now() may have set RECONNECTING
                # while we were inside check_server(), which already spawned a
                # _reconnect_task. Proceeding here would start a second
                # concurrent reconnect.
                if self._manager._states.get(name) != ConnectionState.CONNECTED:
                    break

                # Server failed - attempt reconnect. Unpublish live adapters
                # immediately so LLM stops calling a dead client; desired-active
                # tools are restored if reconnect succeeds.
                self._manager.unpublish_server_tools(name, remember_desired=True)
                logger.warning(f"MCP health check failed for '{name}', attempting reconnect")
                self._manager._states[name] = ConnectionState.RECONNECTING
                success = await self._reconnect(name)
                if not success:
                    self._manager._states[name] = ConnectionState.FAILED
                    logger.error(
                        f"MCP server '{name}' failed after {self._max_reconnect_attempts} reconnect attempts"
                    )
                # Exit regardless: on failure state=FAILED, on success connect_server
                # started a fresh monitor task — this old loop should not continue.
                break
        except asyncio.CancelledError:
            pass

    async def _reconnect(self, name: str) -> bool:
        """Attempt reconnection with exponential backoff.

        Reconnect restores the server process and re-activates the MCP tools
        that were active before the transient disconnect (via the manager's
        remembered desired-active set).
        """
        # Move the current monitor/reconnect task into _reconnect_tasks before
        # connect_server(force=True) calls stop_monitoring(). stop_monitoring()
        # skips cancelling its own current task, but explicit user disconnects
        # still see and cancel this in-flight reconnect from another task.
        current = asyncio.current_task()
        self._tasks.pop(name, None)
        if current is not None:
            self._reconnect_tasks[name] = current

        try:
            for attempt in range(self._max_reconnect_attempts):
                delay = self._backoff_base**attempt
                logger.info(
                    f"MCP reconnect '{name}': attempt {attempt + 1}/{self._max_reconnect_attempts}, waiting {delay:.1f}s"
                )
                await asyncio.sleep(delay)

                try:
                    await self._manager.connect_server(
                        name,
                        force=True,
                        auto_describe=False,
                        preserve_desired=True,
                    )
                    if self._manager._states.get(name) == ConnectionState.CONNECTED:
                        self._manager.restore_desired_tools(name)
                        logger.info(f"MCP server '{name}' reconnected (attempt {attempt + 1})")
                        self._reconnect_attempts[name] = 0
                        return True
                except Exception as exc:
                    logger.warning(f"MCP reconnect '{name}' attempt {attempt + 1} failed: {exc}")

            return False
        finally:
            if current is not None and self._reconnect_tasks.get(name) is current:
                self._reconnect_tasks.pop(name, None)
