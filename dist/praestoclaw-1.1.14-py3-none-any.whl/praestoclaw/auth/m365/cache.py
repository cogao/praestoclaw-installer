"""Persistent encrypted cache for Teams RT strategy.

Stores the most recently observed Teams refresh token plus the latest minted
access token (per scope) so subsequent process starts can skip Edge launch
and reuse the cached AT until expiry.

On-disk layout: a single file at ``<auth_dir>/m365_auth_cache.bin`` containing
the WP1-encrypted JSON below. Encryption reuses
:func:`praestoclaw.security.secrets.encrypt_at_rest`.

Schema (version 1)::

    {
      "version": 1,
      "rt": {
        "client_id": "...", "home_account_id": "...", "tenant_id": "...",
        "secret": "...", "environment": "login.windows.net",
        "updated_at": 1777000000.0
      } | null,
      "access_tokens": {
        "<scope>": {"token": "...", "expires_at": 1777003600.0}
      }
    }
"""

from __future__ import annotations

import json
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from loguru import logger

from praestoclaw.auth.m365.extractor import RefreshTokenRecord
from praestoclaw.security.secrets import _atomic_write_file, decrypt_at_rest, encrypt_at_rest

CACHE_VERSION = 1
CACHE_FILENAME = "m365_auth_cache.bin"  # backwards-compat constant; prefer cache_filename(tenant)


def cache_filename(tenant_id: str | None) -> str:
    """Per-tenant cache filename so multiple Entra tenants don't collide.

    Mirrors the ``token_cache_<client_id[:8]>.bin`` pattern used by the
    MSAL caches in :mod:`praestoclaw.utils.auth`. When *tenant_id* is
    falsy (no cloud config wired) we fall back to the legacy unprefixed
    name so the on-disk layout is unchanged for that case.
    """
    if not tenant_id:
        return CACHE_FILENAME
    return f"m365_auth_cache_{tenant_id[:8]}.bin"


@dataclass(slots=True)
class CachedAccessToken:
    token: str
    expires_at: float  # unix epoch seconds

    def is_fresh(self, *, skew_s: int = 60) -> bool:
        return time.time() < self.expires_at - skew_s


class M365AuthCache:
    """Thread-safe, file-backed cache for one Teams RT + N access tokens."""

    def __init__(self, cache_path: Path) -> None:
        self._path = cache_path
        self._lock = threading.Lock()
        self._rt: RefreshTokenRecord | None = None
        self._rt_updated_at: float = 0.0
        self._access_tokens: dict[str, CachedAccessToken] = {}
        self._loaded = False

    # ── Public API ───────────────────────────────────────────────────────────

    def load(self) -> None:
        """Read cache file from disk. Idempotent — safe to call repeatedly."""
        with self._lock:
            if self._loaded:
                return
            self._loaded = True
            if not self._path.exists():
                return
            try:
                raw = self._path.read_bytes()
            except OSError as exc:
                logger.debug("m365_auth cache read failed: {}", exc)
                return
            decrypted = decrypt_at_rest(raw)
            if not decrypted:
                return
            try:
                doc = json.loads(decrypted.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                logger.warning("m365_auth cache parse failed ({}); discarding", exc)
                return
            if not isinstance(doc, dict) or doc.get("version") != CACHE_VERSION:
                logger.debug("m365_auth cache version mismatch; discarding")
                return
            rt_dict = doc.get("rt")
            if isinstance(rt_dict, dict):
                try:
                    self._rt = RefreshTokenRecord(
                        client_id=str(rt_dict["client_id"]),
                        home_account_id=str(rt_dict["home_account_id"]),
                        tenant_id=str(rt_dict["tenant_id"]),
                        secret=str(rt_dict["secret"]),
                        environment=str(rt_dict.get("environment") or "login.windows.net"),
                    )
                    self._rt_updated_at = float(rt_dict.get("updated_at") or 0.0)
                except (KeyError, ValueError, TypeError) as exc:
                    logger.debug("m365_auth cache rt entry malformed: {}", exc)
                    self._rt = None
            ats = doc.get("access_tokens")
            if isinstance(ats, dict):
                for scope, val in ats.items():
                    if not isinstance(val, dict):
                        continue
                    tok = val.get("token")
                    exp = val.get("expires_at")
                    if isinstance(tok, str) and isinstance(exp, (int, float)):
                        self._access_tokens[scope] = CachedAccessToken(tok, float(exp))

    def get_refresh_token(self) -> RefreshTokenRecord | None:
        with self._lock:
            return self._rt

    def get_access_token(self, scope: str, *, skew_s: int = 60) -> str | None:
        """Return a cached AT for *scope* if still fresh, else None."""
        with self._lock:
            cached = self._access_tokens.get(scope)
            if cached and cached.is_fresh(skew_s=skew_s):
                return cached.token
            return None

    def update_refresh_token(self, rt: RefreshTokenRecord) -> None:
        with self._lock:
            self._rt = rt
            self._rt_updated_at = time.time()
        self._persist()

    def update_access_token(self, scope: str, token: str, expires_at: float) -> None:
        with self._lock:
            self._access_tokens[scope] = CachedAccessToken(token, expires_at)
        self._persist()

    def clear_refresh_token(self) -> None:
        """Wipe RT + ATs. Called when AAD says the RT is permanently invalid."""
        with self._lock:
            self._rt = None
            self._rt_updated_at = 0.0
            self._access_tokens.clear()
        self._persist()

    # ── Internal ─────────────────────────────────────────────────────────────

    def _persist(self) -> None:
        with self._lock:
            doc = {
                "version": CACHE_VERSION,
                "rt": (
                    {**asdict(self._rt), "updated_at": self._rt_updated_at}
                    if self._rt is not None
                    else None
                ),
                "access_tokens": {
                    scope: {"token": at.token, "expires_at": at.expires_at}
                    for scope, at in self._access_tokens.items()
                },
            }
        try:
            payload = json.dumps(doc, ensure_ascii=False).encode("utf-8")
            encrypted = encrypt_at_rest(payload, strict=True)
            self._path.parent.mkdir(parents=True, exist_ok=True)
            _atomic_write_file(self._path, encrypted)
        except OSError as exc:
            logger.warning("m365_auth cache persist failed: {}", exc)
