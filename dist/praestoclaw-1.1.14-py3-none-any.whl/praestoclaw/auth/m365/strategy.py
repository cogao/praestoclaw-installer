"""Token strategy that borrows Teams Web's MSAL session.

Two entry points, with deliberately separate UX guarantees:

  ``try_silent``       — never opens a browser. Tries:
                           A1 in-memory AT cache
                           A2 on-disk AT cache
                           B  HTTP refresh of cached RT
                         Returns None when none of the above produce a token.
                         Used by the silent chain in ``CloudChannel``.

  ``try_interactive``  — A1/A2/B fast paths first, then visible Edge launch
                         if those fail (Phase C). Used when the user
                         explicitly chose "Microsoft 365 sign-in" in the
                         interactive login menu.

Mirrors Kosmos's split between silent acquisition (``BrowserAuthProvider``
phases A/B/C-via-CDP) and the user-facing ``ensureBrowserLogin`` phase D.
We don't implement CDP-attach because PraestoClaw is a daemon and
``localhost:9222`` is rarely available; visible Edge launch via Playwright
is reserved for the interactive entry point.

The strategy owns the encrypted on-disk cache so all phases agree on which
RT/AT to use and persist mutations atomically.
"""

from __future__ import annotations

import asyncio
import time
from pathlib import Path

import httpx
from loguru import logger

from praestoclaw.auth.m365.cache import M365AuthCache, cache_filename
from praestoclaw.auth.m365.extractor import pick_best_refresh_token
from praestoclaw.auth.m365.playwright_session import (
    PlaywrightSessionError,
    acquire_refresh_tokens,
)
from praestoclaw.auth.m365.refresh import (
    RefreshTokenInvalidError,
    RefreshTransientError,
    swap_for_access_token,
)


class M365AuthStrategy:
    """Coordinator for the Microsoft 365 sign-in path.

    Two entry points: :meth:`try_silent` (no UI, never opens a browser)
    and :meth:`try_interactive` (may open a visible Edge window).

    *enabled* gates the entire strategy. When False both methods return None.

    *allow_browser_launch* gates the visible Edge launch in
    :meth:`try_interactive`. When False, ``try_interactive`` runs the same
    cheap A/B paths but returns None instead of opening Edge.
    """

    def __init__(
        self,
        *,
        cache_dir: Path,
        profile_dir: Path,
        enabled: bool = True,
        allow_browser_launch: bool = True,
        login_timeout_s: int = 120,
        preferred_tenant: str | None = None,
    ) -> None:
        self._enabled = enabled
        self._allow_browser_launch = allow_browser_launch
        self._login_timeout_s = login_timeout_s
        self._preferred_tenant = preferred_tenant
        cache_path = cache_dir / cache_filename(preferred_tenant)
        self._cache = M365AuthCache(cache_path)
        self._profile_dir = profile_dir
        self._lock = asyncio.Lock()
        self._first_run = not cache_path.exists()

    @property
    def first_run(self) -> bool:
        """True when no cache exists — caller may want to show a consent prompt."""
        return self._first_run

    async def try_silent(self, target_scope: str) -> str | None:
        """Return a fresh access token for *target_scope* or None.

        Silent path — never opens any browser:

          A1 in-mem AT → A2 disk AT → B HTTP refresh of cached RT → give up.

        Mirrors Kosmos's split between silent acquisition (cache + HTTP)
        and the user-facing ``ensureBrowserLogin`` step. A visible Edge
        window is reserved for :meth:`try_interactive`.

        Side effects: the disk cache is updated whenever a fresh AT or
        rotated RT is observed. On permanent RT invalidation the cache is
        wiped so the next call falls through cleanly.
        """
        if not self._enabled:
            return None

        async with self._lock:
            self._cache.load()

            cached_at = self._cache.get_access_token(target_scope)
            if cached_at:
                logger.info("[m365_auth] phase A hit (cached AT, fresh)")
                return cached_at

            cached_rt = self._cache.get_refresh_token()
            if cached_rt is not None:
                token = await self._phase_b(cached_rt, target_scope)
                if token:
                    return token

            logger.info("[m365_auth] silent paths exhausted; caller will fall back")
            return None

    async def try_interactive(self, target_scope: str) -> str | None:
        """Return a fresh access token, allowing a visible Edge window.

        Used by :class:`CloudChannel` when the user selects
        "Microsoft 365 sign-in" in the interactive login menu.

        Tries the cheap A/B paths first so the user is not forced to look
        at Edge if a cached RT still works. Only when those fail do we
        launch a visible Edge window pointed at Teams Web.

        Returns ``None`` when the user closes the window, the timeout
        expires, or Playwright fails to launch.
        """
        if not self._enabled or not self._allow_browser_launch:
            return None

        async with self._lock:
            self._cache.load()

            # Try cheap paths first.
            cached_at = self._cache.get_access_token(target_scope)
            if cached_at:
                logger.info("[m365_auth] interactive: cached AT still fresh, skipping Edge")
                return cached_at
            cached_rt = self._cache.get_refresh_token()
            if cached_rt is not None:
                token = await self._phase_b(cached_rt, target_scope)
                if token:
                    logger.info("[m365_auth] interactive: HTTP refresh succeeded, skipping Edge")
                    return token

            # Visible Edge — first user interaction or RT chain dead.
            return await self._phase_c(target_scope, headless=False)

    async def shutdown(self) -> None:
        """Release any held resources. No-op today; reserved for future use."""

    # ── Phases ───────────────────────────────────────────────────────────────

    async def _phase_b(self, rt, target_scope: str) -> str | None:
        logger.debug(
            "[m365_auth] phase B request: client_id={} tenant={} scope={}",
            rt.client_id,
            rt.tenant_id,
            target_scope[:80],
        )
        try:
            result = await swap_for_access_token(rt, target_scope)
        except RefreshTokenInvalidError as exc:
            logger.warning("[m365_auth] phase B refused ({}); clearing cache", exc.error_code)
            self._cache.clear_refresh_token()
            return None
        except RefreshTransientError as exc:
            logger.warning("[m365_auth] phase B transient: {}", exc)
            return None
        except httpx.HTTPError as exc:
            logger.warning("[m365_auth] phase B HTTP error: {}", exc)
            return None

        # Persist rotated RT + new AT
        if result.new_refresh_token.secret != rt.secret:
            self._cache.update_refresh_token(result.new_refresh_token)
        self._cache.update_access_token(target_scope, result.access_token, result.expires_at)
        logger.info(
            "[m365_auth] phase B success scope={} exp_in={}s",
            target_scope[:60],
            int(result.expires_at - time.time()),
        )
        return result.access_token

    async def _phase_c(self, target_scope: str, *, headless: bool) -> str | None:
        try:
            records = await acquire_refresh_tokens(
                self._profile_dir,
                headless=headless,
                timeout_s=self._login_timeout_s,
            )
        except PlaywrightSessionError as exc:
            logger.warning("[m365_auth] phase C launch failed: {}", exc)
            return None
        except Exception as exc:  # noqa: BLE001 — defensive: never let Playwright kill us
            logger.warning("[m365_auth] phase C unexpected error: {}", exc)
            return None

        if not records:
            return None

        # When multiple accounts are cached, prefer the one matching the
        # tenant we expect (mirrors Kosmos's EXPECTED_TENANT_ID filter at
        # TeamsTokenExtractor.ts:165-183).
        rt = pick_best_refresh_token(records, preferred_tenant=self._preferred_tenant) or records[0]
        self._cache.update_refresh_token(rt)
        self._first_run = False  # cache now populated
        return await self._phase_b(rt, target_scope)
