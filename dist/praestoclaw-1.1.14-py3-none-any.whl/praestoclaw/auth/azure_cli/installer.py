"""Cross-platform installer for the Azure CLI.

Detects the host platform and picks an installation method that targets the
system PATH (so no shell-rc surgery is required afterward):

- macOS:   `brew install azure-cli` (installs Homebrew first if missing).
           Drops the binary in `/opt/homebrew/bin` (Apple Silicon) or
           `/usr/local/bin` (Intel) — both on the default PATH.
- Linux:   distro package manager. apt/dnf/yum/zypper/pacman supported;
           the deb/rpm flows use the official microsoft.com install scripts
           that invoke sudo internally.
- Windows: `winget install -e --id Microsoft.AzureCLI` — drops the binary in
           the system-wide path.

Refuses to run without a tty so we never hang waiting on a hidden sudo /
admin password prompt — callers should detect that case and print the
manual command instead.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
from dataclasses import dataclass
from typing import Any

from loguru import logger


@dataclass
class InstallPlan:
    """A concrete plan for installing az on this host."""

    label: str  # human-readable, e.g. "Homebrew"
    cmd: list[str]  # argv passed to subprocess
    needs_sudo: bool  # True when the plan invokes sudo internally
    size_mb: int  # rough estimate, shown in the prompt
    est_seconds: int  # rough estimate, shown in the prompt
    post_hint: str | None = None  # extra line shown after install


# ── Platform-specific plans ──────────────────────────────────────────────────


def _macos_plan() -> InstallPlan:
    """macOS: brew when present, otherwise install brew first then azure-cli."""
    if shutil.which("brew"):
        return InstallPlan(
            label="Homebrew",
            cmd=["brew", "install", "azure-cli"],
            needs_sudo=False,
            size_mb=500,
            est_seconds=180,
        )
    # No brew yet — install it first, then `brew install azure-cli`. The brew
    # installer prompts for the admin password once to set up
    # /opt/homebrew permissions; this is normal macOS dev experience.
    chained = (
        '/bin/bash -c "$(curl -fsSL '
        'https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" '
        "&& "
        "for p in /opt/homebrew/bin/brew /usr/local/bin/brew; do "
        '[ -x "$p" ] && eval "$($p shellenv)" && break; '
        "done "
        "&& brew install azure-cli"
    )
    return InstallPlan(
        label="Install Homebrew, then Azure CLI",
        cmd=["bash", "-c", chained],
        needs_sudo=False,
        size_mb=600,
        est_seconds=300,
        post_hint="Homebrew was installed alongside Azure CLI.",
    )


def _detect_linux_pm() -> str | None:
    """Return the first detected package manager name, or None."""
    for pm in ("apt-get", "dnf", "yum", "zypper", "pacman"):
        if shutil.which(pm):
            return pm
    return None


def _linux_plan() -> InstallPlan | None:
    """Linux: distro package manager; None when nothing supported."""
    pm = _detect_linux_pm()
    if pm == "apt-get":
        return InstallPlan(
            label="apt (official Microsoft Deb script)",
            cmd=[
                "bash",
                "-c",
                "curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash",
            ],
            needs_sudo=True,
            size_mb=100,
            est_seconds=60,
        )
    if pm in ("dnf", "yum"):
        return InstallPlan(
            label=f"{pm} (official Microsoft Rpm script)",
            cmd=[
                "bash",
                "-c",
                "curl -sL https://aka.ms/InstallAzureCLIRpm | sudo bash",
            ],
            needs_sudo=True,
            size_mb=100,
            est_seconds=60,
        )
    if pm == "zypper":
        return InstallPlan(
            label="zypper",
            cmd=["sudo", "zypper", "install", "-y", "azure-cli"],
            needs_sudo=True,
            size_mb=100,
            est_seconds=60,
        )
    if pm == "pacman":
        return InstallPlan(
            label="pacman",
            cmd=["sudo", "pacman", "-S", "--noconfirm", "azure-cli"],
            needs_sudo=True,
            size_mb=100,
            est_seconds=60,
        )
    return None


_WIN_PLAN = InstallPlan(
    label="winget install Microsoft.AzureCLI",
    cmd=[
        "winget",
        "install",
        "-e",
        "--id",
        "Microsoft.AzureCLI",
        "--silent",
        "--accept-package-agreements",
        "--accept-source-agreements",
        "--disable-interactivity",
    ],
    needs_sudo=False,
    size_mb=200,
    est_seconds=120,
)


# ── Public API ───────────────────────────────────────────────────────────────


def _try_fixup_path_for_az() -> bool:
    """Probe well-known install locations and prepend whichever holds az.

    Both ``brew install`` (macOS, when /opt/homebrew/bin is missing from a
    pruned PATH) and ``winget install`` (Windows, where the persistent PATH
    is updated but the running process's PATH was captured at startup) can
    leave ``az`` on disk while ``shutil.which`` returns None. This probes
    the standard install locations and prepends whichever holds ``az`` so
    subsequent ``shutil.which("az")`` calls succeed in the same process.

    Returns True if we mutated PATH (i.e. found az in a known location).
    Idempotent — safe to call repeatedly.
    """
    if shutil.which("az") is not None:
        return False

    candidates: list[str]
    binary: str
    if sys.platform == "darwin":
        candidates = ["/opt/homebrew/bin", "/usr/local/bin"]
        binary = "az"
    elif sys.platform == "win32":
        # Read env vars directly — `os.path.expandvars` does NOT expand
        # `%VAR%` form when invoked from a non-cmd shell (notably git bash,
        # where bash already stripped the % expansion before exec).
        # `os.environ` is populated by Python itself from the Windows API
        # so it works regardless of parent shell.
        program_files = os.environ.get("ProgramFiles", r"C:\Program Files")
        program_files_x86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
        local_app_data = os.environ.get("LocalAppData", os.path.expanduser(r"~\AppData\Local"))
        candidates = [
            rf"{program_files}\Microsoft SDKs\Azure\CLI2\wbin",
            rf"{program_files_x86}\Microsoft SDKs\Azure\CLI2\wbin",
            rf"{local_app_data}\Microsoft\WinGet\Links",
        ]
        binary = "az.cmd"
    else:
        return False

    for d in candidates:
        if os.path.isfile(os.path.join(d, binary)):
            os.environ["PATH"] = f"{d}{os.pathsep}{os.environ.get('PATH', '')}"
            return True
    return False


def is_az_installed() -> bool:
    """Return True when an ``az`` binary is on PATH.

    Also tries to fix up PATH first — handles the case where a previous
    `pc init` install left az on disk but the current process's PATH was
    captured before that install.
    """
    if shutil.which("az") is not None:
        return True
    _try_fixup_path_for_az()
    return shutil.which("az") is not None


def detect_install_plan() -> InstallPlan | None:
    """Pick an InstallPlan for the current platform, or None when unsupported."""
    sysname = sys.platform
    if sysname == "darwin":
        return _macos_plan()
    if sysname.startswith("linux"):
        return _linux_plan()
    if sysname == "win32":
        if shutil.which("winget"):
            return _WIN_PLAN
        return None
    return None


def install_az(plan: InstallPlan, *, console: Any | None = None) -> bool:
    """Run the install plan with output streamed live. Return True on success.

    Refuses to run when stdin is not a tty — sudo prompts (Linux) and the
    Homebrew installer's admin password prompt would hang otherwise. Callers
    should detect that case and print the command for manual execution.
    """
    if not sys.stdin.isatty():
        logger.warning("[azure_cli] no tty — refusing to run install command")
        return False

    if console is not None:
        try:
            console.print(f"  [dim]Running:[/dim] {' '.join(plan.cmd)}")
        except Exception:
            pass

    # Suppress winget's "Found ... / Downloading ... / This application is
    # licensed ..." chatter — it adds noise without conveying anything the
    # user can act on. Buffer output and reprint only when the install fails.
    try:
        result = subprocess.run(
            plan.cmd,
            check=False,
            env=os.environ.copy(),
            capture_output=True,
            text=True,
        )
    except FileNotFoundError as exc:
        logger.error("[azure_cli] install launch failed: {}", exc)
        return False
    except KeyboardInterrupt:
        logger.warning("[azure_cli] install interrupted by user")
        return False

    if result.returncode != 0:
        # winget exits with 0x8A150109 (-2147024657 / 2316632107) when the
        # package is already installed and at the latest version. Treat as
        # success — the binary is on disk, we just don't need to download.
        if sys.platform == "win32" and (result.returncode & 0xFFFFFFFF) == 0x8A150109:
            logger.info("[azure_cli] winget reports already at latest version")
        else:
            logger.warning("[azure_cli] install exited with code {}", result.returncode)
            if console is not None and (result.stdout or result.stderr):
                try:
                    console.print(result.stdout or "")
                    console.print(result.stderr or "")
                except Exception:
                    pass
            return False

    if console is not None and plan.post_hint:
        try:
            console.print(f"  [dim]{plan.post_hint}[/dim]")
        except Exception:
            pass

    # On macOS / Windows the binary may be on disk but not on the running
    # process's PATH yet (winget updates persistent PATH only; brew runs
    # fine but PATH may be pruned). Probe standard locations and prepend
    # them so the strategy can find az immediately.
    _try_fixup_path_for_az()

    return shutil.which("az") is not None


def platform_summary() -> str:
    """Short string used in error messages and logs (e.g. 'macOS arm64')."""
    return f"{platform.system()} {platform.machine()}"
