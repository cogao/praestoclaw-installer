"""Sign-in menu UI — provider-aware.

The menu accepts a list of :class:`AuthProvider` instances and shows their
``display_label`` to the user. Selection returns the chosen provider (or
None for "skip"). The menu does NOT run authentication itself — the caller
invokes ``provider.interactive_login()`` on the returned object.

Adapted from ``utils/auth.py:_arrow_menu`` + ``prompt_login_method`` but
operating on the new ``AuthProvider`` protocol instead of bare strings.
"""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

from rich.console import Console
from rich.panel import Panel

if TYPE_CHECKING:
    from praestoclaw.auth.base import AuthProvider


_console = Console()


def show_login_menu(
    providers: list[AuthProvider],
    *,
    default: AuthProvider | None = None,
    title: str = "Cloud Sign-in",
    subtitle: str | None = None,
) -> AuthProvider | None:
    """Show the sign-in menu and return the chosen provider.

    Returns ``None`` when the user skips. Always appends a "Skip" option
    after the providers, so the caller does not need to manage it.

    *default* highlights one provider initially; if not in *providers* it's
    ignored. Non-interactive environments (no tty) auto-select Skip.
    """
    if subtitle is None:
        subtitle = (
            "Choose how to sign in with your work account.\n\n"
            "Credentials are encrypted locally and never uploaded.\n"
            "Run [cyan]pc secrets list[/cyan] to manage."
        )

    _console.print(
        Panel(
            f"[bold]{subtitle}[/bold]" if "\n" not in subtitle else subtitle,
            title=title,
            border_style="cyan",
        )
    )

    options: list[tuple[str, str]] = [(p.name, p.display_label) for p in providers]
    options.append(("__skip__", "Skip for now"))

    default_index = 0
    if default is not None:
        for i, p in enumerate(providers):
            if p.name == default.name:
                default_index = i
                break

    chosen_key = _arrow_menu(options, default=default_index)
    if chosen_key == "__skip__":
        return None
    for p in providers:
        if p.name == chosen_key:
            return p
    return None


def _arrow_menu(
    options: list[tuple[str, str]],
    *,
    default: int = 0,
) -> str:
    """Arrow-key menu — list of ``(key, label)``. Returns the chosen key.

    Falls through to selecting the last option when stdin is not a tty,
    so CI / piped invocations don't hang on a phantom prompt.
    """
    selected = default
    hint = "\033[90m  Up/Down switch  Enter confirm  Esc skip\033[0m"

    def _draw(initial: bool = False) -> None:
        buf: list[str] = []
        if not initial:
            buf.append(f"\r\033[{len(options) + 1}A")
        for i, (_, label) in enumerate(options):
            marker = ">" if i == selected else " "
            if i == selected:
                buf.append(f"\033[K  \033[1;36m{marker} {label}\033[0m\n")
            else:
                buf.append(f"\033[K  \033[37m{marker} {label}\033[0m\n")
        buf.append(f"\033[K{hint}\n")
        sys.stdout.write("".join(buf))
        sys.stdout.flush()

    from praestoclaw.utils.input import flush_stdin, is_tty, read_key_blocking

    if not is_tty():
        selected = len(options) - 1
        _console.print(f"  [dim](non-interactive: defaulting to {options[selected][1]})[/dim]")
        return options[selected][0]

    # Discard any keystrokes typed while the previous step was running
    # (e.g. an Enter pressed while waiting for `az login` to complete)
    # so we don't auto-confirm this menu.
    flush_stdin()

    sys.stdout.write("\033[?25l")  # hide cursor
    _draw(initial=True)

    try:
        while True:
            key = read_key_blocking()
            if key == "enter":
                break
            if key == "esc":
                selected = len(options) - 1
                break
            if key == "up":
                selected = (selected - 1) % len(options)
                _draw()
            elif key == "down":
                selected = (selected + 1) % len(options)
                _draw()
    except (EOFError, KeyboardInterrupt, OSError):
        selected = len(options) - 1
    finally:
        sys.stdout.write("\033[?25h")  # show cursor
        sys.stdout.flush()

    return options[selected][0]
