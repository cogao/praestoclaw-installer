"""Canonical tool-call / tool-result sanitizer (Hermes-style).

Single source of truth for ensuring conversation history has valid
tool_call ↔ tool_result pairing before sending to any LLM provider.

Used by:
  - loop_v2._assemble_messages() — pre-call sanitization
  - compressor — post-compression repair
  - context.build_messages() — v1 assembly
  - memory — history sanitization

Strategy (ordered local pairing — matching Hermes agent):
  1. Walk messages sequentially
  2. When an assistant message with tool_calls is found:
     a. Validate each tool_call structure (id, function.name, arguments)
     b. Look ahead at *consecutive* tool messages that follow
     c. Match tool results to tool_calls by tool_call_id (local only)
     d. For matched tool_calls: keep both the call and its result
     e. For unmatched tool_calls: stub (stub_missing=True) or strip (False)
     f. If no tool_calls survive: demote to plain text or drop
  3. Tool messages not consumed by a preceding assistant group → orphaned → drop
"""

from __future__ import annotations

import re
from typing import Any

from loguru import logger

# Stub content injected for tool_calls whose result was lost
# (crash, compaction, provider timeout, etc.)
_STUB_RESULT = (
    "[tool result unavailable — execution was interrupted "
    "or result was lost during context compression]"
)

_TOOL_NAME_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def is_provider_safe_tool_name(name: str) -> bool:
    """Return True if *name* is safe for all configured provider APIs.

    OpenAI / GitHub Responses API rejects function-call input items whose
    ``name`` contains characters outside this conservative shape. Use this
    for both durable history sanitization and live LLMResponse filtering so
    pseudo-tools such as ``antml:thinking`` never reach execution or replay.
    """
    return bool(_TOOL_NAME_RE.fullmatch(name))


def _is_valid_tool_call(tc: Any) -> bool:
    """Check if a single tool_call entry is structurally valid for LLM providers."""
    if not isinstance(tc, dict):
        return False
    tc_id = tc.get("id")
    if not tc_id or not isinstance(tc_id, str):
        return False
    fn = tc.get("function")
    if not isinstance(fn, dict):
        return False
    if not fn.get("name") or not isinstance(fn["name"], str):
        return False
    # Provider APIs reject function/tool names outside this conservative
    # OpenAI/Responses-compatible shape. Claude-family models may emit
    # pseudo-tool names such as ``antml:thinking``; if those enter durable
    # history and we later fail over to a Responses API model, the request
    # is rejected with e.g. ``Invalid input[i].name``. Treat such entries
    # as malformed so they are stripped with their paired tool result.
    if not is_provider_safe_tool_name(fn["name"]):
        return False
    # arguments must be a string (JSON) or dict
    args = fn.get("arguments")
    if args is not None and not isinstance(args, (str, dict)):
        return False
    return True


def sanitize_tool_messages(
    messages: list[dict[str, Any]],
    *,
    stub_missing: bool = True,
) -> list[dict[str, Any]]:
    """Sanitize tool_call / tool_result pairing using ordered local matching.

    Walks messages sequentially. For each assistant message with tool_calls,
    looks ahead at *consecutive* tool messages to find local matches.
    This prevents stale/orphaned tool results from being misattributed to
    a later assistant message that happens to share the same tool_call_id.

    Args:
        messages: Conversation history (may contain system/user/assistant/tool).
        stub_missing: If True, insert stub tool-result messages for tool_calls
            that have no matching result (Hermes-style). If False, strip the
            unmatched tool_call entries instead (lighter, used by compressor).

    Returns:
        A new list with valid pairing. Original list is not mutated.
    """
    result: list[dict[str, Any]] = []
    stubs_added = 0
    orphans_dropped = 0
    calls_stripped = 0

    # Global tool_use id dedup across the whole conversation. The
    # Anthropic /v1/messages endpoint (and the GitHub Copilot
    # OpenAI→Anthropic shim that fronts ``github/claude-*``) requires
    # each tool_use id to be unique; if the same id ever appears in two
    # assistant turns, the shim collapses the corresponding tool_result
    # blocks into a single user message and the request fails with
    # "Found multiple tool_result blocks with id: …". This can happen
    # when a previous run persisted a duplicate to disk before the
    # provider-side dedup landed. We always keep the *first* occurrence
    # and drop later assistant tool_calls (and their orphaned results)
    # that re-use the same id.
    global_seen_ids: set[str] = set()

    i = 0
    while i < len(messages):
        msg = messages[i]
        role = msg.get("role")

        if role == "assistant" and msg.get("tool_calls"):
            original_tcs = msg["tool_calls"]

            # Step 1: validate structure of each tool_call, and dedupe
            # by id (locally within this assistant turn AND globally
            # across earlier turns). See comment on ``global_seen_ids``
            # above for why cross-turn dedup is required.
            valid_tcs: list[dict[str, Any]] = []
            seen_ids: set[str] = set()
            for tc in original_tcs:
                if not _is_valid_tool_call(tc):
                    continue
                tc_id = tc["id"]
                if tc_id in seen_ids or tc_id in global_seen_ids:
                    continue
                seen_ids.add(tc_id)
                valid_tcs.append(tc)
            if len(valid_tcs) < len(original_tcs):
                calls_stripped += len(original_tcs) - len(valid_tcs)
            global_seen_ids.update(seen_ids)

            # Step 2: look ahead at consecutive tool messages (local pairing)
            j = i + 1
            local_results: dict[str, dict[str, Any]] = {}  # tc_id → tool msg
            while j < len(messages) and messages[j].get("role") == "tool":
                tc_id = messages[j].get("tool_call_id", "")
                if tc_id:
                    local_results[tc_id] = messages[j]
                j += 1

            # Step 3: determine which tool_calls to keep
            if stub_missing:
                kept_tcs = valid_tcs  # keep all valid, stub missing
            else:
                kept_tcs = [tc for tc in valid_tcs if tc["id"] in local_results]

            if not kept_tcs:
                # No valid tool_calls remain — demote or drop
                content = msg.get("content") or ""
                if content:
                    result.append({"role": "assistant", "content": content})
                # else: drop entirely
                # Also drop the trailing tool messages (they're orphaned)
                orphans_dropped += len(local_results)
                i = j
                continue

            # Step 4: build sanitized assistant message
            if len(kept_tcs) != len(original_tcs):
                msg = {**msg, "tool_calls": kept_tcs}
            result.append(msg)

            # Step 5: emit tool results in tool_call order
            kept_ids = {tc["id"] for tc in kept_tcs}
            for tc in kept_tcs:
                tc_id = tc["id"]
                if tc_id in local_results:
                    result.append(local_results[tc_id])
                elif stub_missing:
                    fn = tc.get("function", {})
                    tool_name = fn.get("name", "unknown") if isinstance(fn, dict) else "unknown"
                    stub: dict[str, Any] = {
                        "role": "tool",
                        "tool_call_id": tc_id,
                        "content": f"[{tool_name}] {_STUB_RESULT}",
                        "_stub": True,
                    }
                    result.append(stub)
                    stubs_added += 1

            # Count orphaned tool results (local results not claimed by any kept tc)
            for tc_id in local_results:
                if tc_id not in kept_ids:
                    orphans_dropped += 1

            i = j  # skip past the tool messages we consumed

        elif role == "tool":
            # Tool message not preceded by an assistant with tool_calls → orphaned
            orphans_dropped += 1
            i += 1

        else:
            result.append(msg)
            i += 1

    if stubs_added or orphans_dropped or calls_stripped:
        logger.info(
            "Tool sanitizer: {} stub(s) added, {} orphan(s) dropped, {} tool_call(s) stripped (malformed or duplicate id)",
            stubs_added,
            orphans_dropped,
            calls_stripped,
        )

    return result
