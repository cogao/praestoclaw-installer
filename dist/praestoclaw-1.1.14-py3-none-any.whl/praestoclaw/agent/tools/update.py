"""
UpdateCheckTool — standard-tier tool for checking PraestoClaw updates.

Available to the LLM on demand (user can ask about version/upgrade status).
Also called by the heartbeat cron job (HEARTBEAT.md enables it via tools()).
"""

from __future__ import annotations

import asyncio
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.risk import RiskAssessment, RiskScore


class UpdateCheckTool(Tool):
    """Check for PraestoClaw updates."""

    risk_range = (0, 0)

    @property
    def name(self) -> str:
        return "check_update"

    @property
    def description(self) -> str:
        return "Check if a newer version of PraestoClaw is available."

    @property
    def parameters(self) -> dict[str, Any]:
        return {"type": "object", "properties": {}}

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=120, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="Read-only update check")

    async def execute(self, **kwargs: Any) -> str:
        """Check for updates (runs blocking I/O in a thread)."""
        try:
            from praestoclaw.utils.update import check_update

            status = await asyncio.to_thread(check_update)
            text = status.summary
            if not status.up_to_date and not status.error:
                # The `summary` string mentions `praestoclaw update` because it
                # is also rendered to CLI users. For chat users the fast-path
                # keyword is far more reliable (the shell-tool path races the
                # daemon's own shutdown and frequently drops the reply). Steer
                # the LLM toward the keyword and away from shell commands.
                text += (
                    "\n\n[guidance-to-llm] When telling the user how to "
                    "update, instruct them to reply with the single word "
                    "`update` (English) or `更新` (Chinese) — pick the one "
                    "that matches their preferred language. Do NOT suggest "
                    "`praestoclaw update`, `pc update`, or any shell command."
                )
            return text
        except Exception as exc:
            # Log the full exception for diagnostics, but return a
            # generic message — the raw ``str(exc)`` can embed file
            # paths, URLs, or other internal details that the LLM would
            # then surface to the user.
            logger.warning("Update check failed: {}", exc)
            return (
                "Update check failed (couldn't reach the update channel)."
                " Try again later; see the local log for details."
            )
