"""A2A tool — async discovery and messaging with other AI agents.

Discovery and routing happen inside the native agent-gateway business protocol;
the agent never fetches public agent-card JSON.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.risk import RiskAssessment, RiskScore

if TYPE_CHECKING:
    from praestoclaw.a2a.runtime import A2ARuntime

SUPPORTED_LIST_SCOPES = {"mine"}


class A2ATool(Tool):
    """Async agent-to-agent messaging via the A2A protocol."""

    risk_range = (2, 5)

    def __init__(self, a2a_runtime: A2ARuntime) -> None:
        self._runtime = a2a_runtime

    # ── Tool ABC ────────────────────────────────────────────────────────

    @property
    def name(self) -> str:
        return "a2a"

    @property
    def description(self) -> str:
        return (
            "通过 A2A 协议与其他 AI agent 通信。这是异步 fire-and-forget 模式："
            "调用 send 后会立即返回 dispatched，对方的 ack 和回复会作为单独的"
            "系统通知到达，**不要轮询**。Actions: list (列出当前用户下的其他 agent), "
            "discover (通过 gateway 内部协议发现其他用户), send (向目标发消息)。"
            " send 时若你预期对方需要执行长任务（review PR、analyze repo、"
            "build、refactor、跨多步操作等），请设置 as_task=true 并提供 "
            "task_summary（一句话描述要做的事），这会让对方周期性回报进度，"
            "网关也会延长超时窗口。短问答 / 单轮聊天保持 as_task=false。"
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=30, tier="core", category="builtin")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["send", "discover", "list"],
                    "description": (
                        "'list': enumerate sibling agents under the current user "
                        "(no target needed; currently supports scope='mine'); "
                        "'send': fire-and-forget a text message to a remote agent — "
                        "you'll receive the ack and reply later as system notifications. "
                        "'discover': query Gateway-internal discovery for a different "
                        "target user."
                    ),
                },
                "target": {
                    "type": "string",
                    "description": (
                        "Target agent's user_id (for example 'dev-user-bob' or "
                        "'bob@contoso.com'). Required for 'send' and 'discover'; "
                        "not used by 'list'."
                    ),
                },
                "scope": {
                    "type": "string",
                    "enum": ["mine"],
                    "default": "mine",
                    "description": (
                        "List scope for action='list'. Currently only 'mine' is "
                        "supported, meaning other A2A agents registered under the "
                        "current authenticated user."
                    ),
                },
                "message": {
                    "type": "string",
                    "description": (
                        "Message content. Required for 'send'. This is read by "
                        "the REMOTE agent, not its human. If the user wants the "
                        "remote HUMAN to respond/confirm/decide, address it to "
                        "the human (e.g. 'please tell your user X wants her to "
                        "reply hi') — do NOT phrase it as an imperative like "
                        "'reply hi after you receive this', which the remote "
                        "agent will execute itself instead of waiting for its "
                        "owner."
                    ),
                },
                "agent_id": {
                    "type": "string",
                    "description": (
                        "Optional direct A2A agent_id returned by discovery "
                        "(for example agents[0].agent_id). Use this with send "
                        "when target is a user_id and the addressable agent_id differs."
                    ),
                },
                "as_task": {
                    "type": "boolean",
                    "default": False,
                    "description": (
                        "When true, send the message as a task carrier (PraestoClaw "
                        "Gateway v1 task protocol). The executor wraps its run in a "
                        "periodic heartbeat so the originator sees progress events and "
                        "the Gateway extends the executing-stage deadline. Use this for "
                        "any request that may take more than a few seconds — code review, "
                        "repo analysis, builds, multi-step refactors, etc. Defaults to "
                        "false (plain message)."
                    ),
                },
                "task_summary": {
                    "type": "string",
                    "description": (
                        "One-line description of the task intent (e.g. 'Review PR #229'). "
                        "Used only when as_task=true. Falls back to a truncated form of "
                        "'message' when omitted."
                    ),
                },
                "hint_risk": {
                    "type": "string",
                    "enum": ["read", "write", "external"],
                    "description": (
                        "Optional risk hint for the task — informs the receiver's "
                        "approval policy. 'read' = read-only inspection, 'write' = "
                        "modifies the receiver's state, 'external' = side-effects on "
                        "the outside world. Used only when as_task=true."
                    ),
                },
            },
            "required": ["action"],
        }

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        action = args.get("action", "")
        if action in {"discover", "list"}:
            return RiskScore(2, reason=f"Read-only A2A {action}")
        if action == "send":
            if bool(args.get("as_task", False)):
                return RiskScore(5, reason="Sending task to remote agent (heartbeat-tracked)")
            return RiskScore(4, reason="Sending message to remote agent")
        return RiskScore(4, reason=f"Unknown A2A action: {action}")

    async def execute(self, **kwargs: Any) -> str:
        action: str = str(kwargs.get("action", "")).strip()
        target: str = (kwargs.get("target") or "").strip()

        try:
            if action == "list":
                return await self._list(str(kwargs.get("scope") or "mine"))
            if action == "discover":
                if not target:
                    return "Error: 'target' parameter is required for 'discover'."
                return await self._discover(target)
            if action == "send":
                if not target:
                    return "Error: 'target' parameter is required for 'send'."
                return await self._send(target, kwargs)
            return f"Error: unknown action '{action}'. Use 'list', 'send', or 'discover'."
        except Exception as exc:
            return f"Error: A2A {action} failed — {exc}"

    # ── Action handlers ─────────────────────────────────────────────────

    async def _discover(self, target: str) -> str:
        result = await self._runtime.discover(target)
        if result.get("error"):
            code = result.get("code", "")
            detail = result.get("detail", "")
            if "not_found" in str(code) or "404" in str(detail):
                return (
                    f"Agent '{target}' not found. The target user's PraestoClaw instance "
                    f"may not be connected to the gateway, or the user_id doesn't match."
                )
            return f"Error discovering agent '{target}': {detail or code or 'unknown'}"

        subject = result.get("subject", {})
        subject = subject if isinstance(subject, dict) else {}
        name = str(subject.get("display_name") or subject.get("user_id") or target)
        description = str(result.get("description") or "No description")
        presence = result.get("presence", {})
        presence = presence if isinstance(presence, dict) else {}
        skills = result.get("skills", [])
        agents = result.get("agents", [])

        lines = [
            f"Agent: {name}",
            f"User: {subject.get('user_id') or target}",
            f"Description: {description}",
        ]
        state = presence.get("state")
        if state:
            lines.append(f"Presence: {state}")
        if skills:
            lines.append("Skills:")
            for skill in skills:
                skill_name = skill.get("name", "unknown") if isinstance(skill, dict) else str(skill)
                lines.append(f"  - {skill_name}")
        if isinstance(agents, list) and agents:
            lines.append("Direct A2A agents:")
            for index, agent in enumerate(agents):
                if not isinstance(agent, dict):
                    continue
                agent_id = str(agent.get("agent_id") or "")
                user_id = str(agent.get("user_id") or subject.get("user_id") or target)
                role = str(agent.get("role") or "agent")
                direct = agent.get("direct_a2a")
                suffix = " direct_a2a=true" if direct is True else ""
                lines.append(
                    f"  - agents[{index}].agent_id: {agent_id} "
                    f"(user_id={user_id}, role={role}{suffix})"
                )
        return "\n".join(lines)

    async def _list(self, scope: str) -> str:
        normalized_scope = (scope or "mine").strip().lower()
        if normalized_scope not in SUPPORTED_LIST_SCOPES:
            return (
                f"Error: unsupported A2A list scope '{scope}'. "
                "Currently supported scope: 'mine' (other agents under your user)."
            )

        result = await self._runtime.list_agents(normalized_scope)
        if result.get("error"):
            detail = result.get("detail") or result.get("code") or "unknown"
            return f"Error listing A2A agents (scope={normalized_scope}): {detail}"

        agents_value = result.get("agents")
        if not isinstance(agents_value, list):
            agents_value = result.get("items")
        agents = agents_value if isinstance(agents_value, list) else []

        subject = result.get("subject", {})
        subject = subject if isinstance(subject, dict) else {}
        subject_user = str(subject.get("user_id") or subject.get("id") or "current user")
        result_scope = str(result.get("scope") or normalized_scope)

        if not agents:
            return (
                f"No other A2A agents are currently registered under {subject_user} "
                f"(scope={result_scope})."
            )

        local_user_id, local_agent_id = self._local_identity()
        lines = [
            f"A2A agents (scope={result_scope})",
            f"User: {subject_user}",
        ]
        for index, agent in enumerate(agents):
            if not isinstance(agent, dict):
                continue
            lines.extend(
                self._format_list_agent(
                    index,
                    agent,
                    local_user_id=local_user_id,
                    local_agent_id=local_agent_id,
                )
            )
        lines.append("Use target=<user_id> and agent_id=<agent_id> with action='send'.")
        return "\n".join(lines)

    async def _send(self, target: str, kwargs: dict[str, Any]) -> str:
        message: str | None = kwargs.get("message")
        if not message:
            return "Error: 'message' parameter is required for 'send'."

        # Channel context is injected by the tool registry from the active
        # conversation. Without it, we can't route the eventual ack/reply
        # notification back to the user — so refuse early.
        channel = kwargs.get("_channel", "")
        channel_id = kwargs.get("_channel_id", "")
        session_id = kwargs.get("_session_id", "") or kwargs.get("_session_key", "")

        if not channel or not channel_id:
            return (
                "Error: a2a send requires a user-originating channel context "
                "(this tool isn't usable from background/cron jobs)."
            )

        agent_id = str(kwargs.get("agent_id") or kwargs.get("target_agent_id") or "").strip()

        # Auto-resolve agent_id when the LLM forgot to call ``discover``
        # first. Without an agent_id the gateway fills in user_id as the
        # agent_id, which never matches a real registration → callers get
        # a confusing ``recipient_not_available`` even when the target is
        # actually online (just under a different agent_id, e.g.
        # ``wp_diYea8mffX8xQ``). Doing the discovery here makes the tool
        # behave the same regardless of whether the LLM remembered the
        # two-step protocol.
        if not agent_id:
            try:
                discovered = await self._runtime.discover(target)
            except Exception as exc:  # noqa: BLE001
                discovered = {"error": True, "detail": str(exc)}
            if discovered.get("error"):
                detail = str(discovered.get("detail") or "discovery failed")
                return (
                    f"Error: cannot send to '{target}' — agent_id was not "
                    f"provided and discovery failed: {detail}. "
                    f"Use action='discover' first to find a usable agent_id."
                )
            agents = discovered.get("agents")
            if isinstance(agents, list):
                for cand in agents:
                    if not isinstance(cand, dict):
                        continue
                    cand_id = str(cand.get("agent_id") or "").strip()
                    if cand_id:
                        agent_id = cand_id
                        break
            if not agent_id:
                return (
                    f"Error: no online agents found for '{target}'. "
                    f"They may be offline. Use action='list' to see who is online."
                )

        result = await self._runtime.send_async(
            target,
            message,
            channel=channel,
            channel_id=channel_id,
            session_id=session_id,
            target_agent_id=agent_id,
            task=self._build_task_dict(message, kwargs),
        )

        if result.get("ok"):
            mid = result.get("message_id", "")
            tid = result.get("task_id", "")
            if tid:
                return (
                    f"已发出 a2a task (message_id={mid}, task_id={tid})。"
                    f"对方将周期性回报进度，最终结果会作为系统通知到达，"
                    f"无需轮询，请等待通知。"
                )
            return (
                f"已发出 a2a 消息 (message_id={mid})。"
                f"对方上线后会收到，ack 和回复会作为系统通知到达，"
                f"无需轮询，请等待通知。"
            )

        code = result.get("error_code", "unknown")
        msg = result.get("error_message", "")
        return f"a2a send 失败：{code} — {msg}"

    @staticmethod
    def _build_task_dict(message: str, kwargs: dict[str, Any]) -> dict[str, Any] | None:
        """Construct the ``task`` dict for ``A2ARuntime.send_async`` when
        the LLM opted into task mode via ``as_task=True``. Returns ``None``
        for plain-message sends so the runtime stays on the legacy text
        path. ``task_summary`` falls back to a 120-char snippet of the
        message; the cloud translator further guards against an empty
        summary."""

        if not bool(kwargs.get("as_task", False)):
            return None
        summary = str(kwargs.get("task_summary") or "").strip()
        if not summary:
            summary = (message or "").strip()[:120]
        task: dict[str, Any] = {"summary": summary or "(no summary)"}
        hint_risk = kwargs.get("hint_risk")
        if isinstance(hint_risk, str) and hint_risk in {"read", "write", "external"}:
            task["hint_risk"] = hint_risk
        return task

    def _local_identity(self) -> tuple[str, str]:
        local_party = getattr(self._runtime, "local_party", None)
        user_id = getattr(local_party, "id", "")
        agent_id = getattr(local_party, "agent_id", "")
        return (
            user_id if isinstance(user_id, str) else "",
            agent_id if isinstance(agent_id, str) else "",
        )

    @staticmethod
    def _format_list_agent(
        index: int,
        agent: dict[str, Any],
        *,
        local_user_id: str,
        local_agent_id: str,
    ) -> list[str]:
        user_id = str(agent.get("user_id") or agent.get("owner_user_id") or "")
        agent_id = str(agent.get("agent_id") or agent.get("id") or "")
        name = str(agent.get("display_name") or agent.get("name") or agent_id or "unknown")
        role = str(agent.get("role") or "agent")
        description = str(agent.get("description") or "")
        presence = agent.get("presence", {})
        presence = presence if isinstance(presence, dict) else {}
        state = str(presence.get("state") or "")
        skills = A2ATool._skill_names(agent.get("skills", []))

        markers: list[str] = []
        if local_agent_id and agent_id == local_agent_id:
            if not local_user_id or not user_id or user_id == local_user_id:
                markers.append("self")

        detail_parts = [
            f"agent_id={agent_id or 'unknown'}",
            f"user_id={user_id or 'unknown'}",
            f"role={role}",
        ]
        if state:
            detail_parts.append(f"presence={state}")
        if markers:
            detail_parts.append(", ".join(markers))

        lines = [f"  - agents[{index}]: {name} ({', '.join(detail_parts)})"]
        if description:
            lines.append(f"    description: {description}")
        if skills:
            lines.append(f"    skills: {', '.join(skills)}")
        return lines

    @staticmethod
    def _skill_names(skills_value: Any) -> list[str]:
        if not isinstance(skills_value, list):
            return []
        names: list[str] = []
        for skill in skills_value:
            if isinstance(skill, dict):
                name = skill.get("name")
            else:
                name = skill
            if name:
                names.append(str(name))
        return names
