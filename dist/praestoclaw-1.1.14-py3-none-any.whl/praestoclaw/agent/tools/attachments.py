"""Attachment processing tool — exposes current-turn attachments to the model on demand."""

from __future__ import annotations

import asyncio
from typing import Any

from praestoclaw.agent.attachments.preprocessor import (
    AttachmentRef,
    AttachmentResolver,
    FetchedAttachment,
    answer_text_attachment,
    compress_image,
    download_attachment,
    extract_text_content,
    is_supported_text_attachment,
    summarize_image,
)
from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.providers.base import LLMProvider
from praestoclaw.security.risk import RiskAssessment, RiskScore


class AttachmentProcessTool(Tool):
    """Process current-turn attachments when the model needs their content."""

    risk_range = (3, 3)

    def __init__(self, provider: LLMProvider) -> None:
        self._provider = provider
        self._resolver = AttachmentResolver()

    @property
    def name(self) -> str:
        return "attachment_process"

    @property
    def description(self) -> str:
        return (
            "Read current-turn attachments only when their content is needed. "
            "For images, downloads the selected attachment, compresses it for a "
            "separate vision call. For text/PDF/DOCX/PPTX/XLSX files, extracts text "
            "in an isolated call and returns compact task-relevant Markdown."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "indexes": {
                    "type": "array",
                    "items": {"type": "integer", "minimum": 1},
                    "description": "1-based current-turn attachment indexes. Omit to process all.",
                },
                "mode": {
                    "type": "string",
                    "enum": ["summary"],
                    "default": "summary",
                    "description": "Processing mode. Returns compact task-relevant attachment summaries.",
                },
            },
            "additionalProperties": False,
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=180, streaming=True, tier="core", max_output_chars=20_000)

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(3, reason="Reads current-turn attachment URLs and summarizes content")

    def validate(self, args: dict[str, Any]) -> list[str]:
        indexes = args.get("indexes")
        if indexes is not None:
            if not isinstance(indexes, list) or not all(
                isinstance(i, int) and i > 0 for i in indexes
            ):
                return ["indexes must be a list of positive integers"]
        mode = args.get("mode", "summary")
        if mode != "summary":
            return ["mode must be 'summary'"]
        return []

    async def execute(self, **kwargs: Any) -> str:
        errors = self.validate(kwargs)
        if errors:
            return "Error: " + "; ".join(errors)

        metadata = kwargs.get("_metadata")
        if not isinstance(metadata, dict):
            metadata = None
        user_message = str(kwargs.get("_user_message") or "")
        model = str(kwargs.get("_model") or "")
        if not model:
            return "Error: attachment_process requires runtime model context"

        try:
            attachments = self._resolver.select(metadata, kwargs.get("indexes"))
        except ValueError as exc:
            return f"Error: {exc}"

        if not attachments:
            return "Error: no current-turn attachments are available"

        if self._progress:
            await self._progress(f"Reading {len(attachments)} attachment(s)...")

        results = await asyncio.gather(
            *(self._process_one(att, model=model, user_message=user_message) for att in attachments)
        )

        blocks: list[str] = ["Attachment processing results:"]
        for block in results:
            blocks.append(block)
        return "\n".join(blocks).strip()

    async def _process_one(
        self, attachment: AttachmentRef, *, model: str, user_message: str
    ) -> str:
        title = attachment.name or attachment.url
        lines = [
            f"\n## Attachment {attachment.index}: {title}",
            f"Kind: {attachment.kind}",
        ]
        if attachment.content_type:
            lines.append(f"Content type: {attachment.content_type}")
        if attachment.file_type:
            lines.append(f"File type: {attachment.file_type}")
        if attachment.kind == "image":
            lines.append(f"Source: {attachment.url}")
        try:
            if attachment.requires_auth and attachment.kind != "image":
                raise ValueError("authenticated non-image attachments are not supported in v1")

            fetched = await download_attachment(attachment.url)
            if attachment.kind == "image" or fetched.content_type.startswith("image/"):
                await self._process_image(
                    lines,
                    attachment=attachment,
                    fetched=fetched,
                    model=model,
                    user_message=user_message,
                )
            elif is_supported_text_attachment(attachment):
                await self._process_text(
                    lines,
                    attachment=attachment,
                    fetched=fetched,
                    model=model,
                    user_message=user_message,
                )
            else:
                raise ValueError(
                    "unsupported attachment type: "
                    f"{attachment.file_type or attachment.content_type or fetched.content_type or 'unknown'}"
                )
        except Exception as exc:  # noqa: BLE001 - return per-attachment failures to the model
            lines.append(f"Error: {exc}")
        return "\n".join(lines)

    async def _process_image(
        self,
        lines: list[str],
        *,
        attachment: AttachmentRef,
        fetched: FetchedAttachment,
        model: str,
        user_message: str,
    ) -> None:
        image = compress_image(fetched.data)
        if self._progress:
            await self._progress(
                f"Summarizing attachment {attachment.index} "
                f"({len(fetched.data)} bytes -> {len(image.data)} bytes)..."
            )
        summary = await summarize_image(
            provider=self._provider,
            model=model,
            user_message=user_message,
            attachment=attachment,
            image=image,
        )
        lines.append(
            "Compressed image: "
            f"{image.width}x{image.height}, {image.content_type}, "
            f"{image.original_bytes} -> {len(image.data)} bytes"
        )
        lines.append("Summary:")
        lines.append(summary)

    async def _process_text(
        self,
        lines: list[str],
        *,
        attachment: AttachmentRef,
        fetched: FetchedAttachment,
        model: str,
        user_message: str,
    ) -> None:
        text, extraction = await extract_text_content(attachment, fetched)
        if self._progress:
            await self._progress(
                f"Reading attachment {attachment.index} ({len(text)} extracted chars)..."
            )
        summary, processing = await answer_text_attachment(
            provider=self._provider,
            model=model,
            user_message=user_message,
            attachment=attachment,
            text=text,
        )
        lines.append(f"Extraction: {extraction}")
        lines.append(f"Processing: {processing}")
        lines.append("Summary:")
        lines.append(summary)


__all__ = ["AttachmentProcessTool"]
