"""Background-task status tool — inspect detached sub-agent runs.

Lets the main agent answer follow-up questions ("is the task done yet?") about
tasks started with ``spawn(mode=background)``. Read-only except for ``cancel``.
"""

from __future__ import annotations

import json
from typing import Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.host.background_tasks import BackgroundTaskManager
from praestoclaw.security.risk import RiskAssessment, RiskScore


class TasksTool(Tool):
    """List, inspect, fetch results of, or cancel background sub-agent tasks."""

    risk_range = (0, 2)

    def __init__(self, manager: BackgroundTaskManager) -> None:
        self._manager = manager

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=30, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        if (args.get("action") or "list") == "cancel":
            return RiskScore(2, reason="Cancel a background task")
        return RiskScore(0, reason="Read background task status")

    @property
    def name(self) -> str:
        return "tasks"

    @property
    def description(self) -> str:
        return (
            "Check background tasks started via spawn(mode=background): "
            "list them, get status/result, or cancel one."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "status", "result", "cancel"],
                    "description": (
                        "list (default) = all tasks; status = one task's state; "
                        "result = finished output; cancel = stop a running task."
                    ),
                },
                "task_id": {
                    "type": "string",
                    "description": "Task id. Required for status, result, and cancel.",
                },
            },
            "required": [],
            # Defence-in-depth: keep registry-injected ``_session_id``
            # (which scopes owner) out of the public schema so a model
            # cannot try to spoof it in its tool args.
            "additionalProperties": False,
        }

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "list")
        task_id = kwargs.get("task_id")
        # Registry-injected caller session. Scopes every action to the calling
        # conversation so one session cannot enumerate, read, or cancel another
        # session's background tasks.
        owner = kwargs.get("_session_id")

        if action == "list":
            tasks = self._manager.list_tasks(owner=owner)
            if not tasks:
                return "No background tasks."
            return json.dumps(tasks, ensure_ascii=False, indent=2)

        if not task_id:
            return f"Error: action '{action}' requires a task_id."

        if action == "status":
            snap = self._manager.status(task_id, owner=owner)
            if snap is None:
                return f"Unknown task {task_id}."
            return json.dumps(snap, ensure_ascii=False)

        if action == "result":
            result = self._manager.get_result(task_id, owner=owner)
            if result is not None:
                return result
            snap = self._manager.status(task_id, owner=owner)
            if snap is None:
                return f"Unknown task {task_id}."
            return (
                f"Task {task_id} is {snap['state']} "
                f"({snap['elapsed_seconds']}s elapsed) — no result yet."
            )

        if action == "cancel":
            return await self._manager.cancel(task_id, owner=owner)

        return f"Error: unknown action '{action}'. Use list, status, result, or cancel."
