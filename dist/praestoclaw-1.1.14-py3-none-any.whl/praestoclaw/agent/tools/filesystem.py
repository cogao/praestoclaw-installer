"""
File system tools — read, write, edit, list, search with workspace sandboxing.

All paths are resolved through the Sandbox to prevent path traversal.
"""

from __future__ import annotations

import asyncio
import difflib
import os
import re
import stat
import threading
import time
from collections.abc import Iterator
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path, PurePosixPath
from typing import Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.risk import RiskAssessment, RiskScore
from praestoclaw.security.sandbox import PathDeniedError, Sandbox

_DEFAULT_MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB

# ── Event-loop safety for file search ─────────────────────────────────────────
#
# search_files walks the tree with synchronous os calls (scandir/stat/read).
# A single one of those can block indefinitely — most notably an os.stat() on a
# Windows OneDrive "online-only" placeholder, which triggers a blocking network
# hydration. Running that on the asyncio event loop freezes the whole agent:
# heartbeats stop, the gateway liveness pong is missed, the connection is reaped
# and the user sees a spurious "agent offline" (see #415 / #386).
#
# The scan is therefore offloaded to a *bounded* worker pool. Bounded matters:
# a thread stuck in a hung syscall cannot be cancelled, so it leaks until the
# syscall returns. A small fixed pool caps how many can ever be stuck at once
# (no unbounded thread/memory growth) while keeping the event loop responsive.
_SEARCH_EXECUTOR_MAX_WORKERS = 4
_SEARCH_EXECUTOR = ThreadPoolExecutor(
    max_workers=_SEARCH_EXECUTOR_MAX_WORKERS,
    thread_name_prefix="search_files",
)

# Backpressure: a bounded pool caps *worker threads*, but the executor's submit
# queue is unbounded. If workers wedge on stuck syscalls, further calls would
# pile up queued jobs (each already abandoned by the caller's wait_for) and grow
# memory without bound. So we cap in-flight jobs (running + queued) and fail fast
# once saturated. The slot is released from the future's done callback — i.e.
# when the *job* finishes, not when the awaiting coroutine is cancelled — so a
# wedged worker keeps holding its slot and cannot be masked by new submissions.
_SEARCH_MAX_INFLIGHT = _SEARCH_EXECUTOR_MAX_WORKERS * 4  # workers + bounded backlog
_search_inflight_lock = threading.Lock()
_search_inflight = 0


def _acquire_search_slot() -> bool:
    """Reserve an in-flight slot; return False if the pool is saturated."""
    global _search_inflight
    with _search_inflight_lock:
        if _search_inflight >= _SEARCH_MAX_INFLIGHT:
            return False
        _search_inflight += 1
        return True


def _release_search_slot() -> None:
    global _search_inflight
    with _search_inflight_lock:
        _search_inflight -= 1


# Windows file attributes marking a cloud-only placeholder (dehydrated file).
# Opening/reading such a file — or an uncached stat that has to reach the
# provider — forces a blocking download. We detect placeholders from the
# DirEntry's scan-cached metadata (best-effort, typically no extra probe) and
# skip them so the walk never reads them. Other platforms never set these.
_FILE_ATTRIBUTE_RECALL_ON_OPEN = 0x00040000
_FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS = 0x00400000


def _is_cloud_placeholder(st: Any) -> bool:
    """Return True if ``st`` marks a cloud-only (dehydrated) placeholder file.

    Inspects ``st_file_attributes``; callers pass a ``DirEntry``-backed stat,
    which is typically served from directory-scan metadata. Only meaningful on
    Windows; on other platforms ``os.stat_result`` has no ``st_file_attributes``
    and this is always False.
    """
    attrs = getattr(st, "st_file_attributes", 0)
    return bool(attrs & (_FILE_ATTRIBUTE_RECALL_ON_OPEN | _FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS))


def _check_file_size(content: str | bytes, max_bytes: int = _DEFAULT_MAX_FILE_SIZE) -> None:
    """Raise PathDeniedError if content exceeds the file size limit."""
    size = len(content) if isinstance(content, bytes) else len(content.encode("utf-8"))
    if size > max_bytes:
        raise PathDeniedError(f"File content exceeds maximum size ({size:,} > {max_bytes:,} bytes)")


# ── Path risk helpers ────────────────────────────────────────────────────────

# ── Path risk categories (checked in order: most specific first) ─────────────
#
#   credential  Private keys, password stores. Compromise = identity theft.
#               e.g. .ssh/id_rsa, .gnupg/, .aws/credentials, /etc/shadow
#
#   config_secret  Project-level secrets, registry tokens. Limited blast radius.
#               e.g. .env, .npmrc, .netrc, known_hosts
#
#   system      OS directories. Write is dangerous but sandbox usually blocks.
#               e.g. /etc/hosts, /usr/bin, C:\Windows
#
#   workspace   Normal project files. Fully reversible via git.
#

_CREDENTIAL_PATTERNS = re.compile(
    r"([\\/]\.ssh[\\/]|[\\/]\.gnupg[\\/]|[\\/]\.aws[\\/]"
    r"|[\\/]id_rsa|[\\/]id_ed25519|[\\/]authorized_keys$"
    r"|[\\/]shadow$|[\\/]\.htpasswd$"
    r"|^\.ssh[\\/]|^\.aws[\\/]|^\.gnupg[\\/])",
    re.IGNORECASE,
)

# Project-level config secrets — scoped to the project, limited blast radius.
_PROJECT_SECRET_PATTERNS = re.compile(
    r"([\\/]\.env$|[\\/]\.env\.|[\\/]credentials$"
    r"|[\\/]\.npmrc$|[\\/]\.pypirc$"
    r"|^\.env$|^\.env\.|^credentials$)",
    re.IGNORECASE,
)

# User/system-level config secrets — broader impact than project-level.
_USER_SECRET_PATTERNS = re.compile(
    r"([\\/]\.netrc$|[\\/]known_hosts$|[\\/]passwd$)",
    re.IGNORECASE,
)

_SYSTEM_PATHS = re.compile(
    r"^(/etc|/usr|/bin|/sbin|/boot|/sys|/proc|C:\\Windows|C:\\Program Files)",
    re.IGNORECASE,
)


def path_risk_level(path: str) -> tuple[str, int, int]:
    """Classify path risk → (category, read_score, write_score).

    Check order: credential → config_secret → system → workspace.
    Credential first so /etc/shadow gets credential (8) not system (7).
    """
    if _CREDENTIAL_PATTERNS.search(path):
        return "credential", 5, 9
    if _USER_SECRET_PATTERNS.search(path):
        return "user_secret", 3, 7
    if _PROJECT_SECRET_PATTERNS.search(path):
        return "project_secret", 3, 6
    if _SYSTEM_PATHS.match(path):
        return "system", 4, 8
    return "workspace", 0, 3


class ReadFileTool(Tool):
    risk_range = (0, 5)

    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=30)

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        path = args.get("path", "")
        category, read_score, _ = path_risk_level(path)
        if category == "workspace":
            return RiskScore(0, reason="Read-only file access")
        return RiskScore(read_score, reason=f"Read {category} file: {path}")

    @property
    def name(self) -> str:
        return "read_file"

    @property
    def description(self) -> str:
        return "Read file contents. Supports offset and limit for partial reads."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path relative to workspace"},
                "offset": {"type": "integer", "description": "Start line (1-based)"},
                "limit": {"type": "integer", "description": "Max lines to return"},
            },
            "required": ["path"],
        }

    async def execute(self, **kwargs: Any) -> str:
        try:
            resolved = self._sandbox.resolve_path(kwargs["path"])
            content = resolved.read_text(encoding="utf-8")
            if kwargs.get("offset") or kwargs.get("limit"):
                lines = content.splitlines(keepends=True)
                start = max(0, (kwargs.get("offset", 1) or 1) - 1)
                end = start + (kwargs.get("limit") or len(lines))
                content = "".join(lines[start:end])
            return content
        except PathDeniedError as exc:
            return f"BLOCKED: {exc}"
        except FileNotFoundError:
            return f"File not found: {kwargs['path']}"
        except Exception as exc:
            return f"Error reading file: {exc}"


class WriteFileTool(Tool):
    risk_range = (3, 9)

    def __init__(
        self, sandbox: Sandbox, *, max_file_size_bytes: int = _DEFAULT_MAX_FILE_SIZE
    ) -> None:
        self._sandbox = sandbox
        self._max_file_size = max_file_size_bytes

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=45, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        path = args.get("path", "")
        category, _, write_score = path_risk_level(path)
        if category == "workspace":
            return RiskScore(3, reason="File write within workspace")
        return RiskScore(write_score, reason=f"Write to {category} file: {path}")

    @property
    def name(self) -> str:
        return "write_file"

    @property
    def description(self) -> str:
        return "Write content to a file. Creates parent directories if needed."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path relative to workspace"},
                "content": {"type": "string", "description": "Content to write"},
            },
            "required": ["path", "content"],
        }

    async def execute(self, **kwargs: Any) -> str:
        try:
            resolved = self._sandbox.resolve_path(kwargs["path"])
            content = kwargs["content"]
            _check_file_size(content, self._max_file_size)
            resolved.parent.mkdir(parents=True, exist_ok=True)
            resolved.write_text(content, encoding="utf-8")
            return f"Written: {kwargs['path']}"
        except PathDeniedError as exc:
            return f"BLOCKED: {exc}"
        except Exception as exc:
            return f"Error writing file: {exc}"


class EditFileTool(Tool):
    risk_range = (3, 9)

    def __init__(
        self, sandbox: Sandbox, *, max_file_size_bytes: int = _DEFAULT_MAX_FILE_SIZE
    ) -> None:
        self._sandbox = sandbox
        self._max_file_size = max_file_size_bytes

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=60)

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        path = args.get("path", "")
        category, _, write_score = path_risk_level(path)
        if category == "workspace":
            return RiskScore(3, reason="File edit within workspace")
        return RiskScore(write_score, reason=f"Edit {category} file: {path}")

    @property
    def name(self) -> str:
        return "edit_file"

    @property
    def description(self) -> str:
        return "Edit a file by replacing an exact string match. Returns a unified diff."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path"},
                "old_string": {"type": "string", "description": "Exact text to find"},
                "new_string": {"type": "string", "description": "Replacement text"},
            },
            "required": ["path", "old_string", "new_string"],
        }

    async def execute(self, **kwargs: Any) -> str:
        try:
            resolved = self._sandbox.resolve_path(kwargs["path"])
            content = resolved.read_text(encoding="utf-8")
            old = kwargs["old_string"]
            new = kwargs["new_string"]

            if old not in content:
                return self._fuzzy_hint(content, old, kwargs["path"])

            count = content.count(old)
            if count > 1:
                return (
                    f"Error: old_string has {count} matches — "
                    f"provide more context to make it unique"
                )

            updated = content.replace(old, new, 1)
            _check_file_size(updated, self._max_file_size)
            resolved.write_text(updated, encoding="utf-8")

            # Show diff
            diff = difflib.unified_diff(
                content.splitlines(keepends=True),
                updated.splitlines(keepends=True),
                fromfile=f"a/{kwargs['path']}",
                tofile=f"b/{kwargs['path']}",
                n=3,
            )
            return "".join(diff) or f"Edited: {kwargs['path']}"
        except PathDeniedError as exc:
            return f"BLOCKED: {exc}"
        except Exception as exc:
            return f"Error editing file: {exc}"

    @staticmethod
    def _fuzzy_hint(content: str, old_string: str, path: str) -> str:
        """When old_string is not found, find the closest match and show a diff hint."""
        lines = content.splitlines(keepends=True)
        old_lines = old_string.splitlines(keepends=True)
        old_len = len(old_lines)

        # Skip fuzzy matching for large content to avoid O(n²) SequenceMatcher cost
        if len(lines) > 40_000 or old_len > 1024 or len(content) > 2_000_000:
            return f"Error: old_string not found in {path}."

        best_ratio = 0.0
        best_start = 0

        # Slide a window of old_len lines across the file
        for i in range(max(1, len(lines) - old_len + 1)):
            candidate = lines[i : i + old_len]
            ratio = difflib.SequenceMatcher(None, "".join(candidate), old_string).ratio()
            if ratio > best_ratio:
                best_ratio = ratio
                best_start = i

        if best_ratio < 0.4:
            return f"Error: old_string not found in {path}. No similar content found."

        best_match = "".join(lines[best_start : best_start + old_len])
        diff_lines = list(
            difflib.unified_diff(
                old_string.splitlines(keepends=True),
                best_match.splitlines(keepends=True),
                fromfile="old_string (provided)",
                tofile=f"actual content (line {best_start + 1})",
                n=3,
            )
        )
        diff_text = "".join(diff_lines[:30])  # Cap output to avoid token bloat
        return (
            f"Error: old_string not found in {path}.\n"
            f"Best match ({best_ratio:.0%} similar) at line {best_start + 1}:\n"
            f"{diff_text}"
        )


class ListDirTool(Tool):
    risk_range = (0, 4)

    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=30)

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        path = args.get("path", ".")
        category, _, _ = path_risk_level(path)
        if category == "credential":
            return RiskScore(4, reason=f"List credential directory: {path}")
        if category == "system":
            return RiskScore(3, reason=f"List system directory: {path}")
        if category in ("user_secret", "project_secret"):
            return RiskScore(1, reason=f"List {category} directory: {path}")
        return RiskScore(0, reason="Read-only directory listing")

    @property
    def name(self) -> str:
        return "list_dir"

    @property
    def description(self) -> str:
        return "List directory contents. Supports recursive listing."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Directory path (default: workspace root)",
                },
                "recursive": {"type": "boolean", "description": "List recursively"},
            },
        }

    async def execute(self, **kwargs: Any) -> str:
        try:
            path_str = kwargs.get("path", ".")
            resolved = self._sandbox.resolve_path(path_str)
            if not resolved.is_dir():
                return f"Not a directory: {path_str}"

            entries: list[str] = []
            if kwargs.get("recursive"):
                for p in sorted(resolved.rglob("*")):
                    rel = p.relative_to(resolved)
                    suffix = "/" if p.is_dir() else ""
                    entries.append(f"{rel}{suffix}")
            else:
                for p in sorted(resolved.iterdir()):
                    suffix = "/" if p.is_dir() else ""
                    entries.append(f"{p.name}{suffix}")

            return "\n".join(entries[:500]) if entries else "(empty directory)"
        except PathDeniedError as exc:
            return f"BLOCKED: {exc}"
        except Exception as exc:
            return f"Error listing directory: {exc}"


class SearchFilesTool(Tool):
    risk_range = (0, 4)

    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=60)

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        path = args.get("path", ".")
        mode = args.get("mode", "content")
        category, read_score, _ = path_risk_level(path)
        if category == "workspace":
            return RiskScore(0, reason="File search within workspace")
        # content mode reads file contents — same risk as read_file
        if mode == "content":
            return RiskScore(read_score, reason=f"Content search in {category} path: {path}")
        # name mode only lists filenames — same as list_dir
        if category == "credential":
            return RiskScore(4, reason=f"File name search in credential path: {path}")
        if category == "system":
            return RiskScore(3, reason=f"File name search in system path: {path}")
        return RiskScore(1, reason=f"File name search in {category} path: {path}")

    @property
    def name(self) -> str:
        return "search_files"

    @property
    def description(self) -> str:
        return (
            "Search files by content (regex) or file name (glob). Returns matching lines or paths."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Regex pattern (content mode) or glob pattern (name mode)",
                },
                "mode": {
                    "type": "string",
                    "enum": ["content", "name"],
                    "description": "Search mode: 'content' for regex in file contents, "
                    "'name' for glob on file names (default: content)",
                },
                "path": {
                    "type": "string",
                    "description": "Search root directory (default: workspace root)",
                },
                "file_pattern": {
                    "type": "string",
                    "description": "Glob filter for files to search, e.g. '*.py' (content mode only)",
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of results to return (default: 50)",
                },
            },
            "required": ["pattern"],
        }

    async def execute(self, **kwargs: Any) -> str:
        try:
            pattern = kwargs["pattern"]
            mode = kwargs.get("mode", "content")
            path_str = kwargs.get("path", ".")
            file_pattern = kwargs.get("file_pattern")
            max_results = kwargs.get("max_results", 50)

            # Validate mode
            if mode not in ("content", "name"):
                return "Error: mode must be 'content' or 'name'"

            # Clamp max_results to safe bounds
            max_results = min(max(1, max_results), 500)

            # Run the whole synchronous job — path resolution, the is_dir check,
            # and the scan — on a bounded worker pool, never on the event loop.
            # resolve_path()/is_dir() also stat the filesystem, so a cloud
            # placeholder at/above the root could otherwise freeze the loop just
            # like the walk itself (see #415 / #386). Keeping the loop responsive
            # also lets the registry's asyncio.wait_for actually enforce the
            # timeout. Exceptions raised in the thread propagate to the handlers
            # below.
            #
            # Fail fast when the pool is saturated rather than queueing unbounded
            # work behind wedged workers. The slot is released from the future's
            # done callback (job finished), not on coroutine cancellation, so a
            # stuck worker keeps holding its slot.
            if not _acquire_search_slot():
                return (
                    "search_files is busy: too many searches are still running "
                    "(some may be stuck on slow or cloud-backed files). "
                    "Try again shortly or narrow the search path."
                )
            # Submit to the executor directly and track the slot on the
            # concurrent.futures Future. Its done callback fires only when the
            # job actually finishes (or is cancelled before it ever runs) — NOT
            # when the awaiting coroutine is cancelled by the registry's
            # wait_for timeout. A wedged worker therefore keeps holding its slot
            # (the thread can't be interrupted mid-syscall), preserving the
            # backpressure. wrap_future lets wait_for still time out the await.
            try:
                cfuture = _SEARCH_EXECUTOR.submit(
                    self._run_search,
                    path_str,
                    mode,
                    pattern,
                    file_pattern,
                    max_results,
                )
            except Exception:
                # submit() can raise (e.g. executor shut down during teardown)
                # before any future exists to release the slot via callback.
                _release_search_slot()
                raise
            cfuture.add_done_callback(lambda _f: _release_search_slot())
            return await asyncio.wrap_future(cfuture)
        except PathDeniedError as exc:
            return f"BLOCKED: {exc}"
        except re.error as exc:
            return f"Invalid regex pattern: {exc}"
        except Exception as exc:
            return f"Error searching files: {exc}"

    def _run_search(
        self,
        path_str: str,
        mode: str,
        pattern: str,
        file_pattern: str | None,
        max_results: int,
    ) -> str:
        """Resolve the root, validate it, and run the scan — all synchronous.

        Runs entirely inside the search worker thread (see ``execute``), so the
        path resolution and ``is_dir`` stat never touch the event loop.
        """
        resolved = self._sandbox.resolve_path(path_str)
        if not resolved.is_dir():
            return f"Not a directory: {path_str}"
        # Derive deadline from metadata timeout (minus 1s margin, clamped to at
        # least 1s) so it stays in sync with the timeout property.
        deadline = time.monotonic() + max(self.metadata.timeout - 1, 1.0)
        if mode == "name":
            return self._search_by_name(resolved, pattern, max_results, deadline)
        return self._search_by_content(resolved, pattern, file_pattern, max_results, deadline)

    # Directories skipped during search — install/cache/VCS dirs that are
    # typically huge and never contain user-authored source code.
    _SKIP_DIRS: frozenset[str] = frozenset(
        {
            ".git",
            ".hg",
            ".svn",
            "node_modules",
            "bower_components",
            "__pycache__",
            ".mypy_cache",
            ".pytest_cache",
            ".ruff_cache",
            ".venv",
            "venv",
            ".env",
            "env",
            ".tox",
            ".nox",
            ".cargo",
            "target",  # Rust
            "Pods",  # iOS CocoaPods
            ".gradle",
            ".terraform",
            ".next",
            ".nuxt",
            "obj",  # .NET build intermediates
        }
    )

    # File extensions that are always binary — skip in content search to avoid
    # wasting time on open + read + UnicodeDecodeError.
    _BINARY_EXTENSIONS: frozenset[str] = frozenset(
        {
            ".dll",
            ".exe",
            ".pdb",
            ".so",
            ".dylib",
            ".o",
            ".a",
            ".lib",
            ".obj",
            ".class",
            ".jar",
            ".war",
            ".ear",
            ".pyc",
            ".pyo",
            ".whl",
            ".egg",
            ".zip",
            ".tar",
            ".gz",
            ".bz2",
            ".xz",
            ".7z",
            ".rar",
            ".png",
            ".jpg",
            ".jpeg",
            ".gif",
            ".bmp",
            ".ico",
            ".webp",
            ".tiff",
            ".mp3",
            ".mp4",
            ".avi",
            ".mov",
            ".wav",
            ".flac",
            ".ogg",
            ".pdf",
            ".doc",
            ".docx",
            ".xls",
            ".xlsx",
            ".ppt",
            ".pptx",
            ".woff",
            ".woff2",
            ".ttf",
            ".otf",
            ".eot",
            ".nupkg",
            ".snupkg",
        }
    )

    def _walk_files(
        self,
        root: Path,
        glob: str | None = None,
        deadline: float = 0.0,
        deadline_hit: list[bool] | None = None,
    ) -> Iterator[Path]:
        """Yield files in directory tree, skipping heavy install/cache dirs.

        Walks with os.scandir (topdown) so directory pruning prevents descending
        into skipped dirs (rglob cannot do this), and so each entry can be
        inspected via its ``DirEntry`` whose ``stat()`` is typically served from
        the directory-scan cache (notably on Windows, where it avoids forcing a
        OneDrive cloud-placeholder hydration). Caching is a CPython optimisation,
        not an API guarantee, so this is best-effort rather than a hard promise.
        Lazy generator — callers can break early without traversing the full tree.

        Args:
            deadline_hit: optional single-element list; set to ``[True]`` when
                the generator exits early due to deadline.  Using a mutable
                container avoids instance-level state that would race under
                concurrent ``execute()`` calls on the same tool instance.
        """
        files_yielded = 0
        # Explicit DFS stack of directories still to visit (topdown).
        pending: list[Path] = [root]
        while pending:
            current = pending.pop()
            # Check deadline once per directory (cheap amortised cost)
            if deadline and time.monotonic() > deadline:
                if deadline_hit is not None:
                    deadline_hit[0] = True
                return
            subdirs: list[Path] = []
            files: list[os.DirEntry[str]] = []
            try:
                with os.scandir(current) as entries:
                    # Split into dirs/files in a single pass over the iterator.
                    for entry in entries:
                        try:
                            is_dir = entry.is_dir(follow_symlinks=False)
                        except OSError:
                            continue
                        if is_dir:
                            # Prune skipped directories before descending.
                            if entry.name not in self._SKIP_DIRS:
                                subdirs.append(Path(entry.path))
                        else:
                            files.append(entry)
            except OSError:
                # Unreadable directory (permissions, race, etc.) — skip it.
                continue

            # Sort filenames for deterministic output across platforms.
            for entry in sorted(files, key=lambda e: e.name):
                # Skip symlinks (could escape workspace), then take a single
                # DirEntry stat (typically served from scan metadata) and use it
                # for both the regular-file test and the placeholder check —
                # one metadata probe per entry instead of two.
                try:
                    if entry.is_symlink():
                        continue
                    st = entry.stat(follow_symlinks=False)
                except OSError:
                    continue
                # Skip non-regular files (FIFOs/sockets can block read forever).
                if not stat.S_ISREG(st.st_mode):
                    continue
                # Skip cloud-only placeholders before we ever open/read them:
                # reading (or a later uncached stat) would block on a network
                # hydration and could freeze the loop.
                if _is_cloud_placeholder(st):
                    continue
                filepath = Path(entry.path)
                if glob:
                    # Use PurePosixPath.match() which is component-aware
                    # (* does not cross /) and supports ** for recursion,
                    # matching rglob semantics exactly.
                    try:
                        rel = PurePosixPath(*filepath.relative_to(root).parts)
                    except ValueError:
                        continue
                    if not rel.match(glob):
                        continue
                files_yielded += 1
                # Check deadline every 200 yielded files (global counter across
                # all directories — supplements the per-directory check above).
                if deadline and files_yielded % 200 == 0 and time.monotonic() > deadline:
                    if deadline_hit is not None:
                        deadline_hit[0] = True
                    return
                yield filepath

            # Descend into subdirectories. Push in reverse-sorted order so the
            # stack pops them in ascending order (deterministic traversal).
            for sub in sorted(subdirs, key=lambda p: p.name, reverse=True):
                pending.append(sub)

    def _search_by_name(self, root: Path, pattern: str, max_results: int, deadline: float) -> str:
        """Search for files by glob pattern."""
        matches: list[str] = []
        # Cache sandbox checks per directory — all files in an allowed dir are allowed.
        allowed_dirs: dict[Path, bool] = {}
        walk_deadline = [False]
        for p in self._walk_files(root, pattern, deadline, walk_deadline):
            parent = p.parent
            if parent not in allowed_dirs:
                try:
                    self._sandbox.resolve_path(str(parent))
                    allowed_dirs[parent] = True
                except PathDeniedError:
                    allowed_dirs[parent] = False
            if not allowed_dirs[parent]:
                continue
            # Per-file deny-path check (dir cache doesn't catch file-level denials).
            # No .resolve() needed — _walk_files already skips symlinks and
            # root comes from sandbox.resolve_path(), so paths are canonical.
            if self._sandbox.is_path_denied(p):
                continue
            try:
                rel = p.relative_to(root).as_posix()
            except ValueError:
                rel = str(p)
            matches.append(rel)
            if len(matches) >= max_results:
                break

        deadline_hit = walk_deadline[0]
        if not matches:
            suffix = " (search timed out — results may be incomplete)" if deadline_hit else ""
            return f"No files matching '{pattern}'{suffix}"
        header = f"Found {len(matches)} file(s) matching '{pattern}'"
        if deadline_hit:
            header += " (search timed out — results may be incomplete)"
        return header + ":\n" + "\n".join(matches)

    def _search_by_content(
        self,
        root: Path,
        pattern: str,
        file_pattern: str | None,
        max_results: int,
        deadline: float,
    ) -> str:
        """Search file contents by regex pattern.

        Output follows ripgrep ``--heading`` format (industry standard):
        ``:`` marks match lines, ``-`` marks context lines, grouped by file.
        """
        compiled = re.compile(pattern)
        file_glob = file_pattern or None
        # Collect results grouped by file: list of (rel_path, [(linenum, is_match, text)])
        file_blocks: list[tuple[str, list[tuple[int, bool, str]]]] = []
        match_count = 0
        # Cache sandbox checks per directory
        allowed_dirs: dict[Path, bool] = {}
        files_seen = 0
        walk_deadline = [False]
        deadline_hit = False

        for filepath in self._walk_files(root, file_glob, deadline, walk_deadline):
            # Count ALL yielded files for deadline checks (not just those
            # passing filters — otherwise dirs full of binary/denied files
            # would rarely trigger the check).
            files_seen += 1
            if files_seen % 100 == 0 and time.monotonic() > deadline:
                deadline_hit = True
                break

            # Per-directory sandbox check (cached)
            parent = filepath.parent
            if parent not in allowed_dirs:
                try:
                    self._sandbox.resolve_path(str(parent))
                    allowed_dirs[parent] = True
                except PathDeniedError:
                    allowed_dirs[parent] = False
            if not allowed_dirs[parent]:
                continue
            # Per-file deny-path check (dir cache doesn't catch file-level denials).
            # No .resolve() needed — _walk_files already skips symlinks and
            # root comes from sandbox.resolve_path(), so paths are canonical.
            if self._sandbox.is_path_denied(filepath):
                continue
            # Skip known binary extensions — avoids open/read/UnicodeDecodeError overhead
            if filepath.suffix.lower() in self._BINARY_EXTENSIONS:
                continue

            # Skip files larger than 5 MB to prevent OOM
            try:
                if filepath.stat().st_size > 5_000_000:
                    continue
            except OSError:
                continue
            try:
                lines = filepath.read_text(encoding="utf-8").splitlines()
            except (UnicodeDecodeError, PermissionError, OSError):
                continue

            try:
                rel = filepath.relative_to(root).as_posix()
            except ValueError:
                rel = str(filepath)

            # Collect matches with context for this file
            file_lines: list[tuple[int, bool, str]] = []
            # Track which line numbers are already emitted to avoid duplicates
            # when context windows of adjacent matches overlap.
            emitted: set[int] = set()
            for i, line in enumerate(lines):
                # Check deadline every 1000 lines within large files
                if i % 1000 == 0 and i > 0 and time.monotonic() > deadline:
                    deadline_hit = True
                    break
                if compiled.search(line):
                    for offset in range(max(0, i - 1), min(len(lines), i + 2)):
                        if offset not in emitted:
                            emitted.add(offset)
                            # Use pattern match (not offset==i) to determine separator
                            # so context lines that also match get ':' not '-'.
                            is_match = bool(compiled.search(lines[offset]))
                            file_lines.append((offset + 1, is_match, lines[offset]))
                    match_count += 1
                    if match_count >= max_results:
                        break
            if file_lines:
                file_blocks.append((rel, file_lines))
            if match_count >= max_results or deadline_hit:
                break

        if walk_deadline[0]:
            deadline_hit = True

        if not file_blocks:
            suffix = " (search timed out — results may be incomplete)" if deadline_hit else ""
            return f"No matches for pattern '{pattern}'{suffix}"

        # Format as ripgrep --heading style (list + join to avoid quadratic concat)
        parts: list[str] = []
        for rel, file_lines in file_blocks:
            lines_out = [rel]
            for linenum, is_match, text in file_lines:
                sep = ":" if is_match else "-"
                lines_out.append(f"{linenum}{sep}{text}")
            parts.append("\n".join(lines_out))

        header = f"Found {match_count} match(es) for '{pattern}'"
        if deadline_hit:
            header += " (search timed out — results may be incomplete)"
        return header + ":\n\n" + "\n\n".join(parts)
