"""megaphone_reload tool — apply megaphone.yaml changes without restart.

The setup skill walks the user through editing ~/.praestoclaw/megaphone.yaml,
then calls this tool to make the changes take effect: registered cron jobs
are removed and re-registered from the freshly loaded config.

Risk score 0 — the tool only reshapes the local cron registry from a config
file the user already controls; no external side effects.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.risk import RiskAssessment, RiskScore

if TYPE_CHECKING:
    from praestoclaw.cron.service import SchedulerService


class MegaphoneReloadTool(Tool):
    """Reload ~/.praestoclaw/megaphone.yaml and re-register cron jobs."""

    risk_range = (0, 0)

    def __init__(self, scheduler: SchedulerService | None) -> None:
        self._scheduler = scheduler

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=15)

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="Local cron registry reshape from user-owned config file")

    @property
    def name(self) -> str:
        return "megaphone_reload"

    @property
    def description(self) -> str:
        return (
            "Apply changes to the megaphone config "
            "(~/.praestoclaw/skills/megaphone/megaphone.yaml) without restarting "
            "PraestoClaw. Removes all currently registered megaphone-* cron jobs "
            "and re-registers them from the freshly loaded config. Call this "
            "after editing the config (enable/disable a source, change schedule, "
            "add a channel/rule/repo, etc.). Returns the list of active jobs."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {"type": "object", "properties": {}, "additionalProperties": False}

    async def execute(self, **kwargs: Any) -> str:
        if self._scheduler is None:
            return "Error: scheduler not running — cron is disabled in this PraestoClaw instance."

        from praestoclaw.megaphone.config import load_config
        from praestoclaw.megaphone.loader import (
            register_megaphone_jobs,
            unregister_megaphone_jobs,
        )

        try:
            removed = unregister_megaphone_jobs(self._scheduler)
        except Exception as exc:
            logger.exception("megaphone_reload: unregister failed")
            return f"Error removing existing megaphone jobs: {exc}"

        try:
            cfg = load_config()
        except Exception as exc:
            logger.exception("megaphone_reload: config load failed")
            return (
                "Error loading megaphone config "
                f"(~/.praestoclaw/skills/megaphone/megaphone.yaml): {exc}\n"
                f"(Removed {len(removed)} previously registered jobs before the failure.)"
            )

        if not cfg.enabled:
            return (
                f"Removed {len(removed)} megaphone job(s). "
                "Top-level `megaphone.enabled` is false — nothing re-registered."
            )

        try:
            registered = register_megaphone_jobs(self._scheduler, cfg)
        except Exception as exc:
            logger.exception("megaphone_reload: register failed")
            return f"Error registering megaphone jobs: {exc}"

        if not registered:
            return (
                f"Removed {len(removed)} megaphone job(s). "
                "No source is enabled with valid targets — nothing re-registered. "
                "(Set `<source>.enabled: true` and add at least one channel/rule/repo.)"
            )

        return (
            f"Removed {len(removed)} previous job(s); "
            f"registered {len(registered)} active job(s): {', '.join(registered)}."
        )


class MegaphoneStateTool(Tool):
    """Read and update Megaphone config/state through a narrow local API."""

    MAX_SNAPSHOT_SESSIONS = 128
    risk_range = (1, 1)

    def __init__(self) -> None:
        self._snapshot_sessions: dict[str, None] = {}

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=15)

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(1, reason="Local Megaphone config/state read or watermark update")

    @property
    def name(self) -> str:
        return "megaphone_state"

    @property
    def description(self) -> str:
        return (
            "Read the active Megaphone config/state snapshot and update Megaphone "
            "watermarks/caches. Use this in megaphone cron scans instead of reading "
            "~/.praestoclaw/skills/megaphone files directly."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": [
                        "snapshot",
                        "mark_emails_seen",
                        "unseen_emails",
                        "update_teams",
                        "set_user_identity",
                        "mark_user_identity_checked",
                        "set_teams_ids",
                        "mark_teams_ids_checked",
                        "invalidate_teams_ids",
                    ],
                },
                "source": {"type": "string", "enum": ["email", "teams", "all"]},
                "msg_ids": {"type": "array", "items": {"type": "string"}},
                "channel_id": {"type": "string"},
                "last_message_id": {"type": "string"},
                "channel_name": {"type": "string"},
                "team_id": {"type": ["string", "null"]},
                "identity": {"type": "object"},
            },
            "required": ["action"],
            "additionalProperties": False,
        }

    async def execute(self, **kwargs: Any) -> str:
        action = str(kwargs.get("action") or "")

        from praestoclaw.megaphone.state import MegaphoneState

        if action == "snapshot":
            source = str(kwargs.get("source") or "all")
            session_id = self._session_id(kwargs)
            if self._snapshot_session_cached(session_id):
                return json.dumps(
                    {
                        "ok": True,
                        "already_loaded": True,
                        "message": (
                            "Megaphone snapshot was already loaded for this session. "
                            "Reuse the previous snapshot result; state was not reloaded."
                        ),
                    },
                    ensure_ascii=False,
                )
            from praestoclaw.megaphone.config import config_path, load_config

            cfg = load_config()
            state = MegaphoneState()
            payload = self._snapshot(cfg, state, source, str(config_path()))
            self._remember_snapshot_session(session_id)
            return json.dumps(payload, ensure_ascii=False, indent=2, default=str)

        state = MegaphoneState()

        if action == "mark_emails_seen":
            blocked = self._watermark_block_reason(kwargs)
            if blocked:
                return blocked
            msg_ids = [str(v) for v in kwargs.get("msg_ids") or [] if v]
            state.mark_emails_seen(msg_ids)
            state.save_email()
            return json.dumps(
                {"ok": True, "marked": msg_ids, "advanced": bool(msg_ids)},
                ensure_ascii=False,
            )

        if action == "unseen_emails":
            msg_ids = [str(v) for v in kwargs.get("msg_ids") or [] if v]
            if not msg_ids:
                return (
                    "Error: unseen_emails requires msg_ids from messages already fetched with "
                    "MCP_mail; it only filters candidate IDs and does not query email."
                )
            unseen = state.unseen_emails(msg_ids)
            return json.dumps({"unseen": unseen}, ensure_ascii=False)

        if action == "update_teams":
            blocked = self._watermark_block_reason(kwargs)
            if blocked:
                return blocked
            channel_id = str(kwargs.get("channel_id") or "")
            last_message_id = str(kwargs.get("last_message_id") or "")
            if not channel_id or not last_message_id:
                return "Error: update_teams requires channel_id and last_message_id."
            state.update_teams(channel_id, last_message_id)
            state.save_teams()
            return json.dumps({"ok": True, "channel_id": channel_id}, ensure_ascii=False)

        if action == "set_user_identity":
            identity = kwargs.get("identity")
            if not isinstance(identity, dict):
                return "Error: set_user_identity requires identity object."
            state.set_user_identity(identity)
            state.save_identity()
            return json.dumps(
                {"ok": True, "identity": state.get_user_identity()}, ensure_ascii=False
            )

        if action == "mark_user_identity_checked":
            state.mark_user_identity_checked()
            state.save_identity()
            return json.dumps({"ok": True}, ensure_ascii=False)

        if action == "set_teams_ids":
            channel_name = str(kwargs.get("channel_name") or "")
            channel_id = str(kwargs.get("channel_id") or "")
            team_id = kwargs.get("team_id")
            if not channel_name or not channel_id:
                return "Error: set_teams_ids requires channel_name and channel_id."
            state.set_teams_ids(channel_name, None if team_id is None else str(team_id), channel_id)
            state.save_teams()
            return json.dumps({"ok": True, "channel_name": channel_name}, ensure_ascii=False)

        if action == "mark_teams_ids_checked":
            channel_name = str(kwargs.get("channel_name") or "")
            if not channel_name:
                return "Error: mark_teams_ids_checked requires channel_name."
            state.mark_teams_ids_checked(channel_name)
            state.save_teams()
            return json.dumps({"ok": True, "channel_name": channel_name}, ensure_ascii=False)

        if action == "invalidate_teams_ids":
            channel_name = str(kwargs.get("channel_name") or "")
            if not channel_name:
                return "Error: invalidate_teams_ids requires channel_name."
            removed = state.invalidate_teams_ids(channel_name)
            state.save_teams()
            return json.dumps(
                {"ok": True, "channel_name": channel_name, "was_cached": removed},
                ensure_ascii=False,
            )

        return f"Error: unknown action '{action}'."

    @staticmethod
    def _session_id(kwargs: dict[str, Any]) -> str:
        return str(kwargs.get("_session_id") or kwargs.get("session_id") or "")

    @staticmethod
    def _snapshot_cacheable_session(session_id: str) -> bool:
        return session_id.startswith("scheduler_megaphone-")

    def _snapshot_session_cached(self, session_id: str) -> bool:
        return bool(
            session_id
            and self._snapshot_cacheable_session(session_id)
            and session_id in self._snapshot_sessions
        )

    def _remember_snapshot_session(self, session_id: str) -> None:
        if not session_id or not self._snapshot_cacheable_session(session_id):
            return
        if session_id in self._snapshot_sessions:
            self._snapshot_sessions.pop(session_id)
        self._snapshot_sessions[session_id] = None
        while len(self._snapshot_sessions) > self.MAX_SNAPSHOT_SESSIONS:
            oldest = next(iter(self._snapshot_sessions))
            self._snapshot_sessions.pop(oldest)

    def _watermark_block_reason(self, kwargs: dict[str, Any]) -> str | None:
        session_id = self._session_id(kwargs)
        if not session_id:
            return None
        if not session_id.startswith("scheduler_megaphone-"):
            return None
        bad = self._first_prior_session_error(
            session_id,
            source=self._source_from_session(session_id),
        )
        if not bad:
            return None
        return (
            "Error: refusing to advance Megaphone watermarks because an earlier tool call "
            f"in session {session_id!r} failed: {bad}"
        )

    @staticmethod
    def _source_from_session(session_id: str) -> str:
        if session_id.startswith("scheduler_megaphone-email_"):
            return "email"
        if session_id.startswith("scheduler_megaphone-teams_"):
            return "teams"
        return ""

    def _first_prior_session_error(self, session_id: str, *, source: str) -> str | None:
        from praestoclaw.megaphone.audit import iter_session_audit_entries
        from praestoclaw.utils.helpers import get_data_dir

        try:
            for entry in iter_session_audit_entries(get_data_dir(), session_id):
                if self._audit_entry_blocks_watermark(entry, source=source):
                    tool = entry.get("tool") or "unknown"
                    preview = str(entry.get("result_preview") or "").strip()
                    return f"{tool}: {preview[:160]}"
        except OSError as exc:
            logger.warning("megaphone_state could not inspect audit logs: {}", exc)
        return None

    @staticmethod
    def _audit_entry_is_error(entry: dict[str, Any]) -> bool:
        from praestoclaw.megaphone.audit import audit_entry_is_failure

        return audit_entry_is_failure(entry)

    def _audit_entry_blocks_watermark(self, entry: dict[str, Any], *, source: str) -> bool:
        if not self._audit_entry_is_error(entry):
            return False
        tool = str(entry.get("tool") or "")
        if source == "email":
            return tool.startswith("MCP_mail")
        if source == "teams":
            return tool.startswith("MCP_teams") or tool == "web_fetch"
        return False

    def _snapshot(self, cfg: Any, state: Any, source: str, path: str) -> dict[str, Any]:
        lookback = int(getattr(cfg, "lookback_hours", 24) or 24)
        data = {
            "config_path": path,
            "config": cfg.model_dump(by_alias=True),
            "state": state._data,
            "computed": {
                "lookback_hours": lookback,
                "user_identity": state.get_user_identity(),
                "user_identity_refresh_due": state.user_identity_refresh_due(),
            },
        }
        if source in {"email", "all"}:
            data["computed"]["email_since"] = state.effective_since_iso("email", lookback)
        if source in {"teams", "all"}:
            teams = []
            for chat in getattr(cfg.teams, "chats", []):
                cached = state.get_teams_ids(chat.name)
                entry: dict[str, Any] = {
                    "name": chat.name,
                    "keywords": list(chat.keywords),
                    "instructions": list(chat.instructions),
                    "cached_ids": cached,
                    "ids_refresh_due": state.teams_ids_refresh_due(chat.name),
                }
                if cached and cached.get("channel_id"):
                    entry["since"] = state.effective_since_teams_iso(cached["channel_id"], lookback)
                    entry["watermark"] = state.teams_watermark(cached["channel_id"])
                teams.append(entry)
            data["computed"]["teams"] = teams
        return data
