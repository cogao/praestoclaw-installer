"""Intelligent parallel tool execution."""

from __future__ import annotations

import asyncio
import os
from collections.abc import Awaitable, Callable

from praestoclaw.providers.base import ToolCallRequest

_PATH_KEYS = ("path", "file_path", "file", "filename")


class ToolParallelizer:
    """Determines parallel safety and executes tool batches."""

    ALWAYS_PARALLEL: frozenset[str] = frozenset(
        {"read_file", "list_files", "search_files", "glob", "web_search", "web_fetch"}
    )
    PATH_SCOPED: frozenset[str] = frozenset({"write_file", "edit_file"})
    NEVER_PARALLEL: frozenset[str] = frozenset({"browser", "spawn"})
    MAX_WORKERS: int = 8

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def should_parallelize(self, tool_calls: list[ToolCallRequest]) -> bool:
        if len(tool_calls) <= 1:
            return False

        names = {tc.name for tc in tool_calls}

        if names & self.NEVER_PARALLEL:
            return False

        if names <= self.ALWAYS_PARALLEL:
            return True

        # If any path-scoped tools, check for overlapping paths
        if names & self.PATH_SCOPED:
            paths = self._extract_paths(tool_calls)
            if not paths:
                return False
            return not self._paths_overlap(paths)

        return False

    async def execute_batch(
        self,
        tool_calls: list[ToolCallRequest],
        execute_fn: Callable[[ToolCallRequest], Awaitable[str]],
    ) -> list[tuple[str, str]]:
        if self.should_parallelize(tool_calls):
            return await self._run_parallel(tool_calls, execute_fn)
        return await self._run_sequential(tool_calls, execute_fn)

    # ------------------------------------------------------------------
    # Path helpers
    # ------------------------------------------------------------------

    def _extract_paths(self, tool_calls: list[ToolCallRequest]) -> list[str]:
        paths: list[str] = []
        for tc in tool_calls:
            for key in _PATH_KEYS:
                if key in tc.arguments:
                    val = tc.arguments[key]
                    if isinstance(val, str):
                        paths.append(os.path.normpath(val))
                        break
        return paths

    def _paths_overlap(self, paths: list[str]) -> bool:
        normed = [os.path.normpath(p) for p in paths]
        for i, a in enumerate(normed):
            for b in normed[i + 1 :]:
                if a == b:
                    return True
                a_sep = a + os.sep
                b_sep = b + os.sep
                if a_sep.startswith(b_sep) or b_sep.startswith(a_sep):
                    return True
        return False

    # ------------------------------------------------------------------
    # Execution strategies
    # ------------------------------------------------------------------

    async def _run_parallel(
        self,
        tool_calls: list[ToolCallRequest],
        execute_fn: Callable[[ToolCallRequest], Awaitable[str]],
    ) -> list[tuple[str, str]]:
        sem = asyncio.Semaphore(self.MAX_WORKERS)

        async def _guarded(tc: ToolCallRequest) -> tuple[str, str]:
            async with sem:
                try:
                    result = await execute_fn(tc)
                    return (tc.id, result)
                except Exception as exc:
                    return (tc.id, f"[error] {exc}")

        results = await asyncio.gather(*[_guarded(tc) for tc in tool_calls])
        return list(results)

    async def _run_sequential(
        self,
        tool_calls: list[ToolCallRequest],
        execute_fn: Callable[[ToolCallRequest], Awaitable[str]],
    ) -> list[tuple[str, str]]:
        results: list[tuple[str, str]] = []
        for tc in tool_calls:
            try:
                result = await execute_fn(tc)
                results.append((tc.id, result))
            except Exception as exc:
                results.append((tc.id, f"[error] {exc}"))
        return results
