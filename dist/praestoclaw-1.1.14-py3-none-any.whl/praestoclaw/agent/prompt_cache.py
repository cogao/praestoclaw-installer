"""Prompt cache breakpoint injection for Anthropic-style providers."""

from __future__ import annotations

import copy
from typing import Any

from praestoclaw.providers.base import LLMProvider

CACHE_MARKER = {"type": "ephemeral"}


def _inject_cache_control(msg: dict[str, Any], marker: dict[str, str]) -> None:
    """Inject cache_control into a message in-place."""
    content = msg.get("content")
    if isinstance(content, str):
        msg["content"] = [{"type": "text", "text": content, "cache_control": marker}]
    elif isinstance(content, list):
        msg["content"] = [*content[:-1], {**content[-1], "cache_control": marker}]
    else:
        msg["cache_control"] = marker


def apply_cache_breakpoints(
    messages: list[dict[str, Any]],
    provider: LLMProvider,
    *,
    cache_ttl: str = "5m",
) -> list[dict[str, Any]]:
    """Inject Anthropic cache_control breakpoints using 'system_and_3' strategy."""
    if not provider.supports_cache_control:
        return messages

    result = copy.deepcopy(messages)
    marker = CACHE_MARKER

    # Slot 0: system prompt
    for msg in result:
        if msg.get("role") == "system":
            _inject_cache_control(msg, marker)
            break

    # Slots 1-3: last 3 non-system messages
    non_system = [msg for msg in result if msg.get("role") != "system"]
    for msg in non_system[-3:]:
        _inject_cache_control(msg, marker)

    return result
