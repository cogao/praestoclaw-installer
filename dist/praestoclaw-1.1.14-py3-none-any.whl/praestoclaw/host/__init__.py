"""Agent Host skeleton for the channel rewrite."""

from praestoclaw.host.runtime_contracts import (
    AgentRuntimeProtocol,
    AgentRuntimeRequest,
    AgentRuntimeResult,
    TurnProvenanceSummary,
)

__all__ = [
    "AgentRuntimeProtocol",
    "AgentRuntimeRequest",
    "AgentRuntimeResult",
    "AgentRuntime",
    "AgentLoopRuntimeAdapter",
    "InboundMessageBusRuntimeAdapter",
    "TurnProvenanceSummary",
]


def __getattr__(name: str) -> object:
    if name in {"AgentLoopRuntimeAdapter", "AgentRuntime", "InboundMessageBusRuntimeAdapter"}:
        from praestoclaw.host.legacy_agent_runtime import (
            AgentLoopRuntimeAdapter,
            AgentRuntime,
            InboundMessageBusRuntimeAdapter,
        )

        return {
            "AgentLoopRuntimeAdapter": AgentLoopRuntimeAdapter,
            "AgentRuntime": AgentRuntime,
            "InboundMessageBusRuntimeAdapter": InboundMessageBusRuntimeAdapter,
        }[name]
    raise AttributeError(name)
