"""Hook runner port reserved for the message-flow rewrite."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Any, Protocol, TypeVar

T = TypeVar("T")


class HookFailurePolicy(StrEnum):
    FAIL_OPEN = "fail_open"
    FAIL_CLOSED = "fail_closed"


@dataclass(frozen=True, slots=True)
class GateDecision:
    allowed: bool
    reason: str | None = None

    @classmethod
    def allow(cls) -> GateDecision:
        return cls(allowed=True)

    @classmethod
    def block(cls, reason: str) -> GateDecision:
        return cls(allowed=False, reason=reason)


class HookRunner(Protocol):
    async def observe(self, name: str, event: object) -> None: ...

    async def modify(self, name: str, event: T) -> T: ...

    async def gate(self, name: str, event: object) -> GateDecision: ...

    async def claim(self, name: str, event: object) -> Any | None: ...


class NoopHookRunner:
    async def observe(self, name: str, event: object) -> None:
        return None

    async def modify(self, name: str, event: T) -> T:
        return event

    async def gate(self, name: str, event: object) -> GateDecision:
        return GateDecision.allow()

    async def claim(self, name: str, event: object) -> Any | None:
        return None
