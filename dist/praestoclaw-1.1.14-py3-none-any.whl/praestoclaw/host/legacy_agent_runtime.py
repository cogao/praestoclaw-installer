"""Adapter from the new runtime contract to the existing AgentLoopV2.

This is a cutover aid for the TUI direct path and the local webchat
WebSocket path. It synthesizes a ``(channel, channel_id)`` pair from the
turn provenance so tools that gate on a real user-originated channel
context (e.g. the a2a tool) work correctly. Without this synthesis the
a2a tool falsely reports "background/cron" because both kwargs default
to empty strings.
"""

from __future__ import annotations

from typing import Any

from agent_gateway_protocol.agent_link.v1 import LogicalChannel

from praestoclaw.agent.loop_v2 import AgentLoopV2
from praestoclaw.bus.events import InboundMessage
from praestoclaw.bus.queue import MessageBus
from praestoclaw.config.schema import ChannelType
from praestoclaw.host.runtime_contracts import AgentRuntimeRequest, AgentRuntimeResult

# Map turn-provenance ``logical_channel`` strings onto the legacy ChannelType
# enum that the agent loop and tools expect during the cutover.
_LOGICAL_CHANNEL_MAP: dict[str, ChannelType] = {
    LogicalChannel.LOCAL_TUI.value: ChannelType.CLI,
    LogicalChannel.LOCAL_WEBCHAT.value: ChannelType.WEB,
    LogicalChannel.CLOUD_TUI.value: ChannelType.CLOUD,
    LogicalChannel.SCHEDULER_LOCAL.value: ChannelType.CLI,
    LogicalChannel.TEAMS.value: ChannelType.CLOUD,
    LogicalChannel.A2A.value: ChannelType.CLOUD,
    LogicalChannel.U2U.value: ChannelType.CLOUD,
    LogicalChannel.SCHEDULER_REMOTE.value: ChannelType.CLOUD,
    LogicalChannel.FUTURE_EXTERNAL.value: ChannelType.CLOUD,
    "agent_link": ChannelType.CLOUD,
}


class AgentLoopRuntimeAdapter:
    def __init__(self, agent_loop: AgentLoopV2) -> None:
        self._agent_loop = agent_loop

    async def run_once(self, request: AgentRuntimeRequest) -> AgentRuntimeResult:
        metadata: dict[str, Any] = dict(request.runtime_policy.get("message_metadata") or {})
        channel: ChannelType = ChannelType.CLI
        if request.turn_id:
            metadata["turn_id"] = request.turn_id
        if request.turn_provenance is not None:
            logical = request.turn_provenance.logical_channel
            metadata["turn_provenance"] = {
                "initiated_by": request.turn_provenance.initiated_by.value,
                "human_initiated": request.turn_provenance.human_initiated,
                "logical_channel": logical,
                "trust_boundary": request.turn_provenance.trust_boundary,
                "supervision_required": request.turn_provenance.supervision_required,
            }
            if not request.turn_provenance.human_initiated or logical in {
                LogicalChannel.A2A.value,
                LogicalChannel.U2U.value,
                LogicalChannel.SCHEDULER_LOCAL.value,
                LogicalChannel.SCHEDULER_REMOTE.value,
            }:
                metadata["execution_lane"] = "system"
            channel = _LOGICAL_CHANNEL_MAP.get(logical) or (
                ChannelType.CLI
                if request.turn_provenance.human_initiated
                and request.turn_provenance.trust_boundary == "local"
                else ChannelType.CLOUD
            )
        raw_channel_override = str(request.runtime_policy.get("channel_type") or "").strip()
        if raw_channel_override:
            channel = ChannelType.of(raw_channel_override, default=channel)

        route_identity = str(request.runtime_policy.get("route_identity") or "").strip()
        # Keep persistence/session identity stable (request.session_id), but
        # route runtime/tool side-effects back to the originating connection.
        # Fallback to session_id for callers that don't provide route_identity.
        channel_id = route_identity or request.session_id
        run_kwargs: dict[str, Any] = {
            "channel": channel,
            "channel_id": channel_id,
            "metadata": metadata,
        }
        # Thread telemetry ids set by ChannelTurnKernel into metadata so
        # _execute_tools can tag tool_invoked events with the same turn/session.
        for key in ("telemetry_turn_id", "telemetry_session_id"):
            val = request.runtime_policy.get(key)
            if isinstance(val, str) and val:
                metadata[key] = val
        exclude_tools = request.tool_policy.get("exclude_tools")
        if isinstance(exclude_tools, list) and exclude_tools:
            run_kwargs["exclude_tools"] = [str(tool) for tool in exclude_tools]

        response = await self._agent_loop.run_once(
            request.user_content,
            session_id=request.session_id,
            **run_kwargs,
        )
        return AgentRuntimeResult(content=response)


class AgentRuntime(AgentLoopRuntimeAdapter):
    """Channel-blind runtime facade backed by the legacy AgentLoopV2 core."""


class InboundMessageBusRuntimeAdapter:
    """Compatibility runtime that dispatches sanitized turns to the message bus.

    This keeps legacy channel delivery behavior intact while allowing channel
    ingress to pass through ``ChannelTurnKernel`` before entering
    ``AgentLoopV2.start()``.
    """

    def __init__(self, bus: MessageBus, *, channel: ChannelType) -> None:
        self._bus = bus
        self._channel = channel

    async def run_once(self, request: AgentRuntimeRequest) -> AgentRuntimeResult:
        policy = request.runtime_policy
        metadata = dict(policy.get("message_metadata") or {})
        if request.turn_id:
            metadata["turn_id"] = request.turn_id
        # Thread telemetry ids set by ChannelTurnKernel through the bus.
        for key in ("telemetry_turn_id", "telemetry_session_id"):
            val = policy.get(key)
            if isinstance(val, str) and val:
                metadata[key] = val
        if request.turn_provenance is not None:
            metadata["turn_provenance"] = {
                "initiated_by": request.turn_provenance.initiated_by.value,
                "human_initiated": request.turn_provenance.human_initiated,
                "logical_channel": request.turn_provenance.logical_channel,
                "trust_boundary": request.turn_provenance.trust_boundary,
                "supervision_required": request.turn_provenance.supervision_required,
            }
            if not request.turn_provenance.human_initiated or (
                request.turn_provenance.logical_channel
                in {
                    LogicalChannel.A2A.value,
                    LogicalChannel.U2U.value,
                    LogicalChannel.SCHEDULER_LOCAL.value,
                    LogicalChannel.SCHEDULER_REMOTE.value,
                }
            ):
                metadata["execution_lane"] = "system"

        route_identity = str(policy.get("route_identity") or request.session_id)
        await self._bus.publish_inbound(
            InboundMessage(
                logical_channel=self._channel,
                physical_ingress=str(policy.get("physical_ingress") or self._channel.value),
                delivery_route_id=route_identity,
                sender_id=str(policy.get("sender_id") or ""),
                sender_name=str(policy.get("sender_name") or policy.get("sender_id") or ""),
                content=request.user_content,
                content_format=str(policy.get("content_format") or "text"),
                conversation_id=str(policy.get("conversation_id") or request.session_id),
                turn_id=request.turn_id or route_identity,
                agent_session_key=request.session_id,
                attachments=list(request.attachments) if request.attachments else None,
                timestamp=str(policy.get("received_at") or "") or None,
                metadata=metadata,
            )
        )
        return AgentRuntimeResult(content="", metadata={"dispatched": True})
