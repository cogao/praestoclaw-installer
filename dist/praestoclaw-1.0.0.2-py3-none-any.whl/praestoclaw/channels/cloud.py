"""
Cloud channel — outbound WebSocket relay to PraestoClaw Cloud Gateway.

Connects to wss://<cloud-gateway>/connect using an Entra ID access token.
Supports two login methods:

  browser  — opens the default browser for interactive PKCE auth code flow
             (http://localhost callback, no redirect URI limitations).
  wam      — WAM broker (native OS auth dialog, no browser); falls back to
             browser PKCE if the app registration doesn't support broker.
             Requires msal[broker] on Windows.
  device   — device code flow (visit a URL + enter a code); works in
             headless / SSH / corporate environments that block browser launch.
             Only used when explicitly configured (many tenants disable this).
  auto     — (default) same as browser. WAM not attempted unless explicitly
             configured via login_method=wam.

Inbound  (server → client): connected, buffered_start/end, message, ping, error
Outbound (client → server): response, chunk, pong
"""

from __future__ import annotations

import asyncio
import html as _html
import json
import re
import socket
import time
import webbrowser
from pathlib import Path
from typing import Any, Literal

import msal
import websockets
import websockets.exceptions
from loguru import logger
from rich.console import Console
from rich.panel import Panel

from praestoclaw.bus.events import EventType, InboundMessage, OutboundMessage, StreamingChunk
from praestoclaw.bus.queue import MessageBus
from praestoclaw.channels.base import BaseChannel
from praestoclaw.channels.conv_ref_store import ConvRefStore
from praestoclaw.config.schema import ChannelType
from praestoclaw.mcp.defaults import SHARED_ENTRA_CLIENT_ID
from praestoclaw.utils.helpers import get_auth_dir, webchat_url_from_connect
from praestoclaw.utils.html import html_to_markdown

# MSAL error codes that indicate admin consent is required or the user
# cannot consent to the requested permissions.  When the primary app
# registration triggers one of these, we fall back to the shared Entra
# client ID (aebc6443 — VS Code / Agency) which is pre-consented in
# most enterprise tenants.
_CONSENT_ERROR_CODES = frozenset(
    {
        "AADSTS90094",  # admin consent required
        "AADSTS65001",  # user/admin has not consented
        "AADSTS70011",  # invalid scope (consent not granted)
        "AADSTS650052",  # app needs permissions that require admin consent
        "AADSTS700024",  # client assertion audience not allowed
    }
)

_console = Console()


class CloudChannel(BaseChannel):
    """Outbound WebSocket relay to PraestoClaw Cloud Gateway."""

    def __init__(
        self,
        bus: MessageBus,
        *,
        url: str,
        tenant_id: str,
        client_id: str,
        scope: str,
        login_method: Literal["auto", "browser", "wam", "device"] = "auto",
        login_port: int = 49216,
        allow_from: list[str] | None = None,
        auto_reconnect: bool = True,
        reconnect_max: int = 60,
        bypass_token: str | None = None,
        open_browser_on_connect: bool = False,
        # A2A Phase 1 parameters
        a2a_enabled: bool = False,
        a2a_instance_id: str | None = None,
        a2a_user_id: str | None = None,
        a2a_is_active_instance: bool = True,
        a2a_protocol_version: str = "1",
        a2a_card_seed: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(bus, allow_from)
        self._url = url
        self._tenant_id = tenant_id
        self._client_id = client_id
        self._scope = scope
        self._login_method = login_method
        self._login_port = login_port
        self._auto_reconnect = auto_reconnect
        self._reconnect_max = reconnect_max

        self._bypass_token = bypass_token
        self._open_browser_on_connect = open_browser_on_connect

        # A2A Phase 1 state
        self._a2a_enabled = a2a_enabled
        self._a2a_instance_id = a2a_instance_id
        self._a2a_user_id = a2a_user_id
        self._a2a_is_active_instance = a2a_is_active_instance
        self._a2a_protocol_version = a2a_protocol_version
        self._a2a_card_seed = a2a_card_seed or {}
        self._a2a_registered = False
        self._a2a_runtime: Any = None  # A2ARuntime — set via set_a2a_runtime()

        self._token: str | None = None
        self._running = False
        self._ws_connected = False  # True only while WebSocket handshake is live
        self._send_queue: asyncio.Queue[str] = asyncio.Queue(maxsize=500)
        self._connect_task: asyncio.Task | None = None
        self._browser_opened = False  # open browser only on first successful connect
        self._runtime: Any = None  # set by Runtime after construction
        self._ping_count = 0  # monotonic counter for ping/pong log correlation
        self._push_deliveries: dict[
            str, dict[str, bool]
        ] = {}  # push_ack results keyed by request_id
        self._push_events: dict[str, asyncio.Event] = {}  # push_ack waiters
        self._local_oid: str | None = None  # set by _capture_identity after MSAL login
        self._local_tid: str | None = None
        self._local_upn: str | None = None  # preferred_username (email), for A2A user_id
        self._conv_ref_store = ConvRefStore()
        self._last_auth_expired: float = -600.0  # ensures first auth_expired always passes
        self._validator: Any = None  # set in start(); see RelayValidator
        self._using_shared_app = False  # set True after fallback to aebc6443 succeeds

        # MSAL PublicClientApplication — persists token cache across reconnects.
        # Skipped in bypass mode (no MSAL calls needed).
        self._cache_path: Path | None = None
        self._broker_enabled = False
        if bypass_token:
            logger.warning("Cloud channel using bypass token — disable for production!")
            self._msal_app = None
        else:
            # Persist MSAL token cache to ~/.praestoclaw/auth/ so login survives process restarts.
            # auth/ is ACL-protected on Windows, chmod 0o700 on POSIX.
            self._cache_path = get_auth_dir() / f"token_cache_{client_id[:8]}.bin"
            self._token_cache = msal.SerializableTokenCache()
            if self._cache_path.exists():
                try:
                    from praestoclaw.security.secrets import decrypt_at_rest

                    raw = decrypt_at_rest(self._cache_path.read_bytes())
                    if raw:
                        self._token_cache.deserialize(raw.decode("utf-8"))
                        logger.debug("MSAL token cache loaded from {}", self._cache_path)
                except Exception as exc:
                    logger.warning(
                        "Cannot load MSAL token cache at {} ({}); starting fresh.",
                        self._cache_path,
                        exc,
                    )
                    # Don't delete — cache may be encrypted with a key that becomes
                    # available later (e.g., after keyring unlock or env var set)
            broker_kwargs: dict[str, Any] = {}
            self._broker_enabled = False
            if login_method == "wam":
                from praestoclaw.utils.auth import _broker_kwargs

                broker_kwargs = _broker_kwargs()
                if broker_kwargs:
                    self._broker_enabled = True
                    logger.debug("Broker enabled ({})", list(broker_kwargs.keys())[0])
                else:
                    logger.warning("login_method=wam but msal[broker] not installed; using browser")
                    self._login_method = "browser"

            self._msal_app = msal.PublicClientApplication(
                client_id=client_id,
                authority=f"https://login.microsoftonline.com/{tenant_id}",
                token_cache=self._token_cache,
                **broker_kwargs,
            )

    def set_runtime(self, runtime: Any) -> None:
        """Set the Runtime reference for admin relay queries."""
        self._runtime = runtime

    @property
    def name(self) -> str:
        return ChannelType.CLOUD

    @property
    def _scopes(self) -> list[str]:
        """MSAL scopes list — empty when no explicit scope configured."""
        return [self._scope] if self._scope else []

    def get_push_delivery(self, request_id: str) -> dict[str, bool] | None:
        """Return and clear accumulated push delivery results for *request_id*.

        Multiple push_ack frames for the same request_id are merged (OR):
        once a sub-channel is marked delivered, it stays delivered.

        Retrieval is one-shot: the stored delivery state for *request_id* is
        removed from the internal cache when this method is called.
        """
        self._push_events.pop(request_id, None)  # clean up waiter
        return self._push_deliveries.pop(request_id, None)

    def wait_push_delivery(self, request_id: str) -> asyncio.Event:
        """Return an ``asyncio.Event`` that is set when a push_ack arrives.

        The caller should ``await asyncio.wait_for(event.wait(), timeout=N)``
        then call ``get_push_delivery()`` to retrieve the results.
        """
        evt = self._push_events.get(request_id)
        if evt is None:
            evt = asyncio.Event()
            self._push_events[request_id] = evt
            # If ack already arrived before wait was registered, set immediately
            if request_id in self._push_deliveries:
                evt.set()
        return evt

    @property
    def is_connected(self) -> bool:
        """True only while the WebSocket handshake is live (not during reconnect backoff)."""
        return self._ws_connected

    # ── Lifecycle ────────────────────────────────────────────────────────────

    def has_cached_credentials(self) -> bool:
        """Return True if a cached session likely exists (fast, no network).

        Used by the runtime to decide whether to auto-connect on startup.
        Checks for accounts in broker + browser caches without attempting
        token refresh (that happens in _acquire_token_sync).
        """
        if self._bypass_token:
            return True
        from praestoclaw.utils.helpers import get_auth_dir

        # Check broker and browser caches for both primary and shared apps.
        for cid in (self._client_id, SHARED_ENTRA_CLIENT_ID):
            for suffix in ("_broker", ""):
                cache_path = get_auth_dir() / f"token_cache_{cid[:8]}{suffix}.bin"
                if not cache_path.exists():
                    continue
                try:
                    token_cache = msal.SerializableTokenCache()
                    from praestoclaw.security.secrets import decrypt_at_rest

                    raw = decrypt_at_rest(cache_path.read_bytes())
                    if raw:
                        token_cache.deserialize(raw.decode("utf-8"))
                    app = msal.PublicClientApplication(cid, token_cache=token_cache)
                    if app.get_accounts():
                        return True
                except Exception:  # noqa: S112 — best-effort cache check
                    continue
        return False

    async def start(self) -> None:
        if self._running:
            return  # already started — prevent duplicate connection tasks
        self._running = True

        # Acquire initial token — may raise RuntimeError("Cloud sign-in skipped")
        # if the user selects Skip in the interactive menu.
        self._token = await asyncio.get_running_loop().run_in_executor(
            None, self._acquire_token_sync
        )

        # Create relay validator — reads identity dynamically from this channel
        from praestoclaw.security.relay_validator import RelayValidator

        self._validator = RelayValidator(channel=self)

        # Subscribe to outbound bus messages
        self._bus.on_outbound(self._handle_outbound)

        # Launch connection loop as background task
        self._connect_task = asyncio.create_task(self._connect_loop(), name="cloud-channel-loop")
        logger.info("Cloud channel started -> {}", self._url)

    async def stop(self) -> None:
        self._running = False
        if self._connect_task and not self._connect_task.done():
            self._connect_task.cancel()
        # Drain the send queue so callers aren't stuck
        while not self._send_queue.empty():
            try:
                self._send_queue.get_nowait()
            except asyncio.QueueEmpty:
                break
        logger.info("Cloud channel stopped")

    async def send(self, channel_id: str, content: str, **kwargs: Any) -> None:
        """Enqueue a response frame (called by ChannelManager).

        Approval cards are sent as ``notification`` frames so the gateway does
        NOT delete the reply context — the context must stay alive until the
        tool result is delivered after the user approves/denies.
        """
        # Approval cards use "notification" so the gateway keeps deleteContext=false,
        # preserving the reply context until the final tool result is delivered.
        # Callers pass keep_context=True (via kwargs) to opt in.
        frame_type = "notification" if kwargs.get("keep_context") else "response"

        # Non-routable channel_id (e.g. "scheduler:xxx") → send as a "push"
        # frame.  Push frames don't target a specific conversation; the gateway
        # broadcasts them to the connected user's active clients.
        _INTERNAL_PREFIXES = ("scheduler:", "agent-", "cron:", "copilot-", "claude-", "a2a:")
        is_non_routable = (
            any(channel_id.startswith(p) for p in _INTERNAL_PREFIXES)
            or channel_id == self.name  # bare "cloud" from notify tool without conversation context
        )

        if is_non_routable:
            data: dict[str, Any] = {
                "type": "push",
                "content": content,
                "format": kwargs.get("format", "markdown"),
            }
            push_target = kwargs.get("push_target")  # "teams" | "webchat" | None
            if push_target:
                data["target"] = push_target
            push_request_id = kwargs.get("push_request_id")
            if push_request_id:
                data["request_id"] = push_request_id
            title = kwargs.get("title")
            if title:
                data["title"] = title
            # Attach stored conv_ref for stateless Teams proactive messaging.
            # Skip when target is explicitly "webchat" (no Teams routing needed).
            if self._local_oid and push_target != "webchat":
                ref = self._conv_ref_store.get(self._local_oid)
                if ref:
                    data["conv_ref"] = ref
        else:
            data = {
                "type": frame_type,
                "channel_id": channel_id,
                "content": content,
                "format": kwargs.get("format", "markdown"),
            }
            thread_id = kwargs.get("thread_id")
            if thread_id:
                data["thread_id"] = thread_id

        frame = json.dumps(data, ensure_ascii=False)
        logger.info(
            "[A2A] cloud TX outbound: type={} channel_id={} content_len={}",
            data.get("type"),
            channel_id,
            len(content or ""),
        )
        await self._send_queue.put(frame)

    async def send_typing(self, channel_id: str, **kwargs: Any) -> None:
        """Send a typing indicator via WebSocket."""
        frame = json.dumps({"type": "typing", "channel_id": channel_id}, ensure_ascii=False)
        await self._send_queue.put(frame)

    # ── Outbound bus handler ─────────────────────────────────────────────────

    async def _handle_outbound(self, msg: OutboundMessage | StreamingChunk) -> None:
        """Route streaming chunks from the agent → WebSocket send queue.

        OutboundMessage (non-streaming responses) are handled by ChannelManager
        which calls CloudChannel.send() — registering both handlers would send
        each response twice and cause reply_context_expired errors on the second.
        Only StreamingChunk is handled here because ChannelManager.send() has no
        streaming-chunk path.
        """
        if msg.channel != self.name:
            return

        if not isinstance(msg, StreamingChunk):
            return

        frame = json.dumps(
            {
                "type": "chunk",
                "channel_id": msg.channel_id,
                "content": msg.content,
                "chunk_type": msg.chunk_type,
                "done": msg.done,
            },
            ensure_ascii=False,
        )
        await self._send_queue.put(frame)

    # ── Connection loop ──────────────────────────────────────────────────────

    async def _connect_loop(self) -> None:
        """Main loop: connect → run → reconnect with exponential backoff."""
        backoff = 1
        while self._running:
            try:
                await self._run_connection()
                backoff = 1  # reset on clean close
            except asyncio.CancelledError:
                break
            except Exception as exc:
                if not self._running:
                    break

                # websockets follows HTTP redirects and raises InvalidURI when the
                # Location header has an https:// scheme (not wss://).  This happens
                # when the server redirects the WebSocket upgrade to an auth page
                # (e.g. /Account/AccessDenied) instead of returning 401/403.
                # Force interactive re-authentication in this case rather than
                # silently refreshing a token that the server is already rejecting.
                is_auth_redirect = isinstance(exc, websockets.exceptions.InvalidURI) and (
                    "AccessDenied" in str(exc) or "login" in str(exc).lower()
                )
                # websockets ≤13: RejectHandshake with exc.status_code
                # websockets ≥14: InvalidStatus with exc.response.status_code
                _status = getattr(exc, "status_code", None) or getattr(
                    getattr(exc, "response", None), "status_code", None
                )
                _rejection_types = (websockets.exceptions.InvalidStatus,)
                if hasattr(websockets.exceptions, "RejectHandshake"):
                    _rejection_types = (*_rejection_types, websockets.exceptions.RejectHandshake)  # type: ignore[assignment]
                is_auth_rejection = isinstance(exc, _rejection_types) and _status in (401, 403)

                if is_auth_redirect or is_auth_rejection:
                    logger.warning(
                        "Cloud gateway rejected connection (auth failure: {}). Re-authenticating…",
                        exc,
                    )
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2, self._reconnect_max)
                    # Route through _acquire_token_sync so bypass-token mode
                    # (where _msal_app is None) returns the bypass token directly
                    # instead of crashing inside _interactive_login.
                    try:
                        self._token = await asyncio.get_running_loop().run_in_executor(
                            None, self._acquire_token_sync
                        )
                    except Exception as auth_err:
                        logger.error("Re-authentication failed: {}", auth_err)
                else:
                    if isinstance(exc, TimeoutError):
                        logger.warning(
                            "Cloud gateway opening handshake timed out. "
                            "Check gateway reachability/DNS/proxy and IPv6 routing. "
                            "Reconnecting in {}s…",
                            backoff,
                        )
                    logger.warning(
                        "Cloud gateway connection lost: {}. Reconnecting in {}s…", exc, backoff
                    )
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2, self._reconnect_max)

                    # Refresh token silently before reconnecting
                    try:
                        self._token = await asyncio.get_running_loop().run_in_executor(
                            None, self._refresh_token_sync
                        )
                    except Exception as auth_err:
                        logger.error("Token refresh failed: {}", auth_err)

    async def _run_connection(self) -> None:
        """Single WebSocket connection lifecycle."""
        headers = {"Authorization": f"Bearer {self._token}"}

        async with websockets.connect(
            self._url,
            additional_headers=headers,
            ping_interval=None,  # server manages heartbeat via ping/pong frames
            happy_eyeballs_delay=0.25,  # race IPv6/IPv4 to avoid stalled single-stack attempts
            interleave=1,
            open_timeout=15,
            close_timeout=5,
        ) as ws:
            self._ws_connected = True
            self._a2a_registered = False  # Reset on every reconnect
            logger.success("Connected to Cloud Gateway")

            # Handshake: connected → instance_register → instance_registered
            # Must complete BEFORE the send loop starts or CHANNEL_CONNECTED fires
            await self._do_handshake(ws)

            self._bus.events.emit(EventType.CHANNEL_CONNECTED, {"channel": self.name})

            recv_task = asyncio.create_task(self._recv_loop(ws))
            send_task = asyncio.create_task(self._send_loop(ws))

            try:
                done, pending = await asyncio.wait(
                    [recv_task, send_task],
                    return_when=asyncio.FIRST_COMPLETED,
                )
                for task in pending:
                    task.cancel()
                    try:
                        await task
                    except asyncio.CancelledError:
                        pass
                # Re-raise any exception from the completed task
                for task in done:
                    if not task.cancelled():
                        task.result()
            finally:
                self._ws_connected = False
                recv_task.cancel()
                send_task.cancel()

    async def _do_handshake(self, ws) -> None:
        """Gateway handshake: wait for connected, send instance_register, await ack.

        Runs before the send loop and CHANNEL_CONNECTED event so that
        instance_register is always the first outbound frame.
        """
        # Wait for 'connected' frame from gateway
        while True:
            raw = await asyncio.wait_for(ws.recv(), timeout=30)
            frame = json.loads(raw)
            if frame.get("type") == "connected":
                count = frame.get("buffered_count", 0)
                logger.debug("Gateway handshake complete. Buffered messages: {}", count)
                if self._open_browser_on_connect and not self._browser_opened:
                    self._browser_opened = True
                    web_url = webchat_url_from_connect(self._url)
                    asyncio.get_running_loop().run_in_executor(None, webbrowser.open, web_url)
                    logger.info("Opening web chat: {}", web_url)
                break
            else:
                await self._dispatch(frame)

        # Send instance_register directly on the websocket (not via _send_queue)
        sent = await self._send_instance_register(ws)
        if not sent:
            return  # No registration sent — skip waiting for ack

        # Wait for instance_registered acknowledgement
        try:
            while True:
                raw = await asyncio.wait_for(ws.recv(), timeout=15)
                frame = json.loads(raw)
                if frame.get("type") == "instance_registered":
                    await self._on_instance_registered(frame)
                    break
                else:
                    await self._dispatch(frame)
        except TimeoutError:
            logger.warning(
                "Timed out waiting for instance_registered — continuing without registration"
            )

    async def _recv_loop(self, ws) -> None:
        """Process incoming frames from the gateway."""
        async for raw in ws:
            try:
                frame = json.loads(raw)
            except json.JSONDecodeError:
                logger.warning("Malformed frame from gateway: {!r:.100}", raw)
                continue

            await self._dispatch(frame)

    async def _send_loop(self, ws) -> None:
        """Drain send queue → write frames to WebSocket."""
        while True:
            frame = await self._send_queue.get()
            try:
                await ws.send(frame)
            except Exception:
                # Put it back so it's not lost on reconnect
                await self._send_queue.put(frame)
                raise

    # ── Frame dispatch ───────────────────────────────────────────────────────

    async def _dispatch(self, frame: dict[str, Any]) -> None:
        ftype = frame.get("type")

        if ftype == "connected":
            # Normally consumed by _do_handshake before recv_loop starts.
            # Handle here as a safety fallback only.
            count = frame.get("buffered_count", 0)
            logger.debug("Gateway connected frame (late): buffered={}", count)

        elif ftype == "instance_registered":
            # A2A Phase 1: acknowledgement from gateway
            await self._on_instance_registered(frame)

        elif ftype == "message":
            if not self._validator.validate_message(frame):
                logger.warning("Rejected message: relay token validation failed")
                return
            await self._on_message(frame)

        elif ftype == "ping":
            self._ping_count += 1
            await self._send_queue.put(json.dumps({"type": "pong"}, ensure_ascii=False))
            logger.debug(
                "Ping #{} -> pong  [url={} queue_depth={}]",
                self._ping_count,
                self._url,
                self._send_queue.qsize(),
            )

        elif ftype == "buffered_start":
            logger.info("Replaying {} buffered message(s)…", frame.get("count", "?"))

        elif ftype == "buffered_end":
            logger.info("Buffered message replay complete")

        elif ftype == "admin_request":
            caller = self._validator.validate_admin(frame)
            if caller is None:
                logger.warning("Rejected admin_request: relay token validation failed")
                return
            # NOTE: not cryptographically verified in Step 1 (stub validator).
            # Step 3 adds real JWT verification for this value.
            frame["relay_caller_oid"] = caller
            await self._on_admin_request(frame)

        elif ftype == "approval_response":
            # This frame type is NOT generated by the gateway today —
            # WebChat approvals arrive as type=message ("/approve <id>").
            # Validating here is defense-in-depth against injection.
            if not self._validator.validate_message(frame):
                logger.warning("Rejected approval_response: relay token validation failed")
                return
            await self._on_approval_response(frame)

        elif ftype == "push_ack":
            rid = frame.get("request_id", "")
            if rid:
                existing = self._push_deliveries.get(rid, {})
                # Merge: once delivered, stays delivered (multiple pushes for same approval)
                existing["webchat"] = existing.get("webchat", False) or bool(
                    frame.get("webchat_delivered")
                )
                existing["teams"] = existing.get("teams", False) or bool(
                    frame.get("teams_delivered")
                )
                # Capture Teams card ActivityId for cross-channel card updates
                teams_activity_id = frame.get("teams_activity_id")
                if teams_activity_id:
                    existing["teams_activity_id"] = teams_activity_id
                self._push_deliveries[rid] = existing
                # Size cap: evict oldest entries on insert to prevent
                # unbounded growth from acks that are never retrieved.
                _MAX = 1000
                if len(self._push_deliveries) > _MAX:
                    for k in list(self._push_deliveries.keys())[
                        : len(self._push_deliveries) - _MAX
                    ]:
                        del self._push_deliveries[k]
                # Signal any waiter registered via wait_push_delivery()
                evt = self._push_events.get(rid)
                if evt:
                    evt.set()
                logger.debug(
                    "Push ack {}: webchat={} teams={}",
                    rid,
                    existing["webchat"],
                    existing["teams"],
                )

        elif ftype == "error":
            code = frame.get("code", "unknown")
            msg = frame.get("message", "")
            _AUTH_EXPIRED_COOLDOWN = 300  # seconds between accepted auth_expired frames

            # reply_context_expired is expected when a response arrives after the
            # Teams reply window closes (e.g. long-running tool). Log at DEBUG.
            if code == "reply_context_expired":
                logger.debug("Gateway error [{}]: {}", code, msg)
            elif code == "auth_expired":
                # Rate limit before logging to prevent log spam from injected frames.
                now = time.monotonic()
                if now - self._last_auth_expired < _AUTH_EXPIRED_COOLDOWN:
                    logger.debug("Ignoring rapid auth_expired (rate limited)")
                    return
                self._last_auth_expired = now
                logger.warning("Gateway error [{}]: {}", code, msg)
                # Force token refresh on next reconnect
                self._token = None
            else:
                logger.warning("Gateway error [{}]: {}", code, msg)

        elif ftype == "a2a_message":
            env = frame.get("envelope") or {}
            sender_p = env.get("sender") or {}
            receiver_p = env.get("receiver") or {}
            logger.info(
                "[A2A] cloud RX a2a_message: id={} type={} parent={} sender={} receiver={}",
                env.get("id", ""),
                env.get("type", ""),
                env.get("parent_id") or "-",
                sender_p.get("id", "") if isinstance(sender_p, dict) else "",
                receiver_p.get("id", "") if isinstance(receiver_p, dict) else "",
            )
            if self._a2a_runtime:
                await self._a2a_runtime.handle_a2a_message(frame)
            else:
                logger.warning("a2a_message received but A2A runtime not configured")

        elif ftype == "a2a_dispatch":
            logger.info(
                "[A2A] cloud RX a2a_dispatch: id={} status={} code={} msg={}",
                frame.get("message_id", ""),
                frame.get("status", ""),
                frame.get("code", "") or "-",
                frame.get("message", "") or "-",
            )
            if self._a2a_runtime:
                await self._a2a_runtime.handle_a2a_dispatch(frame)
            else:
                logger.warning("a2a_dispatch received but A2A runtime not configured")

        else:
            logger.debug("Unhandled frame type: {}", ftype)

    async def _on_message(self, frame: dict[str, Any]) -> None:
        """Publish an inbound message frame to the bus."""
        content = frame.get("content", "")
        content_format = frame.get("content_format", "text").lower()

        # Strip <at>…</at> @mention XML BEFORE HTML→Markdown conversion,
        # otherwise html_to_markdown strips the tags but leaves the text.
        content = re.sub(r"<at>[^<]*</at>", "", content).strip()

        # Convert HTML rich text to Markdown
        if content_format == "html":
            content = html_to_markdown(content)
            content_format = "markdown"

        channel_id = frame.get("channel_id", "")
        sender_id = frame.get("sender_id", "")
        sender_name = frame.get("sender_name", sender_id)
        thread_id = frame.get("thread_id")
        session_key = frame.get("session_key")
        metadata = {**frame.get("metadata", {})}
        metadata["content_format"] = content_format

        # Allow-list check must happen before any approval fast-path
        # and before storing conv_ref (don't persist routing data from blocked senders).
        if not self.is_allowed(sender_id):
            logger.warning("Message blocked from {} (not in allow_from)", sender_id)
            return

        # Store conv_ref from Teams messages for proactive push later.
        conv_ref = metadata.get("conv_ref")
        if metadata.get("source") == "cloud_teams" and isinstance(conv_ref, dict):
            cr_surl = conv_ref.get("service_url", "")
            cr_cid = conv_ref.get("conversation_id", "")
            if cr_surl and cr_cid and sender_id:
                self._conv_ref_store.upsert(sender_id, cr_surl, cr_cid)

        # Metadata approval fast-path: Teams card button or slash command sends
        # approval_action in metadata — resolve directly, bypassing the blocked queue.
        approval_action = metadata.get("approval_action")
        approval_request_id = metadata.get("approval_request_id")
        if approval_action and approval_request_id:
            await self._on_approval_response(
                {
                    "action": approval_action,
                    "request_id": approval_request_id,
                    "sender_id": sender_id,
                }
            )
            logger.debug(
                "Cloud approval action={} request_id={}", approval_action, approval_request_id
            )
            return

        if not content:
            logger.debug("Cloud message with empty content from {} — ignored", sender_id)
            return

        # Approval keyword / slash-command fast-path — bypass the blocked agent queue.
        cl = content.lower()  # content already stripped via re.sub earlier
        action: str | None = None
        req_id = ""

        parts = content.split(maxsplit=1)
        # /approve <id> · /deny <id> · /always <id>  (with explicit request_id)
        if cl.startswith("/approve ") and len(parts) == 2:
            action, req_id = "approve", parts[1]
        elif cl.startswith("/deny ") and len(parts) == 2:
            action, req_id = "deny", parts[1]
        elif cl.startswith("/always ") and len(parts) == 2:
            action, req_id = "always", parts[1]
        # bare keyword (no id — runtime resolves any single pending approval)
        # Only intercept when there IS a pending approval; otherwise pass
        # through to the agent so "yes"/"no" in normal conversation works.
        elif cl in {"yes", "y", "approve", "/approve"}:
            action = "approve"
        elif cl in {"no", "n", "deny", "/deny"}:
            action = "deny"
        elif cl in {"always", "a", "/always"}:
            action = "always"

        if action and req_id:
            # Explicit /approve <id> — always route to approval
            pass
        elif action:
            # Bare keyword — only intercept if there's a pending approval.
            # Otherwise "yes"/"no" in normal conversation gets swallowed.
            has_pending = False
            if self._runtime and hasattr(self._runtime, "approval_manager"):
                has_pending = bool(self._runtime.approval_manager.get_pending())
            if not has_pending:
                action = None

        if action:
            await self._on_approval_response(
                {"action": action, "request_id": req_id, "sender_id": sender_id}
            )
            logger.debug("Cloud approval action={} request_id={}", action, req_id or "(any)")
            return

        msg = InboundMessage(
            channel=self.name,
            channel_id=channel_id,
            sender_id=sender_id,
            sender_name=sender_name,
            content=content,
            content_format=content_format,
            thread_id=thread_id,
            session_key=session_key,
            timestamp=frame.get("timestamp"),
            metadata=metadata,
        )
        await self._bus.publish_inbound(msg)
        logger.debug(
            "Cloud message channel_id={} sender={} len={}", channel_id, sender_id, len(content)
        )

    async def _on_approval_response(self, frame: dict[str, Any]) -> None:
        """Resolve an approval request directly (bypasses inbound queue).

        Approval responses must NOT go through the inbound message queue
        because the agent loop is blocked in the pre_tool_use hook waiting
        for resolution — routing through the queue would deadlock.
        """
        action = frame.get("action", "")
        request_id = frame.get("request_id", "")
        if not action:
            logger.warning("Malformed approval_response frame: {}", frame)
            return
        # Empty request_id is valid — runtime resolves any single pending approval

        sender_id = frame.get("sender_id", "unknown")

        # Resolve directly via the approval manager on the bus event
        self._bus.events.emit(
            EventType.APPROVAL_RESOLVED,
            {
                "request_id": request_id,
                "action": action,
                "resolver": sender_id,
            },
        )
        logger.debug("Approval response: action={} request_id={}", action, request_id)

    def set_a2a_runtime(self, runtime: Any) -> None:
        """Attach A2A runtime for inbound request dispatch."""
        self._a2a_runtime = runtime
        runtime.set_frame_sender(self.send_a2a_frame)

    async def send_a2a_frame(self, frame: dict[str, Any]) -> None:
        """Enqueue an A2A frame (a2a_message envelope) for sending."""
        await self._send_queue.put(json.dumps(frame, ensure_ascii=False))

    async def _send_instance_register(self, ws) -> bool:
        """Send instance_register frame directly on *ws*.

        Returns True if the frame was sent, False if skipped (no instance_id).
        When ``a2a_enabled`` is False, sends a minimal registration with
        ``is_active_instance=False`` and an opaque anonymous user_id.
        """
        if not self._a2a_instance_id:
            logger.warning("instance_register skipped: instance_id not set")
            return False

        from praestoclaw import __version__

        if self._a2a_enabled:
            # user_id fallback chain: explicit config → logged-in UPN (email) → OID → anon
            user_id = (
                self._a2a_user_id
                or self._local_upn
                or self._local_oid
                or f"anon-{self._a2a_instance_id}"
            )
            is_active = self._a2a_is_active_instance
            card_seed = self._a2a_card_seed
        else:
            user_id = f"anon-{self._a2a_instance_id}"
            is_active = False
            card_seed = {}

        frame = {
            "type": "instance_register",
            "instance_id": self._a2a_instance_id,
            "user_id": user_id,
            "is_active_instance": is_active,
            "instance_version": __version__,
            "protocol_version": self._a2a_protocol_version,
            "card_seed": card_seed,
            "metadata": {"runtime": "praestoclaw"},
        }
        await ws.send(json.dumps(frame, ensure_ascii=False))
        logger.info(
            "Sent instance_register (instance_id={}, user_id={}, a2a_enabled={})",
            self._a2a_instance_id,
            user_id,
            self._a2a_enabled,
        )
        return True

    async def _on_instance_registered(self, frame: dict[str, Any]) -> None:
        """Handle instance_registered acknowledgement."""
        status = frame.get("status", "ok")
        instance_id = frame.get("instance_id", "")
        user_id = frame.get("user_id", "")
        connection_id = frame.get("connection_id", "")
        protocol_version = frame.get("protocol_version", "")
        hb_interval = frame.get("heartbeat_interval_seconds", 30)
        hb_timeout = frame.get("heartbeat_timeout_seconds", 10)

        if status != "ok":
            logger.warning(
                "instance_registered rejected (status={}, instance_id={})",
                status,
                instance_id,
            )
            return

        self._a2a_registered = True
        logger.info(
            "instance_registered (instance_id={}, user_id={}, connection_id={}, "
            "protocol_version={}, heartbeat={}s/{}s)",
            instance_id,
            user_id,
            connection_id,
            protocol_version,
            hb_interval,
            hb_timeout,
        )

    async def _on_admin_request(self, frame: dict[str, Any]) -> None:
        """Handle an admin data query from the Cloud Gateway.

        Routes the request to the local WebServer's API handlers in-process
        and sends back an admin_response frame with the result.
        """
        request_id = frame.get("request_id", "")
        endpoint = frame.get("endpoint", "")
        if not request_id or not endpoint:
            logger.warning("Malformed admin_request frame: {}", frame)
            return

        status = 200
        body: Any = {"error": "not_found", "message": f"Unknown endpoint: {endpoint}"}

        try:
            result = await self._handle_admin_endpoint(endpoint, frame)
            if result is not None:
                status = result.get("status", 200)
                body = result.get("body", body)
            else:
                status = 404
        except Exception as exc:
            logger.error("Admin request error endpoint={}: {}", endpoint, exc)
            status = 500
            body = {"error": "internal_error", "message": str(exc)}

        response_frame = json.dumps(
            {
                "type": "admin_response",
                "request_id": request_id,
                "status": status,
                "body": json.dumps(body, ensure_ascii=False) if not isinstance(body, str) else body,
            },
            ensure_ascii=False,
        )
        await self._send_queue.put(response_frame)

    def _build_channels(self, rt: Any) -> list[dict[str, Any]]:
        """Build the channel list for /api/status — mirrors server.py logic."""
        from praestoclaw.utils.helpers import webchat_url_from_connect

        channels: list[dict[str, Any]] = []
        for name in rt.channel_manager._channels:
            if name == ChannelType.CLOUD:
                continue
            if name in (ChannelType.WEB, "gateway"):
                channels.append({"name": name, "url": "/chat", "connected": True})
            else:
                channels.append({"name": name, "url": None, "connected": True})

        cloud_cfg = rt.config.channels.cloud
        if cloud_cfg.enabled and cloud_cfg.url:
            try:
                wc_url: str | None = webchat_url_from_connect(cloud_cfg.url)
            except ValueError:
                wc_url = None
            channels.append(
                {"name": "Web Chat (Cloud)", "url": wc_url, "connected": self._ws_connected}
            )
            teams_url = cloud_cfg.teams_bot_url or None
            channels.append(
                {
                    "name": "Teams (Cloud)",
                    "url": teams_url,
                    "connected": self._ws_connected and bool(teams_url),
                }
            )
        return channels

    async def _handle_admin_endpoint(
        self, endpoint: str, frame: dict[str, Any]
    ) -> dict[str, Any] | None:
        """Dispatch an admin request to the Runtime via shared handlers.

        Returns {"status": int, "body": dict|str} or None if not found.
        """
        rt = self._runtime
        if rt is None:
            return {"status": 503, "body": {"error": "runtime_unavailable"}}

        from praestoclaw.web.api_handlers import (
            handle_approval_resolve,
            handle_approvals,
            handle_audit,
            handle_config,
            handle_cost,
            handle_estop,
            handle_health,
            handle_memory,
            handle_models,
            handle_reset,
            handle_session_detail,
            handle_sessions,
            handle_skills,
            handle_status,
            handle_tools,
        )

        method = frame.get("method", "GET")

        # ── GET ───────────────────────────────────────────────────────
        if method == "GET":
            routes: dict[str, Any] = {
                "/api/status": lambda: handle_status(rt, channels=self._build_channels(rt)),
                "/api/health": lambda: handle_health(rt),
                "/api/sessions": lambda: handle_sessions(rt),
                "/api/tools": lambda: handle_tools(rt),
                "/api/skills": lambda: handle_skills(rt),
                "/api/memory": lambda: handle_memory(rt),
                "/api/audit": lambda: handle_audit(rt),
                "/api/cost": lambda: handle_cost(rt),
                "/api/models": lambda: handle_models(rt),
                "/api/approvals": lambda: handle_approvals(rt),
            }
            if endpoint in routes:
                return {"status": 200, "body": routes[endpoint]()}

            if endpoint.startswith("/api/sessions/"):
                from urllib.parse import unquote

                session_id = unquote(endpoint[len("/api/sessions/") :])
                detail = handle_session_detail(rt, session_id)
                return (
                    {"status": 200, "body": detail}
                    if detail
                    else {"status": 404, "body": {"error": "not_found"}}
                )

            if endpoint == "/api/config":
                result = handle_config(rt)
                return (
                    {"status": 200, "body": result}
                    if result
                    else {"status": 500, "body": {"error": "Failed to serialize config."}}
                )

        # ── POST ──────────────────────────────────────────────────────
        if method == "POST":
            body_str = frame.get("body")
            body_data: dict[str, Any] = {}
            if body_str:
                try:
                    body_data = json.loads(body_str)
                except (json.JSONDecodeError, TypeError):
                    pass

            if endpoint == "/api/estop":
                return {
                    "status": 200,
                    "body": handle_estop(rt, body_data.get("reason", "admin dashboard")),
                }
            if endpoint == "/api/reset":
                return {"status": 200, "body": handle_reset(rt, body_data.get("actor", "admin"))}
            if endpoint.startswith("/api/approvals/") and endpoint.endswith("/resolve"):
                req_id = endpoint.split("/")[3] if len(endpoint.split("/")) >= 5 else ""
                code, body = handle_approval_resolve(
                    rt, req_id, body_data.get("approved", False), body_data.get("resolver", "admin")
                )
                return {"status": code, "body": body}

        return None

    # ── Auth ─────────────────────────────────────────────────────────────────

    def _acquire_token_sync(self) -> str:
        """Acquire token — silent if cached, then menu-driven interactive.

        Flow: bypass → try silent (broker or browser cache) → menu.
        """
        if self._bypass_token:
            logger.debug("Using bypass token (local dev mode)")
            return self._bypass_token

        assert self._msal_app is not None, "_msal_app must be set when bypass_token is not used"

        # 1. Try silent — check both broker and browser caches.
        token = self._try_silent_all()
        if token:
            return token

        # 2. Show login menu and execute the user's choice.
        return self._execute_login_choice()

    def _try_silent_all(self) -> str | None:
        """Try silent token acquisition from all cached sources.

        Checks: primary broker → primary browser → shared broker → shared browser.
        Returns token string or None.
        """
        from praestoclaw.utils.auth import _broker_kwargs
        from praestoclaw.utils.helpers import get_auth_dir

        client_ids = [self._client_id]
        if not self._using_shared_app:
            client_ids.append(SHARED_ENTRA_CLIENT_ID)

        for cid in client_ids:
            if cid == self._client_id:
                authority = f"https://login.microsoftonline.com/{self._tenant_id}"
            else:
                authority = "https://login.microsoftonline.com/organizations"

            # Try broker cache (WAM PRT refresh with scopes=["openid"]).
            bkw = _broker_kwargs()
            if bkw:
                token = self._try_silent_one(
                    cid,
                    authority,
                    bkw,
                    get_auth_dir() / f"token_cache_{cid[:8]}_broker.bin",
                    scopes=["openid"],
                )
                if token:
                    if cid != self._client_id:
                        self._switch_to_shared_app(enable_broker=True)
                    return token

            # Try browser cache (refresh_token with config scope).
            browser_scope = self._scope or f"{cid}/.default"
            token = self._try_silent_one(
                cid,
                authority,
                {},
                get_auth_dir() / f"token_cache_{cid[:8]}.bin",
                scopes=[browser_scope],
            )
            if token:
                if cid != self._client_id:
                    self._switch_to_shared_app()
                return token

        return None

    def _try_silent_one(
        self,
        client_id: str,
        authority: str,
        broker_kwargs: dict[str, Any],
        cache_path: Path,
        scopes: list[str],
    ) -> str | None:
        """Try silent acquisition from one specific cache file."""
        token_cache = msal.SerializableTokenCache()
        if cache_path.exists():
            try:
                from praestoclaw.security.secrets import decrypt_at_rest

                raw = decrypt_at_rest(cache_path.read_bytes())
                if raw:
                    token_cache.deserialize(raw.decode("utf-8"))
            except Exception:
                return None

        app = msal.PublicClientApplication(
            client_id,
            authority=authority,
            token_cache=token_cache,
            **broker_kwargs,
        )
        accounts = app.get_accounts()
        if not accounts:
            return None

        # Broker: force_refresh to get id_token via PRT (AT cache hit
        # only returns access_token for Graph, no id_token).
        result = app.acquire_token_silent(
            scopes, account=accounts[0], force_refresh=bool(broker_kwargs)
        )
        if not result or ("access_token" not in result and "id_token" not in result):
            return None

        # Persist refreshed cache to disk.
        from praestoclaw.utils.auth import _persist_cache

        _persist_cache(token_cache, cache_path)

        logger.debug(
            "Token acquired silently (client={}, broker={})",
            client_id[:8],
            bool(broker_kwargs),
        )
        self._capture_identity(result)
        # Broker with openid scope returns access_token for Graph (wrong aud).
        # Use id_token for broker, access_token for browser.
        if broker_kwargs:
            return str(result.get("id_token") or result.get("access_token", ""))
        return self._pick_token(result)

    def _execute_login_choice(self) -> str:
        """Show the login menu, execute the chosen sign-in path."""
        from praestoclaw.utils.auth import interactive_cloud_login

        has_primary = bool(self._msal_app and self._msal_app.get_accounts())
        token = interactive_cloud_login(
            tenant_id=self._tenant_id,
            client_id=self._client_id,
            scope=self._scope,
            login_port=self._login_port,
            has_primary_account=has_primary,
        )

        # Capture identity from the fresh token via _try_silent_all
        # (reads the cache file that interactive_cloud_login just wrote).
        self._try_silent_all()
        return token

    def _try_shared_or_apikey(self) -> str:
        """Prompt for API key (local LLM), then try shared app for cloud."""
        # Primary app is unusable — ask for API key so local CLI works
        # regardless of whether cloud login succeeds.
        self._prompt_api_key()
        self._switch_to_shared_app()
        try:
            token = self._interactive_login()
            self._persist_cache()
            return token
        except Exception:
            raise RuntimeError("Cloud sign-in skipped")

    # Alias — reconnect path uses the same logic as initial acquisition.
    _refresh_token_sync = _acquire_token_sync

    # ── Shared Entra ID fallback ────────────────────────────────────────────

    @staticmethod
    def _pick_token(result: dict) -> str:
        """Return the best token from an MSAL result.

        Prefer access_token (aud=resource app, typ=at+jwt) so that shared-app
        fallback tokens have the primary app audience.  Fall back to id_token
        (aud=client_id, typ=JWT) when no access_token is available.
        The Gateway accepts both typ=at+jwt and typ=JWT.
        """
        return str(result.get("access_token") or result["id_token"])

    @staticmethod
    def _is_consent_error(exc: Exception) -> bool:
        """True if the exception text contains a known consent error code."""
        msg = str(exc)
        return any(code in msg for code in _CONSENT_ERROR_CODES)

    @staticmethod
    def _is_timeout_error(exc: Exception) -> bool:
        """True if the MSAL interactive login timed out."""
        # MSAL raises BrowserInteractionTimeoutError with message
        # "User did not complete the flow in time".
        cls = type(exc).__name__
        if "Timeout" in cls:
            return True
        msg = str(exc).lower()
        return "timed out" in msg or "timeout" in msg or "not complete the flow in time" in msg

    @staticmethod
    def _prompt_api_key() -> None:
        """Prompt for a Web API key, confirm, and save to secret store + config.

        Skips if ``WEB_API_KEY`` is already configured.
        """
        import sys

        from praestoclaw.security.secrets import get_secret, set_secret

        if get_secret("WEB_API_KEY"):
            logger.debug("WEB_API_KEY already configured — skipping prompt")
            return
        if not sys.stdin.isatty():
            logger.debug("Non-interactive — skipping API key prompt")
            return
        _console.print(
            Panel(
                "[bold]Configure a Web API key[/bold] for the local web interface.\n"
                "Press [bold]Enter[/bold] to skip.",
                title="API Key",
                border_style="blue",
            )
        )
        try:
            from rich.prompt import Prompt

            key = Prompt.ask("  API Key", password=True, default="", show_default=False).strip()
            if not key:
                _console.print("  [dim]Skipped.[/dim]")
                return
            _console.print(f"  [dim]({len(key)} characters)[/dim]")
            confirm = Prompt.ask(
                "  Confirm API Key", password=True, default="", show_default=False
            ).strip()
            if key != confirm:
                _console.print("  [red]Keys do not match \u2014 skipped.[/red]")
                return
        except (EOFError, KeyboardInterrupt):
            _console.print("  [dim]Skipped.[/dim]")
            return
        set_secret("WEB_API_KEY", key)

        # Write SECRET[WEB_API_KEY] reference into praestoclaw.local.yaml so the
        # config loader resolves it at startup (same pattern as GITHUB_COPILOT_TOKEN).
        try:
            from praestoclaw.config.loader import set_local_config_value

            set_local_config_value("channels.web.api_key", "SECRET[WEB_API_KEY]")
        except Exception as exc:
            logger.warning("Failed to write api_key to local config: {}", exc)

        _console.print("  [green]\u2713[/green] Web API key saved.")

    def _switch_to_shared_app(self, *, enable_broker: bool = False) -> None:
        """Replace the MSAL app and scope with the shared Entra client ID.

        After this call, all existing auth paths (_acquire_token_sync,
        _interactive_login, _browser_flow, _device_code_flow) work
        unchanged — they just use the new client_id and scope.
        The Cloud Gateway must list the shared client ID in
        ``AzureAd:LegacyAudiences`` to accept these tokens.

        When *enable_broker* is True, WAM broker is enabled on the shared
        app so that ``_browser_flow(try_wam=True)`` works with it.
        """
        logger.warning(
            "Switching to shared Entra app ({}) — primary app requires admin consent",
            SHARED_ENTRA_CLIENT_ID[:8],
        )
        self._scope = f"{SHARED_ENTRA_CLIENT_ID}/.default"
        self._cache_path = get_auth_dir() / f"token_cache_{SHARED_ENTRA_CLIENT_ID[:8]}.bin"
        self._token_cache = msal.SerializableTokenCache()
        if self._cache_path.exists():
            try:
                from praestoclaw.security.secrets import decrypt_at_rest

                raw = decrypt_at_rest(self._cache_path.read_bytes())
                if raw:
                    self._token_cache.deserialize(raw.decode("utf-8"))
            except Exception as exc:
                logger.warning("Failed to load shared-app token cache: {}", exc)
        broker_kwargs: dict[str, Any] = {}
        if enable_broker:
            from praestoclaw.utils.auth import _broker_kwargs

            broker_kwargs = _broker_kwargs()
            self._broker_enabled = bool(broker_kwargs)
            if not broker_kwargs:
                logger.warning("msal[broker] not installed; broker disabled on shared app")
        else:
            self._broker_enabled = False
        self._msal_app = msal.PublicClientApplication(
            SHARED_ENTRA_CLIENT_ID,
            authority="https://login.microsoftonline.com/organizations",
            token_cache=self._token_cache,
            **broker_kwargs,
        )
        self._using_shared_app = True

    def _interactive_login(self, timeout: int = 300) -> str:
        """Dispatch to the configured login method.

        "auto" / "browser" — browser PKCE only (default, always works).
        "wam"              — WAM broker → browser PKCE fallback (opt-in).
        "device"           — device code only (opt-in, many tenants disable it).
        """
        if self._login_method == "device":
            return self._device_code_flow(timeout=timeout)
        if self._login_method == "wam":
            return self._browser_flow(try_wam=self._broker_enabled, timeout=timeout)
        # "auto" and "browser": browser PKCE only
        return self._browser_flow(try_wam=False, timeout=timeout)

    def _resolve_login_port(self) -> int:
        """Return a usable localhost port for the PKCE callback.

        Tries self._login_port first (the preferred/gateway port).
        If that port is already bound, asks the OS for any free port.
        """
        preferred = self._login_port
        for port in (preferred, 52813, 58729, 0):  # fixed high ports for AAD, then OS-assigned
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                try:
                    s.bind(("localhost", port))
                    chosen = s.getsockname()[1]
                    if port != preferred:
                        logger.debug(
                            "Login port {} busy — using {} instead",
                            preferred,
                            chosen,
                        )
                    return int(chosen)
                except OSError:
                    continue
        # Should never reach here — port 0 always succeeds
        return preferred  # pragma: no cover

    @staticmethod
    def _wait_with_countdown(done: Any, timeout: int) -> bool:
        """Show a fallback countdown, listening for ESC to skip.

        Returns True if the user pressed ESC (skip), False if *done* was set
        (MSAL completed) or the countdown expired naturally.
        """

        from praestoclaw.utils.input import is_tty, read_key_nonblocking

        remaining = timeout
        while remaining > 0 and not done.is_set():
            _console.print(
                f"  Fallback in [yellow]{remaining}s[/yellow] [dim](ESC to skip)[/dim]\u2026",
                end="\r",
            )
            if is_tty():
                try:
                    key = read_key_nonblocking()
                    if key == "esc":
                        _console.print(" " * 60, end="\r")
                        return True
                except KeyboardInterrupt:
                    _console.print(" " * 60, end="\r")
                    raise
            if done.wait(1):
                break
            remaining -= 1
        _console.print(" " * 60, end="\r")
        return False

    def _browser_flow(self, *, try_wam: bool = False, timeout: int = 300) -> str:
        """Interactive browser-based auth (authorization code + PKCE).

        MSAL opens the default browser and starts a local HTTP server on
        login_port (default 49216 — high port to avoid conflicts) for the
        callback. The registered redirect URI is http://localhost which
        AAD matches against any http://localhost:{PORT} loopback address.
        """
        port = self._resolve_login_port()
        _console.print(
            Panel(
                "[bold]Opening browser for sign-in\u2026[/bold]\n\n"
                f"Callback : [cyan]http://localhost:{port}[/cyan]\n"
                f"Fallback : [dim]alternative sign-in offered after {timeout}s[/dim]\n"
                "Press [bold]Ctrl+C[/bold] to cancel.",
                title="Sign In",
                border_style="yellow",
            )
        )

        assert self._msal_app is not None

        # After the OAuth callback, redirect to the web chat — but only
        # for the primary app.  The shared-app fallback path should NOT
        # redirect because the user's primary app couldn't authenticate
        # and the web chat may not work with the fallback token.
        if self._using_shared_app:
            success_template = (
                "<!DOCTYPE html><html><head><title>PraestoClaw</title></head>"
                "<body>Sign-in successful — you can close this tab.</body></html>"
            )
        else:
            web_url = webchat_url_from_connect(self._url)
            safe_url = _html.escape(web_url, quote=True)
            success_template = (
                "<!DOCTYPE html><html><head><title>PraestoClaw</title>"
                f'<meta http-equiv="refresh" content="0;url={safe_url}"></head>'
                f'<body>Sign-in successful — <a href="{safe_url}">opening PraestoClaw</a>…'
                "</body></html>"
            )

        wam_kwargs: dict[str, Any] = {}
        if try_wam:
            from praestoclaw.utils.auth import _get_foreground_window_handle

            wam_kwargs["parent_window_handle"] = _get_foreground_window_handle(self._msal_app)

        import threading

        msal_result: dict[str, Any] = {}
        msal_error: BaseException | None = None
        done_event = threading.Event()

        msal_app = self._msal_app

        # WAM: empty scopes → broker uses OIDC defaults, returns id_token.
        # Browser: needs app scope so access_token audience matches.
        interactive_scopes = [] if try_wam else self._scopes

        def _msal_call() -> None:
            nonlocal msal_result, msal_error
            try:
                msal_result = msal_app.acquire_token_interactive(
                    scopes=interactive_scopes,
                    prompt="select_account",
                    port=port,
                    timeout=timeout,
                    success_template=success_template,
                    **wam_kwargs,
                )
            except BaseException as exc:
                msal_error = exc
            finally:
                done_event.set()

        msal_thread = threading.Thread(target=_msal_call, daemon=True)
        msal_thread.start()

        # Wait with countdown + ESC detection. ESC skips to fallback.
        skipped = self._wait_with_countdown(done_event, timeout)
        if skipped:
            # User pressed ESC — simulate timeout so caller triggers fallback
            raise TimeoutError("Sign-in skipped by user (ESC)")

        msal_thread.join(timeout=2)
        if msal_error is not None:
            raise msal_error
        result = msal_result

        # WAM broker failed — unconditionally retry with plain browser.
        # Common WAM errors: broker_error (redirect URI missing), admin consent
        # required (AADSTS65001), public client blocked (AADSTS7000218), etc.
        if try_wam and "error" in result:
            err = result.get("error", "")
            err_desc = result.get("error_description", "")
            logger.info("WAM broker failed ({}); falling back to browser PKCE", err)
            logger.debug("WAM error detail: {}", err_desc[:300])
            # Not passing parent_window_handle → MSAL uses browser PKCE.
            result = self._msal_app.acquire_token_interactive(
                scopes=self._scopes,
                prompt="select_account",
                port=port,
                timeout=timeout,
                success_template=success_template,
            )

        if "error" in result:
            raise RuntimeError(
                f"Browser login failed: {result.get('error_description', result['error'])}"
            )

        self._log_authenticated(result)
        self._capture_identity(result)
        self._save_identity(result)
        return self._pick_token(result)

    def _device_code_flow(self, timeout: int = 300) -> str:
        """Device code flow — visit a URL and enter a short code.

        Works in headless / SSH / corporate environments where browser
        pop-ups are blocked.  *timeout* is accepted for API consistency
        but device code flow uses its own server-side expiry.
        """
        assert self._msal_app is not None
        flow = self._msal_app.initiate_device_flow(scopes=self._scopes)
        if "error" in flow:
            raise RuntimeError(
                f"Device code flow failed to start: {flow.get('error_description', flow['error'])}"
            )

        _console.print(
            Panel(
                f"[bold]Sign in required[/bold]\n\n{flow['message']}",
                title="Device Code",
                border_style="yellow",
            )
        )

        result = self._msal_app.acquire_token_by_device_flow(flow)
        if "error" in result:
            raise RuntimeError(
                f"Device code flow failed: {result.get('error_description', result['error'])}"
            )

        self._log_authenticated(result)
        self._capture_identity(result)
        self._save_identity(result)
        return self._pick_token(result)

    def _persist_cache(self) -> None:
        """Write MSAL token cache to disk if it changed.

        Uses an atomic rename and mode 0o600 on POSIX. On Windows the parent
        auth/ directory is ACL-restricted via icacls (best-effort; see ensure_private_dir).
        """
        if self._cache_path is None or not self._token_cache.has_state_changed:
            return
        try:
            tmp = self._cache_path.with_suffix(".tmp")
            from praestoclaw.security.secrets import encrypt_at_rest, is_encrypted

            plaintext = self._token_cache.serialize().encode("utf-8")
            data = encrypt_at_rest(plaintext)
            # Avoid overwriting an encrypted cache with plaintext
            if data == plaintext and self._cache_path.exists():
                if is_encrypted(self._cache_path.read_bytes()):
                    logger.warning(
                        "MSAL cache not written: encryption key unavailable "
                        "and existing cache is encrypted"
                    )
                    return
            tmp.write_bytes(data)
            try:
                tmp.chmod(0o600)
            except (NotImplementedError, OSError):
                pass  # Windows/some filesystems: parent ACL governs access
            tmp.replace(self._cache_path)
            logger.debug("MSAL token cache saved to {}", self._cache_path)
        except Exception as exc:
            logger.warning("Failed to save MSAL token cache: {}", exc)

    @staticmethod
    def _log_authenticated(result: dict) -> None:
        claims = result.get("id_token_claims", {})
        name = claims.get("name") or claims.get("preferred_username", "unknown")
        oid = claims.get("oid", "unknown")
        _console.print(
            f"  [green]\u2713[/green] Authenticated as [bold]{name}[/bold] [dim](oid={oid})[/dim]"
        )
        logger.success("Authenticated as: {} (oid={})", name, oid)

    def _capture_identity(self, result: dict) -> None:
        """Extract oid/tid from an MSAL token result, if claims are present.

        Called on every acquisition path (silent, browser, device code).
        Best-effort: MSAL may omit ``id_token_claims`` on a pure cache hit,
        in which case this is a no-op and identity is captured on the next
        interactive login.
        """
        claims = result.get("id_token_claims", {})
        if claims.get("oid"):
            self._local_oid = claims["oid"]
        if claims.get("tid"):
            self._local_tid = claims["tid"]
        if claims.get("preferred_username"):
            self._local_upn = claims["preferred_username"]

    def _save_identity(self, result: dict) -> None:
        """Persist Entra ID claims to ~/.praestoclaw/USER.md."""
        if self._runtime is None:
            return
        from praestoclaw.utils.identity import save_identity

        save_identity(
            result.get("id_token_claims", {}),
            self._runtime.workspace,
            user_file=self._runtime.config.agents.default.user_file,
        )
