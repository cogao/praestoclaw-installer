"""
Web server authentication — API key + Entra ID JWT verification.

Auth priority: X-API-Key header → Bearer (API key) → Bearer (Entra JWT)
              → ?key= query → ?token= query → reject

The /health, /api/health, / (UI), /api/auth/config, /api/auth/device-code,
/auth/spa-callback, and /favicon.svg endpoints are public.
"""

from __future__ import annotations

import hmac
import time
from typing import TYPE_CHECKING, Any

from loguru import logger

if TYPE_CHECKING:
    from praestoclaw.config.schema import WebServerConfig


def verify_api_key(api_key: str | None, config: WebServerConfig) -> bool:
    """
    Verify an API key against the configured web server key.

    Returns True if:
    - No API key is configured (auth disabled)
    - The provided key matches the configured key (constant-time comparison)
    """
    if config.api_key is None:
        return True  # No key configured = auth disabled

    if api_key is None:
        return False

    expected = config.api_key.get_secret_value()
    return hmac.compare_digest(api_key, expected)


# ── Entra ID JWT validation ────────────────────────────────────────────────

# Cache JWKS keys for 1 hour to avoid re-fetching on every request
_jwks_cache: dict[str, Any] = {}
_jwks_cache_time: float = 0
_JWKS_CACHE_TTL = 3600  # seconds


def _get_jwks_client(tenant_id: str) -> Any:
    """Get a PyJWKClient for the given tenant, with caching."""
    import jwt

    global _jwks_cache, _jwks_cache_time

    now = time.monotonic()
    if tenant_id in _jwks_cache and (now - _jwks_cache_time) < _JWKS_CACHE_TTL:
        return _jwks_cache[tenant_id]

    jwks_url = f"https://login.microsoftonline.com/{tenant_id}/discovery/v2.0/keys"
    client = jwt.PyJWKClient(jwks_url)
    _jwks_cache[tenant_id] = client
    _jwks_cache_time = now
    return client


def validate_entra_token(token: str, config: WebServerConfig) -> dict[str, Any] | None:
    """
    Validate an Entra ID JWT token.

    Returns decoded claims on success, None on failure.
    Validates: signature (JWKS), audience, issuer, expiry.
    """
    if not getattr(config, "entra_tenant_id", None) or not getattr(config, "entra_client_id", None):
        return None

    try:
        import jwt

        jwks_client = _get_jwks_client(config.entra_tenant_id)
        signing_key = jwks_client.get_signing_key_from_jwt(token)

        # Entra ID v2.0 issuer format
        issuer = f"https://login.microsoftonline.com/{config.entra_tenant_id}/v2.0"

        audiences: list[str] = [config.entra_client_id]
        if getattr(config, "entra_client_id_legacy", None):
            audiences.extend(config.entra_client_id_legacy)

        claims = jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256"],
            audience=audiences,
            issuer=issuer,
        )
        # Require oid claim — reject tokens without a user identity
        if not claims.get("oid"):
            logger.debug("Entra ID token rejected: missing oid claim")
            return None
        # When owner_oid is set (from cloud channel identity), only allow
        # tokens from the same user — prevents other tenant users from
        # accessing the local web server.
        if getattr(config, "owner_oid", None) and claims["oid"] != config.owner_oid:
            logger.debug("Entra ID token rejected: oid mismatch")
            return None
        return claims
    except Exception as exc:
        logger.debug(f"Entra ID token validation failed: {exc}")
        return None


# ── Auth Middleware ──────────────────────────────────────────────────────────


class AuthMiddleware:
    """
    ASGI middleware that enforces API key or Entra ID authentication.

    Auth priority:
    1. X-API-Key header (constant-time comparison)
    2. Bearer token matched as API key
    3. Bearer token validated as Entra ID JWT
    4. ?key= query parameter (WebSocket API key)
    5. ?token= query parameter (WebSocket Entra JWT)
    """

    # Paths that skip authentication
    _PUBLIC_PATHS: frozenset[str] = frozenset(
        {
            "/",
            "/chat",
            "/chat.html",
            "/health",
            "/api/health",
            "/api/status",
            "/api/auth/config",
            "/api/auth/device-code",
            "/api/auth/device-code/poll",
            "/auth/spa-callback",
            "/favicon.svg",
        }
    )

    def __init__(self, app: object, config: WebServerConfig) -> None:
        self._app = app
        self._config = config
        self._entra_enabled = bool(config.entra_tenant_id and config.entra_client_id)

    async def __call__(self, scope: dict, receive: object, send: object) -> None:  # noqa: ANN401
        if scope["type"] not in ("http", "websocket"):
            await self._app(scope, receive, send)  # type: ignore[operator]
            return

        path: str = scope.get("path", "")

        # Skip auth for public paths and static assets
        if path in self._PUBLIC_PATHS or path.startswith("/static/"):
            await self._app(scope, receive, send)  # type: ignore[operator]
            return

        # Skip auth entirely if neither API key nor Entra ID is configured
        if self._config.api_key is None and not self._entra_enabled:
            await self._app(scope, receive, send)  # type: ignore[operator]
            return

        _has_api_key = self._config.api_key is not None

        # ── Try API key auth (only when api_key is configured) ──
        if _has_api_key:
            api_key = self._extract_x_api_key(scope)
            if api_key and verify_api_key(api_key, self._config):
                await self._app(scope, receive, send)  # type: ignore[operator]
                return

        # ── Try Bearer token ──
        bearer = self._extract_bearer_token(scope)
        if bearer:
            # Try as API key (only when api_key is configured)
            if _has_api_key and verify_api_key(bearer, self._config):
                await self._app(scope, receive, send)  # type: ignore[operator]
                return
            # Try as Entra ID JWT
            entra_claims = (
                validate_entra_token(bearer, self._config) if self._entra_enabled else None
            )
            if entra_claims:
                scope["user_claims"] = entra_claims
                await self._app(scope, receive, send)  # type: ignore[operator]
                return

        # ── Try query parameters (WebSocket fallback) ──
        if _has_api_key:
            query_key = self._extract_query_param(scope, "key")
            if query_key and verify_api_key(query_key, self._config):
                await self._app(scope, receive, send)  # type: ignore[operator]
                return

        if self._entra_enabled:
            query_token = self._extract_query_param(scope, "token")
            entra_claims_q = (
                validate_entra_token(query_token, self._config) if query_token else None
            )
            if entra_claims_q:
                scope["user_claims"] = entra_claims_q
                await self._app(scope, receive, send)  # type: ignore[operator]
                return

        # ── Reject ──
        logger.warning(f"Unauthorized request to {path}")
        if scope["type"] == "websocket":
            await self._send_ws_close(receive, send)
        else:
            await self._send_401(send)

    @staticmethod
    def _extract_x_api_key(scope: dict) -> str | None:
        """Extract X-API-Key from ASGI scope headers."""
        headers: list[tuple[bytes, bytes]] = scope.get("headers", [])
        for name, value in headers:
            if name.lower() == b"x-api-key":
                return value.decode("utf-8", errors="ignore").strip()
        return None

    @staticmethod
    def _extract_bearer_token(scope: dict) -> str | None:
        """Extract the Bearer token from ASGI scope headers."""
        headers: list[tuple[bytes, bytes]] = scope.get("headers", [])
        for name, value in headers:
            if name.lower() == b"authorization":
                decoded = value.decode("utf-8", errors="ignore")
                if decoded.lower().startswith("bearer "):
                    return decoded[7:].strip()
                return None
        return None

    @staticmethod
    def _extract_query_param(scope: dict, param: str) -> str | None:
        """Extract a named parameter from the query string."""
        from urllib.parse import parse_qs

        qs: str = scope.get("query_string", b"").decode("utf-8", errors="ignore")
        params = parse_qs(qs)
        values = params.get(param, [])
        return values[0] if values else None

    @staticmethod
    async def _send_ws_close(receive: object, send: object) -> None:
        """Reject a WebSocket connection with close code 1008 (Policy Violation)."""
        await receive()  # type: ignore[operator]  # consume the ws connect
        await send({"type": "websocket.close", "code": 1008})  # type: ignore[operator]

    @staticmethod
    async def _send_401(send: object) -> None:
        """Send a 401 Unauthorized JSON response."""
        import json

        body = json.dumps(
            {"error": "Unauthorized", "message": "Invalid or missing API key"}
        ).encode()

        await send(
            {  # type: ignore[operator]
                "type": "http.response.start",
                "status": 401,
                "headers": [
                    (b"content-type", b"application/json"),
                    (b"content-length", str(len(body)).encode()),
                ],
            }
        )
        await send(
            {  # type: ignore[operator]
                "type": "http.response.body",
                "body": body,
            }
        )
