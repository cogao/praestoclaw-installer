"""
Web server middleware — rate limiting and request logging.

Provides an in-memory token-bucket rate limiter per client IP
and structured request logging via loguru.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

from loguru import logger

# ── Rate Limiter ────────────────────────────────────────────────────────────


@dataclass
class _TokenBucket:
    """Per-client token bucket state."""

    tokens: float
    last_refill: float
    max_tokens: float
    refill_rate: float  # tokens per second

    def consume(self) -> bool:
        """Try to consume one token. Returns True if allowed, False if exhausted."""
        now = time.monotonic()
        elapsed = now - self.last_refill
        self.tokens = min(self.max_tokens, self.tokens + elapsed * self.refill_rate)
        self.last_refill = now

        if self.tokens >= 1.0:
            self.tokens -= 1.0
            return True
        return False


class RateLimiter:
    """
    In-memory token-bucket rate limiter keyed by client IP.

    Each client gets *rate_per_minute* tokens per minute.
    Tokens refill continuously. Exceeding the limit returns False from check().
    """

    def __init__(self, rate_per_minute: int = 60) -> None:
        self._max_tokens = float(rate_per_minute)
        self._refill_rate = rate_per_minute / 60.0  # tokens per second
        self._buckets: dict[str, _TokenBucket] = {}

    def check(self, client_ip: str) -> bool:
        """
        Check whether the client is within the rate limit.

        Returns True if the request is allowed, False if rate-limited (429).
        """
        bucket = self._buckets.get(client_ip)
        if bucket is None:
            bucket = _TokenBucket(
                tokens=self._max_tokens,
                last_refill=time.monotonic(),
                max_tokens=self._max_tokens,
                refill_rate=self._refill_rate,
            )
            self._buckets[client_ip] = bucket

        return bucket.consume()

    def reset(self, client_ip: str | None = None) -> None:
        """Reset rate limiter state — for a single client or all."""
        if client_ip is None:
            self._buckets.clear()
        else:
            self._buckets.pop(client_ip, None)


# ── Request Logger Middleware ───────────────────────────────────────────────


class RequestLogger:
    """
    ASGI middleware that logs every HTTP request with method, path,
    status code, and duration.
    """

    def __init__(self, app: object) -> None:
        self._app = app

    async def __call__(self, scope: dict, receive: object, send: object) -> None:  # noqa: ANN401
        if scope["type"] != "http":
            await self._app(scope, receive, send)  # type: ignore[operator]
            return

        method: str = scope.get("method", "?")
        path: str = scope.get("path", "?")
        client = scope.get("client")
        client_ip = client[0] if client else "unknown"

        start = time.monotonic()
        status_code: int | None = None

        async def _send_wrapper(message: dict) -> None:
            nonlocal status_code
            if message["type"] == "http.response.start":
                status_code = message.get("status", 0)
            await send(message)  # type: ignore[operator]

        try:
            await self._app(scope, receive, _send_wrapper)  # type: ignore[operator]
        finally:
            duration_ms = (time.monotonic() - start) * 1000
            logger.debug(
                f"{method} {path} -> {status_code or '?'} ({duration_ms:.1f}ms) [{client_ip}]"
            )
