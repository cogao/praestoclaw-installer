"""Shared update-check logic — used by heartbeat tool and CLI (wheel mirror path).

PraestoClaw is not published on PyPI. Wheel-install users check the public
installer mirror's ``latest.txt`` pointer instead. Git users check their
upstream branch (unchanged)."""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from pathlib import Path

from praestoclaw import __version__

# Public mirror that hosts pre-built wheels + ``latest.txt`` pointer.
# Must stay in sync with install.ps1 / install.sh.
MIRROR_BASE = "https://raw.githubusercontent.com/cogao/praestoclaw-installer/main"


@dataclass
class UpdateStatus:
    """Result of an update check."""

    up_to_date: bool
    current: str = __version__
    latest: str | None = None
    commit_count: int = 0
    commit_log: str = ""  # oneline summaries (git only)
    install_mode: str = "unknown"  # "git" | "mirror"
    error: str | None = None

    @property
    def summary(self) -> str:
        if self.error:
            return f"Update check failed: {self.error}"
        if self.up_to_date:
            if self.install_mode == "git":
                return f"PraestoClaw v{self.current} is up to date (git)."
            return f"PraestoClaw v{self.current} is up to date (latest: v{self.latest or self.current})."
        if self.install_mode == "git":
            msg = f"PraestoClaw update available: {self.commit_count} new commit(s).\nCurrent: v{self.current}"
            if self.commit_log:
                msg += f"\nLatest commits:\n{self.commit_log}"
            return msg + "\nRun `praestoclaw update` to install."
        return (
            f"PraestoClaw update available: v{self.current} -> v{self.latest}\n"
            f"Run `praestoclaw update` to install."
        )


def is_git_install() -> Path | None:
    """Return repo root if editable git install, else None."""
    repo_root = Path(__file__).resolve().parent.parent.parent
    return repo_root if (repo_root / ".git").exists() else None


def parse_version(v: str) -> tuple[int, ...]:
    """Parse version string to comparable tuple (e.g. '0.7.0' -> (0, 7, 0))."""
    return tuple(int(x) for x in re.findall(r"\d+", v))


def check_git(repo: Path) -> UpdateStatus:
    """Fetch and compare with upstream. Does NOT pull."""
    if _run(["git", "fetch"], cwd=repo) is None:
        return UpdateStatus(up_to_date=False, install_mode="git", error="git fetch failed")

    local = _run(["git", "rev-parse", "HEAD"], cwd=repo)
    remote = _run(["git", "rev-parse", "@{u}"], cwd=repo)
    if not local or not remote:
        return UpdateStatus(
            up_to_date=False, install_mode="git", error="could not compare local/remote"
        )

    if local == remote:
        return UpdateStatus(up_to_date=True, install_mode="git")

    # Detect ahead/behind/diverged
    lr_out = _run(["git", "rev-list", "--left-right", "--count", "HEAD...@{u}"], cwd=repo)
    behind = 0
    if lr_out:
        parts = lr_out.split()
        if len(parts) == 2:
            behind = int(parts[1])

    if behind == 0:
        # Ahead only or diverged with no upstream commits — no update available
        return UpdateStatus(up_to_date=True, install_mode="git")

    log_out = _run(["git", "log", "--oneline", "-5", f"{local}..{remote}"], cwd=repo) or ""

    return UpdateStatus(
        up_to_date=False,
        install_mode="git",
        commit_count=behind,
        commit_log=log_out,
    )


def check_mirror() -> UpdateStatus:
    """Check the public installer mirror's ``latest.txt`` for a newer version."""
    latest = _fetch_mirror_version()
    if latest is None:
        return UpdateStatus(
            up_to_date=False,
            install_mode="mirror",
            error="could not determine latest version from mirror",
        )

    if parse_version(__version__) >= parse_version(latest):
        return UpdateStatus(up_to_date=True, install_mode="mirror", latest=latest)

    return UpdateStatus(up_to_date=False, install_mode="mirror", latest=latest)


# Backward-compat alias — old callers / docs may still say "pypi".
check_pypi = check_mirror


def check_update() -> UpdateStatus:
    """Auto-detect install mode and check for updates.

    Writes ``~/.praestoclaw/.last_update_check`` on success so heartbeat
    pre-flight and startup check share the same throttle marker.
    """
    repo = is_git_install()
    status = check_git(repo) if repo else check_mirror()

    if not status.error:
        _touch_marker()

    return status


def _touch_marker() -> None:
    """Update the shared throttle marker file."""
    import time

    try:
        from praestoclaw.utils.helpers import get_data_dir

        marker = get_data_dir() / ".last_update_check"
        marker.write_text(str(int(time.time())), encoding="utf-8")
    except OSError:
        pass


# ── Internal helpers ─────────────────────────────────────────────────────────


def _run(cmd: list[str], cwd: Path | None = None, timeout: int = 30) -> str | None:
    """Run a command, return stdout or None on failure."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd)
        return r.stdout.strip() if r.returncode == 0 else None
    except Exception:
        return None


def _fetch_mirror_version() -> str | None:
    """Get latest version from the installer mirror's ``latest.txt``.

    Uses a cache-busting query string so GitHub Raw's 5-minute CDN TTL
    doesn't serve a stale pointer right after a release.
    """
    import time

    url = f"{MIRROR_BASE}/latest.txt?t={int(time.time())}"
    try:
        import httpx

        resp = httpx.get(url, timeout=10, follow_redirects=True)
        resp.raise_for_status()
        text = resp.text.strip()
        # Validate PEP 440-ish version string
        if re.match(r"^\d+(\.\d+)*([.-][a-zA-Z0-9]+)*$", text):
            return text
    except Exception:
        pass
    return None
