"""
MCP client - connects to external MCP servers to discover and invoke tools.

Supports both stdio (subprocess) and HTTP/SSE transports using JSON-RPC 2.0
protocol, following the Model Context Protocol specification.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator, Callable
from typing import TYPE_CHECKING, Any

from loguru import logger

if TYPE_CHECKING:
    import httpx

from praestoclaw.mcp.transport import HttpTransport, MCPTransport, StdioTransport
from praestoclaw.mcp.types import MCPCapabilities

# Protocol versions — modern servers only need the latest.
# Legacy stdio servers (Agency, npx) may need the older version as fallback.
PROTOCOL_VERSION = "2025-03-26"
LEGACY_VERSIONS = ["2025-03-26", "2024-11-05"]
# Backward compat alias used by _test_mcp_server
SUPPORTED_VERSIONS = LEGACY_VERSIONS


class MCPClient:
    """
    Client that connects to an external MCP server.

    Supports two transport modes:
    - **stdio**: spawns a subprocess and communicates via stdin/stdout
    - **http**: connects to an HTTP/SSE endpoint

    Usage::

        client = MCPClient(command="npx", args=["-y", "@modelcontextprotocol/server-fs"])
        await client.connect()
        tools = await client.list_tools()
        result = await client.call_tool("read_file", {"path": "/tmp/example.txt"})
        await client.disconnect()
    """

    def __init__(
        self,
        *,
        command: str | None = None,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
        url: str | None = None,
        headers: dict[str, str] | None = None,
        auth: httpx.Auth | None = None,
        name: str = "mcp-server",
        skip_sse: bool = False,
        legacy_protocol: bool = False,
    ) -> None:
        """
        Initialize the MCP client.

        Provide either command/args for stdio transport, or url for HTTP transport.

        Args:
            command: Executable to spawn for stdio transport.
            args: Arguments for the subprocess command.
            env: Extra environment variables for stdio subprocess.
            url: URL for HTTP/SSE transport.
            headers: Optional HTTP headers (for HTTP transport).
            auth: Optional httpx.Auth for OAuth (for HTTP transport).
            name: Human-readable server name for logging.
            skip_sse: Skip legacy SSE probe (for known Streamable HTTP servers).
            legacy_protocol: Try older protocol versions as fallback.
        """
        if command is None and url is None:
            raise ValueError("MCPClient requires either 'command' (stdio) or 'url' (http)")

        self._name = name
        self._transport: MCPTransport | None = None
        self._request_id = 0
        self._pending: dict[int, asyncio.Future[dict[str, Any]]] = {}
        self._receive_task: asyncio.Task[None] | None = None
        self._transport_factory: Callable[[], MCPTransport]
        self._protocol_version: str | None = None
        self._server_capabilities: dict[str, Any] = {}
        self._on_tools_changed: Callable[[], Any] | None = None
        self._on_connection_lost: Callable[[], None] | None = None
        self._on_probe_failed: Callable[[], None] | None = None
        self._versions = LEGACY_VERSIONS if legacy_protocol else [PROTOCOL_VERSION]

        if command is not None:
            self._transport_factory = lambda: StdioTransport(command, args, env=env)
        else:
            assert url is not None
            self._transport_factory = lambda: HttpTransport(
                url, headers=headers, auth=auth, skip_sse=skip_sse
            )

    @property
    def is_connected(self) -> bool:
        """Whether the client has an active transport connection."""
        return self._transport is not None

    @property
    def name(self) -> str:
        """Server name for logging and identification."""
        return self._name

    @property
    def protocol_version(self) -> str | None:
        """Negotiated protocol version after connect()."""
        return self._protocol_version

    @property
    def capabilities(self) -> MCPCapabilities:
        """Server capabilities detected during initialization."""
        return MCPCapabilities.from_server_response(self._server_capabilities)

    def set_on_tools_changed(self, callback: Callable[[], Any] | None) -> None:
        """Set callback for ``notifications/tools/list_changed``."""
        self._on_tools_changed = callback

    async def connect(self, *, timeout: float = 30.0) -> None:
        """
        Establish connection to the MCP server.

        For stdio: spawns the subprocess.
        For HTTP: opens the HTTP client and SSE stream.

        Args:
            timeout: Seconds to wait *per protocol-version attempt* (default 30s).
                PraestoClaw tries each version in ``SUPPORTED_VERSIONS`` in order,
                so worst-case total handshake time is
                ``len(SUPPORTED_VERSIONS) * timeout`` (currently 2x, i.e. worst case = 2 * timeout).
        """
        if self._transport is not None:
            logger.warning(f"MCPClient({self._name}): already connected")
            return

        transport = self._transport_factory()
        await transport.start()
        self._transport = transport
        self._receive_task = asyncio.create_task(self._receive_loop())

        # Protocol negotiation — try newest version first, fallback if legacy
        last_error: Exception | None = None
        for version in self._versions:
            try:
                response = await self._send_request(
                    "initialize",
                    {
                        "protocolVersion": version,
                        "capabilities": {},
                        "clientInfo": {
                            "name": "praestoclaw",
                            "version": "0.1.0",
                        },
                    },
                    timeout=timeout,
                )
                result = response.get("result", {})
                self._protocol_version = result.get("protocolVersion", version)
                self._server_capabilities = result.get("capabilities", {})
                logger.debug(
                    f"MCPClient({self._name}): connected "
                    f"(protocol={self._protocol_version}), "
                    f"server={result.get('serverInfo', {})}"
                )
                last_error = None
                break
            except Exception as exc:
                last_error = exc
                if version == self._versions[-1]:
                    raise
                logger.debug(
                    f"MCPClient({self._name}): protocol {version} failed, trying next: {exc}"
                )

        if last_error is not None:
            raise last_error

        # Send initialized notification (no response expected)
        await self._send_notification("notifications/initialized", {})

    async def list_tools(self, *, timeout: float = 30.0) -> list[dict[str, Any]]:
        """
        Request the list of available tools from the MCP server.

        Args:
            timeout: Seconds to wait for the server response (default 30s).

        Returns:
            List of tool descriptors, each with 'name', 'description',
            and 'inputSchema' fields.
        """
        if self._transport is None:
            raise RuntimeError(f"MCPClient({self._name}): not connected")

        response = await self._send_request("tools/list", {}, timeout=timeout)
        result = response.get("result", {})
        tools: list[dict[str, Any]] = result.get("tools", [])
        logger.debug(f"MCPClient({self._name}): discovered {len(tools)} tools")
        return tools

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        *,
        timeout: float = 30.0,
    ) -> str:
        """
        Invoke a tool on the MCP server.

        Args:
            name: Tool name as reported by list_tools().
            arguments: Tool input parameters.
            timeout: Seconds to wait for the server response (default 30s).

        Returns:
            Tool execution result as a string.
        """
        if self._transport is None:
            raise RuntimeError(f"MCPClient({self._name}): not connected")

        response = await self._send_request(
            "tools/call",
            {
                "name": name,
                "arguments": arguments or {},
            },
            timeout=timeout,
        )

        # Check for JSON-RPC error
        if "error" in response:
            error = response["error"]
            code = error.get("code", -1)
            message = error.get("message", "Unknown error")
            logger.error(f"MCPClient({self._name}): tool error: [{code}] {message}")
            return f"MCP error [{code}]: {message}"

        # Extract result content
        result = response.get("result", {})
        content_parts = result.get("content", [])
        text_parts: list[str] = []
        for part in content_parts:
            if isinstance(part, dict) and part.get("type") == "text":
                text_parts.append(part.get("text", ""))
            elif isinstance(part, dict):
                text_parts.append(str(part))
            else:
                text_parts.append(str(part))

        return "\n".join(text_parts) if text_parts else str(result)

    async def call_tool_streaming(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        *,
        timeout: float = 30.0,
    ) -> AsyncGenerator[str, None]:
        """Invoke a tool and yield results as they arrive.

        Falls back to single-chunk yield if server doesn't support streaming.
        """
        # For now, fall back to non-streaming - full streaming requires
        # server-side support for partial content responses.
        result = await self.call_tool(name, arguments, timeout=timeout)
        yield result

    # ------------------------------------------------------------------
    # Resources
    # ------------------------------------------------------------------

    async def list_resources(self, *, timeout: float = 30.0) -> list[dict[str, Any]]:
        """List available resources from the MCP server.

        Returns empty list if server doesn't support resources.
        """
        if "resources" not in self._server_capabilities:
            return []
        if self._transport is None:
            raise RuntimeError(f"MCPClient({self._name}): not connected")

        response = await self._send_request("resources/list", {}, timeout=timeout)
        resources: list[dict[str, Any]] = response.get("result", {}).get("resources", [])
        logger.debug(f"MCPClient({self._name}): {len(resources)} resources")
        return resources

    async def read_resource(self, uri: str, *, timeout: float = 30.0) -> str:
        """Read a resource by URI."""
        if self._transport is None:
            raise RuntimeError(f"MCPClient({self._name}): not connected")

        response = await self._send_request("resources/read", {"uri": uri}, timeout=timeout)
        contents = response.get("result", {}).get("contents", [])
        parts: list[str] = []
        for c in contents:
            if isinstance(c, dict) and "text" in c:
                parts.append(c["text"])
            else:
                parts.append(str(c))
        return "\n".join(parts) if parts else str(response.get("result", {}))

    # ------------------------------------------------------------------
    # Prompts
    # ------------------------------------------------------------------

    async def list_prompts(self, *, timeout: float = 30.0) -> list[dict[str, Any]]:
        """List available prompts from the MCP server.

        Returns empty list if server doesn't support prompts.
        """
        if "prompts" not in self._server_capabilities:
            return []
        if self._transport is None:
            raise RuntimeError(f"MCPClient({self._name}): not connected")

        response = await self._send_request("prompts/list", {}, timeout=timeout)
        prompts: list[dict[str, Any]] = response.get("result", {}).get("prompts", [])
        logger.debug(f"MCPClient({self._name}): {len(prompts)} prompts")
        return prompts

    async def get_prompt(
        self, name: str, arguments: dict[str, str] | None = None, *, timeout: float = 30.0
    ) -> str:
        """Get a rendered prompt by name."""
        if self._transport is None:
            raise RuntimeError(f"MCPClient({self._name}): not connected")

        response = await self._send_request(
            "prompts/get",
            {"name": name, "arguments": arguments or {}},
            timeout=timeout,
        )
        messages = response.get("result", {}).get("messages", [])
        parts: list[str] = []
        for m in messages:
            content = m.get("content", {})
            if isinstance(content, dict) and "text" in content:
                parts.append(content["text"])
            elif isinstance(content, str):
                parts.append(content)
            else:
                parts.append(str(m))
        return "\n".join(parts) if parts else str(response.get("result", {}))

    async def disconnect(self) -> None:
        """Close the connection to the MCP server."""
        if self._receive_task is not None:
            self._receive_task.cancel()
            try:
                await self._receive_task
            except asyncio.CancelledError:
                pass
            self._receive_task = None

        if self._transport is not None:
            await self._transport.close()
            self._transport = None

        # Cancel any pending requests
        for future in self._pending.values():
            if not future.done():
                future.cancel()
        self._pending.clear()

        logger.debug(f"MCPClient({self._name}): disconnected")

    # ------------------------------------------------------------------
    # Internal JSON-RPC helpers
    # ------------------------------------------------------------------

    def _next_id(self) -> int:
        """Generate monotonically increasing request IDs."""
        self._request_id += 1
        return self._request_id

    async def _send_request(
        self,
        method: str,
        params: dict[str, Any],
        *,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        """Send a JSON-RPC request and wait for the matching response."""
        if self._transport is None:
            raise RuntimeError(f"MCPClient({self._name}): transport not available")

        request_id = self._next_id()
        message: dict[str, Any] = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
            "params": params,
        }

        future: asyncio.Future[dict[str, Any]] = asyncio.get_event_loop().create_future()
        self._pending[request_id] = future

        await self._transport.send(message)

        try:
            return await asyncio.wait_for(future, timeout=timeout)
        except TimeoutError:
            self._pending.pop(request_id, None)
            raise TimeoutError(
                f"MCPClient({self._name}): request '{method}' (id={request_id}) "
                f"timed out after {timeout}s"
            )

    async def _send_notification(self, method: str, params: dict[str, Any]) -> None:
        """Send a JSON-RPC notification (no response expected)."""
        if self._transport is None:
            raise RuntimeError(f"MCPClient({self._name}): transport not available")

        message: dict[str, Any] = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
        }
        await self._transport.send(message)

    async def _receive_loop(self) -> None:
        """Background task that routes incoming JSON-RPC messages to pending futures."""
        assert self._transport is not None
        try:
            while True:
                message = await self._transport.receive()

                # Match responses to pending requests by id
                msg_id = message.get("id")
                if msg_id is not None and msg_id in self._pending:
                    future = self._pending.pop(msg_id)
                    if not future.done():
                        future.set_result(message)
                elif msg_id is not None:
                    logger.debug(
                        f"MCPClient({self._name}): received response for unknown id={msg_id}"
                    )
                else:
                    # Server-initiated notification
                    method = message.get("method", "unknown")
                    if method == "notifications/tools/list_changed":
                        logger.info(f"MCPClient({self._name}): tools list changed")
                        if self._on_tools_changed is not None:
                            try:
                                result = self._on_tools_changed()
                                if asyncio.isfuture(result) or asyncio.iscoroutine(result):
                                    await result
                            except Exception as exc:
                                logger.warning(
                                    f"MCPClient({self._name}): on_tools_changed error: {exc}"
                                )
                    else:
                        logger.debug(f"MCPClient({self._name}): notification: {method}")
        except asyncio.CancelledError:
            pass
        except ConnectionError as exc:
            logger.warning(f"MCPClient({self._name}): connection lost: {exc}")
            # Transport is dead - clear it so is_connected returns False and the
            # health monitor detects the failure on its next ping.
            self._transport = None
            # Reject pending requests immediately; callers get ConnectionError
            # rather than hanging until their per-tool timeout expires.
            had_active_calls = bool(self._pending)
            for future in self._pending.values():
                if not future.done():
                    future.set_exception(ConnectionError(f"Connection lost: {exc}"))
            self._pending.clear()
            # Choose reconnect path based on whether tool calls were in flight:
            # - Active calls → _on_probe_failed (→ reconnect_now, auto_register=True)
            #   The user was using these tools; restore them after reconnect.
            # - No active calls → _on_connection_lost (→ trigger_reconnect, auto_register=False)
            #   Background crash with no active usage; don't silently re-inject tools.
            if had_active_calls:
                cb = self._on_probe_failed or self._on_connection_lost
            else:
                cb = self._on_connection_lost
            if cb is not None:
                try:
                    cb()
                except Exception:
                    pass
        except Exception as exc:
            logger.error(f"MCPClient({self._name}): receive loop error: {exc}")

    async def probe_and_reconnect(self) -> None:
        """Probe server health after a tool failure and reconnect if unreachable.

        Called as a background task when a tool call returns RuntimeError or
        TimeoutError — covers the Agency case where the subprocess is still
        alive (so _receive_loop never fires ConnectionError) but the backend
        service is down and all tool calls fail.

        Sends a quick list_tools request (5 s timeout). If that also fails,
        _on_probe_failed (→ reconnect_now) is invoked to trigger an immediate
        reconnect that skips the redundant check_server ping.

        IMPORTANT: _transport is intentionally NOT cleared here. The reconnect
        path calls connect_server(force=True) → old_client.disconnect(), which
        cancels _receive_task and calls transport.close() to properly kill the
        subprocess. Clearing _transport early would cause disconnect() to skip
        transport.close(), leaking the old subprocess.
        """
        if not self.is_connected or (
            self._on_probe_failed is None and self._on_connection_lost is None
        ):
            return
        try:
            # Use the built-in timeout param rather than asyncio.wait_for so
            # that a timeout raises TimeoutError (caught below) instead of
            # cancelling the inner coroutine, which would leave the request
            # future in _pending and leak it.
            await self.list_tools(timeout=5.0)
        except Exception:
            # Server is not responding — notify for immediate reconnect.
            # Uses _on_probe_failed (-> reconnect_now) rather than
            # _on_connection_lost (-> trigger_reconnect) so the reconnect task
            # skips the redundant check_server ping that would add another
            # ~10 s wait after the probe already spent 5 s confirming failure.
            cb = self._on_probe_failed or self._on_connection_lost
            if cb is not None:
                try:
                    cb()
                except Exception:
                    pass
