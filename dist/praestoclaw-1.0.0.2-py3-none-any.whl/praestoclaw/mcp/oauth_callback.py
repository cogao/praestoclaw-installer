"""OAuth callback server and browser redirect handlers for MCP authorization code flow.

Provides :func:`create_oauth_handlers` which returns the ``redirect_handler`` and
``callback_handler`` callables required by the MCP SDK's
:class:`~mcp.client.auth.OAuthClientProvider`.
"""

from __future__ import annotations

import asyncio
import html
import socket
import threading
import webbrowser
from collections.abc import Awaitable, Callable
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse

from loguru import logger

# HTML returned to the browser after a successful callback.
_SUCCESS_HTML = b"""\
<!DOCTYPE html>
<html><head><title>PraestoClaw</title></head>
<body style="font-family:system-ui;text-align:center;padding:4em">
<h2>Authorization complete</h2>
<p>You may close this tab and return to PraestoClaw.</p>
</body></html>
"""


def create_oauth_handlers(
    port: int = 0,
) -> tuple[
    Callable[[str], Awaitable[None]],
    Callable[[], Awaitable[tuple[str, str | None]]],
    int,
]:
    """Create redirect + callback handlers for the OAuth authorization code flow.

    Args:
        port: Fixed localhost port for the callback server.  ``0`` (default)
              lets the OS pick a free port.

    Returns:
        ``(redirect_handler, callback_handler, actual_port)`` — the first two
        are async callables matching the MCP SDK's ``OAuthClientProvider``
        constructor signature; the third is the bound port for building
        ``redirect_uris``.
    """
    # Probe for an available port, then release immediately.  The socket is
    # only re-bound when callback_handler() is actually called (on 401).
    # This avoids holding a port/FD for servers that never need OAuth.
    info = socket.getaddrinfo(
        "localhost", port, socket.AF_UNSPEC, socket.SOCK_STREAM, 0, socket.AI_PASSIVE
    )
    family = info[0][0] if info else socket.AF_INET
    addr = "::1" if family == socket.AF_INET6 else "127.0.0.1"
    probe = socket.socket(family, socket.SOCK_STREAM)
    probe.bind((addr, port))
    actual_port: int = probe.getsockname()[1]
    probe.close()

    # Shared state between the HTTP handler thread and the async caller.
    _result_future: asyncio.Future[tuple[str | None, str | None]] | None = None
    _loop: asyncio.AbstractEventLoop | None = None
    _callback_error: list[str] = []  # auth-server error captured by HTTP handler

    class _CallbackHandler(BaseHTTPRequestHandler):
        """Handles a single ``GET /callback?code=…&state=…``."""

        def do_GET(self) -> None:  # noqa: N802 (HTTP method convention)
            parsed = urlparse(self.path)
            if parsed.path not in ("/", "/callback"):
                self.send_response(404)
                self.end_headers()
                return

            # Clear stale error from any prior callback attempt.
            _callback_error.clear()

            params = parse_qs(parsed.query)
            code = params.get("code", [None])[0]  # type: ignore[arg-type]
            state = params.get("state", [None])[0]  # type: ignore[arg-type]
            error = params.get("error", [None])[0]  # type: ignore[arg-type]
            error_desc = params.get("error_description", [None])[0]  # type: ignore[arg-type]

            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            if error:
                raw_desc = error_desc or error
                safe_desc = html.escape(raw_desc)
                error_html = (
                    b"<!DOCTYPE html>"
                    b"<html><head><title>PraestoClaw</title></head>"
                    b'<body style="font-family:system-ui;text-align:center;padding:4em">'
                    b"<h2>Authorization failed</h2>"
                    b"<p>" + safe_desc.encode("utf-8") + b"</p>"
                    b"</body></html>"
                )
                self.wfile.write(error_html)
                # Store sanitized description for the CLI error message:
                # strip all ASCII control chars (0x00-0x1F, 0x7F) to prevent
                # terminal injection, and cap length.
                import re as _re

                sanitized = _re.sub(r"[\x00-\x1f\x7f]", " ", raw_desc).strip()[:500]
                _callback_error.append(sanitized)
            else:
                self.wfile.write(_SUCCESS_HTML)

            if _loop is not None and _result_future is not None and not _result_future.done():
                result: tuple[str | None, str | None] = (code, state)
                _loop.call_soon_threadsafe(_result_future.set_result, result)

        def log_message(self, format: str, *args: object) -> None:  # noqa: A002
            pass  # suppress HTTP server logs

    # -- handlers --------------------------------------------------------------

    async def redirect_handler(authorization_url: str) -> None:
        """Open the system browser for user authorization."""
        try:
            opened = webbrowser.open(authorization_url)
            if opened:
                logger.debug("Opened browser for OAuth authorization")
                return
        except Exception:
            pass
        # Headless / SSH / browser failed — print URL for manual copy-paste.
        logger.info("Open this URL to authorize:\n  {}", authorization_url)

    async def callback_handler() -> tuple[str, str | None]:
        """Start the localhost callback server and wait for the auth code."""
        nonlocal _result_future, _loop
        _loop = asyncio.get_running_loop()
        _result_future = _loop.create_future()

        # Bind now (deferred from factory creation to avoid holding a port).
        server_socket = socket.socket(family, socket.SOCK_STREAM)
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_socket.bind((addr, actual_port))
        server_socket.listen(5)

        server = HTTPServer(("localhost", 0), _CallbackHandler, bind_and_activate=False)
        server.socket = server_socket

        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()

        try:
            code, state = await asyncio.wait_for(_result_future, timeout=300)
            if code is None:
                detail = _callback_error[0] if _callback_error else "unknown error"
                raise RuntimeError(
                    f"OAuth callback did not contain an authorization code ({detail})"
                )
            return code, state
        except TimeoutError:
            raise RuntimeError(
                "OAuth callback timed out (300 s). "
                "Please complete authorization in the browser and try again."
            ) from None
        finally:
            server.shutdown()
            server.server_close()
            server_socket.close()
            thread.join(timeout=5)

    return redirect_handler, callback_handler, actual_port
