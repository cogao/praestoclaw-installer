"""
Token usage tracker — JSONL-based persistent cost tracking.

Records every LLM call's token usage and provides aggregated stats
by model, by day, and totals.

Storage: ~/.praestoclaw/token_usage.jsonl (one JSON line per LLM call)
"""

from __future__ import annotations

import json
from collections import defaultdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger


class TokenUsageTracker:
    """Track and persist token usage per LLM call."""

    def __init__(self, data_dir: Path | None = None) -> None:
        import threading

        self._lock = threading.Lock()
        self._file: Path | None = None
        if data_dir:
            data_dir.mkdir(parents=True, exist_ok=True)
            self._file = data_dir / "token_usage.jsonl"

        # In-memory aggregates: model → {prompt, completion, calls}
        self._by_model: dict[str, dict[str, int]] = defaultdict(
            lambda: {"prompt": 0, "completion": 0, "calls": 0}
        )
        # Daily aggregates: date_str → model → {prompt, completion, calls}
        self._by_day: dict[str, dict[str, dict[str, int]]] = defaultdict(
            lambda: defaultdict(lambda: {"prompt": 0, "completion": 0, "calls": 0})
        )
        self._total_prompt = 0
        self._total_completion = 0
        self._total_calls = 0

        self._load_from_disk()

    def record(
        self,
        model: str,
        prompt_tokens: int,
        completion_tokens: int,
        duration_ms: float = 0,
        session_id: str = "",
    ) -> None:
        """Record a single LLM call's token usage (thread-safe)."""
        if prompt_tokens <= 0 and completion_tokens <= 0:
            return

        with self._lock:
            now = datetime.now(UTC)
            day = now.strftime("%Y-%m-%d")

            self._by_model[model]["prompt"] += prompt_tokens
            self._by_model[model]["completion"] += completion_tokens
            self._by_model[model]["calls"] += 1
            self._by_day[day][model]["prompt"] += prompt_tokens
            self._by_day[day][model]["completion"] += completion_tokens
            self._by_day[day][model]["calls"] += 1
            self._total_prompt += prompt_tokens
            self._total_completion += completion_tokens
            self._total_calls += 1

            if self._file:
                try:
                    entry = {
                        "ts": now.isoformat(),
                        "model": model,
                        "prompt": prompt_tokens,
                        "completion": completion_tokens,
                        "duration_ms": round(duration_ms),
                    }
                    if session_id:
                        entry["session"] = session_id
                    with self._file.open("a", encoding="utf-8") as f:
                        f.write(json.dumps(entry, separators=(",", ":")) + "\n")
                except Exception as exc:
                    logger.debug("Failed to write token usage: {}", exc)

    def stats(self) -> dict[str, Any]:
        """Return aggregated usage stats."""
        return {
            "total": {
                "prompt_tokens": self._total_prompt,
                "completion_tokens": self._total_completion,
                "total_tokens": self._total_prompt + self._total_completion,
                "calls": self._total_calls,
            },
            "by_model": {
                model: {
                    "prompt_tokens": d["prompt"],
                    "completion_tokens": d["completion"],
                    "total_tokens": d["prompt"] + d["completion"],
                    "calls": d["calls"],
                }
                for model, d in sorted(self._by_model.items())
            },
            "by_day": {
                day: {
                    model: {
                        "prompt_tokens": d["prompt"],
                        "completion_tokens": d["completion"],
                        "total_tokens": d["prompt"] + d["completion"],
                        "calls": d["calls"],
                    }
                    for model, d in sorted(models.items())
                }
                for day, models in sorted(self._by_day.items(), reverse=True)
            },
        }

    def _load_from_disk(self) -> None:
        """Rebuild in-memory aggregates from JSONL file."""
        if not self._file or not self._file.exists():
            return
        try:
            with self._file.open(encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                        model = entry.get("model", "unknown")
                        prompt = int(entry.get("prompt", 0))
                        completion = int(entry.get("completion", 0))
                        day = str(entry.get("ts", ""))[:10]
                    except (json.JSONDecodeError, ValueError, TypeError):
                        continue  # skip corrupted lines

                    self._by_model[model]["prompt"] += prompt
                    self._by_model[model]["completion"] += completion
                    self._by_model[model]["calls"] += 1
                    if day:
                        self._by_day[day][model]["prompt"] += prompt
                        self._by_day[day][model]["completion"] += completion
                        self._by_day[day][model]["calls"] += 1
                    self._total_prompt += prompt
                    self._total_completion += completion
                    self._total_calls += 1
            logger.debug("Loaded {} token usage records from disk", self._total_calls)
        except Exception as exc:
            logger.warning("Failed to load token usage: {}", exc)
