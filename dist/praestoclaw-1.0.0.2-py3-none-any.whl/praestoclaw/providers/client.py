"""
OpenAI-compatible unified provider.

Supports:
- GitHub Copilot  — chat models (/chat/completions) and Responses API models
                    (gpt-5.4 family, codex variants, *-pro variants)
- OpenAI direct   — chat/completions + Responses API
- Azure OpenAI / Azure AI Foundry — chat/completions + Responses API

Design follows nanobot (HKUDS/nanobot) provider patterns:
- choices[0]-first content merge; tool_calls merged across all choices
- max_completion_tokens for gpt-5.x / o-series (not max_tokens)
- temperature suppressed for reasoning models (gpt-5.x, o-series, reasoning_effort)
- empty-content sanitization (None for assistant+tools, "(empty)" otherwise)
- reasoning_effort forwarded as {"effort": ...} on Responses API
- reasoning_content extracted from Responses API output items
"""

from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator
from typing import Any

from loguru import logger

from praestoclaw.config.schema import ProvidersConfig
from praestoclaw.providers.base import LLMChunk, LLMProvider, LLMResponse, ToolCallRequest
from praestoclaw.providers.resolver import resolve_credentials, resolve_model_chain
from praestoclaw.providers.usage import TokenUsageTracker

# ── Routing ────────────────────────────────────────────────────────────────────


def _requires_responses_api(model_name: str) -> bool:
    """True for models that require /v1/responses regardless of provider.

    Applies to all *-codex variants and gpt-5.x-pro variants.
    """
    n = model_name.lower()
    return "codex" in n or (n.startswith("gpt-5") and n.endswith("-pro"))


# GitHub Copilot-specific: the entire gpt-5.4 family rejects /chat/completions
# on the Copilot endpoint and requires the Responses API.  OpenAI direct is fine.
_GITHUB_COPILOT_RESPONSES_PREFIX: tuple[str, ...] = ("gpt-5.4",)


def _api_model_name(resolved_model: str) -> str:
    for prefix in ("github_copilot/", "github/", "openai/", "azure/", "azure_ai/"):
        if resolved_model.startswith(prefix):
            return resolved_model.removeprefix(prefix)
    return resolved_model


def _should_prefer_responses_api(resolved_model: str) -> bool:
    name = _api_model_name(resolved_model)
    if resolved_model.startswith(("github/", "github_copilot/")) and name.startswith(
        _GITHUB_COPILOT_RESPONSES_PREFIX
    ):
        return True
    return _requires_responses_api(name)


def _is_chat_unsupported_error(exc: Exception) -> bool:
    body = getattr(exc, "body", None)
    if isinstance(body, dict):
        error = body.get("error", {})
        code = str(error.get("code", "")).lower()
        message = str(error.get("message", "")).lower()
        if code == "unsupported_api_for_model":
            return True
        if "/chat/completions" in message:
            return True
    text = str(exc).lower()
    return "unsupported_api_for_model" in text or "/chat/completions endpoint" in text


# ── Parameter helpers (nanobot patterns) ──────────────────────────────────────

# Model families that require max_completion_tokens instead of max_tokens.
_COMPLETION_TOKENS_FAMILIES: tuple[str, ...] = ("gpt-5", "o1", "o2", "o3", "o4")


def _uses_completion_tokens(model_name: str) -> bool:
    n = model_name.lower()
    return any(n.startswith(f) for f in _COMPLETION_TOKENS_FAMILIES)


def _supports_temperature(model_name: str, reasoning_effort: str | None) -> bool:
    """False for reasoning models — temperature is ignored or rejected."""
    if reasoning_effort and reasoning_effort != "none":
        return False
    n = model_name.lower()
    return not any(n.startswith(f) for f in ("gpt-5", "o1", "o2", "o3", "o4"))


# ── Message sanitization ───────────────────────────────────────────────────────


def _sanitize_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Sanitize messages for OpenAI-compatible APIs.

    - Strip internal metadata keys (``_``-prefixed and ``is_error``)
    - Empty string content: None for assistant+tool_calls, "(empty)" otherwise
      (avoids 400 errors from providers that reject empty content)
    - tool_call arguments: dict → JSON string
    """
    out = []
    for msg in messages:
        msg = {k: v for k, v in msg.items() if not k.startswith("_") and k != "is_error"}
        role = msg.get("role")
        content = msg.get("content")

        if isinstance(content, str) and not content:
            msg["content"] = None if (role == "assistant" and msg.get("tool_calls")) else "(empty)"

        if msg.get("tool_calls"):
            fixed = []
            for tc in msg["tool_calls"]:
                tc = dict(tc)
                if "function" in tc:
                    fn = dict(tc["function"])
                    if isinstance(fn.get("arguments"), dict):
                        fn["arguments"] = json.dumps(fn["arguments"])
                    tc["function"] = fn
                fixed.append(tc)
            msg["tool_calls"] = fixed

        out.append(msg)
    return out


# ── Responses API helpers ──────────────────────────────────────────────────────


def _responses_input(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert chat-style messages to Responses API input items.

    - tool messages → function_call_output (preserves call_id for multi-turn)
    - assistant + tool_calls → function_call items (fixes "no tool call found" errors)
    """
    items: list[dict[str, Any]] = []
    for msg in _sanitize_messages(messages):
        role = msg.get("role", "user")
        content = msg.get("content") or ""
        if not isinstance(content, str):
            content = json.dumps(content, ensure_ascii=False)

        if role == "tool":
            items.append(
                {
                    "type": "function_call_output",
                    "call_id": msg.get("tool_call_id", ""),
                    "output": content,
                }
            )
            continue

        if role not in {"system", "user", "assistant"}:
            role = "user"

        if role == "assistant" and msg.get("tool_calls"):
            # Emit text content first (reasoning preamble from gpt-5.4 etc.),
            # then function_call items — Responses API supports this ordering.
            if content:
                items.append({"role": "assistant", "content": content})
            for tc in msg["tool_calls"]:
                fn = tc.get("function", {})
                args = fn.get("arguments", "{}")
                items.append(
                    {
                        "type": "function_call",
                        "call_id": tc.get("id", ""),
                        "name": fn.get("name", ""),
                        "arguments": args if isinstance(args, str) else json.dumps(args),
                    }
                )
            continue

        items.append({"role": role, "content": content})

    return items


def _responses_tools(tools: list[dict[str, Any]] | None) -> list[dict[str, Any]] | None:
    if not tools:
        return None
    converted = []
    for tool in tools:
        if tool.get("type") != "function":
            continue
        fn = tool.get("function", {})
        converted.append(
            {
                "type": "function",
                "name": fn.get("name", ""),
                "description": fn.get("description", ""),
                "parameters": fn.get("parameters", {"type": "object", "properties": {}}),
            }
        )
    return converted


# ── Provider ───────────────────────────────────────────────────────────────────


class OpenAIProvider(LLMProvider):
    """Unified provider for GitHub Copilot, OpenAI, and Azure OpenAI.

    Routing logic:
    - github/gpt-5.4, github_copilot/gpt-5.4  → Responses API (Copilot GA 2026-03-05)
    - *-codex, gpt-5.x-pro                    → Responses API (all providers)
    - everything else                          → Chat Completions
      - on unsupported_api_for_model error     → automatic fallback to Responses API
    """

    def __init__(self, providers: ProvidersConfig | None = None) -> None:
        self._providers = providers or ProvidersConfig()
        self._usage: TokenUsageTracker | None = None
        self._client_cache: dict[tuple[str, str | None, str | None, Any], Any] = {}

    def set_usage_tracker(self, tracker: TokenUsageTracker) -> None:
        """Attach a token usage tracker for cost monitoring."""
        self._usage = tracker

    # ── Request building ───────────────────────────────────────────────────────

    def _build_kwargs(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> tuple[str, dict[str, Any], dict[str, Any]]:
        """Return (resolved_model, req_kwargs, creds)."""
        resolved_model = model
        creds = resolve_credentials(resolved_model, self._providers)
        model_name = _api_model_name(resolved_model)

        req_kwargs: dict[str, Any] = {
            "model": model_name,
            "messages": _sanitize_messages(messages),
        }

        # Temperature: suppressed for reasoning models (nanobot pattern)
        if temperature is not None and _supports_temperature(model_name, reasoning_effort):
            req_kwargs["temperature"] = temperature

        # max_tokens → max_completion_tokens for gpt-5.x / o-series
        if max_tokens is not None:
            param = "max_completion_tokens" if _uses_completion_tokens(model_name) else "max_tokens"
            req_kwargs[param] = max_tokens

        if tools:
            req_kwargs["tools"] = tools

        # reasoning_effort for chat/completions (gpt-5.x, o-series)
        if reasoning_effort and reasoning_effort != "none":
            req_kwargs["reasoning_effort"] = reasoning_effort

        return resolved_model, req_kwargs, creds

    def _build_client(self, resolved_model: str, creds: dict[str, Any]) -> Any:
        from openai import AsyncAzureOpenAI, AsyncOpenAI

        api_key = creds.get("api_key")
        if not api_key:
            raise ValueError(f"Missing API key for model '{resolved_model}'")

        api_base: str | None = creds.get("api_base")
        api_version: str | None = creds.get("api_version")
        extra_headers = creds.get("extra_headers")
        headers_key = (
            tuple(sorted(extra_headers.items()))
            if isinstance(extra_headers, dict)
            else extra_headers
        )
        cache_key = (api_key, api_base, api_version, headers_key)

        if cache_key in self._client_cache:
            return self._client_cache[cache_key]

        client: AsyncAzureOpenAI | AsyncOpenAI
        if resolved_model.startswith(("azure/", "azure_ai/")):
            if not api_base:
                raise ValueError("Azure OpenAI / Azure AI Foundry requires endpoint (api_base)")
            client = AsyncAzureOpenAI(
                api_key=api_key,
                azure_endpoint=api_base,
                api_version=api_version or "2024-10-21",
                default_headers=extra_headers,
            )
        else:
            client = AsyncOpenAI(
                api_key=api_key,
                base_url=api_base,
                default_headers=extra_headers,
            )

        self._client_cache[cache_key] = client
        return client

    # ── Response parsing ───────────────────────────────────────────────────────

    @staticmethod
    def _parse_chat_tool_calls(message: Any) -> list[ToolCallRequest]:
        if not getattr(message, "tool_calls", None):
            return []
        tool_calls = []
        for tc in message.tool_calls:
            args = tc.function.arguments
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {"raw": args}
            tool_calls.append(
                ToolCallRequest(
                    id=tc.id,
                    name=tc.function.name,
                    arguments=args,
                )
            )
        return tool_calls

    @staticmethod
    def _merge_choices(response: Any) -> tuple[str, list[ToolCallRequest], str]:
        """Merge content and tool_calls across all choices (nanobot pattern).

        choices[0] is authoritative for content and finish_reason.
        Content from other choices is only used if choices[0] has none.
        Tool calls are merged from ALL choices (GitHub Copilot may split them).
        """
        if not response.choices:
            return "", [], "stop"

        primary = response.choices[0]
        content: str = primary.message.content or ""
        finish_reason: str = primary.finish_reason or "stop"

        all_tool_calls: list[ToolCallRequest] = []
        for choice in response.choices:
            tcs = OpenAIProvider._parse_chat_tool_calls(choice.message)
            all_tool_calls.extend(tcs)
            if not content and choice.message.content:
                content = choice.message.content
            if tcs and choice.finish_reason == "tool_calls":
                finish_reason = "tool_calls"

        if all_tool_calls and finish_reason != "tool_calls":
            finish_reason = "tool_calls"

        if len(response.choices) > 1:
            logger.debug(
                "Chat response has {} choices, merged {} tool_calls",
                len(response.choices),
                len(all_tool_calls),
            )

        return content, all_tool_calls, finish_reason

    @staticmethod
    def _parse_responses_result(
        response: Any,
    ) -> tuple[str, list[ToolCallRequest], str | None, int, int]:
        """Parse Responses API result.

        Returns (content, tool_calls, reasoning_content, prompt_tokens, completion_tokens).
        reasoning_content captures thinking blocks from gpt-5.4 / DeepSeek-R1 etc.
        """
        content: str = getattr(response, "output_text", "") or ""
        tool_calls: list[ToolCallRequest] = []
        reasoning_parts: list[str] = []

        for item in getattr(response, "output", []) or []:
            item_type = getattr(item, "type", None)

            if item_type == "function_call":
                raw_args = getattr(item, "arguments", "{}") or "{}"
                if isinstance(raw_args, str):
                    try:
                        args = json.loads(raw_args)
                    except json.JSONDecodeError:
                        args = {"raw": raw_args}
                else:
                    args = raw_args
                tool_calls.append(
                    ToolCallRequest(
                        id=str(
                            getattr(item, "call_id", None)
                            or getattr(item, "id", None)
                            or "function_call"
                        ),
                        name=getattr(item, "name", ""),
                        arguments=args,
                    )
                )

            elif item_type == "reasoning":
                # Preserve reasoning/thinking content (gpt-5.4, encrypted_content etc.)
                for part in getattr(item, "content", []) or []:
                    part_type = getattr(part, "type", None)
                    if part_type in ("thinking", "text"):
                        text = getattr(part, "thinking", None) or getattr(part, "text", "")
                        if text:
                            reasoning_parts.append(text)

            elif item_type == "message" and not content:
                texts: list[str] = []
                for part in getattr(item, "content", []) or []:
                    if getattr(part, "type", None) in ("output_text", "text"):
                        text = getattr(part, "text", "")
                        if text:
                            texts.append(text)
                if texts:
                    content = "".join(texts)

        reasoning_content: str | None = "\n".join(reasoning_parts) if reasoning_parts else None

        usage = getattr(response, "usage", None)
        prompt_tokens = (
            int(getattr(usage, "input_tokens", 0) or getattr(usage, "prompt_tokens", 0) or 0)
            if usage
            else 0
        )
        completion_tokens = (
            int(getattr(usage, "output_tokens", 0) or getattr(usage, "completion_tokens", 0) or 0)
            if usage
            else 0
        )

        return content, tool_calls, reasoning_content, prompt_tokens, completion_tokens

    # ── Responses API call ─────────────────────────────────────────────────────

    async def _complete_via_responses(
        self,
        *,
        client: Any,
        resolved_model: str,
        req_kwargs: dict[str, Any],
    ) -> LLMResponse:
        resp_kwargs: dict[str, Any] = {
            "model": req_kwargs["model"],
            "input": _responses_input(req_kwargs["messages"]),
        }
        if "temperature" in req_kwargs:
            resp_kwargs["temperature"] = req_kwargs["temperature"]

        # max_completion_tokens / max_tokens → max_output_tokens
        if "max_completion_tokens" in req_kwargs:
            resp_kwargs["max_output_tokens"] = req_kwargs["max_completion_tokens"]
        elif "max_tokens" in req_kwargs:
            resp_kwargs["max_output_tokens"] = req_kwargs["max_tokens"]

        # reasoning_effort → {"effort": ...} on Responses API
        if "reasoning_effort" in req_kwargs:
            resp_kwargs["reasoning"] = {"effort": req_kwargs["reasoning_effort"]}

        converted_tools = _responses_tools(req_kwargs.get("tools"))
        if converted_tools:
            resp_kwargs["tools"] = converted_tools

        start = time.monotonic()
        response = await client.responses.create(**resp_kwargs)
        elapsed_ms = (time.monotonic() - start) * 1000

        content, tool_calls, reasoning_content, prompt_tokens, completion_tokens = (
            self._parse_responses_result(response)
        )

        return LLMResponse(
            content=content,
            tool_calls=tool_calls,
            finish_reason="tool_calls" if tool_calls else "stop",
            model=getattr(response, "model", None) or resolved_model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            duration_ms=elapsed_ms,
            reasoning_content=reasoning_content,
        )

    # ── Public API ─────────────────────────────────────────────────────────────

    async def complete(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> LLMResponse:
        candidate_models = resolve_model_chain(model, self._providers)
        if not candidate_models:
            raise ValueError(
                f"No model candidates resolved for alias '{model}'. "
                "Configure GITHUB_TOKEN or OPENAI_API_KEY."
            )

        result: LLMResponse | None = None
        resolved_model = model
        last_error: Exception | None = None

        for idx, candidate in enumerate(candidate_models):
            resolved_model, req_kwargs, creds = self._build_kwargs(
                model=candidate,
                messages=messages,
                tools=tools,
                temperature=temperature,
                max_tokens=max_tokens,
                reasoning_effort=reasoning_effort,
            )
            try:
                client = self._build_client(resolved_model, creds)

                if _should_prefer_responses_api(resolved_model):
                    result = await self._complete_via_responses(
                        client=client,
                        resolved_model=resolved_model,
                        req_kwargs=req_kwargs,
                    )
                else:
                    try:
                        start = time.monotonic()
                        response = await client.chat.completions.create(**req_kwargs)
                        elapsed_ms = (time.monotonic() - start) * 1000

                        content, tool_calls, finish_reason = self._merge_choices(response)
                        usage = response.usage
                        result = LLMResponse(
                            content=content,
                            tool_calls=tool_calls,
                            finish_reason=finish_reason,
                            model=resolved_model,
                            prompt_tokens=usage.prompt_tokens if usage else 0,
                            completion_tokens=usage.completion_tokens if usage else 0,
                            duration_ms=elapsed_ms,
                        )
                    except Exception as exc:
                        if _is_chat_unsupported_error(exc):
                            logger.warning(
                                "Model '{}' does not support /chat/completions; "
                                "switching to Responses API",
                                resolved_model,
                            )
                            result = await self._complete_via_responses(
                                client=client,
                                resolved_model=resolved_model,
                                req_kwargs=req_kwargs,
                            )
                        else:
                            raise

                if idx > 0:
                    logger.warning(
                        "LLM fallback succeeded: '{}' -> '{}'",
                        candidate_models[0],
                        resolved_model,
                    )
                break

            except Exception as exc:
                last_error = exc
                logger.error("LLM error ({}): {}", resolved_model, exc)
                if idx < len(candidate_models) - 1:
                    logger.warning(
                        "Retrying LLM with fallback model '{}' after '{}' failed",
                        candidate_models[idx + 1],
                        resolved_model,
                    )

        if result is None:
            if last_error is not None:
                raise last_error
            raise RuntimeError("LLM completion failed without an exception")

        logger.debug(
            "LLM {}: {}+{} tokens, {:.0f}ms, {} tool calls{}",
            resolved_model,
            result.prompt_tokens,
            result.completion_tokens,
            result.duration_ms,
            len(result.tool_calls),
            " [reasoning]" if result.reasoning_content else "",
        )

        if self._usage:
            self._usage.record(
                model=resolved_model,
                prompt_tokens=result.prompt_tokens,
                completion_tokens=result.completion_tokens,
                duration_ms=result.duration_ms,
            )

        return result

    async def stream(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> AsyncIterator[LLMChunk]:
        candidate_models = resolve_model_chain(model, self._providers)
        if not candidate_models:
            raise ValueError(
                f"No model candidates resolved for alias '{model}'. "
                "Configure GITHUB_TOKEN or OPENAI_API_KEY."
            )

        last_error: Exception | None = None

        for idx, candidate in enumerate(candidate_models):
            resolved_model, req_kwargs, creds = self._build_kwargs(
                model=candidate,
                messages=messages,
                tools=tools,
                temperature=temperature,
                max_tokens=max_tokens,
                reasoning_effort=reasoning_effort,
            )

            try:
                client = self._build_client(resolved_model, creds)

                if _should_prefer_responses_api(resolved_model):
                    # Responses API is non-streaming: complete then yield
                    result = await self._complete_via_responses(
                        client=client,
                        resolved_model=resolved_model,
                        req_kwargs=req_kwargs,
                    )
                    if self._usage:
                        self._usage.record(
                            model=resolved_model,
                            prompt_tokens=result.prompt_tokens,
                            completion_tokens=result.completion_tokens,
                            duration_ms=result.duration_ms,
                        )
                    if result.content:
                        yield LLMChunk(
                            content=result.content,
                            finish_reason="stop",
                            model=result.model,
                        )
                    return

                try:
                    response = await client.chat.completions.create(**req_kwargs, stream=True)
                except Exception as exc:
                    if _is_chat_unsupported_error(exc):
                        logger.warning(
                            "Model '{}' does not support /chat/completions; "
                            "switching to Responses API",
                            resolved_model,
                        )
                        result = await self._complete_via_responses(
                            client=client,
                            resolved_model=resolved_model,
                            req_kwargs=req_kwargs,
                        )
                        if self._usage:
                            self._usage.record(
                                model=resolved_model,
                                prompt_tokens=result.prompt_tokens,
                                completion_tokens=result.completion_tokens,
                                duration_ms=result.duration_ms,
                            )
                        if result.content:
                            yield LLMChunk(
                                content=result.content,
                                finish_reason="stop",
                                model=result.model,
                            )
                        return
                    raise

                emitted_any = False
                try:
                    async for chunk in response:
                        if not chunk.choices:
                            continue
                        emitted_any = True
                        choice = chunk.choices[0]
                        delta = choice.delta
                        yield LLMChunk(
                            content=delta.content or "",
                            finish_reason=choice.finish_reason,
                            model=resolved_model,
                        )
                    if idx > 0:
                        logger.warning(
                            "LLM stream fallback succeeded: '{}' -> '{}'",
                            candidate_models[0],
                            resolved_model,
                        )
                    return
                except Exception as exc:
                    last_error = exc
                    logger.error("LLM stream iteration error ({}): {}", resolved_model, exc)
                    if emitted_any or idx >= len(candidate_models) - 1:
                        raise
                    logger.warning(
                        "Retrying stream with fallback model '{}' after early "
                        "stream failure in '{}'",
                        candidate_models[idx + 1],
                        resolved_model,
                    )

            except Exception as exc:
                last_error = exc
                logger.error("LLM stream error ({}): {}", resolved_model, exc)
                if idx < len(candidate_models) - 1:
                    logger.warning(
                        "Retrying stream with fallback model '{}' after '{}' failed",
                        candidate_models[idx + 1],
                        resolved_model,
                    )
                    continue
                raise

        if last_error is not None:
            raise last_error
        raise RuntimeError("LLM stream failed without an exception")
