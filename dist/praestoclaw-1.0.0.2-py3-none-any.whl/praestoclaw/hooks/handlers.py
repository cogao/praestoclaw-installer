"""
Built-in hook handlers — the 8 safety handlers always registered.

on_message_received:
  - InjectionScanner (priority 10)

pre_tool_use:
  - EStopGate (priority 1)
  - PolicyGate (priority 10)
  - ApprovalGate (priority 20) — allowlist check, classifier, human-in-the-loop

post_tool_use:
  - LeakScanner (priority 10)
  - Auditor (priority 30)

on_message_sent:
  - OutboundLeakScanner (priority 10)
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

from loguru import logger

from praestoclaw.config.schema import ChannelType
from praestoclaw.hooks.manager import (
    HookManager,
    HookResult,
    MessageHookContext,
    PostToolHookContext,
    PreToolHookContext,
)
from praestoclaw.security.leak import detect_credentials, redact_credentials
from praestoclaw.security.sanitizer import Sanitizer

if TYPE_CHECKING:
    from praestoclaw.bus.queue import EventBus
    from praestoclaw.channels.manager import ChannelManager
    from praestoclaw.security.allowlist import AllowlistManager
    from praestoclaw.security.approval import ApprovalManager
    from praestoclaw.security.audit import AuditLogger
    from praestoclaw.security.rbac import PolicyEngine
    from praestoclaw.security.scorer import RiskScorer


# ── on_message_received handlers ─────────────────────────────────────────────


class InjectionScanner:
    """Detect prompt injection patterns in inbound messages."""

    def __init__(self, *, block: bool = False) -> None:
        self._block = block

    async def __call__(self, ctx: MessageHookContext) -> HookResult:
        findings = Sanitizer.check_prompt_injection(ctx.content)
        if findings:
            logger.warning(
                "Injection patterns detected from {}: {}",
                ctx.sender_id or "unknown",
                findings,
            )
            if self._block:
                return HookResult.reject(f"Prompt injection detected: {findings[0]}")
        return HookResult.allow()


# ── pre_tool_use handlers ────────────────────────────────────────────────────


class EStopGate:
    """Reject all tool calls when E-stop is active."""

    def __init__(self, estop: object | None = None) -> None:
        self._estop = estop

    async def __call__(self, ctx: PreToolHookContext) -> HookResult:
        if self._estop is not None and getattr(self._estop, "is_halted", False):
            return HookResult.reject("E-stop is active — all tool execution halted")
        return HookResult.allow()


class PolicyGate:
    """Check RBAC permissions before tool execution."""

    def __init__(self, policy_engine: PolicyEngine | None = None) -> None:
        self._engine = policy_engine

    async def __call__(self, ctx: PreToolHookContext) -> HookResult:
        if self._engine is None:
            return HookResult.allow()
        # check_permission returns (allowed: bool, level: AutonomyLevel)
        # operation defaults to "write" for tools that modify state
        operation = (
            "read" if ctx.tool_name in ("read_file", "list_dir", "search_files") else "write"
        )
        allowed, _level = self._engine.check_permission(
            ctx.tool_name, operation, agent_name=ctx.agent_name
        )
        if not allowed:
            return HookResult.reject(
                f"Tool '{ctx.tool_name}' denied by policy for agent '{ctx.agent_name}'"
            )
        return HookResult.allow()


# ── Approval escalation helpers ───────────────────────────────────────────────

# Sources that identify a specific cloud sub-channel.
_CLOUD_SOURCES = ("cloud_webchat", "cloud_teams")


def _track_push(attempted: set[str], ch_name: ChannelType, push_target: str | None) -> None:
    """Record a successful push delivery in *attempted*.

    For cloud, only a **targeted** push (``push_target`` set) is tracked —
    the Python client knows exactly which sub-channel was addressed.  A
    fan-out (``push_target=None``) is **not** tracked because the gateway
    may silently skip a sub-channel that has no active connection /
    conversation reference, and the Python client has no visibility into
    the per-sub-channel delivery outcome.  Leaving the set empty for
    fan-outs means Stage 3 will retry with targeted pushes — at worst
    this causes a duplicate card on a sub-channel that already received
    the fan-out, which is acceptable.
    """
    if ch_name == ChannelType.CLOUD:
        if push_target:
            attempted.add(f"{ch_name.value}_{push_target}")
        # fan-out (push_target=None): intentionally do NOT track — see docstring
    else:
        attempted.add(ch_name.value if hasattr(ch_name, "value") else str(ch_name))


# ── Score-aware timeout calculation ───────────────────────────────────────────

_T_BASE: dict[int, int] = {1: 45, 2: 90, 3: 120, 4: 150, 5: 180, 6: 240, 7: 300, 8: 360}
_T_FACTOR: dict[str, float] = {"open": 0.75, "standard": 1.0, "controlled": 1.25, "restricted": 1.5}
_H_FACTOR: dict[str, float] = {"open": 1.5, "standard": 1.0, "controlled": 0.75, "restricted": 0.5}


def _score_aware_timeout(
    score: int | None,
    is_auto_approve: bool,
    profile: str = "standard",
) -> int | None:
    """Compute score × profile aware timeout.

    Timeout-auto (auto-approve): higher score → longer timeout (more intervention time).
    Human (reject): higher score → shorter timeout (reject dangerous ops faster).
    Null score → None (wait forever for human decision).

    Returns timeout in seconds, or None for infinite wait.
    """
    if score is None:
        return None  # null score: always wait for human

    if is_auto_approve:
        base = _T_BASE.get(score, 180)
        factor = _T_FACTOR.get(profile, 1.0)
        raw = base * factor
    else:
        factor = _H_FACTOR.get(profile, 1.0)
        raw = (10 - score) * 60 * factor

    # Clamp to [30, 600] and round to nearest 30s
    clamped = max(30, min(600, raw))
    return round(clamped / 30) * 30


class ApprovalGate:
    """Risk scorer approval gate for tool calls with human-in-the-loop (v2).

    Flow:
    1. Allowlist check -> allow (both scorer and no-scorer paths)
    2. No scorer wired -> fall back to deterministic assess_risk + policy;
       RiskPrompt without scorer -> reject (fail closed)
    3. Score tool call via scorer (assess_risk → LLM if needed) -> RiskScore
    4. Policy table lookup: score x profile -> Auto/Timeout-auto/Human/Reject
    5. On Human/Timeout-auto: request approval, send prompt, await resolution.

    CLI special case: uses ``run_in_executor`` for inline ``input()`` prompt
    (y/n/always). "always" adds the tool to the allowlist.
    """

    def __init__(
        self,
        scorer: RiskScorer | None = None,
        *,
        approval_manager: ApprovalManager | None = None,
        allowlist: AllowlistManager | None = None,
        bus: EventBus | None = None,
        channel_manager: ChannelManager | None = None,
        session_manager: Any = None,
        auto_approve_timeout: int = 180,
        security_profile: str = "standard",
    ) -> None:
        self._scorer = scorer
        self._security_profile = security_profile
        self._approval_manager = approval_manager
        self._allowlist = allowlist
        self._bus = bus
        self._channel_manager = channel_manager
        self._session_manager = session_manager
        self._auto_approve_timeout = auto_approve_timeout

    async def __call__(self, ctx: PreToolHookContext) -> HookResult:
        from praestoclaw.security.risk import PolicyAction, lookup_policy

        # 0. Hard-block config_praestoclaw in cron context (before allowlist)
        if ctx.metadata.get("source") == "cron" and ctx.tool_name == "config_praestoclaw":
            return HookResult.reject("config_praestoclaw is not permitted in cron jobs")

        # 1. Allowlist check — skip scoring entirely (checked for both paths)
        if self._allowlist and self._allowlist.check(ctx.tool_name, ctx.args):
            logger.debug("Allowlist hit for tool '{}' -- skipping scorer", ctx.tool_name)
            return HookResult.allow()

        # 2. No scorer wired -> fall back to deterministic assess_risk + policy
        if not self._scorer:
            if ctx.tool_ref is not None and hasattr(ctx.tool_ref, "assess_risk"):
                from praestoclaw.security.risk import RiskScore

                assessment = ctx.tool_ref.assess_risk(ctx.args)
                if isinstance(assessment, RiskScore):
                    # Cron risk elevation — unattended execution is riskier
                    if ctx.metadata.get("source") == "cron" and assessment.score is not None:
                        assessment = RiskScore(
                            min(assessment.score + 1, 10),
                            f"{assessment.reason} [+1 cron elevation]",
                        )
                    profile = self._security_profile
                    action, always_allow = lookup_policy(assessment.score, profile)
                    if action == PolicyAction.AUTO:
                        return HookResult.allow()
                    if action == PolicyAction.REJECT:
                        return HookResult.reject(
                            f"[score {assessment.score} / 10] {assessment.reason}"
                        )
                    # Human / Timeout-auto — route to approval if available
                    if not self._approval_manager:
                        return HookResult.reject(f"Requires approval: {assessment.reason}")
                    return await self._route_to_approval(ctx, assessment, action, always_allow)
                # RiskPrompt but no scorer → fail closed
                return HookResult.reject("No risk scorer available for LLM evaluation")
            return HookResult.allow()

        # 3. Score the tool call (assess_risk → scorer → policy table)
        risk_score = await self._scorer.score(
            ctx.tool_name,
            ctx.args,
            tool_ref=ctx.tool_ref,
            user_messages=ctx.user_messages or [],
        )

        # 3a. Cron risk elevation — unattended execution is riskier
        if ctx.metadata.get("source") == "cron" and risk_score.score is not None:
            from praestoclaw.security.risk import RiskScore

            risk_score = RiskScore(
                min(risk_score.score + 1, 10),
                f"{risk_score.reason} [+1 cron elevation]",
            )

        # 4. Policy table lookup (use gate's profile, not scorer's, for consistency)
        action, always_allow = lookup_policy(risk_score.score, self._security_profile)

        if action == PolicyAction.AUTO:
            return HookResult.allow()
        if action == PolicyAction.REJECT:
            return HookResult.reject(f"[score {risk_score.score} / 10] {risk_score.reason}")

        # 5. Human or Timeout-auto — route to approval
        if not self._approval_manager:
            return HookResult.reject(f"Requires approval: {risk_score.reason}")

        return await self._route_to_approval(ctx, risk_score, action, always_allow)

    async def _route_to_approval(
        self,
        ctx: PreToolHookContext,
        risk_score: Any,
        action: Any,
        always_allow: bool,
    ) -> HookResult:
        """Route a tool call to human approval (Human or Timeout-auto action)."""
        from praestoclaw.security.risk import PolicyAction

        assert self._approval_manager is not None

        # Score-aware timeouts (see _score_aware_timeout):
        # Timeout-auto: higher score → longer timeout (more time to intervene)
        # Human: higher score → shorter timeout (reject dangerous ops faster)
        auto_timeout: int | None = None
        reject_timeout: int | None = None
        if action == PolicyAction.TIMEOUT_AUTO:
            auto_timeout = _score_aware_timeout(
                risk_score.score, is_auto_approve=True, profile=self._security_profile
            )
        else:
            reject_timeout = _score_aware_timeout(
                risk_score.score, is_auto_approve=False, profile=self._security_profile
            )

        # Resolve channel
        resolved_channel = ctx.channel
        if resolved_channel is None and self._channel_manager:
            active = self._channel_manager.active_channel_names()
            if active:
                resolved_channel = ChannelType.of(active[0])

        # Compute trigger context from metadata (cron, heartbeat, etc.)
        from praestoclaw.security.approval_format import (
            action_preview,
            risk_level,
            trigger_context,
        )

        trigger = trigger_context(ctx.metadata)

        request = await self._approval_manager.request_approval(
            tool_name=ctx.tool_name,
            args=ctx.args,
            agent_name=ctx.agent_name,
            channel=resolved_channel,
            channel_id=ctx.channel_id or "",
            score=risk_score.score,
            reason=risk_score.reason,
            always_allow=always_allow,
            trigger=trigger,
        )

        # Persist approval_request to session (with new card fields)
        if self._session_manager and ctx.session_id:
            import json as _json

            _level, _color, _ = risk_level(risk_score.score)
            self._session_manager.add_message(
                ctx.session_id,
                {
                    "role": "approval_request",
                    "content": _json.dumps(
                        {
                            "request_id": request.id,
                            "tool_name": ctx.tool_name,
                            "action_preview": action_preview(ctx.tool_name, ctx.args),
                            "risk_level": _level,
                            "risk_color": _color,
                            "args": {k: str(v)[:200] for k, v in list(ctx.args.items())[:10]},
                            "score": risk_score.score,
                            "reason": risk_score.reason,
                            "agent_name": ctx.agent_name,
                            "trigger": trigger,
                            "always_allow": always_allow,
                            "status": "pending",
                        }
                    ),
                },
            )

        # Emit APPROVAL_REQUESTED event
        if self._bus:
            from praestoclaw.bus.events import EventType

            self._bus.emit(
                EventType.APPROVAL_REQUESTED,
                {
                    "request_id": request.id,
                    "tool_name": ctx.tool_name,
                    "score": risk_score.score,
                    "reason": risk_score.reason,
                    "always_allow": always_allow,
                    "trigger": trigger,
                },
            )

        # Send approval prompt to channel
        if request.channel == ChannelType.CLI:
            return await self._cli_prompt(
                ctx,
                request,
                risk_score,
                action,
                always_allow,
                auto_timeout,
                reject_timeout=reject_timeout,
            )

        # --- Stage 1: primary channel ---
        source: str = ctx.metadata.get("source", "")
        attempted_channels: set[str] = set()
        sent = await self._send_approval_prompt(
            ctx, request, risk_score, auto_timeout, reject_timeout
        )
        # Track what Stage 1 covered — but only when it actually enqueued
        # AND the send was targeted (not a fan-out push whose sub-channel
        # delivery is uncertain).  For cloud, only mark the sub-channel when
        # the send used a real channel_id (interactive notification frame).
        # Fan-out pushes rely on push_ack below for precise tracking.
        if sent:
            if (
                source in _CLOUD_SOURCES
                and ctx.channel_id
                and not ctx.channel_id.startswith(
                    ("scheduler:", "cron:", "agent-", "copilot-", "claude-")
                )
            ):
                attempted_channels.add(source)
            elif request.channel != ChannelType.CLOUD:
                attempted_channels.add(request.channel.value)

        # For cloud push sends, verify actual delivery via push_ack.
        # _send_approval_prompt returns True when the frame is enqueued,
        # but the gateway may have no webchat/teams clients to deliver to.
        # Wait for the push_ack event (set by CloudChannel on receipt) to
        # confirm delivery, then update tracking.  Interactive notification
        # frames (with a routable channel_id) do not produce push_ack, so
        # skip this check to avoid any delay.
        _used_push_mode = (
            not ctx.channel_id
            or ctx.channel_id.startswith(("scheduler:", "cron:", "agent-", "copilot-", "claude-"))
            or ctx.channel_id == ChannelType.CLOUD.value
        )
        if sent and _used_push_mode and request.channel == ChannelType.CLOUD:
            delivered = await self._verify_cloud_push(request.id, attempted_channels)
            if not delivered:
                sent = False

        # --- Stage 2: next active channel (only if Stage 1 failed) ---
        #   Iterate candidates until one send succeeds.  For cloud pushes,
        #   verify via push_ack that at least one sub-channel received it.
        if not sent:
            for ch_name, push_target in self._fallback_channels(
                request.channel, source, attempted_channels
            ):
                sent = await self._send_push_approval(
                    ch_name, push_target, request, risk_score, auto_timeout, reject_timeout
                )
                if sent:
                    _track_push(attempted_channels, ch_name, push_target)
                    # Verify cloud push delivery
                    if ch_name == ChannelType.CLOUD:
                        delivered = await self._verify_cloud_push(request.id, attempted_channels)
                        if not delivered:
                            sent = False
                            continue  # try next fallback
                    break

        # --- Wait with half-time escalation (Stage 3) ---
        timeout = auto_timeout or reject_timeout
        half = (timeout // 2) if timeout else 300

        resolved_early = await self._approval_manager.wait_partial(request.id, half)
        if not resolved_early and self._approval_manager.is_pending(request.id):
            # Before escalating, check push delivery receipts from the gateway.
            # This narrows Stage 3 to only sub-channels that were NOT reached.
            if self._channel_manager:
                cloud_ch = self._channel_manager.get(ChannelType.CLOUD)
                if cloud_ch:
                    ack = cloud_ch.get_push_delivery(request.id)
                    if ack:
                        if ack.get("webchat"):
                            attempted_channels.add("cloud_webchat")
                        if ack.get("teams"):
                            attempted_channels.add("cloud_teams")
                        # Preserve Teams card ActivityId for cross-channel card updates
                        _teams_aid_val = ack.get("teams_activity_id")
                        if isinstance(_teams_aid_val, str):
                            request.teams_activity_id = _teams_aid_val

            # Stage 3: expand to unattempted channels
            logger.info(
                "Approval {} not resolved after {}s, escalating to other channels",
                request.id,
                half,
            )
            for ch_name, push_target in self._unattempted_channels(attempted_channels):
                ok = await self._send_push_approval(
                    ch_name, push_target, request, risk_score, auto_timeout, reject_timeout
                )
                if ok:
                    _track_push(attempted_channels, ch_name, push_target)
                    logger.info(
                        "Escalated approval {} to {}",
                        request.id,
                        f"{ch_name.value}_{push_target}" if push_target else ch_name.value,
                    )

        # Remaining wait — auto-approve or reject on full timeout
        remaining_auto = (auto_timeout - half) if auto_timeout else None
        remaining_reject = (reject_timeout - half) if reject_timeout else None
        resolved = await self._approval_manager.wait_for_resolution(
            request.id,
            auto_approve_timeout=remaining_auto,
            reject_timeout=remaining_reject,
        )

        # Emit resolution event
        if self._bus:
            from praestoclaw.bus.events import EventType

            approved = resolved.status.value == "approved"
            self._bus.emit(
                EventType.TOOL_APPROVED if approved else EventType.TOOL_DENIED,
                {
                    "request_id": request.id,
                    "tool_name": ctx.tool_name,
                    "resolver": resolved.resolver,
                },
            )

        from praestoclaw.security.approval import ApprovalStatus

        approved = resolved.status == ApprovalStatus.APPROVED
        logger.info(
            "APPROVAL_DECISION tool={} decision={} resolver={} score={} request_id={}",
            ctx.tool_name,
            "approved" if approved else "denied",
            resolved.resolver or "timeout",
            risk_score.score,
            request.id,
        )

        # Cross-channel resolution: notify ALL active channels so cards
        # on other channels collapse (e.g. approved on Teams → Web UI updates).
        if self._channel_manager:
            import json as _json2

            from praestoclaw.security.approval_format import build_resolved_card

            preview = action_preview(ctx.tool_name, ctx.args)
            # Derive specific outcome for accurate card labels
            _action = resolved.action or ""
            _resolver = resolved.resolver or ""
            if _action == "always":
                outcome = "approved_always"
            elif _resolver == "auto-approve-timeout":
                outcome = "approved_timeout"
            elif resolved.status == ApprovalStatus.TIMEOUT:
                outcome = "denied_timeout"
            else:
                outcome = resolved.status.value  # "approved" or "denied"
            resolved_card = build_resolved_card(
                tool_name=ctx.tool_name,
                action_preview=preview,
                score=risk_score.score,
                outcome=outcome,
                agent_name=getattr(ctx, "agent_name", ""),
                reason=risk_score.reason if hasattr(risk_score, "reason") else "",
            )
            # Structured notification — Web UI parses and collapses the card;
            # Gateway uses resolved_card to update Teams Adaptive Cards in-place.
            payload: dict[str, Any] = {
                "type": "approval_resolved",
                "request_id": request.id,
                "status": outcome,
                "resolver": resolved.resolver or "unknown",
                "tool_name": ctx.tool_name,
                "action_preview": preview,
                "resolved_card": resolved_card,
            }
            # Include Teams card ActivityId so the gateway can update the
            # card even after a restart (client-provided, not in-memory).
            _teams_aid = request.teams_activity_id
            if _teams_aid:
                payload["teams_activity_id"] = _teams_aid
            resolution_frame = _json2.dumps(payload)
            for ch_name in self._channel_manager.active_channel_names():
                ch = self._channel_manager.get(ch_name)
                if not ch:
                    continue
                try:
                    cid = ctx.channel_id or ch_name.value
                    await ch.send(cid, resolution_frame, keep_context=True)
                except Exception as exc:
                    logger.warning(
                        "Cross-channel resolution notification failed for {}: {}", ch_name, exc
                    )

        if approved:
            return HookResult.allow()
        return HookResult.reject(
            f"Tool '{ctx.tool_name}' {resolved.status.value} by {resolved.resolver or 'timeout'}"
        )

    async def _cli_prompt(
        self,
        ctx: PreToolHookContext,
        request: Any,
        risk_score: Any,
        action: Any,
        always_allow: bool,
        auto_timeout: int | None,
        *,
        reject_timeout: int | None = None,
    ) -> HookResult:
        """Inline CLI approval prompt — rich display with optional countdown."""
        assert self._approval_manager is not None

        from praestoclaw.security.approval_format import CLIApprovalFormatter

        formatter = CLIApprovalFormatter()
        banner = formatter.format_request(
            request, risk_score, auto_timeout, reject_timeout=reject_timeout
        )

        def _read() -> str:
            try:
                return input(banner).strip().lower()
            except (EOFError, KeyboardInterrupt):
                return "n"

        effective_timeout = auto_timeout or reject_timeout
        if effective_timeout is not None:
            loop = asyncio.get_running_loop()
            try:
                answer = await asyncio.wait_for(
                    loop.run_in_executor(None, _read), timeout=effective_timeout
                )
            except TimeoutError:
                if auto_timeout is not None:
                    print(f"\n  [auto-approved after {auto_timeout}s timeout]")
                    answer = "y"
                else:
                    print(f"\n  [auto-rejected after {reject_timeout}s timeout]")
                    answer = "n"
        else:
            loop = asyncio.get_running_loop()
            answer = await loop.run_in_executor(None, _read)

        approved = answer in ("y", "yes", "always", "a")
        _action = "always" if answer in ("always", "a") else ("approve" if approved else "deny")
        self._approval_manager.resolve(
            request.id, approved=approved, resolver="cli-user", action=_action
        )
        logger.info(
            "APPROVAL_DECISION tool={} decision={} resolver=cli-user score={} request_id={}",
            ctx.tool_name,
            "approved" if approved else "denied",
            risk_score.score,
            request.id,
        )
        if approved:
            if answer in ("always", "a") and always_allow and self._allowlist:
                self._allowlist.add(
                    ctx.tool_name,
                    ctx.args,
                    added_by="cli-user",
                    note="Added via CLI 'always' prompt",
                )
            return HookResult.allow()
        return HookResult.reject(f"Tool '{ctx.tool_name}' denied by user")

    async def _send_approval_prompt(
        self,
        ctx: PreToolHookContext,
        request: Any,
        risk_score: Any,
        auto_timeout: int | None,
        reject_timeout: int | None = None,
    ) -> bool:
        """Send an approval prompt to the primary channel.

        Returns ``True`` if the prompt was enqueued for delivery,
        ``False`` if the channel is unavailable or send failed.
        """
        import json as _json

        from praestoclaw.security.approval_format import get_approval_formatter

        if not self._channel_manager:
            return False
        channel = self._channel_manager.get(request.channel)
        if not channel:
            return False

        # For WebChannel, `is_connected` only tracks WebSocket push subscribers.
        # However, `/api/chat` uses per-request response queues that are still
        # reachable when `ctx.channel_id` is set (in-flight HTTP request).
        # Cron/scheduler passes synthetic IDs like "scheduler:{job}" that are
        # NOT real per-request queues — exclude those.
        _WEB_REQUEST_PREFIXES = ("web-req-", "web-sse-", "web-ws-")
        web_has_request = request.channel == ChannelType.WEB and any(
            ctx.channel_id.startswith(p) for p in _WEB_REQUEST_PREFIXES
        )
        if request.channel == ChannelType.WEB:
            if not (channel.is_connected or web_has_request):
                return False
        elif not channel.is_connected:
            return False

        effective_cid = (
            ctx.channel_id
            if web_has_request
            else (ctx.channel_id or (request.channel.value if request.channel else ""))
        )

        # Select formatter — Teams gets Adaptive Card, others get JSON
        source = ctx.metadata.get("source", "")
        _push_target = "teams" if source == "cloud_teams" else None
        formatter = get_approval_formatter(request.channel, push_target=_push_target)
        content = formatter.format_request(
            request, risk_score, auto_timeout, reject_timeout=reject_timeout
        )
        payload = _json.dumps(content) if isinstance(content, dict) else str(content)
        kwargs: dict[str, Any] = {"keep_context": True}
        if request.channel == ChannelType.CLOUD:
            kwargs["push_request_id"] = request.id
        try:
            await channel.send(effective_cid, payload, **kwargs)
            return True
        except Exception as exc:
            logger.error("Failed to send approval prompt: {}", exc)
            return False

    async def _send_push_approval(
        self,
        ch_name: ChannelType,
        push_target: str | None,
        request: Any,
        risk_score: Any,
        auto_timeout: int | None,
        reject_timeout: int | None = None,
    ) -> bool:
        """Send an approval prompt via push mode to *ch_name*.

        *push_target* is ``"teams"`` / ``"webchat"`` / ``None`` and is
        forwarded as a kwarg to ``CloudChannel.send()`` for targeted push.
        """
        import json as _json

        from praestoclaw.security.approval_format import get_approval_formatter

        if not self._channel_manager:
            return False
        channel = self._channel_manager.get(ch_name)
        if not channel or not channel.is_connected:
            return False

        # CLI: non-blocking print (no interactive prompt)
        if ch_name == ChannelType.CLI:
            try:
                await channel.send(
                    "",
                    f"\n\u26a0 Approval pending: {request.tool_name}"
                    f" (score={request.score}) \u2014 /approve {request.id}\n",
                )
                return True
            except Exception:
                return False

        formatter = get_approval_formatter(ch_name, push_target=push_target)
        content = formatter.format_request(
            request, risk_score, auto_timeout, reject_timeout=reject_timeout
        )
        payload = _json.dumps(content) if isinstance(content, dict) else str(content)
        kwargs: dict[str, Any] = {"keep_context": True}
        if push_target:
            kwargs["push_target"] = push_target
        if ch_name == ChannelType.CLOUD:
            kwargs["push_request_id"] = request.id
        try:
            cid = ch_name.value if hasattr(ch_name, "value") else str(ch_name)
            await channel.send(cid, payload, **kwargs)
            return True
        except Exception as exc:
            logger.warning("Push approval to {}:{} failed: {}", ch_name, push_target, exc)
            return False

    async def _verify_cloud_push(
        self,
        request_id: str,
        attempted_channels: set[str],
    ) -> bool:
        """Wait for push_ack from the Cloud Gateway and update tracking.

        Returns ``True`` if at least one sub-channel received the push
        **or** no ack was received (conservatively assume delivered).
        Returns ``False`` only when the ack explicitly reports both
        sub-channels undelivered.  Uses an event-driven wait so the ack
        arrives (typically <100ms) instead of a fixed sleep.
        """
        if not self._channel_manager:
            return True  # can't verify — assume delivered
        cloud_ch = self._channel_manager.get(ChannelType.CLOUD)
        if not cloud_ch:
            return True

        # Register for push_ack event (set by CloudChannel._on_frame)
        evt = cloud_ch.wait_push_delivery(request_id)
        if evt is not None:
            try:
                await asyncio.wait_for(evt.wait(), timeout=2)
            except TimeoutError:
                pass  # old gateway or slow network — fall through

        ack = cloud_ch.get_push_delivery(request_id)
        if ack is None:
            return True  # no ack — conservatively assume delivered
        if ack.get("webchat"):
            attempted_channels.add("cloud_webchat")
        if ack.get("teams"):
            attempted_channels.add("cloud_teams")
        return bool(ack.get("webchat") or ack.get("teams"))

    def _fallback_channels(
        self,
        primary_channel: ChannelType,
        source: str,
        attempted_channels: set[str],
    ) -> list[tuple[ChannelType, str | None]]:
        """Return an ordered list of fallback ``(channel, push_target)`` candidates.

        The caller iterates and tries each until one send succeeds (e.g.
        a cloud sibling may be unreachable if the WSS is down).
        """
        candidates: list[tuple[ChannelType, str | None]] = []

        # 1. Cloud sub-channel sibling (only when source identifies a sub-channel)
        if primary_channel == ChannelType.CLOUD:
            if source == "cloud_webchat" and "cloud_teams" not in attempted_channels:
                candidates.append((ChannelType.CLOUD, "teams"))
            elif source == "cloud_teams" and "cloud_webchat" not in attempted_channels:
                candidates.append((ChannelType.CLOUD, "webchat"))

        def _append_cloud_subchannels(
            targets: list[tuple[ChannelType, str | None]],
            skip: set[str],
        ) -> None:
            """Split Cloud into targeted sub-channels (teams + webchat).

            A bare ``(CLOUD, None)`` push routes through the generic
            ``CloudApprovalFormatter`` / gateway backward-compat path.
            Always splitting ensures Teams uses ``TeamsApprovalFormatter``
            (pass-through cards) while webchat uses its own formatter.

            Idempotent — safe to call multiple times; checks both *skip* and
            existing entries in *targets* to avoid duplicates.
            """
            existing = {t for c, t in targets if c == ChannelType.CLOUD}
            if "cloud_teams" not in skip and "teams" not in existing:
                targets.append((ChannelType.CLOUD, "teams"))
            if "cloud_webchat" not in skip and "webchat" not in existing:
                targets.append((ChannelType.CLOUD, "webchat"))

        # 2. Other active channels — skip the primary (already tried in
        #    Stage 1) to avoid redundant sends.
        if self._channel_manager:
            for ch_name in self._channel_manager.active_channel_names():
                if ch_name == primary_channel:
                    continue
                ch = self._channel_manager.get(ch_name)
                if not ch or not ch.is_connected:
                    continue
                if ch_name == ChannelType.CLOUD:
                    _append_cloud_subchannels(candidates, attempted_channels)
                else:
                    ch_key = ch_name.value if hasattr(ch_name, "value") else str(ch_name)
                    if ch_key not in attempted_channels:
                        candidates.append((ch_name, None))

        # 3. escalation_channels config — always append (deduped) so
        #    config fallback is reachable even when dynamic candidates fail.
        if self._approval_manager:
            existing_keys = {
                c.value if hasattr(c, "value") else str(c)
                for c, t in candidates
                if t is None  # Cloud entries have t="teams"/"webchat", skip them
            }
            for ch_name in self._approval_manager.escalation_channels:
                if ch_name == ChannelType.CLOUD:
                    # Idempotent — deduplicates against both attempted + existing
                    _append_cloud_subchannels(candidates, attempted_channels)
                else:
                    ch_key = ch_name.value if hasattr(ch_name, "value") else str(ch_name)
                    if ch_key not in attempted_channels and ch_key not in existing_keys:
                        candidates.append((ch_name, None))

        return candidates

    def _unattempted_channels(
        self,
        attempted_channels: set[str],
    ) -> list[tuple[ChannelType, str | None]]:
        """Return delivery targets not yet in *attempted_channels*.

        Cloud is always split into ``cloud_webchat`` and ``cloud_teams`` —
        only the specific sub-channel key suppresses a retry.  A prior
        fan-out (no sub-channel key tracked) does NOT suppress retries
        because the Python client cannot know which sub-channels the
        gateway actually delivered to.
        """
        targets: list[tuple[ChannelType, str | None]] = []
        if not self._channel_manager:
            return targets
        for ch_name in self._channel_manager.active_channel_names():
            ch = self._channel_manager.get(ch_name)
            if not ch or not ch.is_connected:
                continue
            if ch_name == ChannelType.CLOUD:
                if "cloud_webchat" not in attempted_channels:
                    targets.append((ChannelType.CLOUD, "webchat"))
                if "cloud_teams" not in attempted_channels:
                    targets.append((ChannelType.CLOUD, "teams"))
            else:
                ch_key = ch_name.value if hasattr(ch_name, "value") else str(ch_name)
                if ch_key not in attempted_channels:
                    targets.append((ch_name, None))
        return targets


# ── post_tool_use handlers ───────────────────────────────────────────────────


class LeakScanner:
    """Scan tool output for credential patterns and env-var values."""

    async def __call__(self, ctx: PostToolHookContext) -> HookResult:
        # Pattern-based detection (JWT, AWS, GitHub PAT, etc.)
        findings = detect_credentials(ctx.result)
        if findings:
            types = ", ".join(sorted({t for t, _ in findings}))
            logger.warning(
                "Credential patterns detected in '{}' output: {}",
                ctx.tool_name,
                types,
            )

        # Env-var value detection (existing)
        redacted = Sanitizer.redact_env_values(ctx.result)
        if redacted != ctx.result:
            logger.warning("Env var leak detected in '{}' output", ctx.tool_name)

        return HookResult.allow()


class Redactor:
    """Replace detected secrets in tool output.

    Env-var values are replaced with ``[REDACTED]``.
    Credential patterns are replaced with ``[REDACTED:{type}]``
    (e.g. ``[REDACTED:JWT]``, ``[REDACTED:AWS Access Key]``).
    """

    async def __call__(self, ctx: PostToolHookContext) -> HookResult:
        # Pattern-based redaction first, then env-var redaction
        cleaned = redact_credentials(ctx.result)
        cleaned = Sanitizer.redact_env_values(cleaned)
        if cleaned != ctx.result:
            ctx.result = cleaned
        return HookResult.allow(data=ctx)


class Auditor:
    """Log every tool call to the audit trail."""

    def __init__(self, audit_logger: AuditLogger | None = None) -> None:
        self._audit = audit_logger

    async def __call__(self, ctx: PostToolHookContext) -> HookResult:
        if self._audit is not None:
            self._audit.log_tool(
                tool=ctx.tool_name,
                actor=ctx.agent_name,
                args=ctx.args,
                result=ctx.result[:200] if ctx.result else "",
                is_error=not ctx.success,
                session_id=ctx.session_id,
                duration_ms=ctx.duration_ms,
            )
        return HookResult.allow()


# ── on_message_sent handlers ────────────────────────────────────────────────


class OutboundLeakScanner:
    """Scan outbound responses for credential leaks."""

    async def __call__(self, ctx: MessageHookContext) -> HookResult:
        cleaned = redact_credentials(ctx.content)
        cleaned = Sanitizer.redact_env_values(cleaned)
        if cleaned != ctx.content:
            logger.warning("Leak detected in outbound message to {}", ctx.channel)
            ctx.content = cleaned
        return HookResult.allow(data=ctx)


# ── Registration helper ──────────────────────────────────────────────────────


def register_builtin_handlers(
    hook_manager: HookManager,
    *,
    estop: object | None = None,
    policy_engine: PolicyEngine | None = None,
    audit_logger: AuditLogger | None = None,
    scorer: RiskScorer | None = None,
    approval_manager: ApprovalManager | None = None,
    allowlist: AllowlistManager | None = None,
    bus: EventBus | None = None,
    channel_manager: ChannelManager | None = None,
    session_manager: Any = None,
    auto_approve_timeout: int = 180,
    security_profile: str = "standard",
    block_injections: bool = False,
) -> None:
    """Register all built-in handlers onto a HookManager.

    Args:
        hook_manager: HookManager instance.
        estop: EStop instance (optional).
        policy_engine: PolicyEngine instance (optional).
        audit_logger: AuditLogger instance (optional).
        scorer: RiskScorer (v2) for the ApprovalGate (optional).
        approval_manager: ApprovalManager for human-in-the-loop (optional).
        allowlist: AllowlistManager for per-user tool allowlist (optional).
        bus: EventBus for emitting approval events (optional).
        channel_manager: ChannelManager for sending approval prompts (optional).
        auto_approve_timeout: Seconds before Timeout-auto executes.
        block_injections: If True, reject messages with injection patterns.
    """
    mgr = hook_manager

    # on_message_received
    mgr.register("on_message_received", InjectionScanner(block=block_injections), priority=10)

    # pre_tool_use
    mgr.register("pre_tool_use", EStopGate(estop), priority=1)
    mgr.register("pre_tool_use", PolicyGate(policy_engine), priority=10)
    mgr.register(
        "pre_tool_use",
        ApprovalGate(
            scorer,
            approval_manager=approval_manager,
            allowlist=allowlist,
            bus=bus,
            channel_manager=channel_manager,
            session_manager=session_manager,
            auto_approve_timeout=auto_approve_timeout,
            security_profile=security_profile,
        ),
        priority=20,
    )

    # post_tool_use
    mgr.register("post_tool_use", LeakScanner(), priority=10)
    # Redactor disabled — redacting tool output breaks LLM tool chaining
    # (LLM can't use credentials returned by one tool in a subsequent call).
    # User-facing protection is handled by OutboundLeakScanner on_message_sent.
    # See: https://github.com/gim-home/PraestoClaw/issues/184
    mgr.register("post_tool_use", Auditor(audit_logger), priority=30)

    # on_message_sent
    mgr.register("on_message_sent", OutboundLeakScanner(), priority=10)
