"""
CronTool — lets the agent manage scheduled jobs at runtime.

The agent can list, add, remove, enable, disable, run, and inspect jobs.
Dynamic jobs persist to ~/.praestoclaw/cron/jobs.json.

Three execution modes (mutually exclusive):
- message: static text delivered as-is (zero execution cost)
- prompt:  intent for LLM agent (agent selects tools via skills)
- tool:    direct tool call (no LLM)

Delivery is handled by ``notify_channels`` — the executing agent never
needs to know about delivery channels or mechanisms.
"""

from __future__ import annotations

import json
import re
from typing import TYPE_CHECKING, Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.risk import RiskAssessment, RiskPrompt, RiskScore

if TYPE_CHECKING:
    from praestoclaw.agent.tools.registry import ToolRegistry
    from praestoclaw.cron.service import SchedulerService


class CronTool(Tool):
    """Agent-facing tool for managing scheduled jobs."""

    risk_range = (0, 9)

    def __init__(self, scheduler: SchedulerService, registry: ToolRegistry | None = None) -> None:
        self._scheduler = scheduler
        self._registry = registry

    @property
    def name(self) -> str:
        return "cron"

    @property
    def description(self) -> str:
        return (
            "Manage scheduled jobs. "
            "Job output is automatically delivered to the current user via notify_channels."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["add", "list", "remove", "enable", "disable", "run", "info"],
                    "description": (
                        "add = create or replace job; list = show all; "
                        "remove = delete; enable/disable = toggle; "
                        "run = trigger once now; info = show details."
                    ),
                },
                "job_id": {
                    "type": "string",
                    "description": (
                        "Short descriptive name, e.g. 'drink-water'. "
                        "Required for remove/enable/disable/run/info."
                    ),
                },
                "schedule": {
                    "anyOf": [{"type": "string"}, {"type": "integer"}],
                    "description": (
                        "'at:+300' = 5 min from now (seconds); "
                        "'at:2026-03-24T22:10:00' = absolute; "
                        "'3600' = every hour (interval in seconds); "
                        "'0 9 * * *' = cron. Required for add."
                    ),
                },
                # ── Content: three modes, mutually exclusive ──
                "message": {
                    "type": "string",
                    "description": (
                        "Static text delivered as-is (zero cost). "
                        "Default choice for reminders, alerts, greetings, and any fixed text. "
                        "e.g. 'remind me to drink water' → message='Drink water'."
                    ),
                },
                "prompt": {
                    "type": "string",
                    "description": (
                        "Intent for LLM agent at trigger time — "
                        "only when the content requires real-time reasoning (summaries, lookups). "
                        "Write as the current user and do not repeat the USER.md. "
                        "Describe what to produce with a brief high-level plan in user's language. "
                    ),
                },
                "tool": {
                    "type": "string",
                    "description": "Tool name to execute directly. No LLM. Requires tool_args.",
                },
                "tool_args": {
                    "type": "object",
                    "description": "Arguments for tool (required when tool is set).",
                },
                # ── Delivery ──
                "notify_channels": {
                    "type": "array",
                    "items": {
                        "type": "string",
                        "enum": ["cloud", "web", "cli", "*"],
                    },
                    "description": (
                        "WHERE to route results. "
                        "User mentions Teams → ['cloud'] (NOT 'web'). "
                        "Browser → ['web']. Terminal → ['cli']. * = all active. "
                        "Omit (defaults to all active) only if user states no channel preference."
                    ),
                },
            },
            "required": ["action"],
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=45, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        action = (args.get("action", "") or "").strip()
        if action in ("list", "info"):
            return RiskScore(0, reason=f"Read-only cron operation ({action})")
        if action == "run":
            return RiskScore(4, reason="Trigger immediate job execution")
        if action == "enable":
            return RiskScore(3, reason="Re-enable a scheduled job")
        if action == "disable":
            return RiskScore(4, reason="Pause a scheduled job")
        if action == "remove":
            job_id = (args.get("job_id", "") or "").strip()
            job = self._scheduler._jobs.get(job_id) if job_id else None
            if job and (job.message or str(job.schedule).startswith("at")):
                return RiskScore(4, reason="Delete a one-shot or message job")
            return RiskScore(5, reason="Delete a scheduled job")
        # add action
        if args.get("message"):
            return RiskScore(1, reason="Schedule static message delivery")
        tool_name = args.get("tool")
        prompt = args.get("prompt")
        if tool_name and self._registry:
            target = self._registry.get(tool_name)
            if target:
                tool_args = args.get("tool_args") or {}
                tool_risk = target.assess_risk(tool_args)
                if isinstance(tool_risk, RiskScore):
                    return RiskScore(
                        tool_risk.score,
                        reason=f"Schedule {tool_name}: {tool_risk.reason}",
                    )
                # Shift range +1 (capped at 10) for unattended scheduling risk.
                sched_lo = min(tool_risk.range[0] + 1, 10)
                sched_hi = min(tool_risk.range[1] + 1, 10)
                return RiskPrompt(
                    context=(
                        f"Schedule recurring {tool_name} execution.\n"
                        f"Underlying tool: {tool_risk.context}\n"
                        f"Scheduling adds risk — recurring unattended execution."
                    ),
                    range=(sched_lo, sched_hi),
                    signals=tool_risk.signals + ("scheduled",),
                )
        if tool_name:
            return RiskScore(5, reason=f"Schedule tool '{tool_name}' (no registry to evaluate)")
        if prompt:
            preview = prompt[:100] + ("..." if len(prompt) > 100 else "")
            return RiskPrompt(
                context=(
                    f"Agent prompt execution.\n"
                    f"Prompt: {preview}\n"
                    f"Schedule: {args.get('schedule', '?')}"
                ),
                range=(2, 8),
                factors=(
                    "2: Local file reads only",
                    "3: Read external APIs",
                    "4: File modifications",
                    "5: Side effects (notifying current user is automatic, not counted)",
                    "6: External sends to OTHER recipients",
                    "7: Broad scope across multiple systems",
                    "8: Destructive or irreversible operations",
                ),
                exclude_args=frozenset({"notify_channels", "job_id"}),
            )
        return RiskScore(2, reason="Cron management")

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "")

        if action == "list":
            return self._handle_list()
        elif action == "add":
            return self._handle_add(kwargs)
        elif action == "remove":
            return self._handle_job_action(kwargs, "remove")
        elif action == "enable":
            return self._handle_job_action(kwargs, "enable")
        elif action == "disable":
            return self._handle_job_action(kwargs, "disable")
        elif action == "run":
            return await self._handle_run(kwargs)
        elif action == "info":
            return self._handle_info(kwargs)

        return f"Unknown action: {action}"

    # ── Action handlers ───────────────────────────────────────────────

    def _handle_list(self) -> str:
        jobs = self._scheduler.list_jobs()
        if not jobs:
            return "No scheduled jobs."
        lines = ["Scheduled jobs:"]
        for j in jobs:
            status = "enabled" if j["enabled"] else "DISABLED"
            next_run = j.get("next_run") or "N/A"
            mode = j.get("mode", "prompt")
            lines.append(
                f"  {j['name']}: {j['trigger_type']} ({j['schedule']}) "
                f"mode={mode} [{status}] next={next_run}"
            )
        return "\n".join(lines)

    def _handle_add(self, kwargs: dict[str, Any]) -> str:
        schedule = kwargs.get("schedule")
        tool_name = kwargs.get("tool")
        arguments = kwargs.get("tool_args")
        prompt = kwargs.get("prompt")
        message = kwargs.get("message")

        if not schedule:
            return "Error: 'schedule' is required for add."

        # Mutual exclusivity (three-way)
        modes_set = sum(1 for x in (message, prompt, tool_name) if x)
        if modes_set > 1:
            return "Error: 'message', 'prompt', and 'tool' are mutually exclusive."
        if modes_set == 0:
            return "Error: one of 'message', 'prompt', or 'tool' is required for add."
        if tool_name and arguments is None:
            return "Error: 'tool_args' is required when 'tool' is set."

        # Block config_praestoclaw — not permitted in cron jobs
        if tool_name == "config_praestoclaw":
            return "Error: config_praestoclaw cannot be scheduled as a cron job."

        # Tool existence check
        if tool_name and self._registry:
            target = self._registry.get(tool_name)
            if not target:
                return f"Error: unknown tool '{tool_name}'."

        # Job ID derivation (no auto-suffix — replace semantics)
        job_id = kwargs.get("job_id")
        if not job_id:
            source = message or prompt or tool_name or "job"
            # \w matches Unicode letters (Chinese, etc.) + digits + underscore
            slug = re.sub(r"[^\w]+", "-", source[:40], flags=re.UNICODE).strip("-")
            job_id = slug or "job"

        notify_channels = kwargs.get("notify_channels")
        if notify_channels is None:
            notify_channels = ["*"]

        try:
            self._scheduler.add_job(
                name=job_id,
                schedule=schedule,
                prompt=prompt or "",
                message=message,
                tool=tool_name,
                arguments=arguments,
                notify_channels=notify_channels,
                dynamic=True,
                channel=kwargs.get("_channel"),
                channel_id=kwargs.get("_channel_id"),
            )
        except ValueError as exc:
            return f"Error: {exc}"

        # Rich return value with summary
        from praestoclaw.cron import detect_trigger_type

        trigger_type = detect_trigger_type(schedule)
        if message:
            mode_line = "Mode: message"
            content_line = f"Content: {message[:100]}"
        elif prompt:
            mode_line = "Mode: prompt"
            content_line = f"Prompt: {prompt[:100]}"
        else:
            mode_line = f"Mode: tool ({tool_name})"
            content_line = f"Arguments: {json.dumps(arguments, ensure_ascii=False)}"

        deliver_str = ", ".join(notify_channels)
        return (
            f"Job '{job_id}' added.\n"
            f"  Schedule: {schedule} ({trigger_type})\n"
            f"  {mode_line}\n"
            f"  Deliver to: {deliver_str}\n"
            f"  {content_line}\n"
            f"Use cron(action='run', job_id='{job_id}') to test now."
        )

    def _handle_job_action(self, kwargs: dict[str, Any], action: str) -> str:
        job_id = kwargs.get("job_id")
        if not job_id:
            return f"Error: 'job_id' is required for {action}."
        try:
            getattr(self._scheduler, f"{action}_job" if action == "remove" else action)(job_id)
        except ValueError as exc:
            return f"Error: {exc}"
        return f"Job '{job_id}' {action}d."

    async def _handle_run(self, kwargs: dict[str, Any]) -> str:
        job_id = kwargs.get("job_id")
        if not job_id:
            return "Error: 'job_id' is required for run."

        # prompt/tool mode → background (avoids timeout); message mode → sync
        job_obj = self._scheduler._jobs.get(job_id)
        run_in_background = bool(job_obj and not job_obj.message)

        try:
            if run_in_background:
                await self._scheduler.run_job(job_id, background=True)
                jobs_by_name = {j["name"]: j for j in self._scheduler.list_jobs()}
                job = jobs_by_name.get(job_id, {})
                deliver_str = ", ".join(job.get("notify_channels", ["*"]))
                return (
                    f"Job '{job_id}' triggered in background.\n"
                    f"Result will be delivered to: {deliver_str}"
                )
            else:
                result = await self._scheduler.run_job(job_id)
                if result is None:
                    return f"Job '{job_id}' execution failed. Check logs."
                return f"Job '{job_id}' triggered.\n---\n{result}"
        except ValueError as exc:
            return f"Error: {exc}"

    def _handle_info(self, kwargs: dict[str, Any]) -> str:
        job_id = kwargs.get("job_id")
        if not job_id:
            return "Error: 'job_id' is required for info."
        jobs_by_name = {j["name"]: j for j in self._scheduler.list_jobs()}
        job = jobs_by_name.get(job_id)
        if not job:
            return f"Error: job '{job_id}' not found."  # info is read-only, no service call needed
        mode = job.get("mode", "prompt")
        deliver_str = ", ".join(job.get("notify_channels", ["*"]))

        # Content line based on mode
        if mode == "message":
            content_line = f"Content: {job.get('message', '')}"
        elif mode == "tool":
            content_line = f"Tool: {job.get('tool', '')}"
        else:
            # Prompt mode
            prompt = job.get("prompt", "")
            content_line = f"Prompt: {prompt[:1024]}" if prompt else ""

        lines = [
            f"Job: {job['name']}",
            f"Schedule: {job['trigger_type']} ({job['schedule']})",
            f"Mode: {mode}",
            f"Deliver to: {deliver_str}",
            f"Status: {'enabled' if job['enabled'] else 'DISABLED'}",
            f"Next run: {job.get('next_run') or 'N/A'}",
            f"Failures: {job['failure_count']}",
        ]
        if job.get("created_at"):
            lines.append(f"Created: {job['created_at'][:19]}")
        if job.get("updated_at"):
            lines.append(f"Updated: {job['updated_at'][:19]}")
        if content_line:
            lines.append(content_line)
        return "\n".join(lines)
