"""
Shell execution tool — sandboxed command runner with deny-pattern guards,
workspace restriction, output truncation, and timeout enforcement.
"""

from __future__ import annotations

import asyncio
import os
import platform
import re
import shutil
from typing import Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.leak import redact_credentials
from praestoclaw.security.risk import RiskAssessment, RiskPrompt, RiskScore
from praestoclaw.security.sandbox import CommandDeniedError, PathDeniedError, Sandbox

_IS_WINDOWS = platform.system() == "Windows"


async def _kill_proc_tree(proc: asyncio.subprocess.Process) -> None:
    """Terminate a subprocess and wait for it to exit.

    On Windows ``proc.kill()`` only terminates the direct process; child
    processes (e.g. a python child spawned by bash/cmd) keep running and
    hold the pipes open.  ``taskkill /F /T`` is used here to terminate the
    whole process tree.  On non-Windows platforms, only the direct process
    is signaled with ``proc.kill()``, and child processes may continue
    running.

    All waits are bounded to avoid hanging the timeout handler.
    All kill calls suppress ``OSError`` / ``ProcessLookupError`` for
    already-exited processes so cleanup is best-effort and never raises.
    """
    kill_timeout = 5.0
    if _IS_WINDOWS:
        # /F = force, /T = tree (children), /PID = by process id
        # Use absolute path to prevent PATH hijack from workspace.
        _taskkill = os.path.join(
            os.environ.get("SystemRoot", r"C:\Windows"), "System32", "taskkill.exe"
        )
        try:
            kill_proc = await asyncio.create_subprocess_exec(
                _taskkill,
                "/F",
                "/T",
                "/PID",
                str(proc.pid),
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            try:
                await asyncio.wait_for(kill_proc.wait(), timeout=kill_timeout)
            except TimeoutError:
                try:
                    kill_proc.kill()
                    await asyncio.wait_for(kill_proc.wait(), timeout=2)
                except (OSError, TimeoutError):
                    pass
                try:
                    proc.kill()
                except OSError:
                    pass
            else:
                if kill_proc.returncode != 0:
                    try:
                        proc.kill()
                    except OSError:
                        pass
        except OSError:
            try:
                proc.kill()
            except OSError:
                pass
    else:
        try:
            proc.kill()
        except OSError:
            pass

    try:
        await asyncio.wait_for(proc.wait(), timeout=kill_timeout)
    except (TimeoutError, OSError):
        pass


def _has_unquoted_compound(cmd: str) -> bool:
    """Check for ``|``, ``||``, ``&&``, ``&``, or ``;`` outside of quotes.

    Skips fd-redirect forms (``2>&1``, ``1>&2``, ``&>``, ``&>>``) which are
    NOT compound operators.
    """
    in_single = False
    in_double = False
    i = 0
    n = len(cmd)
    while i < n:
        c = cmd[i]
        if c == "'" and not in_double:
            in_single = not in_single
        elif c == '"' and not in_single:
            in_double = not in_double
        elif not in_single and not in_double:
            if c == "|" or c == ";":
                return True
            if c == "&":
                # Skip fd-redirect: N>&M (digit before >, & after >)
                # and &> / &>> (& before >)
                if i + 1 < n and cmd[i + 1] == ">":
                    i += 1  # skip past &> or &>>
                elif i > 0 and cmd[i - 1] == ">":
                    pass  # e.g. >&1 — part of N>&M
                else:
                    return True  # && or background &
        i += 1
    return False


def _has_unquoted_redirect(cmd: str) -> bool:
    """Check for file-targeting ``>``/``>>``/``&>``/``&>>`` outside quotes.

    Only skips fd-dup forms where ``>&`` is followed by a single digit
    (``>&1``, ``>&2``, ``2>&1``).  All other ``>`` are treated as file
    redirects, including bash ``&>`` / ``&>>`` (stdout+stderr to file).
    """
    in_single = False
    in_double = False
    i = 0
    n = len(cmd)
    while i < n:
        c = cmd[i]
        if c == "'" and not in_double:
            in_single = not in_single
        elif c == '"' and not in_single:
            in_double = not in_double
        elif c == ">" and not in_single and not in_double:
            if i > 0 and cmd[i - 1] == ">":
                pass  # second > in >> or &>> (first > already counted)
            elif i + 1 < n and cmd[i + 1] == "&":
                # >&digit is fd-dup (e.g. >&1, 2>&1). >&nondigit is file redirect.
                if i + 2 < n and cmd[i + 2].isdigit():
                    pass  # fd-dup: >&1, >&2
                else:
                    return True  # >&somefile — file redirect
            else:
                return True  # plain > or >> or &> or &>>
        i += 1
    return False


# ── Risk assessment patterns ─────────────────────────────────────────────────

# File-reading commands — score based on target file path (reuse filesystem logic).
_SHELL_FILE_READ = re.compile(
    r"^(cat|head|tail|less|more|file|stat|wc|type)\s+(.+)",
    re.IGNORECASE,
)
# Directory-reading commands — score based on target path.
_SHELL_DIR_READ = re.compile(
    r"^(ls|dir|tree|du|df)\b(?:\s+(.+))?",
    re.IGNORECASE,
)
# Pure info commands — always 0, no file target.
_SHELL_INFO = re.compile(
    r"^(pwd|whoami|hostname|uname|date|id|env|printenv|set|echo|which|where|"
    r"where\.exe|Start-Sleep)\b",
    re.IGNORECASE,
)
# Search commands — score based on search path.
_SHELL_SEARCH = re.compile(
    r"^(find|grep|rg|ag|awk|sed\s+-n|sort|uniq|cut|tr|diff|md5sum|sha256sum)\b",
    re.IGNORECASE,
)
# Linters (read-only analysis) → 2
_SHELL_LINTER = re.compile(
    r"^(ruff\s+check|mypy|pyright|pylint|flake8|eslint|tsc)\b",
    re.IGNORECASE,
)
# Test runners (may create/modify files) → 3
_SHELL_TEST = re.compile(
    r"^(pytest|(?:python[23]?(?:\.\d+)?|py)\s+-m\s+pytest|(?:python[23]?(?:\.\d+)?|py)\s+-m\s+unittest|"
    r"npm\s+test|npx\s+jest|npx\s+vitest|go\s+test|"
    r"cargo\s+test|dotnet\s+test)\b",
    re.IGNORECASE,
)
# Formatters (modify files in place) → 3
_SHELL_FORMATTER = re.compile(
    r"^(ruff\s+format|black|prettier|gofmt|rustfmt|dotnet\s+format)\b",
    re.IGNORECASE,
)
# Info commands for toolchains → 0
_SHELL_TOOLCHAIN_INFO = re.compile(
    r"^(dotnet\s+--info|dotnet\s+--list-sdks|dotnet\s+--list-runtimes|"
    r"dotnet\s+--version|node\s+--version|(?:python[23]?(?:\.\d+)?|py)\s+--version|"
    r"go\s+version|rustc\s+--version|java\s+--version)\b",
    re.IGNORECASE,
)
# Trivial project setup → 2
_SHELL_PROJECT_INIT = re.compile(
    r"^(dotnet\s+new)\b",
    re.IGNORECASE,
)
# Build / restore (compile, no install to system) → 3
_SHELL_BUILD = re.compile(
    r"^(npm\s+(run\s+)?build|yarn\s+build|cmake|"
    r"cargo\s+build|go\s+build|dotnet\s+build|dotnet\s+publish|dotnet\s+restore|"
    r"pip\s+wheel|(?:python[23]?(?:\.\d+)?|py)\s+setup\.py|(?:python[23]?(?:\.\d+)?|py)\s+-m\s+build)\b",
    re.IGNORECASE,
)
# Install commands → LLM (3~7)
_SHELL_INSTALL = re.compile(
    r"^(pip\s+install|(?:python[23]?(?:\.\d+)?|py)\s+-m\s+pip\s+install|npm\s+install|"
    r"yarn\s+add|dotnet\s+add\s+package|dotnet\s+tool\s+install|make)\b",
    re.IGNORECASE,
)
# npx / dotnet run → LLM (4~8), runs arbitrary code
_SHELL_EXEC_ARBITRARY = re.compile(
    r"^(npx\s|dotnet\s+run)\b",
    re.IGNORECASE,
)
# Publish / DB migration → LLM (5~8), affects external systems
_SHELL_PUBLISH = re.compile(
    r"^(dotnet\s+nuget\s+push|npm\s+publish|dotnet\s+ef\s+database)\b",
    re.IGNORECASE,
)
# curl/wget piped to shell → 9
_SHELL_CURL_PIPE = re.compile(
    r"\b(curl|wget)\b.*\|\s*(ba)?sh\b",
    re.IGNORECASE,
)
# General pipe to interpreter → LLM (includes PowerShell variants)
_SHELL_PIPE_EXEC = re.compile(
    r"\|\s*(ba)?sh\b|\|\s*python\b|\|\s*node\b|\|\s*eval\b|"
    r"\|\s*pwsh\b|\|\s*powershell\b|\|\s*iex\b|\|\s*Invoke-Expression\b",
    re.IGNORECASE,
)
# Common cleanup targets (gitignored / build artifacts / temp files) → 4
# Well-known build artifacts / cache / temp directories and glob patterns.
# Match: rm [-rf] <known-target> (end of string — no other args).
_CLEANUP_TARGETS = (
    r"__pycache__|\.pytest_cache|\.mypy_cache|\.ruff_cache|\.tox"
    r"|node_modules|\.next|\.nuxt|\.output"
    r"|bin[\\/]Debug|bin[\\/]Release|obj"
    r"|target[\\/]debug|target[\\/]release"
    r"|\.cache"
    r"|\*\.pyc|\*\.pyo|\*\.tmp|\*\.log|\*\.bak"
)
_SHELL_CLEANUP = re.compile(
    rf"^rm\s+(-r\s+|-rf\s+|-f\s+)?({_CLEANUP_TARGETS})[\\/]?$",
    re.IGNORECASE,
)
# rm -rf (recursive force, not cleanup) → 7
_SHELL_RM_RF = re.compile(r"^rm\s+-rf\s", re.IGNORECASE)
# rm (single file or directory) → 5
_SHELL_RM = re.compile(r"^(rm|rmdir|del|rd|shred|unlink)\b", re.IGNORECASE)
_SHELL_NETWORK = re.compile(
    r"\b(curl|wget|ssh|scp|rsync|nc|ncat|netcat|telnet|ftp)\b",
    re.IGNORECASE,
)
_SHELL_DELETE = re.compile(
    r"\b(rm|rmdir|del|rd|shred|unlink)\b",
    re.IGNORECASE,
)
_SHELL_ELEVATED = re.compile(
    r"\b(sudo|runas|doas|pkexec|su\s)\b",
    re.IGNORECASE,
)
_SHELL_REDIRECT_SYSTEM = re.compile(
    r">{1,2}\s*/etc/|>{1,2}\s*/usr/|>{1,2}\s*C:\\Windows",
    re.IGNORECASE,
)

# ── Git commands (checked in order: force → push → remote → read → write) ────

# Git force push / hard reset / clean / destructive branch-tag delete → 7
# Matches: -f (standalone or combined like -fu), --force, --force-with-lease
_SHELL_GIT_FORCE = re.compile(
    r"^git\s+("
    r"push\s+.*(-[a-zA-Z]*f[a-zA-Z]*(\s|$)|--force)|"
    r"reset\s+--hard|"
    r"clean\s+-[fdxX]|"
    r"branch\s+(?-i:-D)\b|"
    r"tag\s+-d\b"
    r")",
    re.IGNORECASE,
)
# Git push (non-force, checked after force) → 5
_SHELL_GIT_PUSH = re.compile(r"^git\s+push\b", re.IGNORECASE)
# Git fetch / pull / clone → 4
_SHELL_GIT_REMOTE = re.compile(
    r"^git\s+(fetch|pull|clone)\b",
    re.IGNORECASE,
)
# Git read-only → 0
# Only subcommands that are ALWAYS read-only regardless of flags.
# branch/tag/remote/config have both read and write forms → handled in _WRITE.
# reflog without subcommand is read; reflog expire/delete are destructive → _WRITE.
_SHELL_GIT_READ = re.compile(
    r"^git\s+(status|log|diff|show|blame|shortlog|describe|"
    r"ls-files|ls-tree|rev-parse|rev-list|version|help|"
    r"grep|stash\s+(list|show)|reflog(?!\s+(expire|delete)))\b",
    re.IGNORECASE,
)
# Git local write → 3
# Includes branch/tag/remote/config (have write forms; read forms are low-risk
# at score 3 anyway — trivially reversible, acceptable conservative score).
_SHELL_GIT_WRITE = re.compile(
    r"^git\s+(add|commit|stash|checkout|switch|merge|rebase|cherry-pick|"
    r"reset|am|apply|mv|restore|bisect|worktree|init|"
    r"branch|tag|remote|config|submodule|reflog)\b",
    re.IGNORECASE,
)

# ── File operations ──────────────────────────────────────────────────────────

_SHELL_CD = re.compile(r"^cd(\s|$)", re.IGNORECASE)
_SHELL_FILE_CREATE = re.compile(r"^(mkdir|touch)\b", re.IGNORECASE)
_SHELL_FILE_COPY = re.compile(r"^(cp|copy|mv|move|rename|ln)\b", re.IGNORECASE)
_SHELL_ARCHIVE = re.compile(
    r"^(tar|zip|unzip|gzip|gunzip|7z|bzip2|xz)\b",
    re.IGNORECASE,
)

# ── Package manager info ─────────────────────────────────────────────────────

# Local-only queries (no network) → 0
_SHELL_PKG_LOCAL = re.compile(
    r"^("
    r"pip\s+(list|show|freeze|check|--version)|"
    r"(?:python[23]?(?:\.\d+)?|py)\s+-m\s+pip\s+(list|show|freeze|check)|"
    r"npm\s+(ls|list|--version)|"
    r"yarn\s+(list|why|--version)|"
    r"dotnet\s+(list|nuget\s+list|tool\s+list)|"
    r"cargo\s+(tree|metadata|--version)|"
    r"go\s+(list|mod\s+(graph|verify)|version)"
    r")\b",
    re.IGNORECASE,
)
# Network-querying package commands (contact registry) → 1
_SHELL_PKG_NETWORK = re.compile(
    r"^("
    r"pip\s+index|(?:python[23]?(?:\.\d+)?|py)\s+-m\s+pip\s+index|"
    r"npm\s+(info|view|outdated|audit(?!\s+fix))|"
    r"yarn\s+(info|outdated)"
    r")\b",
    re.IGNORECASE,
)

# ── Script file execution → 3 (known file, can't see content) ───────────────

# Only match known script extensions. Bare `./gradlew` or `./configure` could
# run arbitrary code and should fall through to the ambiguous LLM path.
_SHELL_SCRIPT_FILE = re.compile(
    r"^("
    r"(?:python[23]?(?:\.\d+)?|py)\s+[\w./\\-]+\.pyw?\b|"  # python script.py / .pyw
    r"node\s+[\w./\\-]+\.(js|mjs|cjs)\b|"  # node app.js
    r"bash\s+[\w./\\-]+\.(sh|bash)\b|"  # bash script.sh
    r"sh\s+[\w./\\-]+\.(sh|bash)\b|"  # sh script.sh
    r"\.[\\/](?:[\w.-]+[\\/])*[\w.-]+\.(sh|bash|py|pyw|js|mjs|cjs|ps1)\b"  # ./scripts/run.sh
    r")",
    re.IGNORECASE,
)

# ── Inline / dynamic code execution → LLM (content determines risk) ─────────
# These run CODE CONTENT that is visible in the command string.  The LLM must
# evaluate the payload, not just the interpreter.  See _SECURITY_SHELL.md §
# "Inline & dynamic script execution".

_SHELL_INLINE_EXEC = re.compile(
    r"^("
    r"(?:python[23]?(?:\.\d+)?|py)\s+-c\s|"  # python -c "..."
    r"(?:python[23]?(?:\.\d+)?|py)\s+-m\s|"  # python -m module (unknown module)
    r"node\s+-e\s|"  # node -e "..."
    r"bash\s+-c\s|sh\s+-c\s|"  # bash -c "..." / sh -c "..."
    r"pwsh\s+(-c|-Command)\s|"  # pwsh -c/-Command "..."
    r"powershell\s+(-c|-Command)\s"  # powershell -Command "..."
    r")",
    re.IGNORECASE,
)

# ── PowerShell cmdlet (read-like verbs) → LLM for path-aware scoring ────────
# Bare PS cmdlet calls (not wrapped in powershell -Command).
# Get-*, Test-*, Select-*, Measure-*, Where-*, Format-*, Sort-*, Group-*

_SHELL_PS_READ = re.compile(
    r"^(Get-|Test-|Select-|Measure-|Where-|Format-|Sort-|Group-|"
    r"Compare-|ConvertTo-|ConvertFrom-|Out-String|Write-Output|"
    r"Select-String)\w*\b",
    re.IGNORECASE,
)

# ── PowerShell expression → LLM (may hide side effects like .Delete()) ──────
# Parenthesized expressions starting with read cmdlets: (Get-Item ...), (Get-Date)

_SHELL_PS_EXPR_READ = re.compile(r"^\((Get-|Test-|Measure-|Select-)", re.IGNORECASE)

# ── GitHub CLI ───────────────────────────────────────────────────────────────

_SHELL_GH_READ = re.compile(
    r"^gh\s+("
    r"pr\s+(list|view|diff|checks|status)|"
    r"issue\s+(list|view|status)|"
    r"repo\s+(view|list)|"
    r"run\s+(list|view|watch)|"
    r"release\s+(list|view)|"
    r"auth\s+status|copilot"
    r")\b",
    re.IGNORECASE,
)
# gh repo clone → 4 (same as git clone — downloads remote code)
_SHELL_GH_CLONE = re.compile(r"^gh\s+repo\s+clone\b", re.IGNORECASE)
# gh api without explicit method is GET (read), but with -X POST/PUT/DELETE is write.
# Route `gh api` to LLM via the ambiguous section for method-aware scoring.
_SHELL_GH_WRITE = re.compile(
    r"^gh\s+("
    r"pr\s+(create|merge|close|comment|review|edit|reopen|ready)|"
    r"issue\s+(create|close|comment|edit|reopen)|"
    r"repo\s+(fork)|"
    r"release\s+(create|delete|edit)|"
    r"run\s+(cancel|rerun)"
    r")\b",
    re.IGNORECASE,
)

# Shell executable resolution for each mode
_SHELL_EXECUTABLES: dict[str, list[str]] = {
    "bash": ["bash"],
    "cmd": ["cmd.exe"],
    "powershell": ["pwsh", "powershell"],
}


def _resolve_shell(mode: str) -> tuple[str | None, list[str]]:
    """Resolve shell executable and prefix args.

    Returns (executable, prefix_args). executable=None means use default
    (asyncio.create_subprocess_shell).

    Supports named modes (auto/bash/cmd/powershell) and arbitrary paths.
    """
    if mode == "auto":
        return None, []

    # Named modes
    candidates = _SHELL_EXECUTABLES.get(mode)
    if candidates:
        for candidate in candidates:
            path = shutil.which(candidate)
            if path:
                if mode == "cmd":
                    return path, ["/c"]
                if mode == "powershell":
                    return path, ["-NoProfile", "-Command"]
                return path, ["-c"]
        return None, []  # fallback to default

    # Arbitrary path (e.g. "/usr/bin/zsh", "C:\\cygwin\\bin\\sh.exe")
    resolved = shutil.which(mode)
    if resolved:
        return resolved, ["-c"]

    return None, []  # fallback to default


class ShellTool(Tool):
    """Execute shell commands within the workspace sandbox."""

    risk_range = (0, 10)
    _MAX_BACKGROUND = 3

    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox
        self._background: dict[int, asyncio.subprocess.Process] = {}  # pid → proc

    async def kill_all_background(self) -> int:
        """Kill all background processes. Called on E-stop or session end.

        Returns number of processes that were confirmed terminated.
        Processes that survive are kept in the dict for retry on next call.
        """
        killed = 0
        for pid, proc in list(self._background.items()):
            if proc.returncode is None:
                await _kill_proc_tree(proc)
            if proc.returncode is not None:
                del self._background[pid]
                killed += 1
        return killed

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=600, streaming=True)

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        command = (args.get("command", "") or "").strip()
        if not command:
            return RiskScore(0, reason="Empty command")
        # Redacted command for use in prompt/reason strings (visible in UI/logs/LLM).
        # Original `command` is still used for pattern matching above.
        safe_cmd = redact_credentials(command)

        # ── Deny patterns → 10 (except curl|sh which is handled below) ──
        # curl|sh is caught by _SHELL_CURL_PIPE at score 9 before deny check
        if _SHELL_CURL_PIPE.search(command):
            return RiskScore(9, reason=f"Pipe download to shell: {safe_cmd}")

        matched = self._sandbox.match_deny_pattern(command)
        if matched:
            return RiskScore(10, reason=f"Matches deny pattern: {matched}")

        # ── Compound / redirect / pipe pre-checks ────────────────────────
        # These must run BEFORE command-specific patterns (info, search, PS
        # read) to prevent `echo > /etc/passwd` or `Get-X | Remove-X` from
        # being short-circuited at a low score.

        # System redirect anywhere in command → LLM (elevated range)
        if _SHELL_REDIRECT_SYSTEM.search(command):
            return RiskPrompt(
                context=f"Shell command with system redirect: {safe_cmd}",
                range=(7, 9),
                signals=("system-redirect",),
                factors=(
                    "7: Append to system log file",
                    "8: Overwrite system config (/etc/hosts, /etc/resolv.conf)",
                    "9: Overwrite critical system file (/etc/passwd, /etc/shadow)",
                ),
            )

        # Any other redirect (> or >>) outside quotes → LLM (write operation)
        # Catches `echo x > file.txt` which is score 2-3, not 0.
        if _has_unquoted_redirect(command):
            return RiskPrompt(
                context=f"Shell command with output redirect: {safe_cmd}",
                range=(2, 5),
                factors=(
                    "2: Redirect to workspace temp/output file",
                    "3: Redirect overwriting existing workspace file",
                    "5: Redirect to user config or sensitive path",
                ),
            )

        # Pipe to interpreter → LLM
        if _SHELL_PIPE_EXEC.search(command):
            return RiskPrompt(
                context=f"Shell command pipes to interpreter: {safe_cmd}",
                range=(5, 8),
                factors=(
                    "5: Pipe of known safe content (e.g. echo literal | python -c)",
                    "6: Pipe from local file to interpreter",
                    "7: Pipe from network source or dynamic content",
                    "8: Pipe with elevated privileges or to system shell",
                ),
            )

        # Compound command (|, &&, ;) outside quotes → LLM for full evaluation.
        # Must go to LLM before simple matchers to prevent e.g.
        # `echo x | sudo tee /etc/hosts` from being caught by _SHELL_INFO.
        # Quote-aware: `grep 'a|b'` and `curl "?a=1&b=2"` are NOT compound.
        # Note: escaped quotes (\" inside double-quotes) may cause false positives
        # (routing safe commands to LLM unnecessarily) — this is a safe failure.
        if _has_unquoted_compound(command):
            return RiskPrompt(
                context=f"Compound shell command: {safe_cmd}",
                range=(2, 8),
                factors=(
                    "2: Chained read-only commands (pwd && ls, git status && echo done)",
                    "4: Chain includes local write (mkdir && cp, ls | tee file)",
                    "6: Chain includes network or external side-effect",
                    "7: Chain includes destructive or system-impacting operation",
                    "8: Chain with elevated privileges or system file writes",
                ),
            )

        # ── Git commands (order: force → push → remote → read → write) ──
        if _SHELL_GIT_FORCE.match(command):
            return RiskScore(7, reason=f"Git force/destructive: {safe_cmd}")
        if _SHELL_GIT_PUSH.match(command):
            return RiskScore(5, reason=f"Git push: {safe_cmd}")
        if _SHELL_GIT_REMOTE.match(command):
            return RiskScore(4, reason=f"Git remote operation: {safe_cmd}")
        if _SHELL_GIT_READ.match(command):
            return RiskScore(0, reason=f"Git read-only: {safe_cmd}")
        if _SHELL_GIT_WRITE.match(command):
            return RiskScore(3, reason=f"Git local write: {safe_cmd}")

        # ── File-reading commands → score based on file path ─────────────
        from praestoclaw.agent.tools.filesystem import path_risk_level

        m = _SHELL_FILE_READ.match(command)
        if m:
            target = m.group(2).split()[0].strip("'\"")  # first argument
            _, read_score, _ = path_risk_level(target)
            return RiskScore(read_score, reason=f"Read file: {target}")

        m = _SHELL_DIR_READ.match(command)
        if m:
            target = (m.group(2) or ".").split()[0].strip("'\"")
            category, _, _ = path_risk_level(target)
            if category == "credential":
                return RiskScore(4, reason=f"List credential dir: {target}")
            if category == "system":
                return RiskScore(3, reason=f"List system dir: {target}")
            if category in ("user_secret", "project_secret"):
                return RiskScore(1, reason=f"List {category} dir: {target}")
            return RiskScore(0, reason=f"Read-only: {safe_cmd}")

        # Pure info commands → 0
        if _SHELL_INFO.match(command):
            return RiskScore(0, reason="Info command")

        # Search commands → 1 (read-only but may scan file contents)
        if _SHELL_SEARCH.match(command):
            return RiskScore(1, reason="Search command")

        # cd → 0
        if _SHELL_CD.match(command):
            return RiskScore(0, reason="Change directory")

        # Package info — local queries → 0, network queries → 1
        if _SHELL_PKG_LOCAL.match(command):
            return RiskScore(0, reason="Package info (local)")
        if _SHELL_PKG_NETWORK.match(command):
            return RiskScore(1, reason=f"Package info (network query): {safe_cmd}")

        # ── Dev tools ────────────────────────────────────────────────────
        if _SHELL_TOOLCHAIN_INFO.match(command):
            return RiskScore(0, reason="Toolchain version/info query")

        if _SHELL_LINTER.match(command):
            return RiskScore(2, reason="Linter (read-only analysis)")

        if _SHELL_PROJECT_INIT.match(command):
            return RiskScore(2, reason="Project scaffolding")

        if _SHELL_TEST.match(command):
            return RiskScore(3, reason="Test runner (may modify files)")

        if _SHELL_FORMATTER.match(command):
            return RiskScore(3, reason="Formatter (modifies files in place)")

        if _SHELL_BUILD.match(command):
            return RiskScore(3, reason="Build/compile command")

        # File creation → 1
        if _SHELL_FILE_CREATE.match(command):
            return RiskScore(1, reason=f"Create file/directory: {safe_cmd}")

        # File copy/move → 2
        if _SHELL_FILE_COPY.match(command):
            return RiskScore(2, reason=f"Copy/move file: {safe_cmd}")

        # Archive / compression → 2
        if _SHELL_ARCHIVE.match(command):
            return RiskScore(2, reason=f"Archive/compression: {safe_cmd}")

        # Script file execution → 3 (known file, can't see content)
        if _SHELL_SCRIPT_FILE.match(command):
            return RiskScore(3, reason=f"Script file execution: {safe_cmd}")

        # ── Install / package management → LLM (3~7) ────────────────────
        # Checked BEFORE inline exec so `python -m pip install` uses install
        # range (3~7) not the broader inline range (0~7).
        if _SHELL_INSTALL.match(command):
            return RiskPrompt(
                context=f"Shell command: {safe_cmd}",
                range=(3, 7),
                signals=("install", "package manager"),
                factors=(
                    "3: Local editable install (pip install -e .), lock-file restore (npm ci)",
                    "4: Well-known package from official registry",
                    "5: Less common package, or installs from git URL",
                    "6: Untrusted source, --pre/--force flag, or system-wide install (no venv)",
                    "7: Install from arbitrary URL, or package name looks suspicious/typosquatted",
                ),
            )

        # Inline / dynamic code execution → LLM (evaluate the code content)
        # Floor at 2 (not 0) so profile-aware fallback is never dangerously low.
        # LLM can still score below 2 per "unless clearly warranted" clause.
        if _SHELL_INLINE_EXEC.match(command):
            return RiskPrompt(
                context=f"Inline code execution: {safe_cmd}",
                range=(2, 7),
                factors=(
                    "2: Read-only (print, stat, list, path check, datetime, type check)",
                    "3: Local file write or modification",
                    "5: Network request, package operation, or external side-effect",
                    "7: System modification, destructive operation, or eval/exec of dynamic input",
                ),
            )

        # PowerShell cmdlet (Get-*/Test-*/Select-*/...) → LLM for path-aware scoring.
        # Get-Content ~/.ssh/id_rsa differs from Get-Content README.md.
        # Skip if command contains unquoted pipe — `Get-X | Stop-X` must go to
        # ambiguous section. Quoted pipes (Select-String "a|b") are fine.
        if _SHELL_PS_READ.match(command) and not _has_unquoted_compound(command):
            return RiskPrompt(
                context=f"PowerShell cmdlet: {safe_cmd}",
                range=(0, 3),
                factors=(
                    "0: Read workspace file, list workspace dir, get date/version",
                    "1: Read user config (~/.gitconfig, ~/.bashrc)",
                    "2: Read system path (/etc, C:\\Windows) or list sensitive dir",
                    "3: Read credential/secret file (~/.ssh/*, .env, *token*)",
                ),
            )

        # PowerShell parenthesized expressions — may hide side effects after a
        # read cmdlet, e.g. (Get-Item ...).Delete(), so route to LLM.
        if _SHELL_PS_EXPR_READ.match(command):
            return RiskPrompt(
                context=f"PowerShell expression: {safe_cmd}",
                range=(0, 7),
                factors=(
                    "0: Simple property access or read-only inspection",
                    "3: Local file modification or rename",
                    "5: External side effect or command invocation",
                    "7: Destructive method (.Delete(), Remove-Item) or system modification",
                ),
            )

        # GitHub CLI read → 1
        if _SHELL_GH_READ.match(command):
            return RiskScore(1, reason=f"GitHub CLI read: {safe_cmd}")

        # gh repo clone → 4 (consistent with git clone)
        if _SHELL_GH_CLONE.match(command):
            return RiskScore(4, reason=f"GitHub CLI clone: {safe_cmd}")

        # GitHub CLI write → 5
        if _SHELL_GH_WRITE.match(command):
            return RiskScore(5, reason=f"GitHub CLI write: {safe_cmd}")

        # Arbitrary code execution → LLM (4~8)
        if _SHELL_EXEC_ARBITRARY.match(command):
            return RiskPrompt(
                context=f"Shell command: {safe_cmd}",
                range=(4, 8),
                signals=("arbitrary code execution",),
                factors=(
                    "4: Run well-known project entry point (dotnet run, npx tsc)",
                    "5: Run local project script with known purpose",
                    "6: Run third-party package directly (npx unknown-tool)",
                    "7: Run with elevated access or network-facing flags",
                    "8: Run untrusted code, or --dangerously/--no-verify flags",
                ),
            )

        # Publish / DB migration → LLM (5~8)
        if _SHELL_PUBLISH.match(command):
            return RiskPrompt(
                context=f"Shell command: {safe_cmd}",
                range=(5, 8),
                signals=("publish", "deploy", "migrate"),
                factors=(
                    "5: Publish to private/internal registry or dry-run",
                    "6: Publish to public registry (npm, NuGet) with scope/org",
                    "7: DB migration on dev/staging, or publish without scope",
                    "8: DB migration on production, or publish overwriting existing version",
                ),
            )

        # ── Delete commands — classified by target ────────────────────────
        if _SHELL_CLEANUP.match(command):
            return RiskScore(4, reason=f"Cleanup build artifacts / temp files: {safe_cmd}")
        if _SHELL_RM_RF.match(command):
            return RiskScore(7, reason=f"Recursive force delete: {safe_cmd}")
        if _SHELL_RM.match(command):
            return RiskScore(5, reason=f"Delete file/directory: {safe_cmd}")

        # ── Ambiguous — collect hints, compute range, then build factors ──
        hints: list[str] = []
        lo, hi = 3, 6
        if _SHELL_NETWORK.search(command):
            hints.append("network")
            lo, hi = max(lo, 4), max(hi, 7)
        if _SHELL_DELETE.search(command):
            hints.append("delete")
            lo, hi = max(lo, 4), max(hi, 7)
        if _SHELL_ELEVATED.search(command):
            hints.append("elevated")
            lo, hi = max(lo, 6), max(hi, 9)
        # Note: system-redirect is caught by the early pre-check above
        # and never reaches this ambiguous section.

        # Use "Lower/Higher" labels — numeric prefixes would be misleading
        # when multiple hints shift lo/hi (e.g. delete+elevated → lo=6 but
        # "6: Delete temp file" doesn't make sense).
        factors: list[str] = []
        if "network" in hints:
            factors.append("Lower: read-only GET/fetch, downloading docs/data")
            factors.append("Higher: POST/PUT to API, uploading data, internal services")
        if "delete" in hints:
            factors.append("Lower: delete single temp file, git-restorable workspace file")
            factors.append("Higher: delete directory tree, non-recoverable files, system paths")
        if "elevated" in hints:
            factors.append("Lower: install system package (apt/brew) for dev tooling")
            factors.append("Higher: modify system config, change permissions, manage services")

        return RiskPrompt(
            context=f"Shell command: {safe_cmd}",
            range=(lo, hi),
            signals=tuple(hints),
            factors=tuple(factors),
        )

    @property
    def name(self) -> str:
        return "shell"

    @property
    def description(self) -> str:
        return "Execute a shell command."

    @property
    def parameters(self) -> dict[str, Any]:
        default_shell = "cmd" if _IS_WINDOWS else "bash"
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The command to execute.",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds. 0 = background (return immediately). Default: 600.",
                },
                "directory": {
                    "type": "string",
                    "description": "Working directory (relative to workspace). Default: workspace root.",
                },
                "shell": {
                    "type": "string",
                    "description": f"Shell to use: auto (default, OS default = {default_shell}), bash, cmd, powershell, or a path.",
                },
            },
            "required": ["command"],
        }

    async def execute(self, **kwargs: Any) -> str:
        command: str = kwargs["command"]
        max_timeout = self.metadata.timeout  # 600s from ToolMetadata
        raw_timeout = kwargs.get("timeout")
        background = raw_timeout == 0
        timeout: float | None = (
            None
            if raw_timeout is None
            else (None if background else min(max(int(raw_timeout), 1), max_timeout))
        )
        if timeout is None and not background:
            timeout = max_timeout
        directory: str = kwargs.get("directory", "")
        shell_mode: str = kwargs.get("shell", "auto")

        # Security check
        try:
            self._sandbox.check_command(command)
        except CommandDeniedError as exc:
            return f"BLOCKED: {exc}"

        # Resolve working directory
        if directory:
            try:
                cwd = self._sandbox.resolve_path(directory)
            except PathDeniedError as exc:
                return f"BLOCKED: {exc}"
            if not cwd.is_dir():
                return f"Error: directory '{directory}' does not exist"
        else:
            cwd = self._sandbox.workspace

        # Resolve shell executable
        shell_exe, shell_args = _resolve_shell(shell_mode)

        try:
            if shell_exe:
                proc = await asyncio.create_subprocess_exec(
                    shell_exe,
                    *shell_args,
                    command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(cwd),
                    env={**os.environ},
                )
            else:
                proc = await asyncio.create_subprocess_shell(
                    command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(cwd),
                    env={**os.environ},
                )

            # Background mode: return immediately with PID
            if background:
                # Clean up finished background processes
                self._background = {
                    pid: p for pid, p in self._background.items() if p.returncode is None
                }
                if len(self._background) >= self._MAX_BACKGROUND:
                    return (
                        f"Error: max {self._MAX_BACKGROUND} background processes. "
                        f"Running: {', '.join(str(p) for p in self._background.keys())}"
                    )
                pid = proc.pid
                self._background[pid] = proc
                stop_cmd = f"taskkill /F /T /PID {pid}" if _IS_WINDOWS else f"kill {pid}"
                return (
                    f"Background process started: PID {pid}\n"
                    f"Command: {command}\n"
                    f"Use shell(command='{stop_cmd}') to stop."
                )

            # Stream stdout line-by-line when progress callback is available
            if self._progress and proc.stdout:
                stdout_lines: list[str] = []
                try:

                    async def _read_stdout() -> None:
                        assert proc.stdout is not None
                        while True:
                            line = await proc.stdout.readline()
                            if not line:
                                break
                            decoded = line.decode("utf-8", errors="replace")
                            stdout_lines.append(decoded)
                            if self._progress:
                                await self._progress(decoded)

                    async def _read_stderr() -> bytes:
                        assert proc.stderr is not None
                        return await proc.stderr.read()

                    stderr_bytes, _ = await asyncio.wait_for(
                        asyncio.gather(_read_stderr(), _read_stdout()),
                        timeout=timeout,
                    )
                except TimeoutError:
                    await _kill_proc_tree(proc)
                    return f"Command timed out after {timeout}s"

                await proc.wait()
                stdout_text = "".join(stdout_lines)
                stderr_text = stderr_bytes.decode("utf-8", errors="replace") if stderr_bytes else ""
            else:
                # Non-streaming path
                try:
                    stdout_raw, stderr_raw = await asyncio.wait_for(
                        proc.communicate(),
                        timeout=timeout,
                    )
                except TimeoutError:
                    await _kill_proc_tree(proc)
                    return f"Command timed out after {timeout}s"
                stdout_text = stdout_raw.decode("utf-8", errors="replace") if stdout_raw else ""
                stderr_text = stderr_raw.decode("utf-8", errors="replace") if stderr_raw else ""

            output_parts: list[str] = []
            if stdout_text:
                output_parts.append(stdout_text)
            if stderr_text:
                output_parts.append(stderr_text)

            output = "\n".join(output_parts).strip() or "(no output)"

            if proc.returncode != 0:
                output = f"Exit code {proc.returncode}\n{output}"

            return output

        except Exception as exc:
            return f"Shell error: {exc}"
