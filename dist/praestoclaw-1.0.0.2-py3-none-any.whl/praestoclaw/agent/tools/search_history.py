"""
Search History tool — query past conversations, decisions, and knowledge
via HistoryStore FTS5 search.

Read-only, no side effects. Core tier (always in function schema).
"""

from __future__ import annotations

import re
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.risk import RiskAssessment, RiskScore

if TYPE_CHECKING:
    from praestoclaw.agent.memory import AgentMemory


class SearchHistoryTool(Tool):
    """Search past conversations and knowledge for relevant context."""

    risk_range = (0, 0)

    def __init__(self, memory: AgentMemory) -> None:
        self._memory = memory

    @property
    def name(self) -> str:
        return "search_history"

    @property
    def description(self) -> str:
        return (
            "Search past conversation history. "
            "Returns timestamped entries with what was done and why."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(
            timeout=30,
            tier="core",
        )

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="Read-only history search")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search terms: entity names, ticket IDs (ICM#, PR#), file paths, emails, keywords. Empty string with after/before = list all in date range.",
                },
                "top_k": {
                    "type": "integer",
                    "description": "Max results (default 5, max 50)",
                },
                "detail": {
                    "type": "boolean",
                    "description": "Full entries with tools/files/session (default false)",
                },
                "after": {
                    "type": "string",
                    "description": "Date filter: YYYY-MM-DD or Nd (e.g. 7d = last 7 days)",
                },
                "before": {
                    "type": "string",
                    "description": "Date filter: YYYY-MM-DD",
                },
                "mode": {
                    "type": "string",
                    "enum": ["AND", "OR", "EXACT"],
                    "description": "AND=all terms match (default), OR=any term, EXACT=phrase match",
                },
            },
            "required": [],
        }

    @staticmethod
    def _parse_date(value: str) -> str | None:
        """Parse date string to ISO format. Supports YYYY-MM-DD or Nd (relative)."""
        if not value:
            return None
        # Relative: "7d", "30d"
        m = re.match(r"^(\d+)d$", value.strip())
        if m:
            days = int(m.group(1))
            dt = datetime.now(UTC) - timedelta(days=days)
            return dt.strftime("%Y-%m-%d")
        # Absolute: YYYY-MM-DD
        if re.match(r"^\d{4}-\d{2}-\d{2}$", value.strip()):
            return value.strip()
        return None

    _CJK_RE = re.compile(r"[\u4e00-\u9fff\u3400-\u4dbf]+")

    @staticmethod
    def _extract_cjk_bigrams(text: str) -> list[str]:
        """Extract 2-char bigrams from CJK runs in text."""
        cjk_runs = re.findall(r"[\u4e00-\u9fff\u3400-\u4dbf]+", text)
        bigrams: list[str] = []
        for run in cjk_runs:
            for i in range(len(run) - 1):
                bigrams.append(run[i : i + 2])
        return bigrams

    @staticmethod
    def _escape_fts(term: str) -> str:
        """Escape a term for safe use inside FTS5 double-quoted strings."""
        return term.replace('"', '""')

    @classmethod
    def _build_fts_query(cls, query: str, mode: str) -> str:
        """Build FTS5 query string based on search mode."""
        terms = query.split()
        if not terms:
            return ""
        if mode in ("EXACT", "phrase"):
            return f'fts5:"{cls._escape_fts(query)}"'
        if mode in ("OR", "broad"):
            return "fts5:" + " OR ".join(f'"{cls._escape_fts(t)}"' for t in terms)
        # AND (default)
        return "fts5:" + " AND ".join(f'"{cls._escape_fts(t)}"' for t in terms)

    async def execute(self, **kwargs: Any) -> str:
        query: str = kwargs.get("query", "")
        top_k: int = kwargs.get("top_k", 5)
        detail: bool = kwargs.get("detail", False)
        after: str = kwargs.get("after", "")
        before: str = kwargs.get("before", "")
        mode: str = kwargs.get("mode", "AND")

        # Clamp top_k to a safe range
        top_k = max(1, min(top_k, 50))
        fetch_k = top_k * 3 if (after or before) else top_k * 2

        if not query.strip():
            if not (after or before):
                return "Error: provide query terms or a date range (after/before)."
            # Date-only query: list recent entries, post-filter by date
            results = self._memory.history.list_recent(top_k=fetch_k)
        else:
            # Try FTS5 first, fall back to SQL LIKE for CJK
            fts_query = self._build_fts_query(query, mode)
            results = self._memory.history.search(fts_query, top_k=fetch_k) if fts_query else []

            if not results and self._CJK_RE.search(query):
                cjk_terms = self._extract_cjk_bigrams(query)[:20]
                if cjk_terms:
                    results = self._memory.history.search_like(cjk_terms, top_k=fetch_k)

        if not results:
            return f"No results for '{query or 'date range'}'. Try broader terms or mode='OR'."

        # Apply temporal decay only for keyword searches (FTS5 results have rank)
        # Date-only queries are already sorted by recency from list_recent()
        if query.strip():
            from praestoclaw.agent.memory import apply_temporal_decay

            results = apply_temporal_decay(results)

        # Post-filter by date range
        after_date = self._parse_date(after) if after else None
        before_date = self._parse_date(before) if before else None

        filtered = []
        for r in results:
            created = r.get("created_at", "")[:10]
            if after_date and created < after_date:
                continue
            if before_date and created > before_date:
                continue
            filtered.append(r)
            if len(filtered) >= top_k:
                break

        if not filtered:
            return f"No results for '{query}' with the given filters."

        lines: list[str] = []
        for i, r in enumerate(filtered, 1):
            created = r.get("created_at", "")[:10]
            content = r.get("content", "")
            score = r.get("decayed_score")
            score_str = f", score={score:.2f}" if score is not None else ""
            if detail:
                lines.append(f"[{i}] ({created}{score_str})\n{content}")
            else:
                preview = content[:200].replace("\n", " ")
                lines.append(f"[{i}] ({created}{score_str}) {preview}")

        return "\n\n".join(lines)
