"""A2A tool — async fire-and-forget messaging with other AI agents.

Two actions only:

* ``send`` — push a text envelope through ``A2ARuntime.send_async`` and return
  immediately with a ``message_id``. The remote agent's ack and reply arrive
  later as injected ``InboundMessage`` system notifications (``metadata.source
  == "a2a_notify"``). The LLM **must not** poll — it should just stop and wait
  for the notification turn.
* ``discover`` — fetch the remote agent's card via the gateway HTTP endpoint.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.risk import RiskAssessment, RiskScore

if TYPE_CHECKING:
    from praestoclaw.a2a.runtime import A2ARuntime


class A2ATool(Tool):
    """Async agent-to-agent messaging via the A2A protocol."""

    risk_range = (2, 5)

    def __init__(self, a2a_runtime: A2ARuntime) -> None:
        self._runtime = a2a_runtime

    # ── Tool ABC ────────────────────────────────────────────────────────

    @property
    def name(self) -> str:
        return "a2a"

    @property
    def description(self) -> str:
        return (
            "通过 A2A 协议与其他 AI agent 通信。这是异步 fire-and-forget 模式："
            "调用 send 后会立即返回 dispatched，对方的 ack 和回复会作为单独的"
            "系统通知到达，**不要轮询**。Actions: send (向目标发消息), "
            "discover (查询目标 agent 的 card)。"
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=30, tier="standard", category="builtin")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["send", "discover"],
                    "description": (
                        "'send': fire-and-forget a text message to a remote agent — "
                        "you'll receive the ack and reply later as system notifications. "
                        "'discover': fetch a remote agent's card."
                    ),
                },
                "target": {
                    "type": "string",
                    "description": (
                        "Target agent's user_id (typically email-shaped, e.g. "
                        "'bob@contoso.com'). Required for both actions."
                    ),
                },
                "message": {
                    "type": "string",
                    "description": "Message content. Required for 'send'.",
                },
            },
            "required": ["action", "target"],
        }

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        action = args.get("action", "")
        if action == "discover":
            return RiskScore(2, reason="Read-only A2A discover")
        if action == "send":
            return RiskScore(4, reason="Sending message to remote agent")
        return RiskScore(4, reason=f"Unknown A2A action: {action}")

    async def execute(self, **kwargs: Any) -> str:
        action: str = kwargs.get("action", "")
        target: str = (kwargs.get("target") or "").strip()

        if not target:
            return "Error: 'target' parameter is required."

        try:
            if action == "discover":
                return await self._discover(target)
            if action == "send":
                return await self._send(target, kwargs)
            return f"Error: unknown action '{action}'. Use 'send' or 'discover'."
        except Exception as exc:
            return f"Error: A2A {action} failed — {exc}"

    # ── Action handlers ─────────────────────────────────────────────────

    async def _discover(self, target: str) -> str:
        card = await self._runtime.get_agent_card(target)
        if card.get("error"):
            status = card.get("status", "")
            detail = card.get("detail", "")
            if "404" in str(status) or "404" in str(detail):
                return (
                    f"Agent '{target}' not found. The target user's PraestoClaw instance "
                    f"may not be connected to the gateway, or the user_id doesn't match. "
                    f"Ensure they have A2A enabled and are connected."
                )
            return f"Error discovering agent '{target}': {detail or status or 'unknown'}"
        name = card.get("name", target)
        desc = card.get("description", "No description")
        skills = card.get("skills", [])
        lines = [f"Agent: {name}", f"Description: {desc}"]
        if skills:
            lines.append("Skills:")
            for skill in skills:
                skill_name = skill.get("name", "unknown") if isinstance(skill, dict) else str(skill)
                lines.append(f"  - {skill_name}")
        return "\n".join(lines)

    async def _send(self, target: str, kwargs: dict[str, Any]) -> str:
        message: str | None = kwargs.get("message")
        if not message:
            return "Error: 'message' parameter is required for 'send'."

        # Channel context is injected by the tool registry from the active
        # conversation. Without it, we can't route the eventual ack/reply
        # notification back to the user — so refuse early.
        channel = kwargs.get("_channel", "")
        channel_id = kwargs.get("_channel_id", "")
        session_id = kwargs.get("_session_id", "") or kwargs.get("_session_key", "")

        if not channel or not channel_id:
            return (
                "Error: a2a send requires a user-originating channel context "
                "(this tool isn't usable from background/cron jobs)."
            )

        result = await self._runtime.send_async(
            target,
            message,
            channel=channel,
            channel_id=channel_id,
            session_id=session_id,
        )

        if result.get("ok"):
            mid = result.get("message_id", "")
            return (
                f"已发出 a2a 消息 (message_id={mid})。"
                f"对方上线后会收到，ack 和回复会作为系统通知到达，"
                f"无需轮询，请等待通知。"
            )

        code = result.get("error_code", "unknown")
        msg = result.get("error_message", "")
        return f"a2a send 失败：{code} — {msg}"
