"""
AgentLoop — the core agentic execution engine.

Implements: LLM call → tool calls → LLM call → ... → final response.

Inspired by HKUDS/nanobot's loop.py but enterprise-hardened with:
- Audit logging on every tool call
- Sandbox enforcement
- Memory consolidation
- RBAC-aware tool filtering
- Prompt injection detection
- Topic-aware context compaction
"""

from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from loguru import logger

from praestoclaw.agent.compaction import (
    clear_old_tool_results,
    compact_fallback,
    compact_messages,
    detect_topic_switch,
    estimate_tokens,
    should_post_compact,
    should_pre_compact,
)
from praestoclaw.agent.consolidation import Consolidator
from praestoclaw.agent.context import ContextBuilder
from praestoclaw.agent.loop_detect import LoopDetector
from praestoclaw.agent.memory import AgentMemory
from praestoclaw.agent.reminders import ReminderTracker
from praestoclaw.agent.tools.registry import ToolRegistry
from praestoclaw.agent.truncation import truncate_tool_output
from praestoclaw.bus.events import EventType, InboundMessage, OutboundMessage, StreamingChunk
from praestoclaw.bus.queue import MessageBus
from praestoclaw.config.schema import AgentConfig, ChannelType, SkillsConfig
from praestoclaw.hooks.manager import (
    HookManager,
    HookVerdict,
    MessageHookContext,
    PostToolHookContext,
    PreToolHookContext,
)
from praestoclaw.providers.base import LLMProvider, LLMResponse
from praestoclaw.providers.resolver import resolve_model_chain
from praestoclaw.security.audit import AuditLogger
from praestoclaw.security.leak import redact_credentials
from praestoclaw.security.sanitizer import Sanitizer
from praestoclaw.session.manager import SessionManager

if TYPE_CHECKING:
    from praestoclaw.security.allowlist import AllowlistManager
    from praestoclaw.security.approval import ApprovalManager
    from praestoclaw.skills.loader import SkillLoader


# Known error patterns indicating context-length-exceeded
_TOKEN_LIMIT_PATTERNS = (
    "context_length_exceeded",
    "maximum context length",
    "too many tokens",
    "context window",
    "token limit",
    "prompt token count",
    "max_prompt_tokens_exceeded",
)


class AgentLoop:
    """
    Main agent loop. Consumes inbound messages from the bus,
    runs the LLM+tool loop, publishes outbound responses.
    """

    def __init__(
        self,
        *,
        config: AgentConfig,
        provider: LLMProvider,
        tool_registry: ToolRegistry,
        bus: MessageBus,
        session_manager: SessionManager,
        audit: AuditLogger,
        workspace: Path,
        hooks: HookManager | None = None,
        available_agents: dict | None = None,
        prompt_mode: Literal["full", "minimal"] = "full",
        skills: list | None = None,
        skill_loader: SkillLoader | None = None,
        skills_config: SkillsConfig | None = None,
        approval_manager: ApprovalManager | None = None,
        allowlist: AllowlistManager | None = None,
        mcp_configs: dict | None = None,
        memory: AgentMemory | None = None,
    ) -> None:
        self._config = config
        self._provider = provider
        self._tools = tool_registry
        self._bus = bus
        self._sessions = session_manager
        self._audit = audit
        self._workspace = workspace
        self._prompt_mode = prompt_mode
        self._skill_loader = skill_loader
        self._skills_config = skills_config or SkillsConfig()
        self._memory = memory or AgentMemory()
        self._context = ContextBuilder(
            config,
            workspace,
            available_agents=available_agents,
            tool_registry=tool_registry,
            mcp_configs=mcp_configs,
            memory=self._memory,
            skill_loader=skill_loader,
            skills_config=self._skills_config,
        )
        # Backward compat: also set _skills if passed directly
        if skills and not skill_loader:
            self._context.set_skills(skills)
        self._hooks = hooks
        self._approval_manager = approval_manager
        self._allowlist = allowlist
        self._running = False
        self._consolidator = Consolidator(
            provider=self._provider,
            memory=self._memory,
            sessions=self._sessions,
            config=self._config,
            input_limit_fn=self._resolve_input_limit,
        )

    async def start(self) -> None:
        """Start consuming messages from the bus."""
        self._running = True
        logger.info(f"Agent loop started (model={self._config.model})")
        while self._running:
            try:
                msg = await asyncio.wait_for(self._bus.get_inbound(), timeout=1.0)
                await self._process_message(msg)
            except TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.error(f"Agent loop error: {exc}")

    async def stop(self) -> None:
        self._running = False

    def _ensure_smart_loaded(self, session_id: str) -> None:
        """On first access, use budget-aware smart tail loading."""
        if not self._sessions.is_loaded(session_id):
            context_limit = self._resolve_input_limit()
            reserved = self._context.estimate_system_prompt_tokens(mode=self._prompt_mode)
            reserved += 2000  # headroom for current user message + runtime context
            self._sessions.smart_load_session(
                session_id,
                context_limit=context_limit,
                reserved_tokens=reserved,
            )

    async def run_once(
        self,
        prompt: str,
        session_id: str | None = None,
        *,
        channel: ChannelType | None = None,
        channel_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        exclude_tools: list[str] | None = None,
    ) -> str:
        """Run a single prompt through the agent (for CLI/API use)."""
        sid = session_id or self._sessions.get_or_create_id(ChannelType.CLI, "local")
        logger.info(f"run_once: channel={channel or 'cli'} session={sid}")
        self._ensure_smart_loaded(sid)
        history = self._sessions.get_messages(sid, llm_only=True)
        response, _streamed = await self._agent_loop(
            prompt,
            history,
            sid,
            channel=channel,
            channel_id=channel_id,
            metadata=metadata,
            exclude_tools=exclude_tools,
        )
        return response

    # ── Typing indicators ───────────────────────────────────────────────

    def _start_typing(
        self,
        channel: ChannelType | None,
        channel_id: str | None,
        metadata: dict | None = None,
    ) -> asyncio.Task | None:
        """Start a periodic typing indicator task. Returns the task (or None for CLI)."""
        if not channel or not channel_id or channel == ChannelType.CLI:
            return None

        payload = {"channel": channel, "channel_id": channel_id, "metadata": metadata or {}}

        # Emit immediately so the first indicator fires without waiting 3s
        self._bus.events.emit(EventType.TYPING_STARTED, payload)

        async def _typing_loop() -> None:
            try:
                while True:
                    await asyncio.sleep(3.0)
                    self._bus.events.emit(EventType.TYPING_STARTED, payload)
            except asyncio.CancelledError:
                pass

        task = asyncio.create_task(_typing_loop(), name="typing-indicator")
        return task

    def _stop_typing(
        self,
        task: asyncio.Task | None,
        channel: ChannelType | None = None,
        channel_id: str | None = None,
    ) -> None:
        """Cancel the typing indicator task and emit TYPING_STOPPED."""
        if task and not task.done():
            task.cancel()
        if channel and channel_id and channel != ChannelType.CLI:
            self._bus.events.emit(
                EventType.TYPING_STOPPED,
                {"channel": channel, "channel_id": channel_id},
            )

    # ── Slash commands ────────────────────────────────────────────────────

    async def _handle_slash(self, cmd: str, session_id: str, msg: InboundMessage) -> str | None:
        """Handle REPL slash commands. Returns reply string or None if not a known command."""

        parts = cmd.split(maxsplit=1)
        verb = parts[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ""

        if verb == "/new":
            # Consolidate before clearing so no knowledge is lost
            try:
                await self._consolidator.maybe_consolidate(session_id, force=True)
            except Exception as exc:
                logger.warning("Pre-clear consolidation failed: {}", exc)
            self._sessions.clear(session_id)
            return "Session cleared. Starting fresh."

        if verb == "/compact":
            # Manual compaction trigger
            history = self._sessions.get_messages(session_id, llm_only=True)
            if len(history) < 10:
                return "Not enough messages to compact."
            try:
                # Build system prompt + history only (no user message —
                # /compact is not a turn, just a maintenance operation)
                system_prompt = self._context.build_system_prompt(mode=self._prompt_mode)
                messages: list[dict[str, Any]] = []
                if system_prompt:
                    messages.append({"role": "system", "content": system_prompt})
                messages.extend(history)
                context_limit = self._resolve_input_limit()
                tokens_before = estimate_tokens(messages)
                compacted = await compact_messages(
                    messages,
                    self._provider,
                    self._config,
                    context_limit=context_limit,
                    focus=arg,
                )
                # Replace in-memory session with compacted messages, keeping
                # the compaction summary but stripping the original system prompt
                # (which is rebuilt each turn by build_messages()).
                kept = [
                    m
                    for m in compacted
                    if m.get("role") != "system"
                    or "[Conversation summary" in (m.get("content") or "")
                ]
                self._sessions.replace_messages(session_id, kept)
                tokens_after = estimate_tokens(kept)
                self._append_compaction_audit(
                    session_id,
                    trigger="manual_compact",
                    tokens_before=tokens_before,
                    tokens_after=tokens_after,
                    messages_total=len(kept),
                    action="llm_summary",
                    consolidation_triggered=True,
                )
                asyncio.create_task(self._consolidator.maybe_consolidate(session_id))
                saved = tokens_before - tokens_after
                return f"Compacted {len(history)} messages to {len(kept)}. Saved ~{saved} tokens."
            except Exception as exc:
                logger.error("Manual compaction failed: {}", exc)
                return f"Compaction failed: {exc}"

        if verb == "/exit":
            return "Use Ctrl+C to exit the REPL."

        if verb == "/help":
            is_cli = not msg.channel or msg.channel == ChannelType.CLI
            rows = [
                "| `/new` | Clear session, start fresh |",
                "| `/compact [focus]` | Manually trigger context compaction |",
            ]
            rows += [
                "| `/status` | Show agent status |",
                "| `/memory` | Show MEMORY.md content |",
                "| `/tools` | List available tools |",
                "| `/skills` | List available skills |",
                "| `/history [N]` | Show last N messages (default 10) |",
                "| `/model [name]` | Show or switch LLM model |",
                "| `/estop [reason]` | Emergency stop — halt all agent activity |",
            ]
            if is_cli:
                rows.append("| `/exit` | Exit hint |")
            return (
                "**Available commands:**\n\n"
                "| Command | Description |\n|---------|-------------|\n" + "\n".join(rows) + "\n"
            )

        if verb == "/status":
            msgs = self._sessions.get_messages(session_id)
            return (
                f"**Agent:** {self._config.name}  \n"
                f"**Model:** {self._config.model}  \n"
                f"**Session:** {session_id}  \n"
                f"**Messages:** {len(msgs)}  \n"
                f"**Max iterations:** {self._config.max_iterations}"
            )

        if verb == "/memory":
            content = self._memory.read_memory()
            return content if content.strip() else "_MEMORY.md is empty._"

        if verb == "/tools":
            tools = self._tools.list_tools()
            lines = ["**Available tools:**"]
            for t in tools:
                lines.append(f"- `{t.name}` — {t.description[:60]}")
            return "\n".join(lines)

        if verb == "/skills":
            try:
                if self._skill_loader:
                    skills = self._skill_loader.load_all()
                else:
                    skills = getattr(self._context, "_skills", None) or []
                if not skills:
                    return "_No skills loaded._"
                lines = ["**Loaded skills:**"]
                for s in skills:
                    mode_tag = f" [{s.mode}]" if hasattr(s, "mode") else ""
                    lines.append(f"- `{s.name}`{mode_tag} — {getattr(s, 'description', '')[:60]}")
                return "\n".join(lines)
            except Exception:
                return "_Skills unavailable._"

        if verb == "/history":
            n = int(arg) if arg.isdigit() else 10
            msgs = self._sessions.get_messages(session_id)
            recent = msgs[-n:]
            if not recent:
                return "_No messages in history._"
            lines = []
            for m in recent:
                role = m.get("role", "?")
                content = m.get("content") or ""
                if isinstance(content, list):
                    content = " ".join(p.get("text", "") for p in content if isinstance(p, dict))
                snippet = str(content)[:120].replace("\n", " ")
                lines.append(f"**{role}:** {snippet}")
            return "\n".join(lines)

        if verb == "/model":
            if not arg:
                return f"Current model: `{self._config.model}`"
            new_model = arg.strip()
            # Validate aliases eagerly; concrete IDs (e.g. github/gpt-5.4) pass
            # through — they can only be validated at call time.
            chain = resolve_model_chain(new_model, getattr(self._provider, "_providers", None))
            if not chain:
                return (
                    f"Cannot switch to `{new_model}`: no provider credentials "
                    f"configured for this alias. Configure provider credentials "
                    f"(e.g. GITHUB_TOKEN, OPENAI_API_KEY, AZURE_OPENAI_API_KEY) "
                    f"or use a concrete model ID."
                )
            old_model = self._config.model
            self._config.model = new_model
            logger.info("Model switched: {} -> {}", old_model, new_model)
            resolved = chain[0] if chain[0] != new_model else None
            suffix = f" (resolves to `{resolved}`)" if resolved else ""
            reply = f"Model switched: `{old_model}` \u2192 `{new_model}`{suffix}"

            # Warn if history has tool calls from the old model — cross-model
            # call IDs can cause Responses API errors on the next message.
            history = self._sessions.get_messages(session_id)
            has_tool_history = any(
                m.get("role") == "tool" or (m.get("role") == "assistant" and m.get("tool_calls"))
                for m in history
            )
            if has_tool_history:
                reply += (
                    "\n\n\u26a0 History contains tool calls from the previous model."
                    " Run `/new` to clear history and avoid cross-model errors."
                )
            return reply

        if verb == "/estop":
            from praestoclaw.bus.events import EventType

            reason = arg or "Manual E-stop via slash command"
            self._bus.events.emit(
                EventType.SECURITY_ESTOP,
                {"reason": reason, "actor": f"user:{msg.sender_id or 'unknown'}"},
            )
            return "**E-STOP ACTIVATED.** All agent activity halted. Run `pc security reset` to resume."

        # Unknown slash command — don't intercept, let it go to the agent
        return None

    # ── Context limit resolution ──────────────────────────────────────────

    def _resolve_input_limit(self) -> int:
        """Resolve the effective input token limit from config or model catalog.

        Returns the max input tokens (prompt ceiling), not the total context
        window.  All compaction and overflow checks use this value.
        """
        context_limit = self._config.context_limit
        if context_limit is None:
            from praestoclaw.providers.model_catalog import get_max_input_tokens

            chain = resolve_model_chain(
                self._config.model, getattr(self._provider, "_providers", None)
            )
            resolved = chain[0] if chain else self._config.model
            context_limit = get_max_input_tokens(resolved)
        return context_limit

    # ── Internal ─────────────────────────────────────────────────────────

    async def _process_message(self, msg: InboundMessage) -> None:
        """Process a single inbound message through the agent loop."""
        # Normalize channel at the boundary — InboundMessage accepts str for
        # external callers, but all internal code uses ChannelType.
        msg.channel = ChannelType.of(msg.channel)  # type: ignore[assignment]
        session_id = (
            msg.session_key
            or msg.session_id
            or self._sessions.get_or_create_id(msg.channel, msg.sender_id)
        )

        logger.info(
            f"Inbound: channel={msg.channel} channel_id={msg.channel_id} session={session_id}"
        )
        self._audit.log_message(
            channel=msg.channel,
            direction="inbound",
            actor=msg.sender_id,
            session_id=session_id,
        )

        # Check for approval response commands
        if await self._try_route_approval(msg):
            return

        # Check for slash commands
        cmd = msg.content.strip()
        if cmd.startswith("/"):
            reply = await self._handle_slash(cmd, session_id, msg)
            if reply is not None:
                await self._bus.publish_outbound(
                    OutboundMessage(
                        channel=msg.channel,
                        channel_id=msg.channel_id,
                        content=reply,
                        thread_id=msg.thread_id,
                    )
                )
                return

        # ── Hook: on_message_received ────────────────────────────────
        if self._hooks:
            hook_ctx = MessageHookContext(
                content=msg.content,
                channel=msg.channel,
                sender_id=msg.sender_id,
                session_id=session_id,
            )
            result = await self._hooks.dispatch_checked("on_message_received", hook_ctx)
            if result.verdict == HookVerdict.REJECT:
                logger.warning("Message rejected by hook: {}", result.reason)
                await self._bus.publish_outbound(
                    OutboundMessage(
                        channel=msg.channel,
                        channel_id=msg.channel_id,
                        content=f"Message blocked: {result.reason}",
                        thread_id=msg.thread_id,
                    )
                )
                return
        else:
            # Fallback: inline injection check when no hooks configured
            findings = Sanitizer.check_prompt_injection(msg.content)
            if findings:
                self._audit.log_security(
                    event="prompt_injection_detected",
                    details={"findings": findings, "sender": msg.sender_id},
                    severity="warning",
                )
                logger.warning(f"Prompt injection detected from {msg.sender_id}: {findings}")

        # Get history and run agent loop (filter UI-only roles like approval_request)
        self._ensure_smart_loaded(session_id)
        history = self._sessions.get_messages(session_id, llm_only=True)

        # Start typing indicator (Teams/Cloud channels show "typing..." to the user)
        typing_task = self._start_typing(msg.channel, msg.channel_id, metadata=msg.metadata)
        try:
            response, streamed = await self._agent_loop(
                msg.content,
                history,
                session_id,
                channel=msg.channel,
                channel_id=msg.channel_id,
                metadata=msg.metadata,
                thread_id=msg.thread_id,
                typing_task=typing_task,
            )
        except Exception as exc:
            logger.error(f"Agent loop error: {exc}")
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=msg.channel,
                    channel_id=msg.channel_id,
                    content=f"Error: {exc}",
                    thread_id=msg.thread_id,
                )
            )
            return
        finally:
            # Stop typing indicator when response is ready (or on error)
            self._stop_typing(typing_task, msg.channel, msg.channel_id)

        # ── Hook: on_message_sent ────────────────────────────────────
        # Skip when streamed — _stream_response already ran this hook.
        if self._hooks and not streamed:
            out_ctx = MessageHookContext(
                content=response,
                channel=msg.channel,
                session_id=session_id,
            )
            result = await self._hooks.dispatch_checked("on_message_sent", out_ctx)
            if result.verdict == HookVerdict.REJECT:
                logger.warning("Outbound message blocked by hook: {}", result.reason)
                response = "[Message blocked by security policy]"
            elif result.data and isinstance(result.data, MessageHookContext):
                response = result.data.content

        # Skip the full OutboundMessage when content was already streamed —
        # channels already received every token via StreamingChunks.
        if not streamed:
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=msg.channel,
                    channel_id=msg.channel_id,
                    content=response,
                    thread_id=msg.thread_id,
                )
            )

        self._audit.log_message(
            channel=msg.channel,
            direction="outbound",
            actor="agent",
            session_id=session_id,
        )

    async def _agent_loop(
        self,
        user_input: str,
        history: list[dict[str, Any]],
        session_id: str,
        *,
        channel: ChannelType | None = None,
        channel_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        thread_id: str | None = None,
        typing_task: asyncio.Task | None = None,
        exclude_tools: list[str] | None = None,
    ) -> tuple[str, bool]:
        """
        Core agentic loop:
        1. Build context (system + history + user message)
        2. Call LLM with tools
        3. If tool calls → execute → append results → loop
        4. If text response → return

        Compaction checks (§2 of compaction.md):
        - [1] Pre-completion: 95% emergency compaction before LLM call
        - [3] Post-completion: 80% topic-aware compaction after LLM response
        - Token-limit error: emergency compact + retry once
        """
        # Auto-match skills to inject into user context
        injected_skills = None
        if self._skill_loader:
            injected_skills = (
                self._skill_loader.match(
                    user_input,
                    threshold=self._skills_config.inject_threshold,
                    max_results=self._skills_config.max_inject,
                )
                or None
            )

        # Build messages
        messages = self._context.build_messages(
            history,
            user_input,
            mode=self._prompt_mode,
            channel=channel,
            channel_id=channel_id,
            injected_skills=injected_skills,
        )

        # Save user message to session (include actually-injected skill names from context builder)
        user_msg_entry: dict[str, Any] = {"role": "user", "content": user_input}
        actually_injected = getattr(self._context, "_last_injected_skill_names", [])
        if actually_injected:
            user_msg_entry["_injected_skills"] = list(actually_injected)
        self._sessions.add_message(session_id, user_msg_entry)

        max_iter = self._config.max_iterations
        iteration = 0
        loop_detector = LoopDetector()
        context_limit = self._resolve_input_limit()

        reminder = ReminderTracker(
            interval=self._config.reminder_interval,
            agent_name=self._config.name,
            user_task=user_input,
            memory=self._memory,
        )

        # Token tracking — updated after each LLM call
        _last_prompt_tokens: int = 0
        _last_completion_tokens: int = 0
        _msgs_at_last_llm_call: int = len(messages)

        while iteration < max_iter:
            iteration += 1
            logger.debug(f"Agent iteration {iteration}/{max_iter}")

            # Refresh tool schemas each iteration (progressive loading may
            # have activated new tools since the last iteration)
            tool_schemas = self._tools.get_schemas(
                self._config.tools or None,
                exclude=exclude_tools,
            )

            # ── [1] Pre-completion check (§2.2): 95% → emergency ─────
            # On first iteration (no prior LLM usage), use heuristic on
            # full messages. Otherwise use actual tokens + new messages delta.
            if _last_prompt_tokens == 0:
                _pre_check = estimate_tokens(messages) / context_limit > 0.95
            else:
                new_msgs_since_last = messages[_msgs_at_last_llm_call:]
                _pre_check = should_pre_compact(
                    _last_prompt_tokens,
                    _last_completion_tokens,
                    new_msgs_since_last,
                    context_limit,
                )
            if _pre_check:
                logger.warning("Pre-completion emergency compaction (>95%)")
                tokens_before = estimate_tokens(messages)
                messages = await self._emergency_compact(
                    messages, session_id, context_limit, reminder
                )
                self._append_compaction_audit(
                    session_id,
                    trigger="pre_completion_emergency",
                    tokens_before=tokens_before,
                    tokens_after=estimate_tokens(messages),
                    messages_total=len(messages),
                )

            # ── Graceful termination: Stage 1 — Nudge ────────────────
            if iteration == max_iter - 2:
                messages.append(
                    {
                        "role": "system",
                        "content": (
                            "You are approaching the iteration limit. "
                            "Please wrap up your current task and provide a final answer soon."
                        ),
                    }
                )

            # ── Graceful termination: Stage 2 — Force text ───────────
            # At iteration max-1, call LLM WITHOUT tools to force a text summary
            tools_for_call = tool_schemas if (tool_schemas and iteration < max_iter - 1) else None

            # When no tools are offered, use streaming for real-time token delivery
            if tools_for_call is None and channel and channel_id:
                # Stop typing indicator before streaming starts — the user
                # will see real tokens arriving instead of "typing…".
                self._stop_typing(typing_task, channel, channel_id)
                typing_task = None  # prevent double-cancel in finally block
                content = await self._stream_response(
                    messages=messages,
                    channel=channel,
                    channel_id=channel_id,
                    session_id=session_id,
                )
                self._sessions.add_message(session_id, {"role": "assistant", "content": content})
                messages.append({"role": "assistant", "content": content})
                # Fire-and-forget: don't block the response
                asyncio.create_task(self._consolidator.maybe_consolidate(session_id))
                return content, True

            # ── [2] LLM Call ─────────────────────────────────────────
            try:
                response: LLMResponse = await self._provider.complete(
                    model=self._config.model,
                    messages=messages,
                    tools=tools_for_call,
                )
            except Exception as exc:
                # ── Token-limit error recovery (§2.3) ────────────────
                if self._is_token_limit_error(exc):
                    logger.warning("Token-limit error, attempting emergency compaction + retry")
                    tokens_before = estimate_tokens(messages)
                    messages = await self._emergency_compact(
                        messages, session_id, context_limit, reminder
                    )
                    self._append_compaction_audit(
                        session_id,
                        trigger="token_limit_error",
                        tokens_before=tokens_before,
                        tokens_after=estimate_tokens(messages),
                        messages_total=len(messages),
                    )
                    # Retry once
                    response = await self._provider.complete(
                        model=self._config.model,
                        messages=messages,
                        tools=tools_for_call,
                    )
                else:
                    raise

            # Track actual token usage from provider
            _last_prompt_tokens = response.prompt_tokens
            _last_completion_tokens = response.completion_tokens
            _msgs_at_last_llm_call = len(messages)

            # No tool calls → done
            if not response.tool_calls:
                content = response.content
                self._sessions.add_message(session_id, {"role": "assistant", "content": content})
                messages.append({"role": "assistant", "content": content})

                # ── [3] Post-completion check (§2.1) ─────────────────
                await self._post_completion_check(
                    messages,
                    session_id,
                    context_limit,
                    reminder,
                    _last_prompt_tokens,
                )

                # Fire-and-forget: don't block the response
                asyncio.create_task(self._consolidator.maybe_consolidate(session_id))

                return content, False

            # Has tool calls → execute them
            # Add assistant message with tool calls
            assistant_msg: dict[str, Any] = {
                "role": "assistant",
                "content": response.content or "",
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.name,
                            "arguments": json.dumps(tc.arguments, ensure_ascii=False)
                            if isinstance(tc.arguments, dict)
                            else tc.arguments,
                        },
                    }
                    for tc in response.tool_calls
                ],
            }
            messages.append(assistant_msg)
            self._sessions.add_message(session_id, assistant_msg)

            # ── IronClaw 3-phase tool execution ─────────────────────
            tool_calls = response.tool_calls

            # Phase 1: Preflight — pre_tool_use hooks (sequential)
            approved: list[tuple[Any, bool]] = []  # (tc, blocked)
            tool_results: dict[str, str] = {}  # tc.id → result or error
            for tc in tool_calls:
                logger.info(f"Tool call: {tc.name}({list(tc.arguments.keys())})")
                blocked = False
                # Block excluded tools even if LLM hallucinates them
                if exclude_tools and tc.name in exclude_tools:
                    blocked = True
                    tool_results[tc.id] = f"Tool '{tc.name}' is not available."
                    approved.append((tc, blocked))
                    continue
                if self._hooks:
                    _tool = self._tools.get(tc.name)
                    # Collect last 3 user messages for risk scorer context
                    _user_msgs: list[str] = []
                    if session_id and self._sessions:
                        try:
                            _all_msgs = self._sessions.get_messages(session_id)
                            _user_msgs = [
                                m["content"]
                                for m in _all_msgs
                                if m.get("role") == "user" and m.get("content")
                            ][-3:]
                        except Exception:
                            _user_msgs = []
                    if not _user_msgs and user_input:
                        _user_msgs = [user_input]
                    # Redact credentials so secrets aren't leaked to the scorer prompt
                    _user_msgs = [redact_credentials(m) for m in _user_msgs]
                    pre_ctx = PreToolHookContext(
                        tool_name=tc.name,
                        args=tc.arguments,
                        agent_name=self._config.name,
                        session_id=session_id,
                        tool_ref=_tool,
                        channel=channel,
                        channel_id=channel_id or "",
                        user_messages=_user_msgs,
                        metadata=metadata or {},
                    )
                    pre_result = await self._hooks.dispatch_checked("pre_tool_use", pre_ctx)
                    if pre_result.verdict == HookVerdict.REJECT:
                        tool_results[tc.id] = (
                            f"Tool '{tc.name}' blocked by security policy: {pre_result.reason}\n"
                            "Do NOT retry this tool. Inform the user it was blocked and suggest alternatives."
                        )
                        logger.warning(f"Tool '{tc.name}' blocked: {pre_result.reason}")
                        blocked = True
                approved.append((tc, blocked))

            # Phase 2: Execute — parallel for independent tools (asyncio.gather)
            # Safety: tools that share state (e.g., browser) are serialized
            # by deduplicating tool names — only one call per tool name runs concurrently.
            _STATEFUL_TOOLS = {"browser"}

            async def _execute_tool(tc: Any) -> str:
                return await self._tools.execute(
                    tc.name,
                    tc.arguments,
                    actor="agent",
                    session_id=session_id,
                    bus=self._bus,
                    channel=channel,
                    channel_id=channel_id,
                    thread_id=thread_id,
                    metadata=metadata,
                )

            runnable = [(tc, blocked) for tc, blocked in approved if not blocked]
            # Split into parallelizable and serializable
            parallel_batch = []
            serial_batch = []
            seen_names: set[str] = set()
            for tc, _ in runnable:
                if tc.name in _STATEFUL_TOOLS or tc.name in seen_names:
                    serial_batch.append(tc)
                else:
                    parallel_batch.append(tc)
                    seen_names.add(tc.name)

            # Run parallel batch
            if parallel_batch:
                tasks = [_execute_tool(tc) for tc in parallel_batch]
                results = await asyncio.gather(*tasks, return_exceptions=True)
                for tc, result in zip(parallel_batch, results):
                    if isinstance(result, Exception):
                        tool_results[tc.id] = f"Error executing {tc.name}: {result}"
                    else:
                        tool_results[tc.id] = str(result)

            # Run serial batch (stateful or duplicate tool names)
            for tc in serial_batch:
                try:
                    tool_results[tc.id] = await _execute_tool(tc)
                except Exception as exc:
                    tool_results[tc.id] = f"Error executing {tc.name}: {exc}"

            # Phase 3: Postflight — hooks see raw output, then redact (sequential)
            for tc, blocked in approved:
                result = tool_results.get(tc.id, "")

                # post_tool_use hook BEFORE redaction (LeakScanner needs raw output)
                if self._hooks and not blocked:
                    post_ctx = PostToolHookContext(
                        tool_name=tc.name,
                        args=tc.arguments,
                        result=result,
                        agent_name=self._config.name,
                        session_id=session_id,
                    )
                    hook_result = await self._hooks.dispatch_checked("post_tool_use", post_ctx)
                    # Apply hook modifications (e.g., Redactor updates ctx.result)
                    if hook_result.data and isinstance(hook_result.data, PostToolHookContext):
                        result = hook_result.data.result

                # Redact secrets AFTER hooks have inspected raw output
                result = Sanitizer.redact_env_values(result)

                # Unified truncation: per-tool metadata > global config default
                # Strategy: LLM compress first, smart_truncate fallback.
                tool_obj = self._tools.get(tc.name)
                tool_max = tool_obj.metadata.max_output_chars if tool_obj else 0
                output_cfg = self._tools.output_config
                result = await truncate_tool_output(
                    content=result,
                    tool_name=tc.name,
                    max_chars=tool_max if tool_max > 0 else output_cfg.max_chars,
                    provider=self._provider,
                    llm_enabled=output_cfg.llm_compression_enabled,
                    tool_args=tc.arguments,
                )

                tool_msg: dict[str, Any] = {
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": result,
                }
                is_error = blocked or result.startswith(("Error", "Failed", "BLOCKED"))
                messages.append(tool_msg)
                # Persist all results; errors marked with is_error flag so
                # get_messages(llm_only=True) skips them (prevents replay loops).
                if is_error:
                    tool_msg["is_error"] = True
                self._sessions.add_message(session_id, tool_msg)

            # ── Loop detection (AFTER all tool messages to preserve ordering) ─
            # OpenAI requires all tool-role messages to immediately follow
            # their assistant message with tool_calls — no system messages
            # may be inserted between them.
            for tc, _blocked in approved:
                warning, should_terminate = loop_detector.check(tc.name, tc.arguments)
                if warning:
                    messages.append({"role": "system", "content": warning})
                    if should_terminate:
                        return (
                            "I detected a repetitive loop and stopped to avoid wasting resources. "
                            f"Pattern: {warning}"
                        ), False

            # ── [3] Post-completion check (§2.1) — runs after tool results too
            await self._post_completion_check(
                messages,
                session_id,
                context_limit,
                reminder,
                _last_prompt_tokens,
            )

            # ── System reminders ──────────────────────────────────────
            # Track tool calls and inject periodic reminder if due
            reminder.record_tool_calls(len(tool_calls))
            if reminder.should_inject():
                messages.append(reminder.build_reminder())

            # Post-spawn reminder: if any tool call was a 'spawn' that
            # succeeded, inject a parent-task reminder so the agent
            # re-orients after processing delegated sub-agent results.
            blocked_ids = {tc.id for tc, blocked in approved if blocked}
            spawn_calls = [tc for tc in tool_calls if tc.name == "spawn"]
            for sc in spawn_calls:
                if sc.id in blocked_ids:
                    continue
                result = tool_results.get(sc.id, "")
                is_spawn_error = result.startswith("Error") or result.startswith("BLOCKED")
                if not is_spawn_error:
                    child_name = sc.arguments.get("agent", "sub-agent")
                    messages.append(reminder.build_post_spawn_reminder(child_name))

        # ── Graceful termination: Stage 3 — Hard stop ────────────────
        return (
            f"I reached the maximum number of iterations ({max_iter}). "
            "You can try breaking the task into smaller steps."
        ), False

    # ── Compaction helpers ────────────────────────────────────────────────

    @staticmethod
    def _is_token_limit_error(exc: Exception) -> bool:
        """Check if an exception is a context-length-exceeded error."""
        msg = str(exc).lower()
        return any(p in msg for p in _TOKEN_LIMIT_PATTERNS)

    async def _emergency_compact(
        self,
        messages: list[dict[str, Any]],
        session_id: str,
        context_limit: int,
        reminder: ReminderTracker,
    ) -> list[dict[str, Any]]:
        """Run emergency compaction: LLM summary + re-inject memory + trigger consolidation."""
        try:
            messages = await compact_messages(
                messages,
                self._provider,
                self._config,
                context_limit=context_limit,
            )
        except Exception as exc:
            logger.error("Emergency compaction LLM failed: {}, using fallback", exc)
            messages = compact_fallback(messages, keep_recent=3)

        # Re-inject memory + task reminder
        messages = self._reinject_after_compaction(messages, reminder)
        # Fire consolidation in background
        asyncio.create_task(self._consolidator.maybe_consolidate(session_id))
        return messages

    async def _post_completion_check(
        self,
        messages: list[dict[str, Any]],
        session_id: str,
        context_limit: int,
        reminder: ReminderTracker,
        prompt_tokens: int,
    ) -> None:
        """Post-completion check (§2.1): topic-aware compaction at 80%."""
        msg_count = len([m for m in messages if m.get("role") != "system"])
        if not should_post_compact(prompt_tokens, context_limit, msg_count):
            return

        tokens_before = estimate_tokens(messages)
        if detect_topic_switch(messages, self._config.compaction_topic_threshold):
            # Topic switched → full compaction
            logger.info("Post-completion: topic switch detected, running full compaction")
            try:
                compacted = await compact_messages(
                    messages,
                    self._provider,
                    self._config,
                    context_limit=context_limit,
                )
                # Strip system messages except compaction summaries (rebuilt
                # each turn by build_messages), matching manual /compact logic.
                kept = [
                    m
                    for m in compacted
                    if m.get("role") != "system"
                    or "[Conversation summary" in (m.get("content") or "")
                ]
                self._sessions.replace_messages(session_id, kept)
                messages.clear()
                messages.extend(self._reinject_after_compaction(compacted, reminder))
                self._append_compaction_audit(
                    session_id,
                    trigger="post_completion_topic_switch",
                    tokens_before=tokens_before,
                    tokens_after=estimate_tokens(kept),
                    messages_total=len(kept),
                    action="llm_summary",
                    consolidation_triggered=True,
                )
                asyncio.create_task(self._consolidator.maybe_consolidate(session_id))
            except Exception as exc:
                logger.error("Post-completion compaction failed: {}", exc)
        else:
            # Same topic → clear old tool results only (no LLM, instant)
            cleared = clear_old_tool_results(messages, keep_turns=3)
            if cleared:
                self._append_compaction_audit(
                    session_id,
                    trigger="post_completion_same_topic",
                    tokens_before=tokens_before,
                    tokens_after=estimate_tokens(messages),
                    messages_total=len(messages),
                    action="clear_tool_results",
                    tool_results_cleared=cleared,
                )

    def _reinject_after_compaction(
        self,
        messages: list[dict[str, Any]],
        reminder: ReminderTracker,
    ) -> list[dict[str, Any]]:
        """Re-inject memory + task reminder after compaction."""
        new_reminders = reminder.build_post_compaction_reminders()
        # De-duplicate
        reminder_keys = {(m.get("role"), m.get("content")) for m in new_reminders}
        messages = [m for m in messages if (m.get("role"), m.get("content")) not in reminder_keys]
        messages.extend(new_reminders)
        return messages

    def _append_compaction_audit(
        self,
        session_id: str,
        *,
        trigger: str,
        tokens_before: int,
        tokens_after: int,
        messages_total: int,
        action: str = "llm_summary",
        consolidation_triggered: bool = False,
        tool_results_cleared: int = 0,
    ) -> None:
        """Append a _compaction audit entry to the session JSONL.

        This entry is filtered out by get_messages() — it's metadata only.
        """
        entry: dict[str, Any] = {
            "_compaction": {
                "at": datetime.now(UTC).isoformat(),
                "trigger": trigger,
                "tokens_before": tokens_before,
                "tokens_after": tokens_after,
                "messages_total": messages_total,
                "action": action,
                "consolidation_triggered": consolidation_triggered,
            }
        }
        if tool_results_cleared:
            entry["_compaction"]["tool_results_cleared"] = tool_results_cleared
        self._sessions.add_message(session_id, entry)

    # ── Approval routing ──────────────────────────────────────────────────

    async def _try_route_approval(self, msg: InboundMessage) -> bool:
        """Intercept /approve, /deny, /always commands and metadata.approval_action.

        Returns ``True`` if the message was an approval response (consumed),
        ``False`` if it should proceed to the normal agent loop.
        """
        if self._approval_manager is None:
            return False

        mgr: ApprovalManager = self._approval_manager  # type: ignore[assignment]

        content = msg.content.strip()
        content_lower = content.lower()
        action: str | None = None
        request_id: str | None = None

        # Check metadata first (Teams Adaptive Card / Cloud structured response)
        if msg.metadata.get("approval_action"):
            action = msg.metadata["approval_action"]
            request_id = msg.metadata.get("approval_request_id")

        # Slash commands with explicit ID: /approve <id>, /deny <id>, /always <id>
        elif content.startswith("/approve "):
            action = "approve"
            request_id = content.split(maxsplit=1)[1].strip()
        elif content.startswith("/deny "):
            action = "deny"
            request_id = content.split(maxsplit=1)[1].strip()
        elif content.startswith("/always "):
            action = "always"
            request_id = content.split(maxsplit=1)[1].strip()

        # Simple keywords / bare commands — resolve against the single pending request
        # (fallback for web/Teams when UI buttons are not available)
        else:
            pending = mgr.get_pending()
            if len(pending) == 1:
                sole = pending[0]
                if content_lower in ("yes", "y", "approve", "/approve"):
                    action, request_id = "approve", sole.id
                elif content_lower in ("no", "n", "deny", "/deny"):
                    action, request_id = "deny", sole.id
                elif content_lower in ("always", "a", "/always"):
                    action, request_id = "always", sole.id

        if not action or not request_id:
            return False

        try:
            approved = action in ("approve", "always")
            mgr.resolve(
                request_id, approved=approved, resolver=msg.sender_id or "user", action=action
            )

            # "always" also adds to allowlist
            if action == "always" and self._allowlist is not None:
                resolved_req = mgr.get_request(request_id)
                if resolved_req:
                    self._allowlist.add(  # type: ignore[union-attr]
                        resolved_req.tool_name,
                        resolved_req.args,
                        added_by=msg.sender_id or "user",
                        note="Added via /always command",
                    )

            status = "approved" if approved else "denied"
            ch = ChannelType.of(msg.channel)
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=ch,
                    channel_id=msg.channel_id,
                    content=f"Tool call {status}.",
                    thread_id=msg.thread_id,
                )
            )
        except (KeyError, ValueError) as exc:
            ch = ChannelType.of(msg.channel)
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=ch,
                    channel_id=msg.channel_id,
                    content=f"Approval error: {exc}",
                    thread_id=msg.thread_id,
                )
            )
        return True

    async def _stream_response(
        self,
        *,
        messages: list[dict[str, Any]],
        channel: ChannelType,
        channel_id: str,
        session_id: str | None = None,
    ) -> str:
        """Stream a text-only LLM response, publishing chunks to the bus.

        Uses dispatch_outbound (handler-only, no queue) to avoid filling the
        bounded outbound queue with high-frequency StreamingChunks.  The done
        marker is always sent via try/finally so channels exit streaming state
        even when the provider raises mid-stream.
        """
        parts: list[str] = []
        try:
            async for chunk in self._provider.stream(
                model=self._config.model,
                messages=messages,
            ):
                if chunk.content:
                    parts.append(chunk.content)
                    await self._bus.dispatch_outbound(
                        StreamingChunk(
                            channel=channel,
                            channel_id=channel_id,
                            content=chunk.content,
                            done=False,
                        )
                    )
        finally:
            # Always send the done marker so channels exit streaming state
            await self._bus.dispatch_outbound(
                StreamingChunk(
                    channel=channel,
                    channel_id=channel_id,
                    content="",
                    done=True,
                )
            )
        content = "".join(parts)
        # Run on_message_sent hook on full accumulated content so outbound
        # hooks (e.g. leak scanner) can inspect the complete streamed response.
        if self._hooks:
            msg_ctx = MessageHookContext(
                content=content, channel=channel, session_id=session_id or ""
            )
            result = await self._hooks.dispatch_checked("on_message_sent", msg_ctx)
            if result.verdict == HookVerdict.REJECT:
                logger.warning(
                    "Streamed outbound message blocked by hook: {}",
                    result.reason,
                )
                content = "[Message blocked by security policy]"
            elif result.data and isinstance(result.data, MessageHookContext):
                content = result.data.content
        return content
