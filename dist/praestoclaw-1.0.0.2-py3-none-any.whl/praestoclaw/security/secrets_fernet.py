"""
FernetBackend — AES-128-CBC + HMAC-SHA256 encrypted file store.

Stores secrets in ``~/.praestoclaw/auth/secrets.json.enc`` with atomic writes
and file-level locking for concurrent access protection.  The master key is
managed by ``secrets.py`` helpers (keyring → env → file).
"""

from __future__ import annotations

import json
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken
from loguru import logger

from praestoclaw.security.secrets import (
    SecretStore,
    _atomic_write_file,
    _init_master_key,
    _try_get_fernet,
)
from praestoclaw.utils.helpers import get_auth_dir

_LOCK_TIMEOUT = 10  # seconds


def _get_lock(lock_path: Path):  # noqa: ANN202
    """Return a file lock, preferring ``filelock`` with fallback."""
    try:
        from filelock import FileLock

        return FileLock(lock_path, timeout=_LOCK_TIMEOUT)
    except ImportError:
        pass
    # Fallback: no-op context manager (single process is fine for most users)
    from contextlib import nullcontext

    logger.warning("filelock not installed — concurrent access unprotected. pip install filelock")
    return nullcontext()


class FernetBackend(SecretStore):
    """Encrypted local file store using Fernet (AES-128-CBC + HMAC-SHA256)."""

    def __init__(self, store_path: Path | None = None) -> None:
        self._path = store_path or (get_auth_dir() / "secrets.json.enc")
        self._lock_path = self._path.with_suffix(".lock")
        self._fernet: Fernet | None = None
        self._data: dict | None = None
        self._master_key_source: str = "unknown"

    def _ensure_fernet(self) -> Fernet:
        """Lazily initialize the Fernet instance and track master key source."""
        if self._fernet is not None:
            return self._fernet

        from praestoclaw.security.secrets import (
            _try_master_key_from_env,
            _try_master_key_from_file,
            _try_master_key_from_keyring,
        )

        f = _try_get_fernet()
        if f is not None:
            self._fernet = f
            # Track source for metadata
            if _try_master_key_from_keyring():
                self._master_key_source = "keyring"
            elif _try_master_key_from_env():
                self._master_key_source = "env"
            elif _try_master_key_from_file():
                self._master_key_source = "file"
            return f

        # No existing key — initialize one
        key = _init_master_key()
        self._fernet = Fernet(key)
        # Determine where the new key was stored
        if _try_master_key_from_keyring():
            self._master_key_source = "keyring"
        elif _try_master_key_from_file():
            self._master_key_source = "file"
        else:
            self._master_key_source = "generated"
        return self._fernet

    def _load(self) -> dict:
        """Load and return the secrets file contents."""
        if self._data is not None:
            return self._data

        if not self._path.is_file():
            self._data = {
                "version": 2,
                "encryption": "fernet-aes128cbc",
                "kdf": "none",
                "kdf_params": {},
                "master_key_source": "unknown",
                "secrets": {},
            }
            return self._data

        try:
            raw = self._path.read_text(encoding="utf-8")
            self._data = json.loads(raw)
            # Ensure "secrets" is a dict (guard against malformed JSON)
            if not isinstance(self._data.get("secrets"), dict):
                self._data["secrets"] = {}
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning("Corrupted secrets file {}: {}. Starting fresh.", self._path, exc)
            self._data = {
                "version": 2,
                "encryption": "fernet-aes128cbc",
                "kdf": "none",
                "kdf_params": {},
                "master_key_source": "unknown",
                "secrets": {},
            }
        return self._data

    def _persist_locked(self) -> None:
        """Write the secrets file atomically.  Caller must hold the lock."""
        if self._data is None:
            return
        self._data["master_key_source"] = self._master_key_source
        content = json.dumps(self._data, indent=2, ensure_ascii=False)
        _atomic_write_file(self._path, content)
        self._data = None  # invalidate cache

    def get(self, name: str) -> str | None:
        lock = _get_lock(self._lock_path)
        with lock:
            data = self._load()
            token = data.get("secrets", {}).get(name)
        if not token:
            return None
        try:
            fernet = self._ensure_fernet()
            return fernet.decrypt(token.encode()).decode()
        except InvalidToken:
            logger.warning(
                "Failed to decrypt secret '{}' — wrong master key or corrupted token", name
            )
            return None
        except Exception as exc:
            logger.warning("Error reading secret '{}': {}", name, exc)
            return None

    def set(self, name: str, value: str) -> None:
        fernet = self._ensure_fernet()
        lock = _get_lock(self._lock_path)
        with lock:
            self._data = None  # force reload under lock
            data = self._load()
            encrypted = fernet.encrypt(value.encode()).decode()
            data.setdefault("secrets", {})[name] = encrypted
            self._persist_locked()

    def delete(self, name: str) -> None:
        lock = _get_lock(self._lock_path)
        with lock:
            self._data = None
            data = self._load()
            secrets = data.get("secrets", {})
            if name in secrets:
                del secrets[name]
                self._persist_locked()

    def list_names(self) -> list[str]:
        lock = _get_lock(self._lock_path)
        with lock:
            data = self._load()
        return list(data.get("secrets", {}).keys())

    def rotate_all(self, old_fernet: Fernet, new_fernet: Fernet) -> int:
        """Re-encrypt all secrets from *old_fernet* key to *new_fernet* key.

        Returns the number of secrets rotated.
        """
        from cryptography.fernet import MultiFernet

        mf = MultiFernet([new_fernet, old_fernet])
        lock = _get_lock(self._lock_path)
        with lock:
            self._data = None
            data = self._load()
            secrets = data.get("secrets", {})
            count = 0
            for name, token in secrets.items():
                try:
                    secrets[name] = mf.rotate(token.encode()).decode()
                    count += 1
                except InvalidToken:
                    logger.warning("Skipping secret '{}' during rotation — invalid token", name)
            # Always update fernet to new key (even if store is empty)
            self._fernet = new_fernet
            if count:
                self._persist_locked()
        return count

    def backend_info(self) -> str:
        lock = _get_lock(self._lock_path)
        with lock:
            data = self._load()
        count = len(data.get("secrets", {}))
        # Read persisted source if we haven't initialized fernet yet
        source = self._master_key_source
        if source == "unknown":
            source = data.get("master_key_source", "unknown")
        return f"FernetBackend (file={self._path}, secrets={count}, master_key={source})"
