"""
Relay token validator — verifies JWTs forwarded by the Cloud Gateway.

Step 1 (stub): all methods pass through without validation.
Step 3 replaces the stub with real Entra ID / Bot Framework JWT verification.

See explore/archive/cloud-gateway-dotnet/token-passthrough.md for the original design.
The Python gateway implementation is in gateway/src/gateway/auth/.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from praestoclaw.channels.cloud import CloudChannel


class RelayValidator:
    """Validates JWT tokens forwarded by the Cloud Gateway relay.

    Holds a back-reference to the owning CloudChannel so that identity
    (``_local_oid`` / ``_local_tid``) is always read dynamically — if the
    user re-authenticates with a different account, the validator picks up
    the new identity automatically.

    Step 1 stub: all methods pass through. Step 3 adds real JWT validation.
    """

    def __init__(self, channel: CloudChannel) -> None:
        self._channel = channel

    def validate_message(self, frame: dict[str, Any]) -> bool:
        """Validate a message or approval_response frame.

        Returns True if the frame should be accepted, False to reject.
        Step 1 stub: always returns True.
        """
        return True

    def validate_admin(self, frame: dict[str, Any]) -> str | None:
        """Validate an admin_request frame.

        Returns the caller OID on success, None to reject.
        Step 1 stub: returns the declared caller_oid without verification.
        """
        raw_caller = frame.get("caller_oid")
        caller: str = raw_caller if isinstance(raw_caller, str) and raw_caller else "unknown"
        return caller
