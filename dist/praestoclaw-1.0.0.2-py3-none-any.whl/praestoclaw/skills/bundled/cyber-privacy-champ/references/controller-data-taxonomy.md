# Controller Data Taxonomy Guide
> Source: Controller Data Taxonomy Guide.docx (2025-11-17), microsoft.sharepoint.com/sites/privacy
> Purpose: Definitions only — use with Data Use Framework. Does NOT replace privacy review.

## Scope
- Uniform terminology for data Microsoft products collect when **Microsoft is the controller**.
- Anchors internal/external discussions with customers, regulators, stakeholders.
- Does NOT prescribe rules for uses of data types — see Data Use Framework (https://aka.ms/useframe).
- Not intended to address Microsoft's role as controller in the employment setting.

## Data Identification Levels

| Level | Definition | Examples |
|---|---|---|
| **Identified Data** | Data relates to a specific person whose identity is known; includes direct identification (name, email), data linked directly with identifying data, and/or linked with a user ID that directly connects to identifying data. | Profile data linked to an MSA or PUID; data linked to email, phone number, or third-party credential (e.g. Facebook, Twitter). |
| **Pseudonymized Data** | Data relates to a specific person whose identity is not known; not directly linked with identifying data, but there is a known systematic way to create/re-create a link; persistently associated with an identifier that could be used to re-associate with an identified person. | Data associated with a randomly generated GUID. |
| **Unlinked Pseudonymized Data** | High confidence the actual human subject cannot be identified directly or indirectly by the data alone or in combination with retained/available data. | GUID not logged to any unique ID linkable to subject; identifier generated using a key that persists only for a specified period. |
| **Anonymized Data** | Data that is unlinked and whose attributes are altered (randomized/generalized) so there is reasonable confidence a person cannot be identified. | — |
| **Aggregated Data** | Statistical data with no individual-level entries, combined from enough different persons that individual attributes are not identifiable. | — |

## Data Types

### CUSTOMER CONTENT DATA

#### Customer Content
Data an end user inputs/uploads and controls as they use a Microsoft product/service, plus data they intentionally create from that use.

**Examples:** Documents, photos, videos, music (including metadata), content body of email/messages/audio-visual communications, Notes field of a contact entry, calendar entries, transcripts of content entered into a product/service, data entered in HealthVault, file path names, voice/video data from customer communications.

#### Credentials
Data provided by the end user to identify themselves to the device/application/cloud service (e.g. passwords, password hints), including biometric data provided for identification.

#### Customer Contact List
Contact information for people the end user provides and maintains. Note: contact info provided solely to administer or make payment for the service is Account Data.

**Examples:** Outlook "My Contacts", Skype Contacts, family members in Microsoft Family, third-party contacts entered into Microsoft products, third-party contacts imported from non-Microsoft services.

#### Biometric
Data resulting from specific technical processing relating to physical, physiological, or behavioral characteristics of an individual. Note: captured video/photos or voice recordings without technical processing are NOT biometric data; high-resolution fingerprint/iris/retina image IS biometric data.

**Examples:** Facial Verification, Facial Grouping, Speaker Verification/Identification, Iris/Retina Scanning, Fingerprint Scanning, Posture.

#### Personal Health Data & Medical Records
Sensitive personal data relating to an individual's mental or physical health.

**Examples:** Physiological/biological information (genetic data, pulse, heart rate, EKG, blood glucose, blood pressure, eye prescriptions, body weight); medical records (clinical trial data, medical imaging, treatment records/notes/plans, prescriptions).

### CAPTURED OR GENERATED DATA

#### Device Connectivity and Configuration Data
Data about the end user's device configuration and network capabilities.

**Examples:** IP address of device, device type/model/manufacturer, operating system version, screen resolution, installed applications, network connection type/speed, country/region, language setting.

#### Product and Service Usage Data
Data generated as a result of an end user's interaction with or use of the product/service.

**Examples:** Pages visited, links clicked, features used, frequency/duration of use, application launch/close events, search queries, items purchased, content viewed/created, navigation paths, error codes.

#### Product and Service Performance Data
Data collected about the operation and performance of the product/service.

**Examples:** Crash dumps, response times, error rates, CPU/memory utilization, reliability metrics, load times.

#### Support Interaction Data
Data provided during support (or authorized capture) to obtain support/troubleshooting. Note: customer contact info during support = Account Data.

#### Support Data (formerly Support Content Data)
Customer Content provided during an exceptional use triggered by a request for support/troubleshooting services.

#### Feedback and Ratings Data
Data provided as part of a review/feedback about Microsoft products/services.

#### Software Setup and Inventory Data
Data about software installation, setup, and updates.

#### Demographic Information Data
Data about demographic characteristics (e.g. age, gender, education level, occupation).

#### Interests and Favorites Data
Data about the end user's interests and favorites as captured from product/service use. Also known as Profiling data.

#### Content Consumption Data
Data about content consumed (e.g. articles read, videos watched, music played).

#### Inking, Typing and Speech Utterance Data
Record of unprocessed input provided by end user through inking/typing/speech utterance/gesture. The actual input (e.g. speech utterance) — not the transcript text.

#### Social Data
Data about the end user's social interactions, connections, and communities through use of a Microsoft product/service. Communities may be public or private.

#### Fitness and Activity Data
Data related to the end user's fitness and physical activity captured through sensors or manual input.

#### Environmental Sensor Data
Data from environmental sensors (e.g. temperature, humidity, noise level, air quality).

#### Licensing and Purchase Data
Data about licenses and entitlements for installed software.

### CLOUD SERVICE PROVIDER DATA

#### Browsing History Data
Client-side browsing history. More restrictive handling than other captured data.

#### Search Requests and Query Data
Search commands and queries entered by end user.

#### Third Party Search Results Data
Search results from a third-party search provider. **Most restrictive — X (not permitted) for nearly all uses.**

#### Precise User Location Data
Location data with precision of 300 meters or better. More restrictive handling.

### ACCOUNT DATA

#### Account Data / Customer Contact Data
Account or administration contact information. Includes billing, payment, licensing data.

**Examples:** Admin name, contact email, phone, billing address, payment method.

#### Payment Instrument Data
Data about the end user's payment instruments (e.g. credit card numbers, bank account).

## DATA SHARING

| Category | Definition |
|---|---|
| **Share with Third-Party Data Processors** | Transfer data to a third-party contractually bound to uphold Microsoft commitments. |
| **Share with Third-Party Data Controllers** | Transfer data to a third-party that uses the data for its own purposes. |

## Key Concepts

### Within vs Across
- **Within** = data sourced from and used for the same product/service.
- **Across** = data sourced from one product/service and used for another.
- Concept remains important but is highly context/scenario-driven; removed from Use Categories in new Data Use Framework. Work with privacy manager and CELA.

### Sensitive Data
- No separate sensitive-data category in this taxonomy.
- Sensitivity depends on region, use, and context (e.g. children's data, health data).
- May require DPIA. Frontline CELA and Privacy Teams should review.

## ISO 19944 Alignment
- Based on ISO/IEC DIS 19944; see Appendix in source document for mapping.
- Key mappings: "Captured or Generated" = End user identifiable information (8.2.3.2.1), "Product and Service Usage Data" = Observed Usage of Service Capability (8.2.3.2.4).
