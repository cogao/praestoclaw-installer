# Rules and Scenarios — Cyber Privacy Champ

Main answer layer. Each topic = rule + scenario pattern + response template in one place. No duplication across files.

---

## 1. Privacy review triggers

**Rule:** Treat these as strong indicators that privacy review is needed or should be evaluated:
- new feature, service, or release
- update to existing feature or service
- new or changed personal data processing
- new purpose for data use
- notice or consent changes
- cookies, sharing, biometrics, location, profiling, AI/ML
- ~1 year since last privacy review

**Scenario — "Do we need a privacy review?"**

> **Conclusion:** This likely needs at least a privacy consult, and possibly a formal privacy review depending on implementation details.
>
> **Why:** [cite the trigger: new feature, changed data processing, AI/ML, etc.]
>
> **What to do next:** If still early → consult. If implementation is defined → prepare for formal review.
>
> **Escalate if needed:** If the change is novel, ambiguous, or clearly privacy-impacting → Privacy Manager.

---

## 2. Consult vs review

**Rule:**
- **Privacy consult** — early ideation/planning; generally no 1CS Privacy Assessment needed
- **Privacy review** — concrete feature/release; formal evaluation with artifacts and workflow

If the design is still forming → consult first.

**Scenario — "Is this a consult or a review?"**

> If the team is still designing → consult. If artifacts can be prepared → review. If unsure → consult first, note review may follow.

---

## 3. Pre-review

**Rule:** Pre-review = preparation before formal review. NOT approval.

Typical pre-review work:
- check 1CS Privacy Assessment completeness and accuracy
- review generated tasks
- verify required artifacts exist
- find gaps before Privacy Manager review

**Scenario — "What does pre-review mean?"**

> Pre-review helps ensure the package is complete before the Privacy Manager sees it. It is not the approval itself.

---

## 4. 1CS workflow

**Rule:**
- 1CS Privacy Assessment → ADO User Story
- Follow-up items → Tasks
- Assessment answers drive required tasks and artifacts
- Durable evidence matters; fragile links alone are insufficient

**Scenario — "What should I check in the 1CS Privacy Assessment?"**

> Focus on: complete/accurate answers, tasks actually followed, artifacts exist and are durable, linked references sufficient for audit.

---

## 5. Artifacts

**Rule:** Exact list depends on assessment answers. Common artifacts:
- 1CS Privacy Assessment + generated Tasks
- Data Scout / data inventory
- Data Flow Diagram
- DSR plan
- DPIA update (if triggered)
- UI/UX screenshots (where notice/consent matters)

Artifacts should align with each other and provide durable evidence.

**Scenario — "What artifacts do we usually need?"**

> List the common artifacts above. Add: they should be internally consistent, not just loosely linked.

---

## 6. Data Scout

**Rule:** If the feature uses data, expect Data Scout or equivalent data inventory work. Privacy Managers may compare Data Scout with DFD and DSR plan — they should align.

**Scenario — "Do we need Data Scout?"**

> If your feature uses data → yes. Make sure Data Scout, DFD, and DSR plan tell the same story.

---

## 7. DPIA

**Rule:** DPIA update may be needed when privacy-impacting changes occur:
- new processing, new purpose, consent/notice changes, cookies, sharing, biometrics, location, profiling, AI/ML

DPIA update tasks → L3 champ or Privacy Manager.

**Scenario — "Do we need a DPIA update?"**

> If consent changed or AI/profiling was added → likely yes. Have an L3 champ or Privacy Manager handle it.

---

## 8. Role boundaries and signoff

**Rule:**
- **Regular champ:** preparation, guidance, assessment/task/artifact help
- **L3 champ:** low-risk signoff + advanced tasks (e.g., DPIA updates)
- **Privacy Manager:** medium/high-risk, novel, ambiguous, formal judgment

Low-risk = ADO user story tagged Low. Safe Patterns = special low-risk category. If not clearly low-risk → escalate.

**Scenario — "Can a champ sign this off?"**

> Only if clearly low-risk and the champ is L3. If risk is unclear, medium/high, or ambiguous → Privacy Manager.

**Scenario — "Who should handle this?"**

> Preparation questions → any champ. Low-risk signoff → L3. Everything else → Privacy Manager. When unsure, route upward.

---

## 9. DAR vs Privacy Review

**Rule:** Data Access Request ≠ Privacy Review. Different processes. DAR does not replace Privacy Review.

**Scenario — "Is DAR the same as Privacy Review?"**

> No. They are different processes. One does not replace the other.

---

## 10. Annual review timing

**Scenario — "We reviewed this ~1 year ago. Do we need another?"**

> Annual timing can itself trigger reevaluation. If the feature or data use changed → even more likely.

---

## 11. Taxonomy and data profile

**Rule:**
- Enterprise Data Taxonomy / Asset Classification = processor-side (AAD/Entra ID)
- Controller Data Taxonomy = controller-side data type definitions (MSA)
- Controller Data Use Framework = how controller data may be used once collected
- Taxonomy alone does not replace privacy review
- Privacy review determines the concrete outcome

When answering taxonomy/profile questions:
1. Identify the data
2. Determine controller vs processor side
3. Determine: what is it? how may it be used? how must it be handled?
4. Prefer current guidance over historical unless user asks about history
5. Run OUTPUT GATE (see SKILL.md A0.2) before any classification output

**Scenario — "Which framework should I use?"**

> First determine: is this processor-side (enterprise customer data handling) or controller-side (Microsoft using data as controller)? Then:
> - Processor → Enterprise Data Taxonomy + Data Handling Standards V5
> - Controller → Controller Data Taxonomy + Controller Data Use Framework

**Scenario — "How should I fill the data profile / Data Scout?"**

> Describe the real processing. For each data element: type, source, purpose, flow, access, retention, sharing/export/model usage. Align with 1CS Assessment, DFD, and DSR plan.

---

## 12. Current vs historical guidance

**Rule:**
- `Data Handling Standards.xlsx` → `V5 (current)` = current tab
- `Controller Data Use Framework - old.xlsx` = explicitly old/historical
- Prefer current guidance for present-state recommendations
- Use older materials only for lineage or historical explanation

**Scenario — "Should I use current guidance or an old workbook?"**

> Prefer current when explicitly identified. V5 = current. Old workbooks = historical context only.

---

## 13. Derived / inferred / model data

**Rule:**
- Derived/inferred data usually keeps source classification
- Mixed datasets inherit highest-sensitivity classification
- Model handling may inherit from training data classification
- Hashing/transformation does NOT automatically remove sensitivity

If user tries to justify a downgrade → recommend escalation.

**Scenario — "Can we treat model output as less sensitive than source data?"**

> Default: no. Derived data keeps source classification. Mixed datasets inherit highest. Recommend escalation if trying to downgrade.

---

## 14. Taxonomy cross-contamination (Scenario 17)

**The mistake:** Using Enterprise taxonomy terms (EUPI, OII, EUII) in a Controller/MSA scenario, or vice versa.

**Real example (Societas OneDrive attach):**
- ❌ Graph API access token → classified as "EUPI" → wrong: EUPI is Enterprise taxonomy
- ✅ Correct: **Credentials Data** (Controller taxonomy) — an access token is an authentication credential
- ❌ driveId/itemId/webUrl → classified as "OII" → wrong: OII is Enterprise taxonomy
- ✅ Correct: **Product and Service Usage Data** (Controller taxonomy) — system-generated resource identifiers

**Root cause:** Warning existed ("never mix") but no concrete allow-list or validation step. Model defaulted to familiar Enterprise terms.

**Prevention:** Always run the OUTPUT GATE (SKILL.md A0.2):
1. Confirm side (Controller vs Enterprise)
2. Look up the allow-list for that side
3. Verify chosen term exists in the allow-list
4. If not → find the correct term

---

## 15. Vague / ambiguous questions

**Rule:** Ask for minimum missing facts, then give a provisional answer:
- Is this a new feature or a change?
- Does it involve personal data or a new use of data?
- Is the design early, or are you preparing review artifacts?

Do not wait for perfect information. Give the safest likely path.

---

## 16. Safe default language

Use wording like:
- "This likely needs at least a privacy consult, and possibly a formal privacy review depending on implementation details."
- "If this changes how personal data is processed, assume privacy review involvement is needed."
- "If the user story is tagged Low and you are L3, this may be eligible for champ signoff; otherwise route to the Privacy Manager."
- "For current handling expectations, prefer the current V5 handling matrix over older historical tabs."
- "First classify what kind of data this is, then decide what controller or processor rules apply."
