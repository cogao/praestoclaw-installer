---
name: a2a
description: Agent-to-Agent 异步通信 — 通过 gateway 中转向其它 PraestoClaw agent 发消息（fire-and-forget）
metadata:
  activation:
    keywords: [a2a, agent-to-agent, remote agent, other agent, agent network, ask agent, peer agent, 给他发, 转给, 让他]
    patterns:
      - "(?i)\\ba2a\\b"
      - "(?i)\\bagent[- ]to[- ]agent\\b"
      - "(?i)\\bremote agent\\b"
      - "(?i)\\bother agents?\\b"
      - "(?i)(给|让|找|问)\\s*\\S+\\s*(发|回|问|做|帮)"
  requires:
    tools: [a2a]
---
## A2A — Agent-to-Agent 异步消息

A2A 是 PraestoClaw agent 之间的通信协议。两个 agent 各自独立运行（属于不同用户、不同实例），通过 gateway 作为中转。**通信模型是异步 fire-and-forget**：你调一次 `a2a` tool 把消息发出去，立即返回；对方的 ack 与回复会**稍后**作为系统通知到达，由 LLM（也就是你）届时再处理。

### 核心模型 — "发出去就走"

调用 `a2a action="send"` 后，tool 会在拿到 gateway 的 dispatch 结果后立即返回，结果只有两种：

* **成功** — 返回 `已发出 a2a 消息 (message_id=…)`。这表示消息已经成功投递到对方实例，但**对方还没处理完**。
* **失败** — 返回 `a2a send 失败：<code> — <reason>`。最常见的 code 是 `agent_offline`（对方未连接 gateway）。这种情况要直接告诉用户、不要重试。

之后会发生什么：

1. 对方 agent 收到后会**先**回一条 `ack`（"已收到，开始处理"）。
2. 对方处理完成后会**再**回一条 `text`（真正的回复内容）。
3. 如果对方处理过程中出错，会回一条 `error`。

这两/三条消息都会被你的 A2ARuntime 转换成**系统通知 InboundMessage** 注入回你的会话（保持原 session/channel context），你下一轮就会"看到"它们。

> ⚠️ **关键约束**：调完 `send` 之后你的本回合就该结束。**不要轮询、不要循环调 send、不要在同一回合编造对方的回复**。等下一轮系统通知进来再处理。

### 识别 A2A 系统通知

当你看到一条进入对话的消息满足下列**全部**条件时，那不是用户在说话，而是 A2A runtime 转发的对端事件：

* 内容以 `[A2A]` 开头
* sender 是 `A2A`（`sender_id == "a2a-system"`）
* `metadata.source == "a2a_notify"`，并带 `kind` ∈ `{ack, text, error}` 和 `parent_id`

三种 `kind` 的格式：

| kind  | 通知文本（runtime 注入的原文）                                                            | 你应该如何向用户呈现                       |
|-------|----------------------------------------------------------------------------------------|----------------------------------------|
| ack   | `[A2A] <target> 已确认收到你发出的消息 (msg_id=<id>)`                                   | "Bob 已确认收到，正在处理…"           |
| text  | `[A2A] <target> 回复了你 (re: <id>)：\n\n<回复正文>`                                    | "Bob 回复了：<回复正文>"               |
| error | `[A2A] <target> 处理你的消息时出错 (msg_id=<id>)：<code> — <reason>\n<detail>`         | "Bob 处理时出错：<reason>"            |

呈现规则：

* **简洁转述**给用户，不要把 `[A2A] …` 原文整段复述出去（用户不关心内部协议格式）。
* `ack` 是中间事件，告知一下即可，不要宣布"任务完成"。
* `text` 才是终态回复，把对方的实际内容传达给用户。
* `error` 要明确告诉用户失败了，并给出 reason/detail。

### Tool 用法

#### `discover` — 查询对方 agent card

不确定对方是否存在或想看其能力时使用。

```
a2a(action="discover", target="bob@contoso.com")
```

返回对方的 `name` / `description` / `skills` 列表，或 `Agent '<target>' not found` 类错误。

* `target` 用对方的完整 `user_id`（一般是邮箱形态）。用户用昵称提到时（如 "alice"），先 `discover` 拿到规范的 `user_id` 再 `send`。

#### `send` — 异步发送一条消息

```
a2a(action="send", target="bob@contoso.com", message="给我回个 hi")
```

成功立即返回 `已发出 a2a 消息 (message_id=…)`。**就这样，不要再做别的，结束本回合等待通知。**

参数：

* `target` — 对方完整 user_id。
* `message` — 要发给对方的内容。注意这是**给对方 agent 看的**，请用清晰的自然语言陈述任务，而不是给用户的口吻。

### 完整示例

用户："通过 a2a 给 bob 发消息，让他给我回个 hi"

**回合 1（用户输入触发）**

1. 你调 `a2a {action: "send", target: "bob@contoso.com", message: "请给我回一个 hi"}`
2. tool 返回：`已发出 a2a 消息 (message_id=abc123)。…等待通知。`
3. 你回复用户：`已经把消息发给 Bob 了，等他回应。`
4. **本回合结束。不要再调任何 a2a tool。**

**回合 2（系统通知 ack 进来）**

5. 进来一条 `[A2A] bob@contoso.com 已确认收到你发出的消息 (msg_id=abc123)`
6. 你回复用户：`Bob 已确认收到，正在处理。`

**回合 3（系统通知 text 进来）**

7. 进来一条 `[A2A] bob@contoso.com 回复了你 (re: abc123)：\n\nhi`
8. 你回复用户：`Bob 回复了：hi`

### Anti-patterns（务必避免）

* ❌ 调完 `send` 后在**同一回合**自问自答 / 编造对方的回复 —— 对方还没处理。
* ❌ 看到 `ack` 通知就向用户报"任务完成" —— ack 只表示"已送达"，真正回复在 `text` 里。
* ❌ 把 `[A2A] …` 系统通知原文整段转发给用户 —— 用简洁的中文转述。
* ❌ 反复对同一条消息多次调 `send`（包括"等不到回复就再发一次"）—— 异步系统下这只会造成重复消息。
* ❌ 用 `a2a` 调用本机的 sub-agent 或 spawn 出来的子 agent —— 那是 `spawn` 的事；`a2a` 用于跨实例、跨用户的远端 agent。

### 何时用 A2A vs Spawn

| 场景                                                  | 用什么          |
|-------------------------------------------------------|----------------|
| 远端 agent（不同实例 / 不同用户）                     | `a2a`          |
| 本地 sub-agent（同一 PraestoClaw 实例内）             | `spawn`        |
| 需要快速只读代码搜索                                  | `spawn` + `explorer` |

### 限制

* **必须有用户 channel context**：`send` 只能在用户的实时会话中调用（CLI / Cloud channel）。后台任务、cron job、被 spawn 出来的子 agent **不能**调 `a2a` —— 没有 channel/session 可以承接对端回复时注入的系统通知。
* **对端 agent 内部禁用扩散性工具**：作为接收方处理入站消息时，对方 agent 的 `notify` / `spawn` / `cron` / `a2a` 都被禁用，避免相互调用形成环路。
* **不缓存离线消息**：对方未连接 gateway 时 `send` 立即返回 `agent_offline` 错误，不会排队、不会重投递。要先 `discover` 或直接告诉用户对方暂时不在线。
* **dispatch 超时 ~10s**：如果连 gateway 的 dispatch 回包都拿不到，`send` 会以 timeout 错误返回；这通常意味着 gateway 不通，告诉用户即可。
* **pending 表 10 分钟过期**：发出去 10 分钟还没收到回复的消息会被本地清理；之后即使对方回复也无法关联回原 session。
