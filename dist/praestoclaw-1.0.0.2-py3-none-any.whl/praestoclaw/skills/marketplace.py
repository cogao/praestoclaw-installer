"""Skill Marketplace — discover and install skills from external repositories.

A marketplace is a local directory containing skill folders (SKILL.md files).
Two formats are supported:

1. **Flat** — ``skills/<name>/SKILL.md`` (microsoft_skills_marketplace style)
2. **Plugin** — ``plugins/<name>/skills/<sub>/SKILL.md`` with a top-level README.md
   (edge-agents style). Each sub-skill is listed independently under the plugin name.

Installed skills are symlinked into ``~/.praestoclaw/skills/`` so the normal
SkillLoader picks them up automatically.
"""

from __future__ import annotations

import json
import re
import shutil
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

import yaml
from loguru import logger

_METADATA_FILE = ".marketplace.json"
_SAFE_CHAR_RE = re.compile(r"[^a-zA-Z0-9_-]")


def _safe_skill_dirname(name: str) -> str:
    """Return a filesystem-safe directory name derived from a skill name.

    Raises ``ValueError`` on empty names, names containing path traversal
    segments, or names starting with ``.``.
    """
    if not name or not name.strip():
        raise ValueError("Skill name must not be empty")
    name = name.strip()
    if name.startswith("."):
        raise ValueError(f"Skill name must not start with '.': {name!r}")
    # Reject path traversal segments in the original name
    for part in re.split(r"[\\/]", name):
        if part in ("..", "."):
            raise ValueError(f"Skill name must not contain path traversal: {name!r}")
    # Convert / to -- then sanitize remaining chars
    safe = name.replace("/", "--")
    safe = _SAFE_CHAR_RE.sub("_", safe)
    if not safe or safe.startswith("."):
        raise ValueError(f"Skill name produces invalid directory: {name!r}")
    if ".." in safe:
        raise ValueError(f"Skill name produces invalid directory: {name!r}")
    return safe[:128]


@dataclass
class MarketplaceSkill:
    """A skill available in a marketplace (not yet installed)."""

    name: str
    description: str
    source: str  # marketplace source id
    source_label: str  # human-readable marketplace name
    plugin: str  # parent plugin name (same as name for flat skills)
    path: str  # absolute path to the skill directory
    installed: bool = False
    keywords: list[str] = field(default_factory=list)
    has_references: bool = False  # True if the skill dir has references/
    recommended: bool = False


@dataclass
class MarketplaceSource:
    """A configured marketplace source."""

    id: str
    label: str
    path: str  # absolute path to the marketplace root
    format: str  # "flat" or "plugin"
    skill_count: int = 0


def _parse_frontmatter(skill_md: Path) -> dict:
    """Extract YAML frontmatter from a SKILL.md file."""
    try:
        text = skill_md.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return {}
    m = re.match(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
    if not m:
        return {}
    try:
        return yaml.safe_load(m.group(1)) or {}
    except Exception:
        return {}


def _extract_description(readme: Path) -> str:
    """Extract first non-heading, non-empty line from README.md."""
    try:
        for line in readme.read_text(encoding="utf-8", errors="replace").splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith("#") and not stripped.startswith("---"):
                return stripped[:200]
    except Exception:
        pass
    return ""


def discover_marketplace(source_path: Path, source_id: str, source_label: str) -> MarketplaceSource:
    """Probe a marketplace directory and return its metadata."""
    fmt = detect_format(source_path)
    skills = list_marketplace_skills(
        source_path, source_id, source_label, fmt, installed_names=set()
    )
    return MarketplaceSource(
        id=source_id,
        label=source_label,
        path=str(source_path),
        format=fmt,
        skill_count=len(skills),
    )


def detect_format(source_path: Path) -> str:
    """Detect whether a marketplace uses flat or plugin format."""
    # Plugin format: has subdirs with skills/ subdirectories
    for child in source_path.iterdir():
        if child.is_dir() and (child / "skills").is_dir():
            return "plugin"
        if child.is_dir() and (child / "SKILL.md").is_file():
            return "flat"
    return "flat"


def list_marketplace_skills(
    source_path: Path,
    source_id: str,
    source_label: str,
    fmt: str,
    *,
    installed_names: set[str],
    skill_file: str | None = None,
    recommended: bool = False,
) -> list[MarketplaceSkill]:
    """List all skills available in a marketplace directory."""
    results: list[MarketplaceSkill] = []

    if fmt == "flat":
        # Flat: source_path/<name>/SKILL.md
        for child in sorted(source_path.iterdir()):
            if not child.is_dir():
                continue
            skill_md = child / "SKILL.md"
            if not skill_md.is_file():
                continue
            fm = _parse_frontmatter(skill_md)
            name = fm.get("name", child.name)
            results.append(
                MarketplaceSkill(
                    name=name,
                    description=fm.get("description", "")[:300],
                    source=source_id,
                    source_label=source_label,
                    plugin=name,
                    path=str(child),
                    installed=name in installed_names,
                    keywords=fm.get("metadata", {}).get("activation", {}).get("keywords", [])
                    or fm.get("metadata", {})
                    .get("praestoclaw", {})
                    .get("activation", {})
                    .get("keywords", []),
                    has_references=(child / "references").is_dir(),
                )
            )

    elif fmt == "plugin":
        # Plugin: source_path/<plugin>/skills/<sub>/SKILL.md
        for plugin_dir in sorted(source_path.iterdir()):
            if not plugin_dir.is_dir():
                continue
            skills_dir = plugin_dir / "skills"
            # Check for a single top-level SKILL.md (some plugins use this)
            top_skill = plugin_dir / "SKILL.md"
            if top_skill.is_file() and not skills_dir.is_dir():
                fm = _parse_frontmatter(top_skill)
                name = fm.get("name", plugin_dir.name)
                results.append(
                    MarketplaceSkill(
                        name=name,
                        description=fm.get("description", "")[:300],
                        source=source_id,
                        source_label=source_label,
                        plugin=plugin_dir.name,
                        path=str(plugin_dir),
                        installed=name in installed_names,
                        keywords=_extract_keywords(fm),
                        has_references=(plugin_dir / "references").is_dir(),
                    )
                )
                continue

            if not skills_dir.is_dir():
                continue

            # Get plugin-level description from README.md
            plugin_desc = ""
            readme = plugin_dir / "README.md"
            if readme.is_file():
                plugin_desc = _extract_description(readme)

            sub_skills = list(skills_dir.iterdir())
            if len(sub_skills) == 1 and sub_skills[0].is_dir():
                # Single sub-skill — use plugin name
                sub = sub_skills[0]
                skill_md = sub / "SKILL.md"
                if skill_md.is_file():
                    fm = _parse_frontmatter(skill_md)
                    name = plugin_dir.name  # Use plugin name for single-skill plugins
                    desc = fm.get("description", plugin_desc)
                    results.append(
                        MarketplaceSkill(
                            name=name,
                            description=desc[:300],
                            source=source_id,
                            source_label=source_label,
                            plugin=plugin_dir.name,
                            path=str(sub),
                            installed=name in installed_names,
                            keywords=_extract_keywords(fm),
                            has_references=(sub / "references").is_dir(),
                        )
                    )
            else:
                # Multiple sub-skills — prefix with plugin name
                for sub in sorted(sub_skills):
                    if not sub.is_dir():
                        continue
                    skill_md = sub / "SKILL.md"
                    if not skill_md.is_file():
                        continue
                    fm = _parse_frontmatter(skill_md)
                    sub_name = fm.get("name", sub.name)
                    name = f"{plugin_dir.name}/{sub_name}"
                    results.append(
                        MarketplaceSkill(
                            name=name,
                            description=fm.get("description", "")[:300],
                            source=source_id,
                            source_label=source_label,
                            plugin=plugin_dir.name,
                            path=str(sub),
                            installed=name in installed_names,
                            keywords=_extract_keywords(fm),
                            has_references=(sub / "references").is_dir(),
                        )
                    )

    elif fmt == "single":
        # Single: the source_path IS the skill directory
        skill_md = source_path / "SKILL.md"
        if not skill_md.is_file() and skill_file:
            alt = source_path / skill_file
            if alt.is_file():
                skill_md = alt
        if skill_md.is_file():
            fm = _parse_frontmatter(skill_md)
            name = fm.get("name", source_path.name)
            results.append(
                MarketplaceSkill(
                    name=name,
                    description=fm.get("description", "")[:300],
                    source=source_id,
                    source_label=source_label,
                    plugin=name,
                    path=str(source_path),
                    installed=name in installed_names,
                    keywords=_extract_keywords(fm),
                    has_references=(source_path / "references").is_dir(),
                    recommended=recommended,
                )
            )

    return results


def _extract_keywords(fm: dict) -> list[str]:
    """Extract keywords from frontmatter metadata (supports both flat and namespaced)."""
    meta = fm.get("metadata", {})
    wp = meta.get("praestoclaw", meta)
    act = wp.get("activation", {})
    keywords = act.get("keywords", [])
    return list(keywords) if isinstance(keywords, list) else []


def install_skill(
    skill: MarketplaceSkill,
    install_dir: Path,
    *,
    marketplace_root: Path | None = None,
    skill_file: str | None = None,
) -> Path:
    """Install a marketplace skill by copying it into the user skills directory.

    Returns the installed path.
    """
    install_dir.mkdir(parents=True, exist_ok=True)

    safe_name = _safe_skill_dirname(skill.name)
    install_dir_resolved = install_dir.resolve()
    dest = install_dir / safe_name
    # Verify dest stays inside install_dir after resolution
    try:
        dest_resolved = dest.resolve()
    except OSError as exc:
        raise ValueError(f"Invalid install destination for {skill.name!r}") from exc
    if not (
        dest_resolved == install_dir_resolved
        or _is_relative_to(dest_resolved, install_dir_resolved)
    ):
        raise ValueError(f"Install destination escapes skills directory: {dest_resolved}")

    source = Path(skill.path)
    if not source.exists():
        raise FileNotFoundError(f"Skill source not found: {source}")
    source_resolved = source.resolve()
    if not source_resolved.is_dir():
        raise NotADirectoryError(f"Skill source is not a directory: {source}")
    if marketplace_root is not None:
        mp_resolved = marketplace_root.resolve()
        if not _is_relative_to(source_resolved, mp_resolved):
            raise ValueError(
                f"Skill source {source_resolved} is outside marketplace root {mp_resolved}"
            )

    # If dest exists, decide based on metadata
    if dest.exists():
        meta = _read_install_metadata(dest)
        if meta is None:
            raise FileExistsError(
                f"Cannot install: {dest} already exists and is not a marketplace skill. "
                "Remove it manually if you want to install this skill."
            )
        if meta.get("name") != skill.name or meta.get("source") != skill.source:
            raise FileExistsError(
                f"Cannot install: {dest} is already used by "
                f"{meta.get('source')}::{meta.get('name')}."
            )
        shutil.rmtree(dest)

    shutil.copytree(
        source,
        dest,
        symlinks=True,
        ignore=shutil.ignore_patterns(".git", ".git/*", "__pycache__", "*.pyc", ".DS_Store"),
    )
    # Ensure SKILL.md exists (rename lowercase variant if needed)
    skill_md_upper = dest / "SKILL.md"
    if not skill_md_upper.is_file() and skill_file:
        alt = dest / skill_file
        if alt.is_file():
            shutil.copy2(alt, skill_md_upper)

    _write_install_metadata(
        dest,
        {
            "name": skill.name,
            "source": skill.source,
            "source_label": skill.source_label,
            "installed_at": datetime.now(UTC).isoformat(),
        },
    )

    logger.info("Installed skill '{}' from {} to {}", skill.name, skill.source, dest)
    return dest


def uninstall_skill(name: str, install_dir: Path) -> bool:
    """Remove an installed marketplace skill. Returns True if removed.

    Refuses to remove directories that do not have a ``.marketplace.json``
    metadata file (i.e. skills the user authored or installed manually).
    """
    safe_name = _safe_skill_dirname(name)
    install_dir_resolved = install_dir.resolve()
    dest = install_dir / safe_name
    try:
        dest_resolved = dest.resolve()
    except OSError:
        return False
    if not _is_relative_to(dest_resolved, install_dir_resolved):
        raise ValueError(f"Uninstall target escapes skills directory: {dest_resolved}")
    if not (dest.exists() and dest.is_dir()):
        return False
    if _read_install_metadata(dest) is None:
        raise ValueError(
            f"Refusing to remove {dest}: not a marketplace-installed skill "
            f"(missing {_METADATA_FILE})."
        )
    shutil.rmtree(dest)
    logger.info("Uninstalled skill '{}'", name)
    return True


def _is_relative_to(path: Path, other: Path) -> bool:
    try:
        path.relative_to(other)
        return True
    except ValueError:
        return False


def _read_install_metadata(dest: Path) -> dict | None:
    meta_file = dest / _METADATA_FILE
    if not meta_file.is_file():
        return None
    try:
        data = json.loads(meta_file.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _write_install_metadata(dest: Path, meta: dict) -> None:
    (dest / _METADATA_FILE).write_text(
        json.dumps(meta, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def get_install_dir() -> Path:
    """Return the user skills installation directory."""
    from praestoclaw.utils.helpers import get_data_dir

    return get_data_dir() / "skills"


def get_installed_skill_names(install_dir: Path) -> set[str]:
    """Return names of skills installed via the marketplace.

    Only directories containing a ``.marketplace.json`` metadata file are
    considered marketplace-managed. The name returned is taken from the
    metadata (preserving the original ``plugin/sub`` form).
    """
    names: set[str] = set()
    if not install_dir.is_dir():
        return names
    for child in install_dir.iterdir():
        if not child.is_dir():
            continue
        if not (child / "SKILL.md").is_file():
            continue
        meta = _read_install_metadata(child)
        if meta is None:
            continue
        name = meta.get("name")
        if isinstance(name, str) and name:
            names.add(name)
    return names


# ── Built-in marketplace sources ───────────────────────────────────────────


@dataclass
class BuiltinMarketplace:
    """A built-in marketplace source that can be cloned from GitHub during init."""

    id: str
    label: str
    repo: str  # GitHub owner/name
    subpath: str  # path under the repo to use as marketplace root
    format: str  # "flat", "plugin", or "single"
    description: str
    recommended: bool = False
    skill_file: str | None = None  # override for case-insensitive skill file (e.g. "skill.md")


BUILTIN_MARKETPLACES: list[BuiltinMarketplace] = [
    BuiltinMarketplace(
        id="microsoft-skills",
        label="Microsoft Skills Marketplace",
        repo="gim-home/microsoft_skills_marketplace",
        subpath="skills",
        format="flat",
        description="Office docs (docx/xlsx/pptx/pdf), Edge dev & Git workflows (~22 skills)",
    ),
    BuiltinMarketplace(
        id="edge-agents",
        label="Edge Agents",
        repo="edge-microsoft/edge-agents",
        subpath="plugins",
        format="plugin",
        description="Edge/Chromium dev, ADO, debugging, PR/CR automation (~210 skills)",
    ),
    BuiltinMarketplace(
        id="opc",
        label="One Person Company",
        repo="iamtouchskyer/opc",
        subpath=".",
        format="single",
        description="Full AI team with digraph pipeline, 16+ specialist roles, quality gates",
        recommended=True,
        skill_file="skill.md",
    ),
]


def get_marketplace_cache_dir() -> Path:
    """Return the directory where cloned marketplace repos live."""
    from praestoclaw.utils.helpers import get_data_dir

    return get_data_dir() / "marketplaces"


def clone_or_update_github_repo(
    repo: str,
    cache_dir: Path,
    *,
    ref: str | None = None,
    timeout: int = 180,
) -> Path:
    """Clone a GitHub repo into ``cache_dir/<safe-name>`` or ``git pull`` if present.

    ``repo`` is ``owner/name``. Returns the local clone path. Raises
    ``RuntimeError`` with a clear message on failure.
    """
    import shutil as _shutil
    import subprocess

    if _shutil.which("git") is None:
        raise RuntimeError("git is not installed. Install git and try again.")

    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repo):
        raise ValueError(f"Invalid repo spec: {repo!r} (expected 'owner/name')")

    cache_dir.mkdir(parents=True, exist_ok=True)
    safe_dir = repo.replace("/", "__")
    dest = cache_dir / safe_dir
    url = f"https://github.com/{repo}.git"

    if (dest / ".git").is_dir():
        cmd = ["git", "-C", str(dest), "pull", "--ff-only", "--depth", "1"]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if result.returncode != 0:
            raise RuntimeError(
                f"git pull failed for {repo}: {result.stderr.strip() or result.stdout.strip()}"
            )
        logger.info("Updated marketplace repo {} at {}", repo, dest)
    else:
        cmd = ["git", "clone", "--depth", "1"]
        if ref:
            cmd += ["--branch", ref]
        cmd += [url, str(dest)]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if result.returncode != 0:
            raise RuntimeError(
                f"git clone failed for {repo}: {result.stderr.strip() or result.stdout.strip()}"
            )
        logger.info("Cloned marketplace repo {} to {}", repo, dest)

    return dest


def bulk_install_from_source(
    source_path: Path,
    source_id: str,
    source_label: str,
    fmt: str,
    install_dir: Path,
    *,
    skill_file: str | None = None,
    recommended: bool = False,
) -> tuple[int, int, list[tuple[str, str]]]:
    """Install every skill found under ``source_path``.

    Returns ``(installed, skipped, errors)`` where ``errors`` is a list of
    ``(skill_name, message)`` tuples. Skills that are already installed from
    the same source are re-installed (upgrade path). Skills whose target
    directory is occupied by a user-authored skill are skipped with an error.
    """
    resolved_fmt = fmt if fmt in ("flat", "plugin", "single") else detect_format(source_path)
    skills = list_marketplace_skills(
        source_path,
        source_id,
        source_label,
        resolved_fmt,
        installed_names=set(),
        skill_file=skill_file,
        recommended=recommended,
    )
    installed = 0
    skipped = 0
    errors: list[tuple[str, str]] = []
    for skill in skills:
        try:
            install_skill(skill, install_dir, marketplace_root=source_path, skill_file=skill_file)
            installed += 1
        except FileExistsError as exc:
            skipped += 1
            errors.append((skill.name, str(exc)))
        except (ValueError, FileNotFoundError, NotADirectoryError, OSError) as exc:
            errors.append((skill.name, str(exc)))
    return installed, skipped, errors
