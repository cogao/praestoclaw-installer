"""Init CLI command — praestoclaw init."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

import typer
from rich.panel import Panel
from rich.table import Table

from praestoclaw.cli.commands import (
    app,
    console,
)

_TOTAL_STEPS = 6


# ── Modern interactive selection ──────────────────────────────────────────────


def _step_header(n: int, label: str) -> None:
    """Print step header: ``[1/5] Label``."""
    console.print(f"\n[bold cyan][{n}/{_TOTAL_STEPS}][/bold cyan] [bold]{label}[/bold]")


def _step_done(value: str) -> None:
    """Print a completed step result with green checkmark."""
    console.print(f"  [green]+[/green] {value}")


def _is_tty() -> bool:
    """Return True if running in a real terminal (not piped/test)."""
    from praestoclaw.utils.input import is_tty

    return is_tty()


def _read_key() -> str:
    """Read a single keypress. Returns ``'up'``, ``'down'``, ``'enter'``, or the character."""
    from praestoclaw.utils.input import read_key_blocking

    return read_key_blocking()


def _select(
    options: list[tuple[str, str]],
    *,
    default: int = 1,
) -> int:
    """Show a selection menu and return the 1-based chosen index.

    Uses arrow-key navigation in a real terminal. Falls back to numbered
    input in non-TTY environments (tests, piped stdin).
    """
    if _is_tty():
        try:
            return _select_arrows(options, default=default - 1) + 1
        except Exception:
            pass
    return _select_numbered(options, default=default)


def _select_arrows(
    options: list[tuple[str, str]],
    *,
    default: int = 0,
) -> int:
    """Inline arrow-key radio selector. Returns 0-based index.

    Renders options with ``*`` / ``o`` markers, then erases itself
    after the user presses Enter — leaving the cursor right below the
    step header so the caller can print a result line.
    """
    cur = default
    n = len(options)
    max_label = max(len(label) for label, _ in options)
    # lines rendered: blank + n options + blank + hint = n + 3
    total_lines = n + 3

    def _render(first: bool = False) -> None:
        out = sys.stdout
        if not first:
            out.write(f"\033[{total_lines}A")
        out.write("\n")
        for i, (label, desc) in enumerate(options):
            pad = label.ljust(max_label)
            if i == cur:
                line = f"  \033[36m*\033[0m \033[1m{pad}\033[0m"
            else:
                line = f"  \033[90mo {pad}\033[0m"
            if desc:
                line += f"  \033[90m\u2014 {desc}\033[0m"
            out.write(f"\033[2K{line}\n")
        out.write("\n\033[2K  \033[2;90mUp/Down switch  Enter confirm  Esc skip\033[0m\n")
        out.flush()

    sys.stdout.write("\033[?25l")  # hide cursor
    try:
        _render(first=True)
        while True:
            key = _read_key()
            if key in ("up", "k"):
                cur = (cur - 1) % n
                _render()
            elif key in ("down", "j"):
                cur = (cur + 1) % n
                _render()
            elif key == "enter":
                # Erase the rendered menu
                sys.stdout.write(f"\033[{total_lines}A")
                for _ in range(total_lines):
                    sys.stdout.write("\033[2K\n")
                sys.stdout.write(f"\033[{total_lines}A")
                sys.stdout.flush()
                return cur
            elif key == "esc":
                # ESC = select last option (skip/default)
                cur = n - 1
                sys.stdout.write(f"\033[{total_lines}A")
                for _ in range(total_lines):
                    sys.stdout.write("\033[2K\n")
                sys.stdout.write(f"\033[{total_lines}A")
                sys.stdout.flush()
                return cur
            elif key.isdigit():
                idx = int(key) - 1
                if 0 <= idx < n:
                    cur = idx
                    _render()
    finally:
        sys.stdout.write("\033[?25h\033[0m")  # show cursor, reset attrs
        sys.stdout.flush()


def _select_numbered(
    options: list[tuple[str, str]],
    *,
    default: int = 1,
) -> int:
    """Numbered fallback for non-TTY (tests, piped input). Returns 1-based index."""
    for i, (label, desc) in enumerate(options, 1):
        marker = " *" if i == default else ""
        if desc:
            console.print(f"  [bold]{i}.[/bold] {label}  [dim]\u2014 {desc}[/dim]{marker}")
        else:
            console.print(f"  [bold]{i}.[/bold] {label}{marker}")
    while True:
        raw = typer.prompt(f"Select [1-{len(options)}]", default=str(default))
        try:
            choice = int(raw)
            if 1 <= choice <= len(options):
                return choice
        except ValueError:
            pass
        console.print(f"  [yellow]Please enter 1\u2013{len(options)}[/yellow]")


# ── Utilities ─────────────────────────────────────────────────────────────────


def _check_connectivity() -> bool:
    """Return True if github.com is reachable (quick HEAD check)."""
    try:
        import httpx

        with httpx.Client(timeout=5) as http:
            resp = http.head("https://github.com")
            return resp.status_code < 500
    except Exception:
        return False


def _skill_marketplace_setup(local_config: dict[str, Any], *, quick: bool) -> dict[str, Any]:
    """Clone & bulk-install built-in skill marketplaces.

    Registers the cloned repos under ``skills.marketplaces`` in *local_config*
    so the Portal UI can manage them afterwards. Returns a summary dict:
    ``{source_id: {"installed": int, "skipped": int, "errors": int}}``.
    """
    import shutil as _shutil

    from praestoclaw.skills.marketplace import (
        BUILTIN_MARKETPLACES,
        bulk_install_from_source,
        clone_or_update_github_repo,
        get_install_dir,
        get_marketplace_cache_dir,
    )

    summary: dict[str, Any] = {}

    # Build option labels
    options: list[tuple[str, str]] = [
        ("Install all", "clone all repos and install ~230+ skills (recommended)"),
        ("Microsoft Skills only", "Office docs, Edge dev & Git workflows (~22 skills)"),
        ("Edge Agents only", "Edge/Chromium dev, ADO, PR/CR automation (~210 skills)"),
        ("Recommended only", "curated picks: OPC and other recommended skills"),
        ("Skip", "configure later via 'wp' Portal > Skills > Marketplace"),
    ]

    if quick:
        # Quick mode: skip (requires network + disk). User can run later.
        console.print("\n[bold cyan][6/6][/bold cyan] [bold]Skill Marketplace[/bold]")
        console.print("  [dim]Skipped in quick mode. Install later via Portal.[/dim]")
        return summary

    _step_header(6, "Skill Marketplace (optional)")
    console.print(
        "  [dim]Pre-install skill bundles from GitHub to extend agent capabilities.[/dim]"
    )

    if _shutil.which("git") is None:
        console.print("  [yellow]git not found \u2014 skipping marketplace install.[/yellow]")
        return summary

    if not _is_tty():
        console.print(
            "  [dim]Non-interactive mode \u2014 skipping. "
            "Run later via [cyan]wp[/cyan] Portal > Skills > Marketplace.[/dim]"
        )
        return summary

    choice = _select(options, default=1)
    if choice == 5:
        _step_done("skipped")
        return summary

    selected_ids: set[str] = set()
    if choice == 1:
        selected_ids = {m.id for m in BUILTIN_MARKETPLACES}
    elif choice == 2:
        selected_ids = {"microsoft-skills"}
    elif choice == 3:
        selected_ids = {"edge-agents"}
    elif choice == 4:
        selected_ids = {m.id for m in BUILTIN_MARKETPLACES if m.recommended}

    cache_dir = get_marketplace_cache_dir()
    install_dir = get_install_dir()
    mp_section = local_config.setdefault("skills", {}).setdefault("marketplaces", {})

    for m in BUILTIN_MARKETPLACES:
        if m.id not in selected_ids:
            continue
        console.print(f"  [dim]-> {m.label} ({m.repo})[/dim]")
        try:
            repo_path = clone_or_update_github_repo(m.repo, cache_dir)
        except Exception as exc:
            console.print(f"    [red]clone failed:[/red] {exc}")
            summary[m.id] = {"installed": 0, "skipped": 0, "errors": 1}
            continue

        source_path = repo_path / m.subpath if m.subpath else repo_path
        if not source_path.is_dir():
            console.print(
                f"    [yellow]expected path not found:[/yellow] {source_path} "
                "(skipping install; you can reconfigure in praestoclaw.local.yaml)"
            )
            summary[m.id] = {"installed": 0, "skipped": 0, "errors": 1}
            # still register the marketplace pointing at repo root
            source_path = repo_path

        installed, skipped, errors = bulk_install_from_source(
            source_path,
            m.id,
            m.label,
            m.format,
            install_dir,
            skill_file=m.skill_file,
            recommended=m.recommended,
        )
        console.print(
            f"    [green]installed:[/green] {installed}  "
            f"[yellow]skipped:[/yellow] {skipped}  "
            f"[red]errors:[/red] {len(errors)}"
        )
        if errors and len(errors) <= 3:
            for n, msg in errors:
                console.print(f"      [dim]- {n}: {msg[:120]}[/dim]")
        summary[m.id] = {
            "installed": installed,
            "skipped": skipped,
            "errors": len(errors),
        }

        # Register in config so Portal UI can manage it
        mp_section[m.id] = {
            "label": m.label,
            "path": str(source_path),
            "format": m.format,
        }

    total_installed = sum(v.get("installed", 0) for v in summary.values())
    _step_done(f"{total_installed} skill(s) installed from {len(summary)} source(s)")

    return summary


def _show_environment(shutil: Any) -> None:
    """Detect and display installed tools during init."""
    import platform

    tools = ["git", "gh", "node", "az", "claude"]

    detected: list[str] = []
    for tool_name in tools:
        if shutil.which(tool_name):
            detected.append(f"[green]{tool_name}[/green]")

    plat = f"{platform.system()} {platform.machine()}"
    console.print(f"[bold]Environment:[/bold] {plat}\n[bold]Tools:[/bold] {', '.join(detected)}\n")


def _detect_github_context() -> tuple[bool, list[str]]:
    """Detect whether the user likely uses GitHub.

    Returns ``(is_developer, reasons)`` where *reasons* lists what was found.
    """
    import shutil

    reasons: list[str] = []

    # 1. git / gh CLI installed
    if shutil.which("git"):
        reasons.append("git installed")
    if shutil.which("gh"):
        reasons.append("gh CLI installed")

    # 2. GITHUB_TOKEN set
    if os.environ.get("GITHUB_TOKEN"):
        reasons.append("$GITHUB_TOKEN set")

    # 3. gh auth token available (check even if git/gh CLI found)
    if not any("gh CLI" in r for r in reasons):
        try:
            import subprocess

            r = subprocess.run(["gh", "auth", "token"], capture_output=True, text=True, timeout=5)
            if r.returncode == 0 and r.stdout.strip():
                reasons.append("gh auth token available")
        except Exception:
            pass

    # 4. .git in cwd or parents
    cwd = Path.cwd()
    for p in [cwd, *cwd.parents]:
        if (p / ".git").exists():
            reasons.append(f".git found in {p}")
            break
        if p == p.parent:
            break

    # 5. Dev project files in cwd
    dev_files = ["package.json", "pyproject.toml", "Cargo.toml", "go.mod", "pom.xml", "Makefile"]
    for f in dev_files:
        if (cwd / f).exists():
            reasons.append(f"{f} in cwd")
            break

    # 6. ~/.gitconfig
    if (Path.home() / ".gitconfig").exists():
        reasons.append("~/.gitconfig exists")

    return bool(reasons), reasons


def _cloud_login_if_needed() -> None:
    """If cloud is enabled but no MSAL account is cached, run the login menu.

    Called during ``init`` so the user can authenticate before first use.
    Uses ``load_config(".")`` which merges bundled defaults + existing local
    yaml.  The bundled defaults always define url/tenant_id/client_id, so
    this works even before the updated local yaml is saved to disk.
    """
    from praestoclaw.config.loader import load_config
    from praestoclaw.mcp.auth import has_msal_account

    try:
        cfg = load_config(".")
    except Exception:
        return

    cloud_cfg = cfg.channels.cloud
    if not cloud_cfg.url or not cloud_cfg.tenant_id or not cloud_cfg.client_id:
        return
    if not cloud_cfg.scope:
        cloud_cfg.scope = f"{cloud_cfg.client_id}/.default"

    # Check primary and shared app caches — skip if either has a cached account.
    if has_msal_account(cloud_cfg.client_id):
        console.print("  [green]+[/green] Already signed in")
        return
    from praestoclaw.mcp.defaults import SHARED_ENTRA_CLIENT_ID

    if has_msal_account(SHARED_ENTRA_CLIENT_ID):
        console.print("  [green]+[/green] Already signed in")
        return

    # No cached account — show login menu (it has its own privacy hint).
    try:
        from praestoclaw.utils.auth import interactive_cloud_login

        interactive_cloud_login(
            tenant_id=cloud_cfg.tenant_id,
            client_id=cloud_cfg.client_id,
            scope=cloud_cfg.scope,
            login_port=cloud_cfg.login_port,
        )
    except RuntimeError as exc:
        if "skipped" in str(exc).lower():
            console.print("  [dim]Cloud sign-in skipped.[/dim]")
        else:
            console.print(f"  [yellow]Warning:[/yellow] Cloud sign-in failed: {exc}")
    except KeyboardInterrupt:
        console.print("  [dim]Cloud sign-in skipped.[/dim]")
    except Exception as exc:
        console.print(f"  [yellow]Warning:[/yellow] Cloud sign-in failed: {exc}")


# ── Main init command ─────────────────────────────────────────────────────────


@app.command()
def init(
    directory: str | None = typer.Option(
        None, "--dir", "-d", help="Target directory (default: ~/.praestoclaw)"
    ),
    name: str | None = typer.Option(
        None, "--name", "-n", help="Project name (sets top-level 'name' in config)"
    ),
    quick: bool = typer.Option(False, "--quick", "-q", help="Accept all defaults, no prompts"),
) -> None:
    """Create or update the local config override (praestoclaw.local.yaml).

    By default this writes to ``~/.praestoclaw/praestoclaw.local.yaml``.
    Safe to run multiple times \u2014 existing values are shown as defaults
    so you only change what you want. Use --quick to accept all defaults.
    """
    import shutil

    import yaml

    from praestoclaw.utils.helpers import get_data_dir

    dir_path = get_data_dir() if directory is None else Path(directory).resolve()
    dir_path.mkdir(parents=True, exist_ok=True)

    local_path = dir_path / "praestoclaw.local.yaml"

    # Load existing config to use as defaults
    existing: dict = {}
    is_update = local_path.exists()
    if is_update:
        try:
            loaded = yaml.safe_load(local_path.read_text(encoding="utf-8"))
            existing = loaded if isinstance(loaded, dict) else {}
        except Exception:
            existing = {}

    # ── Environment detection ─────────────────────────────────────────
    _show_environment(shutil)

    if quick:
        console.print("[dim]--quick mode: accepting all defaults[/dim]\n")
    else:
        action = "Update" if is_update else "Create"
        console.print(
            Panel(
                f"[bold]PraestoClaw Setup[/bold]\n\n"
                f"{'Updating' if is_update else 'Creating'} [cyan]{local_path}[/cyan]",
                title=f"{action} praestoclaw.local.yaml",
                border_style="blue",
            )
        )

    # ── [1/5] GitHub token ────────────────────────────────────────────
    raw_token: str = (existing.get("providers") or {}).get("github_copilot", {}).get(
        "token", ""
    ) or ""
    # A SECRET[…] or ${…} reference means a token is configured but resolved at runtime.
    has_configured_token = bool(raw_token)
    current_token = "" if raw_token.startswith(("${", "SECRET[")) else raw_token

    github_token: str | None = None
    if quick:
        if raw_token:
            # Preserve existing token reference (SECRET[…] / ${…} / plaintext) as-is
            github_token = None
        else:
            env_token = os.environ.get("GITHUB_TOKEN")
            if env_token:
                console.print(
                    "[yellow]Note:[/yellow] Using $GITHUB_TOKEN from environment (plaintext).\n"
                    "  For better security, run:"
                    " [bold]wp secrets set GITHUB_COPILOT_TOKEN[/bold]"
                )
                github_token = env_token
            else:
                # No token configured and no env var — run interactive device-code login.
                # This is the one step that cannot be "defaulted away" in quick mode.
                _step_header(1, "GitHub Copilot (LLM Provider)")
                console.print("  [dim]PraestoClaw uses GitHub Copilot as its AI engine.[/dim]")
                with console.status("[bold cyan]Checking connectivity\u2026"):
                    online = _check_connectivity()
                if online:
                    from praestoclaw.security.github_auth import github_device_login

                    try:
                        github_token = github_device_login(console=console)
                    except Exception as exc:
                        console.print(f"  [yellow]GitHub sign-in failed:[/yellow] {exc}")
                else:
                    console.print(
                        "  [yellow]Cannot reach github.com \u2014 skipping GitHub auth.[/yellow]\n"
                        "  Run [bold]praestoclaw init[/bold] again when online."
                    )
    elif current_token:
        _step_header(1, "GitHub Copilot (LLM Provider)")
        console.print("  [dim]PraestoClaw uses GitHub Copilot as its AI engine.[/dim]")
        _GH_REAUTH_OPTS: list[tuple[str, str]] = [
            ("Keep current token", f"{current_token[:8]}..."),
            ("Re-authenticate with GitHub", "opens browser, paste a code to authorize"),
        ]
        choice = _select(_GH_REAUTH_OPTS, default=1)
        _step_done(_GH_REAUTH_OPTS[choice - 1][0])
        if choice == 2:
            with console.status("[bold cyan]Checking connectivity\u2026"):
                online = _check_connectivity()
            if online:
                from praestoclaw.security.github_auth import github_device_login

                try:
                    github_token = github_device_login(console=console)
                except Exception as exc:
                    console.print(f"  [yellow]GitHub sign-in failed:[/yellow] {exc}")
                    github_token = current_token
            else:
                console.print(
                    "  [yellow]Cannot reach github.com \u2014 keeping current token[/yellow]"
                )
                github_token = current_token
        else:
            github_token = current_token
    else:
        _step_header(1, "GitHub Copilot (LLM Provider)")
        console.print("  [dim]PraestoClaw uses GitHub Copilot as its AI engine.[/dim]")
        if has_configured_token:
            if raw_token.startswith("SECRET["):
                _skip_desc = "already configured (SecretStore)"
            elif raw_token.startswith("${"):
                _skip_desc = "already configured (environment variable)"
            else:
                _skip_desc = "already configured"
        else:
            _skip_desc = "configure later"
        _GH_NEW_OPTS: list[tuple[str, str]] = [
            ("Sign in with GitHub", "opens browser, paste a code to authorize"),
            ("Skip", _skip_desc),
        ]
        choice = _select(_GH_NEW_OPTS, default=2 if has_configured_token else 1)
        _step_done(_GH_NEW_OPTS[choice - 1][0])
        if choice == 1:
            with console.status("[bold cyan]Checking connectivity\u2026"):
                online = _check_connectivity()
            if online:
                from praestoclaw.security.github_auth import github_device_login

                try:
                    github_token = github_device_login(console=console)
                except Exception as exc:
                    console.print(f"  [yellow]GitHub sign-in failed:[/yellow] {exc}")
            else:
                console.print(
                    "  [yellow]Cannot reach github.com \u2014 skipping GitHub auth.[/yellow]\n"
                    "  Run [bold]wp init[/bold] again when online."
                )
        # choice == 2: skip, github_token stays None

    # ── [2/5] Security profile ────────────────────────────────────────
    _PROFILES: list[tuple[str, str]] = [
        ("open", "AI runs freely, no confirmations needed"),
        ("standard", "AI asks before risky actions (recommended)"),
        ("controlled", "AI asks before most actions"),
        ("restricted", "AI asks before every action"),
    ]
    _PROFILE_NAMES = [p[0] for p in _PROFILES]

    current_profile: str = (existing.get("security") or {}).get("profile", "standard") or "standard"
    if quick:
        security_profile = current_profile
    else:
        _step_header(2, "Security Profile")
        console.print("  [dim]Controls how much autonomy the AI agent has.[/dim]")
        default_idx = (
            (_PROFILE_NAMES.index(current_profile) + 1) if current_profile in _PROFILE_NAMES else 2
        )
        choice = _select(_PROFILES, default=default_idx)
        security_profile = _PROFILE_NAMES[choice - 1]
        _step_done(security_profile)

    # ── [3/5] Web channel (web server) ────────────────────────────────
    current_gw: dict = (existing.get("channels") or {}).get("web") or existing.get("gateway") or {}
    current_gw_enabled: bool = bool(current_gw.get("enabled", True))
    if quick:
        enable_web = current_gw_enabled
    else:
        web_port = current_gw.get("port", 3004)
        _step_header(3, f"Web UI (localhost:{web_port})")
        console.print(f"  [dim]A local web chat interface at http://localhost:{web_port}[/dim]")
        _WEB_OPTS: list[tuple[str, str]] = [
            ("Enable", "access PraestoClaw from your browser"),
            ("Disable", "CLI only, no web interface"),
        ]
        choice = _select(_WEB_OPTS, default=1 if current_gw_enabled else 2)
        enable_web = choice == 1
        _step_done("enabled" if enable_web else "disabled")

    # ── [4/5] Cloud channel (Teams, Web Chat) ─────────────────────────
    current_cloud: dict = (existing.get("channels") or {}).get("cloud") or {}
    current_cloud_enabled: bool = bool(current_cloud.get("enabled", True))
    if quick:
        enable_cloud = current_cloud_enabled
    else:
        _step_header(4, "Cloud Connection (Teams, Web Chat)")
        console.print("  [dim]Connect to Microsoft Teams and Web Chat via cloud relay.[/dim]")
        _CLOUD_OPTS: list[tuple[str, str]] = [
            ("Enable", "chat with PraestoClaw from Teams or browser"),
            ("Disable", "local only, no cloud connection"),
        ]
        choice = _select(_CLOUD_OPTS, default=1 if current_cloud_enabled else 2)
        enable_cloud = choice == 1
        _step_done("enabled" if enable_cloud else "disabled")

    # Sub-steps when cloud is enabled (not quick).
    if enable_cloud and not quick:
        pass  # 4.1 Cloud sign-in and 4.2 Teams app run after config write below.

    # ── Build config (deep-merge: preserve existing keys, update changed ones) ──
    local_config: dict = dict(existing)  # start from existing

    if name:
        local_config["name"] = name

    local_config.setdefault("providers", {}).setdefault("github_copilot", {})
    if github_token and not github_token.startswith("${"):
        # New real token — store in SecretStore, write reference in YAML
        try:
            from praestoclaw.security.secrets import set_secret

            set_secret("GITHUB_COPILOT_TOKEN", github_token)
            local_config["providers"]["github_copilot"]["token"] = "SECRET[GITHUB_COPILOT_TOKEN]"
            console.print("  [green]+[/green] Token stored in SecretStore")
        except Exception as exc:
            console.print(
                f"  [yellow]Warning:[/yellow] SecretStore unavailable ({exc}).\n"
                "  Token will be stored as plaintext in praestoclaw.local.yaml."
            )
            local_config["providers"]["github_copilot"]["token"] = github_token
    elif github_token:
        # Explicit "${GITHUB_TOKEN}" env-var reference
        local_config["providers"]["github_copilot"]["token"] = github_token
    elif raw_token:
        # User skipped — preserve existing reference (SECRET[…] / ${…} / plaintext)
        local_config["providers"]["github_copilot"]["token"] = raw_token
    else:
        # No token at all — fallback to env-var reference
        local_config["providers"]["github_copilot"]["token"] = "${GITHUB_TOKEN}"

    local_config.setdefault("security", {})
    local_config["security"]["profile"] = security_profile

    local_config.setdefault("logging", {"level": "INFO", "format": "pretty"})

    gw = local_config.setdefault("channels", {}).setdefault("web", {})
    gw["enabled"] = enable_web
    if enable_web:
        gw.setdefault("host", "localhost")
        gw.setdefault("port", current_gw.get("port", 3004))

    cloud = local_config.setdefault("channels", {}).setdefault("cloud", {})
    cloud["enabled"] = enable_cloud

    # ── Cloud sub-steps (sign-in first, then Teams app) ────────────
    if enable_cloud and not quick:
        console.print("  [dim](4.1) Cloud sign-in[/dim]")
        _cloud_login_if_needed()

        console.print("  [dim](4.2) Teams app[/dim]")
        from praestoclaw.cli.teams import is_teams_installed

        if is_teams_installed():
            console.print("  [green]+[/green] Teams app already installed")
        elif not _is_tty():
            console.print(
                "  [dim]Teams app not detected; run"
                " [cyan]wp teams install[/cyan] to install it later.[/dim]"
            )
        else:
            console.print("  [dim]Teams app not detected — starting sideload install...[/dim]")
            try:
                from praestoclaw.cli.teams import teams_install as _teams_install

                _teams_install(package=None, open_teams=False, quiet=True)
            except KeyboardInterrupt:
                console.print("  [dim]Teams install skipped by user.[/dim]")
            except typer.Exit as exc:
                if getattr(exc, "exit_code", 1) == 0:
                    console.print("  [dim]Teams install skipped.[/dim]")
                else:
                    console.print(
                        "  [yellow]Warning:[/yellow] Teams install failed;"
                        " cloud features may not work.\n"
                        "  [dim]Run [cyan]wp teams install[/cyan] to retry.[/dim]"
                    )
            except Exception as exc:
                # Network timeouts / API errors — don't abort the whole init.
                console.print(
                    f"  [yellow]Warning:[/yellow] Teams install error: "
                    f"{type(exc).__name__}: {str(exc)[:120]}\n"
                    "  [dim]Cloud features may not work. "
                    "Run [cyan]wp teams install[/cyan] to retry later.[/dim]"
                )

    # ── [5/6] MCP Servers ─────────────────────────────────────────────
    from praestoclaw.cli.mcp import _mcp_setup

    mcp_added: dict[str, Any] = {}
    if quick:
        mcp_added = _mcp_setup(dir_path, local_config, select_all=True, quick=True, step=5)
    else:
        _step_header(5, "MCP Servers (Teams, Mail, Calendar, ADO, \u2026)")
        mcp_added = _mcp_setup(dir_path, local_config, step=5)

    # ── [6/6] Skill Marketplace ───────────────────────────────────────
    skills_summary = _skill_marketplace_setup(local_config, quick=quick)

    from praestoclaw.config.loader import save_yaml

    header = (
        "# PraestoClaw local config override\n"
        "# This file is gitignored \u2014 use it for API keys, model preferences,\n"
        "# and local settings that should not be committed.\n"
        "# Values here are deep-merged on top of praestoclaw.yaml.\n"
        "\n"
    )
    save_yaml(local_path, local_config, header=header)

    verb = "Updated" if is_update else "Created"
    console.print(f"\n  [green]+[/green] [bold]{verb}[/bold] {local_path}")

    # ── Summary (especially useful for --quick mode) ──────────────────
    if quick:
        summary = Table(show_header=False, box=None, padding=(0, 2))
        summary.add_column(style="bold")
        summary.add_column()

        token_ref = local_config.get("providers", {}).get("github_copilot", {}).get("token", "")
        if token_ref == "SECRET[GITHUB_COPILOT_TOKEN]":
            provider_desc = "GitHub Copilot (SecretStore)"
        elif token_ref.startswith("${"):
            provider_desc = f"GitHub Copilot ({token_ref})"
        elif token_ref:
            provider_desc = "GitHub Copilot (token set)"
        else:
            provider_desc = "not configured"
        summary.add_row("Provider", provider_desc)
        summary.add_row("Profile", security_profile)
        web_port = gw.get("port", 3004)
        summary.add_row("Web UI", f"enabled (:{web_port})" if enable_web else "disabled")
        summary.add_row("Cloud", "enabled" if enable_cloud else "disabled")
        summary.add_row("MCP", f"{len(mcp_added)} server(s) added" if mcp_added else "none added")
        skills_total = sum(v.get("installed", 0) for v in (skills_summary or {}).values())
        summary.add_row(
            "Skills",
            f"{skills_total} installed from {len(skills_summary)} source(s)"
            if skills_summary
            else "none added",
        )

        console.print(Panel(summary, title="Quick Setup Summary", border_style="cyan"))

    # ── Completion ────────────────────────────────────────────────────
    console.print(
        Panel(
            "[bold]Next steps:[/bold]\n"
            "  pc s            \u2014 start the server\n"
            "  pc chat         \u2014 start chatting\n"
            "  pc doctor       \u2014 verify setup\n"
            "  pc mcp setup    \u2014 reconfigure MCP servers",
            title="* Setup Complete",
            border_style="green",
        )
    )


# Backward-compat alias (hidden, not in help)
app.command("onboard", hidden=True)(init)
