"""Praesto Tag Experiment — borrowed-identity capability gate.

EXPERIMENTAL / THROWAWAY. Pairs with the gateway/channel ``praesto_tag_exp``
glue (grep that prefix to see the whole experiment).

Context: in this mock the bot acts as a group's shared digital employee, but it
is physically backed by a *real* employee's agent — it borrows that employee's
identity and permissions. A real digital employee would have its own
permissions; until that exists we must not let the borrowed session silently
use permissions the lending employee never agreed to lend.

Policy (the gentleman's-mock trade-off):
  * Exposed built-ins — plan, group_memory, meeting_automation, teams_group_fetch,
    group_notify,
    team_knowledge_capture, kb_scope/kb_inspect/kb_change_history/kb_draft/kb_publish,
    attachment_process, feedback_submit, shell, spawn, tasks, web_fetch, and tools.
    ``feedback_submit`` fixes its GitHub repository and create label. It accepts
    in-memory title/body for create and session-owned comment/edit, plus explicit
    GitHub logins for additive assignment at creation or to a supplied real issue
    ID. Assignment uses the authenticated ``gh`` identity without another approval;
    it never targets PRs or grants comment/edit rights on an unowned issue.
    ``kb_scope`` lets the group pick *which* knowledge base it uses, but only from
    the operator's ``kb.repos`` allowlist — the choice is borrowed, the
    authorisation is not.
  * Personal/global MCP — ``m365-user`` exposes the organisation directory;
    ``calendar`` exposes its full tool set for prototype meeting workflows.
    The Teams MCP used to be exposed wholesale,
    which was never really defensible: its search tools accept no ``chatId`` at
    all, so the only thing keeping a borrowed turn inside the group that asked
    was the wording of a prompt. One date-scoped query was observed returning
    34 unrelated conversations from across the tenant while missing the meeting
    it was asked about. ``teams_group_fetch`` replaces it and is structurally
    incapable of leaving ``metadata["cid"]``. Group-owned MCP bindings use a
    separate per-chat namespace and expose only the current chat's tools.
    * Everything else is unavailable by default. An enabled, current-chat Group
      Skill may expose its declared ``safe-tools`` for the matching turn; every
      declared argument pattern is independently re-checked here before execution.
    * Skills — the independent ``skill`` lifecycle tool owns per-chat snapshots.
      Personal SkillLoader state is not visible or loadable through ``tools``.

This module only *classifies*; the ``ApprovalGate`` in ``hooks/handlers.py``
turns an ``"approve"`` classification into a real human-in-the-loop prompt.
"""

from __future__ import annotations

import re
from typing import Any

PRAESTO_TAG_EXP_METADATA_KEY = "praesto_tag_exp"

# Prefix marking an MCP-server-targeting ``tools`` meta-tool call (connecting a
# server can exercise the employee's agency creds, so it stays gated).
_MCP_PREFIX_FOR_GATE = "MCP_"

# Built-in tools exposed to a borrowed-identity group turn. Everything else is
# hidden from the model and rejected at the execution gate.
PRAESTO_TAG_EXP_ALLOWED_BUILTIN_TOOLS: frozenset[str] = frozenset(
    {
        "attachment_process",
        "feedback_submit",
        "feedback_context",
        "group_memory",
        "kb_change_history",
        "kb_draft",
        "kb_inspect",
        "kb_publish",
        "kb_scope",
        "meeting_automation",
        "mcp",
        "plan",
        "shell",
        "skill",
        "spawn",
        "tasks",
        "team_knowledge_capture",
        "teams_group_fetch",
        "group_notify",
        "tools",
        "web_fetch",
    }
)

# Built-ins reserved for this experiment's model-facing surface. They stay
# hidden on normal personal-agent turns even while the runtime keeps them
# registered for experiment groups and any internal scheduled callbacks.
# ``group_notify`` is intentionally absent: it is a general Teams group tool.
PRAESTO_TAG_EXP_ONLY_BUILTIN_TOOLS: frozenset[str] = frozenset(
    {
        "kb_change_history",
        "kb_draft",
        "kb_inspect",
        "kb_publish",
        "kb_scope",
        "meeting_automation",
        "mcp",
        "skill",
        "team_knowledge_capture",
        "teams_group_fetch",
    }
)

# Personal/global MCP servers exposed to the group turn, including all of each
# server's tools so calendar discovery and follow-up operations work together.
PRAESTO_TAG_EXP_ALLOWED_MCP_SERVERS: frozenset[str] = frozenset({"calendar", "m365-user"})

# Group skills are managed by the independent model-facing ``skill`` tool.
# Personal SkillLoader names are deliberately never admitted through ``tools``.
PRAESTO_TAG_EXP_ALLOWED_SKILLS: frozenset[str] = frozenset()

# Built-ins that are safe to run without borrowing additional personal-agent
# permissions. ``tools`` is handled separately because it manages both local
# tools and MCP server connections.
_PRAESTO_TAG_EXP_BORROWED_TOOLS = frozenset(
    {
        "attachment_process",
        "feedback_submit",
        "feedback_context",
        "group_memory",
        "kb_change_history",
        "kb_draft",
        "kb_inspect",
        "kb_publish",
        "kb_scope",
        "meeting_automation",
        "mcp",
        "plan",
        "shell",
        "skill",
        "spawn",
        "tasks",
        "team_knowledge_capture",
        "teams_group_fetch",
        "group_notify",
        "web_fetch",
    }
)

# Personal tools that must NOT surface in a borrowed-identity group turn: the
# shared employee persists facts via ``group_memory`` (the group's isolated local
# store), never the lending employee's private MEMORY.md / history. Canonical source shared by
# the loop (schema exclusion + prompt guidance) and the ``tools`` meta-tool (so
# it neither lists nor re-activates these behind the exclusion's back).
PRAESTO_TAG_EXP_PERSONAL_TOOLS: frozenset[str] = frozenset({"memory", "search_history"})

# A group skill may widen the current turn only. Keep agent control-plane and
# personal-state tools outside that extension even in this prototype. Shell is
# deliberately part of the default gentleman's-mock surface above.
PRAESTO_TAG_EXP_GROUP_SKILL_HARD_DENY: frozenset[str] = frozenset(
    {
        "config_praestoclaw",
        "cron",
        "memory",
        "notify",
        "search_history",
        "skill",
        "skill_manage",
        "tools",
    }
)

# Classification tokens returned to the gate.
PRAESTO_TAG_EXP_ALLOW = "allow"
PRAESTO_TAG_EXP_APPROVE = "approve"
PRAESTO_TAG_EXP_REJECT = "reject"


def praesto_tag_exp_is_active(metadata: dict[str, Any] | None) -> bool:
    """Whether the current turn is a praesto tag exp borrowed-identity turn."""
    return bool((metadata or {}).get(PRAESTO_TAG_EXP_METADATA_KEY))


def _mcp_server_and_raw(tool_name: str) -> tuple[str, str]:
    """Split an ``MCP_<server>_<tool>`` name into ``(server, raw_tool)`` lowered.

    Returns ``("", "")`` for non-MCP (built-in / host) tools.
    """
    if not tool_name or not tool_name.startswith("MCP_"):
        return "", ""
    rest = tool_name[len("MCP_") :]
    server, _, raw = rest.partition("_")
    return server.lower(), raw.lower()


def group_skill_safe_tool_matches(
    entries: list[dict[str, Any]] | None,
    tool_name: str,
    args: dict[str, Any] | None = None,
    *,
    check_args: bool = True,
) -> bool:
    """Match one current-turn Group Skill safe-tool entry.

    Declared argument patterns use ``fullmatch``.  Every declared field must be
    present and match; undeclared fields are intentionally ignored, consistent
    with the existing allowlist entry shape.
    """
    if tool_name in PRAESTO_TAG_EXP_GROUP_SKILL_HARD_DENY or tool_name.startswith("MCP_"):
        return False
    for raw in entries or []:
        if not isinstance(raw, dict) or str(raw.get("tool") or "") != tool_name:
            continue
        match = raw.get("match")
        if not isinstance(match, dict) or not match:
            continue
        if not check_args:
            return True
        try:
            if all(
                key in (args or {})
                and re.fullmatch(str(pattern), str((args or {}).get(key))) is not None
                for key, pattern in match.items()
            ):
                return True
        except re.error:
            continue
    return False


def praesto_tag_exp_tool_is_exposed(
    tool_name: str,
    *,
    group_skill_safe_tools: list[dict[str, Any]] | None = None,
    group_mcp_tool_names: list[str] | None = None,
) -> bool:
    """Whether a tool may be surfaced or invoked in a borrowed group turn."""
    if tool_name in PRAESTO_TAG_EXP_ALLOWED_BUILTIN_TOOLS:
        return True
    if tool_name in (group_mcp_tool_names or []):
        return True
    if group_skill_safe_tool_matches(group_skill_safe_tools, tool_name, check_args=False):
        return True
    server, _ = _mcp_server_and_raw(tool_name)
    return bool(server) and server in PRAESTO_TAG_EXP_ALLOWED_MCP_SERVERS


def praesto_tag_exp_classify_capability(
    tool_name: str,
    args: dict[str, Any] | None,
    *,
    current_cid: str,
    group_skill_safe_tools: list[dict[str, Any]] | None = None,
    group_mcp_tool_names: list[str] | None = None,
) -> str:
    """Classify an exposed tool as allow/approve, or reject an unavailable tool.

    ``current_cid`` is the Teams conversation id of the group this turn came
    from (``metadata["cid"]``). Only the small exposed tool set can run at all.
    Conversation scoping is enforced inside ``teams_group_fetch``, which reads
    the cid from turn metadata rather than from model-supplied arguments — so
    there is nothing for this classifier to second-guess.
    """
    if not current_cid:
        return PRAESTO_TAG_EXP_REJECT
    args = args or {}
    if not praesto_tag_exp_tool_is_exposed(
        tool_name,
        group_skill_safe_tools=group_skill_safe_tools,
        group_mcp_tool_names=group_mcp_tool_names,
    ):
        return PRAESTO_TAG_EXP_REJECT

    if tool_name in (group_mcp_tool_names or []):
        return PRAESTO_TAG_EXP_ALLOW
    server, _ = _mcp_server_and_raw(tool_name)
    if server in PRAESTO_TAG_EXP_ALLOWED_MCP_SERVERS:
        return PRAESTO_TAG_EXP_ALLOW
    if tool_name not in PRAESTO_TAG_EXP_ALLOWED_BUILTIN_TOOLS:
        return (
            PRAESTO_TAG_EXP_ALLOW
            if group_skill_safe_tool_matches(group_skill_safe_tools, tool_name, args)
            else PRAESTO_TAG_EXP_REJECT
        )

    # The group's own shared store is part of the default-borrow surface.
    if tool_name in _PRAESTO_TAG_EXP_BORROWED_TOOLS:
        return PRAESTO_TAG_EXP_ALLOW
    # The ``tools`` meta-tool only manages the LOCAL tool registry (list /
    # describe / enable / disable a built-in tool). That is not a borrowed action
    # — any tool it enables is independently re-gated when called. So don't spam
    # the employee with an approval just to inspect/enable a local tool (e.g. the
    # model poking at group_memory). Only explicitly allowlisted global MCP
    # servers may be managed here.
    if tool_name == "tools":
        target = str(args.get("name") or "").strip()
        if not target:
            return PRAESTO_TAG_EXP_ALLOW
        if target.startswith(_MCP_PREFIX_FOR_GATE):
            server, _ = _mcp_server_and_raw(target)
            if server and server in PRAESTO_TAG_EXP_ALLOWED_MCP_SERVERS:
                return PRAESTO_TAG_EXP_ALLOW
            return PRAESTO_TAG_EXP_REJECT
        if target in PRAESTO_TAG_EXP_ALLOWED_BUILTIN_TOOLS:
            return PRAESTO_TAG_EXP_ALLOW
        return PRAESTO_TAG_EXP_REJECT
    return PRAESTO_TAG_EXP_REJECT
