"""Windows background updater for replacing locked console entry points."""

from __future__ import annotations

import argparse
import ctypes
import subprocess
import sys
from pathlib import Path


def _wait_for_process_exit(pid: int) -> None:
    """Wait for a Windows process to exit without requiring third-party deps."""
    if sys.platform != "win32":
        return

    synchronize = 0x00100000
    infinite = 0xFFFFFFFF
    kernel32 = ctypes.windll.kernel32
    handle = kernel32.OpenProcess(synchronize, False, pid)
    if not handle:
        return
    try:
        kernel32.WaitForSingleObject(handle, infinite)
    finally:
        kernel32.CloseHandle(handle)


def main() -> int:
    parser = argparse.ArgumentParser(description="PraestoClaw Windows update worker")
    parser.add_argument("--parent-pid", type=int, required=True)
    parser.add_argument("--cwd", default=None)
    parser.add_argument(
        "--start-praestoclaw",
        action="store_true",
        help="Start PraestoClaw after a successful update.",
    )
    parser.add_argument("pip_args", nargs=argparse.REMAINDER)
    args = parser.parse_args()

    pip_args = list(args.pip_args)
    if pip_args and pip_args[0] == "--":
        pip_args = pip_args[1:]
    if not pip_args:
        print("No pip arguments provided.", file=sys.stderr)
        return 1

    _wait_for_process_exit(args.parent_pid)

    cwd = Path(args.cwd) if args.cwd else None
    cmd = [sys.executable, "-m", "pip", *pip_args]
    print("Running:", " ".join(cmd), flush=True)
    result = subprocess.run(cmd, cwd=cwd)
    if result.returncode == 0:
        print("PraestoClaw update complete.", flush=True)
        if args.start_praestoclaw:
            print("Running post-update startup sequence...", flush=True)
            try:
                step_result = subprocess.run(
                    ["praestoclaw", "init", "--quick"], cwd=cwd, timeout=300
                )
                if step_result.returncode != 0:
                    print(
                        f"Command failed ({step_result.returncode}): praestoclaw init --quick",
                        file=sys.stderr,
                    )
            except subprocess.TimeoutExpired:
                print("praestoclaw init --quick timed out (300s)", file=sys.stderr)
            except OSError as exc:
                print(f"Failed to run praestoclaw init --quick: {exc}", file=sys.stderr)

            print("Starting PraestoClaw server...", flush=True)
            try:
                subprocess.Popen(["praestoclaw", "s"], cwd=cwd)
            except OSError as exc:
                print(f"Failed to start PraestoClaw: {exc}", file=sys.stderr)
    else:
        print(f"PraestoClaw update failed with exit code {result.returncode}.", file=sys.stderr)
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
