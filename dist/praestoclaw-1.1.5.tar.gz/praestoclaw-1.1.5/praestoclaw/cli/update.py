"""Update CLI command — praestoclaw update.

Detects install mode automatically:
  - Git (editable install)  → git pull + pip install -e ".[all]"
  - Mirror (wheel install)  → pip install --upgrade --force-reinstall <wheel URL>

On Windows, pip is delegated to a helper process that waits for the current
entry-point exe to exit before installing, avoiding file-lock failures.
"""

from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path

import typer

from praestoclaw import __version__
from praestoclaw.cli.commands import app, console


def _win_defer_pip(
    pip_args: list[str], cwd: Path | str | None = None, *, start_praestoclaw: bool = True
) -> bool:
    """Start a helper that waits for this process to exit, then runs pip."""
    cmd = [
        sys.executable,
        "-m",
        "praestoclaw.cli.update_worker",
        "--parent-pid",
        str(os.getpid()),
    ]
    if cwd is not None:
        cmd.extend(["--cwd", str(cwd)])
    if start_praestoclaw:
        cmd.append("--start-praestoclaw")
    cmd.append("--")
    cmd.extend(pip_args)

    try:
        subprocess.Popen(cmd, close_fds=True)
    except OSError as exc:
        console.print(f"[red]Could not start Windows updater:[/red] {exc}")
        raise typer.Exit(1)

    console.print(
        "[green]Update helper started.[/green]\n"
        "  It will wait for this command to exit, run pip, then start PraestoClaw."
    )
    return False


def _is_git_install() -> Path | None:
    from praestoclaw.utils.update import is_git_install

    return is_git_install()


def _our_exe_paths() -> set[str]:
    """Return the exact install paths of our ``praestoclaw`` and ``pc`` entry-points.

    Uses ``sysconfig`` to resolve both the system and user Scripts dirs, then
    checks for the actual files. Result is a set of lowercased, normalised
    absolute paths — safe for direct comparison with process executable paths.
    """
    import sysconfig

    candidates: set[str] = set()
    dirs: list[str] = []
    for scheme in ("nt", "nt_user"):
        try:
            d = sysconfig.get_path("scripts", scheme)
            if d:
                dirs.append(d)
        except KeyError:
            pass
    # Also consider the directory of the current executable itself.
    dirs.append(str(Path(sys.executable).parent))

    for d in dirs:
        for name in ("praestoclaw.exe", "praestoclaw", "pc.exe", "pc"):
            p = Path(d) / name
            if p.exists():
                candidates.add(str(p.resolve()).lower())
    return candidates


def _is_praestoclaw_process(
    image_name: str,
    command_line: str,
    executable_path: str = "",
    *,
    our_paths: set[str] | None = None,
) -> bool:
    """Return True only when the process can be confidently identified as PraestoClaw."""
    cmd = command_line or ""
    img = (image_name or "").strip().lower()
    lower_cmd = cmd.lower()
    exe = (executable_path or "").strip()

    # 1. Exact executable path match — most reliable.
    if exe:
        paths = our_paths if our_paths is not None else _our_exe_paths()
        norm_exe = str(Path(exe).resolve()).lower() if Path(exe).exists() else exe.lower()
        if norm_exe in paths:
            return True

    # 2. Process named "praestoclaw" — unambiguous.
    if img in {"praestoclaw.exe", "praestoclaw", "praestoclaw-script.py"}:
        return True

    # 3. Command line contains praestoclaw executable path or module invocation.
    if "praestoclaw.cli.commands" in lower_cmd:
        return True
    if re.search(r"(?:^|\s)-m\s+praestoclaw(?:\s|$)", cmd, re.IGNORECASE):
        return True
    if re.search(r"[/\\]praestoclaw(?:\.exe)?[\"'\s]", lower_cmd):
        return True

    # 4. `pc` shorthand — only when command line mentions praestoclaw internals.
    #    We do NOT rely on name/path heuristics alone for `pc`.
    if img in {"pc.exe", "pc", "pc-script.py"} and "praestoclaw" in lower_cmd:
        return True

    return False


def _own_pid_chain() -> set[int]:
    """Return a set of PIDs to exclude: current process + ancestor chain.

    On Windows, ``pc.exe`` may be a shim whose child ``python.exe`` has a
    different PID.  We walk up the parent chain to make sure we never kill
    any process in our own ancestry.
    """
    pids = {os.getpid()}
    if sys.platform == "win32":
        try:
            ps = (
                "$p = Get-CimInstance Win32_Process "
                f"-Filter 'ProcessId = {os.getpid()}';"
                "while ($p) {"
                "  Write-Output $p.ProcessId;"
                "  $p = Get-CimInstance Win32_Process "
                '    -Filter ("ProcessId = {0}" -f $p.ParentProcessId) '
                "    -ErrorAction SilentlyContinue"
                "}"
            )
            r = _run(["powershell", "-NoProfile", "-Command", ps], timeout=10)
            if r.returncode == 0:
                for line in r.stdout.splitlines():
                    line = line.strip()
                    if line.isdigit():
                        pids.add(int(line))
        except Exception:  # noqa: BLE001 — best-effort
            pass
    else:
        try:
            ppid = os.getppid()
            pids.add(ppid)
        except Exception:  # noqa: BLE001
            pass
    return pids


def _find_running_pc_processes() -> list[tuple[int, str]]:
    """Return running PraestoClaw process list excluding own process chain."""
    exclude_pids = _own_pid_chain()
    found: list[tuple[int, str]] = []

    cached_paths = _our_exe_paths()

    if sys.platform == "win32":
        ps_cmd = (
            "$ErrorActionPreference='SilentlyContinue';"
            "Get-CimInstance Win32_Process | "
            "Where-Object { $_.ProcessId -notin @("
            f"{','.join(str(p) for p in exclude_pids)}"
            ") } | "
            'ForEach-Object { "$($_.ProcessId)\t$($_.Name)\t$($_.ExecutablePath)\t$($_.CommandLine)" }'
        )
        result = _run_best_effort(["powershell", "-NoProfile", "-Command", ps_cmd], timeout=20)
        if result is None or result.returncode != 0:
            return []
        for line in result.stdout.splitlines():
            parts = line.strip().split("\t", 3)
            if len(parts) < 2:
                continue
            try:
                pid = int(parts[0])
            except ValueError:
                continue
            image_name = parts[1]
            exe_path = parts[2] if len(parts) >= 3 else ""
            cmdline = parts[3] if len(parts) >= 4 else ""
            if _is_praestoclaw_process(image_name, cmdline, exe_path, our_paths=cached_paths):
                found.append((pid, image_name))
        return found

    result = _run_best_effort(["ps", "-eo", "pid=,args="], timeout=20)
    if result is None or result.returncode != 0:
        return []
    for line in result.stdout.splitlines():
        raw = line.strip()
        if not raw:
            continue
        pieces = raw.split(None, 1)
        if len(pieces) != 2:
            continue
        try:
            pid = int(pieces[0])
        except ValueError:
            continue
        if pid in exclude_pids:
            continue
        cmdline = pieces[1]
        image_name = Path(cmdline.split()[0]).name if cmdline.split() else ""
        if _is_praestoclaw_process(image_name, cmdline, our_paths=cached_paths):
            found.append((pid, cmdline))
    return found


def _stop_running_pc_processes() -> None:
    """Kill running PraestoClaw processes so update/install can proceed safely."""
    running = _find_running_pc_processes()
    if not running:
        console.print("[dim]No running PraestoClaw process detected.[/dim]")
        return

    console.print(f"[yellow]Stopping {len(running)} running PraestoClaw process(es)...[/yellow]")
    for pid, label in running:
        if sys.platform == "win32":
            result = _run(["taskkill", "/PID", str(pid), "/F"], timeout=20)
            if result.returncode == 0:
                console.print(f"  [green]+[/green] killed PID {pid} ({label})")
            else:
                console.print(f"  [yellow]![/yellow] could not kill PID {pid} ({label})")
        else:
            result = _run(["kill", "-9", str(pid)], timeout=10)
            if result.returncode == 0:
                console.print(f"  [green]+[/green] killed PID {pid}")
            else:
                console.print(f"  [yellow]![/yellow] could not kill PID {pid}")


def _run_post_update_startup_sequence() -> None:
    """Post-update startup: re-init config then start server (best-effort)."""
    console.print("\n[dim]Running post-update startup sequence...[/dim]")

    init_result = _run_best_effort(["praestoclaw", "init", "--quick"], timeout=300)
    if init_result is None or init_result.returncode != 0:
        console.print("[yellow]Warning:[/yellow] `praestoclaw init --quick` failed.")

    console.print("[dim]Starting PraestoClaw server...[/dim]")
    try:
        subprocess.Popen(["praestoclaw", "s"])
    except OSError as exc:
        console.print(f"[yellow]Warning:[/yellow] Could not start `praestoclaw s`: {exc}")


def _delegate_to_mirror_script(*, force_mirror: bool = False) -> None:
    """Execute the update script to handle the full upgrade lifecycle.

    When ``force_mirror`` is True (explicit ``--mirror`` flag), uses the local
    repo copy of the script for easy development testing.
    Otherwise downloads the latest script from the public mirror so the
    update logic is always current even when the local binary is outdated.

    On Windows: runs update.ps1 via powershell.
    On macOS/Linux: runs update.sh via bash.
    """
    if sys.platform == "win32":
        script_name = "update.ps1"
        runner = ["powershell", "-ExecutionPolicy", "Bypass", "-File"]
    else:
        script_name = "update.sh"
        runner = ["bash"]

    import tempfile

    # Create a unique tempdir per run to avoid:
    #  - symlink/hardlink pre-creation attacks on shared /tmp (Unix)
    #  - collisions between concurrent `pc update` runs
    script_dir = Path(tempfile.mkdtemp(prefix="pc_update_"))
    script_path = script_dir / script_name

    if force_mirror:
        # --mirror: use local script for dev testing.
        # Copy to tempdir via the same write path as the download branch so
        # any byte-handling regressions (e.g. CRLF double-encoding) surface
        # in local testing too.
        repo = _is_git_install()
        local_script = (repo / script_name) if repo else Path(script_name)
        if not local_script.is_file():
            console.print(f"[yellow]{script_name} not found locally.[/yellow]")
            return
        console.print(f"[dim]Using local {script_name} (copied to tempdir)[/dim]")
        script_path.write_bytes(local_script.read_bytes())
    else:
        # Default: download from mirror
        import httpx

        from praestoclaw.utils.update import MIRROR_BASE

        url = f"{MIRROR_BASE}/{script_name}?t={int(__import__('time').time())}"
        console.print("[dim]Downloading latest update script from mirror...[/dim]")

        try:
            resp = httpx.get(url, timeout=15, follow_redirects=True)
            resp.raise_for_status()
        except Exception as exc:
            console.print(
                f"[yellow]Could not download update script:[/yellow] {exc}\n"
                "  Falling back to built-in update logic."
            )
            updated = _mirror_update(check_only=False)
            if updated and sys.platform != "win32":
                _run_post_update_startup_sequence()
            return

        script_path.write_bytes(resp.content)

    console.print(f"[dim]Running {script_name}...[/dim]\n")

    try:
        if sys.platform != "win32":
            cmd = runner + [str(script_path)]
            os.execvp(cmd[0], cmd)  # noqa: S606 — intentional process replacement
        else:
            # Write a tiny .bat launcher that waits for our process to exit,
            # then runs the ps1 script in a clean PowerShell environment.
            # This avoids Python's stdio pollution that breaks Start-Process
            # -RedirectStandardOutput inside the child PowerShell.
            bat_path = script_dir / "_pc_update_launcher.bat"
            bat_path.write_text(
                f'@echo off\npwsh -ExecutionPolicy Bypass -File "{script_path}"\n',
                encoding="utf-8",
            )
            # Detach: start the bat and exit immediately.
            # The bat inherits the current console window (no new window).
            subprocess.Popen(  # noqa: S602 — shell=True needed for cmd /c
                f'cmd /c "{bat_path}"',
                shell=True,
                close_fds=True,
            )
            console.print("[dim]Update launched — this process will exit now.[/dim]")
            raise SystemExit(0)
    except OSError as exc:
        console.print(f"[red]Failed to run update script:[/red] {exc}")
        raise typer.Exit(1)


def _run(
    cmd: list[str], cwd: Path | str | None = None, timeout: int = 120
) -> subprocess.CompletedProcess[str]:
    try:
        if timeout > 0:
            return subprocess.run(cmd, capture_output=True, text=True, cwd=cwd, timeout=timeout)
        return subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)
    except subprocess.TimeoutExpired:
        console.print(f"[red]Command timed out ({timeout}s):[/red] {' '.join(cmd)}")
        raise typer.Exit(1)
    except FileNotFoundError:
        console.print(f"[red]Command not found:[/red] {cmd[0]}")
        raise typer.Exit(1)


def _run_best_effort(
    cmd: list[str], cwd: Path | str | None = None, timeout: int = 120
) -> subprocess.CompletedProcess[str] | None:
    """Like _run but returns None on any failure instead of exiting."""
    try:
        if timeout > 0:
            return subprocess.run(cmd, capture_output=True, text=True, cwd=cwd, timeout=timeout)
        return subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)
    except Exception:  # noqa: BLE001
        return None


def _git_update(repo: Path, check_only: bool) -> bool:
    """Update from git: fetch, compare, pull, reinstall deps if needed.

    Returns True if the update is fully complete (code pulled and deps up-to-date).
    Returns False if there is nothing to update, or if a manual step is still
    required (e.g. Windows: pip must be run manually after closing this process).
    """
    # Check for dirty working tree
    status_result = _run(["git", "status", "--porcelain"], cwd=repo)
    if status_result.returncode != 0:
        console.print(f"[red]git status failed:[/red]\n{status_result.stderr.strip()}")
        raise typer.Exit(1)
    if status_result.stdout.strip():
        console.print(
            "[yellow]Working tree has uncommitted changes.[/yellow]\n"
            "  Commit or stash them before updating."
        )
        raise typer.Exit(1)

    # Fetch latest
    result = _run(["git", "fetch"], cwd=repo)
    if result.returncode != 0:
        console.print(f"[red]git fetch failed:[/red]\n{result.stderr.strip()}")
        raise typer.Exit(1)

    # Check for upstream changes
    local_result = _run(["git", "rev-parse", "HEAD"], cwd=repo)
    if local_result.returncode != 0:
        console.print(f"[red]git rev-parse HEAD failed:[/red]\n{local_result.stderr.strip()}")
        raise typer.Exit(1)
    local = local_result.stdout.strip()

    remote_result = _run(["git", "rev-parse", "@{u}"], cwd=repo)
    if remote_result.returncode != 0:
        console.print(
            "[red]No upstream tracking branch set.[/red]\n"
            "  Set one with: [bold]git branch --set-upstream-to origin/<branch>[/bold]"
        )
        raise typer.Exit(1)
    remote = remote_result.stdout.strip()

    if local == remote:
        console.print("[green]Already up to date![/green]  (no new commits)")
        return False

    # Detect ahead/behind/diverged state
    count_result = _run(["git", "rev-list", "--left-right", "--count", "HEAD...@{u}"], cwd=repo)
    if count_result.returncode != 0:
        console.print(f"[red]git rev-list failed:[/red]\n{count_result.stderr.strip()}")
        raise typer.Exit(1)
    parts = count_result.stdout.strip().split()
    if len(parts) != 2:
        console.print(f"[red]Unexpected git rev-list output:[/red] {count_result.stdout.strip()}")
        raise typer.Exit(1)
    ahead, behind = int(parts[0]), int(parts[1])

    if behind == 0 and ahead > 0:
        console.print(
            f"[yellow]Local branch is {ahead} commit(s) ahead of upstream.[/yellow]\n"
            "  Nothing to pull. Push your changes or reset to upstream."
        )
        return False

    if ahead > 0 and behind > 0:
        console.print(
            f"[yellow]Branch has diverged:[/yellow] {ahead} ahead, {behind} behind.\n"
            "  Resolve manually (rebase or merge) before updating."
        )
        raise typer.Exit(1)

    # Show what's new (behind > 0, ahead == 0)
    log_result = _run(["git", "log", "--oneline", f"{local}..{remote}"], cwd=repo)
    new_commits = log_result.stdout.strip()
    commit_count = len(new_commits.splitlines()) if new_commits else 0
    console.print(f"[cyan]{commit_count}[/cyan] new commit(s) available:")
    for line in new_commits.splitlines()[:10]:
        console.print(f"  {line}")
    if commit_count > 10:
        console.print(f"  [dim]... and {commit_count - 10} more[/dim]")

    if check_only:
        console.print("\n  Run [bold]pc update[/bold] to pull and install.")
        return False

    # Kill running PraestoClaw processes before modifying files.
    _stop_running_pc_processes()

    # Pull
    console.print("\n[dim]Pulling...[/dim]")
    result = _run(["git", "pull"], cwd=repo)
    if result.returncode != 0:
        console.print(f"[red]git pull failed:[/red]\n{result.stderr.strip()}")
        raise typer.Exit(1)
    console.print("[green]Pull complete.[/green]")

    # For editable installs, Python sources are used directly from the repo —
    # git pull alone is sufficient for pure code changes.  Only re-run pip if
    # pyproject.toml changed in the pulled commits (new deps or entry points).
    toml_changed_result = _run(
        ["git", "diff", "--name-only", f"{local}..{remote}", "--", "pyproject.toml"],
        cwd=repo,
    )
    # If the diff command fails (e.g. SHA no longer resolvable), err on the
    # side of caution and assume pyproject.toml may have changed.
    if toml_changed_result.returncode != 0:
        needs_pip = True
    else:
        needs_pip = bool(toml_changed_result.stdout.strip())

    if needs_pip:
        console.print("[dim]pyproject.toml changed — dependencies need reinstalling.[/dim]")
        if sys.platform == "win32":
            console.print("[dim]Starting Windows update helper...[/dim]")
            return _win_defer_pip(["install", "-e", ".[all]"], cwd=repo)

        with console.status("[bold cyan]Installing dependencies..."):
            pip_result = _run(
                [sys.executable, "-m", "pip", "install", "-e", ".[all]"],
                cwd=repo,
                timeout=300,
            )
        if pip_result.returncode != 0:
            console.print(f"[red]pip install failed:[/red]\n{pip_result.stderr.strip()}")
            raise typer.Exit(1)
        console.print("[green]Dependencies updated![/green]")

    return True


def _mirror_update(check_only: bool) -> bool:
    """Update from the public wheel mirror: check latest.txt, pip install --upgrade.

    Returns True if an update was performed.
    """
    from praestoclaw.utils.update import MIRROR_BASE, check_mirror

    console.print("[dim]Checking mirror...[/dim]")
    status = check_mirror()

    if status.error:
        console.print(
            "[yellow]Could not check for updates.[/yellow]\n"
            "  Re-run the installer to upgrade:\n"
            "  [bold]irm https://aka.ms/praestoclaw/install.ps1 | iex[/bold]  (Windows)\n"
            "  [bold]curl -fsSL https://aka.ms/praestoclaw/install.sh | sh[/bold]  (macOS/Linux)"
        )
        raise typer.Exit(1)

    if status.up_to_date:
        console.print(f"[green]Already up to date![/green]  (latest: v{status.latest})")
        return False

    latest = status.latest
    console.print(f"New version available: [cyan]v{latest}[/cyan]")

    if check_only:
        console.print("  Run [bold]pc update[/bold] to install it.")
        return False

    # Kill running PraestoClaw processes before pip replaces files.
    _stop_running_pc_processes()

    wheel_url = f"{MIRROR_BASE}/dist/praestoclaw-{latest}-py3-none-any.whl"
    pip_args = ["install", "--upgrade", "--force-reinstall", wheel_url]

    console.print("[dim]Upgrading...[/dim]")

    if sys.platform == "win32":
        console.print("[dim]Starting Windows update helper...[/dim]")
        return _win_defer_pip(pip_args)

    with console.status("[bold cyan]Installing..."):
        pip_result = _run([sys.executable, "-m", "pip", *pip_args], timeout=180)
    if pip_result.returncode == 0:
        console.print(f"[green]Updated to v{latest}![/green]")
        return True

    console.print(f"[red]Update failed:[/red]\n{pip_result.stderr.strip()}")
    raise typer.Exit(1)


@app.command(name="update")
def update(
    check: bool = typer.Option(False, "--check", help="Only check for updates, don't install"),
    mirror: bool = typer.Option(
        False, "--mirror", help="Force mirror mode even for git/editable installs"
    ),
) -> None:
    """Update PraestoClaw to the latest version."""
    console.print(f"Current version: [bold]v{__version__}[/bold]")

    repo = _is_git_install()

    # Mirror mode: delegate to the latest update script from the mirror.
    # This ensures the update logic is always current even when the local
    # pc binary is outdated.
    if mirror or not repo:
        if not check:
            _delegate_to_mirror_script(force_mirror=mirror)
            return  # _delegate_to_mirror_script replaces the process or exits
        # --check only: just check, don't delegate
        console.print("Install mode:    [cyan]mirror[/cyan]")
        updated = _mirror_update(check)
    else:
        console.print(f"Install mode:    [cyan]git[/cyan]  ({repo})")
        updated = _git_update(repo, check)

    # Remind to restart if web server is running and we actually updated
    if updated:
        from praestoclaw.cli.commands import _check_web_running

        running = _check_web_running()
        if running:
            pid, port = running
            console.print(
                f"\n[yellow]Web server is running (PID {pid}, port {port}).[/yellow]\n"
                "  Restart it to use the new version."
            )

        if sys.platform != "win32":
            _run_post_update_startup_sequence()


# "upgrade" is a hidden alias — keeps the same convention as other aliases in commands.py
app.command("upgrade", hidden=True)(update)
