"""
Teams First-Run Experience dispatcher.

Hooks into ``CloudChannel._on_message`` and decides whether the inbound
message warrants a FRE card response. The dispatcher is intentionally
*one-way*: it asks "given the current FRE state, should we send a card
*now*?" and either does so or returns. It never blocks the regular
agent pipeline \u2014 messages still flow into the bus exactly as before.

The flow:

1. First-ever Teams message from a user we've never greeted \u2192 send the
   welcome card. Mark seed ``welcome`` shown.
2. Subsequent messages \u2192 the dispatcher is a no-op unless the message
   text matches one of the FRE button handlers (capability / a2a tour).
   Those branches send the next card and mark the corresponding seed
   shown so the user never sees the same card twice.

Opt-out: when ``is_teams_fre_disabled()`` returns ``True`` (set by
``praestoclaw teams fre disable``) the dispatcher short-circuits.

Progressive (cron-like) seeds:

* The ``run_due_seeds`` coroutine scans ``user_activity`` and sends
  delayed cards (memory promo at 24 h since last activity, capability
  tip at 7 d) via stored Teams ``conv_ref``s.
* ``start_seed_loop`` wraps that scan in a long-running asyncio task
  that the cloud channel kicks off at startup. The loop is best-effort:
  any per-iteration error is logged at debug and the loop sleeps until
  the next tick.
"""

from __future__ import annotations

import asyncio
import json
import re
from datetime import datetime, timedelta
from typing import Any

from loguru import logger

from praestoclaw.channels import teams_cards
from praestoclaw.utils import fre_state as fs

# Seed identifiers \u2014 keep stable, they're persisted in fre-state.json.
SEED_WELCOME = "teams.welcome"
SEED_CAPABILITY = "teams.capability"
# Single-card A2A tour. Older multi-stage seeds (teams.a2a_tour.1/2/3) are
# obsolete; we keep the new id distinct so repeat clicks of “试试 A2A”
# are idempotent for users who already saw the card.
SEED_A2A_TOUR = "teams.a2a_tour"

# Substrings (case-insensitive) that flag a message as the user clicking
# one of the welcome card buttons. We use substring matching because
# the ``msteams.messageBack`` action injects the button's ``text`` field
# into the conversation as a normal user message, sometimes with light
# whitespace differences across Teams desktop / web / mobile.
_TRIGGER_CAPABILITY = "\u4ecb\u7ecd\u4e00\u4e0b\u4f60\u80fd\u505a\u4ec0\u4e48"
_TRIGGER_A2A_TOUR = "a2a"

# Plain conversational greetings. When a FRE card has just been sent in
# the same turn (typically the welcome card on the user's very first
# message) we suppress the agent reply for these so the user only sees
# the welcome card \u2014 otherwise the LLM tacks on a redundant "Hi! \u6709
# \u4ec0\u4e48\u53ef\u4ee5\u5e2e\u4f60\u7684?" bubble alongside the card.
#
# The pattern matches only when the entire message *is* a greeting
# (optionally followed by punctuation): "Hi", "hello!", "\u4f60\u597d\u3002",
# "good morning". Real questions like "Hi, what meetings do I have?"
# never match because trailing content fails the ``$`` anchor.
_GREETING_RE = re.compile(
    r"^\s*(?:"
    r"hi+|hello+|hey+|heya|hiya|hola|howdy|yo|sup|"
    r"good\s+(?:morning|afternoon|evening|night)|"
    r"what'?s\s+up|"
    r"\u4f60\u597d[\u554a\u5440]?|\u60a8\u597d|\u563f+|\u54c8\u5587|\u54c8\u7f57|"
    r"\u5728(?:\u5417|\u4e48|\u561b)|"
    r"\u65e9|\u65e9\u5b89|\u65e9\u4e0a\u597d|\u4e2d\u5348\u597d|\u4e0b\u5348\u597d|\u665a\u4e0a\u597d|\u665a\u5b89"
    r")[\s.,!?~\u3002\uff01\uff1f\uff0c\u3001]*$",
    re.IGNORECASE,
)


def _is_greeting(content: str | None) -> bool:
    """Return True when *content* is a bare conversational greeting."""
    if not content:
        return False
    return bool(_GREETING_RE.match(content))


def _is_teams_source(metadata: dict[str, Any] | None) -> bool:
    if not isinstance(metadata, dict):
        return False
    return metadata.get("source") in ("cloud_teams", "teams_bridge")


async def maybe_send_fre_card(
    channel: Any,
    *,
    sender_id: str,
    channel_id: str,
    content: str,
    metadata: dict[str, Any] | None,
    sender_name: str | None = None,
) -> bool:
    """Possibly send a FRE Adaptive Card in response to *content*.

    Returns ``True`` when a card was sent (the caller may still want to
    let the agent see the message; we do *not* swallow the message).
    Returns ``False`` when no card was warranted.

    All errors are caught and logged at debug \u2014 a broken FRE card must
    never block the user's actual chat message.
    """
    try:
        if not _is_teams_source(metadata):
            return False
        if fs.is_teams_fre_disabled():
            return False

        # Stamp activity for the seed loop \u2014 even messages we won't
        # respond to (e.g. follow-up chat after the welcome card) count
        # as engagement and reset the 24h/7d countdowns.
        fs.record_user_activity(sender_id)

        text_lc = (content or "").strip().lower()

        # 1) Welcome \u2014 fires on the very first message from this Teams user.
        if not fs.is_seed_shown(SEED_WELCOME):
            user = fs.load_fre_state().get("user") or {}
            first_name = (user.get("first_name") or "").strip()
            # Fallback to the Teams ``from.name`` (e.g. "Alex Smith")
            # when fre-state.user is empty — happens if the user opened
            # Teams before completing ``pc init``'s SSO step.
            if not first_name and sender_name:
                first_name = sender_name.strip().split()[0] if sender_name.strip() else ""
            await _send_card(
                channel,
                channel_id,
                teams_cards.build_welcome_card(first_name),
            )
            fs.mark_seed_shown(SEED_WELCOME)
            return True

        # 2) "What can you do" button → capability card with starter chips.
        #    Re-render every click so the user can browse the chips
        #    repeatedly (matches the Web UI starter-chip experience).
        #    The seed flag is still recorded for the cron-driven 7-day
        #    capability tip, so we don't gate the card on it.
        if _TRIGGER_CAPABILITY in (content or ""):
            from praestoclaw.defaults.starter_prompts import get_starter_prompts

            await _send_card(
                channel,
                channel_id,
                teams_cards.build_capability_card(get_starter_prompts("teams")),
            )
            fs.mark_seed_shown(SEED_CAPABILITY)
            return True

        # 3) A2A tour — single card describing how to use A2A. Triggered
        #    by the welcome card's “试试 A2A” button (which sends the
        #    fixed phrase “带我看一下 A2A 怎么用”) or any later
        #    user mention of “a2a” while the seed hasn't been shown yet.
        if _TRIGGER_A2A_TOUR in text_lc and not fs.is_seed_shown(SEED_A2A_TOUR):
            await _send_card(channel, channel_id, teams_cards.build_a2a_tour_card())
            fs.mark_seed_shown(SEED_A2A_TOUR)
            return True

        return False
    except Exception as exc:  # noqa: BLE001 \u2014 never break the chat path
        logger.debug("teams FRE dispatcher error: {}", exc)
        return False


async def _send_card(channel: Any, channel_id: str, card: dict[str, Any]) -> None:
    """Serialize and send a Teams Adaptive Card via the cloud channel.

    Mirrors the path used by ``TeamsApprovalFormatter`` (push frame with
    ``push_target='teams'`` and ``keep_context=True``) so the gateway
    delivers the card as an Adaptive Card attachment rather than a plain
    message.
    """
    payload = json.dumps(teams_cards.wrap_for_teams(card), ensure_ascii=False)
    await channel.send(
        channel_id,
        payload,
        push_target="teams",
        keep_context=True,
    )


def fre_should_intercept(content: str | None) -> bool:
    """Return ``True`` when *content* should NOT be forwarded to the agent.

    The cloud channel uses this in tandem with ``maybe_send_fre_card``:

        sent = await maybe_send_fre_card(...)
        if sent and fre_should_intercept(content):
            return False  # skip agent path

    Two cases are intercepted:

    * **FRE button replies** \u2014 capability tour and A2A walkthrough
      buttons inject a fixed text payload. Letting the LLM answer those
      on top of the card produces a confusing duplicate response.
    * **Plain greetings** \u2014 "Hi", "\u4f60\u597d", "hello", etc. When the
      welcome card was just sent (the only path on which this branch
      fires, because ``maybe_send_fre_card`` returned ``True``), the
      welcome card already greets the user; an additional LLM-generated
      "Hi! \u6709\u4ec0\u4e48\u53ef\u4ee5\u5e2e\u4f60\u7684?" bubble is redundant noise.

    Substantive first messages ("\u4eca\u5929\u90fd\u6709\u54ea\u4e9b\u4f1a\u8bae?")
    do *not* match ``_is_greeting`` and are still forwarded to the agent
    so the user gets a real answer alongside the welcome card.
    """
    if not content:
        return False
    text = content.strip()
    text_lc = text.lower()
    # NOTE: compare against the *lowercased* text so the case of "A2A"
    # in the welcome card's imBack value ("带我看一下 A2A 怎么用")
    # doesn't slip through. A previous version compared the raw text
    # against a lowercase literal, causing the agent to be invoked in
    # parallel with the FRE A2A tour card; the late LLM reply then
    # surfaced as a stray "A2A 使用指南" message after the user clicked
    # the next FRE button.
    return (
        _TRIGGER_CAPABILITY in text
        or text_lc == "a2a"
        or text_lc == "\u5e26\u6211\u770b\u4e00\u4e0b a2a \u600e\u4e48\u7528"
        or _is_greeting(content)
    )


__all__ = [
    "SEED_WELCOME",
    "SEED_CAPABILITY",
    "SEED_A2A_TOUR",
    "SEED_MEMORY_PROMO",
    "SEED_CAPABILITY_TIP",
    "fre_should_intercept",
    "maybe_send_fre_card",
    "run_due_seeds",
    "start_seed_loop",
]


# ---------------------------------------------------------------------------
# Progressive (delayed) seeds
# ---------------------------------------------------------------------------

SEED_MEMORY_PROMO = "teams.memory_promo"
SEED_CAPABILITY_TIP = "teams.capability_tip"

# Tunables \u2014 expressed as timedelta so callers can override in tests.
DELAY_MEMORY_PROMO = timedelta(hours=24)
DELAY_CAPABILITY_TIP = timedelta(days=7)
SEED_LOOP_TICK = timedelta(minutes=15)

# Curated 7-day tip pool. Each tuple is (title, body). The scanner picks
# the first entry the user hasn't seen \u2014 we keep IDs implicit because
# all we need is "did capability_tip ever fire?" semantics; refining to
# per-tip dedupe is a follow-up if/when the pool grows beyond a couple.
_CAPABILITY_TIPS: list[tuple[str, str]] = [
    (
        "\u4f60\u77e5\u9053\u5417\uff1f",
        "PraestoClaw \u53ef\u4ee5\u540c\u65f6\u8c03\u7528 GitHub Copilot \u548c Claude Code \u8dd1\u540e\u53f0\u4efb\u52a1\u3002"
        "\u8bd5\u8bd5\u8bf4\uff1a\u201c\u8ba9 Copilot \u4fee\u6389\u8fd9\u4e2a\u4ed3\u5e93\u91cc\u7684 lint \u8b66\u544a\u3002\u201d",
    ),
]


def _parse_iso(ts: str | None) -> datetime | None:
    """Parse an ISO timestamp written by ``fre_state._now_iso``.

    The format is ``%Y-%m-%dT%H:%M:%S%z`` (local time + UTC offset).
    Returns ``None`` for empty or malformed input \u2014 the seed loop
    treats unparseable timestamps as "no recent activity".
    """
    if not ts:
        return None
    try:
        return datetime.strptime(ts, "%Y-%m-%dT%H:%M:%S%z")
    except (TypeError, ValueError):
        return None


async def _send_card_to_oid(channel: Any, oid: str, card: dict[str, Any]) -> bool:
    """Push a card to the conversation associated with *oid*.

    Uses the cloud channel's ``send`` with a non-routable channel_id so
    the gateway stamps the call as a "push" frame and looks up the
    stored ``conv_ref``. Returns ``True`` when the send call completed
    without raising (the gateway may still drop the frame if the
    conv_ref is stale; that's surfaced via 4xx in cloud_gateway logs).
    """
    if not getattr(channel, "is_connected", False):
        logger.debug("seed loop: channel not connected, skipping oid={}", oid)
        return False
    payload = json.dumps(teams_cards.wrap_for_teams(card), ensure_ascii=False)
    # Use the "a2a:" prefix so cloud.send() treats this as non-routable
    # and goes through the push branch (which attaches conv_ref).
    try:
        await channel.send(
            f"a2a:fre-seed:{oid}",
            payload,
            push_target="teams",
            keep_context=True,
        )
        return True
    except Exception as exc:  # noqa: BLE001
        logger.debug("seed loop: send failed for oid={}: {}", oid, exc)
        return False


async def run_due_seeds(channel: Any, *, now: datetime | None = None) -> int:
    """Send any progressive seeds whose delay has elapsed.

    Returns the number of cards actually sent. Idempotent: each seed is
    marked shown after a successful send so subsequent ticks won't
    re-fire it.

    Parameters
    ----------
    channel:
        The cloud channel instance \u2014 must implement ``send`` and expose
        ``is_connected``.
    now:
        Override for the wall clock (test hook). Defaults to local time
        so it can be diffed against ``record_user_activity`` timestamps.
    """
    if fs.is_teams_fre_disabled():
        return 0

    now = now or datetime.now().astimezone()
    sent = 0

    activity = fs.get_user_activity()
    if not activity:
        return 0

    for sender_id, last_iso in activity.items():
        last = _parse_iso(last_iso)
        if last is None:
            continue
        elapsed = now - last

        # 24h memory promo \u2014 only after the user has actually been greeted.
        if (
            elapsed >= DELAY_MEMORY_PROMO
            and fs.is_seed_shown(SEED_WELCOME)
            and not fs.is_seed_shown(SEED_MEMORY_PROMO)
        ):
            if await _send_card_to_oid(channel, sender_id, teams_cards.build_memory_promo_card()):
                fs.mark_seed_shown(SEED_MEMORY_PROMO)
                sent += 1

        # 7d capability tip \u2014 also gated on welcome so we don't ambush
        # users who only just installed the app.
        if (
            elapsed >= DELAY_CAPABILITY_TIP
            and fs.is_seed_shown(SEED_WELCOME)
            and not fs.is_seed_shown(SEED_CAPABILITY_TIP)
        ):
            title, body = _CAPABILITY_TIPS[0]
            if await _send_card_to_oid(
                channel, sender_id, teams_cards.build_capability_tip_card(title, body)
            ):
                fs.mark_seed_shown(SEED_CAPABILITY_TIP)
                sent += 1

    return sent


def start_seed_loop(channel: Any, *, tick: timedelta | None = None) -> asyncio.Task:
    """Spawn the long-running seed scanner as an asyncio task.

    Returns the created task so the caller can ``cancel()`` it on
    channel shutdown. The loop:

    * sleeps ``tick`` (default 15 min) between scans;
    * catches and logs every error so a transient failure doesn't kill
      the loop;
    * exits cleanly on ``CancelledError``.
    """
    interval = (tick or SEED_LOOP_TICK).total_seconds()

    async def _loop() -> None:
        logger.debug("teams FRE seed loop started, tick={}s", interval)
        try:
            while True:
                try:
                    await run_due_seeds(channel)
                except Exception as exc:  # noqa: BLE001
                    logger.debug("seed loop iteration error: {}", exc)
                await asyncio.sleep(interval)
        except asyncio.CancelledError:
            logger.debug("teams FRE seed loop cancelled")
            raise

    return asyncio.create_task(_loop(), name="teams-fre-seed-loop")
