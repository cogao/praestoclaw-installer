"""Agent-side transport protocol client for PraestoClaw Gateway.

Implements the v1 ``t.*`` protocol as a standalone client layer:

* WebSocket handshake with ``t.hello`` / ``t.welcome``.
* Server-driven heartbeat (``t.ping`` -> ``t.pong``).
* Ordered ``t.data`` delivery with cumulative ``t.ack``.
* In-memory outbox replay on successful resume.
* Automatic reconnect with backoff for recoverable closes.

The payload carried by ``t.data.payload`` is opaque to this module.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import random
import time
from collections import deque
from collections.abc import AsyncIterator, Awaitable, Callable, Mapping
from dataclasses import dataclass, field
from enum import Enum, IntEnum
from typing import Any

import websockets

HeadersProvider = Callable[[], Awaitable[Mapping[str, str]]]

PROTOCOL_VERSION = 1
DEFAULT_MAX_PAYLOAD_BYTES = 1_048_576
DEFAULT_MAX_OUTBOX_BYTES = 1_048_576
DEFAULT_RESUME_TTL_S = 300.0
DEFAULT_DUPLICATE_ABUSE_THRESHOLD = 1024
DEFAULT_DUPLICATE_ABUSE_WINDOW_S = 30.0
_CLOSED_SENTINEL = object()


class CloseCode(IntEnum):
    """Protocol close codes used by the transport layer."""

    NORMAL = 1000
    AUTHENTICATION_FAILED = 1008
    SERVER_INTERNAL_ERROR = 1011
    UNKNOWN_FRAME_OR_INVALID_JSON = 4000
    PROTOCOL_ERROR = 4001
    PAYLOAD_TOO_LARGE = 4002
    HEARTBEAT_TIMEOUT = 4003
    SUPERSEDED = 4004
    RESUME_REJECTED = 4005
    VERSION_NEGOTIATION_FAILED = 4006


RECOVERABLE_CLOSE_CODES = frozenset(
    {
        CloseCode.SERVER_INTERNAL_ERROR,
        CloseCode.UNKNOWN_FRAME_OR_INVALID_JSON,
        CloseCode.HEARTBEAT_TIMEOUT,
        CloseCode.RESUME_REJECTED,
        # AUTHENTICATION_FAILED is conditionally recoverable: the reconnect
        # loop calls headers_provider() before each attempt to refresh the
        # bearer token. After MAX_CONSECUTIVE_AUTH_FAILURES in a row we give
        # up so a permanently revoked token does not loop forever.
        CloseCode.AUTHENTICATION_FAILED,
    }
)

MAX_CONSECUTIVE_AUTH_FAILURES = 3


class TransportState(str, Enum):
    """Client send-pump state."""

    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    REPLAYING = "replaying"
    LIVE = "live"
    CLOSING = "closing"
    CLOSED = "closed"


@dataclass(frozen=True)
class TransportEvent:
    """Coarse transport lifecycle event exposed to upper layers."""

    kind: str
    session_id: str | None = None
    prior_session_id: str | None = None
    connection_epoch: int | None = None
    reason: str | None = None
    resumed: bool | None = None


class TransportError(Exception):
    """Raised when a transport frame or state transition violates the protocol."""

    def __init__(self, code: int | CloseCode, reason: str) -> None:
        super().__init__(reason)
        self.code = int(code)
        self.reason = reason


class TransportClosedError(TransportError):
    """Raised when using a closed transport."""

    def __init__(self, reason: str = "transport is closed") -> None:
        super().__init__(CloseCode.NORMAL, reason)


class PayloadTooLargeError(TransportError):
    """Raised when an outbound payload exceeds the negotiated limit."""

    def __init__(self, size: int, limit: int) -> None:
        super().__init__(CloseCode.PAYLOAD_TOO_LARGE, f"payload size {size} exceeds {limit}")
        self.size = size
        self.limit = limit


class TransportDisconnectedBackpressureError(TransportError):
    """Raised when disconnected sends would exceed the local soft cap."""

    def __init__(self, size: int, limit: int) -> None:
        super().__init__(
            CloseCode.SERVER_INTERNAL_ERROR,
            f"disconnected outbox size {size} exceeds soft cap {limit}",
        )
        self.size = size
        self.limit = limit


@dataclass
class TransportClientConfig:
    """Configuration for :class:`GatewayTransportClient`."""

    url: str
    headers: Mapping[str, str] = field(default_factory=dict)
    headers_provider: HeadersProvider | None = None
    """Optional async callable invoked before each connect attempt.

    When set, its return value REPLACES :attr:`headers` for that attempt.
    Use this to refresh short-lived bearer tokens across reconnects. The
    provider must be safe to call from the reconnect loop.
    """
    protocol_version: int = PROTOCOL_VERSION
    min_protocol_version: int | None = None
    features: tuple[str, ...] = ("resume", "ack", "server_ping")
    connect_timeout_s: float = 15.0
    handshake_timeout_s: float = 30.0
    close_timeout_s: float = 5.0
    reconnect_initial_delay_s: float = 1.0
    reconnect_max_delay_s: float = 10.0
    ack_delay_s: float = 1.0
    ack_frame_threshold: int = 32
    ack_byte_threshold: int = 256 * 1024
    receive_queue_size: int = 100
    max_payload_bytes: int = DEFAULT_MAX_PAYLOAD_BYTES
    max_outbox_bytes: int = DEFAULT_MAX_OUTBOX_BYTES
    disconnected_outbox_soft_cap_bytes: int | None = None
    max_disconnected_duration_s: float | None = None
    happy_eyeballs_delay: float = 0.25
    interleave: int = 1


@dataclass
class _OutboxEntry:
    seq: int
    frame_text: str
    byte_len: int
    sent_epoch: int | None = None


def encode_frame(frame: Mapping[str, Any]) -> str:
    """Serialize a transport frame to compact UTF-8 JSON text."""

    return json.dumps(frame, ensure_ascii=False, separators=(",", ":"))


def parse_transport_frame(raw: str | bytes) -> dict[str, Any]:
    """Parse and validate the common top-level transport frame shape."""

    if isinstance(raw, bytes):
        try:
            raw = raw.decode("utf-8")
        except UnicodeDecodeError:
            raise TransportError(CloseCode.UNKNOWN_FRAME_OR_INVALID_JSON, "frame is not utf-8")
    if not isinstance(raw, str):
        raise TransportError(CloseCode.UNKNOWN_FRAME_OR_INVALID_JSON, "frame is not text")
    try:
        frame = json.loads(raw)
    except json.JSONDecodeError:
        raise TransportError(CloseCode.UNKNOWN_FRAME_OR_INVALID_JSON, "invalid json")
    if not isinstance(frame, dict):
        raise TransportError(CloseCode.UNKNOWN_FRAME_OR_INVALID_JSON, "frame must be an object")
    frame_type = frame.get("type")
    if not isinstance(frame_type, str) or not frame_type.startswith("t."):
        raise TransportError(CloseCode.UNKNOWN_FRAME_OR_INVALID_JSON, "non-transport frame")
    if frame_type not in {
        "t.hello",
        "t.welcome",
        "t.ping",
        "t.pong",
        "t.data",
        "t.ack",
        "t.close",
        "t.error",
    }:
        raise TransportError(CloseCode.UNKNOWN_FRAME_OR_INVALID_JSON, f"unknown frame {frame_type}")
    return frame


def _json_size(value: Any) -> int:
    return len(json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))


def _require_uint(frame: Mapping[str, Any], field_name: str, *, minimum: int = 0) -> int:
    value = frame.get(field_name)
    if not isinstance(value, int) or isinstance(value, bool) or value < minimum:
        raise TransportError(CloseCode.PROTOCOL_ERROR, f"{field_name} must be uint >= {minimum}")
    return value


class GatewayTransportClient:
    """Standalone agent-side client for the Gateway transport protocol."""

    def __init__(self, config: TransportClientConfig) -> None:
        self.config = config

        self._state = TransportState.DISCONNECTED
        self._session_id: str | None = None
        self._session_token: str | None = None
        self._connection_epoch = 0
        self._features: frozenset[str] = frozenset()
        self._max_payload_bytes = config.max_payload_bytes
        self._max_outbox_bytes = config.max_outbox_bytes
        self._ping_interval_s = 25.0
        self._pong_timeout_s = 20.0
        self._resume_ttl_s = DEFAULT_RESUME_TTL_S

        self._next_outgoing_seq = 1
        self._delivered_next_seq = 1
        self._pending_ack_seq = 0
        self._last_sent_ack_seq = 0

        self._outbox: deque[_OutboxEntry] = deque()
        self._outbox_bytes = 0
        self._cv = asyncio.Condition()
        self._send_lock = asyncio.Lock()
        self._recv_queue: asyncio.Queue[Any] = asyncio.Queue(maxsize=config.receive_queue_size)
        self._event_queue: asyncio.Queue[TransportEvent] = asyncio.Queue(maxsize=100)

        self._runner_task: asyncio.Task[None] | None = None
        self._ack_timer_task: asyncio.Task[None] | None = None
        self._ws: Any = None
        self._close_requested = False
        self._accepting_sends = True
        self._connected_event = asyncio.Event()
        self._last_frame_at = time.monotonic()
        self._ack_frames_since_flush = 0
        self._ack_bytes_since_flush = 0
        self._last_welcome_resumed: bool | None = None
        self._disconnected_since: float | None = None
        self._duplicate_run_count = 0
        self._duplicate_run_started_at: float | None = None

    @property
    def state(self) -> TransportState:
        return self._state

    @property
    def session_id(self) -> str | None:
        return self._session_id

    @property
    def connection_epoch(self) -> int:
        return self._connection_epoch

    @property
    def last_received_seq(self) -> int:
        """Largest Gateway->agent sequence delivered to the receive queue."""

        return self._delivered_next_seq - 1

    @property
    def next_outgoing_seq(self) -> int:
        return self._next_outgoing_seq

    @property
    def outbox_bytes(self) -> int:
        return self._outbox_bytes

    @property
    def outbox_size(self) -> int:
        return len(self._outbox)

    @property
    def negotiated_features(self) -> frozenset[str]:
        return self._features

    @property
    def last_welcome_resumed(self) -> bool | None:
        return self._last_welcome_resumed

    async def start(self) -> None:
        """Start the reconnect loop."""

        if self._runner_task and not self._runner_task.done():
            return
        self._close_requested = False
        self._accepting_sends = True
        self._runner_task = asyncio.create_task(self._run_loop(), name="gateway-transport-client")

    async def wait_connected(self, timeout: float | None = None) -> None:
        """Wait until the current WebSocket has completed transport negotiation."""

        await asyncio.wait_for(self._connected_event.wait(), timeout=timeout)

    async def send(self, payload: Any) -> int:
        """Append an opaque business payload to the ordered transport outbox."""

        if not self._accepting_sends or self._state in {
            TransportState.CLOSING,
            TransportState.CLOSED,
        }:
            raise TransportClosedError()

        payload_size = _json_size(payload)
        if payload_size > self._max_payload_bytes:
            raise PayloadTooLargeError(payload_size, self._max_payload_bytes)

        async with self._cv:
            seq = self._next_outgoing_seq
            frame_text = encode_frame({"type": "t.data", "seq": seq, "payload": payload})
            frame_size = len(frame_text.encode("utf-8"))
            outbox_limit = self._outbox_limit_for_current_state()
            if (
                self._state in {TransportState.DISCONNECTED, TransportState.CONNECTING}
                and self._outbox_bytes + frame_size > outbox_limit
            ):
                raise TransportDisconnectedBackpressureError(
                    self._outbox_bytes + frame_size,
                    outbox_limit,
                )
            while self._outbox_bytes + frame_size > outbox_limit:
                if not self._accepting_sends:
                    raise TransportClosedError()
                await self._cv.wait()

            self._next_outgoing_seq += 1
            self._outbox.append(_OutboxEntry(seq=seq, frame_text=frame_text, byte_len=frame_size))
            self._outbox_bytes += frame_size
            self._cv.notify_all()
            return seq

    async def receive(self) -> Any:
        """Receive a single opaque business payload."""

        item = await self._recv_queue.get()
        if item is _CLOSED_SENTINEL:
            raise TransportClosedError()
        return item

    async def recv(self) -> AsyncIterator[Any]:
        """Yield opaque business payloads in transport order."""

        while True:
            item = await self._recv_queue.get()
            if item is _CLOSED_SENTINEL:
                break
            yield item

    async def events(self) -> AsyncIterator[TransportEvent]:
        """Yield coarse lifecycle events for upper layers."""

        while True:
            yield await self._event_queue.get()

    async def close(self, *, graceful: bool = True, timeout: float = 5.0) -> None:
        """Stop the client and close the current transport session."""

        self._close_requested = True
        self._accepting_sends = False
        self._state = TransportState.CLOSING
        async with self._cv:
            self._cv.notify_all()

        if graceful and self._ws is not None:
            deadline = time.monotonic() + timeout
            async with self._cv:
                while self._outbox and time.monotonic() < deadline:
                    remaining = max(0.0, deadline - time.monotonic())
                    with contextlib.suppress(TimeoutError):
                        await asyncio.wait_for(self._cv.wait(), timeout=remaining)
                        continue
                    break
            with contextlib.suppress(Exception):
                await self._flush_ack()
                await self._send_frame(
                    {"type": "t.close", "code": int(CloseCode.NORMAL), "reason": "closing"}
                )
                await self._ws.close(code=int(CloseCode.NORMAL), reason="closing")

        if self._runner_task:
            self._runner_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._runner_task
        if self._ack_timer_task:
            self._ack_timer_task.cancel()
            self._ack_timer_task = None
        self._session_token = None
        self._session_id = None
        self._reset_fresh_session()
        self._state = TransportState.CLOSED
        await self._put_closed_sentinel()

    async def _run_loop(self) -> None:
        delay = self.config.reconnect_initial_delay_s
        consecutive_auth_failures = 0
        while not self._close_requested:
            attempt_started_at = time.monotonic()
            try:
                await self._run_connection()
                # Only reset backoff if the connection stayed up long enough
                # to count as stable; otherwise the next iteration grows the
                # delay (avoid hot reconnect loops on flapping handshakes).
                if time.monotonic() - attempt_started_at >= 30.0:
                    delay = self.config.reconnect_initial_delay_s
                consecutive_auth_failures = 0
            except asyncio.CancelledError:
                raise
            except TransportClosedError as exc:
                self._session_token = None
                self._emit_event_nowait(
                    TransportEvent(
                        kind="closed",
                        session_id=self._session_id,
                        connection_epoch=self._connection_epoch or None,
                        reason=exc.reason,
                    )
                )
                self._state = TransportState.CLOSED
                await self._put_closed_sentinel()
                return
            except TransportError as exc:
                await self._emit_event("error", reason=exc.reason)
                if exc.code == int(CloseCode.AUTHENTICATION_FAILED):
                    consecutive_auth_failures += 1
                else:
                    consecutive_auth_failures = 0
                fatal = exc.code not in {int(code) for code in RECOVERABLE_CLOSE_CODES} or (
                    exc.code == int(CloseCode.AUTHENTICATION_FAILED)
                    and consecutive_auth_failures >= MAX_CONSECUTIVE_AUTH_FAILURES
                )
                if fatal:
                    self._session_token = None
                    self._emit_event_nowait(
                        TransportEvent(
                            kind="closed",
                            session_id=self._session_id,
                            connection_epoch=self._connection_epoch or None,
                            reason=exc.reason,
                        )
                    )
                    self._state = TransportState.CLOSED
                    await self._put_closed_sentinel()
                    return
            except websockets.exceptions.ConnectionClosed as exc:
                code = getattr(exc, "code", None)
                await self._emit_event("disconnected", reason=str(code) if code else None)
                if code == int(CloseCode.AUTHENTICATION_FAILED):
                    consecutive_auth_failures += 1
                else:
                    consecutive_auth_failures = 0
                fatal = code is not None and (
                    code not in {int(c) for c in RECOVERABLE_CLOSE_CODES}
                    or (
                        code == int(CloseCode.AUTHENTICATION_FAILED)
                        and consecutive_auth_failures >= MAX_CONSECUTIVE_AUTH_FAILURES
                    )
                )
                if fatal:
                    self._session_token = None
                    self._emit_event_nowait(
                        TransportEvent(
                            kind="closed",
                            session_id=self._session_id,
                            connection_epoch=self._connection_epoch or None,
                            reason=str(code),
                        )
                    )
                    self._state = TransportState.CLOSED
                    await self._put_closed_sentinel()
                    return
            except Exception as exc:
                await self._emit_event("disconnected", reason=str(exc))

            self._connected_event.clear()
            self._ws = None
            self._state = TransportState.DISCONNECTED
            if self._close_requested:
                break
            if self._disconnected_since is None:
                self._disconnected_since = time.monotonic()
            max_disconnected_s = self._max_disconnected_duration_s()
            elapsed_disconnected_s = time.monotonic() - self._disconnected_since
            if elapsed_disconnected_s >= max_disconnected_s:
                prior_session_id = self._session_id
                self._session_token = None
                self._reset_fresh_session()
                self._emit_event_nowait(
                    TransportEvent(
                        kind="resume_failed",
                        prior_session_id=prior_session_id,
                        session_id=None,
                        reason="max_disconnected_duration",
                        resumed=False,
                    )
                )
                self._state = TransportState.CLOSED
                await self._put_closed_sentinel()
                return
            jittered = delay + random.uniform(0, delay * 0.25)  # noqa: S311 - reconnect jitter only
            await asyncio.sleep(min(jittered, max_disconnected_s - elapsed_disconnected_s))
            delay = min(delay * 2, self.config.reconnect_max_delay_s)

        self._state = TransportState.CLOSED
        await self._put_closed_sentinel()

    async def _run_connection(self) -> None:
        self._state = TransportState.CONNECTING
        attempted_resume = self._session_token is not None
        if self.config.headers_provider is not None:
            try:
                provided = await self.config.headers_provider()
            except Exception as exc:  # noqa: BLE001 - surface to reconnect loop
                raise TransportError(
                    CloseCode.AUTHENTICATION_FAILED,
                    f"headers_provider failed: {exc}",
                ) from exc
            headers = dict(provided)
        else:
            headers = dict(self.config.headers)

        async with websockets.connect(
            self.config.url,
            additional_headers=headers,
            ping_interval=None,
            open_timeout=self.config.connect_timeout_s,
            close_timeout=self.config.close_timeout_s,
            happy_eyeballs_delay=self.config.happy_eyeballs_delay,
            interleave=self.config.interleave,
        ) as ws:
            self._ws = ws
            self._last_frame_at = time.monotonic()
            await self._send_frame(self._hello_frame())
            welcome = await asyncio.wait_for(
                self._read_welcome(ws), timeout=self.config.handshake_timeout_s
            )
            resumed = self._apply_welcome(welcome, attempted_resume=attempted_resume)
            self._state = TransportState.REPLAYING if resumed else TransportState.LIVE
            self._connected_event.set()
            self._disconnected_since = None

            reader_task = asyncio.create_task(self._reader(ws), name="gateway-transport-reader")
            pump_task = asyncio.create_task(
                self._send_pump(ws, replay=resumed), name="gateway-transport-pump"
            )
            idle_task = asyncio.create_task(self._idle_watchdog(ws), name="gateway-transport-idle")
            try:
                done, pending = await asyncio.wait(
                    {reader_task, pump_task, idle_task},
                    return_when=asyncio.FIRST_EXCEPTION,
                )
                for task in pending:
                    task.cancel()
                for task in pending:
                    with contextlib.suppress(asyncio.CancelledError):
                        await task
                for task in done:
                    task.result()
            finally:
                self._connected_event.clear()
                if self._ack_timer_task:
                    self._ack_timer_task.cancel()
                    self._ack_timer_task = None

    def _hello_frame(self) -> dict[str, Any]:
        frame: dict[str, Any] = {
            "type": "t.hello",
            "protocol_version": self.config.protocol_version,
            "features": list(self.config.features),
            "last_received_seq": self.last_received_seq,
        }
        if (
            self.config.min_protocol_version is not None
            and self.config.min_protocol_version != self.config.protocol_version
        ):
            frame["min_protocol_version"] = self.config.min_protocol_version
        if self._session_token:
            frame["session_token"] = self._session_token
        return frame

    async def _read_welcome(self, ws: Any) -> dict[str, Any]:
        raw = await ws.recv()
        frame = parse_transport_frame(raw)
        if frame["type"] == "t.error":
            code = str(frame.get("code", "transport_error"))
            close_code = self._t_error_close_code(code)
            # On resumable session-state errors, drop the token so the next
            # attempt does a fresh handshake instead of looping on a stale id.
            if code in {"unknown_session", "expired_session", "resume_rejected"}:
                self._session_token = None
                self._reset_fresh_session()
            raise TransportError(close_code, code)
        if frame["type"] != "t.welcome":
            raise TransportError(CloseCode.PROTOCOL_ERROR, "expected t.welcome")
        return frame

    @staticmethod
    def _t_error_close_code(code: str) -> CloseCode:
        mapping = {
            "unknown_session": CloseCode.RESUME_REJECTED,
            "expired_session": CloseCode.RESUME_REJECTED,
            "resume_rejected": CloseCode.RESUME_REJECTED,
            "version_negotiation_failed": CloseCode.VERSION_NEGOTIATION_FAILED,
            "authentication_failed": CloseCode.AUTHENTICATION_FAILED,
            "superseded": CloseCode.SUPERSEDED,
            "payload_too_large": CloseCode.PAYLOAD_TOO_LARGE,
        }
        return mapping.get(code, CloseCode.PROTOCOL_ERROR)

    def _apply_welcome(self, frame: Mapping[str, Any], *, attempted_resume: bool) -> bool:
        protocol_version = _require_uint(frame, "protocol_version", minimum=1)
        min_protocol_version = self.config.min_protocol_version or self.config.protocol_version
        if not (min_protocol_version <= protocol_version <= self.config.protocol_version):
            raise TransportError(
                CloseCode.VERSION_NEGOTIATION_FAILED, "unsupported protocol version"
            )

        features_value = frame.get("features", [])
        if not isinstance(features_value, list) or not all(
            isinstance(item, str) for item in features_value
        ):
            raise TransportError(CloseCode.PROTOCOL_ERROR, "features must be a string list")
        features = frozenset(features_value)

        session_id = frame.get("session_id")
        session_token = frame.get("session_token")
        if not isinstance(session_id, str) or not session_id:
            raise TransportError(CloseCode.PROTOCOL_ERROR, "session_id is required")
        if not isinstance(session_token, str) or not session_token:
            raise TransportError(CloseCode.PROTOCOL_ERROR, "session_token is required")

        resumed = frame.get("resumed")
        if not isinstance(resumed, bool):
            raise TransportError(CloseCode.PROTOCOL_ERROR, "resumed must be bool")
        if resumed and not attempted_resume:
            raise TransportError(CloseCode.PROTOCOL_ERROR, "fresh connection cannot be resumed")
        gateway_last_received = _require_uint(frame, "last_received_seq")
        connection_epoch = _require_uint(frame, "connection_epoch", minimum=1)

        prior_session_id = self._session_id
        if attempted_resume and not resumed:
            reason = frame.get("resume_failed_reason")
            self._reset_fresh_session()
            self._emit_event_nowait(
                TransportEvent(
                    kind="resume_failed",
                    session_id=session_id,
                    prior_session_id=prior_session_id,
                    connection_epoch=connection_epoch,
                    reason=str(reason) if reason is not None else None,
                    resumed=False,
                )
            )
        elif resumed:
            self._trim_outbox_from_peer_ack(gateway_last_received)
            self._emit_event_nowait(
                TransportEvent(
                    kind="resumed",
                    session_id=session_id,
                    connection_epoch=connection_epoch,
                    resumed=True,
                )
            )
        else:
            self._emit_event_nowait(
                TransportEvent(
                    kind="connected",
                    session_id=session_id,
                    connection_epoch=connection_epoch,
                    resumed=False,
                )
            )

        self._session_id = session_id
        self._session_token = session_token
        self._connection_epoch = connection_epoch
        self._features = features
        self._max_payload_bytes = _require_uint(frame, "max_payload_bytes", minimum=1)
        self._max_outbox_bytes = _require_uint(frame, "max_outbox_bytes", minimum=1)
        self._ping_interval_s = _require_uint(frame, "ping_interval_ms", minimum=1) / 1000
        self._pong_timeout_s = _require_uint(frame, "pong_timeout_ms", minimum=1) / 1000
        resume_ttl_ms = frame.get("resume_ttl_ms")
        if (
            isinstance(resume_ttl_ms, int)
            and not isinstance(resume_ttl_ms, bool)
            and resume_ttl_ms > 0
        ):
            self._resume_ttl_s = resume_ttl_ms / 1000
        self._last_welcome_resumed = resumed
        return resumed

    async def _reader(self, ws: Any) -> None:
        async for raw in ws:
            self._last_frame_at = time.monotonic()
            frame = parse_transport_frame(raw)
            frame_type = frame["type"]
            if frame_type == "t.ping":
                await self._send_frame({"type": "t.pong"})
            elif frame_type == "t.pong":
                continue
            elif frame_type == "t.ack":
                await self._handle_ack(frame)
            elif frame_type == "t.data":
                await self._handle_data(frame, raw_size=len(str(raw).encode("utf-8")))
            elif frame_type == "t.close":
                self._accepting_sends = False
                self._close_requested = True
                await self._flush_ack()
                raise TransportClosedError(str(frame.get("reason", "peer closed")))
            elif frame_type == "t.error":
                code = str(frame.get("code", "transport_error"))
                if code in {"unknown_session", "expired_session", "resume_rejected"}:
                    self._session_token = None
                    self._reset_fresh_session()
                raise TransportError(self._t_error_close_code(code), code)
            else:
                raise TransportError(
                    CloseCode.UNKNOWN_FRAME_OR_INVALID_JSON, f"unexpected {frame_type}"
                )

        if not self._close_requested:
            raise TransportError(CloseCode.HEARTBEAT_TIMEOUT, "websocket disconnected")

    async def _send_pump(self, ws: Any, *, replay: bool) -> None:
        epoch = self._connection_epoch
        replay_tail_seq = self._outbox[-1].seq if replay and self._outbox else None
        self._state = (
            TransportState.REPLAYING if replay_tail_seq is not None else TransportState.LIVE
        )

        while not self._close_requested:
            async with self._cv:
                entry = self._next_unsent_entry(epoch)
                while entry is None and not self._close_requested:
                    await self._cv.wait()
                    entry = self._next_unsent_entry(epoch)
                if self._close_requested:
                    return

            await self._send_text(entry.frame_text)
            entry.sent_epoch = epoch
            if replay_tail_seq is not None and entry.seq >= replay_tail_seq:
                replay_tail_seq = None
                self._state = TransportState.LIVE

    async def _idle_watchdog(self, ws: Any) -> None:
        timeout_s = self._ping_interval_s + self._pong_timeout_s
        while not self._close_requested:
            await asyncio.sleep(min(1.0, timeout_s))
            if time.monotonic() - self._last_frame_at > timeout_s:
                with contextlib.suppress(Exception):
                    await ws.close(
                        code=int(CloseCode.HEARTBEAT_TIMEOUT), reason="heartbeat timeout"
                    )
                raise TransportError(CloseCode.HEARTBEAT_TIMEOUT, "gateway heartbeat timeout")

    async def _handle_ack(self, frame: Mapping[str, Any]) -> None:
        ack = _require_uint(frame, "ack")
        async with self._cv:
            if ack >= self._next_outgoing_seq:
                raise TransportError(CloseCode.PROTOCOL_ERROR, "peer acked unsent data")
            first_unacked = self._first_unacked_or_next_seq()
            if ack < first_unacked:
                return
            self._trim_outbox(ack)
            self._cv.notify_all()

    async def _handle_data(self, frame: Mapping[str, Any], *, raw_size: int) -> None:
        seq = _require_uint(frame, "seq", minimum=1)
        payload = frame.get("payload")
        payload_size = _json_size(payload)
        if payload_size > self._max_payload_bytes:
            raise PayloadTooLargeError(payload_size, self._max_payload_bytes)

        if seq < self._delivered_next_seq:
            self._record_duplicate_data()
            self._pending_ack_seq = max(self._pending_ack_seq, self._delivered_next_seq - 1)
            self._schedule_ack(raw_size=0, count_for_threshold=False)
            return
        if seq > self._delivered_next_seq:
            raise TransportError(CloseCode.PROTOCOL_ERROR, "data sequence gap")

        try:
            self._recv_queue.put_nowait(payload)
        except asyncio.QueueFull:
            raise TransportError(CloseCode.SERVER_INTERNAL_ERROR, "receive queue overloaded")

        self._delivered_next_seq = seq + 1
        self._duplicate_run_count = 0
        self._duplicate_run_started_at = None
        self._pending_ack_seq = seq
        self._schedule_ack(raw_size=raw_size, count_for_threshold=True)

    def _schedule_ack(self, *, raw_size: int, count_for_threshold: bool) -> None:
        if count_for_threshold:
            self._ack_frames_since_flush += 1
            self._ack_bytes_since_flush += raw_size
        threshold_hit = (
            self._ack_frames_since_flush >= self.config.ack_frame_threshold
            or self._ack_bytes_since_flush >= self.config.ack_byte_threshold
        )
        if threshold_hit:
            if self._ack_timer_task:
                self._ack_timer_task.cancel()
            # Reuse the timer slot so the task is referenced and cannot be
            # GC'd mid-flight (see CPython asyncio.create_task warning).
            self._ack_timer_task = asyncio.create_task(self._flush_ack())
            return
        if count_for_threshold:
            if self._ack_timer_task is None or self._ack_timer_task.done():
                self._ack_timer_task = asyncio.create_task(self._delayed_ack())
        elif self._ack_timer_task is None or self._ack_timer_task.done():
            self._ack_timer_task = asyncio.create_task(self._delayed_ack())

    async def _delayed_ack(self) -> None:
        await asyncio.sleep(self.config.ack_delay_s)
        await self._flush_ack()

    async def _flush_ack(self) -> None:
        if self._pending_ack_seq <= self._last_sent_ack_seq:
            return
        self._ack_frames_since_flush = 0
        self._ack_bytes_since_flush = 0
        await self._send_frame({"type": "t.ack", "ack": self._pending_ack_seq})
        self._last_sent_ack_seq = self._pending_ack_seq

    async def _send_frame(self, frame: Mapping[str, Any]) -> None:
        await self._send_text(encode_frame(frame))

    async def _send_text(self, text: str) -> None:
        if self._ws is None:
            return
        async with self._send_lock:
            await self._ws.send(text)

    def _next_unsent_entry(self, epoch: int) -> _OutboxEntry | None:
        for entry in self._outbox:
            if entry.sent_epoch != epoch:
                return entry
        return None

    def _first_unacked_or_next_seq(self) -> int:
        return self._outbox[0].seq if self._outbox else self._next_outgoing_seq

    def _trim_outbox(self, ack: int) -> None:
        while self._outbox and self._outbox[0].seq <= ack:
            entry = self._outbox.popleft()
            self._outbox_bytes -= entry.byte_len

    def _trim_outbox_from_peer_ack(self, ack: int) -> None:
        if ack >= self._next_outgoing_seq:
            raise TransportError(CloseCode.PROTOCOL_ERROR, "peer acked unsent data")
        first_unacked = self._first_unacked_or_next_seq()
        if ack < first_unacked:
            return
        self._trim_outbox(ack)

    def _reset_fresh_session(self) -> None:
        self._outbox.clear()
        self._outbox_bytes = 0
        self._next_outgoing_seq = 1
        self._delivered_next_seq = 1
        self._pending_ack_seq = 0
        self._last_sent_ack_seq = 0
        self._duplicate_run_count = 0
        self._duplicate_run_started_at = None

    def _outbox_limit_for_current_state(self) -> int:
        if self._state in {TransportState.DISCONNECTED, TransportState.CONNECTING}:
            return min(self._max_outbox_bytes, self._disconnected_soft_cap_bytes())
        return self._max_outbox_bytes

    def _disconnected_soft_cap_bytes(self) -> int:
        configured = self.config.disconnected_outbox_soft_cap_bytes
        if configured is not None:
            return max(0, configured)
        return max(1, self._max_outbox_bytes // 2)

    def _max_disconnected_duration_s(self) -> float:
        configured = self.config.max_disconnected_duration_s
        if configured is not None:
            return max(0.0, configured)
        return self._resume_ttl_s

    def _record_duplicate_data(self) -> None:
        now = time.monotonic()
        if (
            self._duplicate_run_started_at is None
            or now - self._duplicate_run_started_at > DEFAULT_DUPLICATE_ABUSE_WINDOW_S
        ):
            self._duplicate_run_started_at = now
            self._duplicate_run_count = 1
            return
        self._duplicate_run_count += 1
        if self._duplicate_run_count >= DEFAULT_DUPLICATE_ABUSE_THRESHOLD:
            raise TransportError(CloseCode.PROTOCOL_ERROR, "duplicate data frame abuse")

    async def _emit_event(self, kind: str, *, reason: str | None = None) -> None:
        self._emit_event_nowait(
            TransportEvent(
                kind=kind,
                session_id=self._session_id,
                connection_epoch=self._connection_epoch or None,
                reason=reason,
            )
        )

    def _emit_event_nowait(self, event: TransportEvent) -> None:
        with contextlib.suppress(asyncio.QueueFull):
            self._event_queue.put_nowait(event)

    async def _put_closed_sentinel(self) -> None:
        with contextlib.suppress(asyncio.QueueFull):
            self._recv_queue.put_nowait(_CLOSED_SENTINEL)
