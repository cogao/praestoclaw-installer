"""
Scheduler service — unified trigger framework for cron, interval, and event jobs.

Jobs execute via AgentLoopV2.run_once() — full tool hook pipeline applies.
Results recorded in run history and optionally delivered to notify_channels.

Based on nanobot (agent pipeline + HEARTBEAT.md + CronTool) and
OpenClaw (session modes + run history).
"""

from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

from praestoclaw.bus.events import EventType, OutboundMessage
from praestoclaw.config.schema import ChannelType, CronConfig
from praestoclaw.cron.heartbeat import JOB_NAME as _HEARTBEAT_JOB_NAME
from praestoclaw.cron.job import Job as _Job
from praestoclaw.cron.job import detect_trigger_type as _detect_trigger_type
from praestoclaw.cron.job import parse_at_schedule as _parse_at_schedule
from praestoclaw.cron.job import safe_filename as _safe_filename
from praestoclaw.cron.preview import normalize_cron_for_apscheduler
from praestoclaw.utils.helpers import get_data_dir


def _resolve_tz(name: str | None) -> Any:
    """Resolve an IANA timezone name to a tzinfo. None → APScheduler default (tzlocal).

    Raises ValueError on an unknown IANA name so callers can return 400.
    """
    if not name:
        return None
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

    try:
        return ZoneInfo(name)
    except ZoneInfoNotFoundError as exc:
        raise ValueError(f"Unknown timezone: {name!r}") from exc


if TYPE_CHECKING:
    from praestoclaw.agent.loop_v2 import AgentLoopV2
    from praestoclaw.bus.queue import MessageBus


# ── Service ──────────────────────────────────────────────────────────────────


_LAST_ERROR_MAX_CHARS = 500


def _truncate_error(message: str | None) -> str | None:
    """Cap a persisted error message to 500 chars; empty/None → None."""
    if not message:
        return None
    return message[:_LAST_ERROR_MAX_CHARS]


class SchedulerService:
    """Unified scheduler: cron + interval + event triggers + heartbeat.

    Jobs execute via AgentLoopV2.run_once() with full hook pipeline.
    APScheduler imported lazily — not a hard dependency.
    """

    MAX_CONSECUTIVE_FAILURES = 5
    HISTORY_MAX_ENTRIES = 100
    CLOUD_NOTIFICATION_PUSH_TARGET = "teams"
    MEGAPHONE_ALERT_PREFIXES = (
        "📢 **小喇叭提醒**",
        "📢 **Megaphone Alert**",
        "📢 小喇叭提醒",
        "📢 Megaphone Alert",
    )

    @staticmethod
    def _has_deliverable_result(result: str) -> bool:
        """Return true when a job result contains user-facing content."""
        return bool(result and result.strip() != "(no response)")

    @classmethod
    def _should_deliver_result(cls, job: _Job, result: str) -> bool:
        """Return true when a job result should be auto-delivered."""
        if not cls._has_deliverable_result(result):
            return False
        if job.name.startswith("megaphone-") and not job.message:
            return cls._extract_megaphone_alert(result) != ""
        return True

    @classmethod
    def _extract_megaphone_alert(cls, result: str) -> str:
        """Extract the Megaphone alert block from model output.

        Some runs may prepend non-alert text (for example planning prose)
        before the final markdown alert. Delivery should use only the alert
        block starting at the first known Megaphone header.
        """
        text = result.strip()
        if not text:
            return ""
        starts = [text.find(prefix) for prefix in cls.MEGAPHONE_ALERT_PREFIXES]
        starts = [idx for idx in starts if idx >= 0]
        if not starts:
            return ""
        return text[min(starts) :].strip()

    def __init__(
        self,
        config: CronConfig,
        bus: MessageBus | None = None,
        active_channels_fn: Any = None,
        *,
        data_dir: Path | None = None,
    ) -> None:
        self._config = config
        self._bus = bus
        self._active_channels_fn = active_channels_fn  # () -> list[str]
        self._agent_loop: AgentLoopV2 | None = None
        self._jobs: dict[str, _Job] = {}
        self._scheduler: Any = None
        self._running = False
        self._event_subscriptions: list[
            tuple[str, EventType, Any]
        ] = []  # (job_name, event_type, handler)
        self._job_semaphore = asyncio.Semaphore(config.max_concurrent_jobs)
        # Buffered notifications for when no channel is active at delivery time
        self._pending_notifications: list[dict[str, Any]] = []
        self._pending_lock = asyncio.Lock()
        self._max_pending = 100

        # Daily run counters for HISTORY summary (per-job, per-day)
        self._daily_counts: dict[str, dict[str, Any]] = {}

        # Cron data: explicit data_dir > ~/.praestoclaw (user-level default)
        self._data_dir = data_dir or get_data_dir()
        self._cron_dir = self._data_dir / "cron"
        self._runs_dir = self._cron_dir / "runs"
        self._jobs_file = self._cron_dir / "jobs.json"

        # Load dynamic jobs (all jobs managed via CronTool, no config-defined jobs)
        self._load_dynamic_jobs()

    def set_agent_loop(self, agent_loop: AgentLoopV2) -> None:
        """Wire the agent loop for job execution. Called by Runtime."""
        self._agent_loop = agent_loop

    # ── Lifecycle ────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Load jobs, register heartbeat, start APScheduler."""
        if not self._config.enabled:
            logger.info("Scheduler disabled — skipping start")
            return

        try:
            from apscheduler.schedulers.asyncio import AsyncIOScheduler
        except ImportError:
            logger.warning("apscheduler not installed — scheduler will not run")
            return

        self._scheduler = AsyncIOScheduler()

        # Register all enabled jobs
        for job in self._jobs.values():
            if job.enabled:
                self._register_trigger(job)

        # Register heartbeat
        if self._config.heartbeat.enabled:
            self._register_heartbeat()

        self._scheduler.start()
        self._running = True

        # Flush buffered notifications when any channel (re)connects
        if self._bus:
            self._bus.events.on(EventType.CHANNEL_CONNECTED, self._on_channel_connected)

        logger.info(
            "Scheduler started ({} jobs, heartbeat={})",
            len([j for j in self._jobs.values() if j.enabled]),
            self._config.heartbeat.enabled,
        )

    async def stop(self) -> None:
        """Graceful shutdown."""
        if self._scheduler and self._running:
            self._scheduler.shutdown(wait=False)
            self._running = False
            # Unsubscribe event triggers
            if self._bus:
                for _name, event_type, handler in self._event_subscriptions:
                    self._bus.events.off(event_type, handler)
                self._bus.events.off(EventType.CHANNEL_CONNECTED, self._on_channel_connected)
            self._event_subscriptions.clear()
            # Flush pending daily summaries to HISTORY.md
            self.flush_all_daily_summaries()
            logger.info("Scheduler stopped")

    # ── Job management ───────────────────────────────────────────────────

    @staticmethod
    def _validate_schedule(schedule: str | int) -> None:
        """Validate schedule format. Raises ValueError on invalid input."""
        trigger_type = _detect_trigger_type(schedule)
        if trigger_type == "at":
            schedule_str = str(schedule).strip()
            if len(schedule_str) > 2 and schedule_str[2:3] == ":":
                value = schedule_str[3:]
                if not value:
                    raise ValueError(
                        f"Invalid at schedule '{schedule}'. "
                        "Use 'at', 'at:+SECONDS', or 'at:ISO_DATETIME'"
                    )
                if value.startswith("+"):
                    try:
                        delay = int(value[1:])
                    except ValueError:
                        raise ValueError(
                            f"Invalid at schedule '{schedule}'. "
                            "Use 'at', 'at:+SECONDS', or 'at:ISO_DATETIME'"
                        ) from None
                    if delay <= 0:
                        raise ValueError(f"Delay must be positive, got {delay}")
                elif value:
                    try:
                        dt = datetime.fromisoformat(value)
                    except ValueError:
                        raise ValueError(f"Invalid ISO datetime in schedule '{schedule}'") from None
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=UTC)
                    if dt < datetime.now(UTC):
                        raise ValueError(f"Schedule time is in the past: {value}")
        elif trigger_type == "cron":
            try:
                from apscheduler.triggers.cron import CronTrigger

                CronTrigger.from_crontab(normalize_cron_for_apscheduler(str(schedule)))
            except ImportError:
                pass
            except (ValueError, TypeError) as exc:
                raise ValueError(f"Invalid cron expression '{schedule}': {exc}") from exc
        elif trigger_type == "interval":
            if int(schedule) <= 0:
                raise ValueError(f"Interval must be positive, got {schedule}")
        elif trigger_type == "event":
            valid = {et.value for et in EventType}
            if str(schedule) not in valid:
                raise ValueError(
                    f"Unknown event type '{schedule}'. Valid: {', '.join(sorted(valid))}"
                )

    def add_job(
        self,
        name: str,
        schedule: str | int,
        prompt: str = "",
        *,
        message: str | None = None,
        agent: str = "default",
        session_mode: str = "isolated",
        notify_channels: list[str] | None = None,
        exclude_tools: list[str] | None = None,
        dynamic: bool = True,
        channel: ChannelType | None = None,
        channel_id: str | None = None,
        tool: str | None = None,
        arguments: dict[str, Any] | None = None,
        timezone: str | None = None,
        description: str | None = None,
    ) -> None:
        """Register a new job (or replace an existing one). Validates schedule before persisting."""
        if name == _HEARTBEAT_JOB_NAME:
            raise ValueError(f"Cannot create or replace reserved internal job '{name}'.")
        existing = self._jobs.get(name)

        self._validate_schedule(schedule)
        if timezone:
            _resolve_tz(timezone)  # validate IANA name; raises ValueError on bad name

        # Enforce exactly one mode
        modes = sum(1 for x in (message, prompt, tool) if x)
        if modes == 0:
            raise ValueError("One of 'message', 'prompt', or 'tool' is required.")
        if modes > 1:
            raise ValueError("'message', 'prompt', and 'tool' are mutually exclusive.")

        # Validation passed — now safe to remove old job before inserting new one
        now_iso = datetime.now(UTC).isoformat()
        old_created_at: str | None = None
        if existing is not None:
            old_created_at = existing.created_at
            self.remove_job(name)

        job = _Job(
            name=name,
            schedule=schedule,
            agent=agent,
            prompt=prompt,
            message=message,
            tool=tool,
            arguments=arguments,
            session_mode=session_mode,
            notify_channels=notify_channels if notify_channels is not None else ["*"],
            exclude_tools=exclude_tools or [],
            dynamic=dynamic,
            channel=channel,
            channel_id=channel_id,
            created_at=old_created_at or now_iso,  # preserve original on replace
            updated_at=now_iso if existing is not None else None,
            timezone=timezone,
            description=description,
        )
        self._jobs[name] = job

        if self._running:
            self._register_trigger(job)

        if dynamic:
            self._persist_dynamic_jobs()

        logger.info("Added job '{}' (schedule={})", name, schedule)

    def _check_job(self, name: str) -> None:
        """Raise ValueError if job doesn't exist or is reserved."""
        if name == _HEARTBEAT_JOB_NAME:
            raise ValueError(f"Cannot modify reserved internal job '{name}'.")
        if name not in self._jobs:
            raise ValueError(f"Job '{name}' not found.")

    def remove_job(self, name: str) -> None:
        """Remove a job."""
        self._check_job(name)
        job = self._jobs.pop(name)
        if self._running:
            self._unregister_trigger(job)
        if job.dynamic:
            self._persist_dynamic_jobs()
        logger.info("Removed job '{}'", name)

    def enable(self, name: str) -> None:
        """Enable a disabled job."""
        self._check_job(name)
        job = self._jobs[name]
        job.enabled = True
        job.failure_count = 0
        if self._running:
            self._unregister_trigger(job)  # remove stale subscription first
            self._register_trigger(job)
        if job.dynamic:
            self._persist_dynamic_jobs()
        logger.info("Enabled job '{}'", name)

    def disable(self, name: str) -> None:
        """Disable a job without removing it."""
        self._check_job(name)
        job = self._jobs[name]
        job.enabled = False
        if self._running:
            self._unregister_trigger(job)
        if job.dynamic:
            self._persist_dynamic_jobs()
        logger.info("Disabled job '{}'", name)

    async def run_job(self, name: str, *, background: bool = False) -> str | None:
        """Trigger a job immediately.

        If background=True, fires the job in a background task and returns None
        immediately (result delivered via notify_channels when done).
        """
        self._check_job(name)
        job = self._jobs[name]
        if background:
            import asyncio

            asyncio.create_task(self._execute_job(job))
            return None
        return await self._execute_job(job)

    def list_jobs(self) -> list[dict[str, Any]]:
        """All jobs with status."""
        result = []
        for job in self._jobs.values():
            next_run = None
            if self._scheduler and job.enabled:
                ap_job = self._scheduler.get_job(job.name)
                if ap_job and ap_job.next_run_time:
                    next_run = ap_job.next_run_time.isoformat()
            mode = "message" if job.message else ("tool" if job.tool else "prompt")
            entry: dict[str, Any] = {
                "name": job.name,
                "schedule": job.schedule,
                "trigger_type": _detect_trigger_type(job.schedule),
                "mode": mode,
                "agent": job.agent,
                "enabled": job.enabled,
                "timezone": job.timezone,
                "session_mode": job.session_mode,
                "failure_count": job.failure_count,
                "dynamic": job.dynamic,
                "next_run": next_run,
                "next_run_at": next_run,
                "status": self._compute_status(job),
                "description": job.description,
                "last_run_at": job.last_run_at,
                "last_status": job.last_status,
                "last_error": job.last_error,
                "notify_channels": job.notify_channels,
                "exclude_tools": job.exclude_tools,
                "created_at": job.created_at,
                "updated_at": job.updated_at,
            }
            if job.message:
                entry["message"] = job.message[:100]
            if job.prompt:
                entry["prompt"] = job.prompt
            if job.tool:
                entry["tool"] = job.tool
            result.append(entry)
        return result

    # Note: `last_status` is the persisted outcome of the previous execution
    # (success/error/None); `status` is the unified UI badge state derived
    # from enabled / _running / last_status.
    @staticmethod
    def _compute_status(job: _Job) -> str:
        """Map a Job's runtime state to a unified UI badge value."""
        if not job.enabled:
            return "disabled"
        if job._running:
            return "running"
        if job.last_status == "error":
            return "error"
        return "idle"

    def update_job(self, name: str, payload: dict[str, Any]) -> None:
        """Partial-merge ``payload`` into the existing Job (BACK-09).

        Only keys present in ``payload`` are assigned; untouched Job fields
        keep their prior value. The job ``name`` is treated as read-only —
        renaming requires recreating the job (out of scope here). Schedule
        changes re-validate and re-register the trigger.
        """
        self._check_job(name)
        job = self._jobs[name]

        # ``name`` is identity — never mutated through update_job.
        payload = {k: v for k, v in payload.items() if k != "name"}

        mutable_fields = {
            "schedule",
            "agent",
            "prompt",
            "message",
            "tool",
            "arguments",
            "session_mode",
            "notify_channels",
            "exclude_tools",
            "enabled",
            "description",
            "timezone",
        }
        unknown = set(payload) - mutable_fields
        if unknown:
            raise ValueError(f"Unknown field(s) in update payload: {sorted(unknown)}")

        # Normalize empty-string timezone to None — empty IANA name is meaningless,
        # and otherwise it would skip validation below while still being assigned.
        if "timezone" in payload and payload["timezone"] == "":
            payload["timezone"] = None

        schedule_changed = "schedule" in payload and payload["schedule"] != job.schedule
        tz_changed = "timezone" in payload and payload["timezone"] != job.timezone
        enabled_changed = "enabled" in payload and bool(payload["enabled"]) != bool(job.enabled)
        if schedule_changed:
            self._validate_schedule(payload["schedule"])
        if "timezone" in payload and payload["timezone"] is not None:
            _resolve_tz(payload["timezone"])  # validate IANA name; raises ValueError on bad name

        for key, value in payload.items():
            setattr(job, key, value)

        job.updated_at = datetime.now(UTC).isoformat()

        if self._running and (schedule_changed or tz_changed or enabled_changed):
            self._unregister_trigger(job)
            if job.enabled:
                self._register_trigger(job)

        if job.dynamic:
            self._persist_dynamic_jobs()

        logger.info("Updated job '{}' (fields={})", name, sorted(payload))

    def health(self) -> dict[str, Any]:
        """Scheduler health status."""
        active = sum(1 for j in self._jobs.values() if j.enabled)
        disabled = sum(1 for j in self._jobs.values() if not j.enabled)
        return {
            "running": self._running,
            "total_jobs": len(self._jobs),
            "active_jobs": active,
            "disabled_jobs": disabled,
            "heartbeat_enabled": self._config.heartbeat.enabled,
        }

    # ── Trigger registration ─────────────────────────────────────────────

    def _unregister_trigger(self, job: _Job) -> None:
        """Remove a job's trigger from APScheduler or EventBus."""
        trigger_type = _detect_trigger_type(job.schedule)

        if trigger_type == "at":
            # Cancel pending DateTrigger if registered in APScheduler
            if self._scheduler:
                try:
                    self._scheduler.remove_job(job.name)
                except Exception:
                    pass  # May not be registered (immediate or already fired)
            return
        elif trigger_type == "event" and self._bus:
            to_remove = [(n, et, h) for n, et, h in self._event_subscriptions if n == job.name]
            for name, et, handler in to_remove:
                self._bus.events.off(et, handler)
                self._event_subscriptions.remove((name, et, handler))
        elif self._scheduler:
            try:
                self._scheduler.remove_job(job.name)
            except Exception:
                pass

    def _register_trigger(self, job: _Job) -> None:
        """Register appropriate trigger in APScheduler or EventBus."""
        trigger_type = _detect_trigger_type(job.schedule)

        if trigger_type == "event":
            self._register_event_trigger(job)
            return

        if trigger_type == "at":
            self._register_at_trigger(job)
            return

        if not self._scheduler:
            return

        try:
            if trigger_type == "cron":
                from apscheduler.triggers.cron import CronTrigger

                tz = _resolve_tz(job.timezone)
                normalized = normalize_cron_for_apscheduler(str(job.schedule))
                trigger = (
                    CronTrigger.from_crontab(normalized, timezone=tz)
                    if tz
                    else CronTrigger.from_crontab(normalized)
                )
            else:  # interval
                from apscheduler.triggers.interval import IntervalTrigger

                trigger = IntervalTrigger(seconds=int(job.schedule))

            self._scheduler.add_job(
                self._execute_job,
                trigger=trigger,
                args=[job],
                id=job.name,
                name=job.name,
                replace_existing=True,
                max_instances=1,
            )
            logger.debug("Registered {} trigger for '{}'", trigger_type, job.name)
        except Exception as exc:
            logger.error("Failed to register trigger for '{}': {}", job.name, exc)

    def _register_at_trigger(self, job: _Job) -> None:
        """Execute a job at a specific time, then auto-remove on success.

        Schedule formats (nanobot at_iso pattern):
          "at"                            — execute immediately
          "at:+60"                        — execute after 60 seconds
          "at:2026-03-04T15:00:00"        — execute at absolute ISO datetime
          "at:2026-03-04T15:00:00+08:00"  — execute at absolute ISO with timezone
        """
        run_at = _parse_at_schedule(str(job.schedule))

        if run_at is not None and self._scheduler:
            # Scheduled one-shot via APScheduler DateTrigger
            from apscheduler.triggers.date import DateTrigger

            async def _run_and_remove_scheduled() -> None:
                result = await self._execute_job(job)
                if result is not None:  # success — clean up
                    self.remove_job(job.name)
                    logger.info("One-shot job '{}' completed and removed", job.name)
                else:  # failure — keep for inspection
                    self.disable(job.name)
                    logger.warning("One-shot job '{}' failed — disabled for inspection", job.name)

            self._scheduler.add_job(
                _run_and_remove_scheduled,
                trigger=DateTrigger(run_date=run_at),
                id=job.name,
                name=job.name,
                replace_existing=True,
            )
            logger.info("One-shot job '{}' scheduled for {}", job.name, run_at.isoformat())
        else:
            # Immediate execution
            async def _run_and_remove() -> None:
                result = await self._execute_job(job)
                if result is not None:  # success — clean up
                    self.remove_job(job.name)
                    logger.info("One-shot job '{}' completed and removed", job.name)
                else:  # failure — keep for inspection
                    self.disable(job.name)
                    logger.warning("One-shot job '{}' failed — disabled for inspection", job.name)

            try:
                loop = asyncio.get_running_loop()
                loop.create_task(_run_and_remove())
            except RuntimeError:
                logger.warning("No event loop — cannot schedule one-shot job '{}'", job.name)

    def _register_event_trigger(self, job: _Job) -> None:
        """Subscribe to EventBus for event-triggered jobs."""
        if not self._bus:
            logger.warning("No bus — cannot register event trigger for '{}'", job.name)
            return

        event_name = str(job.schedule)
        # Find matching EventType
        for et in EventType:
            if et.value == event_name:

                async def _handler(event_type: EventType, payload: dict, _job: _Job = job) -> None:
                    await self._execute_job(_job)

                self._bus.events.on(et, _handler)
                self._event_subscriptions.append((job.name, et, _handler))
                logger.debug("Registered event trigger for '{}' on {}", job.name, event_name)
                return

        logger.warning("Unknown event type '{}' for job '{}'", event_name, job.name)

    def _register_heartbeat(self) -> None:
        """Register the built-in heartbeat interval job."""
        interval = self._config.heartbeat.interval

        job = _Job(
            name=_HEARTBEAT_JOB_NAME,
            schedule=interval,
            agent="default",
            prompt="",  # built dynamically in _execute_heartbeat
            session_mode="persistent",  # single JSONL file; in-memory cleared per run
            notify_channels=[],  # heartbeat notifies via notify() tool, not result broadcast
        )
        self._jobs[_HEARTBEAT_JOB_NAME] = job

        if self._scheduler:
            from apscheduler.triggers.interval import IntervalTrigger

            self._scheduler.add_job(
                self._execute_heartbeat,
                trigger=IntervalTrigger(seconds=interval),
                id=_HEARTBEAT_JOB_NAME,
                name=_HEARTBEAT_JOB_NAME,
                replace_existing=True,
                max_instances=1,
            )
        logger.info("Heartbeat registered (every {}s)", interval)

    # ── Execution ────────────────────────────────────────────────────────

    async def _execute_job(self, job: _Job) -> str | None:
        """Execute a job via AgentLoopV2.run_once()."""
        if not self._agent_loop:
            logger.error("Agent loop not set — cannot execute '{}'", job.name)
            return None

        # Guard against concurrent execution (especially for event triggers)
        if job._running:
            logger.debug("Job '{}' already running — skipping", job.name)
            return None
        job._running = True

        ts = datetime.now(UTC).strftime("%Y%m%dT%H%M%S")
        session_id = (
            f"scheduler_{job.name}_{ts}"
            if job.session_mode == "isolated"
            else f"scheduler_{job.name}"
        )

        started = datetime.now(UTC)
        try:
            logger.info("Executing job '{}' (session={})", job.name, session_id)
            async with self._job_semaphore:
                result: str = ""
                # Don't pass job.channel_id — it's the original conversation ID
                # from creation time, which is stale (ReplyContext expired after 15m).
                # Tools like notify will use the bare channel name → push frame path.
                if job.message:
                    # Message mode — zero execution, deliver static text
                    result = job.message
                elif job.tool:
                    # Tool mode — pre-flight safety checks + direct registry call.
                    # ApprovalGate is NOT run here (already approved at scheduling time,
                    # arguments are fixed). Only EStop + RBAC + post-tool hooks.
                    if job.tool == "config_praestoclaw":
                        raise RuntimeError("config_praestoclaw is not permitted in cron jobs")
                    registry = getattr(self._agent_loop, "_tool_registry", None)
                    if not registry:
                        raise RuntimeError("Tool registry not available")

                    # MCP tools may disconnect between scheduling and execution.
                    # Attempt reconnect before pre-flight so tool_ref is available.
                    if registry.get(job.tool) is None and job.tool.startswith("MCP_"):
                        mcp_mgr = getattr(registry, "_mcp_manager", None)
                        if mcp_mgr is not None:
                            parts = job.tool.split("_", 2)  # ["MCP", server, tool]
                            if len(parts) >= 2:
                                server_name = parts[1]
                                try:
                                    await mcp_mgr.describe_server(server_name)
                                    logger.info(
                                        "MCP server '{}' reconnected for cron job '{}'",
                                        server_name,
                                        job.name,
                                    )
                                except Exception as exc:
                                    logger.warning(
                                        "MCP reconnect failed for '{}': {}",
                                        server_name,
                                        exc,
                                    )

                    # Pre-flight: EStop + RBAC (skip ApprovalGate — already
                    # approved at scheduling time, arguments are fixed)
                    from praestoclaw.hooks.handlers import ApprovalGate
                    from praestoclaw.hooks.manager import (
                        HookVerdict,
                        PostToolHookContext,
                        PreToolHookContext,
                    )

                    hooks = getattr(self._agent_loop, "_hooks", None)
                    if hooks and hasattr(hooks, "dispatch_checked"):
                        tool_ref = registry.get(job.tool)
                        pre_ctx = PreToolHookContext(
                            tool_name=job.tool,
                            args=job.arguments or {},
                            agent_name="scheduler",
                            session_id=session_id,
                            tool_ref=tool_ref,
                            channel=job.channel,
                        )
                        pre_result = await hooks.dispatch_checked(
                            "pre_tool_use",
                            pre_ctx,
                            exclude_types=(ApprovalGate,),
                        )
                        if pre_result.verdict == HookVerdict.REJECT:
                            raise RuntimeError(f"Blocked by security policy: {pre_result.reason}")

                    is_hb = job.name == _HEARTBEAT_JOB_NAME
                    result = await registry.execute(
                        job.tool,
                        dict(job.arguments or {}),
                        actor="scheduler",
                        session_id=session_id,
                        channel=job.channel,
                        metadata={
                            "source": "heartbeat" if is_hb else "cron",
                            "job_name": job.name,
                        },
                    )

                    # Post-flight: LeakScanner + Auditor
                    if hooks and hasattr(hooks, "dispatch_checked"):
                        post_ctx = PostToolHookContext(
                            tool_name=job.tool,
                            args=job.arguments or {},
                            result=result,
                            agent_name="scheduler",
                            session_id=session_id,
                        )
                        await hooks.dispatch_checked("post_tool_use", post_ctx)

                    if result.startswith("Error"):
                        raise RuntimeError(result)
                else:
                    # Task mode — full LLM loop with runtime context injection
                    effective_prompt = job.prompt
                    if job.name != _HEARTBEAT_JOB_NAME:
                        now_str = datetime.now(UTC).strftime("%Y-%m-%d %H:%M UTC")
                        auto_deliver = bool(job.notify_channels)
                        if auto_deliver:
                            delivery_note = (
                                "- Auto-delivery: your text output will be sent to the user "
                                "on their active channels (Teams, Web, CLI — whichever is connected).\n"
                                "- Do NOT use MCP or notify() to re-deliver the same content.\n"
                                "- Only use MCP if the task explicitly asks to send to OTHER "
                                "people or channels (e.g. 'post to #general', 'message Alice').\n"
                                "- Format output as markdown."
                            )
                        else:
                            delivery_note = (
                                "No auto-delivery configured. Use tools (notify, MCP, etc.) "
                                "to deliver results yourself as needed."
                            )
                        effective_prompt = (
                            f"[Scheduled task — {now_str}]\n\n"
                            f"## Context\n"
                            f"This is an unattended background task — the user cannot interact "
                            f"or ask follow-up questions. Your output must be self-contained.\n\n"
                            f"## Approach\n"
                            f"- Cross-reference multiple sources before producing the final result. "
                            f"Prefer thoroughness over speed.\n"
                            f"- Verify key facts with tools and skills rather than "
                            f"relying on assumptions.\n"
                            f"- If information is conflicting, state what you "
                            f"found and what you could not confirm.\n\n"
                            f"## Delivery\n"
                            f"{delivery_note}\n\n"
                            f"## Task\n\n"
                            f"{job.prompt}"
                        )

                    # For Cloud, use a non-routable channel_id so approval
                    # prompts go through the push path (job.channel_id may
                    # reference a stale ReplyContext on the gateway).
                    # For other channels (Web, CLI), leave empty so
                    # _send_approval_prompt doesn't misclassify as interactive.
                    channel_id = f"scheduler:{job.name}" if job.channel == ChannelType.CLOUD else ""
                    is_heartbeat = job.name == _HEARTBEAT_JOB_NAME
                    exclude_tools = ["cron"] if is_heartbeat else ["cron", "config_praestoclaw"]
                    exclude_tools.extend(
                        tool for tool in job.exclude_tools if tool not in exclude_tools
                    )
                    result = await self._agent_loop.run_once(
                        effective_prompt,
                        session_id=session_id,
                        channel=job.channel,
                        channel_id=channel_id,
                        metadata={
                            "source": "heartbeat" if is_heartbeat else "cron",
                            "job_name": job.name,
                        },
                        exclude_tools=exclude_tools,
                    )

                    source_error = self._megaphone_source_read_error(job.name, session_id)
                    if source_error:
                        raise RuntimeError(source_error)

            duration = (datetime.now(UTC) - started).total_seconds()
            self._record_run(job.name, ts, "success", result, duration, started_at=started)
            self._track_job_run(job.name, success=True)
            self._record_last_run(job, status="success", error=None)

            # Reset failure counter on success
            job.failure_count = 0

            # Deliver to channels ("*" = all active).
            # Skip for tool-mode jobs whose tool already handles delivery
            # (e.g. notify tool) to avoid double delivery.
            _SELF_DELIVERING_TOOLS = {"notify"}
            skip_notify = job.tool in _SELF_DELIVERING_TOOLS
            if (
                job.notify_channels
                and self._should_deliver_result(job, result)
                and self._bus
                and not skip_notify
            ):
                delivered_result = (
                    self._extract_megaphone_alert(result)
                    if job.name.startswith("megaphone-") and not job.message
                    else result
                )
                content = (
                    f"[🔔] {delivered_result}"
                    if job.message
                    else f"[📅 {job.name}]\n{delivered_result}"
                )
                notification = {
                    "channel_id": f"scheduler:{job.name}",
                    "content": content,
                    "metadata": {
                        "source": "scheduler",
                        "job_name": job.name,
                        "session_id": session_id,
                    },
                }
                await self._deliver_notification(notification, job.notify_channels)

            return result

        except Exception as exc:
            duration = (datetime.now(UTC) - started).total_seconds()
            logger.error("Job '{}' failed: {}", job.name, exc)
            self._record_run(
                job.name,
                ts,
                "failed",
                str(exc),
                duration,
                started_at=started,
                error_type=type(exc).__name__,
            )
            self._track_job_run(job.name, success=False, error=str(exc))
            self._record_last_run(job, status="error", error=str(exc))

            job.failure_count += 1
            if job.failure_count >= self.MAX_CONSECUTIVE_FAILURES:
                logger.warning(
                    "Job '{}' auto-disabled after {} failures",
                    job.name,
                    job.failure_count,
                )
                self.disable(job.name)

            # Notify user about job failure so it doesn't silently disappear
            if job.notify_channels and self._bus:
                # Fall back to the exception class name when the message is
                # empty (e.g. ``raise RuntimeError()``) — otherwise the user
                # sees the unhelpful literal "Error: None".
                error_msg = _truncate_error(str(exc)) or type(exc).__name__
                fail_content = (
                    f"[⚠️ {job.name} failed]\n"
                    f"Error: {error_msg}\n"
                    f"Failures: {job.failure_count}/{self.MAX_CONSECUTIVE_FAILURES}"
                )
                fail_notification = {
                    "channel_id": f"scheduler:{job.name}",
                    "content": fail_content,
                    "metadata": {
                        "source": "scheduler",
                        "job_name": job.name,
                        "session_id": session_id,
                        "status": "failed",
                    },
                }
                try:
                    await self._deliver_notification(fail_notification, job.notify_channels)
                except Exception as notify_exc:
                    logger.warning(
                        "Failed to deliver failure notification for '{}': {}",
                        job.name,
                        notify_exc,
                    )

            return None

        finally:
            job._running = False

    def _megaphone_source_read_error(self, job_name: str, session_id: str) -> str | None:
        if not job_name.startswith("megaphone-"):
            return None
        if job_name == "megaphone-email":
            source_prefixes = ("MCP_mail",)
        elif job_name == "megaphone-teams":
            source_prefixes = ("MCP_teams",)
        elif job_name.startswith("megaphone-calendar"):
            source_prefixes = ("MCP_calendar",)
        else:
            return None

        try:
            from praestoclaw.megaphone.audit import (
                audit_entry_is_failure,
                iter_session_audit_entries,
            )

            for entry in iter_session_audit_entries(self._data_dir, session_id):
                tool = str(entry.get("tool") or "")
                if not tool.startswith(source_prefixes):
                    continue
                preview = str(entry.get("result_preview") or "").lstrip()
                if audit_entry_is_failure(entry):
                    return f"Megaphone source read failed in {session_id}: {tool}: {preview[:240]}"
        except OSError as exc:
            logger.warning("Could not inspect Megaphone audit logs: {}", exc)
        return None

    async def _execute_heartbeat(self) -> None:
        """Execute heartbeat — delegates to praestoclaw.cron.heartbeat module.

        Uses persistent session mode (single JSONL file on disk for audit)
        but clears in-memory history before each run so the LLM starts
        with a clean context. Cross-run context comes from the state file,
        not session history.

        **Pre-flight optimisation**: Python-side checks determine which
        prompt sections need work. When all sections are idle, the run
        short-circuits with HEARTBEAT_OK — no LLM call, no token cost.
        """
        from praestoclaw.cron.heartbeat import (
            load_heartbeat_prompt,
            preflight_check,
            read_state,
            update_state,
        )

        state = read_state()
        started = datetime.now(UTC)
        ts = started.strftime("%Y%m%dT%H%M%S")

        try:
            # Fast path: if HEARTBEAT.md is disabled (empty override), skip everything
            from praestoclaw.utils.defaults import load_default

            if not load_default("HEARTBEAT.md", allow_empty_override=True):
                return

            # Pre-flight: skip LLM entirely when nothing needs attention.
            statuses = preflight_check()
            if not any(s.active for s in statuses.values()):
                logger.debug("Heartbeat pre-flight: all sections idle, skipping LLM call")
                update_state(state, "HEARTBEAT_OK", self._daily_counts.get(_HEARTBEAT_JOB_NAME))
                duration = (datetime.now(UTC) - started).total_seconds()
                self._record_run(
                    _HEARTBEAT_JOB_NAME, ts, "success", "HEARTBEAT_OK", duration, started_at=started
                )
                self._track_job_run(_HEARTBEAT_JOB_NAME, success=True)
                return

            prompt = load_heartbeat_prompt(state, statuses=statuses)
            if not prompt:
                return

            job = self._jobs.get(_HEARTBEAT_JOB_NAME)
            if not job:
                return

            active_names = [k for k, s in statuses.items() if s.active]
            logger.info("Heartbeat pre-flight: active sections = {}", active_names)

            # Clear in-memory session so LLM sees no prior conversation.
            # Disk JSONL keeps growing (append-only) for audit; in-memory
            # is just this run's messages.
            sessions = getattr(self._agent_loop, "_sessions", None)
            if sessions:
                sid = f"scheduler_{job.name}"
                sessions.replace_messages(sid, [])

            job.prompt = prompt
            result = await self._execute_job(job)

            update_state(state, result, self._daily_counts.get(_HEARTBEAT_JOB_NAME))

            # Deliver notification for non-OK results (Python-side, saves LLM
            # a notify() tool call round). LLM just produces content.
            from praestoclaw.cron.heartbeat import is_heartbeat_ok

            if not is_heartbeat_ok(result) and result and self._bus:
                notification = {
                    "channel_id": f"scheduler:{job.name}",
                    "content": f"[💓 heartbeat]\n{result}",
                    "metadata": {"source": "heartbeat", "job_name": job.name},
                }
                await self._deliver_notification(notification, ["*"])
        except Exception as exc:
            logger.error("Heartbeat failed: {}", exc)
            update_state(state, None, self._daily_counts.get(_HEARTBEAT_JOB_NAME))
            duration = (datetime.now(UTC) - started).total_seconds()
            self._record_run(
                _HEARTBEAT_JOB_NAME, ts, "failed", str(exc), duration, started_at=started
            )
            self._track_job_run(_HEARTBEAT_JOB_NAME, success=False, error=str(exc))

    def _record_last_run(self, job: _Job, *, status: str, error: str | None) -> None:
        """Update a job's persisted last-run snapshot (BACK-02 write path).

        Mutates the in-memory Job and, if the job is dynamic, flushes
        ``jobs.json`` so the state survives a service restart. The error
        message is truncated to 500 chars at this boundary so a multi-MB
        traceback never lands on disk.
        """
        job.last_run_at = datetime.now(UTC).isoformat()
        job.last_status = status
        job.last_error = _truncate_error(error)
        if job.dynamic:
            try:
                self._persist_dynamic_jobs()
            except Exception as exc:  # pragma: no cover — disk failure is best-effort
                logger.warning("Failed to persist last-run state for '{}': {}", job.name, exc)

    def _track_job_run(self, job_name: str, *, success: bool, error: str = "") -> None:
        """Accumulate daily run count. Flush previous day's summary on day change."""
        today = datetime.now(UTC).strftime("%Y-%m-%d")
        counts = self._daily_counts.get(job_name)

        # Day changed → flush yesterday's summary before starting new day
        if counts and counts["day"] != today:
            self._flush_daily_summary(job_name, counts)
            counts = None

        if counts is None:
            counts = {"day": today, "success": 0, "failed": 0, "last_error": ""}
            self._daily_counts[job_name] = counts

        if success:
            counts["success"] += 1
        else:
            counts["failed"] += 1
            if error:
                counts["last_error"] = error[:200]

    def _flush_daily_summary(self, job_name: str, counts: dict[str, Any]) -> None:
        """Write one HISTORY entry for a completed day's job runs."""
        s, f = counts["success"], counts["failed"]
        if s == 0 and f == 0:
            return

        label = "heartbeat" if job_name == _HEARTBEAT_JOB_NAME else f"cron:{job_name}"
        day = counts.get("day", "unknown")
        summary = f"{label} daily summary ({day})\n  did: {s} successful, {f} failed runs"
        if f and counts.get("last_error"):
            summary += f"\n  error: {counts['last_error'][:120]}"

        try:
            # Reuse agent loop's memory if available, else create temporary
            mem = getattr(self._agent_loop, "_memory", None)
            if mem is None:
                from praestoclaw.agent.memory import AgentMemory

                mem = AgentMemory(data_dir=self._cron_dir.parent)
                mem.history.append(summary, [], f"scheduler_{job_name}")
                mem.close()
            else:
                mem.history.append(summary, [], f"scheduler_{job_name}")
            logger.debug("Flushed daily summary for '{}' to HISTORY.md", job_name)
        except Exception as exc:
            logger.warning("Failed to flush daily summary for '{}': {}", job_name, exc)

    def flush_all_daily_summaries(self) -> None:
        """Flush all pending daily summaries (call on shutdown)."""
        for job_name, counts in list(self._daily_counts.items()):
            if counts["success"] > 0 or counts["failed"] > 0:
                self._flush_daily_summary(job_name, counts)
        self._daily_counts.clear()

    # ── Notification delivery with buffering ─────────────────────────────

    async def _deliver_notification(
        self, notification: dict[str, Any], notify_channels: list[str]
    ) -> None:
        """Deliver a notification to active channels, buffering if none are available."""
        if not self._bus:
            return
        # Flush previously buffered notifications first
        await self._flush_pending()

        targets = list(notify_channels)
        if "*" in targets and self._active_channels_fn:
            targets = self._active_channels_fn()
        targets = [t for t in targets if t != "*"]

        if not targets:
            if not self._active_channels_fn:
                # No channel resolver — buffering would never drain; drop.
                logger.debug("No active_channels_fn, dropping notification")
                return
            async with self._pending_lock:
                if len(self._pending_notifications) >= self._max_pending:
                    dropped = self._pending_notifications.pop(0)
                    logger.warning(
                        "Pending buffer full ({}), dropped oldest: {}",
                        self._max_pending,
                        dropped.get("metadata", {}).get("job_name", "?"),
                    )
                self._pending_notifications.append(notification)
                logger.info(
                    "No active channel for notification '{}', buffered ({} pending)",
                    notification.get("metadata", {}).get("job_name", "?"),
                    len(self._pending_notifications),
                )
            return

        await self._publish_to_targets(notification, targets)

    async def _flush_pending(self) -> None:
        """Drain buffered notifications if channels are now available.

        Copies and clears the buffer under the lock, then publishes
        outside the lock to avoid blocking on slow I/O.
        """
        if not self._pending_notifications or not self._active_channels_fn or not self._bus:
            return
        targets = self._active_channels_fn()
        if not targets:
            return
        async with self._pending_lock:
            if not self._pending_notifications:
                return
            pending = list(self._pending_notifications)
            self._pending_notifications.clear()
        logger.info("Flushing {} buffered notifications to {}", len(pending), targets)
        for notification in pending:
            await self._publish_to_targets(notification, targets)

    async def _publish_to_targets(self, notification: dict[str, Any], targets: list[str]) -> None:
        """Publish a notification to each target channel."""
        if not self._bus:
            return
        for channel in targets:
            try:
                channel_type = ChannelType.of(channel)
                metadata = dict(notification.get("metadata", {}))
                if channel_type == ChannelType.CLOUD and "push_target" not in metadata:
                    metadata["push_target"] = self.CLOUD_NOTIFICATION_PUSH_TARGET
                    logger.info(
                        "Publishing cron notification '{}' to cloud:{}",
                        notification.get("metadata", {}).get("job_name", "?"),
                        metadata["push_target"],
                    )
                out = OutboundMessage(
                    channel=channel_type,
                    channel_id=notification["channel_id"],
                    content=notification["content"],
                    metadata=metadata,
                )
                await self._bus.publish_outbound(out)
            except Exception as exc:
                logger.warning("Cron notify to '{}' failed: {}", channel, exc)

    async def _on_channel_connected(self, event_type: EventType, payload: dict) -> None:
        """Event handler: a channel just (re)connected — flush buffered notifications."""
        if self._pending_notifications:
            logger.info(
                "Channel '{}' connected, flushing pending notifications",
                payload.get("channel", "?"),
            )
            await self._flush_pending()

    # ── Persistence ──────────────────────────────────────────────────────

    def _load_dynamic_jobs(self) -> None:
        """Load dynamic jobs from ~/.praestoclaw/cron/jobs.json (or data_dir/cron)."""
        if not self._jobs_file.is_file():
            return
        try:
            data = json.loads(self._jobs_file.read_text(encoding="utf-8"))
            for item in data:
                name = item["name"]
                self._jobs[name] = _Job(
                    name=name,
                    schedule=item["schedule"],
                    agent=item.get("agent", "default"),
                    prompt=item["prompt"] if "prompt" in item else item.get("task", ""),
                    message=item.get("message"),
                    tool=item.get("tool"),
                    arguments=item.get("arguments"),
                    session_mode=item.get("session_mode", "isolated"),
                    notify_channels=item.get("notify_channels", ["*"]),
                    exclude_tools=item.get("exclude_tools", []),
                    enabled=item.get("enabled", True),
                    dynamic=True,
                    channel=item.get("channel"),
                    channel_id=item.get("channel_id"),
                    created_at=item.get("created_at"),
                    updated_at=item.get("updated_at"),
                    description=item.get("description"),
                    timezone=item.get("timezone"),
                    last_run_at=item.get("last_run_at"),
                    last_status=item.get("last_status"),
                    last_error=item.get("last_error"),
                )
            logger.debug("Loaded {} dynamic jobs", len(data))
        except Exception as exc:
            logger.warning("Failed to load dynamic jobs: {}", exc)

    def _persist_dynamic_jobs(self) -> None:
        """Save dynamic jobs to ~/.praestoclaw/cron/jobs.json (or data_dir/cron)."""
        self._cron_dir.mkdir(parents=True, exist_ok=True)
        dynamic = [
            {
                "name": j.name,
                "schedule": j.schedule,
                "agent": j.agent,
                "prompt": j.prompt,
                "session_mode": j.session_mode,
                "notify_channels": j.notify_channels,
                **({"exclude_tools": j.exclude_tools} if j.exclude_tools else {}),
                "enabled": j.enabled,
                **({"channel": j.channel} if j.channel else {}),
                **({"channel_id": j.channel_id} if j.channel_id else {}),
                **({"message": j.message} if j.message else {}),
                **({"tool": j.tool} if j.tool else {}),
                **({"arguments": j.arguments} if j.arguments is not None else {}),
                **({"created_at": j.created_at} if j.created_at else {}),
                **({"updated_at": j.updated_at} if j.updated_at else {}),
                **({"description": j.description} if j.description else {}),
                **({"timezone": j.timezone} if j.timezone else {}),
                **({"last_run_at": j.last_run_at} if j.last_run_at else {}),
                **({"last_status": j.last_status} if j.last_status else {}),
                **({"last_error": j.last_error} if j.last_error else {}),
            }
            for j in self._jobs.values()
            if j.dynamic
        ]
        self._jobs_file.write_text(
            json.dumps(dynamic, indent=2, ensure_ascii=False), encoding="utf-8"
        )

    def _record_run(
        self,
        job_id: str,
        run_id: str,
        status: str,
        result: str | None,
        duration: float,
        started_at: datetime | None = None,
        error_type: str | None = None,
    ) -> None:
        """Append run record to .praestoclaw/cron/runs/{job_id}.jsonl."""
        self._runs_dir.mkdir(parents=True, exist_ok=True)
        path = self._runs_dir / f"{_safe_filename(job_id)}.jsonl"
        record: dict[str, Any] = {
            "run_id": run_id,
            "triggered_at": (started_at or datetime.now(UTC)).isoformat(),
            "status": status,
            "result_preview": result[:500] if result else "",
            "duration_s": round(duration, 2),
        }
        if error_type:
            record["error_type"] = error_type
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

        # Auto-prune: keep last N entries
        self._prune_history(path)

    def _prune_history(self, path: Path) -> None:
        """Keep only the last HISTORY_MAX_ENTRIES lines."""
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
            if len(lines) > self.HISTORY_MAX_ENTRIES:
                path.write_text(
                    "\n".join(lines[-self.HISTORY_MAX_ENTRIES :]) + "\n",
                    encoding="utf-8",
                )
        except Exception:
            pass

    def get_history(self, job_id: str, limit: int = 20) -> list[dict]:
        """Read run history for a job."""
        path = self._runs_dir / f"{_safe_filename(job_id)}.jsonl"
        if not path.is_file():
            return []
        entries = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return entries[-limit:]
