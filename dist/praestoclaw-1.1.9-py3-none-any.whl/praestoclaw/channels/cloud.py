"""
Cloud channel — Gateway protocol adapter for PraestoClaw Cloud Gateway.

Connects to wss://<cloud-gateway>/connect using an Entra ID access token.
Supports two login methods:

  browser  — opens the default browser for interactive PKCE auth code flow
             (http://localhost callback, no redirect URI limitations).
  wam      — WAM broker (native OS auth dialog, no browser); falls back to
             browser PKCE if the app registration doesn't support broker.
             Requires msal[broker] on Windows.
  device   — device code flow (visit a URL + enter a code); works in
             headless / SSH / corporate environments that block browser launch.
             Only used when explicitly configured (many tenants disable this).
  auto     — (default) same as browser. WAM not attempted unless explicitly
             configured via login_method=wam.

The network protocol is implemented by ``praestoclaw.gateway_protocol``.
This channel bridges Gateway business envelopes to the local message bus.
"""

from __future__ import annotations

import asyncio
import contextlib
import html as _html
import json
import os
import random
import re
import socket
import time
import webbrowser
from collections import deque
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

import msal
from agent_gateway_protocol.gateway_protocol.v1.task import (
    EXECUTING_HEARTBEAT_NEXT_MS,
    TASK_HARD_CAP_MS,
    TASK_PROGRESS_TOPIC,
)
from agent_gateway_protocol.gateway_protocol.v1.u2u import (
    A2A_MESSAGE_SEND_TOPIC,
    U2U_MESSAGE_ASK_TOPIC,
    U2U_MESSAGE_DELIVER_TOPIC,
    U2U_MESSAGE_DELIVERED_TOPIC,
    U2U_MESSAGE_EXPIRED_TOPIC,
    U2U_MESSAGE_SEND_REJECTED_TOPIC,
    U2U_MESSAGE_SEND_TOPIC,
)
from loguru import logger
from rich.console import Console
from rich.panel import Panel

from praestoclaw.a2a.models import A2AEnvelope, A2AMessageType, A2AParty
from praestoclaw.bus.events import EventType, InboundMessage, StreamingChunk
from praestoclaw.bus.queue import MessageBus
from praestoclaw.channels.base import BaseChannel
from praestoclaw.channels.conv_ref_store import ConvRefStore
from praestoclaw.config.schema import ChannelType
from praestoclaw.gateway_protocol.business import (
    BusinessClientConfig,
    BusinessError,
    BusinessProtocolClient,
    ConversationBody,
    Dispatcher,
    Envelope,
)
from praestoclaw.gateway_protocol.transport import (
    GatewayTransportClient,
    TransportClientConfig,
    TransportState,
)
from praestoclaw.gateway_protocol.v1.transport import (
    GatewayV1TransportClient,
    v1_transport_config,
)
from praestoclaw.gateway_protocol.v2.awps import (
    AwpsGatewayTransportClient,
    awps_transport_config,
    negotiate_url_from_connect_url,
)
from praestoclaw.mcp.defaults import SHARED_ENTRA_CLIENT_ID
from praestoclaw.utils.helpers import get_auth_dir, webchat_url_from_connect
from praestoclaw.utils.html import html_to_markdown

# MSAL error codes that indicate admin consent is required or the user
# cannot consent to the requested permissions.  When the primary app
# registration triggers one of these, we fall back to the shared Entra
# client ID (aebc6443 — VS Code / Agency) which is pre-consented in
# most enterprise tenants.
_CONSENT_ERROR_CODES = frozenset(
    {
        "AADSTS90094",  # admin consent required
        "AADSTS65001",  # user/admin has not consented
        "AADSTS70011",  # invalid scope (consent not granted)
        "AADSTS650052",  # app needs permissions that require admin consent
        "AADSTS700024",  # client assertion audience not allowed
    }
)

# Scope used by the Microsoft 365 sign-in strategy (m365_auth).
#
# We deliberately request a Graph token rather than this app's own
# `<client_id>/.default` scope. The strategy borrows Teams Web's MSAL
# RefreshToken (client_id 5e3ce6c0-...), and that first-party client_id
# is *not* allowed to mint tokens for our self-registered cloud app
# (AADSTS65001 — no consent path exists, since Teams Web is a Microsoft
# app). Graph is in the same family-of-client-IDs and accepts the swap.
#
# This works **only because the gateway does not validate `aud`**
# (gateway/src/gateway/auth/jwt_auth.py:32 calls pyjwt.decode with
# verify_signature=False and the deployed config leaves jwt_audience
# empty). The gateway authenticates the request from the `oid` claim,
# which is identical regardless of audience. If the gateway later
# enables audience or signature checking, this scope must be revisited
# alongside that change. See docs/design/features/cloud-auth-lifecycle.md §9.
M365_TARGET_SCOPE = "https://graph.microsoft.com/.default"
_SHUTDOWN_TRANSPORT_CLOSE_TIMEOUT_S = 2.0

_console = Console()


@dataclass
class _PendingConversation:
    """Local bus response binding for one inbound Gateway request."""

    request_id: str
    conversation_id: str
    topic: str
    is_stream: bool
    response_future: asyncio.Future[dict[str, Any]] | None = None
    stream_queue: asyncio.Queue[dict[str, Any] | None] | None = None


class _HeartbeatTrackingOutbound:
    """Proxy around ``BusinessProtocolClient.outbound`` that observes beats.

    The executor-side ``TaskHeartbeatEmitter`` (see
    :mod:`praestoclaw.task.heartbeat`) only needs the ``send_event``
    method on whatever we hand it as ``_task_progress_sender``. We wrap
    that single method to bump the local ``last heartbeat`` clock for
    the originating carrier each time a ``task.progress`` envelope
    goes out, so ``_wait_a2a_task_with_heartbeat`` can extend the
    sync waiter as long as the executor is still alive. All other
    attributes pass through unchanged so callers that need richer
    outbound surface (request/notify) keep working.
    """

    __slots__ = ("_inner", "_on_beat")

    def __init__(self, inner: Any, *, on_beat: Any) -> None:
        self._inner = inner
        self._on_beat = on_beat

    async def send_event(
        self,
        topic: str,
        body: Any,
        *,
        headers: Any | None = None,
    ) -> None:
        if topic == TASK_PROGRESS_TOPIC:
            try:
                self._on_beat()
            except Exception:  # noqa: BLE001 — best-effort observability
                logger.exception("task heartbeat bookkeeping failed")
        await self._inner.send_event(topic, body, headers=headers)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)


def _decode_jwt_payload(token: str) -> dict[str, Any]:
    """Decode a JWT's payload without verifying the signature.

    Used when MSAL returns a cached token without ``id_token_claims``.
    We only need the identity claims (oid, tid, preferred_username) —
    the token is already trusted here (issued by MSAL from its own cache).
    """
    import base64

    try:
        parts = token.split(".")
        if len(parts) < 2:
            return {}
        payload = parts[1]
        payload += "=" * (-len(payload) % 4)
        raw = base64.urlsafe_b64decode(payload.encode("ascii"))
        claims = json.loads(raw.decode("utf-8"))
        return claims if isinstance(claims, dict) else {}
    except Exception:
        return {}


def _token_near_expiry(token: str, *, skew_s: int = 60) -> bool:
    """Return True when the JWT's ``exp`` claim is within *skew_s* seconds.

    Tokens without a parseable ``exp`` are treated as fresh (False) so we
    never falsely reject a usable token. Past-exp tokens always return True.
    """
    import time

    claims = _decode_jwt_payload(token)
    exp = claims.get("exp")
    if not isinstance(exp, (int, float)):
        return False
    return time.time() >= float(exp) - skew_s


class _SilentRefreshExhaustedError(Exception):
    """Raised when every silent token-refresh path has failed.

    The protocol startup path catches this distinctly so it avoids a
    guaranteed authentication failure loop.
    """


_ADAPTIVE_CARD_CONTENT_TYPE = "application/vnd.microsoft.card.adaptive"

# Bot Framework HTTP webhook abandons the request at ~240s; we abandon the
# sync future at 210s so the proactive notify route can take over before Teams
# surfaces "Request timed out".
_BOT_FRAMEWORK_WEBHOOK_CEILING_S = 240.0
_TEAMS_INBOUND_TIMEOUT_S = 210.0
_DEFAULT_INBOUND_TIMEOUT_S = 600.0

# a2a_task carrier — heartbeat-aware wait. As long as the executor keeps
# emitting ``task.progress`` heartbeats (cadence
# ``EXECUTING_HEARTBEAT_INTERVAL_MS = 30s``, advertising
# ``next_heartbeat_ms = 120s``), the carrier stays open. If a beat is
# missed by more than ``_A2A_TASK_HEARTBEAT_GRACE_S`` the carrier fails
# fast with ``timeout``. Hard cap mirrors the gateway-side
# ``TASK_HARD_CAP_MS`` (2h) so a runaway executor cannot leak the future
# forever. Spec: docs/design/features/task-protocol.md §5.
#
# Local grace is intentionally aligned with the protocol-advertised
# ``EXECUTING_HEARTBEAT_NEXT_MS`` (120 s). The advertised value is the
# *coordinator-side* deadline (the sender's gateway uses it to decide
# when to fail the task). On the executor side we are also subject to
# event-loop blocking from any sync I/O the LLM might trigger inside an
# ``async def execute`` (sqlite FTS5, ``os.walk``, ``read_text``… see
# issue #312). If a tool stalls the loop for 50–110 s the next
# heartbeat coroutine cannot run, and we would kill an otherwise
# healthy executor right before it recovers. Use a more lenient local
# grace so the executor side survives short blocks. The hard cap still
# bounds runaway turns.
_A2A_TASK_HEARTBEAT_GRACE_S = max(120.0, EXECUTING_HEARTBEAT_NEXT_MS / 1000.0)
_A2A_TASK_HARD_CAP_S = TASK_HARD_CAP_MS / 1000.0

TEAMS_SOURCES: tuple[str, ...] = ("teams_bridge", "cloud_teams")


_LONG_TASK_PLACEHOLDERS_ZH: tuple[str, ...] = (
    "⏳ 看起来是个长任务，还在进行中，请稍等。",
    "⏳ 任务还在跑，完成后会主动推给你～",
    "⏳ 这事儿需要点时间，请稍候。",
    "⏳ 好事多磨。正如星光穿越光年才落入眼眸，请再等一等。",
    "⏳ 字斟句酌中……美好的事物总需要一点时间来慢慢酝酿。",
    "⏳ 正在为您跋山涉水搜寻答案，请允许我再多准备片刻。",
    "⏳ 时间在代码间穿梭，正在为您编织最完美的回复，请静候佳音。",
    "⏳ 春风化雨，润物无声。您的专属结果正在悄然生成中……",
)

_LONG_TASK_PLACEHOLDERS_EN: tuple[str, ...] = (
    "⏳ Looks like a long one — still working on it, hang tight.",
    "⏳ Still cooking. I'll ping you when it's ready.",
    "⏳ This one needs a bit more time. Sit tight.",
    "⏳ Good things take time — like starlight that travels years to find your eyes.",
    "⏳ Choosing every word with care. The best replies are worth the wait.",
    "⏳ Going the extra mile to track this down — give me just a little longer.",
    "⏳ Weaving the perfect answer out of the code. Stay with me.",
    "⏳ Quietly putting the pieces together for you, like rain shaping a garden overnight.",
)


def _looks_chinese(text: str) -> bool:
    """Return True when *text* contains any CJK Unified Ideograph."""

    if not text:
        return False
    for ch in text:
        if "\u4e00" <= ch <= "\u9fff":
            return True
    return False


def _pick_long_task_placeholder(user_text: str) -> str:
    """Pick a friendly long-task placeholder, language-matched when possible."""

    pool = _LONG_TASK_PLACEHOLDERS_ZH if _looks_chinese(user_text) else _LONG_TASK_PLACEHOLDERS_EN
    return random.choice(pool)  # noqa: S311 — UX copy, not security-sensitive


def _extract_card_from_activity_json(text: str) -> dict[str, Any] | None:
    """Return the Adaptive Card from a JSON-serialized Bot Framework Activity.

    ``TeamsApprovalFormatter`` and ``teams_cards.wrap_for_teams`` produce
    ``{"type":"message","attachments":[{"contentType":"...adaptive",
    "content":{...}}]}`` and the cloud channel currently delivers it as a
    JSON-serialized string. Without this helper the gateway sees the raw
    JSON in ``content.text`` and Teams renders it as a literal blob (the
    user-visible ``{"type":"message",...}`` regression). Recovering the
    inner card lets the notify body carry it as ``content.card`` per
    docs/05-channels.md \u00a73.4.

    Returns ``None`` when *text* is not such an envelope (plain string,
    non-JSON, or not a BF message activity).
    """
    if not isinstance(text, str):
        return None
    stripped = text.lstrip()
    if not stripped.startswith("{"):
        return None
    try:
        parsed = json.loads(stripped)
    except (ValueError, TypeError):
        return None
    if not isinstance(parsed, dict) or parsed.get("type") != "message":
        return None
    attachments = parsed.get("attachments")
    if not isinstance(attachments, list):
        return None
    for attachment in attachments:
        if not isinstance(attachment, dict):
            continue
        if attachment.get("contentType") != _ADAPTIVE_CARD_CONTENT_TYPE:
            continue
        inner = attachment.get("content")
        if isinstance(inner, dict):
            return inner
    return None


def _maybe_unwrap_task_carrier(body: dict[str, Any]) -> dict[str, Any]:
    """Translate a task-bearing ``a2a.message.send`` body into a text body.

    Phase-1 client: when the incoming carrier advertises
    ``content_type=application/vnd.praestoclaw.task+json`` we want to
    keep using the existing conversation pipeline (which only
    understands ``text`` / ``file_chunk`` per
    ``agent_gateway_protocol.gateway_protocol.v1.business.data``). We surface
    ``task.intent.summary`` as the user-facing text and stash the full
    task payload in ``metadata.task`` so future tooling can read it.

    No-op for non-task bodies — existing plain a2a flows are untouched.
    """
    from praestoclaw.task import (  # local import to avoid cycle at module load
        CONTENT_TYPE_TASK_REQUEST,
        extract_task_request,
    )

    content = body.get("content")
    if not isinstance(content, dict):
        return body
    if content.get("content_type") != CONTENT_TYPE_TASK_REQUEST:
        return body

    task = extract_task_request(body)
    if task is None:
        # Malformed task body — pass through unchanged; the conversation
        # parser will raise a clear ``content.content_type is invalid``
        # error rather than letting us silently lose the payload.
        return body

    summary = task.intent.summary or "(task with no summary)"
    text = f"[task {task.task_id}] {summary}"

    rewritten = dict(body)
    rewritten["content"] = {
        "content_type": "text",
        "text": text,
        "format": "text",
    }
    metadata = dict(rewritten.get("metadata") or {})
    # SECURITY: the keys below are derived by *us* from the validated
    # task carrier — they must not be spoofable by the peer's freeform
    # ``envelope.metadata``. Pop any peer-supplied value for these
    # trusted keys *first* so that the conditional re-assignments
    # below (empty ``intent.summary``, missing ``sender``) cannot
    # leave a peer value behind. ``source`` in particular gates
    # downstream tool-exclusion policy (e.g. exclude_tools for
    # non-user input); allowing the peer to set ``source="user"``
    # would unmask cron/spawn/a2a in the recipient's LLM context.
    # ``task_sender_id`` is impersonation-prone (heartbeat routing).
    for _trusted_key in ("task", "task_id", "task_summary", "task_sender_id", "source"):
        metadata.pop(_trusted_key, None)
    metadata["task"] = task.model_dump(mode="json")
    metadata["task_id"] = task.task_id
    if task.intent.summary:
        metadata["task_summary"] = task.intent.summary
    sender = body.get("sender")
    if isinstance(sender, dict):
        sender_id = sender.get("id") or sender.get("user_id")
        if isinstance(sender_id, str) and sender_id:
            metadata["task_sender_id"] = sender_id
    metadata["source"] = "a2a_task"
    rewritten["metadata"] = metadata
    return rewritten


class CloudChannel(BaseChannel):
    """Outbound WebSocket relay to PraestoClaw Cloud Gateway."""

    # Heartbeat / watchdog tunables — class-level so tests can monkeypatch
    # them without rewriting the loop. ``_HEARTBEAT_SLEEP_S`` gates the
    # observation cadence; ``_WATCHDOG_MIN_INTERVAL_S`` rate-limits
    # restart attempts so a persistent failure does not busy-loop.
    _HEARTBEAT_SLEEP_S: float = 30.0
    _WATCHDOG_MIN_INTERVAL_S: float = 60.0

    def __init__(
        self,
        bus: MessageBus,
        *,
        url: str,
        tenant_id: str,
        client_id: str,
        scope: str,
        transport_mode: Literal["direct", "awps"] = "awps",
        negotiate_url: str = "",
        negotiate_timeout_s: float = 15.0,
        client_url_refresh_skew_s: float = 300.0,
        login_method: Literal["auto", "browser", "wam", "device"] = "auto",
        login_port: int = 49216,
        allow_from: list[str] | None = None,
        auto_reconnect: bool = True,
        reconnect_max: int = 60,
        bypass_token: str | None = None,
        open_browser_on_connect: bool = False,
        # A2A Phase 1 parameters
        a2a_enabled: bool = False,
        a2a_instance_id: str | None = None,
        a2a_user_id: str | None = None,
        a2a_is_active_instance: bool = True,
        a2a_protocol_version: str = "1",
        a2a_card_seed: dict[str, Any] | None = None,
        # Executor-side notify filter — see ``A2AConfig.executor_notify_filter``.
        # Empty / None disables the filter (no emissions dropped).
        a2a_executor_notify_filter: list[str] | None = None,
        # When set, used verbatim as agent_id (CLI --instance-id dev path).
        # Otherwise agent_id is composed as ``{a2a_instance_id}@{run_id}``.
        agent_id_override: str | None = None,
        # Authentication provider — required unless ``bypass_token`` is set.
        # Build via :func:`praestoclaw.auth.factory.build_auth_provider`.
        auth: Any = None,
    ) -> None:
        super().__init__(bus, allow_from)
        self._url = url
        self._transport_mode = transport_mode
        self._negotiate_url = negotiate_url
        self._negotiate_timeout_s = negotiate_timeout_s
        self._client_url_refresh_skew_s = client_url_refresh_skew_s
        self._tenant_id = tenant_id
        self._client_id = client_id
        self._scope = scope
        self._login_method = login_method
        self._login_port = login_port
        self._auto_reconnect = auto_reconnect
        self._reconnect_max = reconnect_max

        self._bypass_token = bypass_token
        self._open_browser_on_connect = open_browser_on_connect

        # A2A Phase 1 state
        self._a2a_enabled = a2a_enabled
        self._a2a_instance_id = a2a_instance_id
        self._a2a_user_id = a2a_user_id
        self._a2a_is_active_instance = a2a_is_active_instance
        self._a2a_protocol_version = a2a_protocol_version
        self._a2a_card_seed = a2a_card_seed or {}
        self._a2a_executor_notify_filter: frozenset[str] = frozenset(
            str(token) for token in (a2a_executor_notify_filter or []) if token
        )
        self._a2a_runtime: Any = None  # A2ARuntime — set via set_a2a_runtime()
        self._agent_id_override = agent_id_override
        # Process-local run id; stable across reconnects within this process so
        # the gateway can keep routing to us. A new process gets a new run id,
        # which together with the instance_id gives an `{instance}@{run}`
        # identity that is unique per running agent.
        self._run_id = int(time.time())

        self._token: str | None = None
        self._auth = auth  # AuthProvider — required unless bypass_token is set
        self._running = False
        self._ws_connected = False  # True while the Gateway protocol transport is live
        # Online-state observability — see _mark_online/_mark_offline.
        # _online_since is the wall-clock moment we last surfaced an "Agent
        # online" line; _last_agent_link_session_id ties an offline log back
        # to the agent link that just dropped so a reader can scan one grep.
        self._online_since: float | None = None
        self._last_agent_link_session_id: str = ""
        self._last_session_epoch: int = 0
        self._process_started_at: float = time.monotonic()
        self._heartbeat_task: asyncio.Task[None] | None = None
        # Watchdog: in-flight restart task + serialization lock so the
        # 30s heartbeat can never schedule two concurrent restarts and
        # stop() can never race against a half-rebuilt transport.
        self._watchdog_task: asyncio.Task[None] | None = None
        self._watchdog_lock: asyncio.Lock = asyncio.Lock()
        self._browser_opened = False  # open browser only on first successful connect
        self._runtime: Any = None  # set by Runtime after construction
        self._push_deliveries: dict[
            str, dict[str, bool]
        ] = {}  # notify delivery results keyed by request_id
        self._push_events: dict[str, asyncio.Event] = {}  # notify delivery waiters
        self._local_oid: str | None = None  # set by _capture_identity after MSAL login
        self._local_tid: str | None = None
        self._local_upn: str | None = None  # preferred_username (email), for A2A user_id
        self._conv_ref_store = ConvRefStore()
        self._validator: Any = None  # set in start(); see RelayValidator
        self._using_shared_app = False  # set True after fallback to aebc6443 succeeds
        self._transport: GatewayTransportClient | None = None
        self._business: BusinessProtocolClient | None = None
        self._dispatcher: Dispatcher | None = None
        self._pending_conversations: dict[str, _PendingConversation] = {}
        # Wall-clock (monotonic) timestamp of the most recent
        # ``task.progress`` heartbeat the executor emitted for a given
        # carrier request_id. Used by ``_wait_a2a_task_with_heartbeat``
        # to extend the carrier deadline as long as the agent loop is
        # still ticking. Entries are seeded when the task carrier is
        # accepted and cleared in the ``finally`` of
        # ``_handle_conversation_request``.
        self._task_heartbeat_at: dict[str, float] = {}
        self._u2u_pending_targets: dict[str, dict[str, Any]] = {}
        # Track channel_ids whose inbound message originated from a Teams
        # surface (teams_bridge / cloud_teams). When the synchronous /chatng
        # waiter is consumed by an interim response (e.g. an Adaptive Card
        # for human-in-the-loop approval) and the agent later emits a
        # follow-up reply (e.g. tool result after Approve), ``send()`` falls
        # through to ``_send_notify``. Remembering the original surface lets
        # the a2a router defensively pin ``push_target="teams"`` so the
        # follow-up survives even if the global default ever changes.
        self._teams_routed_channel_ids: set[str] = set()
        # Subset of ``_teams_routed_channel_ids`` populated only when the
        # promotion came from an ``a2a_task`` inbound (executor side of an
        # A2A delegation). Used by the executor-notify filter in
        # ``send()`` to gate noisy intermediate emissions without
        # affecting native Teams conversations whose channel_id is also
        # in ``_teams_routed_channel_ids``. Cleaned up alongside the
        # parent set when the per-A2A-reply ``a2a:notify:`` channel_id
        # is consumed.
        self._a2a_promoted_channel_ids: set[str] = set()
        # Strong refs for fire-and-forget tasks so the GC does not collect
        # them mid-flight (CPython asyncio.create_task best practice).
        self._background_tasks: set[asyncio.Task[Any]] = set()

        # ── Deferred outbox for envelopes whose send failed mid-reconnect.
        # When the watchdog tears down a dead transport while a long-
        # running request handler is still executing, the next
        # ``send_envelope`` raises. The Outbound failure handler stashes
        # the envelope here; ``_flush_deferred_outbox`` drains it in FIFO
        # order once the new transport is up. Idempotency on the gateway
        # side is keyed by envelope.id.
        #
        # ``maxlen`` bounds memory if reconnect takes a long time and a
        # busy task floods progress beats. ``deque`` with ``maxlen``
        # auto-drops the oldest entry on overflow (FIFO drop). 500 is a
        # judgement call: enough to cover a multi-minute reconnect even
        # for chatty tasks, but small enough that an envelope storm can't
        # OOM the daemon.
        self._deferred_outbox: deque[Envelope] = deque(maxlen=500)
        self._deferred_outbox_lock = asyncio.Lock()
        # Cumulative count of envelopes dropped by ``maxlen`` overflow.
        # Surfaced in logs for ops visibility; not exposed as a metric.
        self._deferred_outbox_dropped = 0

        # MSAL PublicClientApplication — persists token cache across reconnects.
        # Skipped in bypass mode (no MSAL calls needed).
        self._cache_path: Path | None = None
        self._broker_enabled = False
        if bypass_token:
            logger.warning("Cloud channel using bypass token — disable for production!")
            self._msal_app = None
        else:
            # Persist MSAL token cache to ~/.praestoclaw/auth/ so login survives process restarts.
            # auth/ is ACL-protected on Windows, chmod 0o700 on POSIX.
            self._cache_path = get_auth_dir() / f"token_cache_{client_id[:8]}.bin"
            self._token_cache = msal.SerializableTokenCache()
            if self._cache_path.exists():
                try:
                    from praestoclaw.security.secrets import decrypt_at_rest

                    raw = decrypt_at_rest(self._cache_path.read_bytes())
                    if raw:
                        self._token_cache.deserialize(raw.decode("utf-8"))
                        logger.debug("MSAL token cache loaded from {}", self._cache_path)
                except Exception as exc:
                    logger.warning(
                        "Cannot load MSAL token cache at {} ({}); starting fresh.",
                        self._cache_path,
                        exc,
                    )
                    # Don't delete — cache may be encrypted with a key that becomes
                    # available later (e.g., after keyring unlock or env var set)
            broker_kwargs: dict[str, Any] = {}
            self._broker_enabled = False
            if login_method == "wam":
                from praestoclaw.utils.auth import _broker_kwargs

                broker_kwargs = _broker_kwargs()
                if broker_kwargs:
                    self._broker_enabled = True
                    logger.debug("Broker enabled ({})", list(broker_kwargs.keys())[0])
                else:
                    logger.warning("login_method=wam but msal[broker] not installed; using browser")
                    self._login_method = "browser"

            self._msal_app = msal.PublicClientApplication(
                client_id=client_id,
                authority=f"https://login.microsoftonline.com/{tenant_id}",
                token_cache=self._token_cache,
                **broker_kwargs,
            )

    def set_runtime(self, runtime: Any) -> None:
        """Set the Runtime reference for admin relay queries."""
        self._runtime = runtime

    @property
    def name(self) -> str:
        return ChannelType.CLOUD

    @property
    def _scopes(self) -> list[str]:
        """MSAL scopes list — empty when no explicit scope configured."""
        return [self._scope] if self._scope else []

    def get_push_delivery(self, request_id: str) -> dict[str, bool] | None:
        """Return and clear accumulated push delivery results for *request_id*.

        Multiple notify results for the same request_id are merged (OR): once
        a sub-channel is marked delivered, it stays delivered.

        Retrieval is one-shot: the stored delivery state for *request_id* is
        removed from the internal cache when this method is called.
        """
        self._push_events.pop(request_id, None)  # clean up waiter
        return self._push_deliveries.pop(request_id, None)

    def wait_push_delivery(self, request_id: str) -> asyncio.Event:
        """Return an ``asyncio.Event`` that is set when notify delivery is known.

        The caller should ``await asyncio.wait_for(event.wait(), timeout=N)``
        then call ``get_push_delivery()`` to retrieve the results.
        """
        evt = self._push_events.get(request_id)
        if evt is None:
            evt = asyncio.Event()
            self._push_events[request_id] = evt
            # If ack already arrived before wait was registered, set immediately
            if request_id in self._push_deliveries:
                evt.set()
        return evt

    def _record_push_delivery(
        self,
        request_id: str,
        *,
        target: str | None,
        response: dict[str, Any],
    ) -> None:
        delivery = response.get("delivery")
        if not isinstance(delivery, dict):
            delivery = response.get("deliveries")
        if isinstance(delivery, dict):
            result = {
                "webchat": bool(delivery.get("webchat")),
                "teams": bool(delivery.get("teams")),
            }
        else:
            result = {"webchat": target != "teams", "teams": target == "teams"}

        existing = self._push_deliveries.setdefault(request_id, {"webchat": False, "teams": False})
        existing["webchat"] = existing["webchat"] or result["webchat"]
        existing["teams"] = existing["teams"] or result["teams"]
        evt = self._push_events.get(request_id)
        if evt is not None:
            evt.set()

    @property
    def is_connected(self) -> bool:
        """True only while the WebSocket handshake is live (not during reconnect backoff)."""
        return self._ws_connected

    # ── Lifecycle ────────────────────────────────────────────────────────────

    def has_cached_credentials(self) -> bool:
        """Return True if a cached session likely exists (fast, no network).

        Used by the runtime to decide whether to auto-connect on startup.
        Probes only the cache flavour belonging to the configured provider —
        an MSAL broker cache does NOT count as "credentials" for the browser
        provider, and so on.
        """
        if self._bypass_token:
            return True
        if self._auth is None:
            return False
        try:
            return bool(self._auth.has_cached_credentials())
        except Exception:
            return False

    async def start(self) -> None:
        if self._running:
            return  # already started — prevent duplicate connection tasks
        self._running = True

        logger.info(
            "Cloud channel starting: instance_id={} run_id={}",
            self._a2a_instance_id,
            self._run_id,
        )

        # Acquire initial token — may raise RuntimeError("Cloud sign-in skipped")
        # if the user selects Skip in the interactive menu.
        self._token = await asyncio.get_running_loop().run_in_executor(
            None, self._acquire_token_sync
        )

        # Create relay validator — reads identity dynamically from this channel
        from praestoclaw.security.relay_validator import RelayValidator

        self._validator = RelayValidator(channel=self)
        self._capture_identity_from_token(self._token)
        self._warn_if_tenant_mismatch()
        self._reconcile_a2a_identity_from_auth()

        self._dispatcher = self._build_dispatcher()
        self._transport = self._build_transport_client()
        self._business = BusinessProtocolClient(
            self._transport,
            self._business_config(),
            dispatcher=self._dispatcher,
            transport_provider=self._current_transport,
            send_failure_handler=self._on_outbound_send_failure,
        )

        # Launch the Teams FRE progressive-seed scanner. Best-effort:
        # a startup failure here must not block the cloud channel.
        self._fre_seed_task: asyncio.Task[Any] | None = None
        try:
            from praestoclaw.channels.teams_fre import start_seed_loop

            self._fre_seed_task = start_seed_loop(self)
        except Exception as fre_exc:  # noqa: BLE001
            logger.debug("Failed to start Teams FRE seed loop: {}", fre_exc)
            self._fre_seed_task = None

        await self._business.start()
        await self.publish_a2a_card()
        self._ws_connected = True
        self._bus.events.emit(EventType.CHANNEL_CONNECTED, {"channel": self.name})
        if (
            self._open_browser_on_connect
            and self._transport_mode == "direct"
            and not self._browser_opened
        ):
            self._browser_opened = True
            web_url = webchat_url_from_connect(self._url)
            asyncio.get_running_loop().run_in_executor(None, webbrowser.open, web_url)
            logger.info("Opening web chat: {}", web_url)

        if self._transport_mode == "awps":
            negotiate_url = self._negotiate_url or negotiate_url_from_connect_url(self._url)
            logger.info(
                "Cloud channel started via Gateway v2 AWPS: negotiate_url={}",
                negotiate_url,
            )
        else:
            logger.info(
                "Cloud channel started via Gateway v1 direct WebSocket: url={}",
                self._url,
            )

        # Process-level heartbeat — see _heartbeat_loop docstring. Started
        # last so any earlier start() failure aborts before we spawn it.
        self._heartbeat_task = asyncio.create_task(
            self._heartbeat_loop(), name="praestoclaw-agent-heartbeat"
        )

    def _build_transport_client(self) -> GatewayTransportClient:
        transport_config = self._transport_config()
        if self._transport_mode == "awps":
            return AwpsGatewayTransportClient(transport_config)
        return GatewayV1TransportClient(transport_config)

    def _transport_config(self) -> TransportClientConfig:
        if self._transport_mode == "awps":
            return awps_transport_config(
                url=self._url,
                headers_provider=self._build_auth_headers,
                negotiate_url=self._negotiate_url,
                negotiate_timeout_s=self._negotiate_timeout_s,
                client_url_refresh_skew_s=self._client_url_refresh_skew_s,
                reconnect_max_delay_s=float(self._reconnect_max),
            )

        return v1_transport_config(
            url=self._url,
            headers={"Authorization": f"Bearer {self._token}"},
            headers_provider=self._build_auth_headers,
            reconnect_max_delay_s=float(self._reconnect_max),
        )

    async def stop(self) -> None:
        self._running = False
        self._ws_connected = False
        # Record the offline transition BEFORE we tear down transport;
        # otherwise the dispatcher's own disconnected event might race
        # with cleanup and we'd lose the canonical reason.
        self._mark_offline(reason="channel_stopped", detail="CloudChannel.stop() called")
        if self._heartbeat_task and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._heartbeat_task
            self._heartbeat_task = None
        # Cancel any in-flight watchdog restart so it cannot race against
        # the transport / business teardown below. The lock the watchdog
        # holds is itself awaited (re-entry from heartbeat is already
        # impossible because heartbeat_task was just cancelled).
        if self._watchdog_task and not self._watchdog_task.done():
            self._watchdog_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._watchdog_task
            self._watchdog_task = None
        if self._business is not None:
            await self._business.stop()
            self._business = None
        if self._transport is not None:
            close_timeout = (
                _SHUTDOWN_TRANSPORT_CLOSE_TIMEOUT_S if self._transport_mode == "awps" else 5.0
            )
            await self._transport.close(graceful=True, timeout=close_timeout)
            self._transport = None
        # Cancel the FRE seed loop if it was started.
        fre_task = getattr(self, "_fre_seed_task", None)
        if fre_task and not fre_task.done():
            fre_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await fre_task
        for pending in self._pending_conversations.values():
            if pending.response_future and not pending.response_future.done():
                pending.response_future.set_exception(
                    BusinessError("transport.closed", "cloud channel stopped", retryable=False)
                )
            if pending.stream_queue:
                with contextlib.suppress(asyncio.QueueFull):
                    pending.stream_queue.put_nowait(None)
        self._pending_conversations.clear()
        logger.info("Cloud channel stopped")

    # ── Teams routing tracking (used by A2A notify path) ─────────────────
    def remember_teams_route(self, channel_id: str) -> None:
        """Record that *channel_id* originated on a Teams surface.

        Subsequent ``send()`` calls for this channel_id will be promoted to
        ``push_target="teams"`` so /api/notify routes to Teams (the gateway
        drops notifies whose recipient.channel doesn't match the subscribed
        channel). Called by the inbound message dispatcher and by the A2A
        runtime when republishing a reply on a fresh ``a2a:notify:<id>``
        channel_id derived from a Teams-originated parent.
        """
        if channel_id:
            self._teams_routed_channel_ids.add(channel_id)

    def is_teams_routed(self, channel_id: str) -> bool:
        """Whether *channel_id* should be promoted to ``push_target="teams"``."""
        return channel_id in self._teams_routed_channel_ids

    # ── Executor-side notify classifier ─────────────────────────────────
    @staticmethod
    def _classify_a2a_executor_notify(content: str, kwargs: dict[str, Any]) -> str:
        """Classify an outbound emission for executor-side filtering.

        Returns one of the category tokens recognized by
        ``config.channels.a2a.executor_notify_filter``. Terminal
        emissions (agent final reply, error fallback) carry no
        ``keep_context`` flag and so never reach this classifier — the
        caller only invokes it on intermediate sends.

        Classification keys (cheapest first):
          * explicit ``notify_category`` kwarg — set by emitters that
            cannot be distinguished by ``update_key`` alone (e.g.
            NotifyTool, future per-category emitters);
          * ``update_key`` prefix — set by every Adaptive-Card emitter
            so the C# bot can do in-place card updates. We piggyback
            on the same convention to recognize categories:
              - ``plan:``         → ``plan_progress`` (kept by default)
              - ``tool_status:``  → ``tool_status``
              - ``task:``         → ``task_progress``
              - ``approval:``     → ``approval_prompt`` /
                                    ``approval_resolved`` (distinguished
                                    by the ``push_request_id`` suffix
                                    ``:resolved`` stamped by
                                    ``hooks/handlers.py`` on the swap
                                    card).
          * fallback ``intermediate_other`` — any unrecognized
            ``keep_context=True`` emission. Included in the default
            drop list so new noisy emitters are silenced by default
            (opt-in surfacing via removing the token from the config).
        """
        explicit = kwargs.get("notify_category")
        if isinstance(explicit, str) and explicit:
            return explicit
        update_key = kwargs.get("update_key")
        if isinstance(update_key, str):
            if update_key.startswith("plan:"):
                return "plan_progress"
            if update_key.startswith("tool_status:"):
                return "tool_status"
            if update_key.startswith("task:"):
                return "task_progress"
            if update_key.startswith("approval:"):
                push_request_id = kwargs.get("push_request_id")
                if isinstance(push_request_id, str) and push_request_id.endswith(":resolved"):
                    return "approval_resolved"
                return "approval_prompt"
        return "intermediate_other"

    def _a2a_executor_filter(self) -> frozenset[str]:
        """Resolve the configured drop-list (empty when a2a disabled / unset)."""
        return self._a2a_executor_notify_filter

    async def send(self, channel_id: str, content: str, **kwargs: Any) -> None:
        """Send an agent response or agent-initiated notification via the protocol."""

        # ── Executor-side notify filter ─────────────────────────────────
        # When the channel_id was promoted to Teams routing because of an
        # ``a2a_task`` inbound (executor side of an A2A delegation), the
        # configured drop-list silences noisy intermediate categories so
        # the executor's own Teams chat doesn't get spammed by every
        # tool-status card / NotifyTool broadcast / approval prompt of
        # a long-running remote task. Native Teams sessions and webchat
        # are untouched (they're not in ``_a2a_promoted_channel_ids``).
        #
        # Only intermediate emissions (``keep_context=True``) are
        # candidates for filtering — the final agent reply / error
        # fallback omit that flag and pass through unconditionally so
        # the carrier waiter still closes and the sender agent gets a
        # terminal envelope.
        if channel_id in self._a2a_promoted_channel_ids and bool(kwargs.get("keep_context")):
            drop_set = self._a2a_executor_filter()
            if drop_set:
                category = self._classify_a2a_executor_notify(content, kwargs)
                if category in drop_set:
                    logger.debug(
                        "[a2a-filter] dropped executor notify: "
                        "channel_id={} category={} update_key={}",
                        channel_id,
                        category,
                        kwargs.get("update_key") or "(none)",
                    )
                    return
        pending = self._pending_conversations.get(channel_id)
        # Treat a pending whose sync waiter is already done/cancelled as
        # absent. ``asyncio.wait_for`` cancels the underlying future on
        # timeout (and ``_handle_conversation_request``'s timeout branch
        # also pops the pending entry, but the eviction happens slightly
        # before this lookup), so without this guard a late ``send()`` from
        # the still-running agent would hit the sync branch, find the
        # future ``done()`` and silently drop the message instead of
        # falling through to the proactive ``/api/notify`` path.
        if (
            pending is not None
            and not pending.is_stream
            and pending.response_future is not None
            and pending.response_future.done()
        ):
            pending = None
        is_teams = self.is_teams_routed(channel_id)
        # ``keep_context=True`` marks an intermediate emission (plan
        # live-update, hook status card, FRE seed, approval prompt) that
        # must NOT consume the carrier /chatng waiter. We evaluate it
        # here so the Teams-route promotion below and the routing block
        # further down both honor the same flag.
        is_intermediate = bool(kwargs.get("keep_context"))

        # If the synchronous /chatng waiter has already been consumed (e.g. an
        # approval card replaced the response), promote a remembered Teams
        # channel_id to ``push_target="teams"`` so the follow-up reply
        # reaches /api/notify instead of getting stamped as ``webchat`` and
        # silently dropped by the gateway. The agent loop's OutboundMessage
        # currently doesn't propagate inbound metadata.source.
        #
        # Also promote when the emission is flagged intermediate: those
        # bypass the waiter (see routing block below) and need the same
        # Teams target so the gateway accepts the notify frame.
        if (pending is None or is_intermediate) and is_teams and not kwargs.get("push_target"):
            kwargs["push_target"] = "teams"
            logger.debug(
                "[a2a-route] send() promoted channel_id={} -> push_target=teams",
                channel_id,
            )
            # ``a2a:notify:<parent_id>`` channel_ids are unique per A2A reply
            # and used exactly once for the agent's notification response.
            # Drop them from the tracking set after promotion so long-running
            # agents don't accumulate one entry per A2A reply forever.
            if channel_id.startswith("a2a:notify:"):
                self._teams_routed_channel_ids.discard(channel_id)
                self._a2a_promoted_channel_ids.discard(channel_id)
        elif is_intermediate and not is_teams and not kwargs.get("push_target"):
            # Non-Teams intermediate (e.g. PlanTool live-update on a
            # cloud_webchat session). The routing block below will send
            # it via /api/notify; ``_send_notify`` would otherwise
            # default ``push_target`` to ``"teams"`` and stamp the
            # conversation_id ``teams:<channel_id>``, which the gateway
            # drops as a channel mismatch. Pin to ``webchat`` explicitly
            # so the intermediate surfaces in the user's actual session.
            kwargs["push_target"] = "webchat"

        # Teams Adaptive Card payloads — the agent serializes a BF Activity
        # wrapping an Adaptive Card into ``content`` (see
        # ``teams_cards.wrap_for_teams``). Hoist the card into
        # ``body.content.card`` and clear ``text`` so the gateway forwards it
        # as a structured attachment per docs/05-channels.md \u00a73.4.
        text_content: str = content
        card_content: dict[str, Any] | None = None
        if kwargs.get("push_target") == "teams":
            extracted = _extract_card_from_activity_json(content)
            if extracted is not None:
                card_content = extracted
                text_content = ""

        body = self._response_body(
            text_content,
            fmt=kwargs.get("format", "markdown"),
            card=card_content,
        )
        # Routing rules:
        #
        # * **Adaptive Cards** (``card_content is not None``) MUST always
        #   be delivered via /api/notify so the C# bot's
        #   ``NotifyController`` owns the
        #   ``(oid, update_key) -> activityId`` mapping needed for
        #   in-place card updates (approval-resolved card swap,
        #   plan-progress animation, Stage 3 escalation, etc.). Letting a
        #   card ride the /chatng sync response would post it without
        #   that mapping being registered for any later ``update_key``
        #   reuse, and a subsequent resolve/update would surface a NEW
        #   card instead of editing the original — visible as duplicate
        #   cards in the chat.
        # * **``update_key`` set** — same reason as above; in-place
        #   updates need the NotifyController mapping.
        # * **``keep_context=True``** — caller flagged the emission as an
        #   intermediate progress update (plan-tool live updates, hook
        #   status cards, FRE bootstrap pings, …) rather than the agent
        #   loop's final reply. The carrier waiter must stay unresolved
        #   so the eventual final reply (which omits ``keep_context``)
        #   is the one that closes the /chatng sync slot. Without this,
        #   the FIRST intermediate emission steals the carrier response
        #   slot — visible as: an a2a task carrier returns a plan card
        #   as its "result" after one LLM iteration, the gateway marks
        #   the task done, and the actual work the agent runs over the
        #   following minutes never reaches the sender.
        # * **No pending /chatng waiter** — there's no sync response
        #   slot to use; fall through to /api/notify.
        # * Everything else (plain text agent replies) resolves the
        #   /chatng sync waiter as before.
        update_key_raw = kwargs.get("update_key")
        has_update_key = isinstance(update_key_raw, str) and bool(update_key_raw.strip())
        is_card_payload = card_content is not None
        if pending is None or has_update_key or is_card_payload or is_intermediate:
            await self._send_notify(channel_id, content, **kwargs)
            # Only the *final* card emission should resolve the /chatng
            # waiter. An intermediate Teams Adaptive Card (e.g. a
            # progress card or an approval prompt emitted mid-turn with
            # ``keep_context=True`` on an a2a_task carrier whose
            # request_id was promoted to Teams routing) must leave the
            # carrier open so the eventual final reply can close the
            # sync slot. For non-Teams-routed pendings (e.g. a webchat
            # welcome card on first connect) the card *is* the final
            # response, so unblock with an empty body to suppress the
            # bridge placeholder bubble.
            if pending is not None and is_card_payload and not (is_intermediate and is_teams):
                # The card was delivered out-of-band via /api/notify; unblock
                # the /chatng waiter with an empty body so the bridge response
                # doesn't surface a placeholder text bubble on top of the
                # card. The C# bot already treats ``BridgeResponse(text="",
                # card=None)`` as "no message to post" (see
                # ``AgentCoralineBot.cs`` empty-reply guard, mirroring the
                # approval-only short-circuit in
                # ``endpoints/teams_bridge.py``). Subsequent agent emissions
                # for this turn (e.g. the final text reply after an approval
                # resolves) will see ``pending is None`` and also route via
                # /api/notify, which is the desired behaviour.
                empty_body = self._response_body("", fmt=kwargs.get("format", "markdown"))
                if pending.is_stream:
                    if pending.stream_queue is not None:
                        await pending.stream_queue.put(empty_body)
                        await pending.stream_queue.put(None)
                elif pending.response_future is not None and not pending.response_future.done():
                    pending.response_future.set_result(empty_body)
                # Mark the waiter consumed immediately. The
                # ``_handle_conversation_request/_stream`` ``finally`` block
                # also pops, but it runs asynchronously after the awaiting
                # task wakes up. If the agent emits a second ``send()`` for
                # the same channel_id in the same turn before that happens
                # (e.g. text follow-up right after the approval card), the
                # second call would still observe ``pending != None`` here
                # and try to deliver via the now-resolved future — silently
                # dropping the message (response_future.done()==True branch
                # is a no-op, and the stream queue already has its ``None``
                # sentinel so any further item after it is never yielded).
                # Pop now so the follow-up routes via /api/notify.
                self._pending_conversations.pop(channel_id, None)
            return
        if pending.is_stream:
            if pending.stream_queue is not None:
                await pending.stream_queue.put(body)
                await pending.stream_queue.put(None)
            return
        if pending.response_future is not None and not pending.response_future.done():
            pending.response_future.set_result(body)

    async def send_typing(self, channel_id: str, **kwargs: Any) -> None:
        """Typing indicators are not a v1 Gateway business topic."""
        logger.trace("Typing indicator ignored for cloud channel_id={}", channel_id)

    # ── Outbound bus handler ─────────────────────────────────────────────────

    async def send_streaming(self, channel_id: str, msg: StreamingChunk) -> None:
        """Route streaming chunks from the agent to the pending Gateway stream."""

        pending = self._pending_conversations.get(channel_id)
        if pending is None or pending.stream_queue is None:
            logger.debug("Dropping cloud stream chunk for unknown channel_id={}", channel_id)
            return
        if msg.done:
            await pending.stream_queue.put(None)
            return
        await pending.stream_queue.put(
            self._response_body(
                msg.content, fmt="markdown", metadata={"chunk_type": msg.chunk_type}
            )
        )

    # ── Gateway protocol bridge ──────────────────────────────────────────────

    def _mark_online(self, *, agent_link_session_id: str, epoch: int, mode: str) -> None:
        """Emit the canonical 'Agent online' status line.

        Grepping ``Agent online`` finds every moment the client believes
        it is reachable by the gateway. Pairs with ``_mark_offline`` —
        the two lines bracket every offline window in the log so a
        reader does not need to know about t.welcome / heartbeat /
        reconnect mechanics.
        """
        self._online_since = time.monotonic()
        self._last_agent_link_session_id = agent_link_session_id
        self._last_session_epoch = epoch
        logger.info(
            "Agent online: agent_link_session={}/{} mode={} agent_id={} user_id={}",
            agent_link_session_id,
            epoch,
            mode,
            self._agent_id(),
            self._user_id(),
        )

    def _mark_offline(self, *, reason: str, detail: str = "") -> None:
        """Emit the canonical 'Agent offline' status line.

        ``reason`` is a short, stable token (``transport_disconnected``,
        ``transport_closed_terminal``, ``channel_stopped``,
        ``startup_failed``). ``detail`` carries the free-form context
        for humans. Both go on one line so grep finds the cause.

        Idempotent on the "still offline" case: if we were never marked
        online since the last offline call, we still log — repeated
        offline reasons during a failed reconnect storm are useful.
        """
        was_online_for: float | None
        if self._online_since is not None:
            was_online_for = time.monotonic() - self._online_since
            self._online_since = None
        else:
            was_online_for = None
        logger.warning(
            "Agent offline: reason={} detail={} agent_link_session={}/{} was_online_for={}",
            reason,
            detail or "(none)",
            self._last_agent_link_session_id or "(none)",
            self._last_session_epoch,
            f"{was_online_for:.1f}s" if was_online_for is not None else "(never_online)",
        )

    async def _heartbeat_loop(self) -> None:
        """Periodic process-level liveness line.

        One log line every 30 s with the smallest set of fields that lets
        a reader tell, from a static log file, which of these is true:

        * Process died (no heartbeat after a known one, no atexit /
          process-exit line in the same log). Hard-kill or crash.
        * Event loop is alive but the transport runner_task ended
          (``runner_task=dead``). Reconnect loop gave up; the channel
          will not recover on its own — *unless* the watchdog kicks in
          (see below).
        * Event loop is alive and runner is running but the WS has been
          quiet (``last_inbound_age`` keeps climbing past pong_timeout +
          ping_interval). Network is silently dead — heartbeat_timeout
          should fire soon; if it does not, that itself is a finding.
        * Event loop is blocked. The heartbeat itself stops despite the
          process being alive — caught by ``faulthandler`` (separate
          stuck.log timer).

        **Watchdog**: when ``runner_task`` is observed as ``dead`` or
        ``none`` and the channel is still nominally running, the
        heartbeat triggers a best-effort restart. Retries are unbounded
        (rate-limited only by ``_WATCHDOG_MIN_INTERVAL_S``) so a laptop
        coming back from a multi-hour network outage recovers without
        manual intervention. This recovers from the case where
        the gateway fatally rejects a resume attempt (e.g. ``code=4000
        protocol_error fatal=True``) and the transport's reconnect loop
        exits permanently — historically this required a manual restart.

        The watchdog also covers the ``runner_task=none`` shape: a prior
        watchdog restart that failed mid-rebuild can leave
        ``self._transport = None`` (see :meth:`_watchdog_restart` —
        rebuild aborts with ``self._transport = None`` on
        ``_build_transport_client`` / ``business.start()`` failure). Pre-
        fix the watchdog only retriggered on ``runner_task=dead``, so
        ``runner_task=none`` would sit forever. Both states now route
        through the same restart path.
        """
        # Rate-limit restarts so persistent failures don't busy-loop, but
        # do NOT cap the total number of attempts. A laptop can sit
        # without network for hours (VPN handover, conference WiFi, lid
        # closed); we MUST come back up automatically the moment the
        # network is reachable again — without requiring the user to
        # `launchctl kickstart`. Successful reconnect resets the
        # ``last_attempt_at`` cooldown so a fresh failure responds
        # promptly.
        watchdog_min_interval_s = self._WATCHDOG_MIN_INTERVAL_S
        watchdog_last_attempt_at: float | None = None
        watchdog_attempt_counter = 0  # cumulative, log-only
        # P2-D (issue #341): detect ws_connected=False stuck with a live
        # runner. Transport reader may have silently reconnected to a new
        # gateway session without our dispatcher receiving a welcome event,
        # leaving CloudChannel pinned to a dead session id. Three
        # consecutive ticks (~90 s) of "live runner, ws disconnected" is a
        # high-confidence desync signal; force a full rebuild via the
        # watchdog path.
        ws_disconnected_ticks = 0
        _WS_DESYNC_TICKS = 3

        while self._running:
            try:
                await asyncio.sleep(self._HEARTBEAT_SLEEP_S)
            except asyncio.CancelledError:
                return
            try:
                t = self._transport
                runner = getattr(t, "_runner_task", None) if t else None
                if runner is None:
                    runner_state = "none"
                elif runner.done():
                    runner_state = "dead"
                else:
                    runner_state = "running"
                last_inbound_age: str
                last_frame = getattr(t, "_last_frame_at", None) if t else None
                if isinstance(last_frame, int | float) and last_frame > 0:
                    last_inbound_age = f"{time.monotonic() - last_frame:.1f}s"
                else:
                    last_inbound_age = "(never)"
                t_state = getattr(t, "state", None) if t else None
                transport_state_value = str(getattr(t_state, "value", t_state))
                if runner_state == "running" and self._ws_connected:
                    # Healthy → drop the cooldown so the next failure
                    # gets an immediate restart instead of waiting out a
                    # stale 60 s interval. Do NOT reset cooldown for
                    # runner=running + ws_connected=False; that state is
                    # itself now a watchdog trigger and must remain
                    # rate-limited.
                    watchdog_last_attempt_at = None
                logger.info(
                    "Agent heartbeat: pid={} uptime={:.0f}s agent_link_session={}/{} "
                    "ws_connected={} transport_state={} runner_task={} "
                    "last_inbound_age={}",
                    os.getpid(),
                    time.monotonic() - self._process_started_at,
                    self._last_agent_link_session_id or "(none)",
                    self._last_session_epoch,
                    self._ws_connected,
                    transport_state_value,
                    runner_state,
                    last_inbound_age,
                )

                # Watchdog tick — fire when the runner is gone or never
                # rebuilt and we're nominally still running. Keep going
                # forever (subject only to the 60 s cooldown) so a long
                # outage recovers automatically.
                #
                # P2-D (issue #341): also fire when the runner is alive
                # but ``_ws_connected`` has been False for several ticks.
                # That shape means transport reconnected internally but
                # CloudChannel never observed a fresh welcome event, so
                # ``_last_agent_link_session_id`` is stale and outbound
                # routing targets a dead session.
                desync_detected = False
                if runner_state == "running":
                    transport_live = transport_state_value == TransportState.LIVE.value
                    if not self._ws_connected and transport_live:
                        ws_disconnected_ticks += 1
                        if ws_disconnected_ticks >= _WS_DESYNC_TICKS:
                            desync_detected = True
                    else:
                        ws_disconnected_ticks = 0
                else:
                    ws_disconnected_ticks = 0

                trigger = runner_state in {"dead", "none"} or desync_detected
                if (
                    trigger
                    and self._running
                    and not (self._watchdog_task is not None and not self._watchdog_task.done())
                ):
                    now = time.monotonic()
                    last = watchdog_last_attempt_at
                    if last is None or (now - last) >= watchdog_min_interval_s:
                        watchdog_attempt_counter += 1
                        watchdog_last_attempt_at = now
                        reason = (
                            f"ws_desync (ws_connected=False for {ws_disconnected_ticks} ticks)"
                            if desync_detected
                            else f"runner {runner_state}"
                        )
                        logger.warning(
                            "Cloud watchdog: {}, restarting transport (cumulative attempt #{})",
                            reason,
                            watchdog_attempt_counter,
                        )
                        # Reset the desync counter so a slow rebuild
                        # doesn't immediately retrigger.
                        ws_disconnected_ticks = 0
                        # Schedule restart as a separate task so the
                        # heartbeat keeps ticking and we never block here.
                        # Keep a reference (assigned to _watchdog_task) so
                        # the next tick can detect an in-flight restart
                        # and skip scheduling a second one.
                        self._watchdog_task = asyncio.create_task(
                            self._watchdog_restart(),
                            name="praestoclaw-cloud-watchdog-restart",
                        )
            except Exception:
                logger.exception("Agent heartbeat tick failed")

    async def _watchdog_restart(self) -> None:
        """Best-effort restart of the cloud transport after runner death.

        Tears down the existing transport / business client and rebuilds
        them via ``start()``-equivalent logic. Failures are logged but
        never raised — the next heartbeat tick will observe the result
        and decide whether to retry. Retries are unbounded (only
        rate-limited by ``_WATCHDOG_MIN_INTERVAL_S``) so a laptop coming
        back from a multi-hour network outage recovers automatically.

        Race-safe wrt :meth:`stop`: the entire restart is performed under
        ``_watchdog_lock``, and we re-check ``self._running`` after each
        await boundary so a concurrent ``stop()`` cannot end up with
        freshly built clients owned by a channel that is shutting down.
        On partial-init failure (e.g. ``_business.start()`` raises) we
        tear down whatever we built so the next tick observes a clean
        ``runner=none`` state rather than a stale partially-running one.
        """
        async with self._watchdog_lock:
            if not self._running:
                # Channel was stopped while we were waiting for the lock.
                return

            # Tear down the dead transport / business client first.
            old_business = self._business
            old_transport = self._transport
            self._business = None
            self._transport = None
            self._ws_connected = False
            if old_business is not None:
                with contextlib.suppress(Exception):
                    await old_business.stop()
            if old_transport is not None:
                with contextlib.suppress(Exception):
                    await old_transport.close(graceful=False)

            if not self._running:
                return  # stop() raced past the awaits above

            # Rebuild — mirror the relevant portion of start(). We do NOT
            # re-acquire the token (the cached one is still good unless
            # auth_failures triggered, which we'd see separately) and we
            # do NOT re-spawn the heartbeat (we're already running inside
            # it). Use the same factory ``start()`` uses so AWPS vs direct
            # transport variant matches the user's config.
            new_dispatcher = self._build_dispatcher()
            try:
                new_transport = self._build_transport_client()
            except Exception as exc:
                logger.error("Cloud watchdog: rebuild failed (transport): {}", exc)
                return

            # Provider must return ``new_transport`` during the rebuild
            # window: ``self._transport`` stays None until we commit the
            # swap below, so falling back on ``self._current_transport``
            # (which reads ``self._transport``) would make handshake /
            # request sends inside ``new_business.start()`` resolve to
            # None and raise "no live transport available", breaking
            # the reconnect.
            def _rebuild_provider() -> Any:
                return self._transport if self._transport is not None else new_transport

            new_business = BusinessProtocolClient(
                new_transport,
                self._business_config(),
                dispatcher=new_dispatcher,
                transport_provider=_rebuild_provider,
                send_failure_handler=self._on_outbound_send_failure,
            )
            committed = False
            try:
                try:
                    await new_business.start()
                except Exception as exc:
                    logger.error("Cloud watchdog: rebuild failed (business.start): {}", exc)
                    return

                # Commit only after both transport and business have started.
                self._dispatcher = new_dispatcher
                self._transport = new_transport
                self._business = new_business
                committed = True
            finally:
                if not committed:
                    # Either start() failed or we were cancelled mid-rebuild
                    # (e.g. stop()). Tear down what we built so we don't leak
                    # background tasks / open websockets.
                    with contextlib.suppress(Exception):
                        await new_business.stop()
                    with contextlib.suppress(Exception):
                        await new_transport.close(graceful=False)

            try:
                await self.publish_a2a_card()
            except Exception as exc:
                # Non-fatal: the channel is connected; A2A card publish
                # can be retried by other paths.
                logger.warning("Cloud watchdog: publish_a2a_card failed: {}", exc)

            # Flush envelopes that were deferred while the transport
            # was down. Includes:
            #   - response/error/notify envelopes captured by handlers
            #     whose closures still hold a stale Outbound;
            #   - a single catch-up task.progress beat per task that
            #     experienced heartbeat send failures during the gap.
            # Best-effort: a flush failure here is logged but does not
            # roll the rebuild back — the next request that hits the
            # same Outbound will re-trigger queueing.
            with contextlib.suppress(Exception):
                await self._flush_deferred_outbox()

            self._ws_connected = True
            self._bus.events.emit(EventType.CHANNEL_CONNECTED, {"channel": self.name})
            logger.info("Cloud watchdog: transport restart succeeded")

    # ── Outbound reconnect resilience ────────────────────────────────
    def _current_transport(self) -> Any:
        """Return the live transport so ``Outbound`` always uses the
        latest one (the watchdog may have replaced it)."""
        return self._transport

    async def _on_outbound_send_failure(
        self,
        envelope: Envelope,
        exc: BaseException,
    ) -> bool:
        """Stash an envelope whose send failed; watchdog will replay it."""
        if not self._running:
            return False
        async with self._deferred_outbox_lock:
            # ``deque(maxlen=N).append`` silently drops the leftmost
            # entry when full; detect that by checking length before/
            # after so we can log the loss for ops visibility.
            maxlen = self._deferred_outbox.maxlen
            dropped: Envelope | None = None
            if maxlen is not None and len(self._deferred_outbox) == maxlen:
                dropped = self._deferred_outbox[0]
            self._deferred_outbox.append(envelope)
            if dropped is not None:
                self._deferred_outbox_dropped += 1
                logger.warning(
                    "Deferred outbox full (maxlen={}); dropping oldest "
                    "envelope: kind={} topic={} corr_id={} (total dropped={})",
                    maxlen,
                    dropped.kind.value,
                    dropped.topic or "(none)",
                    dropped.correlation_id or "(none)",
                    self._deferred_outbox_dropped,
                )
        logger.info(
            "Outbound deferred: kind={} topic={} corr_id={} reason={}",
            envelope.kind.value,
            envelope.topic or "(none)",
            envelope.correlation_id or "(none)",
            type(exc).__name__,
        )
        return True

    async def _flush_deferred_outbox(self) -> None:
        """Replay deferred envelopes in FIFO order through the live transport."""
        async with self._deferred_outbox_lock:
            # Check business availability *before* draining — otherwise a
            # mistimed flush (e.g. stop() raced in after the watchdog
            # committed the rebuild) would silently drop every pending
            # envelope. With the check inside the lock we leave the deque
            # intact so a later flush can replay them.
            if not self._deferred_outbox or self._business is None:
                return
            pending = list(self._deferred_outbox)
            self._deferred_outbox.clear()
        business = self._business
        logger.info("Cloud watchdog: flushing {} deferred envelope(s)", len(pending))
        for idx, env in enumerate(pending):
            try:
                await business.outbound.send_envelope(env)
            except Exception as exc:  # noqa: BLE001
                # New transport also died. Rebuild the deque under the
                # lock so the result is strictly FIFO:
                #   [env, *remainder, *any_concurrent_appends]
                # The failure handler may have already re-enqueued env
                # (fire-and-forget kinds) — strip one identity-match
                # occurrence so we don't duplicate it.
                remainder = pending[idx + 1 :]
                async with self._deferred_outbox_lock:
                    extras = list(self._deferred_outbox)
                    self._deferred_outbox.clear()
                    for i, e in enumerate(extras):
                        if e is env:
                            extras.pop(i)
                            break
                    for e in (env, *remainder, *extras):
                        self._deferred_outbox.append(e)
                    requeued = 1 + len(remainder) + len(extras)
                logger.warning(
                    "Cloud watchdog: deferred flush stopped at corr_id={} "
                    "({} envelope(s) re-queued): {}",
                    env.correlation_id or "(none)",
                    requeued,
                    exc,
                )
                break

    def _build_dispatcher(self) -> Dispatcher:
        dispatcher = Dispatcher()

        @dispatcher.on_session_event("connected")
        async def _on_connected(payload: dict[str, Any]) -> None:
            self._ws_connected = True
            agent_link_session_id = payload.get("session_id")
            epoch = payload.get("connection_epoch")
            logger.success(
                "Connected to Cloud Gateway: agent_link_session={}/{}",
                agent_link_session_id,
                epoch,
            )
            self._mark_online(
                agent_link_session_id=str(agent_link_session_id) if agent_link_session_id else "",
                epoch=int(epoch) if isinstance(epoch, int) else 0,
                mode="fresh",
            )

        @dispatcher.on_session_event("resumed")
        async def _on_resumed(payload: dict[str, Any]) -> None:
            self._ws_connected = True
            agent_link_session_id = payload.get("session_id")
            epoch = payload.get("connection_epoch")
            logger.info(
                "Resumed Cloud Gateway agent link: agent_link_session={}/{}",
                agent_link_session_id,
                epoch,
            )
            self._mark_online(
                agent_link_session_id=str(agent_link_session_id) if agent_link_session_id else "",
                epoch=int(epoch) if isinstance(epoch, int) else 0,
                mode="resumed",
            )

        @dispatcher.on_session_event("disconnected")
        async def _on_disconnected(payload: dict[str, Any]) -> None:
            self._ws_connected = False
            logger.warning(
                "Cloud Gateway disconnected: agent_link_session={} reason={}",
                payload.get("session_id"),
                payload.get("reason"),
            )
            self._mark_offline(
                reason="transport_disconnected",
                detail=str(payload.get("reason") or ""),
            )

        @dispatcher.on_session_event("closed")
        async def _on_closed(payload: dict[str, Any]) -> None:
            self._ws_connected = False
            logger.error(
                "Cloud Gateway closed (terminal): agent_link_session={} reason={}",
                payload.get("session_id"),
                payload.get("reason"),
            )
            self._mark_offline(
                reason="transport_closed_terminal",
                detail=str(payload.get("reason") or ""),
            )

        @dispatcher.on_session_event("bye")
        async def _on_bye(payload: dict[str, Any]) -> None:
            # Inbound _session.bye: the gateway is telling us why it's about
            # to (or already did) drop us. For deterministic reasons we stop
            # the channel so the transport reconnect loop doesn't fight the
            # gateway — the runtime/user can decide whether/when to re-attach.
            reason = str(payload.get("reason") or "")
            message = payload.get("message")
            logger.warning(
                "Cloud Gateway bye: reason={} message={} agent_link_session={}",
                reason,
                message,
                payload.get("session_id"),
            )
            self._mark_offline(
                reason="bye:" + (reason or "unknown"),
                detail=str(message or ""),
            )
            if reason in {"server_shutdown", "replaced", "auth_expired"}:
                asyncio.create_task(self.stop())

        @dispatcher.on_request("conversation.message.send")
        async def _conversation_send(body: dict[str, Any], ctx: Any) -> dict[str, Any]:
            return await self._handle_conversation_request(body, ctx, is_stream=False)

        @dispatcher.on_request("conversation.message.stream")
        def _conversation_stream(body: dict[str, Any], ctx: Any) -> Any:
            return self._handle_conversation_stream(body, ctx)

        @dispatcher.on_request(U2U_MESSAGE_DELIVER_TOPIC)
        async def _u2u_deliver(body: dict[str, Any], ctx: Any) -> dict[str, Any]:
            return await self._handle_conversation_request(body, ctx, is_stream=False)

        @dispatcher.on_request(A2A_MESSAGE_SEND_TOPIC)
        async def _a2a_send(body: dict[str, Any], ctx: Any) -> dict[str, Any]:
            # PR-? Task protocol: carrier may advertise
            # content_type=application/vnd.praestoclaw.task+json. Surface
            # the task summary as the user-facing text so the existing
            # conversation pipeline can route it to the agent loop, and
            # preserve the task fields in metadata for downstream tooling.
            body = _maybe_unwrap_task_carrier(body)

            # Task carriers stay on the conversation pipeline so the
            # executor-side ``task.progress`` heartbeat (issue #181) can
            # piggy-back on the existing metadata-passing mechanism. Plain
            # ``a2a.message.send`` carriers (no task body) take the A2A
            # runtime path so the inbound runs in an isolated
            # ``a2a:{sender}`` session, the local user gets a notify, and
            # any future receiver-gate sits in front of the agent loop.
            md = body.get("metadata")
            is_task_carrier = (
                isinstance(md, dict)
                and isinstance(md.get("task"), dict)
                and bool(md.get("task_id"))
            )
            if is_task_carrier:
                # Issue #181: attach a private sender callable so the agent
                # loop can emit periodic ``task.progress`` heartbeats back
                # through the same business outbound the Gateway forwards
                # to the original sender. The leading-underscore key is a
                # contract with ``AgentLoop._process_message`` (it pops the
                # callable out before threading metadata into the LLM/tool
                # layer).
                #
                # Gating on ``metadata['task']`` being a dict keeps this
                # branch un-spoofable: that field is *only* set by
                # ``_maybe_unwrap_task_carrier`` after a successful task
                # extraction.
                assert isinstance(md, dict)
                assert self._business is not None
                task_request_id = str(ctx.envelope.id)
                # Seed the heartbeat clock so the wait loop has a starting
                # point before the first beat fires (interval is 30s and
                # grace is 45s; without a seed we'd time out at 45s even
                # though the executor is healthy).
                self._task_heartbeat_at[task_request_id] = time.monotonic()

                def _bump_heartbeat(rid: str = task_request_id) -> None:
                    # Only refresh entries we still own. Late ``task.progress``
                    # beats can arrive *after* the carrier completes / times out
                    # and ``_handle_conversation_request``'s ``finally`` pops the
                    # entry; a blind ``dict.update`` would re-insert ``rid`` and
                    # leak indefinitely (one entry per stale executor that
                    # outlived its carrier).
                    if rid in self._task_heartbeat_at:
                        self._task_heartbeat_at[rid] = time.monotonic()

                md["_task_progress_sender"] = _HeartbeatTrackingOutbound(
                    self._business.outbound,
                    on_beat=_bump_heartbeat,
                )
                return await self._handle_conversation_request(body, ctx, is_stream=False)

            if self._a2a_runtime is not None:
                envelope = self._build_inbound_a2a_envelope(body, ctx)
                request_id = str(ctx.envelope.id)
                start_t = time.monotonic()
                logger.info(
                    "Inbound a2a request: request_id={} sender={} text_len={}",
                    request_id,
                    envelope.sender.id or "(unknown)",
                    len(envelope.text),
                )
                try:
                    reply_text = await self._a2a_runtime.process_business_request(envelope)
                except BusinessError:
                    raise
                except Exception as exc:
                    logger.exception(
                        "Inbound a2a request failed: request_id={} elapsed={:.2f}s",
                        request_id,
                        time.monotonic() - start_t,
                    )
                    raise BusinessError("internal_error", str(exc)[:200], retryable=False) from exc
                logger.info(
                    "Inbound a2a request replied: request_id={} elapsed={:.2f}s reply_len={}",
                    request_id,
                    time.monotonic() - start_t,
                    len(reply_text),
                )
                return self._response_body(reply_text, fmt="text")
            return await self._handle_conversation_request(body, ctx, is_stream=False)

        # Phase-1 task protocol: dispatch task.progress events to the
        # user-visible notification path and refuse forwarded
        # task.control(undo) requests with task.undo_unsupported.
        from praestoclaw.task import register_task_handlers as _register_task

        _register_task(
            dispatcher,
            self._bus,
            channel=self.name,
            local_user_id_provider=self._user_id,
            a2a_runtime=self._a2a_runtime,
        )

        @dispatcher.on_event(U2U_MESSAGE_DELIVERED_TOPIC)
        async def _u2u_receipt(body: dict[str, Any], ctx: Any) -> None:
            logger.info("U2U delivered receipt: {}", body.get("message_id", ""))
            await self._publish_u2u_receipt(body)

        @dispatcher.on_event(U2U_MESSAGE_EXPIRED_TOPIC)
        async def _u2u_expired(body: dict[str, Any], ctx: Any) -> None:
            logger.warning("U2U message expired: {}", body.get("message_id", ""))

        @dispatcher.on_event(U2U_MESSAGE_SEND_REJECTED_TOPIC)
        async def _u2u_rejected(body: dict[str, Any], ctx: Any) -> None:
            logger.warning(
                "U2U send rejected: message_id={} code={} message={}",
                body.get("rejected_message_id", ""),
                body.get("code", ""),
                body.get("message", ""),
            )

        return dispatcher

    def _business_config(self) -> BusinessClientConfig:
        from praestoclaw import __version__

        features = ["conversation", "file_stream"]
        if self._a2a_enabled:
            features.extend(["a2a", "u2u"])
        return BusinessClientConfig(
            client_version=f"praestoclaw-agent/{__version__}",
            agent_id=self._agent_id(),
            user_id=self._user_id(),
            features=tuple(features),
            metadata={"channel": self.name},
        )

    def _agent_id(self) -> str:
        if self._agent_id_override:
            return self._agent_id_override
        base = self._a2a_instance_id or f"praestoclaw-{socket.gethostname()}"
        return f"{base}@{self._run_id}"

    def _user_id(self) -> str:
        return self._a2a_user_id or self._authenticated_user_id() or f"anon-{self._agent_id()}"

    def _authenticated_user_id(self) -> str | None:
        """Return the user id proven by the current cloud auth token."""

        for value in (self._local_upn, self._local_oid):
            if value:
                normalized = str(value).strip()
                if normalized:
                    return normalized
        return None

    def _authenticated_display_name(self) -> str | None:
        claims = self._last_msal_claims()
        for key in ("name", "preferred_username", "upn", "unique_name", "oid"):
            value = claims.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
        return None

    def _reconcile_a2a_identity_from_auth(self) -> None:
        """Let late-resolved cloud auth identity replace anonymous A2A fallback."""

        if not self._a2a_enabled or self._a2a_runtime is None or self._a2a_user_id:
            return

        user_id = self._authenticated_user_id()
        if not user_id:
            return

        local_party = getattr(self._a2a_runtime, "local_party", None)
        current_id = str(getattr(local_party, "id", "") or "")
        if current_id == user_id:
            return

        update_local_party = getattr(self._a2a_runtime, "update_local_party", None)
        if not callable(update_local_party):
            logger.warning("A2A runtime cannot reconcile authenticated cloud identity")
            return

        update_local_party(user_id, display_name=self._authenticated_display_name())
        logger.info(
            "A2A local identity reconciled from {} to {} (source=cloud-auth)",
            current_id or "(unset)",
            user_id,
        )

    @staticmethod
    def _inbound_timeout_s(ctx: Any, source: str = "") -> float | None:
        """Pick a wait-for timeout for an inbound conversation request.

        Honors the gateway's ``deadline_ms`` header when present, but for
        Teams-sourced requests we cap it to ``_TEAMS_INBOUND_TIMEOUT_S``
        (strictly under the Bot Framework HTTP webhook's ~240s ceiling) so
        we always abandon the sync future *before* Teams gives up and can
        switch to the proactive ``/api/notify`` route. Other sources fall
        back to 10 min so a stuck agent does not leak the pending future /
        channel-id mapping forever.
        """
        try:
            deadline_ms = ctx.envelope.headers.get("deadline_ms")
        except AttributeError:
            deadline_ms = None
        deadline_s: float | None = None
        if isinstance(deadline_ms, int) and not isinstance(deadline_ms, bool) and deadline_ms > 0:
            deadline_s = deadline_ms / 1000
        if source in TEAMS_SOURCES:
            if deadline_s is None:
                return _TEAMS_INBOUND_TIMEOUT_S
            return min(deadline_s, _TEAMS_INBOUND_TIMEOUT_S)
        if deadline_s is not None:
            return deadline_s
        return _DEFAULT_INBOUND_TIMEOUT_S

    async def _wait_a2a_task_with_heartbeat(
        self,
        future: asyncio.Future[dict[str, Any]],
        request_id: str,
    ) -> dict[str, Any]:
        """Heartbeat-aware wait for ``source=="a2a_task"`` carriers.

        Mirrors the gateway-side executing-stage deadline (spec §5):
        as long as the executor keeps emitting ``task.progress`` beats
        (cadence ``EXECUTING_HEARTBEAT_INTERVAL_MS = 30s``, advertising
        ``next_heartbeat_ms = 120s``) the carrier stays open. A missed
        beat (no heartbeat for ``_A2A_TASK_HEARTBEAT_GRACE_S``) fails
        fast with :class:`TimeoutError`; a runaway turn is capped at
        ``_A2A_TASK_HARD_CAP_S`` (2h) so the future cannot leak.

        Why this is different from the generic ``_DEFAULT_INBOUND_TIMEOUT_S
        = 600s`` path: an a2a_task can legitimately run for tens of
        minutes (multi-step research, long tool chains), and the
        executor advertises liveness through the same protocol the
        gateway already trusts to extend its own stage deadline. There
        is no Bot Framework 240s ceiling on this ingress, so we use
        the protocol clock rather than a flat wall-clock cap.
        """

        hard_deadline = time.monotonic() + _A2A_TASK_HARD_CAP_S
        while True:
            now = time.monotonic()
            if now >= hard_deadline:
                raise TimeoutError("a2a_task hard cap")
            # Missing entry == heartbeat-lost. ``_a2a_send`` always
            # seeds the dict when wiring a task carrier; if the entry
            # is gone here either the carrier already cleaned up (the
            # waiter shouldn't even be running) or the inbound was a
            # spoofed ``source="a2a_task"`` carrier that bypassed the
            # seeding path. Defaulting to ``now`` in that case would
            # silently extend the wait to the 2h hard cap. Treat it
            # as a timeout instead.
            last_beat = self._task_heartbeat_at.get(request_id)
            if last_beat is None:
                raise TimeoutError("a2a_task heartbeat unseeded")
            soft_deadline = last_beat + _A2A_TASK_HEARTBEAT_GRACE_S
            if now >= soft_deadline:
                # Race window: if the event loop was just unblocked
                # after a long sync tool call, the late heartbeat
                # coroutine and this waiter are both runnable at the
                # same tick. Yield once so any pending
                # ``_HeartbeatTrackingOutbound._on_beat`` callback can
                # bump ``_task_heartbeat_at`` before we declare the
                # carrier dead, then re-check. Without this we kill
                # healthy executors 6 ms before their late heartbeat
                # lands (observed in prod, issue #312).
                await asyncio.sleep(0)
                last_beat = self._task_heartbeat_at.get(request_id)
                if last_beat is None:
                    raise TimeoutError("a2a_task heartbeat unseeded")
                if time.monotonic() >= last_beat + _A2A_TASK_HEARTBEAT_GRACE_S:
                    raise TimeoutError("a2a_task heartbeat lost")
                continue
            wait_s = max(0.5, min(soft_deadline, hard_deadline) - now)
            done, _pending = await asyncio.wait({future}, timeout=wait_s)
            if future in done:
                return future.result()
            # Loop: re-evaluate against (possibly bumped) heartbeat
            # timestamp and hard deadline.

    @staticmethod
    def _mirror_envelope_source(parsed: ConversationBody, ctx: Any) -> None:
        """Promote ``envelope.headers["source"]`` into ``body.metadata``.

        The gateway's Teams bridge router stamps the originating surface
        on ``envelope.headers["source"]`` (e.g. ``"teams_bridge"``). The
        bridge endpoint also mirrors it into ``body.metadata``, but only
        the body field reaches downstream consumers (inbound frame
        metadata -> ``ctx.metadata`` -> approval formatter selection,
        ``remember_teams_route``, risk-scorer cron/heartbeat branches).
        If a future producer sets only the header, the agent would pick
        the generic ``CloudApprovalFormatter`` and Teams would render
        the raw JSON envelope instead of an Adaptive Card. Mirror it
        here so the body becomes the single source of truth.
        """
        try:
            envelope_source = str(ctx.envelope.headers.get("source") or "")
        except AttributeError:
            envelope_source = ""
        if envelope_source and not parsed.metadata.get("source"):
            parsed.metadata["source"] = envelope_source

    async def _handle_conversation_request(
        self,
        body: dict[str, Any],
        ctx: Any,
        *,
        is_stream: bool,
    ) -> dict[str, Any]:
        parsed = ConversationBody.parse(body)
        self._mirror_envelope_source(parsed, ctx)
        request_id = str(ctx.envelope.id)
        loop = asyncio.get_running_loop()
        future: asyncio.Future[dict[str, Any]] = loop.create_future()
        pending = _PendingConversation(
            request_id=request_id,
            conversation_id=parsed.context.conversation_id,
            topic=str(ctx.envelope.topic or ""),
            is_stream=False,
            response_future=future,
        )
        self._pending_conversations[request_id] = pending
        source = str(parsed.metadata.get("source") or "")

        # Re-entrancy / privilege guard for a2a_task carriers. The legacy
        # ``_run_inbound_agent`` path (``a2a.message.send``) excludes
        # ``[notify, cron, spawn, a2a]`` to prevent infinite a2a loops
        # and to stop a remote agent from operating the local scheduler /
        # spawning long-running jobs / mis-attributing notifications to
        # the owner. The newer a2a_task carrier path was never wired up
        # to any exclusion, so executor turns happily called ``a2a``
        # again and re-spawned tasks.
        #
        # ``notify`` is intentionally NOT excluded here (unlike the
        # legacy list). On a2a_task the executor is a long-running async
        # task whose owner only sees plan/hook intermediate cards on
        # their own Teams — the carrier final reply goes back to the
        # *sender* agent, not the executor's owner. Leaving ``notify``
        # available lets the executor LLM push a final summary to its
        # own owner when useful. The deliberate divergence from the
        # legacy list is the reason we don't simply reuse that constant.
        #
        # Always enforce the required exclusions by merging into any
        # existing list: a remote peer might supply
        # ``metadata.exclude_tools=[]`` (or a non-list value) to bypass
        # the guard. Treat non-list values as untrusted and replace.
        if source == "a2a_task":
            _required_exclusions = ("cron", "spawn", "a2a")
            existing = parsed.metadata.get("exclude_tools")
            if isinstance(existing, list):
                merged = [str(t) for t in existing if isinstance(t, str)]
                for name in _required_exclusions:
                    if name not in merged:
                        merged.append(name)
                parsed.metadata["exclude_tools"] = merged
            else:
                parsed.metadata["exclude_tools"] = list(_required_exclusions)

        # Executor-side Teams routing promotion for a2a_task carriers.
        #
        # Policy (2026-05): a2a_task notify → teams only, fire-and-forget.
        #
        # When an inbound arrives via ``source="a2a_task"`` (another
        # agent's task carrier — the executor has no native surface of
        # its own; the carrier final reply goes back to the *sender*
        # agent, not the executor's owner), we unconditionally promote
        # the carrier ``request_id`` to a Teams route. This way the
        # executor's local emissions (plan progress, hook status cards,
        # approval prompts via ``_send_approval_prompt``) reach the
        # executor's own Teams chat with the correct Adaptive Card
        # formatter and ``push_target="teams"`` on /api/notify, instead
        # of falling through to the generic JSON formatter (rendered as
        # a giant JSON blob in Teams).
        #
        # No gateway confirmation, no escalation: we send to teams and
        # don't care about push_ack. Rationale:
        #   * Gateway has no client-observable signal we can use to
        #     pre-decide whether the owner has a Teams sub-channel
        #     (ConvRefStore is only populated by the legacy embedded
        #     Bot Framework adapter — cloud-only installs never write
        #     to it, so it's always empty in prod).
        #   * push_ack-driven webchat fallback would also need to
        #     re-format the Adaptive Card payload for webchat (the
        #     Teams Activity JSON renders as raw text on webchat), and
        #     ``_send_notify`` doesn't have the original request object
        #     needed for re-formatting at this layer.
        #   * Accepted trade-off: webchat-only users won't see a2a_task
        #     intermediate notifies. They still get final completion
        #     replies via the sender agent's normal channel.
        #
        # Scope: only promote for ``source == "a2a_task"``. Promoting
        # for *any* non-Teams ingress (e.g. ``cloud_webchat``) would
        # rewrite the source on a webchat session whose owner happens
        # to also have a Teams binding and route their cards to Teams
        # instead of the web UI they're actually using.
        #
        # Mirrors the existing inbound-dispatcher promotion above
        # which fires for ``source in ("teams_bridge", "cloud_teams")``.
        if source == "a2a_task" and request_id and not self.is_teams_routed(request_id):
            self.remember_teams_route(request_id)
            # Tag this route as a2a-promoted (not a native Teams
            # conversation) so the executor-notify filter in ``send()``
            # can drop noisy intermediate emissions for this
            # channel_id without touching real Teams sessions.
            self._a2a_promoted_channel_ids.add(request_id)
            if "physical_ingress" not in parsed.metadata:
                parsed.metadata["physical_ingress"] = source
            parsed.metadata["source"] = "cloud_teams"
            logger.debug(
                "[a2a-route] executor teams promotion: "
                "request_id={} physical_ingress={} executor={}",
                request_id,
                source or "(none)",
                self._user_id(),
            )

        timeout_s = self._inbound_timeout_s(ctx, source=source)
        sender_id = getattr(parsed.sender, "id", "") or ""
        text_len = len(getattr(parsed.content, "text", "") or "")
        start_t = time.monotonic()
        logger.info(
            "Inbound message received: request_id={} sender={} source={} "
            "topic={} text_len={} timeout_s={}",
            request_id,
            sender_id or "(unknown)",
            source or "(none)",
            ctx.envelope.topic,
            text_len,
            timeout_s,
        )
        try:
            queued = await self._publish_conversation(parsed, request_id=request_id)
            if not queued:
                # _on_message returns False when the FRE dispatcher / approval
                # fast-path intercepts the message instead of routing it to the
                # agent loop. Those paths still produce a user-visible reply by
                # calling ``channel.send(channel_id=request_id, ...)`` which,
                # because the pending future is already registered above,
                # delivers the body via ``response_future.set_result(...)``
                # rather than ``/api/notify``. Returning a bare "OK" here would
                # discard that pre-resolved body (e.g. the FRE welcome /
                # capability card) and surface a confusing placeholder reply.
                if future.done():
                    res = future.result()
                    logger.info(
                        "Inbound message replied: request_id={} elapsed={:.2f}s via=fast_path",
                        request_id,
                        time.monotonic() - start_t,
                    )
                    return res
                logger.info(
                    "Inbound message replied: request_id={} elapsed={:.2f}s via=ok_stub",
                    request_id,
                    time.monotonic() - start_t,
                )
                return self._response_body("OK", fmt="text")
            try:
                if source == "a2a_task":
                    result = await self._wait_a2a_task_with_heartbeat(future, request_id)
                elif timeout_s is not None:
                    result = await asyncio.wait_for(future, timeout=timeout_s)
                else:
                    result = await future
                logger.info(
                    "Inbound message replied: request_id={} elapsed={:.2f}s "
                    "reply_len={} via=agent_loop",
                    request_id,
                    time.monotonic() - start_t,
                    len(str(result.get("text") or "")) if isinstance(result, dict) else 0,
                )
                return result
            except TimeoutError as timeout_exc:
                # Bot Framework's HTTP webhook abandons us at ~240s. Promote
                # the channel_id to the proactive route so the still-running
                # agent's later send() reaches /api/notify with
                # push_target="teams" — request_id is the inbound frame's
                # channel_id used by subsequent send() calls.
                if source not in TEAMS_SOURCES:
                    # For ``a2a_task`` carriers the timeout was raised by
                    # ``_wait_a2a_task_with_heartbeat`` — either the
                    # executor stopped emitting ``task.progress`` beats
                    # (no longer alive / event loop blocked) or the 2h
                    # hard cap fired. In both cases the gateway will
                    # surface the BusinessError as ``task.timed_out``
                    # and the timeline card will paint ❌. The agent
                    # loop, however, is a separate asyncio task that
                    # would otherwise keep running past the timeout and
                    # eventually deliver a reply via /api/notify — out
                    # of sync with the now-terminal task state (the
                    # user sees both ❌ at +Tm and a fresh notify
                    # message at +Tm+Δ). Interrupt the agent so the
                    # carrier failure is the single source of truth.
                    if source == "a2a_task":
                        self._interrupt_agent_loop(
                            reason=f"a2a_task_carrier_timeout:{timeout_exc}",
                            request_id=request_id,
                            elapsed=time.monotonic() - start_t,
                        )
                    logger.warning(
                        "Inbound message failed: request_id={} elapsed={:.2f}s "
                        "reason=timeout detail={}",
                        request_id,
                        time.monotonic() - start_t,
                        timeout_exc,
                    )
                    raise BusinessError(
                        "timeout",
                        "agent did not produce a response before deadline",
                        retryable=True,
                    )
                self.remember_teams_route(request_id)
                logger.warning(
                    "Inbound message deferred: request_id={} elapsed={:.2f}s "
                    "reason=teams_long_task — proactive route promoted",
                    request_id,
                    time.monotonic() - start_t,
                )
                # Placeholder copy instead of BusinessError: the latter would
                # surface its raw error string to the user; the proactive
                # notify path will deliver the real reply later.
                user_text = getattr(parsed.content, "text", "") or ""
                return self._response_body(
                    _pick_long_task_placeholder(user_text),
                    fmt="markdown",
                )
        except asyncio.CancelledError:
            # Sender cancelled the carrier (a2a.message.send) request.
            # Without this hook the agent loop runs to completion and
            # pushes the result via /api/notify, which the user then
            # sees in Teams/WebChat even though the task card is already
            # marked interrupted. Propagate the cancel to the agent so
            # it stops generating at the next iteration boundary.
            #
            # Skip only when the response future was already resolved
            # with a real result before the cancel arrived (i.e. the
            # agent loop already finished naturally); in that case
            # there is no in-flight turn left to interrupt. NOTE:
            # ``asyncio.wait_for`` cancels the inner future as part of
            # propagating the outer cancellation, so ``future.done()``
            # alone is *not* a usable signal — we must explicitly
            # exclude the cancelled state.
            if not (future.done() and not future.cancelled()):
                self._interrupt_agent_loop(
                    reason="carrier_cancelled",
                    request_id=request_id,
                    elapsed=time.monotonic() - start_t,
                )
            raise
        finally:
            self._pending_conversations.pop(request_id, None)
            self._task_heartbeat_at.pop(request_id, None)
            if not future.done():
                future.cancel()

    def _interrupt_agent_loop(
        self,
        *,
        reason: str,
        request_id: str,
        elapsed: float,
    ) -> None:
        """Ask the agent loop to abort the in-flight turn.

        Called when the carrier request that drove the turn is no longer
        consuming output (sender cancel today; future: deadline expiry).
        The agent loop checks its ``_interrupt`` flag at each iteration
        boundary and returns ``"(interrupted)"`` instead of continuing,
        which stops further LLM/tool calls and prevents the proactive
        notify path from delivering an unwanted result. No-op if the
        runtime hasn't wired its agent yet (early-boot inbound).
        """
        runtime = self._runtime
        agent = getattr(runtime, "agent", None) if runtime is not None else None
        interrupt_fn = getattr(agent, "interrupt", None) if agent is not None else None
        if not callable(interrupt_fn):
            return
        try:
            interrupt_fn()
        except Exception as exc:  # noqa: BLE001 — best-effort
            logger.warning(
                "Agent interrupt failed: request_id={} reason={} err={}",
                request_id,
                reason,
                exc,
            )
            return
        logger.info(
            "Inbound message interrupted: request_id={} elapsed={:.2f}s reason={}",
            request_id,
            elapsed,
            reason,
        )

    async def _handle_conversation_stream(self, body: dict[str, Any], ctx: Any) -> Any:
        parsed = ConversationBody.parse(body)
        self._mirror_envelope_source(parsed, ctx)
        request_id = str(ctx.envelope.id)
        sender_id = getattr(parsed.sender, "id", "") or ""
        text_len = len(getattr(parsed.content, "text", "") or "")
        logger.info(
            "Inbound message received: request_id={} sender={} source={} "
            "topic={} text_len={} mode=stream",
            request_id,
            sender_id or "(unknown)",
            str(parsed.metadata.get("source") or "") or "(none)",
            ctx.envelope.topic,
            text_len,
        )
        # Bounded queue: applies backpressure to fast agents producing chunks
        # faster than the transport can drain.
        queue: asyncio.Queue[dict[str, Any] | None] = asyncio.Queue(maxsize=64)
        pending = _PendingConversation(
            request_id=request_id,
            conversation_id=parsed.context.conversation_id,
            topic=str(ctx.envelope.topic or ""),
            is_stream=True,
            stream_queue=queue,
        )
        self._pending_conversations[request_id] = pending
        stream_start_t = time.monotonic()
        stream_done = False
        try:
            queued = await self._publish_conversation(parsed, request_id=request_id)
            if not queued:
                # Mirror _handle_conversation_request: the FRE dispatcher /
                # approval fast-path may have already pushed a body (and a
                # ``None`` sentinel) onto the stream queue via
                # ``channel.send`` when ``_on_message`` returned False. Drain
                # those entries before falling back to "OK" so the caller
                # actually sees the FRE card / approval ack.
                drained = False
                while not queue.empty():
                    item = queue.get_nowait()
                    if item is None:
                        drained = True
                        break
                    drained = True
                    yield item
                if not drained:
                    yield self._response_body("OK", fmt="text")
                stream_done = True
                return
            while True:
                item = await queue.get()
                if item is None:
                    stream_done = True
                    break
                yield item
        except asyncio.CancelledError:
            # Sender cancelled the streaming carrier — same rationale as
            # the sync variant above. Without this the agent loop would
            # finish the turn and push the unwanted reply via the
            # proactive notify path. Skip when the stream already
            # finished cleanly: there is no in-flight turn left to
            # interrupt.
            if not stream_done:
                self._interrupt_agent_loop(
                    reason="carrier_cancelled_stream",
                    request_id=request_id,
                    elapsed=time.monotonic() - stream_start_t,
                )
            raise
        finally:
            self._pending_conversations.pop(request_id, None)

    async def _publish_conversation(
        self,
        body: ConversationBody,
        *,
        request_id: str,
    ) -> bool:
        content = body.content.to_dict()
        metadata = dict(body.metadata)
        metadata["content_format"] = content.get("format", "text")
        metadata["conversation_id"] = body.context.conversation_id
        metadata["request_id"] = request_id
        metadata["turn_id"] = request_id
        frame = {
            "content": content.get("text", ""),
            "content_format": metadata["content_format"],
            "delivery_route_id": request_id,
            "sender_id": body.sender.id,
            "sender_name": body.sender.display_name or body.sender.id,
            "conversation_id": body.context.conversation_id,
            "turn_id": request_id,
            "agent_session_key": f"{self.name}:{body.sender.id}:{body.context.conversation_id}",
            "timestamp": body.timestamp,
            "metadata": metadata,
        }
        return await self._on_message(frame)

    def _response_body(
        self,
        content: str,
        *,
        fmt: str = "markdown",
        metadata: dict[str, Any] | None = None,
        card: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        content_body: dict[str, Any] = {
            "content_type": "text",
            "text": content,
            "format": fmt or "markdown",
        }
        if card is not None:
            content_body["card"] = card
        return {
            "content": content_body,
            "metadata": dict(metadata or {}),
        }

    def _build_inbound_a2a_envelope(self, body: dict[str, Any], ctx: Any) -> A2AEnvelope:
        """Adapt a v1 ``a2a.message.send`` body into the legacy A2AEnvelope shape.

        The envelope id is reused from the wire request id so log correlation
        across the gateway hop is preserved (and any reply / ack sent later
        through ``_send_envelope`` carries the same parent).
        """
        sender_dict = body.get("sender") or {}
        recipient_dict = body.get("recipient") or {}
        content_dict = body.get("content") or {}
        context_dict = body.get("context") or {}
        sender_party = A2AParty(
            id=str(sender_dict.get("user_id") or sender_dict.get("id") or ""),
            name=str(sender_dict.get("display_name") or ""),
            agent_id=str(sender_dict.get("id") or sender_dict.get("agent_id") or ""),
        )
        receiver_party = A2AParty(
            id=str(recipient_dict.get("user_id") or ""),
            name="",
            agent_id=str(recipient_dict.get("agent_id") or ""),
        )
        parent_id = str(context_dict.get("parent_envelope_id") or "") or None
        return A2AEnvelope(
            id=str(ctx.envelope.id),
            type=A2AMessageType.TEXT,
            sender=sender_party,
            receiver=receiver_party,
            timestamp=int(time.time()),
            parent_id=parent_id,
            payload={"content": str(content_dict.get("text") or "")},
        )

    async def _send_notify(self, channel_id: str, content: str, **kwargs: Any) -> None:
        if self._business is None:
            raise RuntimeError("cloud protocol client is not started")
        target = kwargs.get("push_target") or "teams"
        conversation_id = str(kwargs.get("thread_id") or channel_id or self.name)
        if ":" not in conversation_id:
            conversation_id = f"{target}:{conversation_id}"

        # When *content* is a JSON-serialized Bot Framework Activity wrapping
        # an Adaptive Card (the canonical TeamsApprovalFormatter / teams_cards
        # output), promote the card into ``body.content.card`` so the gateway
        # forwards it as a structured Adaptive Card attachment per
        # docs/05-channels.md \u00a73.4. Without this, the gateway sees a plain
        # JSON string in ``content.text`` and Teams renders it as raw JSON.
        text_content: str = content
        card_content: dict[str, Any] | None = None
        if target == "teams":
            extracted_card = _extract_card_from_activity_json(content)
            if extracted_card is not None:
                card_content = extracted_card
                text_content = ""

        content_body: dict[str, Any] = {
            "content_type": "text",
            "text": text_content,
            "format": kwargs.get("format", "markdown"),
        }
        if card_content is not None:
            content_body["card"] = card_content

        # cloud_tui notifications carry a structured JSON body — the
        # gateway's _route_cloud_tui_notify reads ``content.kind`` /
        # ``content.payload`` directly, not the text field. Parse the
        # caller-provided JSON string back into a dict and inline it so
        # the route gets the fields it expects.
        if target == "cloud_tui":
            try:
                parsed = json.loads(content) if isinstance(content, str) else None
            except json.JSONDecodeError:
                parsed = None
            if isinstance(parsed, dict):
                content_body["text"] = ""
                if "kind" in parsed:
                    content_body["kind"] = parsed["kind"]
                if "payload" in parsed:
                    content_body["payload"] = parsed["payload"]
                if "request_id" in parsed:
                    content_body["request_id"] = parsed["request_id"]

        # In-place update key for proactive Teams cards. When set, the
        # bridge will reuse the activity id of the first send under
        # ``(oid, update_key)`` and call UpdateActivityAsync on subsequent
        # emits — used by long-task progress cards (see PlanTool) to
        # animate a single Adaptive Card instead of stacking new cards
        # per progress tick. Only meaningful for ``push_target=teams``;
        # webchat ignores the field. Falls back to send-fresh on the bot
        # side if no prior id is stored or the update fails.
        update_key = kwargs.get("update_key")
        if isinstance(update_key, str) and update_key.strip():
            content_body["update_key"] = update_key.strip()

        body = {
            "context": {"conversation_id": conversation_id, "task_id": None},
            "sender": {
                "kind": "agent",
                "id": self._agent_id(),
                "user_id": self._user_id(),
            },
            "recipient": {
                "kind": "channel",
                "channel": target,
                "channel_conversation_id": kwargs.get("thread_id") or channel_id,
            },
            "content": content_body,
            "timestamp": datetime.now(UTC).isoformat(),
            "metadata": {
                key: value
                for key, value in {
                    "request_id": kwargs.get("push_request_id"),
                    "title": kwargs.get("title"),
                }.items()
                if value is not None
            },
        }
        response = await self._business.request("conversation.message.notify", body, timeout=30)
        request_id = kwargs.get("push_request_id")
        if isinstance(request_id, str) and request_id:
            self._record_push_delivery(request_id, target=target, response=response)

    async def _on_message(self, frame: dict[str, Any]) -> bool:
        """Publish an inbound message frame to the bus."""
        delivery_route_id = str(frame.get("delivery_route_id") or frame.get("channel_id") or "")
        sender_id_for_log = frame.get("sender_id", "")
        if self._validator and not self._validator.validate_message(frame):
            logger.warning(
                "Inbound message rejected: reason=relay_validator request_id={} sender={}",
                delivery_route_id or "(none)",
                sender_id_for_log or "(unknown)",
            )
            return False

        content = frame.get("content", "")
        content_format = frame.get("content_format", "text").lower()

        # Strip <at>…</at> @mention XML BEFORE HTML→Markdown conversion,
        # otherwise html_to_markdown strips the tags but leaves the text.
        content = re.sub(r"<at>[^<]*</at>", "", content).strip()

        # Convert HTML rich text to Markdown
        if content_format == "html":
            content = html_to_markdown(content)
            content_format = "markdown"

        delivery_route_id = str(frame.get("delivery_route_id") or frame.get("channel_id") or "")
        sender_id = frame.get("sender_id", "")
        sender_name = frame.get("sender_name", sender_id)
        metadata = {**frame.get("metadata", {})}
        metadata["content_format"] = content_format
        conversation_id = str(
            frame.get("conversation_id")
            or metadata.get("conversation_id")
            or frame.get("thread_id")
            or delivery_route_id
        )
        turn_id = str(
            frame.get("turn_id")
            or metadata.get("turn_id")
            or frame.get("request_id")
            or metadata.get("request_id")
            or delivery_route_id
        )
        agent_session_key = str(
            frame.get("agent_session_key")
            or metadata.get("agent_session_key")
            or frame.get("session_key")
            or f"{self.name}:{sender_id or 'anonymous'}:{conversation_id}"
        )
        physical_ingress = str(
            metadata.get("physical_ingress") or metadata.get("source") or self.name
        )

        # Allow-list check must happen before any approval fast-path
        # and before storing conv_ref (don't persist routing data from blocked senders).
        if not self.is_allowed(sender_id):
            logger.warning(
                "Inbound message rejected: reason=not_in_allow_from request_id={} sender={}",
                delivery_route_id or "(none)",
                sender_id or "(unknown)",
            )
            return False

        # Store conv_ref from Teams messages for proactive push later.
        conv_ref = metadata.get("conv_ref")
        if metadata.get("source") == "cloud_teams" and isinstance(conv_ref, dict):
            cr_surl = conv_ref.get("service_url", "")
            cr_cid = conv_ref.get("conversation_id", "")
            if cr_surl and cr_cid and sender_id:
                self._conv_ref_store.upsert(sender_id, cr_surl, cr_cid)

        # Remember Teams-sourced channel_ids so a post-pending follow-up
        # (e.g. tool result after an approval card consumed the /chatng
        # waiter) routes via /api/notify with push_target="teams" instead
        # of falling back to "webchat" (which the gateway would drop).
        if delivery_route_id and metadata.get("source") in ("teams_bridge", "cloud_teams"):
            self.remember_teams_route(delivery_route_id)
            logger.debug(
                "[a2a-route] registered teams channel_id={} (set size={})",
                delivery_route_id,
                len(self._teams_routed_channel_ids),
            )

        # First-Run Experience: when a Teams user sends their first
        # message we surface a welcome Adaptive Card. Subsequent FRE
        # button clicks (capability tour, A2A walkthrough) are also
        # handled here. Returning ``True`` from the dispatcher means a
        # card was sent; if the message was *only* a button reply we
        # skip the agent path so the LLM doesn't add a redundant
        # response on top of the card. See ``channels/teams_fre.py``.
        try:
            from praestoclaw.channels.teams_fre import (
                fre_should_intercept,
                maybe_send_fre_card,
            )

            sent_fre_card = await maybe_send_fre_card(
                self,
                sender_id=sender_id,
                channel_id=delivery_route_id,
                content=content,
                metadata=metadata,
                sender_name=sender_name,
            )
            if sent_fre_card and fre_should_intercept(content):
                return False
        except Exception as fre_exc:  # noqa: BLE001 \u2014 never block chat
            logger.debug("Teams FRE hook failed: {}", fre_exc)

        # Metadata approval fast-path: Teams card button or slash command sends
        # approval_action in metadata — resolve directly, bypassing the blocked queue.
        approval_action = metadata.get("approval_action")
        approval_request_id = metadata.get("approval_request_id")
        if approval_action and approval_request_id:
            await self._on_approval_response(
                {
                    "action": approval_action,
                    "request_id": approval_request_id,
                    "sender_id": sender_id,
                }
            )
            logger.debug(
                "Cloud approval action={} request_id={}", approval_action, approval_request_id
            )
            return False

        if not content:
            logger.info(
                "Inbound message rejected: reason=empty_content request_id={} sender={}",
                delivery_route_id or "(none)",
                sender_id or "(unknown)",
            )
            return False

        # Approval keyword / slash-command fast-path — bypass the blocked agent queue.
        cl = content.lower()  # content already stripped via re.sub earlier
        action: str | None = None
        req_id = ""

        parts = content.split(maxsplit=1)
        # /approve <id> · /deny <id> · /always <id>  (with explicit request_id)
        if cl.startswith("/approve ") and len(parts) == 2:
            action, req_id = "approve", parts[1]
        elif cl.startswith("/deny ") and len(parts) == 2:
            action, req_id = "deny", parts[1]
        elif cl.startswith("/always ") and len(parts) == 2:
            action, req_id = "always", parts[1]
        # bare keyword (no id — runtime resolves any single pending approval)
        # Only intercept when there IS a pending approval; otherwise pass
        # through to the agent so "yes"/"no" in normal conversation works.
        elif cl in {"yes", "y", "approve", "/approve"}:
            action = "approve"
        elif cl in {"no", "n", "deny", "/deny"}:
            action = "deny"
        elif cl in {"always", "a", "/always"}:
            action = "always"

        if action and req_id:
            # Explicit /approve <id> — always route to approval
            pass
        elif action:
            # Bare keyword — only intercept if there's a pending approval.
            # Otherwise "yes"/"no" in normal conversation gets swallowed.
            has_pending = False
            if self._runtime and hasattr(self._runtime, "approval_manager"):
                has_pending = bool(self._runtime.approval_manager.get_pending())
            if not has_pending:
                action = None

        if action:
            await self._on_approval_response(
                {"action": action, "request_id": req_id, "sender_id": sender_id}
            )
            logger.debug("Cloud approval action={} request_id={}", action, req_id or "(any)")
            return False

        # ``update`` / ``/update`` / ``更新`` fast-path — bypass the agent
        # entirely. The update flow is deterministic; routing it through the
        # LLM wastes a round-trip and races the daemon-kill against the
        # model-generated reply, leaving the bridge waiter to time out at
        # 220s with "Request timed out" even though the update succeeded.
        #
        # We reply to the bridge waiter synchronously, THEN spawn a
        # DETACHED ``pc update`` subprocess. That subprocess re-enters
        # update.py, detects ``_invoked_by_daemon()``, and calls
        # ``_schedule_self_update_detached`` from its OWN process — then
        # exits. This is critical: the detached worker's parent becomes
        # the (about-to-exit) ``pc update`` process, not the daemon. The
        # worker subsequently runs ``taskkill /F /T <daemon_pid>``; the
        # /T flag would kill the worker as collateral if the worker were
        # a direct child of the daemon. Going through an intermediate
        # ``pc update`` spawner preserves the orphan-worker invariant
        # that made the original shell-tool flow work.
        if cl in {"update", "/update", "更新", "upgrade", "/upgrade"}:
            # Send the reply FIRST so the bridge waiter is released even if
            # ``subprocess.Popen`` stalls under AV / slow-disk conditions —
            # the whole point of this fast-path is to beat the 220 s bridge
            # timeout. We then spawn the detached updater; on failure we
            # send a follow-up generic error (raw exception text could leak
            # internal paths / env into a chat surface).
            await self.send(
                delivery_route_id,
                "🔄 Update started. The bot will restart and notify you when it's done.",
            )
            try:
                import subprocess
                import sys

                creationflags = 0
                start_new_session = False
                if sys.platform == "win32":
                    creationflags = (
                        subprocess.DETACHED_PROCESS  # type: ignore[attr-defined]
                        | subprocess.CREATE_NEW_PROCESS_GROUP
                    )
                else:
                    start_new_session = True
                subprocess.Popen(  # noqa: S603
                    [sys.executable, "-m", "praestoclaw", "update"],
                    close_fds=True,
                    creationflags=creationflags,
                    start_new_session=start_new_session,
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            except Exception:  # noqa: BLE001 — never let fast-path raise
                logger.exception("Fast-path update failed to spawn pc update")
                await self.send(
                    delivery_route_id,
                    "⚠️ Update could not be started. Check the agent logs for details.",
                )
            logger.debug("Cloud update fast-path dispatched request_id={}", delivery_route_id)
            return False

        msg = InboundMessage(
            logical_channel=self.name,
            physical_ingress=physical_ingress,
            delivery_route_id=delivery_route_id,
            sender_id=sender_id,
            sender_name=sender_name,
            content=content,
            content_format=content_format,
            conversation_id=conversation_id,
            turn_id=turn_id,
            agent_session_key=agent_session_key,
            timestamp=frame.get("timestamp"),
            metadata=metadata,
        )
        await self._bus.publish_inbound(msg)
        logger.debug(
            "Cloud message delivery_route_id={} sender={} len={}",
            delivery_route_id,
            sender_id,
            len(content),
        )
        return True

    async def _on_approval_response(self, frame: dict[str, Any]) -> None:
        """Resolve an approval request directly (bypasses inbound queue).

        Approval responses must NOT go through the inbound message queue
        because the agent loop is blocked in the pre_tool_use hook waiting
        for resolution — routing through the queue would deadlock.
        """
        action = frame.get("action", "")
        request_id = frame.get("request_id", "")
        if not action:
            logger.warning("Malformed approval_response frame: {}", frame)
            return
        # Empty request_id is valid — runtime resolves any single pending approval

        sender_id = frame.get("sender_id", "unknown")

        # Resolve directly via the approval manager on the bus event
        self._bus.events.emit(
            EventType.APPROVAL_RESOLVED,
            {
                "request_id": request_id,
                "action": action,
                "resolver": sender_id,
            },
        )
        logger.debug("Approval response: action={} request_id={}", action, request_id)

    def set_a2a_runtime(self, runtime: Any) -> None:
        """Attach A2A runtime for inbound request dispatch."""
        self._a2a_runtime = runtime
        runtime.set_frame_sender(self.send_a2a_frame)
        runtime.set_discovery_sender(self.discover_a2a)
        runtime.set_list_sender(self.list_a2a)

    async def send_a2a_frame(self, frame: dict[str, Any]) -> None:
        """Translate the legacy local A2A envelope into a v1 business request."""

        if self._business is None:
            raise RuntimeError("cloud protocol client is not started")
        business = self._business
        if frame.get("type") != "a2a_message" or not isinstance(frame.get("envelope"), dict):
            raise ValueError("expected an a2a_message frame")

        envelope = dict(frame["envelope"])
        message_id = str(envelope.get("id", ""))
        sender_value = envelope.get("sender")
        receiver_value = envelope.get("receiver")
        payload_value = envelope.get("payload")
        sender: dict[str, Any] = sender_value if isinstance(sender_value, dict) else {}
        receiver: dict[str, Any] = receiver_value if isinstance(receiver_value, dict) else {}
        payload: dict[str, Any] = payload_value if isinstance(payload_value, dict) else {}
        receiver_id = str(receiver.get("id") or "")
        receiver_agent_id = str(receiver.get("agent_id") or receiver_id)
        content = str(payload.get("content") or payload.get("reason") or "")

        # Task-mode upgrade (issue #181 originator side): when the runtime
        # attached a ``task`` dict to the frame, build a task-bearing
        # carrier body instead of a plain text body. This is the only
        # path on the originator side that produces
        # ``CONTENT_TYPE_TASK_REQUEST`` carriers, so the executor's
        # ``_maybe_unwrap_task_carrier`` → ``TaskHeartbeatEmitter``
        # chain (PR #229) actually fires for LLM-driven A2A calls.
        task_dict = frame.get("task")
        task_id_for_dispatch: str | None = None
        if isinstance(task_dict, dict):
            from praestoclaw.task import (  # noqa: PLC0415
                build_task_request_body,
                new_task_id,
            )

            tid = str(task_dict.get("task_id") or "").strip() or new_task_id()
            summary = str(task_dict.get("summary") or "").strip()
            if not summary:
                # Fall back to a truncated form of the message text so
                # the executor / Gateway always have a non-empty intent
                # summary (build_task_request_body raises otherwise).
                summary = (content or "(no summary)")[:120]
            hint_risk = task_dict.get("hint_risk")
            soft_ms = task_dict.get("soft_ms")
            hard_ms = task_dict.get("hard_ms")
            args = task_dict.get("args") if isinstance(task_dict.get("args"), dict) else None
            body = build_task_request_body(
                sender_user_id=self._user_id(),
                sender_agent_id=self._agent_id(),
                recipient_user_id=receiver_id or self._user_id(),
                recipient_agent_id=receiver_agent_id or self._agent_id(),
                conversation_id=f"a2a-internal:{self._user_id()}:{message_id or 'message'}",
                task_id=tid,
                summary=summary,
                action=task_dict.get("action"),
                hint_risk=hint_risk if isinstance(hint_risk, str) else None,
                undoable=bool(task_dict.get("undoable", False)),
                args=args,
                soft_ms=int(soft_ms) if isinstance(soft_ms, int | float) else None,
                hard_ms=int(hard_ms) if isinstance(hard_ms, int | float) else None,
                sender_display_name=sender.get("name") or self._agent_id(),
                metadata={
                    "legacy_a2a_id": message_id,
                    "legacy_a2a_type": envelope.get("type"),
                },
            )
            # Pin the parent envelope id so the executor's reply still
            # threads back into the same A2A dispatch tracker.
            body.setdefault("context", {})["parent_envelope_id"] = envelope.get("parent_id")
            task_id_for_dispatch = tid
        else:
            body = {
                "context": {
                    "conversation_id": f"a2a-internal:{self._user_id()}:{message_id or 'message'}",
                    "task_id": None,
                    "parent_envelope_id": envelope.get("parent_id"),
                },
                "sender": {
                    "kind": "agent",
                    "id": self._agent_id(),
                    "user_id": self._user_id(),
                    "display_name": sender.get("name") or self._agent_id(),
                },
                "recipient": {
                    "kind": "agent",
                    "user_id": receiver_id or self._user_id(),
                    "agent_id": receiver_agent_id or self._agent_id(),
                },
                "content": {"content_type": "text", "text": content, "format": "text"},
                "timestamp": datetime.now(UTC).isoformat(),
                "metadata": {
                    "legacy_a2a_id": message_id,
                    "legacy_a2a_type": envelope.get("type"),
                },
            }

        if self._a2a_runtime and message_id:
            dispatch_payload: dict[str, Any] = {
                "message_id": message_id,
                "status": "dispatched",
            }
            if task_id_for_dispatch:
                dispatch_payload["task_id"] = task_id_for_dispatch
            await self._a2a_runtime.handle_a2a_dispatch(dispatch_payload)

        async def _request_and_forward_reply() -> None:
            # For task-bearing carriers the gateway's task coordinator
            # owns the entire lifecycle: it ack's the carrier
            # synchronously at submit time and surfaces the final
            # result via ``task.progress(stage=done|declined)``. So we
            # disable the a2a-level reply timeout (``None`` means wait
            # forever) and drop any ack we receive — there is nothing
            # to forward back to the a2a tool because the task layer
            # owns the user-visible thread now. Plain (non-task) a2a
            # carriers keep the original 60s reply timeout.
            request_timeout = None if task_id_for_dispatch else 60
            try:
                response = await business.request(
                    A2A_MESSAGE_SEND_TOPIC, body, timeout=request_timeout
                )
                if task_id_for_dispatch and response.get("ack"):
                    return
                await self._forward_a2a_business_reply(envelope, response)
            except TimeoutError:
                await self._forward_a2a_business_error(
                    envelope,
                    BusinessError("timeout", "a2a.message.send timed out", retryable=True),
                )
            except BusinessError as exc:
                await self._forward_a2a_business_error(envelope, exc)
            except Exception as exc:
                logger.exception("A2A business request failed: {}", exc)
                await self._forward_a2a_business_error(
                    envelope,
                    BusinessError("internal_error", str(exc), retryable=False),
                )

        task = asyncio.create_task(_request_and_forward_reply())
        self._background_tasks.add(task)
        task.add_done_callback(self._background_tasks.discard)

    async def publish_a2a_card(self) -> None:
        """Publish local discovery data through the native Gateway protocol."""

        if not self._a2a_enabled or not self._a2a_card_seed:
            return
        if self._business is None:
            raise RuntimeError("cloud protocol client is not started")
        try:
            await self._business.request(
                "a2a.card.publish",
                {
                    "card": self._a2a_card_seed,
                    "visibility": {"scope": "public"},
                },
                timeout=10,
            )
        except BusinessError as exc:
            logger.warning("A2A card publish failed: {} — {}", exc.code, exc.message)
        except TimeoutError:
            logger.warning("A2A card publish timed out")

    async def discover_a2a(self, target_user_id: str) -> dict[str, Any]:
        """Query Gateway-internal A2A discovery through the business protocol."""

        if self._business is None:
            return {"error": True, "detail": "cloud protocol client is not started"}
        try:
            return await self._business.request(
                "a2a.discovery.show",
                {
                    "query": {"kind": "user", "user_id": target_user_id},
                    "include": ["capabilities", "skills", "presence"],
                },
                timeout=30,
            )
        except TimeoutError:
            return {"error": True, "code": "timeout", "detail": "A2A discovery timed out"}
        except BusinessError as exc:
            return {
                "error": True,
                "code": exc.code,
                "detail": exc.message,
                "retryable": exc.retryable,
            }

    async def list_a2a(self, scope: str = "mine") -> dict[str, Any]:
        """Query Gateway-internal A2A semantic listing through the business protocol."""

        if self._business is None:
            return {"error": True, "detail": "cloud protocol client is not started"}
        try:
            return await self._business.request(
                "a2a.discovery.list",
                {
                    "scope": scope or "mine",
                    "include": ["capabilities", "skills", "presence"],
                },
                timeout=30,
            )
        except TimeoutError:
            return {"error": True, "code": "timeout", "detail": "A2A listing timed out"}
        except BusinessError as exc:
            return {
                "error": True,
                "code": exc.code,
                "detail": exc.message,
                "retryable": exc.retryable,
            }

    # ── Task protocol (PraestoClaw Gateway v1) ─────────────────────────

    async def send_task_request(
        self,
        recipient_user_id: str,
        summary: str,
        *,
        recipient_agent_id: str | None = None,
        task_id: str | None = None,
        action: str | None = None,
        hint_risk: str | None = None,
        undoable: bool = False,
        args: dict[str, Any] | None = None,
        soft_ms: int | None = None,
        hard_ms: int | None = None,
        timeout_s: float = 120.0,
    ) -> dict[str, Any]:
        """Send a task-bearing ``a2a.message.send`` request.

        Matches scenarios 2/3/6 of the Gateway smoke script: a normal
        a2a carrier whose ``content`` advertises
        ``application/vnd.praestoclaw.task+json`` and embeds a
        ``TaskRequest`` body.
        """

        if self._business is None:
            raise RuntimeError("cloud protocol client is not started")

        from praestoclaw.task import build_task_request_body, new_task_id  # noqa: PLC0415

        tid = task_id or new_task_id()
        body = build_task_request_body(
            sender_user_id=self._user_id(),
            sender_agent_id=self._agent_id(),
            recipient_user_id=recipient_user_id,
            recipient_agent_id=recipient_agent_id,
            task_id=tid,
            summary=summary,
            action=action,
            hint_risk=hint_risk,
            undoable=undoable,
            args=args,
            soft_ms=soft_ms,
            hard_ms=hard_ms,
        )
        try:
            response = await self._business.request(A2A_MESSAGE_SEND_TOPIC, body, timeout=timeout_s)
            return {"ok": True, "task_id": tid, "response": response}
        except TimeoutError:
            return {"ok": False, "task_id": tid, "error_code": "timeout"}
        except BusinessError as exc:
            return {
                "ok": False,
                "task_id": tid,
                "error_code": exc.code,
                "error_message": exc.message,
            }

    async def send_task_control(
        self,
        task_id: str,
        action: str,
        *,
        reason: str | None = None,
        timeout_s: float = 30.0,
    ) -> dict[str, Any]:
        """Send a ``task.control`` request (approve/deny/cancel/interrupt/undo)."""

        if self._business is None:
            raise RuntimeError("cloud protocol client is not started")

        from praestoclaw.task import (  # noqa: PLC0415
            TASK_CONTROL_TOPIC,
            build_task_control_body,
        )

        body = build_task_control_body(task_id=task_id, action=action, reason=reason)
        try:
            response = await self._business.request(TASK_CONTROL_TOPIC, body, timeout=timeout_s)
            return {"ok": True, "task_id": task_id, "action": action, "response": response}
        except TimeoutError:
            return {
                "ok": False,
                "task_id": task_id,
                "action": action,
                "error_code": "timeout",
            }
        except BusinessError as exc:
            return {
                "ok": False,
                "task_id": task_id,
                "action": action,
                "error_code": exc.code,
                "error_message": exc.message,
            }

    async def send_u2u(
        self,
        target_user_id: str,
        text: str,
        *,
        channel: Any = None,
        channel_id: str = "",
        session_id: str = "",
    ) -> dict[str, Any]:
        """Send a fire-and-forget U2U event to a target user_id."""

        if self._business is None:
            raise RuntimeError("cloud protocol client is not started")
        envelope = Envelope.event(
            U2U_MESSAGE_SEND_TOPIC,
            self._u2u_body(target_user_id=target_user_id, text=text),
        )
        self._u2u_pending_targets[envelope.id] = {
            "target_user_id": target_user_id,
            "channel": channel or self.name,
            "channel_id": channel_id,
            "session_id": session_id,
        }
        try:
            await self._business.send_envelope(envelope)
        except Exception:
            self._u2u_pending_targets.pop(envelope.id, None)
            raise
        return {"ok": True, "message_id": envelope.id}

    async def ask_u2u(
        self,
        target_user_id: str,
        text: str,
        *,
        timeout_s: float = 120.0,
    ) -> dict[str, Any]:
        """Send a U2U ask request and wait for the target master's reply."""

        if self._business is None:
            raise RuntimeError("cloud protocol client is not started")
        return await self._business.request(
            U2U_MESSAGE_ASK_TOPIC,
            self._u2u_body(target_user_id=target_user_id, text=text),
            timeout=timeout_s,
        )

    def _u2u_body(self, *, target_user_id: str, text: str) -> dict[str, Any]:
        source_user_id = self._user_id()
        return {
            "context": {
                "conversation_id": (
                    f"u2u:{source_user_id}:{target_user_id}:{int(time.time() * 1000)}"
                ),
                "task_id": None,
            },
            "sender": {
                "kind": "agent",
                "id": self._agent_id(),
                "agent_id": self._agent_id(),
                "user_id": source_user_id,
                "display_name": self._agent_id(),
            },
            "recipient": {"kind": "user", "user_id": target_user_id},
            "content": {"content_type": "text", "text": text, "format": "text"},
            "timestamp": datetime.now(UTC).isoformat(),
            "metadata": {},
        }

    async def _publish_u2u_receipt(self, body: dict[str, Any]) -> None:
        message_id = str(body.get("message_id") or "")
        if not message_id:
            return
        pending = self._u2u_pending_targets.pop(message_id, {})
        target_user_id = str(pending.get("target_user_id") or "对方")
        channel = pending.get("channel") or self.name
        session_id = str(
            pending.get("session_id") or pending.get("channel_id") or f"u2u:{message_id}"
        )
        text = f"[U2U] {target_user_id} 已收到你发出的消息 (msg_id={message_id})"
        await self._bus.publish_inbound(
            InboundMessage(
                logical_channel=channel,
                physical_ingress="u2u_receipt",
                delivery_route_id=f"u2u:receipt:{message_id}",
                sender_id="u2u-system",
                sender_name="U2U",
                content=text,
                conversation_id=session_id,
                turn_id=message_id,
                agent_session_key=session_id,
                metadata={
                    "source": "u2u_receipt",
                    "kind": "delivered",
                    "message_id": message_id,
                    "target_user_id": target_user_id,
                    "origin_channel_id": pending.get("channel_id", ""),
                    "delivered_at": body.get("delivered_at", ""),
                },
            )
        )

    async def _forward_a2a_business_reply(
        self,
        original: dict[str, Any],
        response: dict[str, Any],
    ) -> None:
        if self._a2a_runtime is None:
            return
        content_value = response.get("content")
        content: dict[str, Any] = content_value if isinstance(content_value, dict) else {}
        text = str(content.get("text") or "")
        await self._a2a_runtime.handle_a2a_message(
            {
                "type": "a2a_message",
                "envelope": {
                    "id": f"reply-{original.get('id', '')}",
                    "type": "text",
                    "parent_id": original.get("id"),
                    "sender": original.get("receiver", {}),
                    "receiver": original.get("sender", {}),
                    "payload": {"content": text},
                    "timestamp": int(time.time()),
                },
            }
        )

    async def _forward_a2a_business_error(
        self,
        original: dict[str, Any],
        error: BusinessError,
    ) -> None:
        if self._a2a_runtime is None:
            return
        await self._a2a_runtime.handle_a2a_message(
            {
                "type": "a2a_message",
                "envelope": {
                    "id": f"error-{original.get('id', '')}",
                    "type": "error",
                    "parent_id": original.get("id"),
                    "sender": original.get("receiver", {}),
                    "receiver": original.get("sender", {}),
                    "payload": {
                        "code": error.code,
                        "reason": error.message,
                        "detail": json.dumps(error.details, ensure_ascii=False),
                    },
                    "timestamp": int(time.time()),
                },
            }
        )

    async def _on_admin_request(self, frame: dict[str, Any]) -> None:
        """Handle an admin data query from the Cloud Gateway.

        Routes the request to the local WebServer's API handlers in-process
        and sends back an admin_response frame with the result.
        """
        request_id = frame.get("request_id", "")
        endpoint = frame.get("endpoint", "")
        if not request_id or not endpoint:
            logger.warning("Malformed admin_request frame: {}", frame)
            return
        if self._validator:
            caller_oid = self._validator.validate_admin(frame)
            if caller_oid is None:
                logger.warning("Admin request rejected by relay validator")
                return
            frame["relay_caller_oid"] = caller_oid

        status = 200
        body: Any = {"error": "not_found", "message": f"Unknown endpoint: {endpoint}"}

        try:
            result = await self._handle_admin_endpoint(endpoint, frame)
            if result is not None:
                status = result.get("status", 200)
                body = result.get("body", body)
            else:
                status = 404
        except Exception as exc:
            logger.error("Admin request error endpoint={}: {}", endpoint, exc)
            status = 500
            body = {"error": "internal_error", "message": str(exc)}

        logger.debug(
            "Admin request handled locally request_id={} status={} body={}",
            request_id,
            status,
            body if isinstance(body, str) else json.dumps(body, ensure_ascii=False),
        )

    def _build_channels(self, rt: Any) -> list[dict[str, Any]]:
        """Build the channel list for /api/status — mirrors server.py logic."""
        from praestoclaw.utils.helpers import webchat_url_from_connect

        channels: list[dict[str, Any]] = []
        for name in rt.channel_manager._channels:
            if name == ChannelType.CLOUD:
                continue
            if name in (ChannelType.WEB, "gateway"):
                channels.append({"name": name, "url": "/chat", "connected": True})
            else:
                channels.append({"name": name, "url": None, "connected": True})

        cloud_cfg = rt.config.channels.cloud
        if cloud_cfg.enabled and cloud_cfg.url:
            try:
                wc_url: str | None = webchat_url_from_connect(cloud_cfg.url)
            except ValueError:
                wc_url = None
            channels.append(
                {"name": "Web Chat (Cloud)", "url": wc_url, "connected": self._ws_connected}
            )
            teams_url = cloud_cfg.teams_bot_url or None
            channels.append(
                {
                    "name": "Teams (Cloud)",
                    "url": teams_url,
                    "connected": self._ws_connected and bool(teams_url),
                }
            )
        return channels

    async def _handle_admin_endpoint(
        self, endpoint: str, frame: dict[str, Any]
    ) -> dict[str, Any] | None:
        """Dispatch an admin request to the Runtime via shared handlers.

        Returns {"status": int, "body": dict|str} or None if not found.
        """
        rt = self._runtime
        if rt is None:
            return {"status": 503, "body": {"error": "runtime_unavailable"}}

        from praestoclaw.web.api_handlers import (
            handle_approval_resolve,
            handle_approvals,
            handle_audit,
            handle_config,
            handle_cost,
            handle_estop,
            handle_health,
            handle_memory,
            handle_models,
            handle_reset,
            handle_session_detail,
            handle_sessions,
            handle_skills,
            handle_status,
            handle_tools,
        )

        method = frame.get("method", "GET")

        # ── GET ───────────────────────────────────────────────────────
        if method == "GET":
            routes: dict[str, Any] = {
                "/api/status": lambda: handle_status(rt, channels=self._build_channels(rt)),
                "/api/health": lambda: handle_health(rt),
                "/api/sessions": lambda: handle_sessions(rt),
                "/api/tools": lambda: handle_tools(rt),
                "/api/skills": lambda: handle_skills(rt),
                "/api/memory": lambda: handle_memory(rt),
                "/api/audit": lambda: handle_audit(rt),
                "/api/cost": lambda: handle_cost(rt),
                "/api/models": lambda: handle_models(rt),
                "/api/approvals": lambda: handle_approvals(rt),
            }
            if endpoint in routes:
                return {"status": 200, "body": routes[endpoint]()}

            if endpoint.startswith("/api/sessions/"):
                from urllib.parse import unquote

                session_id = unquote(endpoint[len("/api/sessions/") :])
                detail = handle_session_detail(rt, session_id)
                return (
                    {"status": 200, "body": detail}
                    if detail
                    else {"status": 404, "body": {"error": "not_found"}}
                )

            if endpoint == "/api/config":
                result = handle_config(rt)
                return (
                    {"status": 200, "body": result}
                    if result
                    else {"status": 500, "body": {"error": "Failed to serialize config."}}
                )

        # ── POST ──────────────────────────────────────────────────────
        if method == "POST":
            body_str = frame.get("body")
            body_data: dict[str, Any] = {}
            if body_str:
                try:
                    body_data = json.loads(body_str)
                except (json.JSONDecodeError, TypeError):
                    pass

            if endpoint == "/api/estop":
                return {
                    "status": 200,
                    "body": handle_estop(rt, body_data.get("reason", "admin dashboard")),
                }
            if endpoint == "/api/reset":
                return {"status": 200, "body": handle_reset(rt, body_data.get("actor", "admin"))}
            if endpoint.startswith("/api/approvals/") and endpoint.endswith("/resolve"):
                req_id = endpoint.split("/")[3] if len(endpoint.split("/")) >= 5 else ""
                code, body = handle_approval_resolve(
                    rt, req_id, body_data.get("approved", False), body_data.get("resolver", "admin")
                )
                return {"status": code, "body": body}

        return None

    # ── Auth ─────────────────────────────────────────────────────────────────

    def _acquire_token_sync(self) -> str:
        """Acquire token via the configured :class:`AuthProvider`.

        Flow: bypass → ``provider.try_silent`` → if interactive supported,
        show the menu (lets the user re-pick a provider for this session)
        → ``chosen.interactive_login``. Providers without interactive
        support (``azure_cli``) raise instead of hanging.
        """
        if self._bypass_token:
            logger.debug("Using bypass token (local dev mode)")
            return self._bypass_token

        provider = self._auth
        if provider is None:
            raise RuntimeError(
                "Cloud channel constructed without an auth provider. "
                "Use auth.factory.build_auth_provider(cloud_cfg, channel=ch)."
            )

        token = provider.try_silent()
        if token:
            return str(token)

        if not provider.supports_interactive:
            raise RuntimeError(
                f"{provider.name} silent acquisition failed and provider does not"
                " support in-process interactive login. Re-establish the session"
                " manually (e.g. `az login` for azure_cli) and retry."
            )

        from praestoclaw.auth.factory import all_providers
        from praestoclaw.auth.menu import show_login_menu

        cloud_cfg_shim = type(
            "_Shim",
            (),
            {
                "auth_provider": provider.name,
                "tenant_id": self._tenant_id,
                "azure_cli": type(
                    "_Az",
                    (),
                    {"resource": "https://management.azure.com", "tenant_id": None},
                )(),
            },
        )()
        available = all_providers(cloud_cfg_shim, channel=self)
        chosen = show_login_menu(available, default=provider)
        if chosen is None:
            raise RuntimeError("Cloud sign-in skipped")
        result = chosen.interactive_login()
        return result.token

    def _try_silent_one(
        self,
        client_id: str,
        authority: str,
        broker_kwargs: dict[str, Any],
        cache_path: Path,
        scopes: list[str],
    ) -> str | None:
        """Try silent acquisition from one specific cache file."""
        token_cache = msal.SerializableTokenCache()
        if cache_path.exists():
            try:
                from praestoclaw.security.secrets import decrypt_at_rest

                raw = decrypt_at_rest(cache_path.read_bytes())
                if raw:
                    token_cache.deserialize(raw.decode("utf-8"))
            except Exception:
                return None

        app = msal.PublicClientApplication(
            client_id,
            authority=authority,
            token_cache=token_cache,
            **broker_kwargs,
        )
        accounts = app.get_accounts()
        if not accounts:
            return None

        # Broker: force_refresh to get id_token via PRT (AT cache hit
        # only returns access_token for Graph, no id_token).
        result = app.acquire_token_silent(
            scopes, account=accounts[0], force_refresh=bool(broker_kwargs)
        )
        if not result or ("access_token" not in result and "id_token" not in result):
            return None

        # Persist refreshed cache to disk.
        from praestoclaw.utils.auth import _persist_cache

        _persist_cache(token_cache, cache_path)

        logger.debug(
            "Token acquired silently (client={}, broker={})",
            client_id[:8],
            bool(broker_kwargs),
        )
        self._capture_identity(result)
        # Broker with openid scope returns access_token for Graph (wrong aud).
        # Use id_token for broker, access_token for browser.
        if broker_kwargs:
            return str(result.get("id_token") or result.get("access_token", ""))
        return self._pick_token(result)

    def _execute_login_choice(self) -> str:
        """Deprecated — kept temporarily for any callers we missed.

        New code should rely on ``_acquire_token_sync``, which uses
        :class:`AuthProvider`. This forwards to the same path.
        """
        return self._acquire_token_sync()

    def _try_shared_or_apikey(self) -> str:
        """Prompt for API key (local LLM), then try shared app for cloud."""
        # Primary app is unusable — ask for API key so local CLI works
        # regardless of whether cloud login succeeds.
        self._prompt_api_key()
        self._switch_to_shared_app()
        try:
            token = self._interactive_login()
            self._persist_cache()
            return token
        except Exception:
            raise RuntimeError("Cloud sign-in skipped")

    async def _build_auth_headers(self) -> dict[str, str]:
        """Return Authorization headers for the next transport connect attempt.

        Called by :class:`GatewayTransportClient` before each WS upgrade so
        that token refresh happens transparently across reconnects. Best
        effort: if silent refresh is exhausted, the existing (possibly
        expired) token is reused — the gateway will close ``1008`` and the
        transport's bounded-retry policy decides when to give up.
        """
        with contextlib.suppress(_SilentRefreshExhaustedError, Exception):
            await self._refresh_for_reconnect()
        return {"Authorization": f"Bearer {self._token}"}

    async def _refresh_for_reconnect(self) -> None:
        """Refresh the cloud token during reconnect — **silent only**.

        After the initial startup login, the user is no longer at the prompt
        and cannot answer interactive dialogs. This path must never call
        :meth:`_execute_login_choice` (which blocks on stdin / arrow-key
        menus); long-running ``serve`` would otherwise freeze the moment
        Entra returns ``interaction_required``.

        Behaviour:
          * Bypass-token mode → keep ``self._token`` unchanged.
          * Silent succeeds (broker PRT or browser refresh_token) → update
            ``self._token``.
          * Silent exhausted → leave ``self._token`` untouched and return.
            The caller decides whether to back off or raise
            :class:`_SilentRefreshExhaustedError` to skip a doomed
            handshake. The user recovers by running ``praestoclaw cloud``.
        """
        if self._bypass_token:
            return

        if self._auth is None:
            logger.error("Silent cloud token refresh: no auth provider wired")
            raise _SilentRefreshExhaustedError("auth provider missing")

        token = await asyncio.get_running_loop().run_in_executor(None, self._auth.try_silent)
        if token:
            self._token = token
            self._capture_identity_from_token(token)
            return

        logger.error(
            "Silent cloud token refresh exhausted (broker + browser caches). "
            "Run `praestoclaw cloud` to re-authenticate; reconnect loop will "
            "keep retrying with the existing token in the meantime."
        )

    # ── Shared Entra ID fallback ────────────────────────────────────────────

    @staticmethod
    def _pick_token(result: dict) -> str:
        """Return the best token from an MSAL result.

        Prefer access_token (aud=resource app, typ=at+jwt) so that shared-app
        fallback tokens have the primary app audience.  Fall back to id_token
        (aud=client_id, typ=JWT) when no access_token is available.
        The Gateway accepts both typ=at+jwt and typ=JWT.
        """
        return str(result.get("access_token") or result["id_token"])

    @staticmethod
    def _is_consent_error(exc: Exception) -> bool:
        """True if the exception text contains a known consent error code."""
        msg = str(exc)
        return any(code in msg for code in _CONSENT_ERROR_CODES)

    @staticmethod
    def _is_timeout_error(exc: Exception) -> bool:
        """True if the MSAL interactive login timed out."""
        # MSAL raises BrowserInteractionTimeoutError with message
        # "User did not complete the flow in time".
        cls = type(exc).__name__
        if "Timeout" in cls:
            return True
        msg = str(exc).lower()
        return "timed out" in msg or "timeout" in msg or "not complete the flow in time" in msg

    @staticmethod
    def _prompt_api_key() -> None:
        """Prompt for a Web API key, confirm, and save to secret store + config.

        Skips if ``WEB_API_KEY`` is already configured.
        """
        import sys

        from praestoclaw.security.secrets import get_secret, set_secret

        if get_secret("WEB_API_KEY"):
            logger.debug("WEB_API_KEY already configured — skipping prompt")
            return
        if not sys.stdin.isatty():
            logger.debug("Non-interactive — skipping API key prompt")
            return
        _console.print(
            Panel(
                "[bold]Configure a Web API key[/bold] for the local web interface.\n"
                "Press [bold]Enter[/bold] to skip.",
                title="API Key",
                border_style="blue",
            )
        )
        try:
            from rich.prompt import Prompt

            key = Prompt.ask("  API Key", password=True, default="", show_default=False).strip()
            if not key:
                _console.print("  [dim]Skipped.[/dim]")
                return
            _console.print(f"  [dim]({len(key)} characters)[/dim]")
            confirm = Prompt.ask(
                "  Confirm API Key", password=True, default="", show_default=False
            ).strip()
            if key != confirm:
                _console.print("  [red]Keys do not match \u2014 skipped.[/red]")
                return
        except (EOFError, KeyboardInterrupt):
            _console.print("  [dim]Skipped.[/dim]")
            return
        set_secret("WEB_API_KEY", key)

        # Write SECRET[WEB_API_KEY] reference into praestoclaw.local.yaml so the
        # config loader resolves it at startup (same pattern as GITHUB_COPILOT_TOKEN).
        try:
            from praestoclaw.config.loader import set_local_config_value

            set_local_config_value("channels.web.api_key", "SECRET[WEB_API_KEY]")
        except Exception as exc:
            logger.warning("Failed to write api_key to local config: {}", exc)

        _console.print("  [green]\u2713[/green] Web API key saved.")

    def _switch_to_shared_app(self, *, enable_broker: bool = False) -> None:
        """Replace the MSAL app and scope with the shared Entra client ID.

        After this call, all existing auth paths (_acquire_token_sync,
        _interactive_login, _browser_flow, _device_code_flow) work
        unchanged — they just use the new client_id and scope.
        The Cloud Gateway must list the shared client ID in
        ``AzureAd:LegacyAudiences`` to accept these tokens.

        When *enable_broker* is True, WAM broker is enabled on the shared
        app so that ``_browser_flow(try_wam=True)`` works with it.
        """
        logger.warning(
            "Switching to shared Entra app ({}) — primary app requires admin consent",
            SHARED_ENTRA_CLIENT_ID[:8],
        )
        self._scope = f"{SHARED_ENTRA_CLIENT_ID}/.default"
        self._cache_path = get_auth_dir() / f"token_cache_{SHARED_ENTRA_CLIENT_ID[:8]}.bin"
        self._token_cache = msal.SerializableTokenCache()
        if self._cache_path.exists():
            try:
                from praestoclaw.security.secrets import decrypt_at_rest

                raw = decrypt_at_rest(self._cache_path.read_bytes())
                if raw:
                    self._token_cache.deserialize(raw.decode("utf-8"))
            except Exception as exc:
                logger.warning("Failed to load shared-app token cache: {}", exc)
        broker_kwargs: dict[str, Any] = {}
        if enable_broker:
            from praestoclaw.utils.auth import _broker_kwargs

            broker_kwargs = _broker_kwargs()
            self._broker_enabled = bool(broker_kwargs)
            if not broker_kwargs:
                logger.warning("msal[broker] not installed; broker disabled on shared app")
        else:
            self._broker_enabled = False
        self._msal_app = msal.PublicClientApplication(
            SHARED_ENTRA_CLIENT_ID,
            authority="https://login.microsoftonline.com/organizations",
            token_cache=self._token_cache,
            **broker_kwargs,
        )
        self._using_shared_app = True

    def _interactive_login(self, timeout: int = 300) -> str:
        """Dispatch to the configured login method.

        "auto" / "browser" — browser PKCE only (default, always works).
        "wam"              — WAM broker → browser PKCE fallback (opt-in).
        "device"           — device code only (opt-in, many tenants disable it).
        """
        if self._login_method == "device":
            return self._device_code_flow(timeout=timeout)
        if self._login_method == "wam":
            return self._browser_flow(try_wam=self._broker_enabled, timeout=timeout)
        # "auto" and "browser": browser PKCE only
        return self._browser_flow(try_wam=False, timeout=timeout)

    def _resolve_login_port(self) -> int:
        """Return a usable localhost port for the PKCE callback.

        Tries self._login_port first (the preferred/gateway port).
        If that port is already bound, asks the OS for any free port.
        """
        preferred = self._login_port
        for port in (preferred, 52813, 58729, 0):  # fixed high ports for AAD, then OS-assigned
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                try:
                    s.bind(("localhost", port))
                    chosen = s.getsockname()[1]
                    if port != preferred:
                        logger.debug(
                            "Login port {} busy — using {} instead",
                            preferred,
                            chosen,
                        )
                    return int(chosen)
                except OSError:
                    continue
        # Should never reach here — port 0 always succeeds
        return preferred  # pragma: no cover

    @staticmethod
    def _wait_with_countdown(done: Any, timeout: int) -> bool:
        """Show a fallback countdown, listening for ESC to skip.

        Returns True if the user pressed ESC (skip), False if *done* was set
        (MSAL completed) or the countdown expired naturally.
        """

        from praestoclaw.utils.input import is_tty, read_key_nonblocking

        remaining = timeout
        while remaining > 0 and not done.is_set():
            _console.print(
                f"  Fallback in [yellow]{remaining}s[/yellow] [dim](ESC to skip)[/dim]\u2026",
                end="\r",
            )
            if is_tty():
                try:
                    key = read_key_nonblocking()
                    if key == "esc":
                        _console.print(" " * 60, end="\r")
                        return True
                except KeyboardInterrupt:
                    _console.print(" " * 60, end="\r")
                    raise
            if done.wait(1):
                break
            remaining -= 1
        _console.print(" " * 60, end="\r")
        return False

    def _browser_flow(self, *, try_wam: bool = False, timeout: int = 300) -> str:
        """Interactive browser-based auth (authorization code + PKCE).

        MSAL opens the default browser and starts a local HTTP server on
        login_port (default 49216 — high port to avoid conflicts) for the
        callback. The registered redirect URI is http://localhost which
        AAD matches against any http://localhost:{PORT} loopback address.
        """
        port = self._resolve_login_port()
        _console.print(
            Panel(
                "[bold]Opening browser for sign-in\u2026[/bold]\n\n"
                f"Callback : [cyan]http://localhost:{port}[/cyan]\n"
                f"Fallback : [dim]alternative sign-in offered after {timeout}s[/dim]\n"
                "Press [bold]Ctrl+C[/bold] to cancel.",
                title="Sign In",
                border_style="yellow",
            )
        )

        assert self._msal_app is not None

        # After the OAuth callback, redirect to the web chat — but only
        # for the primary app.  The shared-app fallback path should NOT
        # redirect because the user's primary app couldn't authenticate
        # and the web chat may not work with the fallback token.
        if self._using_shared_app:
            success_template = (
                "<!DOCTYPE html><html><head><title>PraestoClaw</title></head>"
                "<body>Sign-in successful — you can close this tab.</body></html>"
            )
        else:
            web_url = webchat_url_from_connect(self._url)
            safe_url = _html.escape(web_url, quote=True)
            success_template = (
                "<!DOCTYPE html><html><head><title>PraestoClaw</title>"
                f'<meta http-equiv="refresh" content="0;url={safe_url}"></head>'
                f'<body>Sign-in successful — <a href="{safe_url}">opening PraestoClaw</a>…'
                "</body></html>"
            )

        wam_kwargs: dict[str, Any] = {}
        if try_wam:
            from praestoclaw.utils.auth import _get_foreground_window_handle

            wam_kwargs["parent_window_handle"] = _get_foreground_window_handle(self._msal_app)

        import threading

        msal_result: dict[str, Any] = {}
        msal_error: BaseException | None = None
        done_event = threading.Event()

        msal_app = self._msal_app

        # WAM: empty scopes → broker uses OIDC defaults, returns id_token.
        # Browser: needs app scope so access_token audience matches.
        interactive_scopes = [] if try_wam else self._scopes

        def _msal_call() -> None:
            nonlocal msal_result, msal_error
            try:
                msal_result = msal_app.acquire_token_interactive(
                    scopes=interactive_scopes,
                    prompt="select_account",
                    port=port,
                    timeout=timeout,
                    success_template=success_template,
                    **wam_kwargs,
                )
            except BaseException as exc:
                msal_error = exc
            finally:
                done_event.set()

        msal_thread = threading.Thread(target=_msal_call, daemon=True)
        msal_thread.start()

        # Wait with countdown + ESC detection. ESC skips to fallback.
        skipped = self._wait_with_countdown(done_event, timeout)
        if skipped:
            # User pressed ESC — simulate timeout so caller triggers fallback
            raise TimeoutError("Sign-in skipped by user (ESC)")

        msal_thread.join(timeout=2)
        if msal_error is not None:
            raise msal_error
        result = msal_result

        # WAM broker failed — unconditionally retry with plain browser.
        # Common WAM errors: broker_error (redirect URI missing), admin consent
        # required (AADSTS65001), public client blocked (AADSTS7000218), etc.
        if try_wam and "error" in result:
            err = result.get("error", "")
            err_desc = result.get("error_description", "")
            logger.info("WAM broker failed ({}); falling back to browser PKCE", err)
            logger.debug("WAM error detail: {}", err_desc[:300])
            # Not passing parent_window_handle → MSAL uses browser PKCE.
            result = self._msal_app.acquire_token_interactive(
                scopes=self._scopes,
                prompt="select_account",
                port=port,
                timeout=timeout,
                success_template=success_template,
            )

        if "error" in result:
            raise RuntimeError(
                f"Browser login failed: {result.get('error_description', result['error'])}"
            )

        self._log_authenticated(result)
        self._capture_identity(result)
        self._save_identity(result)
        return self._pick_token(result)

    def _device_code_flow(self, timeout: int = 300) -> str:
        """Device code flow — visit a URL and enter a short code.

        Works in headless / SSH / corporate environments where browser
        pop-ups are blocked.  *timeout* is accepted for API consistency
        but device code flow uses its own server-side expiry.
        """
        assert self._msal_app is not None
        flow = self._msal_app.initiate_device_flow(scopes=self._scopes)
        if "error" in flow:
            raise RuntimeError(
                f"Device code flow failed to start: {flow.get('error_description', flow['error'])}"
            )

        _console.print(
            Panel(
                f"[bold]Sign in required[/bold]\n\n{flow['message']}",
                title="Device Code",
                border_style="yellow",
            )
        )

        result = self._msal_app.acquire_token_by_device_flow(flow)
        if "error" in result:
            raise RuntimeError(
                f"Device code flow failed: {result.get('error_description', result['error'])}"
            )

        self._log_authenticated(result)
        self._capture_identity(result)
        self._save_identity(result)
        return self._pick_token(result)

    def _persist_cache(self) -> None:
        """Write MSAL token cache to disk if it changed.

        Uses an atomic rename and mode 0o600 on POSIX. On Windows the parent
        auth/ directory is ACL-restricted via icacls (best-effort; see ensure_private_dir).
        """
        if self._cache_path is None or not self._token_cache.has_state_changed:
            return
        try:
            tmp = self._cache_path.with_suffix(".tmp")
            from praestoclaw.security.secrets import encrypt_at_rest, is_encrypted

            plaintext = self._token_cache.serialize().encode("utf-8")
            data = encrypt_at_rest(plaintext)
            # Avoid overwriting an encrypted cache with plaintext
            if data == plaintext and self._cache_path.exists():
                if is_encrypted(self._cache_path.read_bytes()):
                    logger.warning(
                        "MSAL cache not written: encryption key unavailable "
                        "and existing cache is encrypted"
                    )
                    return
            tmp.write_bytes(data)
            try:
                tmp.chmod(0o600)
            except (NotImplementedError, OSError):
                pass  # Windows/some filesystems: parent ACL governs access
            tmp.replace(self._cache_path)
            logger.debug("MSAL token cache saved to {}", self._cache_path)
        except Exception as exc:
            logger.warning("Failed to save MSAL token cache: {}", exc)

    @staticmethod
    def _log_authenticated(result: dict) -> None:
        claims = result.get("id_token_claims", {})
        name = claims.get("name") or claims.get("preferred_username", "unknown")
        oid = claims.get("oid", "unknown")
        _console.print(
            f"  [green]\u2713[/green] Authenticated as [bold]{name}[/bold] [dim](oid={oid})[/dim]"
        )
        logger.success("Authenticated as: {} (oid={})", name, oid)

    def _capture_identity(self, result: dict) -> None:
        """Extract oid/tid from an MSAL token result.

        Called on every acquisition path (silent, browser, device code).
        MSAL omits ``id_token_claims`` on pure cache hits, so when claims
        are missing we fall back to decoding the id_token JWT payload.
        Without this fallback, user_id degrades to ``anon-<instance>``
        on every silent refresh, which makes the gateway treat the
        session as anonymous.
        """
        claims = result.get("id_token_claims") or {}
        if not claims:
            id_token = result.get("id_token")
            if id_token:
                claims = _decode_jwt_payload(id_token)
        if claims.get("oid"):
            self._local_oid = claims["oid"]
        if claims.get("tid"):
            self._local_tid = claims["tid"]
        upn = claims.get("preferred_username") or claims.get("upn") or claims.get("unique_name")
        if upn:
            self._local_upn = str(upn)
        self._last_claims = claims

    def _capture_identity_from_token(self, token: str | None) -> None:
        """Best-effort identity capture for auth providers that return only a token."""

        if not token:
            return
        claims = _decode_jwt_payload(token)
        if claims:
            self._capture_identity({"id_token_claims": claims})

    def _warn_if_tenant_mismatch(self) -> None:
        """Log a loud warning when the silent token belongs to a different tenant.

        This catches the common foot-gun where ``auth_provider=azure_cli`` (the
        default) reuses an ``az login`` session for a personal MSA / different
        work tenant. The WebSocket still connects (gateway only checks ``oid``),
        but Teams messages — bound to the configured tenant — never route to
        this agent. The user just sees "offline" in Teams forever.

        Additive only: never raises, never blocks startup. The user decides
        whether to switch ``channels.cloud.auth_provider`` to ``browser``.
        """
        cfg_tid = (self._tenant_id or "").strip().lower()
        token_tid = (self._local_tid or "").strip().lower()
        if not cfg_tid or not token_tid or cfg_tid == token_tid:
            return
        provider = getattr(self._auth, "name", "?") if self._auth else "?"
        logger.warning(
            "Cloud token tenant mismatch: token tid={} (upn={}), config tenant_id={}. "
            "Agent will appear OFFLINE in Teams because Teams messages route by "
            "the configured tenant. Fix: set `channels.cloud.auth_provider: browser` "
            "in praestoclaw.local.yaml and re-run `pc cloud --login browser` to "
            "sign in with the correct work account. (current provider: {})",
            token_tid,
            self._local_upn or "?",
            cfg_tid,
            provider,
        )

    def _last_msal_claims(self) -> dict[str, Any]:
        """Return claims from the most recent ``_capture_identity`` call.

        Used by auth providers that delegate MSAL plumbing to this channel —
        they need claims for ``AuthResult.claims`` but cannot read MSAL's
        result dict directly.
        """
        return getattr(self, "_last_claims", {}) or {}

    def _save_identity(self, result: dict) -> None:
        """Persist Entra ID claims to ~/.praestoclaw/USER.md."""
        if self._runtime is None:
            return
        from praestoclaw.utils.identity import save_identity

        save_identity(
            result.get("id_token_claims", {}),
            self._runtime.workspace,
            user_file=self._runtime.config.agents.default.user_file,
        )
