"""AgentLoopV2 — Hermes-style run_conversation agent loop.

Replaces the nanobot-derived v1 loop with Hermes-style iteration budget,
multi-pass compression, intelligent parallel tool execution, and
provider failover — while preserving v1's hooks, approval routing,
slash commands, typing indicators, and audit logging.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
from collections import deque
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

from praestoclaw.agent.attachments.preprocessor import AttachmentResolver as _AttachmentResolver
from praestoclaw.agent.attachments.preprocessor import (
    has_pending_attachments as _has_pending_attachments,
)
from praestoclaw.agent.budget import IterationBudget
from praestoclaw.agent.compaction import estimate_tokens
from praestoclaw.agent.compressor import ContextCompressor
from praestoclaw.agent.loop_detect import LoopDetector
from praestoclaw.agent.parallel import ToolParallelizer
from praestoclaw.agent.prompt_builder import PromptBuilder
from praestoclaw.agent.prompt_cache import apply_cache_breakpoints
from praestoclaw.agent.tool_sanitizer import sanitize_tool_messages
from praestoclaw.agent.truncation import truncate_tool_output
from praestoclaw.bus.events import EventType, InboundMessage, OutboundMessage, StreamingChunk
from praestoclaw.bus.queue import MessageBus
from praestoclaw.config.schema import AgentConfig, ChannelType
from praestoclaw.hooks.manager import (
    HookVerdict,
    MessageHookContext,
    PostToolHookContext,
    PreToolHookContext,
)
from praestoclaw.providers.base import LLMProvider, LLMResponse, ToolCallRequest
from praestoclaw.providers.failover import CompressNeededError
from praestoclaw.security.leak import redact_credentials
from praestoclaw.security.sanitizer import Sanitizer

if TYPE_CHECKING:
    from praestoclaw.security.allowlist import AllowlistManager
    from praestoclaw.security.approval import ApprovalManager
    from praestoclaw.security.audit import AuditLogger

_DEFAULT_CONTEXT_LIMIT = 128_000
_EMPTY_FINAL_RESPONSE_PROMPT = (
    "Your previous response contained no user-visible content. Do not end the turn "
    "silently. Continue the task if work remains; otherwise provide a concise final "
    "status for the user."
)
_EMPTY_FINAL_RESPONSE_FALLBACK = (
    "I couldn't produce a final response before this turn ended. The task may be "
    "incomplete; please ask me to continue if you want me to keep working."
)


class AgentLoopV2:
    """Hermes-style agent loop with streaming, parallel tools, and loop detection.

    Supports all v1 capabilities: hooks, approval routing, slash commands,
    typing indicators, audit logging.
    """

    def __init__(
        self,
        *,
        config: AgentConfig,
        provider: LLMProvider,
        tool_registry: Any,
        bus: MessageBus,
        session_store: Any,
        workspace: Path,
        audit: Any = None,
        hooks: Any = None,
        available_agents: dict[str, Any] | None = None,
        prompt_mode: str = "full",
        skill_loader: Any = None,
        skills_config: Any = None,
        approval_manager: ApprovalManager | None = None,
        allowlist: AllowlistManager | None = None,
        mcp_configs: Any = None,
        memory: Any = None,
    ) -> None:
        self._config = config
        self._provider = provider
        self._tool_registry = tool_registry
        self._bus = bus
        self._session_store = session_store
        self._workspace = workspace
        self._audit: AuditLogger | None = audit
        self._hooks = hooks
        self._available_agents = available_agents or {}
        self._prompt_mode = prompt_mode
        self._skill_loader = skill_loader
        self._skills_config = skills_config
        self._approval_manager = approval_manager
        self._allowlist = allowlist
        self._mcp_configs = mcp_configs
        self._memory = memory
        self._interrupt = False
        self._turn_active = False
        self._running = False
        self._current_turn_task: asyncio.Task[None] | None = None
        self._current_turn_msg: InboundMessage | None = None

        # Sub-components
        self._prompt_builder = PromptBuilder(
            config,
            workspace,
            tool_registry=tool_registry,
            available_agents=self._available_agents,
            mcp_configs=mcp_configs,
            memory=memory,
            skill_loader=skill_loader,
            skills_config=skills_config,
        )
        # Learning loop counters (Hermes-style)
        self._turns_since_memory = 0
        self._memory_nudge_interval = config.memory_nudge_interval or 10
        self._compressor = ContextCompressor(
            provider,
            protect_first_n=config.compaction_v2.protect_first_n,
            protect_last_n=config.compaction_v2.protect_last_n,
            post_threshold=config.compaction_v2.post_threshold,
            pre_threshold=config.compaction_v2.pre_threshold,
            anti_thrashing_min_savings=config.compaction_v2.anti_thrashing_min_savings,
        )
        self._parallelizer = ToolParallelizer()

    # ── Public API ───────────────────────────────────────────────────────

    async def start(self) -> None:
        """Consume inbound messages from the bus."""
        self._running = True
        logger.info("AgentLoopV2 started: {}", self._config.name)
        backlog: deque[InboundMessage] = deque()
        inbound_task: asyncio.Task[InboundMessage] | None = None

        def ensure_inbound_task() -> asyncio.Task[InboundMessage]:
            nonlocal inbound_task
            if inbound_task is None or inbound_task.done():
                inbound_task = asyncio.create_task(
                    self._bus.get_inbound(), name="agent-loop-inbound"
                )
            return inbound_task

        try:
            while self._running:
                if self._current_turn_task is None and backlog:
                    self._start_turn(backlog.popleft())
                    continue

                current_task = self._current_turn_task
                wait_for: set[asyncio.Task[Any]] = {ensure_inbound_task()}
                if current_task is not None:
                    wait_for.add(current_task)
                try:
                    done, _ = await asyncio.wait(
                        wait_for,
                        timeout=1.0,
                        return_when=asyncio.FIRST_COMPLETED,
                    )
                except asyncio.CancelledError:
                    break
                if not done:
                    continue

                if current_task is not None and current_task in done:
                    await self._finish_current_turn(current_task)

                if inbound_task is not None and inbound_task in done:
                    try:
                        msg = inbound_task.result()
                    except asyncio.CancelledError:
                        break
                    inbound_task = None
                    active = self._current_turn_task is not None
                    if await self._maybe_handle_interrupt_command(msg, active=active):
                        self._cancel_current_turn("user interrupt command")
                    elif active:
                        self._cancel_current_turn("preempted by newer inbound message")
                        backlog.appendleft(msg)
                    else:
                        self._start_turn(msg)
        finally:
            if inbound_task and not inbound_task.done():
                inbound_task.cancel()
            if self._current_turn_task and not self._current_turn_task.done():
                self._cancel_current_turn("agent loop stopping")
                with contextlib.suppress(asyncio.CancelledError):
                    await self._current_turn_task

    async def stop(self) -> None:
        """Signal the loop to stop."""
        self._running = False
        self._interrupt = True
        self._cancel_current_turn("agent loop stopping")

    def interrupt(self) -> None:
        """Interrupt the in-flight turn without stopping the loop.

        Cooperative: the running ``_run_conversation`` checks the
        ``_interrupt`` flag at the top of each iteration and returns
        ``"(interrupted)"`` instead of continuing. Used by the cloud
        carrier when the sender cancels an ``a2a.message.send`` request
        (see ``CloudProtocolChannel._handle_conversation_request``) so
        the executor stops generating after the current LLM step instead
        of running to completion and pushing the unwanted reply.

        No-op when no turn is currently running so a late cancel cannot
        leak across turn boundaries and abort the next inbound request
        before it has a chance to do any work.
        """
        if not self._turn_active:
            return
        self._interrupt = True

    def _start_turn(self, msg: InboundMessage) -> None:
        self._current_turn_msg = msg
        self._current_turn_task = asyncio.create_task(
            self._run_message_task(msg),
            name=f"agent-turn:{msg.delivery_route_id or 'unknown'}",
        )

    def _cancel_current_turn(self, reason: str) -> None:
        task = self._current_turn_task
        if task is None or task.done():
            return
        self._interrupt = True
        logger.info("Agent turn interrupt requested: reason={}", reason)
        task.cancel()

    async def _finish_current_turn(self, task: asyncio.Task[None]) -> None:
        try:
            await task
        except asyncio.CancelledError:
            logger.info("Agent turn cancelled")
        except Exception as exc:  # noqa: BLE001 — keep loop alive
            logger.error("Agent loop error: {}", exc)
        finally:
            if self._current_turn_task is task:
                self._current_turn_task = None
                self._current_turn_msg = None

    async def _run_message_task(self, msg: InboundMessage) -> None:
        try:
            await self._process_message(msg)
        except asyncio.CancelledError:
            await self._publish_interrupted(msg)
            raise
        except Exception as exc:  # noqa: BLE001 — keep loop alive
            logger.error("Agent loop error: {}", exc)

    @staticmethod
    def _is_interrupt_command(content: str, *, active: bool) -> bool:
        text = content.strip().lower()
        slash_commands = {"/stop", "/cancel", "/interrupt"}
        if text in slash_commands:
            return True
        if not active:
            return False
        return text in {"stop", "cancel", "interrupt", "停止", "取消", "打断", "停一下", "先停"}

    async def _maybe_handle_interrupt_command(self, msg: InboundMessage, *, active: bool) -> bool:
        if not self._is_interrupt_command(msg.content, active=active):
            return False
        channel = ChannelType.of(msg.logical_channel)
        content = "已打断当前任务。" if active else "当前没有正在执行的任务。"
        await self._bus.publish_outbound(
            OutboundMessage(
                channel=channel,
                channel_id=msg.delivery_route_id,
                content=content,
                thread_id=msg.conversation_id or msg.delivery_route_id,
                route_hint=msg.route_hint,
            )
        )
        return True

    async def _publish_interrupted(self, msg: InboundMessage) -> None:
        channel = ChannelType.of(msg.logical_channel)
        await self._bus.publish_outbound(
            OutboundMessage(
                channel=channel,
                channel_id=msg.delivery_route_id,
                content="(interrupted)",
                thread_id=msg.conversation_id or msg.delivery_route_id,
                route_hint=msg.route_hint,
            )
        )

    async def run_once(
        self,
        prompt: str,
        session_id: str | None = None,
        *,
        channel: Any = None,
        channel_id: Any = None,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        exclude_tools: list[str] | None = None,
    ) -> str:
        """Run a single turn: prompt → response."""
        sid = session_id or await self._session_store.get_or_create_session(
            str(channel or "cli"),
            channel_id or "run_once",
        )
        history = await self._session_store.get_messages(sid)
        response_text, _ = await self._run_conversation(
            prompt,
            history,
            sid,
            channel=channel,
            channel_id=channel_id,
            thread_id=thread_id,
            metadata=metadata,
            exclude_tools=exclude_tools,
        )
        return response_text

    # ── Typing indicators ───────────────────────────────────────────────

    def _start_typing(
        self,
        channel: Any,
        channel_id: str | None,
        metadata: dict[str, Any] | None = None,
    ) -> asyncio.Task[None] | None:
        """Start a periodic typing indicator task. Returns the task (or None for CLI)."""
        if not channel or not channel_id or channel == ChannelType.CLI:
            return None

        payload = {"channel": channel, "channel_id": channel_id, "metadata": metadata or {}}
        self._bus.events.emit(EventType.TYPING_STARTED, payload)

        async def _typing_loop() -> None:
            try:
                while True:
                    await asyncio.sleep(3.0)
                    self._bus.events.emit(EventType.TYPING_STARTED, payload)
            except asyncio.CancelledError:
                pass

        return asyncio.create_task(_typing_loop(), name="typing-indicator")

    def _stop_typing(
        self,
        task: asyncio.Task[None] | None,
        channel: Any = None,
        channel_id: str | None = None,
    ) -> None:
        """Cancel the typing indicator task and emit TYPING_STOPPED."""
        if task and not task.done():
            task.cancel()
        if channel and channel_id and channel != ChannelType.CLI:
            self._bus.events.emit(
                EventType.TYPING_STOPPED,
                {"channel": channel, "channel_id": channel_id},
            )

    # ── Slash commands ──────────────────────────────────────────────────

    async def _handle_slash(self, cmd: str, session_id: str, msg: InboundMessage) -> str | None:
        """Handle REPL slash commands. Returns reply string or None if not known."""
        parts = cmd.split(maxsplit=1)
        verb = parts[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ""

        if verb == "/new":
            await self._session_store.replace_messages(session_id, [])
            return "Session cleared. Starting fresh."

        if verb == "/compact":
            history = await self._session_store.get_messages(session_id)
            if len(history) < 10:
                return "Not enough messages to compact."
            result = await self._compressor.compress(history)
            await self._persist_compacted(session_id, result.messages)
            return (
                f"Compacted: {result.tokens_before}→{result.tokens_after} tokens "
                f"({result.savings_percent:.0f}% saved, method: {result.method})"
            )

        if verb == "/status":
            budget_info = f"Budget: {self._config.budget.max_iterations} max"
            model_info = f"Model: `{self._config.model}`"
            core_info = "Agent core: v2 (Hermes-style)"
            return f"{core_info}\n{model_info}\n{budget_info}"

        if verb == "/memory":
            if self._memory:
                content = self._memory.read() if hasattr(self._memory, "read") else ""
                return content if content and content.strip() else "_MEMORY.md is empty._"
            return "_No memory configured._"

        if verb == "/tools":
            schemas = self._tool_registry.get_schemas(self._config.tools or None)
            if not schemas:
                return "_No tools available._"
            lines = ["**Available tools:**"]
            for s in schemas:
                name = s.get("function", {}).get("name", "?")
                desc = s.get("function", {}).get("description", "")[:60]
                lines.append(f"- `{name}` — {desc}")
            return "\n".join(lines)

        if verb == "/model":
            if not arg:
                return f"Current model: `{self._config.model}`"
            old_model = self._config.model
            self._config.model = arg.strip()
            return f"Model switched: `{old_model}` → `{self._config.model}`"

        if verb == "/estop":
            reason = arg or "Manual E-stop via slash command"
            self._bus.events.emit(
                EventType.SECURITY_ESTOP,
                {"reason": reason, "actor": f"user:{msg.sender_id or 'unknown'}"},
            )
            return "**E-STOP ACTIVATED.** All agent activity halted."

        if verb == "/help":
            return (
                "**Available commands:**\n"
                "- `/new` — clear session\n"
                "- `/compact` — compress history\n"
                "- `/status` — show config\n"
                "- `/memory` — show MEMORY.md\n"
                "- `/tools` — list available tools\n"
                "- `/model [name]` — show/switch model\n"
                "- `/estop` — emergency stop\n"
            )

        # Unknown slash command — let it go to the agent
        return None

    # ── Approval routing ────────────────────────────────────────────────

    async def _try_route_approval(self, msg: InboundMessage) -> bool:
        """Intercept /approve, /deny, /always commands. Returns True if consumed."""
        if self._approval_manager is None:
            return False

        mgr = self._approval_manager
        content = msg.content.strip()
        content_lower = content.lower()
        action: str | None = None
        request_id: str | None = None

        # Check metadata first (Teams Adaptive Card / Cloud structured response)
        meta = msg.metadata if hasattr(msg, "metadata") and msg.metadata else {}
        if meta.get("approval_action"):
            action = meta["approval_action"]
            request_id = meta.get("approval_request_id")

        # Slash commands: /approve <id>, /deny <id>, /always <id>
        elif content.startswith("/approve "):
            action, request_id = "approve", content.split(maxsplit=1)[1].strip()
        elif content.startswith("/deny "):
            action, request_id = "deny", content.split(maxsplit=1)[1].strip()
        elif content.startswith("/always "):
            action, request_id = "always", content.split(maxsplit=1)[1].strip()

        # Simple keywords — resolve against the single pending request
        else:
            pending = mgr.get_pending()
            if len(pending) == 1:
                sole = pending[0]
                if content_lower in ("yes", "y", "approve", "/approve"):
                    action, request_id = "approve", sole.id
                elif content_lower in ("no", "n", "deny", "/deny"):
                    action, request_id = "deny", sole.id
                elif content_lower in ("always", "a", "/always"):
                    action, request_id = "always", sole.id

        if not action or not request_id:
            return False

        try:
            approved = action in ("approve", "always")
            mgr.resolve(
                request_id, approved=approved, resolver=msg.sender_id or "user", action=action
            )

            if action == "always" and self._allowlist is not None:
                resolved_req = mgr.get_request(request_id)
                if resolved_req:
                    self._allowlist.add(
                        resolved_req.tool_name,
                        resolved_req.args if hasattr(resolved_req, "args") else None,
                        added_by=msg.sender_id or "user",
                    )

            status = "approved" if approved else "denied"
            logger.info("Approval {} for request {}", status, request_id)
        except Exception as exc:
            logger.error("Approval routing error: {}", exc)

        return True

    # ── Core conversation loop ───────────────────────────────────────────

    async def _run_conversation(
        self,
        *args: Any,
        **kwargs: Any,
    ) -> tuple[str, bool]:
        """Mark the agent as actively serving a turn, then delegate to
        :meth:`_run_conversation_impl`.

        The ``_turn_active`` flag gates :meth:`interrupt` so a cancel
        that arrives after the turn already returned cannot leak into
        the next turn. ``_interrupt`` is also cleared in the finally
        block as belt-and-suspenders in case the flag was set inside a
        narrow window between ``_turn_active`` being checked and the
        impl returning.
        """
        self._turn_active = True
        try:
            return await self._run_conversation_impl(*args, **kwargs)
        finally:
            self._turn_active = False
            self._interrupt = False

    async def _run_conversation_impl(
        self,
        user_message: str,
        history: list[dict[str, Any]],
        session_id: str,
        *,
        channel: Any = None,
        channel_id: str | None = None,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        exclude_tools: list[str] | None = None,
        route_hint: str | None = None,
    ) -> tuple[str, bool]:
        """Run the agentic conversation loop. Returns (response_text, streamed)."""
        # 1. Restore primary provider if failover was active
        if hasattr(self._provider, "restore_primary"):
            self._provider.restore_primary()  # type: ignore[attr-defined]

        # 2. Create budget + fresh loop detector per conversation
        budget = IterationBudget(max_total=self._config.budget.max_iterations)
        grace_enabled = self._config.budget.grace_call
        loop_detector = LoopDetector()
        self._turns_since_memory += 1

        # 3. Build system prompt
        system_prompt = self._build_system_prompt()

        # 4. Auto-match skills for injection
        injected_skills = None
        if self._skill_loader and hasattr(self._skill_loader, "match"):
            skills_config = self._skills_config
            threshold = getattr(skills_config, "inject_threshold", 20) if skills_config else 20
            max_inject = getattr(skills_config, "max_inject", 1) if skills_config else 1
            if max_inject > 0:
                injected_skills = (
                    self._skill_loader.match(
                        user_message, threshold=threshold, max_results=max_inject
                    )
                    or None
                )

        # 5. Build enriched user message (runtime context + skills injection).
        # Surface lightweight metadata only. Image URLs remain visible for URL
        # passthrough workflows (e.g. feedback); signed file download URLs stay
        # hidden and are only resolved by attachment_process.
        attachment_block = self._build_attachment_context(metadata)
        if attachment_block:
            user_message = f"{attachment_block}\n\n{user_message}"

        enriched_content = self._prompt_builder.build_user_message(
            user_message,
            channel=channel,
            channel_id=channel_id,
            injected_skills=injected_skills,
        )
        user_msg = {"role": "user", "content": enriched_content}
        await self._session_store.add_message(session_id, user_msg)

        # 5a. Wire plan tool's session resolver + read active plan (pinned block).
        # The active-plan block is re-assembled every turn from the on-disk
        # snapshot, so compaction can never make the agent "forget" its plan.
        plan_block = ""
        try:
            from praestoclaw.agent.tools.plan import active_plan_block

            plan_tool = self._tool_registry.get("plan")
            if plan_tool and hasattr(plan_tool, "set_session_resolver"):
                plan_tool.set_session_resolver(lambda sid=session_id: sid)
            plan_block = active_plan_block(session_id)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Active plan block lookup failed: {}", exc)

        # 5. Assemble messages
        messages = self._assemble_messages(system_prompt, history, user_msg)
        if plan_block:
            # Insert immediately after the system prompt so it survives
            # compaction (compaction preserves leading system messages).
            messages.insert(1, {"role": "system", "content": plan_block})

        # 6. Preflight compression
        context_limit = self._resolve_context_limit()
        history_tokens = estimate_tokens(messages)
        if self._compressor.should_preflight_compress(history_tokens, context_limit):
            result = await self._compressor.compress(messages, current_tokens=history_tokens)
            messages = result.messages
            await self._persist_compacted(session_id, messages)
            logger.info(
                "Preflight compression: {}→{} tokens", result.tokens_before, result.tokens_after
            )

        # 8. Main loop
        response_text = ""
        streamed = False
        empty_final_retries = 0
        iteration = 0

        while budget.remaining > 0 or (grace_enabled and budget.grace_available):
            # a. Check interrupt
            if self._interrupt:
                self._interrupt = False
                return response_text or "(interrupted)", True

            # b/c. Consume budget or grace; determine if tools are allowed
            current_tools = self._get_tool_schemas(exclude_tools, metadata=metadata)
            if budget.remaining > 0:
                budget.consume()
                # When grace is disabled and we just consumed the last iteration,
                # force text-only so the model wraps up with text.
                if budget.remaining == 0 and not grace_enabled:
                    current_tools = None
            elif budget.grace_available:
                budget.consume_grace()
                current_tools = None  # force text-only on grace
            else:
                break

            # d. Graceful termination nudge
            if budget.remaining == 1 and current_tools is not None:
                messages.append(
                    {
                        "role": "system",
                        "content": "You are running low on iterations. Please wrap up your current task and provide a final response.",
                    }
                )

            # d2. Memory/skill nudge (Hermes-style learning loop)
            if (
                budget.remaining <= 2
                and current_tools is not None
                and self._turns_since_memory >= self._memory_nudge_interval
            ):
                messages.append(
                    {
                        "role": "system",
                        "content": (
                            "Consider saving important findings to memory "
                            "(user preferences, environment details, lessons learned) "
                            "or as a skill (reusable workflows) before wrapping up."
                        ),
                    }
                )
                self._turns_since_memory = 0

            # e. Cache breakpoints
            cached_messages = apply_cache_breakpoints(messages, self._provider)

            # f. Call LLM
            try:
                llm_response, final_delivered = await self._call_llm(
                    self._config.model,
                    cached_messages,
                    current_tools,
                    channel=channel,
                    channel_id=channel_id,
                )
            except CompressNeededError:
                result = await self._compressor.compress(messages)
                messages = result.messages
                await self._persist_compacted(session_id, messages)
                logger.info("Mid-loop compression: saved {:.0f}%", result.savings_percent)
                continue

            # h. Track usage
            await self._session_store.update_usage(
                session_id,
                prompt_tokens=llm_response.prompt_tokens,
                completion_tokens=llm_response.completion_tokens,
                cost=0.0,
            )

            # i. Tool calls
            if llm_response.has_tool_calls:
                assistant_msg = self._response_to_message(llm_response)
                await self._session_store.add_message(session_id, assistant_msg)
                messages.append(assistant_msg)

                # Push the model's preamble text (e.g. "Let me look that
                # up…") to channels BEFORE executing tools. The tools
                # branch above calls ``provider.complete()`` (non-stream),
                # so the streaming chunk path in ``_call_llm`` is skipped
                # — meaning the only place this content currently lands
                # is ``session_store.add_message`` above. That suffices
                # for surfaces that re-read session history (Web UI
                # polls ``/api/sessions/...``), but push-only channels
                # like Teams never see it and jump straight to the
                # tool-progress card. Emit it as an intermediate
                # OutboundMessage so cloud.py routes it via
                # ``_send_notify`` (``keep_context=True`` keeps the
                # ``/chatng`` sync waiter open for the eventual final
                # reply after tool results). Skip on CLI (no push
                # surface) and when there's no channel context (e.g.
                # ``run_once`` callers).
                # ``route_hint`` is forwarded from the inbound so cloud
                # channel routing for synthetic channel_ids (e.g.
                # ``a2a:notify:*``) lands on the right connection
                # instead of broadcasting. ``.strip()`` guards against
                # whitespace-only content (e.g. ``"\n"``) which would
                # otherwise render as an empty bubble on push channels.
                preamble = (llm_response.content or "").strip()
                if preamble and channel and channel_id and channel != ChannelType.CLI:
                    try:
                        await self._bus.publish_outbound(
                            OutboundMessage(
                                channel=channel,
                                channel_id=channel_id,
                                content=preamble,
                                thread_id=thread_id,
                                route_hint=route_hint,
                                metadata={"keep_context": True},
                            )
                        )
                    except Exception as exc:  # noqa: BLE001
                        logger.warning(
                            "Preamble outbound failed (channel={} channel_id={}): {}",
                            channel,
                            channel_id,
                            exc,
                        )

                results = await self._execute_tools(
                    llm_response.tool_calls,
                    session_id=session_id,
                    channel=channel,
                    channel_id=channel_id,
                    thread_id=thread_id,
                    metadata=metadata,
                    exclude_tools=exclude_tools,
                    user_message=user_message,
                )

                for tc, result_str in results:
                    is_error = result_str.startswith("Error:")
                    tool_msg: dict[str, Any] = {
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": result_str,
                    }
                    if is_error:
                        tool_msg["is_error"] = True
                    await self._session_store.add_message(session_id, tool_msg)
                    messages.append(tool_msg)

                    # Reset learning loop counter when memory/skill tools are used
                    if tc.name in ("memory", "skill_manage"):
                        self._turns_since_memory = 0

                # Loop detection
                for tc, _ in results:
                    warning, should_terminate = loop_detector.check(tc.name, tc.arguments)
                    if should_terminate:
                        response_text = warning or "Loop detected — stopping."
                        break
                    if warning:
                        messages.append({"role": "system", "content": warning})
                else:
                    # Post-iteration compression
                    iteration += 1
                    msg_tokens = estimate_tokens(messages)
                    if self._compressor.should_compress(msg_tokens, context_limit):
                        # Pre-compression memory flush (Hermes-style)
                        await self._flush_memories_before_compression(
                            messages, session_id, channel=channel, channel_id=channel_id
                        )
                        cr = await self._compressor.compress(messages, current_tokens=msg_tokens)
                        messages = cr.messages
                        await self._persist_compacted(session_id, messages)
                    continue

                break  # loop terminated
            else:
                # j. Text response → done
                response_text = llm_response.content or ""
                # streamed = final delivery confirmed (all chunks + done marker sent OK)
                streamed = final_delivered
                if not response_text.strip():
                    empty_final_retries += 1
                    can_retry_empty_final = empty_final_retries == 1 and (
                        budget.remaining > 0 or (grace_enabled and budget.grace_available)
                    )
                    if can_retry_empty_final:
                        logger.warning(
                            "Agent produced empty final response; requesting explicit "
                            "continuation/wrap-up session_id={} budget_remaining={} grace_available={}",
                            session_id,
                            budget.remaining,
                            budget.grace_available,
                        )
                        messages.append({"role": "system", "content": _EMPTY_FINAL_RESPONSE_PROMPT})
                        continue
                    logger.warning(
                        "Agent produced empty final response and cannot retry; returning "
                        "incomplete status session_id={} budget_remaining={} grace_available={}",
                        session_id,
                        budget.remaining,
                        budget.grace_available,
                    )
                    response_text = _EMPTY_FINAL_RESPONSE_FALLBACK
                    streamed = False
                break

        # 9. Persist final response
        if response_text:
            await self._session_store.add_message(
                session_id,
                {"role": "assistant", "content": response_text},
            )

        # 10. Fire-and-forget memory consolidation
        if self._memory and response_text:
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(self._async_consolidate(messages, session_id))
            except RuntimeError:
                pass

        return response_text, streamed

    # ── Helpers ──────────────────────────────────────────────────────────

    async def _call_llm(
        self,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None,
        *,
        channel: Any = None,
        channel_id: str | None = None,
    ) -> tuple[LLMResponse, bool]:
        """Call provider — complete() when tools enabled, stream() for text-only.

        Returns (LLMResponse, final_delivered) where final_delivered is True
        only when ALL streaming chunks AND the done=True marker were successfully
        dispatched to a non-CLI channel. If any dispatch fails or if the stream
        errors mid-way, final_delivered is False and the caller should send a
        full OutboundMessage as fallback.

        The done marker is always sent in a finally block.
        """
        # Forward the agent's configured reasoning_effort (e.g. "high" thinking)
        # to the provider. Providers/models that don't support it ignore the value.
        reasoning_effort = getattr(self._config, "reasoning_effort", None)
        if tools:
            return await self._provider.complete(
                model=model,
                messages=messages,
                tools=tools,
                reasoning_effort=reasoning_effort,
            ), False

        # Streaming for text-only responses
        content_parts: list[str] = []
        finish_reason = "stop"
        any_chunk_sent = False
        any_dispatch_failed = False
        stream_error = False

        try:
            async for chunk in self._provider.stream(
                model=model,
                messages=messages,
                tools=None,
                reasoning_effort=reasoning_effort,
            ):
                if chunk.content:
                    content_parts.append(chunk.content)
                    if channel and channel_id and channel != ChannelType.CLI:
                        try:
                            await self._bus.dispatch_outbound(
                                StreamingChunk(
                                    channel=channel,
                                    channel_id=channel_id or "",
                                    content=chunk.content,
                                    done=False,
                                )
                            )
                            any_chunk_sent = True
                        except Exception:
                            any_dispatch_failed = True
                if chunk.finish_reason:
                    finish_reason = chunk.finish_reason
        except Exception:
            stream_error = True
            raise
        finally:
            if any_chunk_sent:
                try:
                    await self._bus.dispatch_outbound(
                        StreamingChunk(
                            channel=channel,
                            channel_id=channel_id or "",
                            content="",
                            done=True,
                        )
                    )
                except Exception:
                    any_dispatch_failed = True

        # final_delivered = all chunks sent successfully + done marker sent + no errors
        response_content = "".join(content_parts)
        final_delivered = (
            any_chunk_sent
            and bool(response_content.strip())
            and not any_dispatch_failed
            and not stream_error
        )

        return LLMResponse(
            content=response_content,
            finish_reason=finish_reason,
            model=model,
        ), final_delivered

    # ── Context assembly ──────────────────────────────────────────────────
    #
    # Delegates to PromptBuilder (praestoclaw/agent/prompt_builder.py).
    # See that module's docstring for the full build order.
    #

    def _build_system_prompt(self) -> str:
        """Assemble the system prompt via PromptBuilder."""
        return self._prompt_builder.build_system_prompt(mode=self._prompt_mode)

    def _build_attachment_context(self, metadata: dict[str, Any] | None) -> str:
        if not _has_pending_attachments(metadata):
            return ""
        refs = _AttachmentResolver().list_current(metadata)
        if not refs:
            return ""

        pending_images = (metadata or {}).get("pending_images") or {}
        errors = pending_images.get("errors") if isinstance(pending_images, dict) else []
        image_urls = pending_images.get("urls") if isinstance(pending_images, dict) else []
        prompt_safe_image_urls: set[str] = (
            {url.strip() for url in image_urls if isinstance(url, str) and url.strip()}
            if isinstance(image_urls, list)
            else set()
        )
        has_successful_image_url = bool(prompt_safe_image_urls)
        err_note = (
            f" ({len(errors)} image upload(s) failed)"
            if errors and not has_successful_image_url
            else ""
        )
        lines = [
            f"[attachments: {len(refs)} file(s)/image(s) attached by user; "
            f"use attachment_process if attachment content is needed{err_note}]"
        ]
        for ref in refs:
            bits = [f"{ref.index}. {ref.kind}"]
            if ref.name:
                bits.append(f"name={ref.name}")
            if ref.file_type:
                bits.append(f"file_type={ref.file_type}")
            if ref.content_type:
                bits.append(f"content_type={ref.content_type}")
            # Only surface URLs that were republished via the public image host
            # (i.e. present in pending_images.urls). Raw Teams/SharePoint signed
            # URLs stay hidden — the model can still read content via
            # attachment_process. See PR #325 review comment.
            if ref.kind == "image" and not ref.requires_auth and ref.url in prompt_safe_image_urls:
                bits.append(f"url={ref.url}")
            else:
                bits.append("url=hidden; available via attachment_process")
            lines.append("  - " + "; ".join(bits))
        return "\n".join(lines)

    def _assemble_messages(
        self,
        system: str,
        history: list[dict[str, Any]],
        user_msg: dict[str, Any],
    ) -> list[dict[str, Any]]:
        # Filter session history to LLM-acceptable roles only. Non-LLM
        # records (``approval_request`` / ``approval_resolved`` and other
        # UI-only metadata) live in the session JSONL so the Web UI can
        # render them, but they MUST NOT be sent to the model:
        #
        #   - OpenAI/compatible providers reject unknown roles outright.
        #   - Other SDKs silently coerce unknown roles to "user", which
        #     plants the raw approval JSON (including ``resolved_card``,
        #     adaptive-card body, agent reasoning) into the model's
        #     context. The model then echoes / paraphrases that JSON in
        #     its next reply, which surfaces in Teams as a ~2 KB blob of
        #     plain text alongside the resolved card. See issue #84.
        #
        # ``is_error`` is dropped only for ``role == "user"`` (UI-only
        # echoes of failed user messages). Tool error results are kept:
        # the model needs to see prior tool failures to recover.
        from praestoclaw.session.manager import SessionManager

        history = [
            m
            for m in history
            if m.get("role") in SessionManager.LLM_ROLES
            and not (m.get("role") == "user" and m.get("is_error"))
        ]
        messages = [{"role": "system", "content": system}, *history, user_msg]
        return sanitize_tool_messages(messages)

    def _get_tool_schemas(
        self,
        exclude_tools: list[str] | None = None,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]] | None:
        allowed = self._config.tools or None
        # Per-agent memory_writable enforcement
        exclude = list(exclude_tools or [])
        if not getattr(self._config, "memory_writable", True):
            exclude.append("memory")
        if not _has_pending_attachments(metadata):
            exclude.append("attachment_process")
        exact_exclude = [name for name in exclude if not name.endswith("*")]
        schemas = self._tool_registry.get_schemas(allowed, exclude=exact_exclude or None)
        schemas = [
            schema
            for schema in schemas
            if not self._tool_excluded(
                str(schema.get("function", {}).get("name", "")),
                exclude,
            )
        ]
        if not schemas:
            return None
        return list(schemas)

    @staticmethod
    def _tool_excluded(name: str, exclude_tools: list[str] | None) -> bool:
        for pattern in exclude_tools or []:
            if pattern.endswith("*") and name.startswith(pattern[:-1]):
                return True
            if name == pattern:
                return True
        return False

    def _resolve_context_limit(self) -> int:
        return self._config.context_limit or _DEFAULT_CONTEXT_LIMIT

    def _response_to_message(self, response: LLMResponse) -> dict[str, Any]:
        msg: dict[str, Any] = {"role": "assistant"}
        if response.content:
            msg["content"] = response.content
        if response.tool_calls:
            msg["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.name,
                        "arguments": json.dumps(tc.arguments, ensure_ascii=False)
                        if isinstance(tc.arguments, dict)
                        else tc.arguments,
                    },
                }
                for tc in response.tool_calls
            ]
        return msg

    async def _execute_tools(
        self,
        tool_calls: list[ToolCallRequest],
        *,
        session_id: str | None = None,
        channel: Any = None,
        channel_id: str | None = None,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        exclude_tools: list[str] | None = None,
        user_message: str = "",
    ) -> list[tuple[ToolCallRequest, str]]:
        """IronClaw 3-phase tool execution pipeline.

        Phase 1 (Preflight, sequential): allowlist enforcement + pre_tool_use hooks
        Phase 2 (Execute, parallel when safe): actual tool invocation
        Phase 3 (Postflight, sequential): post_tool_use hooks → redaction → truncation
        """
        import time

        # Build effective allowed tool set for runtime enforcement
        allowed_tools = self._resolve_allowed_tools(exclude_tools)

        # Phase 1: Preflight — enforce allowlist + pre_tool_use hooks (sequential)
        approved: list[tuple[ToolCallRequest, bool]] = []  # (tc, blocked)
        preflight_results: dict[str, str] = {}  # tc.id → error msg for blocked tools

        for tc in tool_calls:
            logger.info("Tool call: {}({})", tc.name, list(tc.arguments.keys()))
            blocked = False

            # Execution-time allowlist enforcement (defense-in-depth)
            if allowed_tools is not None and tc.name not in allowed_tools:
                blocked = True
                preflight_results[tc.id] = (
                    f"Tool '{tc.name}' is not available for this agent. Do NOT retry this tool."
                )
                logger.warning("Tool '{}' blocked by allowlist at execution time", tc.name)
                if self._audit:
                    self._audit.log_security(
                        event="tool_blocked_by_allowlist",
                        details={"tool": tc.name, "session_id": session_id},
                        severity="warning",
                    )
                approved.append((tc, blocked))

            # Per-agent memory_writable enforcement (defense-in-depth)
            elif tc.name == "memory" and not getattr(self._config, "memory_writable", True):
                blocked = True
                preflight_results[tc.id] = (
                    "Memory writes are disabled for this agent (memory_writable=false)."
                )
                logger.warning("Memory tool blocked: memory_writable=false")
                approved.append((tc, blocked))
                continue

            # pre_tool_use hook (risk scoring, approval, etc.)
            if self._hooks:
                _tool = (
                    self._tool_registry.get(tc.name)
                    if hasattr(self._tool_registry, "get")
                    else None
                )
                # Collect recent user messages for risk scorer context
                _user_msgs: list[str] = [user_message] if user_message else []
                if not _user_msgs and session_id:
                    try:
                        _all = await self._session_store.get_messages(session_id)
                        _user_msgs = [
                            m["content"]
                            for m in _all
                            if m.get("role") == "user" and m.get("content")
                        ][-3:]
                    except Exception:
                        pass
                # Redact credentials before sending to scorer
                _user_msgs = [redact_credentials(m) for m in _user_msgs]

                pre_ctx = PreToolHookContext(
                    tool_name=tc.name,
                    args=tc.arguments,
                    agent_name=self._config.name,
                    session_id=session_id or "",
                    tool_call_id=tc.id,
                    tool_ref=_tool,
                    channel=channel if isinstance(channel, ChannelType) else None,
                    channel_id=str(channel_id or ""),
                    user_messages=_user_msgs,
                    metadata=metadata or {},
                )
                pre_result = await self._hooks.dispatch_checked("pre_tool_use", pre_ctx)
                if pre_result.verdict == HookVerdict.REJECT:
                    preflight_results[tc.id] = (
                        f"Tool '{tc.name}' blocked by security policy: {pre_result.reason}\n"
                        "Do NOT retry this tool. Inform the user it was blocked."
                    )
                    logger.warning("Tool '{}' blocked by hook: {}", tc.name, pre_result.reason)
                    blocked = True

            approved.append((tc, blocked))

        # Phase 2: Execute — parallel for independent tools
        async def _exec_one(tc: ToolCallRequest) -> str:
            try:
                # Copy args to prevent ToolRegistry.execute() from mutating
                # the original tc.arguments (it injects _channel, _metadata etc.)
                # which would pollute loop detection arg comparison and tracing.
                exec_args = dict(tc.arguments)
                if tc.name == "attachment_process":
                    exec_args["_user_message"] = user_message
                    exec_args["_model"] = self._config.model
                result: str = await self._tool_registry.execute(
                    tc.name,
                    exec_args,
                    actor="agent",
                    session_id=session_id,
                    bus=self._bus,
                    channel=channel,
                    channel_id=channel_id,
                    thread_id=thread_id,
                    metadata=metadata,
                    tool_call_id=tc.id,
                )
                return result
            except Exception as e:
                logger.error("Tool {} failed: {}", tc.name, e)
                return f"Error: {e}"

        runnable = [tc for tc, blocked in approved if not blocked]
        exec_results: dict[str, tuple[str, float]] = {}  # tc.id → (result, duration_ms)

        if runnable:
            exec_start = time.monotonic()
            raw_results = await self._parallelizer.execute_batch(runnable, _exec_one)
            duration = (time.monotonic() - exec_start) * 1000
            per_tool_ms = duration / len(runnable) if runnable else 0
            for tc_id, result_str in raw_results:
                exec_results[tc_id] = (result_str, per_tool_ms)

        # Phase 3: Postflight — post_tool_use hooks → redaction → truncation (sequential)
        final_results: list[tuple[ToolCallRequest, str]] = []

        for tc, blocked in approved:
            if blocked:
                final_results.append(
                    (tc, preflight_results.get(tc.id, f"Tool '{tc.name}' blocked."))
                )
                continue

            result, duration_ms = exec_results.get(tc.id, ("", 0.0))

            # post_tool_use hook BEFORE redaction (leak scanner needs raw output)
            if self._hooks:
                post_ctx = PostToolHookContext(
                    tool_name=tc.name,
                    args=tc.arguments,
                    result=result,
                    success=not result.startswith("Error:"),
                    agent_name=self._config.name,
                    session_id=session_id or "",
                    tool_call_id=tc.id,
                    duration_ms=duration_ms,
                    channel=channel if isinstance(channel, ChannelType) else None,
                    channel_id=str(channel_id or ""),
                    metadata=metadata or {},
                )
                hook_result = await self._hooks.dispatch_checked("post_tool_use", post_ctx)
                if hook_result.data and isinstance(hook_result.data, PostToolHookContext):
                    result = hook_result.data.result

            # Redact secrets AFTER hooks inspected raw output
            result = Sanitizer.redact_env_values(result)

            # Unified truncation
            tool_obj = (
                self._tool_registry.get(tc.name) if hasattr(self._tool_registry, "get") else None
            )
            tool_max = getattr(getattr(tool_obj, "metadata", None), "max_output_chars", 0)
            output_cfg = (
                self._tool_registry.output_config
                if hasattr(self._tool_registry, "output_config")
                else None
            )
            max_chars = tool_max if tool_max > 0 else (getattr(output_cfg, "max_chars", 50_000))
            llm_enabled = (
                getattr(output_cfg, "llm_compression_enabled", True) if output_cfg else True
            )
            result = await truncate_tool_output(
                content=result,
                tool_name=tc.name,
                max_chars=max_chars,
                provider=self._provider,
                llm_enabled=llm_enabled,
                tool_args=tc.arguments,
            )

            final_results.append((tc, result))

        return final_results

    def _resolve_allowed_tools(self, exclude_tools: list[str] | None = None) -> set[str] | None:
        """Build the effective allowed tool set for runtime enforcement.

        Returns None if all tools are allowed, otherwise a set of allowed names.
        """
        # Start with agent config allowlist
        config_tools = self._config.tools
        if config_tools is None or (isinstance(config_tools, list) and not config_tools):
            # None or empty list = all tools allowed
            allowed: set[str] | None = None
        else:
            allowed = set(config_tools)

        # Apply exclude_tools
        if exclude_tools and allowed is not None:
            allowed = {name for name in allowed if not self._tool_excluded(name, exclude_tools)}
        elif exclude_tools and allowed is None:
            # All tools minus excluded — get full list from registry
            schemas = self._tool_registry.get_schemas()
            all_names = {s.get("function", {}).get("name", "") for s in schemas}
            allowed = {name for name in all_names if not self._tool_excluded(name, exclude_tools)}

        return allowed

    async def _flush_memories_before_compression(
        self,
        messages: list[dict[str, Any]],
        session_id: str,
        *,
        channel: Any = None,
        channel_id: str | None = None,
    ) -> None:
        """Pre-compression memory flush (Hermes-style).

        Give the agent one LLM call with only the memory tool to save
        important findings before context is compressed and older messages
        are lost. Only fires if the conversation has enough user turns
        to have generated meaningful content.
        """
        if not self._memory:
            return
        # Only flush if there's been meaningful conversation (>= 6 user turns)
        user_turns = sum(1 for m in messages if m.get("role") == "user")
        if user_turns < 6:
            return

        flush_msg = {
            "role": "system",
            "content": (
                "[System: The session context is being compressed. "
                "Save anything worth remembering — prioritize user preferences, "
                "corrections, and recurring patterns over task-specific details.]"
            ),
        }
        try:
            # Build a minimal message list with only memory tool
            flush_messages = messages + [flush_msg]
            memory_schema = self._tool_registry.get_schemas(["memory"])
            if not memory_schema:
                return
            response, _ = await self._call_llm(
                self._config.model,
                flush_messages,
                list(memory_schema),
                channel=channel,
                channel_id=channel_id,
            )
            # Execute any memory tool calls from the flush response
            if response.tool_calls:
                results = await self._execute_tools(
                    response.tool_calls,
                    session_id=session_id,
                    channel=channel,
                    channel_id=channel_id,
                )
                logger.info(
                    "Pre-compression flush: {} memory tool call(s)",
                    len(results),
                )
            # Don't append flush artifacts to the conversation —
            # they would be compressed away immediately anyway
        except Exception as exc:
            logger.debug("Pre-compression flush failed: {}", exc)

    async def _persist_compacted(self, session_id: str, messages: list[dict[str, Any]]) -> None:
        """Persist compacted messages.

        Strips ephemeral system messages (the base prompt is rebuilt by
        :meth:`_assemble_messages` on every turn, so persisting it would
        duplicate the row on next assemble) but preserves compaction
        summary rows (identified by :func:`is_compaction_summary`). The
        summary carries cross-turn memory of the older history, so dropping
        it on persist would force every future compaction to start from
        the truncated tail and steadily lose context.
        """
        from praestoclaw.agent.compressor import is_compaction_summary

        keep = [m for m in messages if m.get("role") != "system" or is_compaction_summary(m)]
        await self._session_store.replace_messages(session_id, keep)

    async def _process_message(self, msg: InboundMessage) -> None:
        """Process a single inbound message through the full agent pipeline.

        Matches v1's _process_message: audit → approval routing → slash commands
        → hooks (on_message_received) → typing → agent loop → hooks
        (on_message_sent) → outbound.
        """
        channel = ChannelType.of(msg.logical_channel)
        delivery_route_id = msg.delivery_route_id
        conversation_id = msg.conversation_id or delivery_route_id
        sender_for_session = msg.sender_id or conversation_id or delivery_route_id or "anonymous"
        agent_session_key = msg.agent_session_key or (
            f"{channel}:{sender_for_session}:{conversation_id or delivery_route_id}"
        )
        await self._session_store.ensure_session(
            agent_session_key,
            str(channel),
            sender_for_session,
        )

        # ── Audit: inbound ──
        if self._audit:
            self._audit.log_message(
                channel=str(channel),
                direction="inbound",
                actor=msg.sender_id or "unknown",
                session_id=agent_session_key,
            )

        # ── Approval routing ──
        if await self._try_route_approval(msg):
            return

        # ── Slash commands ──
        content = msg.content.strip()
        if content.startswith("/"):
            reply = await self._handle_slash(content, agent_session_key, msg)
            if reply is not None:
                await self._bus.publish_outbound(
                    OutboundMessage(
                        channel=channel,
                        channel_id=delivery_route_id,
                        content=reply,
                        thread_id=conversation_id,
                        route_hint=msg.route_hint,
                    )
                )
                return

        # ── Hook: on_message_received ──
        if self._hooks:
            hook_ctx = MessageHookContext(
                content=msg.content,
                channel=channel if isinstance(channel, ChannelType) else ChannelType.CLI,
                sender_id=msg.sender_id or "",
                session_id=agent_session_key,
            )
            result = await self._hooks.dispatch_checked("on_message_received", hook_ctx)
            if result.verdict == HookVerdict.REJECT:
                logger.warning("Message rejected by hook: {}", result.reason)
                await self._bus.publish_outbound(
                    OutboundMessage(
                        channel=channel,
                        channel_id=delivery_route_id,
                        content=f"Message blocked: {result.reason}",
                        thread_id=conversation_id,
                        route_hint=msg.route_hint,
                    )
                )
                return
        else:
            # Fallback: inline prompt injection check when no hooks configured
            findings = Sanitizer.check_prompt_injection(msg.content)
            if findings:
                if self._audit:
                    self._audit.log_security(
                        event="prompt_injection_detected",
                        details={"findings": findings, "sender": msg.sender_id},
                        severity="warning",
                    )
                logger.warning("Prompt injection detected from {}: {}", msg.sender_id, findings)

        # ── Typing indicator ──
        typing_task = self._start_typing(channel, delivery_route_id, metadata=msg.metadata)

        # ── Task heartbeat (issue #181) ──
        # If the inbound carrier was a task-bearing a2a envelope, the
        # cloud channel stashed a private ``_task_progress_sender`` in
        # metadata. Pop it out (we never want the callable to leak into
        # the LLM/tool layer) and wrap the agent turn in a heartbeat
        # emitter so the original sender sees periodic ``executing``
        # progress events and the Gateway extends the executing-stage
        # soft deadline. No-op when the carrier was not a task.
        heartbeat = self._build_task_heartbeat(msg.metadata)

        # Source-driven tool exclusions. Inbound carriers (notably
        # ``source="a2a_task"`` from ``CloudProtocolChannel``) stamp an
        # ``exclude_tools`` list into ``metadata`` to keep the executor
        # turn from re-invoking ``a2a`` (infinite hop) or ``cron`` /
        # ``spawn`` (privilege escalation by a remote peer). ``notify``
        # is deliberately *not* excluded for a2a_task so the executor
        # can still push a final summary to its own owner — see the
        # corresponding NOTE in ``CloudChannel._handle_conversation_request``.
        raw_exclude = (msg.metadata or {}).get("exclude_tools")
        exclude_tools = (
            [str(t) for t in raw_exclude if isinstance(t, str)]
            if isinstance(raw_exclude, list)
            else None
        )

        try:
            history = await self._session_store.get_messages(agent_session_key)
            if heartbeat is not None:
                async with heartbeat:
                    response, streamed = await self._run_conversation(
                        msg.content,
                        history,
                        agent_session_key,
                        channel=channel,
                        channel_id=delivery_route_id,
                        thread_id=conversation_id,
                        metadata=msg.metadata,
                        exclude_tools=exclude_tools,
                        route_hint=msg.route_hint,
                    )
            else:
                response, streamed = await self._run_conversation(
                    msg.content,
                    history,
                    agent_session_key,
                    channel=channel,
                    channel_id=delivery_route_id,
                    thread_id=conversation_id,
                    metadata=msg.metadata,
                    exclude_tools=exclude_tools,
                    route_hint=msg.route_hint,
                )
        except Exception as exc:
            logger.error("Agent loop error: {}", exc)
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=channel,
                    channel_id=delivery_route_id,
                    content="Sorry, an internal error occurred. Please try again.",
                    thread_id=conversation_id,
                    route_hint=msg.route_hint,
                )
            )
            return
        finally:
            self._stop_typing(typing_task, channel, delivery_route_id)

        # Empty/whitespace-only non-streamed turns have no user-visible outbound message.
        # Suppress them before outbound hooks/audit so hooks only observe
        # content that was streamed or is about to be published.
        if not streamed and not response.strip():
            logger.info(
                "Agent produced no final response; suppressing empty outbound "
                "channel={} channel_id={} session_id={}",
                channel,
                delivery_route_id,
                agent_session_key,
            )
            return

        # ── Hook: on_message_sent — runs on delivered/publishable content ──
        # For streamed responses, the hook runs on the full accumulated text
        # (same as v1's _stream_response which ran the hook after streaming).
        # If the hook rejects, we still send a replacement OutboundMessage
        # even if chunks were already streamed (best-effort correction).
        hook_blocked = False
        if self._hooks:
            out_ctx = MessageHookContext(
                content=response,
                channel=channel if isinstance(channel, ChannelType) else ChannelType.CLI,
                session_id=agent_session_key,
            )
            result = await self._hooks.dispatch_checked("on_message_sent", out_ctx)
            if result.verdict == HookVerdict.REJECT:
                logger.warning("Outbound message blocked by hook: {}", result.reason)
                response = "[Message blocked by security policy]"
                hook_blocked = True
            elif result.data and isinstance(result.data, MessageHookContext):
                response = result.data.content

        # ── Outbound: send full message only when NOT already delivered ──
        # If streaming delivered the final response AND hook didn't block,
        # skip the full OutboundMessage (channels already have the content).
        # If hook blocked a streamed response, send the replacement text.
        if not streamed or hook_blocked:
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=channel,
                    channel_id=delivery_route_id,
                    content=response,
                    thread_id=conversation_id,
                    route_hint=msg.route_hint,
                )
            )

        # ── Audit: outbound ──
        if self._audit:
            self._audit.log_message(
                channel=str(channel),
                direction="outbound",
                actor="agent",
                session_id=agent_session_key,
            )

    def _build_task_heartbeat(self, metadata: dict[str, Any] | None) -> Any:
        """Construct a :class:`TaskHeartbeatEmitter` for task-bearing inbounds.

        Returns ``None`` when *metadata* does not describe a task carrier
        (the common case — plain chat / a2a messages get no heartbeat).
        The ``_task_progress_sender`` callable is popped out so it never
        reaches the LLM/tool serialization layer; cloud.py owns the
        contract that this private key carries the outbound handle.
        """

        if not metadata:
            return None
        sender = metadata.pop("_task_progress_sender", None)
        task_id = metadata.get("task_id")
        if sender is None or not isinstance(task_id, str) or not task_id:
            return None
        summary = ""
        raw_summary = metadata.get("task_summary")
        if isinstance(raw_summary, str):
            summary = raw_summary
        try:
            from praestoclaw.task.heartbeat import TaskHeartbeatEmitter  # noqa: PLC0415

            return TaskHeartbeatEmitter(
                sender,
                task_id=task_id,
                summary=summary,
            )
        except Exception as exc:  # noqa: BLE001
            # Heartbeat is best-effort: a misconfigured emitter must not
            # block the actual agent turn. Log and run without it.
            logger.warning("task heartbeat emitter init failed: {}", exc)
            return None

    async def _async_consolidate(
        self,
        messages: list[dict[str, Any]],
        session_id: str,
    ) -> None:
        """Fire-and-forget memory consolidation."""
        try:
            if hasattr(self._memory, "consolidate"):
                await self._memory.consolidate(messages, session_id)
        except Exception:
            logger.exception("Memory consolidation failed")
