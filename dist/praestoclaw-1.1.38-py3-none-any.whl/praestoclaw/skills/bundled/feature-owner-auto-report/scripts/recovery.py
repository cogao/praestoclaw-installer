"""Durable reader replies and bounded next tasks for an existing report run.

This helper neither calls agents nor creates PRs. Sources/candidates are inputs;
resume information is rebuilt from them, never from a remembered plan summary.
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path


def raw_text(path: Path) -> str:
    with path.open(encoding="utf-8", newline="") as handle:
        return handle.read()


def preserve(path: Path, raw: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with path.open("x", encoding="utf-8", newline="") as handle:
            handle.write(raw)
    except FileExistsError:
        if raw_text(path) != raw:
            raise ValueError(f"preserve the existing reader response: {path}") from None


def submit_review(root: Path, manifest: dict, source: Path, report) -> dict:
    """Commit one reader's own draft; invalid drafts never become canonical replies."""
    source = source.resolve()
    folder = source.parent
    project = folder.parent.parent
    confirmation = source.name == "confirmation-draft.json"
    if (
        source.name not in {"review-draft.json", "confirmation-draft.json"}
        or not re.fullmatch(r"v[1-3]", folder.name)
        or folder.parent.name != "candidate"
        or project.parent != (root / "projects").resolve()
        or project.name not in manifest["projects"]
    ):
        raise ValueError("submit the assigned current-run candidate draft path")
    raw = raw_text(source)
    archive = root / "reviews" / (hashlib.sha256(raw.encode("utf-8")).hexdigest() + ".txt")
    preserve(archive, raw)
    review = report.review_module()
    verdicts = review.raw_verdicts(raw)
    if len(verdicts) != 1:
        raise ValueError("submit exactly one candidate reply from its assigned draft")
    verdict = verdicts[0]
    primary = json.loads((folder / "review-packet.json").read_text(encoding="utf-8"))
    bundle = json.loads((root / "sources.json").read_text(encoding="utf-8"))
    if primary.get("source") != report.select_project(bundle, project.name) or primary.get(
        "weekly_source"
    ) != bundle.get("weekly_source"):
        raise ValueError("review candidate differs from this run source")
    if primary.get("confirmation_required") is not True or "review_stage" in primary:
        raise ValueError("this run requires the frozen independent confirmation contract")
    html = (folder / "index.html").read_text(encoding="utf-8")
    packet = primary
    if confirmation:
        packet = json.loads((folder / "confirmation-packet.json").read_text(encoding="utf-8"))
        if packet != review.confirmation_packet(primary):
            raise ValueError("confirmation differs from the primary frozen candidate")
        first = saved_verdict(folder, primary, report)
        if review.validate(primary, first, html, manifest["revision"]) != "independent":
            raise ValueError("confirmation requires the first independent ready review")
    if verdict.get("candidate") != review.candidate_id(packet):
        raise ValueError("review belongs to a different candidate; do not relabel the reply")
    mode = review.validate(packet, verdict, html, manifest["revision"], require_ready=False)
    if mode != "independent":
        raise ValueError("this run requires independent readers")
    target = folder / ("confirmation-review.json" if confirmation else "review.json")
    preserve(target, raw)
    return {"archive": str(archive), "saved": [str(target)]}


def saved_verdict(folder: Path, packet: dict, report, *, confirmation=False) -> dict:
    path = folder / ("confirmation-review.json" if confirmation else "review.json")
    review = report.review_module()
    matches = [
        v
        for v in review.raw_verdicts(raw_text(path))
        if v.get("candidate") == review.candidate_id(packet)
    ]
    if len(matches) != 1:
        raise ValueError(f"{path.name} must contain exactly one bound candidate reply")
    return matches[0]


def candidate_reviews(folder: Path, manifest: dict, report, *, require_ready=False) -> dict:
    """One effective gate for status, repair and preparation; raw replies stay separate."""
    review = report.review_module()
    packet = json.loads((folder / "review-packet.json").read_text(encoding="utf-8"))
    if manifest.get("independent_confirmation") and packet.get("confirmation_required") is not True:
        raise ValueError("this run requires the frozen independent confirmation contract")
    if "review_stage" in packet:
        raise ValueError("the primary packet cannot be a confirmation packet")
    state = dict(state="pending_review", blockers=[], review_path=str(folder / "review.json"))
    proof = dict(packet=packet)
    html = (folder / "index.html").read_text(encoding="utf-8")
    if (folder / "review.json").exists():
        verdict = saved_verdict(folder, packet, report)
        mode = review.validate(packet, verdict, html, manifest["revision"], require_ready=False)
        if packet.get("confirmation_required") and mode != "independent":
            raise ValueError("the primary review requires an independent reader")
        proof["verdict"] = verdict
        state.update(state=verdict["report_review"], blockers=verdict["blockers"])
        if state["state"] == "ready" and packet.get("confirmation_required"):
            confirmation = review.confirmation_packet(packet)
            actual = json.loads((folder / "confirmation-packet.json").read_text(encoding="utf-8"))
            if actual != confirmation:
                raise ValueError("confirmation differs from the primary frozen candidate")
            state.update(
                state="pending_confirmation",
                review_path=str(folder / "confirmation-review.json"),
                review_candidate=review.candidate_id(confirmation),
            )
            if (folder / "confirmation-review.json").exists():
                verdict = saved_verdict(folder, confirmation, report, confirmation=True)
                review.validate_confirmation(
                    packet, verdict, html, manifest["revision"], require_ready=False
                )
                proof["confirmation"] = verdict
                state.update(state=verdict["report_review"], blockers=verdict["blockers"])
    if require_ready:
        if "verdict" not in proof:
            raise ValueError("review.json is still pending")
        review.validate_publication(proof, html, manifest["revision"])
    if state["state"] == "ready" and packet.get("confirmation_required"):
        state["review_inputs"] = {
            name: hashlib.sha256((folder / name).read_bytes()).hexdigest()
            for name in (
                "review-packet.json",
                "review.json",
                "confirmation-packet.json",
                "confirmation-review.json",
            )
        }
    return dict(state, proof=proof)


def pending_submission(folder: Path) -> str | None:
    for stem, canonical in (
        ("review", "review.json"),
        ("confirmation", "confirmation-review.json"),
    ):
        if (folder / canonical).exists():
            continue
        draft = folder / f"{stem}-draft.json"
        if draft.exists():
            return f"unsubmitted reader draft at {draft}"
        dispatched = folder / f"{stem}-dispatched.json"
        if dispatched.exists():
            return (
                f"reader dispatch reserved at {dispatched}, without a validated submission "
                "(actual reader startup is unconfirmed)"
            )
    return None


def reserve_reader_batch(batch: dict) -> None:
    """Consume each export opportunity before output, even if output later fails."""
    if batch.get("phase") != "review":
        return
    for assignment in batch["tasks"]:
        task = Path(assignment["task_file"])
        marker = task.with_name(task.name.replace("-task.md", "-dispatched.json"))
        try:
            with marker.open("x", encoding="utf-8") as handle:
                json.dump(assignment, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
        except FileExistsError as exc:
            raise ValueError(
                f"reader dispatch already reserved; run next for current state: {marker}"
            ) from exc


def batches(root: Path, state: dict) -> list[dict]:
    groups = {"author": [], "review": [], "repair": []}
    for row in state["projects"]:
        project = row["project"]
        directory = root / "projects" / project
        if row["state"] in {
            "ready",
            "render_budget_exhausted",
            "attempt_record_error",
            "render_incomplete",
            "render_in_progress",
        }:
            if row["state"] == "render_in_progress":
                row["next_action"] = (
                    "wait for the current render process, then resume; do not dispatch a duplicate author"
                )
            elif row["state"] != "ready":
                row["next_action"] = (
                    "preserve the attempt records and report the unresolved fields; do not redispatch or change versions"
                )
            continue
        folder = directory / "candidate" / row.get("version", "v1")
        version = row.get("version", "v1")
        if row["state"] == "render_failed":
            phase = "repair"
            prompt = f"Continue the existing {project} structural repair at {directory / 'content.json'}. Read {directory / 'author-task.md'} and current-run sources. Render only {row['version']} with this run's helper. {row['render_attempts']} of 3 attempts are already consumed; never restart the count or change versions. Fix the recorded fields: {row.get('error')}. Do not review yourself."
        elif not row.get("html"):
            phase = "author"
            prompt = f"Work directly as the author of ONE project, {project}. Read and execute {directory / 'author-task.md'}. Do not delegate or spawn another agent. Preserve any existing content.json and repair it in place when present. Return after rendering, without reviewing yourself."
        elif row["state"] in {"pending_review", "pending_confirmation"}:
            if pending := pending_submission(folder):
                row["next_action"] = (
                    f"{pending}; continue the original reader's submission "
                    "or report its interruption. Do not start a fresh review or change versions."
                )
                continue
            phase = "review"
            task_name = (
                "confirmation-task.md"
                if row["state"] == "pending_confirmation"
                else "review-task.md"
            )
            prompt = f"Independently review ONE project, {project}, as a fresh reader separate from its author and any earlier reader. Read and execute {folder / task_name}. Work directly; do not delegate. Sources, content and HTML are read-only. Write only your task's draft and use its submit-review command to commit the unchanged valid reply. Return only the saved path and submission receipt, not a second JSON verdict. Preserve all existing canonical replies and never use a shared scratch path."
        elif row.get("blockers"):
            reviewed = list((directory / "candidate").glob("v*/review.json"))
            if len(reviewed) >= 3:
                row["next_action"] = (
                    "review_budget_exhausted; keep the local candidate and report its blockers"
                )
                continue
            phase = "repair"
            number = (
                max(
                    int(p.name[1:])
                    for p in (directory / "candidate").iterdir()
                    if re.fullmatch(r"v[1-9][0-9]*", p.name)
                )
                + 1
            )
            version = f"v{number}"
            findings = row.get("review_path", str(folder / "review.json"))
            prompt = f"Work directly as the author repairing ONE project, {project}. Read {directory / 'author-task.md'}, the shared contract in {root / 'skill/references/review-policy.md'}, the raw findings at {findings}, {folder / 'review-context.md'} and all its parts, and the complete current-run sources. The context retains earlier findings from both readers; a later reader's silence does not resolve them. Check those against the current draft before using the last correction round. Address every still-valid finding with targeted claim/excerpt corrections in {directory / 'content.json'}. Candidate directories are helper outputs, not author input paths. For each affected business clause, find every occurrence in the headline, section items/cards/timelines, links.context and weekly rationale, progress.basis, evidence, risk and next_action; independently check and correct each occurrence's selected excerpts, not only the fields named by the reader. Preserve supported results and self-check every cited field, clause by clause, for material omissions, conflicting accounts and unsupported clauses before rendering v{number}. First run the author-task JSON syntax check on that exact author input; checking a candidate output does not validate the draft. Then use the exact render command from author-task.md, changing only --version to {version} and retaining the v prefix. Continue through all fields after finding a gap and correct them together. A self-check is not approval. Keep a short note at {directory / f'repair-{version}-note.md'} mapping each finding to all affected fields/sources, including repeated clauses; do not assign a verdict. Preserve all earlier candidates/replies. Do not delegate, review yourself or change candidate identities."
        else:
            row["next_action"] = "resolve the recorded artifact/response error; do not infer a pass"
            continue
        if phase == "author":
            task = directory / "author-task.md"
        elif phase == "review":
            task = folder / (
                "confirmation-task.md"
                if row["state"] == "pending_confirmation"
                else "review-task.md"
            )
        else:
            suffix = (
                f"-after-attempt-{row['render_attempts']}"
                if row["state"] == "render_failed"
                else ""
            )
            task = directory / f"repair-{version}{suffix}-task.md"
            if not task.resolve().is_relative_to(root.resolve()):
                raise ValueError(f"current-run task is outside this run: {task}")
            body = (
                f"# Repair {project} / {version}\n\nRun ID: {state['run_id']}\n"
                f"Run root: {root}\nInput candidate: {row.get('candidate', 'not rendered')}\n\n"
                + prompt
                + "\n"
            )
            if task.exists():
                if task.read_text(encoding="utf-8") != body:
                    raise ValueError(f"saved current-run task changed; preserve it: {task}")
            else:
                with task.open("x", encoding="utf-8") as handle:
                    handle.write(body)
        if not task.is_file() or not task.resolve().is_relative_to(root.resolve()):
            raise ValueError(f"current-run task is missing or outside this run: {task}")
        task_candidate = (
            row.get("review_candidate")
            if row["state"] == "pending_confirmation"
            else row.get("candidate")
        )
        assignment = dict(
            project=project,
            phase=phase,
            version=version,
            run_id=state["run_id"],
            candidate=task_candidate,
            task_file=str(task),
        )
        job = {
            "agent": "default",
            "prompt": (
                f"Execute the {phase} task for {project}, run {state['run_id']}, "
                f"version {version}, input candidate {task_candidate or 'not rendered'}. "
                f"Read this exact task file: {task}. "
                f"All report inputs/outputs belong under {root}. "
                "Check its run/candidate identity before acting. If the file is missing or "
                "conflicts with this assignment, stop and report the mismatch; never search "
                "the workspace for another task or report. Work directly without delegation."
            ),
        }
        groups[phase].append((project, job, assignment))
    result = []
    for phase, items in groups.items():
        for offset in range(0, len(items), 3):
            batch = items[offset : offset + 3]
            result.append(
                {
                    "phase": phase,
                    "projects": [x[0] for x in batch],
                    "tasks": [x[2] for x in batch],
                    "spawn": {
                        "agent": "default",
                        "mode": "parallel",
                        "prompt": json.dumps([x[1] for x in batch], ensure_ascii=False),
                    },
                }
            )
    return result


def handoff(
    root: Path, manifest: dict, state: dict, report, runner: Path, next_command: str
) -> dict:
    state["batches"] = batches(root, state)
    # Full spawn payloads are saved locally; the short plan note survives context
    # loss without copying every source, task or verdict into the chat.
    path = root / "resume.json"
    state["handoff"] = str(root / "RESUME.md")
    state["next_command"] = next_command
    state["plan_note"] = (
        f"Report run {manifest['run_id']}; source {manifest['revision']}; "
        f"{state['ready']}/{state['total']} reviewed ready; "
        f"next dispatch: {next_command}; read {state['handoff']}. "
        "Recompute state before claiming progress or preparing a draft."
    )
    report.write_atomic(path, json.dumps(state, ensure_ascii=False, indent=2) + "\n")
    body = f"""# Continue this report run

{state["plan_note"]}

Current filesystem state: {state["ready"]}/{state["total"]} reviewed ready.
Local preview: {state["preview"]}
Get one complete next dispatch, without summarizing a portfolio-sized payload:
{next_command}
Full recovery state: {path}; the diagnostic command
python "{runner}" resume exposes that complete state when needed. Its batches are
diagnostic only; only next reserves a reader slot for dispatch.

Copy plan_note into the parent plan BEFORE delegation. The top-level parent owns
coordination. Pass next's spawn object unchanged. Do not shorten its prompts, invent
repair-task.md, or replace absolute paths with "its candidate/v2". Dispatch one
bounded batch at a time; each job is one project and
must execute directly. Never delegate the whole portfolio to a new coordinator.
Review batches use the existing native spawn interface. Each independent reader
writes its own revisable draft, then executes its task's submit-review command.
Only a validated reply is committed unchanged to an immutable canonical file.
The reader returns the saved path/receipt, never a second JSON verdict. Sources
and candidates stay read-only; no shared scratch file or cleanup is part of review.
The next command reads only committed canonical reviews. It reserves each reader
slot once before returning its batch. A reservation does not prove the reader started.
Without a valid submission, even with no draft or a lost dispatch response, preserve
the reservation and report the interruption; never start a replacement reader or
skip to another version. An existing draft belongs to its original reader: let that
reader correct and submit it. A reservation is not a draft to submit. Old runs require their
own frozen helper. Never reconstruct a reply from a summary or infer review_mode. A primary ready in a new run is pending until a
different reader completes its one independent confirmation of the SAME candidate.
Either reader's material blocker goes to the remaining bounded correction round.

Use author batches first to cover every selected project, then review and repair.
After every batch or service interruption, execute next_command again and copy its
updated plan_note into the main plan, even while the same phase continues. Use its
complete spawn object rather than summarizing all batches and reconstructing tasks. Do not trust the
counts in this cached file, prior chat messages or plan checkmarks. The latest
candidate needs its own review; an older pass cannot approve a newer revision.
A remaining blocker stops that project's retries, not the other projects.

Before final delivery verify the exact prepared draft task IDs through KB tools.
If a task is cancelled/restarted, it is not the receipt for a separately created
PR. Do not stage placeholders or replace this run with old PR HTML. A missing
installed skill is a runtime/version problem: use this captured run's documented
helper for recovery, or report the missing capability; never relabel old pages.
"""
    report.write_atomic(Path(state["handoff"]), body)
    return state
