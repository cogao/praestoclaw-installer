"""Write-once render reservations survive a new author or coordinator process."""

from __future__ import annotations

import hashlib
import json
import os
import re
from contextlib import contextmanager
from pathlib import Path

LIMIT = 3


@contextmanager
def locked(project: Path):
    """Kernel-released lock serializes admission and the complete render write."""
    with (project / ".render.lock").open("a+b") as handle:
        if os.name == "nt":
            import msvcrt

            if handle.seek(0, 2) == 0:
                handle.write(b"0")
                handle.flush()
            handle.seek(0)
            try:
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as exc:
                raise ValueError("render_in_progress: another process owns this project") from exc
        else:
            import fcntl

            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError as exc:
                raise ValueError("render_in_progress: another process owns this project") from exc
        try:
            yield
        finally:
            if os.name == "nt":
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def complete(project: Path, version: str, records: list[dict]) -> bool:
    folder = project / "candidate" / version
    return (not records or records[-1]["result"].get("ok") is True) and all(
        (folder / name).is_file()
        for name in ["review-packet.json", "index.html", "content.json", "review-task.md"]
    )


def histories(project: Path, run_id: str) -> dict[str, list[dict]]:
    result = {}
    for directory in (project / "render-attempts").glob("v*"):
        if not re.fullmatch(r"v[1-9][0-9]*", directory.name):
            raise ValueError("invalid render attempt version; preserve the attempt records")
        records = []
        for claim in sorted(directory.glob("attempt-*.json")):
            if claim.name.endswith(".result.json"):
                continue
            record = json.loads(claim.read_text(encoding="utf-8"))
            if not isinstance(record, dict):
                raise ValueError("invalid render attempt object; preserve the original record")
            if record.get("run_id") != run_id or record.get("version") != directory.name:
                raise ValueError("render attempt belongs to a different run/version")
            expected = f"attempt-{len(records) + 1}.json"
            if (
                claim.name != expected
                or len(records) >= LIMIT
                or type(record.get("attempt")) is not int
                or record["attempt"] != len(records) + 1
            ):
                raise ValueError("render attempt sequence is invalid; do not reset it")
            result_path = claim.with_suffix(".result.json")
            record["result"] = (
                json.loads(result_path.read_text(encoding="utf-8"))
                if result_path.exists()
                else {"ok": False, "error": "interrupted render; reservation remains consumed"}
            )
            outcome = record["result"]
            if (
                not isinstance(outcome, dict)
                or type(outcome.get("ok")) is not bool
                or not isinstance(outcome.get("error"), str)
            ):
                raise ValueError("invalid render result object; preserve the original record")
            records.append(record)
        if records:
            result[directory.name] = records
    return result


def reserve(project: Path, run_id: str, version: str) -> Path:
    existing = histories(project, run_id)
    known = set(existing) | {
        p.name
        for p in (project / "candidate").glob("v*")
        if p.is_dir() and re.fullmatch(r"v[1-9][0-9]*", p.name)
    }
    newest = max((int(name[1:]) for name in known), default=0)
    number = int(version[1:])
    if number < newest:
        raise ValueError("cannot render an older version after a newer candidate or attempt")
    if number > newest + 1:
        raise ValueError("use the next version in sequence; versions cannot reset attempts")
    for previous in known:
        records = existing.get(previous, [])
        if previous != version and not complete(project, previous, records):
            reason = "render_budget_exhausted" if len(records) >= LIMIT else "unfinished_render"
            raise ValueError(
                f"{reason}: preserve incomplete {previous}; changing versions cannot reset attempts"
            )
    candidate = project / "candidate" / version
    if (candidate / "index.html").exists() or (candidate / "review-packet.json").exists():
        raise ValueError("preserve the frozen candidate; a material revision needs a new version")
    directory = project / "render-attempts" / version
    directory.mkdir(parents=True, exist_ok=True)
    content = project / "content.json"
    fingerprint = hashlib.sha256(content.read_bytes()).hexdigest() if content.is_file() else None
    for number in range(1, LIMIT + 1):
        claim = directory / f"attempt-{number}.json"
        try:
            with claim.open("x", encoding="utf-8", newline="\n") as handle:
                json.dump(
                    {
                        "run_id": run_id,
                        "version": version,
                        "attempt": number,
                        "content_sha256": fingerprint,
                    },
                    handle,
                )
            return claim
        except FileExistsError:
            continue
    raise ValueError(
        f"render_budget_exhausted: {version} used {LIMIT} render attempts; preserve its errors"
    )


def finish(claim: Path, *, ok: bool, error: str = "") -> None:
    with claim.with_suffix(".result.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"ok": ok, "error": error}, handle, ensure_ascii=False)
