"""Prepare selected reports and optional DRI card links as one KB draft. No Git writes."""

from __future__ import annotations

import argparse
import importlib.util
import json
import posixpath
import re
import subprocess
from datetime import date
from html import escape
from html.parser import HTMLParser
from pathlib import Path, PurePosixPath
from string import Template
from urllib.parse import quote

import yaml

REPORT_MARKER = "<!-- generated-by: feature-owner-auto-report -->"
INDEX_MARKER = "<!-- generated-by: feature-owner-auto-report-index -->"
BACKLINKS = "feature-report-navigation"
PROJECT_STATES = {
    "planned": "计划中",
    "active": "进行中",
    "blocked": "受阻",
    "closed": "已关闭",
    "paused": "暂停",
}
VOID_TAGS = {
    "area",
    "base",
    "br",
    "col",
    "embed",
    "hr",
    "img",
    "input",
    "link",
    "meta",
    "param",
    "source",
    "track",
    "wbr",
}


class PublicationError(ValueError):
    pass


def git(repo: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(repo), *args]).decode("utf-8")


def tree_entry(repo: Path, revision: str, path: str) -> str | None:
    """Include mode, object type and blob identity; absence is a protected state."""
    entry = git(repo, "ls-tree", "-z", revision, "--", path).rstrip("\0")
    if not entry:
        return None
    metadata, _, actual = entry.partition("\t")
    if actual != path:
        raise PublicationError(f"cannot establish the exact publication target: {path}")
    return metadata


def check_governance(repo: Path, source: str, base: str, root: str, targets=()) -> None:
    if source == base:
        return
    module = review_module()
    rules = set(module.repository_rule_paths(PurePosixPath(root), list(targets)))
    rules.add(root + "/projects.yaml")
    delegated = set()
    for revision in (source, base):
        for path in sorted(rules):
            entry = tree_entry(repo, revision, path)
            if not entry:
                continue
            if entry.split()[0] not in {"100644", "100755"} or entry.split()[1] != "blob":
                raise PublicationError(f"governance path is not a document: {path}")
            body = git(repo, "cat-file", "blob", f"{revision}:{path}")
            delegated.update(module.referenced_rule_paths(path, body))
    # Git does not follow directory symlinks: a governed leaf can look absent
    # at both commits even when its effective contents changed behind an alias.
    ancestors = {
        str(parent)
        for path in rules | delegated
        for parent in PurePosixPath(path).parents
        if str(parent) != "."
    }
    for revision in (source, base):
        for path in sorted(ancestors):
            entry = tree_entry(repo, revision, path)
            if entry and entry.split()[1] != "tree":
                raise PublicationError(f"governance ancestor is not a tree: {path}")
    for path in delegated:
        for revision in (source, base):
            entry = tree_entry(repo, revision, path)
            if entry and (
                entry.split()[0] not in {"100644", "100755"} or entry.split()[1] != "blob"
            ):
                raise PublicationError(f"governance path is not a document: {path}")
    changed = [
        path
        for path in sorted(rules | delegated)
        if tree_entry(repo, source, path) != tree_entry(repo, base, path)
    ]
    if changed:
        raise PublicationError(
            "publication governance/registry changed since the source capture; "
            "read and reconcile the new rules before preparing a new run: " + ", ".join(changed)
        )


def repo_path(value: str) -> str:
    path = PurePosixPath(value)
    if (
        not value
        or not path.parts
        or path.is_absolute()
        or ".." in path.parts
        or "\\" in value
        or any(ord(c) < 32 for c in value)
    ):
        raise PublicationError("paths must be repository-relative and cannot escape the repository")
    return str(path)


def canonical_targets(values: dict) -> dict:
    result = {}
    for raw_path, value in values.items():
        path = repo_path(raw_path)
        if path in result:
            raise PublicationError("report/review targets must be distinct canonical paths")
        result[path] = value
    return result


def relative_url(target: str, source: str) -> str:
    return quote(posixpath.relpath(target, posixpath.dirname(source) or "."), safe="/")


class Page(HTMLParser):
    """Locate generated slots without reserializing the original page."""

    def __init__(self, content: str):
        super().__init__(convert_charrefs=True)
        self.content = content
        self.offsets = [0]
        for line in content.splitlines(keepends=True):
            self.offsets.append(self.offsets[-1] + len(line))
        self.mains: list[tuple[dict, int]] = []
        self.slots: dict[str, list[tuple[int, int]]] = {BACKLINKS: []}
        self.pending: list[tuple[str, str, int]] = []
        self.links: list[str] = []
        self.heading: list[str] = []
        self.in_heading = False
        self.meta: dict[str, str] = {}
        self.fields: dict[str, list[str]] = {
            key: [] for key in ("weekly-heading", "status-badge", "source-meta")
        }
        self.frames: list[tuple[str, set[str]]] = []
        self.feed(content)
        if self.pending:
            raise PublicationError("unclosed generated navigation slot")

    def position(self) -> int:
        line, column = self.getpos()
        return self.offsets[line - 1] + column

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if tag not in VOID_TAGS:
            fields = self.frames[-1][1].copy() if self.frames else set()
            fields.update(set((values.get("class") or "").split()) & self.fields.keys())
            self.frames.append((tag, fields))
        if tag == "meta" and values.get("name", "").startswith("report-"):
            self.meta[values["name"]] = values.get("content", "")
        start = self.position()
        if tag == "a" and values.get("href"):
            self.links.append(values["href"])
        if tag == "main":
            self.mains.append((values, start + len(self.get_starttag_text())))
        for marker in self.slots:
            if f"data-{marker}" in values:
                self.pending.append((tag, marker, start))
        if tag == "h1" and not self.heading:
            self.in_heading = True

    def handle_endtag(self, tag):
        for i in range(len(self.frames) - 1, -1, -1):
            if self.frames[i][0] == tag:
                del self.frames[i:]
                break
        if tag == "h1":
            self.in_heading = False
        if self.pending and self.pending[-1][0] == tag:
            _, marker, start = self.pending.pop()
            end = self.content.find(">", self.position()) + 1
            self.slots[marker].append((start, end))

    def handle_data(self, data):
        if self.frames:
            for field in self.frames[-1][1]:
                self.fields[field].append(data)
        if self.in_heading:
            self.heading.append(data)

    @property
    def title(self) -> str:
        value = " ".join("".join(self.heading).split())
        if not value:
            raise PublicationError("report page needs a readable h1 title")
        return value

    def report_metadata(self) -> dict[str, str]:
        """Read the report's snapshot, including pre-metadata weekly pages."""
        weeks = set(re.findall(r"\b\d{4}-W\d{2}\b", " ".join(self.fields["weekly-heading"])))
        explicit = self.meta.get("report-week", "")
        if explicit:
            if not re.fullmatch(r"\d{4}-W\d{2}", explicit):
                raise PublicationError("invalid report week metadata")
            weeks.add(explicit)
        if len(weeks) > 1:
            raise PublicationError("conflicting report week metadata and visible heading")
        record = " ".join(self.fields["source-meta"])
        match = re.search(r"源文档更新\s*(\d{4}-\d{2}-\d{2})", record)
        updated = self.meta.get("report-updated") or (match[1] if match else "")
        try:
            updated = date.fromisoformat(updated).isoformat()
        except ValueError:
            updated = ""
        badge = "".join(self.fields["status-badge"]).strip()
        legacy_status = next(
            (key for key, label in PROJECT_STATES.items() if badge in {key, label}), "unknown"
        )
        status = self.meta.get("report-status") or legacy_status
        match = re.search(r"页面生成\s+(\d{4}-\d\d-\d\dT[^<\s]+)", self.content)
        generated = self.meta.get("report-generated") or (match[1] if match else "未记录")
        return dict(week=next(iter(weeks), ""), updated=updated, status=status, generated=generated)


def insert_slot(content: str, marker: str, snippet: str, *, main_id: str | None = None) -> str:
    page = Page(content)
    slots = page.slots[marker]
    if len(slots) > 1:
        raise PublicationError("duplicate generated navigation slots; review the existing page")
    mains = [item for item in page.mains if main_id is None or item[0].get("id") == main_id]
    if len(mains) != 1:
        raise PublicationError(
            "expected one main content anchor; keep the original homepage intact"
        )
    if slots:
        start, end = slots[0]
        return content[:start] + snippet + content[end:]
    at = mains[0][1]
    newline = "\r\n" if "\r\n" in content else "\n"
    return content[:at] + newline + snippet + content[at:]


def report_kind(path: str, root: str) -> str | None:
    parts = PurePosixPath(path).parts
    prefix = PurePosixPath(root).parts
    rest = parts[len(prefix) :]
    if parts[: len(prefix)] != prefix or len(rest) != 3 or rest[2] != "index.html":
        return None
    return {"owners": "owner", "projects": "project"}.get(rest[0])


class DriPage(HTMLParser):
    """Locate explicit project cards; preserve every other byte of the DRI page."""

    def __init__(self, content: str):
        super().__init__(convert_charrefs=True)
        self.content = content
        self.offsets = [0]
        for line in content.splitlines(keepends=True):
            self.offsets.append(self.offsets[-1] + len(line))
        self.stack: list[tuple[str, dict, int]] = []
        self.cards: dict[str, list[tuple[int, int, str]]] = {}
        self.feed(content)
        if any(values.get("data-project") for _, values, _ in self.stack):
            raise PublicationError("unclosed DRI project card")

    def position(self) -> int:
        line, column = self.getpos()
        return self.offsets[line - 1] + column

    def handle_starttag(self, tag, attrs):
        if tag not in {
            "area",
            "base",
            "br",
            "col",
            "embed",
            "hr",
            "img",
            "input",
            "link",
            "meta",
            "param",
            "source",
            "track",
            "wbr",
        }:
            self.stack.append((tag, dict(attrs), self.position()))

    def handle_startendtag(self, tag, attrs):
        pass

    def handle_endtag(self, tag):
        if not self.stack or self.stack[-1][0] != tag:
            return
        _, values, start = self.stack.pop()
        project_id = values.get("data-project")
        if project_id:
            end = self.position()
            self.cards.setdefault(project_id, []).append((start, end, self.content[start:end]))


def link_dri_cards(content: str, path: str, targets: dict[str, str]) -> str:
    page = DriPage(content)
    edits = []
    newline = "\r\n" if "\r\n" in content else "\n"
    for project_id, target in targets.items():
        cards = page.cards.get(project_id, [])
        if len(cards) != 1:
            raise PublicationError(f"expected exactly one DRI card for project {project_id}")
        _, end, card = cards[0]
        href = relative_url(target, path)
        if href in Page(card).links:
            continue
        # Do not silently replace a previous/custom report target.
        if "data-feature-report-link" in card:
            raise PublicationError(f"review the existing report link for project {project_id}")
        edits.append(
            (end, f'{newline}<a data-feature-report-link href="{href}">项目简报 ↗</a>{newline}')
        )
    for at, snippet in sorted(edits, reverse=True):
        content = content[:at] + snippet + content[at:]
    return content


def registry_projects(registry: str) -> dict:
    data = yaml.safe_load(registry)
    entries = data.get("projects") if isinstance(data, dict) else None
    if not isinstance(entries, list) or any(
        not isinstance(p, dict) or not isinstance(p.get("id"), str) for p in entries
    ):
        raise PublicationError("the report index requires the local project registry")
    return {p["id"]: p for p in entries}


def index_page(root: str, reports: dict[str, str], registry: str) -> str:
    """Directory of actual HTML files, with dates from each saved report."""
    projects = registry_projects(registry)
    owners = {owner for p in projects.values() if (owner := str(p.get("owner") or "").strip())}
    rows, people = [], []
    pages = {path: Page(content) for path, content in reports.items()}
    metadata = {path: page.report_metadata() for path, page in pages.items()}
    closed_count = 0
    ordered = sorted(
        reports.items(),
        key=lambda item: (
            report_kind(item[0], root) != "project",
            metadata[item[0]]["status"] == "closed",
            -date.fromisoformat(metadata[item[0]]["updated"]).toordinal()
            if metadata[item[0]]["updated"]
            else 0,
            str(projects.get(PurePosixPath(item[0]).parent.name, {}).get("number", "")).zfill(6),
            item[0],
        ),
    )
    for path, _content in ordered:
        kind = report_kind(path, root)
        page = pages[path]
        info = metadata[path]
        if kind == "project":
            identity = projects.get(PurePosixPath(path).parent.name)
            if not identity:
                continue
            owner = str(identity.get("owner") or "").strip() or "未登记"
            number = str(identity.get("number", "—"))
            project_name = str(identity.get("name") or identity["id"])
        else:
            owner = page.meta.get("report-owner") or page.title
            if owner not in owners:
                continue
            number = ""
        generated = info["generated"]
        week = info["week"] or "项目概览"
        href = relative_url(path, root + "/index.html")
        if kind == "project":
            status = info["status"]
            closed = status == "closed"
            closed_count += closed
            hidden = " hidden" if closed else ""
            state = PROJECT_STATES.get(status, "未登记")
            rows.append(
                f'<tr data-owner="{escape(owner, quote=True)}" data-status="{escape(status, quote=True)}" data-updated="{info["updated"]}" data-number="{escape(number, quote=True)}"{hidden}>'
                f'<td><span class="project-number">{escape(number.zfill(2))}</span>'
                f'<a href="{href}">{escape(project_name)}</a></td>'
                f'<td data-label="Owner">{escape(owner)}</td>'
                f'<td data-label="项目状态"><span class="project-state">{state}</span></td>'
                f'<td data-label="报告周次">{escape(week)}<small title="{escape(generated, quote=True)}">生成 {escape(generated[:10])}</small></td>'
                f'<td data-label="项目记录更新">{info["updated"] or "未登记"}</td></tr>'
            )
        else:
            people.append(
                f'<li><a href="{href}">{escape(owner)} <span aria-hidden="true">↗</span></a>'
                f'<span class="saved-date" title="{escape(generated, quote=True)}">生成于 {escape(generated[:10])}</span></li>'
            )
    options = "".join(
        f'<option value="{escape(owner, quote=True)}">{escape(owner)}</option>'
        for owner in sorted(owners)
    )
    assets = Path(__file__).resolve().parents[1] / "assets"
    return Template((assets / "report-index.html").read_text(encoding="utf-8")).substitute(
        marker=INDEX_MARKER,
        styles=(assets / "report-index.css").read_text(encoding="utf-8"),
        area_title=escape(PurePosixPath(root).name),
        rows="\n".join(rows),
        people="\n".join(people) or "<li>暂无个人报告。</li>",
        project_count=len(rows),
        open_count=len(rows) - closed_count,
        closed_count=closed_count,
        owner_options=options,
    )


def review_module():
    spec = importlib.util.spec_from_file_location(
        "feature_report_review", Path(__file__).with_name("review.py")
    )
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def catalog_summary(root: str, reports: dict[str, str], registry: str | None = None) -> dict:
    registered = registry_projects(registry) if registry is not None else None
    owners = {p.get("owner") for p in registered.values()} if registered is not None else None
    project_states, owner_count = [], 0
    for path, html in reports.items():
        page = Page(html)
        if report_kind(path, root) == "project":
            if registered is None or PurePosixPath(path).parent.name in registered:
                project_states.append(page.report_metadata()["status"])
        elif report_kind(path, root) == "owner":
            if owners is None or (page.meta.get("report-owner") or page.title) in owners:
                owner_count += 1
    closed = project_states.count("closed")
    return dict(
        projects=len(project_states),
        closed=closed,
        unclosed=len(project_states) - closed,
        owners=owner_count,
    )


def prepare_publication(
    repo: Path,
    revision: str,
    root: str,
    reports: dict[str, str],
    task_id: str,
    *,
    source_revision: str | None = None,
    dri_page: str | None = None,
    include_index: bool = False,
    include_weekly: bool = False,
    reviews: dict | None = None,
    batch: str = "all",
    rules_bundle: dict | None = None,
) -> dict:
    root = repo_path(root)
    reports = canonical_targets(reports)
    reviews = canonical_targets(reviews or {})
    if set(reviews) - set(reports):
        raise PublicationError("each review must match a selected report")
    if batch == "weekly" and not include_weekly:
        raise PublicationError("weekly batch requires --weekly")
    if batch not in {"all", "primary", "navigation", "weekly"}:
        raise PublicationError("batch must be all, primary, navigation or weekly")
    if not task_id or (not reports and not include_index):
        raise PublicationError(
            "a draft task and selected reports or an explicit index refresh are required"
        )
    head = git(repo, "rev-parse", "--verify", "--end-of-options", revision + "^{commit}").strip()
    source_head = git(
        repo,
        "rev-parse",
        "--verify",
        "--end-of-options",
        (source_revision or revision) + "^{commit}",
    ).strip()
    if source_head != head:
        ancestor = subprocess.run(
            ["git", "-C", str(repo), "merge-base", "--is-ancestor", source_head, head]
        )
        if ancestor.returncode:
            raise PublicationError("publication base must contain the fixed source revision")
    check_governance(repo, source_head, head, root)
    paths = {p for p in git(repo, "ls-tree", "-r", "--name-only", "-z", head).split("\0") if p}
    original, proposed, titles, project_targets = {}, {}, {}, {}
    index_path = root + "/index.html"
    if index_path in paths:
        original[index_path] = git(repo, "cat-file", "blob", f"{head}:{index_path}")
        # Once explicitly installed, keep this same managed directory in sync.
        include_index = include_index or original[index_path].startswith(INDEX_MARKER)
    if (
        include_index
        and index_path in original
        and not original[index_path].startswith(INDEX_MARKER)
    ):
        raise PublicationError("refusing to replace an unmanaged area index")
    if dri_page is not None:
        dri_page = repo_path(dri_page)
        if (
            not PurePosixPath(dri_page).is_relative_to(root)
            or not dri_page.endswith(".html")
            or dri_page not in paths
            or report_kind(dri_page, root)
        ):
            raise PublicationError("DRI page must already exist inside the selected KB area")
        original[dri_page] = git(repo, "cat-file", "blob", f"{head}:{dri_page}")
    for path, content in reports.items():
        kind = report_kind(path, root)
        if not kind or path in proposed:
            raise PublicationError(
                "report targets must be distinct canonical owner/project index pages"
            )
        page = Page(content)
        if page.meta.get("report-format") != "2" or not {
            "report-owner",
            "report-week",
            "report-generated",
            "report-status",
            "report-updated",
        }.issubset(page.meta):
            raise PublicationError(
                "selected report must be regenerated with the current renderer; use --index without --report for navigation-only refresh"
            )
        if (
            not content.startswith(REPORT_MARKER)
            or len(page.mains) != 1
            or page.mains[0][0].get("data-report-type") != kind
        ):
            raise PublicationError("report HTML must come from the matching project/owner renderer")
        if path in paths:
            original[path] = git(repo, "cat-file", "blob", f"{head}:{path}")
            if not original[path].startswith(REPORT_MARKER):
                raise PublicationError("refusing to replace a report not generated by this skill")
        titles[path] = page.title
        # Strip only this generator's old navigation from the requested report;
        # never resurrect a directory or mutate unrelated reports/homepages.
        links = []
        if include_index:
            links.append(f'<a href="{relative_url(index_path, path)}">返回报告入口</a>')
        if kind == "project" and dri_page:
            project_targets[PurePosixPath(path).parent.name] = path
            links.append(f'<a href="{relative_url(dri_page, path)}">返回 DRI 汇报</a>')
        snippet = (
            f'<nav class="report-navigation" data-{BACKLINKS} aria-label="报告导航">'
            + "".join(links)
            + "</nav>"
            if links
            else ""
        )
        proposed[path] = (
            insert_slot(content, BACKLINKS, snippet)
            if snippet or page.slots[BACKLINKS]
            else content
        )
    if dri_page:
        if not project_targets:
            raise PublicationError("DRI card linking requires a selected project report")
        proposed[dri_page] = link_dri_cards(original[dri_page], dri_page, project_targets)
    if include_index:
        registry_path = root + "/projects.yaml"
        if registry_path not in paths:
            raise PublicationError("the report index requires the local project registry")
        registry = git(repo, "cat-file", "blob", f"{head}:{registry_path}")
        registered = registry_projects(registry)
        owners = {p.get("owner") for p in registered.values()}
        catalog = {p: c for p, c in proposed.items() if report_kind(p, root)}
        for path in sorted(paths):
            if not report_kind(path, root) or path in catalog:
                continue
            content = git(repo, "cat-file", "blob", f"{head}:{path}")
            if not content.startswith(REPORT_MARKER):
                continue
            page = Page(content)
            if report_kind(path, root) == "project":
                if PurePosixPath(path).parent.name not in registered:
                    continue
            elif (page.meta.get("report-owner") or page.title) not in owners:
                continue
            original[path] = content
            # Only navigation changes on existing reports; preserve their dates,
            # facts, citations and any already installed DRI return link.
            link = f'<a href="{relative_url(index_path, path)}">返回报告入口</a>'
            slots = page.slots[BACKLINKS]
            if slots and report_kind(path, root) == "project":
                start, end = slots[0]
                snippet = content[start:end]
                if relative_url(index_path, path) not in Page(snippet).links:
                    snippet = snippet[: snippet.rfind("</nav>")] + link + "</nav>"
            else:
                snippet = f'<nav class="report-navigation" data-{BACKLINKS} aria-label="报告导航">{link}</nav>'
            catalog[path] = proposed[path] = insert_slot(content, BACKLINKS, snippet)
            titles[path] = page.title
        proposed[index_path] = index_page(root, catalog, registry)
        titles[index_path] = "报告入口"
    # Navigation on already published pages keeps their original facts/dates and
    # needs no new semantic review. Every newly selected report does.
    report_spec = importlib.util.spec_from_file_location(
        "weekly_sources", Path(__file__).with_name("report.py")
    )
    assert report_spec and report_spec.loader
    report_helper = importlib.util.module_from_spec(report_spec)
    report_spec.loader.exec_module(report_helper)
    if include_weekly:
        # Reject an invalid candidate set before examining individual proofs.
        registry_path = root + "/projects.yaml"
        registry_text = git(repo, "cat-file", "blob", f"{source_head}:{registry_path}")
        registered = registry_projects(registry_text)
        expected = {
            str(PurePosixPath(root) / "projects" / key / "index.html") for key in registered
        }
        if expected != {path for path in reports if report_kind(path, root) == "project"}:
            raise PublicationError(
                "weekly consolidation requires exactly the registered project candidates"
            )
    review_modes = {}
    reviewed_rule_targets = set()
    for path, html in reports.items():
        proof = (reviews or {}).get(path)
        if not isinstance(proof, dict) or not {"packet", "verdict"}.issubset(proof):
            raise PublicationError(
                "selected report requires its final review packet and verdict; pass --review TARGET=VERDICT_JSON"
            )
        module = review_module()
        try:
            review_modes[path] = module.validate_publication(proof, html, source_head)
            packet = proof["packet"]
            if packet.get("schema") != 2:
                raise ValueError(
                    "publication requires schema 2; preserve legacy evidence and use "
                    "capture-bundle to create a fresh candidate with both reviews"
                )
            if not packet.get("rules_snapshot_sha256"):
                raise ValueError(
                    "new review packets require a rule snapshot; use capture-bundle "
                    "and create a fresh candidate with both reviews"
                )
            if "rules_snapshot_sha256" in packet:
                if (
                    not isinstance(rules_bundle, dict)
                    or module.digest(report_helper.rule_snapshot(rules_bundle))
                    != packet["rules_snapshot_sha256"]
                ):
                    raise ValueError(
                        "publication requires the frozen --rules-bundle from this candidate"
                    )
                destinations = module.rule_targets(
                    PurePosixPath(root), packet["repository_rule_targets"]
                )
                if not set(destinations).issubset(
                    module.rule_targets(PurePosixPath(root), rules_bundle["rule_targets"])
                ):
                    raise ValueError("candidate target was not captured in the frozen rules bundle")
                if PurePosixPath(path).parent not in {
                    PurePosixPath(p).parent for p in destinations
                }:
                    raise ValueError(
                        "publication target was not covered by the candidate's frozen rules"
                    )
                snapshot = report_helper.rule_snapshot(rules_bundle)
                if (
                    snapshot["source_revision"] != source_head
                    or snapshot["registry_path"] != root + "/projects.yaml"
                ):
                    raise ValueError("rule snapshot differs from the candidate source scope")
                if packet["mode"] == "owner":
                    report_helper.owner_records(
                        packet["source"],
                        packet["content"]["owner"],
                        packet["content"].get("include_closed", False),
                    )
                    expected_rules, expected_targets = report_helper.scoped_repository_rules(
                        rules_bundle,
                        owner_targets=[*[p["path"] for p in packet["source"]["projects"]], path],
                    )
                else:
                    expected_rules, expected_targets = report_helper.scoped_repository_rules(
                        rules_bundle, packet["source"], packet.get("weekly_source")
                    )
                if (
                    set(destinations) != set(expected_targets)
                    or packet.get("repository_rules") != expected_rules
                ):
                    raise ValueError("reader rules differ from the frozen scoped rules")
                reviewed_rule_targets.update(expected_targets)
                if dri_page and PurePosixPath(dri_page).parent not in {
                    PurePosixPath(p).parent for p in rules_bundle["rule_targets"]
                }:
                    raise ValueError("DRI target was not covered by the frozen rules")
            if packet["mode"] == "project" and "weekly" in packet["content"]:
                report_helper.require_fresh_weekly(packet["content"])
            if packet["mode"] != report_kind(path, root):
                raise ValueError("review scope differs from the target report kind")
            if (
                packet["mode"] == "project"
                and packet["content"].get("project_id") != PurePosixPath(path).parent.name
            ):
                raise ValueError("review project differs from the target project")
            for source in module.receipts(packet):
                source_path = repo_path(source["path"])
                if not PurePosixPath(source_path).is_relative_to(root):
                    raise ValueError("review source is outside the selected KB area")
                original_source = git(repo, "cat-file", "blob", f"{source_head}:{source_path}")
                if original_source.splitlines() != module.receipt_lines(source):
                    raise ValueError("review receipt differs from the fixed source revision")
        except (ValueError, KeyError, TypeError) as exc:
            raise PublicationError(f"{path}: {exc}") from exc
    weekly_path = None
    if include_weekly:
        spec = importlib.util.spec_from_file_location(
            "weekly_report", Path(__file__).with_name("weekly.py")
        )
        assert spec and spec.loader
        weekly_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(weekly_module)
        for path, reviewed in reviews.items():
            if report_kind(path, root) == "project":
                report_helper.require_fresh_weekly(reviewed["packet"]["content"])
        project_packet = next(
            review["packet"]
            for path, review in reviews.items()
            if report_kind(path, root) == "project"
        )
        cycle_record = report_helper.weekly_record(
            project_packet["weekly_source"], project_packet["source"]["path"], source_head
        )
        try:
            transferred = weekly_module.goal_coverage(
                yaml.safe_load(registry_text),
                cycle_record,
                report_helper.weekly_goals(cycle_record, None),
            )
        except ValueError as exc:
            raise PublicationError(str(exc)) from exc
        weekly_path, weekly_html = weekly_module.assemble(
            root, reports, transferred=transferred, include_index=include_index
        )
        if weekly_path in paths:
            previous = git(repo, "cat-file", "blob", f"{head}:{weekly_path}")
            if not previous.startswith(weekly_module.MARKER):
                raise PublicationError(
                    "preserve the existing scope-specific weekly template; do not replace an unmanaged page"
                )
            original[weekly_path] = previous
        proposed[weekly_path] = weekly_html
        titles[weekly_path] = "Weekly sync"
        if include_index:
            link = relative_url(weekly_path, index_path)
            proposed[index_path] = proposed[index_path].replace(
                "</nav>",
                f'<a href="{link}">本周目标 · 集中查看 ↗</a></nav>',
                1,
            )
    summary = (
        catalog_summary(root, catalog, registry)
        if include_index
        else catalog_summary(root, reports)
    )
    changes = []
    for path, content in proposed.items():
        if content == original.get(path):
            continue
        if path == dri_page:
            label = "补充 DRI 卡片到项目简报的链接"
        elif path not in reports and report_kind(path, root) == "owner":
            label = f"更新 {titles[path]} 的返回入口导航（保留原正文与日期）"
        else:
            label = f"更新 {titles[path]} 的项目报告"
        changes.append(
            dict(
                path=path,
                operation="update" if path in paths else "create",
                content=content,
                summary=label,
                details=["更新选定报告及已授权的导航；不修改项目事实、周期或其他业务空间。"],
            )
        )
    primary = set(reports) | {index_path, dri_page}
    deferred = []
    if batch != "all":
        selected = [
            c
            for c in changes
            if (
                c["path"] == weekly_path
                if batch == "weekly"
                else c["path"] != weekly_path and (c["path"] in primary) == (batch == "primary")
            )
        ]
        deferred = [c["path"] for c in changes if c not in selected]
        changes = selected
    if changes:
        if not isinstance(rules_bundle, dict):
            raise PublicationError("publication changes require a captured --rules-bundle")
        rule_review = review_module()
        try:
            snapshot = report_helper.rule_snapshot(rules_bundle)
            if (
                snapshot["source_revision"] != source_head
                or snapshot["registry_path"] != root + "/projects.yaml"
            ):
                raise ValueError("rule snapshot differs from the publication source scope")
            frozen = report_helper.repository_rule_records(
                snapshot["rules"], source_head, PurePosixPath(root), snapshot["targets"]
            )
            actual = report_helper.capture_repository_rules(
                repo,
                source_head,
                PurePosixPath(root),
                [
                    *[change["path"] for change in changes],
                    *snapshot["targets"],
                    *sorted(reviewed_rule_targets),
                ],
            )
        except (ValueError, KeyError, TypeError) as exc:
            raise PublicationError(f"invalid publication rules bundle: {exc}") from exc
        actual_rules = {rule["path"]: rule_review.receipt_lines(rule) for rule in actual}
        for path in sorted(set(frozen) | set(actual_rules)):
            if (
                path not in frozen
                or path not in actual_rules
                or frozen[path][1] != actual_rules[path]
            ):
                raise PublicationError(
                    "publication rules were omitted or changed; recapture --rule-target for " + path
                )
    check_governance(repo, source_head, head, root, [change["path"] for change in changes])
    full_replacements = set(reports) | {index_path, weekly_path}
    conflicts = [
        change["path"]
        for change in changes
        if change["path"] in full_replacements
        and tree_entry(repo, source_head, change["path"]) != tree_entry(repo, head, change["path"])
    ]
    if conflicts:
        raise PublicationError(
            "publication targets changed since the source capture; preserve their newer content: "
            + ", ".join(conflicts)
        )
    delivery_summary = {
        "project_pages": sum(
            c["path"] in reports and report_kind(c["path"], root) == "project" for c in changes
        ),
        "owner_reports": sum(
            c["path"] in reports and report_kind(c["path"], root) == "owner" for c in changes
        ),
        "owner_return_navigation_pages": sum(
            c["path"] not in reports
            and c["path"] != dri_page
            and report_kind(c["path"], root) == "owner"
            for c in changes
        ),
        "dri_card_link_pages": sum(c["path"] == dri_page for c in changes),
        "weekly_pages": sum(c["path"] == weekly_path for c in changes),
        "index_pages": sum(c["path"] == index_path for c in changes),
        "changes": [{"path": c["path"], "summary": c["summary"]} for c in changes],
    }
    return dict(
        task_id=task_id,
        delivery_summary=delivery_summary,
        base_revision=head,
        source_revision=source_head,
        target_preimages={
            change["path"]: tree_entry(repo, head, change["path"]) for change in changes
        },
        changes=changes,
        report_summary=summary,
        review_modes=review_modes,
        deferred_paths=deferred,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--repo", type=Path, required=True, help="current KB draft's returned worktree"
    )
    parser.add_argument("--revision", required=True, help="that draft's base_head")
    parser.add_argument(
        "--source-revision", help="fixed report evidence revision; defaults to the draft base"
    )
    parser.add_argument(
        "--root", required=True, help="project area, e.g. 10x-productivity/inner-loop"
    )
    parser.add_argument(
        "--dri-page", help="explicitly selected existing DRI HTML with data-project cards"
    )
    parser.add_argument("--task-id", required=True)
    parser.add_argument(
        "--index", action="store_true", help="create the explicitly approved area index.html"
    )
    parser.add_argument("--weekly", action="store_true", help="authorized consolidated weekly page")
    parser.add_argument("--report", action="append", default=[], metavar="TARGET=LOCAL_HTML")
    parser.add_argument("--review", action="append", default=[], metavar="TARGET=VERDICT_JSON")
    parser.add_argument(
        "--rules-bundle", type=Path, help="original captured source bundle for destination rules"
    )
    parser.add_argument("--packet", action="append", default=[], metavar="TARGET=PACKET_JSON")
    parser.add_argument(
        "--confirmation", action="append", default=[], metavar="TARGET=VERDICT_JSON"
    )
    parser.add_argument(
        "--batch", choices=["all", "primary", "navigation", "weekly"], default="all"
    )
    parser.add_argument(
        "--output", type=Path, required=True, help="JSON proposal file outside the KB worktree"
    )
    args = parser.parse_args()
    try:
        reports, inputs = {}, set()
        for argument in args.report:
            target, separator, source = argument.partition("=")
            if not separator or target in reports:
                raise PublicationError("each --report needs a distinct TARGET=LOCAL_HTML")
            file = Path(source).expanduser().resolve()
            reports[target] = file.read_text(encoding="utf-8")
            inputs.add(file)
        packets, reviews = {}, {}
        for argument in args.packet:
            target, separator, source = argument.partition("=")
            if not separator or target in packets or target not in reports:
                raise PublicationError("each --packet must match a distinct selected report")
            packet_path = Path(source).expanduser().resolve()
            packets[target] = json.loads(packet_path.read_text(encoding="utf-8"))
            inputs.add(packet_path)
        for argument in args.review:
            target, separator, source = argument.partition("=")
            if not separator or target in reviews or target not in reports:
                raise PublicationError("each --review must match a distinct selected report")
            verdict_path = Path(source).expanduser().resolve()
            matches = []
            inputs.add(verdict_path)
            for verdict in review_module().raw_verdicts(verdict_path.read_text(encoding="utf-8")):
                if "candidate" in verdict:
                    if target not in packets:
                        raise PublicationError(
                            "new review replies require --packet TARGET=PACKET_JSON"
                        )
                    packet = packets[target]
                    if verdict["candidate"] == review_module().candidate_id(packet):
                        matches.append(dict(packet=packet, verdict=verdict))
                    continue
                packet_path = Path(verdict["packet_path"]).expanduser()
                if not packet_path.is_absolute():
                    packet_path = verdict_path.parent / packet_path
                packet_path = packet_path.resolve()
                packet = json.loads(packet_path.read_text(encoding="utf-8"))
                inputs.add(packet_path)
                if isinstance(packet, dict) and packet.get("candidate_html") == reports[target]:
                    matches.append(dict(packet=packet, verdict=verdict))
            if len(matches) != 1:
                raise PublicationError(
                    "raw reader response must match exactly one final candidate; do not reconstruct a pass"
                )
            reviews[target] = matches[0]
        confirmed = set()
        for argument in args.confirmation:
            target, separator, source = argument.partition("=")
            if not separator or target not in reviews or target in confirmed:
                raise PublicationError("each --confirmation needs a distinct selected report")
            confirmed.add(target)
            path = Path(source).expanduser().resolve()
            inputs.add(path)
            module = review_module()
            packet = module.confirmation_packet(reviews[target]["packet"])
            matches = [
                v
                for v in module.raw_verdicts(path.read_text(encoding="utf-8"))
                if v.get("candidate") == module.candidate_id(packet)
            ]
            if len(matches) != 1:
                raise PublicationError("confirmation must match exactly one frozen candidate")
            reviews[target]["confirmation"] = matches[0]
        output = args.output.resolve()
        if (
            output.suffix.lower() != ".json"
            or output.is_relative_to(args.repo.resolve())
            or output in inputs
        ):
            raise PublicationError(
                "write proposal JSON outside the KB worktree and preserve report inputs"
            )
        if args.rules_bundle and output == args.rules_bundle.resolve():
            raise PublicationError("preserve the rules bundle input")
        result = prepare_publication(
            args.repo,
            args.revision,
            args.root,
            reports,
            args.task_id,
            source_revision=args.source_revision,
            dri_page=args.dri_page,
            include_index=args.index,
            include_weekly=args.weekly,
            reviews=reviews,
            batch=args.batch,
            rules_bundle=json.loads(args.rules_bundle.read_text(encoding="utf-8"))
            if args.rules_bundle
            else None,
        )
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("x", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
            f.write("\n")
        print(
            json.dumps(
                {
                    "proposal_file": str(output),
                    "paths": [c["path"] for c in result["changes"]],
                    "report_summary": result["report_summary"],
                    "delivery_summary": result["delivery_summary"],
                    "review_modes": result["review_modes"],
                    "deferred_paths": result["deferred_paths"],
                },
                ensure_ascii=True,
            )
        )
    except (OSError, ValueError, subprocess.CalledProcessError) as exc:
        parser.exit(1, f"Publication preparation failed: {exc}\n")


if __name__ == "__main__":
    main()
