"""Assemble one cycle reading surface from already rendered project assessments.

No model call, new business judgement, or source date inference occurs here.
"""

from __future__ import annotations

import html
import re
from pathlib import Path, PurePosixPath
from urllib.parse import quote, urlsplit, urlunsplit

from markdown_it import MarkdownIt

MARKER = "<!-- generated-by: feature-owner-auto-report-weekly -->"


def goal_coverage(registry: dict, cycle_record: tuple, goal_rows: list[dict]) -> list[dict]:
    """Resolve absent projects only with both project and explicit goal migration.

    Project migration cannot dispose of every commitment. Keep one disposition
    per original goal ID, and reject ambiguous or merely historical membership.
    Returned rows retain the baseline and the exact recorded transfer evidence.
    """
    projects = registry.get("projects") if isinstance(registry, dict) else None
    if not isinstance(projects, list) or any(
        not isinstance(p, dict) or not isinstance(p.get("id"), str) for p in projects
    ):
        raise ValueError("weekly consolidation requires the local project registry")
    seen = set()
    for row in goal_rows:
        identity = row.get("goal_id")
        if isinstance(identity, str) and (identity := identity.strip()):
            if identity in seen:
                raise ValueError(
                    "cycle contains duplicate baseline goal IDs; reconcile before consolidation: "
                    + identity
                )
            seen.add(identity)
    registered = {p["id"] for p in projects}
    absent = [row for row in goal_rows if row["project_id"] not in registered]
    if not absent:
        return []
    migrations = registry.get("migrations", [])
    if not isinstance(migrations, list):
        raise ValueError("unregistered goal projects need explicit registry migrations")
    dispositions = {}
    tokens = MarkdownIt("commonmark").enable("table").parse("\n".join(cycle_record[1]))
    headers, cells, start, in_table = None, [], 0, False
    for token in tokens:
        if token.type == "table_open":
            headers, in_table = None, True
        elif token.type == "table_close":
            in_table = False
        elif in_table and token.type == "tr_open":
            cells, start = [], token.map[0] + 1
        elif in_table and token.type == "inline":
            cells.append(token.content.strip())
        elif in_table and token.type == "tr_close":
            if headers is None:
                headers = cells
                continue
            row = dict(zip(headers, cells))
            identity = row.get("原承诺 ID", row.get("Original goal ID"))
            disposition = row.get("当前管理处置", row.get("Management disposition"))
            if identity and disposition is not None:
                dispositions.setdefault(identity, []).append(
                    dict(
                        transfer_line=start,
                        transfer_quote=cycle_record[1][start - 1],
                        disposition=disposition,
                        meaning=row.get("状态含义", row.get("Status meaning", "")),
                    )
                )
    transferred, unresolved = [], []
    for goal in absent:
        identity = goal.get("goal_id")
        if not isinstance(identity, str) or not identity.strip():
            unresolved.append(f"{goal['project_id']} (unnamed goal)")
            continue
        identity = identity.strip()
        migration = [
            item
            for item in migrations
            if isinstance(item, dict) and item.get("id") == goal["project_id"]
        ]
        decisions = dispositions.get(identity, [])
        if (
            len(migration) != 1
            or migration[0].get("direction") != "out"
            or len(decisions) != 1
            or decisions[0]["disposition"].casefold()
            not in {"已转出", "transferred", "transferred out"}
        ):
            unresolved.append(f"{goal['project_id']} ({goal['goal_id'] or 'unnamed goal'})")
            continue
        transferred.append({**goal, **decisions[0], "migration": dict(migration[0])})
    if unresolved:
        raise ValueError(
            "cycle contains unregistered goal projects without confirmed goal-level transfer evidence; "
            "reconcile before complete consolidation: " + ", ".join(unresolved)
        )
    return transferred


def assemble(
    root: str,
    reports: dict[str, str],
    *,
    preview: bool = False,
    transferred: list[dict] | None = None,
    include_index: bool = False,
) -> tuple[str, str]:
    weeks, revisions, tables, phases, unassigned = set(), set(), [], set(), []
    historical = []
    observations = []
    for path, page in reports.items():
        if "/projects/" not in path:
            continue
        match = re.search(r'<section class="weekly-review".*?</section>', page, re.S)
        if not match:
            raise ValueError(f"weekly consolidation requires a weekly assessment: {path}")
        section = match.group()
        week = re.search(r'content="(\d{4}-W\d{2})"', page)
        source = re.search(r'<a class="cycle-link" href="([^"]+)"', section)
        if not week or not source:
            raise ValueError("weekly page needs a named cycle and its full source link")
        weeks.add(week[1])
        revisions.add(source[1])
        # Preserve the assessment type once; each linked project page retains
        # its own generation timestamp separately from its factual cutoff.
        phases.update(
            note.split(" · 判断生成 ", 1)[0]
            for note in re.findall(r'<p class="weekly-phase">(.*?)</p>', section)
        )
        table = re.search(r"<tbody>(.*?)</tbody>", section, re.S)
        title = re.search(r"<h1>(.*?)</h1>", page, re.S)[1]
        identity = PurePosixPath(path).parent.name
        # From <root>/pmo/weekly-cycle/<week>/index.html to canonical project HTML.
        target = html.escape(f"../../../projects/{quote(identity, safe='')}/index.html")
        observation = re.search(r'<div class="weekly-observations">.*?</div>', section, re.S)
        if observation:
            observation_html = observation[0].replace('href="#source-', f'href="{target}#source-')
            observations.append(
                f'<article class="report-section"><h3><a href="{target}">{title} ↗</a></h3>'
                f"{observation_html}</article>"
            )
        rows = table[1].replace('href="#source-', f'href="{target}#source-') if table else ""
        rows = rows.replace(
            '<span class="goal-id">', f'<span class="goal-id">{html.escape(root)} · '
        )
        context = re.findall(r'<p class="weekly-cutoff">.*?</p>', section, re.S)
        # Only the meeting-wide decision follows the table. Row-specific next
        # actions have already been retained in tbody.
        context += re.findall(
            r'<p class="weekly-followup">.*?</p>', section.split("</table>")[-1], re.S
        )
        context_html = "".join(context).replace('href="#source-', f'href="{target}#source-')
        if not table:
            unassigned.append(
                f'<li><a href="{target}">{title} ↗</a> · 本周期未登记周目标，本周目标评估不适用。{context_html}</li>'
            )
            continue
        heading = f'<tr class="weekly-project"><th colspan="4"><a href="{target}">{title} ↗</a>{context_html}</th></tr>'
        original_rows = re.findall(r"<tr\b[^>]*>.*?</tr>", rows, re.S)
        moved = [row for row in original_rows if 'data-goal-scope="transferred"' in row]
        current = [row for row in original_rows if row not in moved]
        if moved:
            historical.append(heading + "".join(moved))
        if current:
            tables.append(heading + "".join(current))
    if len(weeks) != 1 or len(revisions) != 1:
        raise ValueError("weekly consolidation needs one area, cycle and source revision")
    week = weeks.pop()
    cycle = revisions.pop()
    if transferred:
        cycle_url = html.unescape(cycle)
        parsed = urlsplit(cycle_url)
        registry_path = parsed.path.rsplit("/pmo/weekly-cycle/", 1)[0] + "/projects.yaml"
        registry_url = html.escape(
            urlunsplit((parsed.scheme, parsed.netloc, registry_path, "", ""))
        )
        for goal in transferred:
            baseline = html.escape(f"{cycle_url}#L{goal['line']}")
            decision = html.escape(f"{cycle_url}#L{goal['transfer_line']}")
            migration = goal["migration"]
            evidence = (
                f'<a href="{decision}">周期管理处置 ↗</a>'
                f"<pre>{html.escape(goal['transfer_quote'])}</pre>"
                f'<a href="{registry_url}">项目迁出登记 ↗</a>'
                f"<p>{html.escape(migration['id'])} · 已迁出；"
                f"登记决定：{html.escape(str(migration.get('decision') or '未单列'))}</p>"
            )
            historical.append(
                '<tr><td data-label="原目标">'
                f'<span class="goal-id">{html.escape(root)} · {html.escape(goal["goal_id"])}</span>'
                f'{html.escape(goal["goal"])} <a href="{baseline}">原目标 ↗</a></td>'
                f'<td data-label="Owner">{html.escape(goal["owner"] or "未登记")}</td>'
                '<td data-label="管理归属"><span class="transferred-goal" data-goal-scope="transferred">'
                "已转出<small>不参与本周收口</small></span></td>"
                f'<td data-label="迁移依据">{html.escape(goal["disposition"])}；{html.escape(goal["meaning"])}'
                f"<details><summary>管理迁移依据</summary>{evidence}</details></td></tr>"
            )
    # Keep the recorded cycle dates; never turn a pasted PMO interpretation into
    # a source date amendment. Each project's cutoff remains in its linked page.
    date_range = re.search(r'<div class="weekly-heading">.*?<span>(.*?)</span>', section, re.S)[1]
    styles = (Path(__file__).parents[1] / "assets/report.css").read_text(encoding="utf-8")
    label = "本地候选 · 尚未全部复核" if preview else "已复核的周目标判断 · 不等于项目验收"
    no_goals = (
        (
            '<section class="report-section"><h2>本周期未登记周目标</h2><ul>'
            + "".join(unassigned)
            + "</ul></section>"
        )
        if unassigned
        else ""
    )
    transfer_section = (
        '<section class="report-section transferred-goals"><h2>已转出目标</h2>'
        "<p>保留原目标与 Owner；管理迁移不代表完成或取消，不计入本空间当前目标与收口统计。</p>"
        '<table class="weekly-table"><thead><tr><th>原目标</th><th>Owner</th>'
        "<th>管理归属</th><th>迁移依据</th></tr></thead><tbody>"
        + "".join(historical)
        + "</tbody></table></section>"
        if historical
        else ""
    )
    index_link = '<a href="../../../index.html">项目入口 ↗</a>' if include_index else ""
    page = f'''{MARKER}
<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{week} · Weekly sync</title><style>{styles}
.sheet {{ width:min(1420px,calc(100% - 48px)); }}
.weekly-table {{ font-size:14px; }} .weekly-table td {{ padding:16px 12px; }}
.weekly-project th {{ background:#e8efe8; font-size:14px; padding:12px; }}
.weekly-table th:nth-child(3) {{ width:19%; }}
@media(max-width:650px) {{ .sheet {{ width:100%; }} .weekly-project th {{ display:block; }} }}
</style></head><body><main class="sheet"><header class="masthead"><p>{html.escape(root)}</p>{index_link}</header>
<h1>{week} · Weekly sync</h1><p class="purpose">在一页中查看本周目标、进度依据、风险与下一步。</p>
<p class="weekly-phase">{label} · 周期原登记 {date_range}</p>
<p class="weekly-phase">进度为目标级 AI 估计，包含既有基础；证据状态、交付风险与收口状态分别判断。转出目标单列，不重复计入本空间交付。</p>
<p class="weekly-phase">{"；".join(sorted(phases))} · 各项目生成时间见对应项目页</p>
<table class="weekly-table"><thead><tr><th>Weekly goal</th><th>Owner</th><th>Goal progress / close</th><th>Evidence / risk / action</th></tr></thead><tbody>{"".join(tables)}</tbody></table>{transfer_section}{no_goals}{"".join(observations)}
<footer class="bottomline"><a href="{cycle}">完整周期原文 ↗</a><span>页面刷新不修改原目标、日期或项目事实</span></footer></main></body></html>'''
    return f"{root}/pmo/weekly-cycle/{week}/index.html", page
