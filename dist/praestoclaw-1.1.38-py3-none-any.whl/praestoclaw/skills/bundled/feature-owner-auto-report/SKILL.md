---
name: feature-owner-auto-report
description: "Create or refresh short, source-linked project or owner progress pages. Manual requests prepare a KB draft by default; publish only after confirmation. Explicit previews and scheduled runs stay local."
metadata:
  activation:
    match_name_parts: false
    keywords:
      - feature-owner-auto-report
      - one pager
      - one-pager
      - 项目简报
      - 项目报告
      - 项目一页纸
      - 项目向上汇报
      - 向上汇报
      - 开发进度页面
      - feature progress page
      - 项目周会页
      - feature weekly sync page
      - 历史报告
      - 历史简报
      - 上周报告
      - one pager history
      - 个人项目报告
      - 个人开发进度
      - owner report
      - 的 report
      - 的report
    patterns:
      - '(?i)(项目|project).{0,30}(历史|上周|previous|history).{0,16}(报告|简报|report|one[ -]?pager)'
      - '(?i)(查看|回看|导出|打开|history).{0,50}(one[ -]?pager|项目报告|项目简报)'
      - '(?i)(生成|更新|刷新|create|refresh).{0,60}(项目周会页|feature weekly sync page)'
      - '(?i)(生成|刷新|更新|制作)(?!.{0,68}(?:团队|PMO|team)\s*的\s*report).{0,8}[^\W\d_][\w .''-]{0,60}的\s*report'
      - '(?i)(生成|刷新|更新|制作|generate|refresh|create).{0,60}(个人项目报告|个人开发进度|owner report)'
      - '(?i)(?<![a-z0-9_-])feature-owner-auto-report(?![a-z0-9_-])'
      - '(?i)(生成|刷新|更新|制作|给|generate|refresh|create).{0,80}(one[ -]?pager|项目简报|项目报告|项目一页纸|项目向上汇报)'
      - '(?i)(one[ -]?pager|项目简报|项目报告|项目一页纸).{0,60}(生成|刷新|更新|generate|refresh)'
      - '(?i)(项目|project).{0,30}向上汇报'
      - '(?i)(生成|刷新|更新|制作).{0,40}(开发进度|feature progress).{0,16}(页面|page|报告)'
  os: [win32, darwin, linux]
  safe-tools:
    - tool: kb_scope
      match:
        action: '^show$'
    - tool: kb_inspect
      match:
        action: '^repos$'
    - tool: kb_inspect
      match:
        action: '^sync$'
    - tool: kb_inspect
      match:
        action: '^rules$'
    - tool: kb_inspect
      match:
        action: '^tree$'
    - tool: kb_inspect
      match:
        action: '^read$'
    - tool: kb_inspect
      match:
        action: '^search$'
    - tool: kb_change_history
      match:
        action: '^latest$'
    - tool: kb_change_history
      match:
        action: '^show$'
    - tool: kb_change_history
      match:
        action: '^file$'
---

# Feature Owner Auto-report

Create source-linked Chinese HTML that an unfamiliar reader can understand.
A manual request normally produces a KB Draft PR; explicit previews and scheduled
runs stay local. A report can be ready while its project is unfinished.

## Choose the reading surface

- **Project overview:** explain who uses the feature, its practical value, current
  roadmap position, supported impact and existing design/adoption links. Use short
  sentences, a highlighted current node and compact result cards where useful.
  Keep sample windows, estimates and material limitations next to results. Aim for
  200–280 Chinese characters plus English words as editing guidance, never a gate.
- **Weekly sync:** when requested, consolidate the selected area's original weekly
  goals, cumulative goal-progress estimates, dated evidence, risks and next actions
  in its weekly-cycle folder. Project pages keep their weekly assessment in an
  appendix. Transferred goals are tracked separately and never counted twice.
- **Owner report:** when explicitly requested, summarize that owner's registered
  projects without inventing an overall personal status. Resolve the canonical
  owner or trusted sender; clarify ambiguous names. Default to non-closed projects
  unless closed/history is requested. Read [owner content](references/owner-content.md).
- **Saved history:** use [KB change history](references/refresh-and-publication.md#readable-history)
  to retrieve the actual saved HTML; do not regenerate it from today's facts.

For project content/schema read [content format](references/content-format.md).
For weekly assessments also read [weekly content](references/weekly-content.md).
Authors and independent readers share [review policy](references/review-policy.md).
These references define the contracts; do not replace them with a generic summary
extractor, a five-panel template or an inferred lifecycle/percentage.

## Scope and authority

Use the conversation's configured KB repository and scope. Read its current rules,
project registry, presentation paths and complete project records at one revision.
Resolve registry IDs, paths and ownership rather than guessing from names. Include
all explicitly requested projects, including closed projects for a full registry
request. A missing record or conflicting identity is a reported gap, not a silent
exclusion. Evidence comes from this KB and material supplied by the user; external
links are citations, not authorization to search other chats, Teams, mail or ADO.

Read-only KB actions listed above preserve runtime scope and allowlists. An approval
or missing capability is not permission to bypass them with a different tool. In a
shared chat use `skill(action="read", name="feature-owner-auto-report", path=...)`
and that chat's KB binding; do not borrow personal context. If that surface cannot
render HTML, return the supported Markdown report and explain the capability gap.

Respect the target KB's layout. Project `index.html` belongs with its project,
weekly HTML with its cycle, and owner reports/navigation with existing owner pages.
Societas 10x removed `inner-loop/reports/`; do not recreate that old catalog. A new
entry or DRI-card integration requires the request's scope and current KB rules.
Existing owner prose and generation dates must survive navigation-only edits.

## Execute a fresh request

A Plan is bookkeeping, not a running generator. After acknowledging an execution
request, continue with scope/sync and the authorized generation in this turn.
Status questions require actual native task status and current files; do not call
an idle task running or duplicate it. A request only for advice/planning stays in chat.

For project or portfolio generation follow [source review](references/source-review.md):

1. Resolve this installed package once. Obtain complete registry/project/cycle and
   directly linked evidence at one fixed KB revision. An authorized draft may read
   the worktree/base returned by its KB task; do not clone an alternative repo or
   use old PR HTML. Preserve complete source receipts and their revision.
2. `report.py prepare-run` creates a fresh workspace run with the captured helper,
   source views and one author task per project. Pass `--weekly` when a consolidated
   weekly view is requested. Read this run's `RESUME.md`; keep its run ID, source
   and saved `next_command` in the main Plan for interruption recovery.
3. Execute the saved `next_command` to obtain one compact batch, then pass its
   `spawn` object unchanged to native spawn. It carries exact task paths and
   run/candidate identities; do not replace it with project names, guessed repair
   filenames or relative paths. A missing/mismatched task stops that assignment,
   never triggers a search of older runs. Only the parent coordinates, up to three
   jobs per batch. Cover every project's first candidate before repeated repairs.
4. Use a different independent reader for each rendered candidate. Sources and
   candidate files are read-only within the reader's task. It writes its own draft,
   runs the task's `submit-review` command, and returns only the saved path/receipt.
   Format or missing metadata is corrected by that reader before submission; the
   helper never supplies `review_mode` or changes a verdict. This is
   a skill instruction on the ordinary runtime, not an added capability restriction.
   Never use shared scratch paths or reconstruct a pass from a summary.
5. Execute `next_command` after each batch to read submitted reviews, update the Plan's
   actual ready count and obtain the next complete dispatch.
   New prepared runs require one fresh independent confirmation after a primary
   ready. Both readers inspect the same frozen candidate; either one's material
   blockers require correction. Do not show the confirmation reader this version's
   primary verdict. `next` supplies its exact task and distinct candidate identity.
   Each candidate has at most three structural render attempts across processes
   and authors, one primary review and (only after ready) one confirmation. Allow
   at most three candidate versions and two targeted corrections; this adds at most
   three confirmation calls per project without increasing render/version limits.
   Preserve sources, older candidates and raw findings; never
   edit hashes, verdicts or attempt records, change versions to reset a limit, or
   fall back to an older pass after a newer candidate fails.
   `next` reserves each reader slot once before returning its dispatch. If the
   reader never starts, returns no draft, writes elsewhere, or fails to submit,
   preserve that reservation and report the interruption. Only the original
   reader may finish its submission; do not launch a replacement or skip versions.
   `status` and `resume` are diagnostics and do not authorize delegation.
6. Once all requested candidates are ready, follow [draft delivery](references/refresh-and-publication.md).
   Prepare primary project+entry, weekly and navigation batches within the KB's
   document limit. Each uses its actual draft task and destination base revision;
   the source revision stays fixed. Do not edit proposal bindings. Verify the exact
   task IDs, paths and actual PR URLs through KB tools before declaring delivery.

A blocker on one project does not stop other first candidates. Exhausted, incomplete
or damaged candidates remain visible in the run's local preview; report the precise
unresolved fields. A partial preview is not a completed KB draft. After interruption,
resume the identified run rather than creating another coordinator or relabeling
older results. An unavailable installed package or missing run is a capability gap.

## Individual rendering

For an explicit individual/local request, the same schema and source/review rules
apply without a portfolio coordinator. The renderer accepts complete KB receipts;
its capture commands also support an explicitly authorized local checkout. Run
`report.py --help` for flags. Typical commands are:

```text
<python> <skill-dir>/scripts/report.py capture-bundle --repo <authorized-worktree> --revision <fixed-source-head> --registry <root>/projects.yaml --week <YYYY-Www> --rule-target <resolved-owner-destination> --output <source-bundle.json>
<python> <skill-dir>/scripts/report.py render --source <source-bundle.json> --content <content.json> --repo-url <verified-repo-url> --output <report.html> --review-packet <packet.json>
<python> <skill-dir>/scripts/report.py render-owner --source <source-bundle.json> --content <owner-content.json> --rule-target <resolved-owner-destination> --repo-url <verified-repo-url> --output <owner.html> --review-packet <packet.json>
```

Resolve the owner destination through the bound KB scope before capture; it is a
repository-relative path, not a guessed owner slug. For multiple owners, repeat
`capture-bundle --rule-target` for every destination, then select the matching
target in each `render-owner` command. Project-only requests can omit the owner
target. Capture requires the selected `--week` for its source bundle; that does not
itself add a weekly appendix to the rendered content.
Complete individual receipts and historical packets remain usable for previews
and inspection. Publication requires a fresh schema 2 candidate with captured
rules and both reviews; never relabel an old packet to meet the new contract.

Cited claims use exact source excerpts, not invented line ranges. Read complete
sources before composing. Review the final HTML's primary text and all material
claims against the generated packet; important limitations cannot be hidden in
source drawers. Changed content requires a new candidate and independent review.
The helper checks identity, source coverage, citation bounds and review binding;
it does not certify business truth or replace the reader's judgment.

## Return and publication

Return a short Chinese receipt in the current conversation: fixed source revision,
requested coverage, actual Draft PR links and any remaining gaps. Describe local
files as local files, not accessible Teams links. Existing DRI-card links and simple
return-to-index owner navigation are distinct outputs; report what actually changed.
Do not launch a browser by default or put HTML/Adaptive Cards in Teams messages.

A manual request defaults to creating a draft, including when it runs in a native
background worker. Complete the draft without asking the owner to copy/commit/push.
An explicit preview or scheduled report remains local and creates no draft. If
staging is unavailable, preserve the preview and state the exact limitation.
Publication, merging, changing project facts/cycles, new schedules and sending to
other chats require separate authority. Keep daily/weekly PMO checks, progress sync
and ingestion as separate skills; this request does not trigger them.
