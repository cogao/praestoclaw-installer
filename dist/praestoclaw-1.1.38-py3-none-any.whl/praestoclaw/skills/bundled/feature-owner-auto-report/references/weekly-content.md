# Feature weekly-sync input

A weekly page combines two complete `kb_inspect(read)` receipts at the same Git
revision and in the same selected KB area: the project `progress.md` and
`pmo/weekly-cycle/<YYYY-Www>/cycle.md`. Use the requested week, or the runtime's
current week when the request says this week. Do not copy the W38 example's
counts, cutoff or commit into a new report.

Save the actual receipts. `report.py render --weekly-source cycle.json` validates
the cycle path, document type, week and common revision. Ordinary project claims
can keep their existing `text`/`lines` format. A weekly claim that needs both sources uses
`sources`, whose `source_id` is the selected project ID, a captured artifact ID
listed in source-view, or `@cycle`. Owner reports
retain their existing format; this is not the W40 people-manager implementation.

Add this object to normal project content (line numbers here are illustrative,
not a usable report input):

```json
{
  "weekly": {
    "week": "2026-W39",
    "phase": "pre_meeting",
    "as_of": {
      "text": "会议证据截至2026-09-18。",
      "sources": [{"source_id": "@cycle", "quote": "2026-09-18会议形成下周计划。"}]
    },
    "assessments": [{
      "line": 57,
      "close_status": "insufficient",
      "rationale": {
        "text": "运行样本已交付，完整范围及验收日期尚未确认。",
        "sources": [
          {"source_id": "@cycle", "quote": "本目标尚缺完整范围的交付和收口决定。"},
          {"source_id": "the-project-id", "quote": "运行样本已交付，完整范围及验收日期尚未确认。"}
        ]
      }
    }]
  }
}
```

The helper reads goal wording, owner and existing goal ID directly from all cycle
tables with `Project ID` / `Weekly goal` (or 本周目标) / `Owner` columns. A row's
`line` is its actual 1-based source line, not a new business ID. It requires one
assessment for every matching original/added goal row. Extra, duplicate or omitted
rows fail. Goal text in generated JSON cannot rewrite the source goal. If a known
added goal or approved scope change is pending synchronization, expose that gap
and use the existing authorized source-update flow before claiming complete
weekly coverage; do not silently omit it or attach it to unrelated source lines.

When source-view reports no matching goals, still supply `weekly.week`, `phase`,
the cited date-only `as_of`, and `assessments: []`. This retains the cycle evidence window
without inventing a goal or failing because weekly-source has no matching content.
Keep `as_of` to the relevant evidence date/window. The helper's no-goal notice
already expresses computed coverage; neither quote an unrelated goal's results
nor search for a sentence proving absence. Put a retained shared task's latest
relevant result/gap and next action in the project brief; do not move another
project's full assessment into as_of or add a duplicate goal row. Apply the same derived-fact rule from
[the shared review policy](review-policy.md).

Use optional `weekly.observations` for relevant cycle observations outside the
registered goals, including observations about a project whose old goal transferred
out. It is a list of cited claims using the same `text`/`sources` format as rationale.
For example, `"observations": [{"text": "9/24 周期记录展示已发生、可读性待改善；该观察尚未同步到项目资料。", "sources": [{"source_id": "@cycle", "lines": [[148, 148]]}]}]`
uses illustrative lines, not a usable citation. Select the actual source date and
observation; distinguish source-reported facts from pending synchronization and
acceptance. The project page and consolidated weekly page both show this list
under 周期观察（非周目标）. It adds no goal, owner, progress or closeout status and
cannot replace a required assessment. Omit it or use `[]` when unnecessary. Do not
put these observations into `as_of`, an unrelated/transferred goal, or the project
brief merely to satisfy a prior review demand.

Keep the original goal after a reduction/retirement and explain the decision in
the rationale. Missing goals show an explicit inability to assess, not zero work
or all closed. The parser's coverage checks do not establish semantic completeness
of an inconsistently maintained cycle; compare the complete cycle and approved
updates, and identify source conflicts.

The model makes the closeout assessment using the existing PMO contract:

- A goal transferred to another management scope is **not retired or delivered**.
  Set `scope: "transferred"`, omit `close_status` and `closure_basis`, and provide
  cited `rationale` and `decision` claims. Its original row remains visible as
  “已转出 / 不参与本周收口”; exclude it from closed/carry-over/insufficient counts.
  Default `scope: "current"` uses the close statuses below. Read approved changes
  before assigning a status; the helper cannot infer transfer from prose.

- `closed`: evidence covers the complete goal (`closure_basis: "delivered"`), or a
  human decision explicitly retires it (`closure_basis: "retired"` plus a cited
  `decision` claim). Retirement is displayed separately from delivery.
- `carry-over`: the source explicitly confirms moving the remaining commitment
  into a later weekly cycle. Include `carry_over.target_week` (YYYY-Www) and
  `carry_over.decision`, a cited claim whose text names that full later cycle.
  Its selected source text must identify the same cycle: explicit `YYYY-Www`, or
  a standalone `Www` in the captured current `@cycle` for a later week of the
  same year, without conflicting year evidence. Lines-only and exact-quote
  citations follow the same rule; only this decision's actual selection counts,
  never an unselected line or text outside an explicit quote. Cross-year targets
  need the full source-stated year. Normal numeric evidence checks still apply
  to the authored year; select the event's year context rather than invent it.
  Cycle identity alone does not establish this goal's accepted transfer: a
  calendar, another goal, a forecast or a negated proposal is not that decision.
  The independent reader must check the human decision, owner and remaining scope.
  The original goal must have an owner. Also include cited
  `next_action` and `checkpoint` claims: `checkpoint` is an object with `text`
  exactly YYYY-MM-DD and its own `sources`, not a bare date string. Use an agreed
  checkpoint from the source; do not turn a desired deadline into an acceptance
  date. A pending result, an owner's forecast, or a review
  checkpoint within the current week is not a carry-over decision.
- `insufficient`: evidence, owner, checkpoint or a required decision is absent or
  contradictory. The rationale states the gap without declaring work not done.

An optional cited `forecast` on an assessment preserves the owner's prediction
separately from close status. For example, "Owner expects this week to close;
acceptance pending" stays `insufficient` if closeout evidence is missing; do not
convert it into carry-over. This does not add a business state to the KB.

Additional fields on a confirmed carry-over assessment (illustrative; not a
source default). Keep its original `line`, cited `rationale` and the PMO fields
described below. The checkpoint and next action are siblings of `carry_over`:

```json
{
  "close_status": "carry-over",
  "carry_over": {
    "target_week": "2026-W40",
    "decision": {
      "text": "Owner 已确认将剩余验收转入 2026-W40。",
      "sources": [{"source_id": "@cycle", "quote": "Owner确认：剩余验收转入2026-W40，承接人和检查点已确认。"}]
    }
  },
  "next_action": {
    "text": "补充剩余验收证据，按已确认检查点复核。",
    "sources": [{"source_id": "@cycle", "quote": "Owner同意补充剩余验收证据，并于2026-10-02复核。"}]
  },
  "checkpoint": {
    "text": "2026-10-02",
    "sources": [{"source_id": "@cycle", "quote": "Owner同意补充剩余验收证据，并于2026-10-02复核。"}]
  }
}
```

`phase: "pre_meeting"` explicitly means 会前判断，非会后验收. A `post_meeting`
page additionally requires a cited `weekly.decision`; do not choose it merely
because generation happens after a calendar meeting. Project `status`, project
`stage`, per-goal closeout and business acceptance stay separate. The helper
validates structure/references and required fields; it cannot prove the judgment
or a claimed human decision is true. Review that against the actual sources.

Use `weekly.as_of` to describe the evidence window or limitations of the selected
records, including the event dates of decisions used in `next_action`, not only
the original meeting. A later supplement that makes a new decision extends the
window; a later transcription date alone does not. Future target/checkpoint dates
are commitments within that window, not evidence cutoff dates. The renderer
separately records when the assessment was generated. It
links the complete cycle at the same revision. The project brief shows results
and impact first; its weekly assessment is an appendix. A consolidated weekly
page displays all assessed goals together, so the meeting need not open every
project link. Keep significant risks visible in the row.
Do not hide the original goal or material facts just to meet the editorial word
budget; condense repeated project prose instead. The four columns become readable
stacked rows on narrow screens.

Build `progress.basis` from the original goal's relevant delivered work first:
distinguish existing foundation, this week's partial delivery, and what still needs
verification. Check dated project updates and captured artifacts even when the
cycle summary is stale. A partial mechanism fix addressing the goal is progress;
it need not close the whole problem. Summarize its effect in one short clause,
leaving PR numbers and implementation details in evidence. Then use the actual
remaining work and date in `rationale` and `next_action`. “Full verification is
missing” must not replace a known partial delivery with “only observations” or
“no fix delivered”. Scope a missing version/result to the unresolved scenario.
If progress and cycle disagree, identify the dated accounts and pending source
sync. Keep project facts distinct from cycle-reported observations. Reconcile all
three weekly fields with the sources independently of what the brief selected.
A single recipient's success does not establish team acceptance, but must not
become “no results”. The project brief uses project sources; `@cycle` is reserved for
weekly management claims and cannot supply project adoption links or their context.

Every current goal's rationale needs at least one citation to that project's
business evidence; a global empty cycle table alone is rejected. Add relevant
cycle quotes for approvals or later observations. This binding does not itself
prove the explanation is specific or true: apply the source review before staging.
`weekly.as_of` follows the same source-dated/explicit-unknown rules as project
`as_of`. Use `YYYY-MM-DD` or `M/D` (such as `9/23`). A full source date may be
shortened to its month/day; a month/day source cannot establish an added year.
Cite the event date in business prose;
do not add a year or infer an event date from YAML `updated`, filenames, record
dates or generation time. A cycle's planned date range is not its fact cutoff;
do not substitute that range just to satisfy date validation. If no event date
is stated, use explicit `date_unknown` with the source-supported limitation.
Both project `as_of` and `weekly.as_of` are required in weekly mode; a cycle
date cannot stand in for the project's own run/owner-report window.

## Goal-level progress, evidence and risk

For fresh assessments of current goals, these fields are required (not null).
Use an explicit unknown range/risk and a cited explanation when evidence is insufficient:

```json
"progress": {"range": "50–80%", "basis": {"text": "已有实现，完整范围的验证尚未完成。", "sources": [{"source_id": "project-id", "quote": "实现已完成；完整范围验证待补。"}]}},
"evidence_status": "partial",
"risk": "yellow",
"next_action": {"text": "Owner 计划补充完整范围验证，日期未定。", "sources": [{"source_id": "project-id", "quote": "Owner 下一步补完整范围验证；尚未确认日期。"}]}
```

These percentages are **AI estimates of the original goal**, not quoted facts or
measured project impact. Choose a broad integer percentage interval from the source-supported basis
(for example 10–30% or 50–70%, with 0 ≤ lower < upper ≤ 100). These are writing
guidelines, not a closed enum of permissible estimates:
0–20% preparation; 20–50% partial work; 50–80% implemented but incomplete validation;
80–95% validated with remaining closeout; 100% only full delivered closure.
Use `unknown` when the source offers no usable basis. Do not average unrelated
subtasks or claim an increase without a comparable earlier snapshot. The UI labels
estimates and includes existing foundation; the rationale distinguishes this
week's new result from historical work. Do not attach progress to transferred goals.
Do not convert these into weekly-new-work percentages during review. A recorded
prior capability can support cumulative goal progress even when this week has
no new delivery; a reviewer may challenge its relevance or the basis, not merely
its earlier date. This definition is shared by authors, the UI and reviewers.

`evidence_status` is complete / partial / insufficient / not_updated; `risk` is
green / yellow / red / unknown (when delivery risk cannot be assessed). They are separate from progress and close_status. Evidence
absence is not proof that work did not happen; an approaching agreed checkpoint
can increase risk without establishing failure. `next_action` remains a cited
claim: distinguish agreed action, owner forecast and PMO suggestion; suggestions
do not create hard dates or commitments. Follow-ups should ask for the actual
remaining result, not repeat requests already satisfied by dated evidence.

Preserve the cycle's recorded dates. If the supplied conversation reports a human
date adjustment that has not been independently captured, label the provenance
and pending synchronization; do not quietly rewrite the period or add a deadline.

Consolidation uses every registered project's reviewed candidate at one revision.
It adds no new assessment and does not mutate cycle.md. Use scope + original goal
ID as identity; keep transferred rows out of current closeout counts. Existing
innovation weekly pages have stage/inclusion rules and a separate template: keep
that contract and explicit excluded/unknown coverage when rendering there.
