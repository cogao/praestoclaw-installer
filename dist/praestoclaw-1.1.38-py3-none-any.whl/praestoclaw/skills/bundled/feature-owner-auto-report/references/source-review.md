# Source-backed composition and bounded review

Authors and readers use the same [review policy](review-policy.md). New packets
embed and bind it so estimates and helper-derived facts are judged against the
same contract as the author's work.

A reader must understand users/value, roadmap, actual impact and adoption; the
separate weekly view explains the weekly goal's current
position and the next recorded action from the main brief. Folded evidence backs
that brief; it does not replace missing results or next steps.

## Source and composition

Use the complete receipts already read through the bound KB tools at one revision.
Do not clone another repository to make a report “fresh”. In an authorized manual
Draft request, after resolving KB scope, sync and rules, start the direct draft to
obtain its actual worktree/base. The helper can capture the selected area's entire
registry and week once from that returned worktree:

```text
<python> <current-skill-dir>/scripts/report.py capture-bundle --repo <returned-task-worktree> --revision <task-base-head> --registry <root>/projects.yaml --week 2026-W39 --output <workspace>/reports/<run>-sources.json
<python> <current-skill-dir>/scripts/report.py prepare-run --source <workspace>/reports/<run>-sources.json --repo-url <verified-repo-url> --output <workspace>/reports/<run>
```

This command reads Git at that named revision without fetch/clone or KB writes.
It also captures Markdown artifacts directly linked from each progress record,
only within that project's artifacts directory. It does not crawl nested links,
other projects or remote systems; unavailable linked files are listed. These
receipts supplement canonical progress rather than changing its state.

Rule capture walks the repository ancestors, registered project directories and
the selected cycle directory. It includes README/readme, CONTRIBUTING, AGENTS,
CLAUDE, conventions/CONVENTIONS and index Markdown files, repository-wide
`.github/CONTRIBUTING.md`, and one hop of policy references on normative lines.
Ordinary navigation links and recursive policy links do not expand this scope.
Each project author and reader receives only that project's applicable rules and
the cycle rules when the cycle is included. Rules remain context, never fact citations.

For an owner report or DRI navigation change, resolve the actual destination first
and add `--rule-target <repository-relative-destination>` to `capture-bundle`,
repeating the option for each selected destination. This freezes its directory
rules with the source bundle; do not guess owner slugs. With multiple captured
owner destinations, pass the selected path to `render-owner --rule-target`; a
single captured owner destination is selected automatically. The owner reader
receives that destination's rules and the selected owner's project rules.
This includes closed projects retained in the source bundle and named in the
report, even when their detailed cards are excluded from the current view.
Existing legacy bundles remain readable but do not gain rules omitted from their
original snapshot. All newly rendered review packets use schema 2. A single receipt
or legacy bundle can produce a preview, but publishing a new candidate requires a
rule snapshot from `capture-bundle`; recapture and review a fresh candidate if it
is missing. Schema 1 packets remain readable as historical evidence, but cannot
prepare a new publication. Their mutable version field cannot establish when
they were generated; preserve them and capture/review a new schema 2 candidate.

Resolve current-skill-dir once from the runtime's installed package, for example
`importlib.resources.files('praestoclaw.skills').joinpath('bundled/feature-owner-auto-report')`.
Do not find it by searching for similarly named workspace copies. The new run
contains these helpers/references and the complete source bundle, so scoped read
tools can access them. prepare-run requires a new directory. Repeated --project ID
selects an explicitly requested subset; the default includes all bundled projects.
For a requested consolidated weekly page, add `--weekly` to `prepare-run` before
delegation. It requires all registered projects and checks cycle coverage against
the fixed registry and explicit goal-level transfer decisions before creating the
run. The saved weekly intent remains in later prepare calls. Registry history
alone cannot remove a goal from coverage; unresolved scope conflicts stop this
preflight. Omit this flag for project-only reports.

Keep the target KB rules read for this request in the coordinator's context. The
generated author/reader tasks name the KB repository, selected registry area and
source revision; their shared contract distinguishes recorded links from permitted
navigation. Before staging, check the actual new adoption/evidence hrefs against
those rules, including explicit shared-infrastructure exceptions. A helper accepting
a recorded URL is not a business-scope approval. Preserve historical source quotes;
do not infer a new allowed area or invent a replacement entry when the rules are unclear.

Before delegation, save prepare-run's plan_note in the persistent parent plan.
Execute prepare-run's `next_command` (`run.py next --run-id <this-run-id>`) and
pass its `spawn` object exactly. It returns one complete batch; do not read only a
project/phase summary and reconstruct the prompts. Full recovery state stays in
resume.json. Task paths are absolute and repairs have actual versioned task files.
If an assigned file is absent or its run/candidate identity differs, report that
condition; never search the workspace for another author/review task or old run.
Each job owns one project; each batch has at most three jobs. The parent dispatches
batches directly; an author does not become another coordinator. This prevents a
nested spawn/approval from silently consuming the parent task's execution window.
Each author reads complete sources, writes new content.json and uses this runner:

```text
<python> <run>/skill/scripts/run.py render --project <project-id> --version v1
```

The generated sources.md includes exact source IDs, matching goal rows, full progress, directly
linked evidence and cycle. Read through every source's end marker. A later linked
owner update can contain the actual delivered result while progress still keeps
older zero-result runs. Preserve both evidence levels and dates; do not let the
oldest detailed example displace newer limited success. If a material update is
only linked remotely or outside this capture, read it through the already allowed
KB read flow, or disclose the missing evidence rather than claiming no result.
The runner supplies the renderer, complete sources and packet/output paths.
Authors do not supply source/weekly-source or build packets. Repairs use the same
bundle, not older receipts or content. Send the generated review-task to a separate
independent reader; an author stops before assigning a verdict.

For new project and weekly claims, select the exact captured source_id and inclusive 1-based
lines from sources.md. The helper fills missing quotes from only those lines before
the existing fact/date/number checks; it never selects supporting lines or fixes a
supplied quote. Disjoint ranges remain separate anchors. The successful candidate
keeps the original `<packet-stem>.authored-content.json` beside its normalized,
quoted content and packet. Independent review still decides whether each selected excerpt supports
every business clause; choosing a valid range is not semantic approval.

Explicit previews and cron remain read-only and use their existing complete KB
receipts; do not start a draft just to obtain a filesystem path. Explicit offline
requests can use a named local checkout. Neither mode bypasses a refused KB read
or expands the allowed area. Re-read only when the selected snapshot changes.

Render an initial small sample to catch structural errors, then complete a first
candidate for every selected project. A blocked review does not gate expansion. Apply any input-contract correction once to subsequent authors. Later
independent readers may run in parallel, with one project per reader and at most three readers per batch.
Start authors directly; do not draft the portfolio with explorers and then hand
it to another coding agent. For spawn parallel mode, provide its documented JSON
array of agent/prompt objects; ordinary prose is for serial mode. The parent
coordinates author and reviewer tasks; authors do not delegate the same work again.
The model writes cited content; scripts only render/package it. Do not create a
keyword, maximum-date or fixed-length extractor for business prose.

- Read the complete current outcomes, next steps, later owner decisions and all
  relevant cycle check-ins. A limited success reported only in the cycle, outside
  the goal table, still counts as a weekly management observation. Preserve it
  in `weekly.observations` with its date and pending project-sync label; that label does not make it
  a source for the project brief.
- Separate original commitment, delivery, forecast, acceptance and scope change.
  A stopped/transferred scope is not a current delivery task. Preserve completed
  handoff separately from remaining automation and downstream work.
- Show a concrete result with its scale/denominator and limit when recorded. For
  closed projects, keep at least the decision-relevant result for later recall.
  If metrics are absent, state the delivered capability and unmeasured benefit.
  Use the documented target user/use case when the value field is empty.
- Show the known next action or decision, agreed date if recorded, and proposal
  status if uncommitted. “日期未定” and “不重开” do not mean “尚未承诺”: preserve
  “建议 / 待 owner 确认” in the visible action itself. Do not turn a request for
  historical documentation into an assigned delivery. Rewrite concisely.
- Distinguish run/delivery dates, owner updates, classification decisions and
  future plans. No final cycle verdict does not mean no dated check-in. Retain
  known partial dates instead of calling all facts undated; identify the actual
  unknown window. Use full dates and their supporting business rows when available.
- Follow weekly-content.md for matching project goals and forecast/carry-over.
  Cite each actual assertion, not a nearby line that merely names the project.
  A citation error names its content path: fix that claim/excerpt, not unrelated
  paragraphs or every project's cutoff. Do not use date_unknown to evade an error.
- For each important metric, preserve what was measured: human effort versus
  end-to-end elapsed time, estimate versus observed result, sample/denominator,
  excluded waiting or exceptional work. Keep that qualifier beside the number.
  More than one source may support a sentence; split it or cite each relevant
  excerpt. A valid quote nearby is not evidence for the whole sentence.

## Freeze candidates

```text
<python> <run>/skill/scripts/run.py render --project <project-id> --version v1
```

The runner automatically uses the bundled cycle. For direct rendering,
--weekly-source takes a cycle receipt, not the whole bundle; omit it when --source
is a capture-bundle. Owner mode continues to use render-owner. New standalone
candidates require both readers too; after primary ready, use `report.py confirm-review`
as documented in [direct preparation](refresh-and-publication.md#selected-reports-and-optional-dri-links).
The helper writes HTML,
a binding JSON packet and a readable Markdown view. The view separates the exact
visible brief, selected excerpts, focused cycle observations and complete numbered
sources, and includes the exact small reply contract for this candidate.

Render reports the independent citation errors together. Fix those fields in the
same author context, then rerun; do not spawn another full author just to fix one
quote. Use at most two structural repair passes per candidate. The run helper persists
all admitted render attempts across processes/authors and refuses a fourth call;
resume must not dispatch a candidate whose attempts are exhausted. If it still fails,
return the exact unresolved fields and local work rather than deleting facts or
claiming success. This is separate from the semantic-review budget below.

Failed renders are not frozen candidates. Once HTML and its packet/view have been
successfully produced, candidate files are write-once. Reuse passed files unchanged. After a material
content correction write v2 paths, preserving v1 and the original reader reply.
Never rerender all passed projects just to update generation time. Never edit a
packet, candidate ID, digest or a raw verdict to make mismatched inputs pass.

## Review the report, not the project's completion

Give a different independent reader the generated review-task paths for at most
three candidates. An author/repair task must not write an independent verdict
for its own candidate. Read the manifest and each bounded part in a separate
read_file call. Do not concatenate parts into one tool result or read the full
JSON packet: the native compressor can silently discard Claim/excerpt structure.
If structure is missing, retry the relevant bounded part as a reading error.
Each reader reads all parts assigned by its generated task: complete sources,
visible candidate, navigation and every cited field. Confirmation is independent
of the author and primary reader and does not read this version's primary verdict.
Both apply the [shared review policy](review-policy.md), embedded in their packet.
It defines progress, date roles, evidence limits, source direction and materiality;
do not replace it with a different rubric or add review layers.

Read the actual primary text: results hidden only in folded evidence do not count
as visible coverage. Preserve concise concrete results and their material limits;
report quality can pass while the project remains incomplete. Review every
assigned Claim through the last, then return all material blockers together.

The view supplies the candidate ID; the reader prepares this small JSON object in
its own candidate-specific `review-draft.json`:

```json
{
  "candidate": "copy Candidate from the view exactly",
  "report_review": "ready",
  "blockers": [],
  "notes": "Name the visible result, remaining gap and important source boundary.",
  "review_mode": "independent"
}
```

report_review is ready or needs_changes. An unfinished project, an insufficient
weekly close status or a disclosed source conflict can all appear in a ready
report. blockers contains only unresolved errors/material omissions in the report;
positive observations belong in notes. No five-boolean checklist, full hash, source
revision, path copying or reviewer persona is requested. Identity/source binding is
checked mechanically against the explicit packet passed to publication.py.

On re-review, also read review-context.md: it contains the previous raw findings
and exact content changes. Report newly discovered material defects in unchanged
fields as first-pass misses; still require their correction, without treating
them as feedback the author had previously received. Review all decisive results,
next steps and source conflicts on the first pass rather than rationing findings.

For new prepared tasks, the independent reader owns one editable draft and submits
it through the exact command in its review task:

```text
<python> <run>/skill/scripts/run.py submit-review --input <candidate>/review-draft.json
```

The reader explicitly supplies `review_mode` along with candidate, report_review,
blockers and notes. Submission archives the attempted raw text and applies the
existing candidate/source/outcome checks; only a valid submission is saved as the
canonical `review.json`. The helper does not supply a missing mode or alter a
decision. JSON syntax or missing-mode errors stay in this same reader's draft
stage: correct the draft and submit again in the same reader task. A source,
candidate or outcome binding error stops submission; do not relabel a reply. The immutable raw archives and canonical reply
must never be edited. An identical successful submission is idempotent so a lost
tool receipt can be recovered; different bytes cannot replace the submitted reply.

After success, return only the submitted paths and short helper receipt, not a
second JSON verdict. The canonical file is the one authoritative reply. The reader
may edit only its draft and call this submission command; sources, content, HTML,
other replies and all candidate artifacts remain read-only. Do not render, use
shared scratch paths or run cleanup. Submission does not call status/resume/next
or write the parent run's preview. The parent continues through `next` to recompute
state and dispatch the remaining work. This task scope uses the ordinary native
tools and preserves their existing approval and capability boundaries.

New prepared runs use protocol 2: each reader submits exactly one reply from its
assigned candidate draft. `next`, `resume` and `prepare` only use submitted
canonical replies; they never import response files or start metadata re-reviews.
An older run must use the original helper already frozen in its own `skill/`
directory. Do not replace that helper, upgrade its manifest or migrate its saved
failures to the new protocol. Old evidence remains readable in its original form.

## Stop conditions and repair budget

- At most three candidate versions and two targeted corrections per project.
  New prepared runs require one primary review and, only after primary ready,
  one fresh independent confirmation of that same candidate. Either one's
  material blocker enters the remaining correction round; neither verdict can
  overwrite the other. This adds at most three confirmation calls per project,
  Do not run extra readers
  to obtain a preferred verdict or re-review a candidate already ready through
  both stages. Each new version needs both of its own bound replies.
- Syntax and missing-mode corrections belong to the same reader's unsubmitted
  draft. The reader retains its decision and blockers, supplies its own mode and
  retries submission; the coordinator never edits a review or launches a separate
  full source review just to repair JSON. Every submitted raw attempt is retained.
- If the third review still has blockers or the response remains unusable, stop
  automatic retries for that project. Continue generating/reviewing the remaining
  selected projects. Run `run.py status` and return its local preview index with
  exact unresolved fields. Keep failed pages as pending candidates; do not omit
  them, reset the whole run, or claim the full reviewed batch is complete.
- If independent delegation is unavailable, report the capability gap and stop
  publication. Keep the run pending; coordinator review cannot replace either
  required independent reader.

These bounds also apply when a reviewer misreads project scope: explain the scope
once within the remaining round, rather than growing a project page into a team
report just to satisfy an incorrect review demand.

## Prepare the draft

Prepared project runs read canonical replies saved by each reader through submit-review. Then use:

```text
<python> <run>/skill/scripts/run.py prepare --repo <returned-draft-worktree> --task-id <actual-task-id> --base-revision <task-base-head> --index --batch primary
```

Use --index only when authorized. The runner selects the latest candidate per
requested project, requires its raw reply and complete original run source, then
prepares a new publication JSON and binding without overwriting earlier proposals.
It never falls back to an older pass or drops a requested page. Stage the exact
returned proposal_file with kb_draft. For the requested owner return links to that
same authorized index, prepare the separate navigation draft explicitly:

```text
<python> <run>/skill/scripts/run.py prepare --repo <navigation-draft-worktree> --task-id <navigation-task-id> --base-revision <navigation-task-base> --index --batch navigation
```

`--batch navigation` selects a subset; `--index` enables the authorized index and
return-link generation. There is no `--navigation` flag. Check returned paths:
an empty proposal is not proof that requested owner links exist. Inspect the
actual pages or correct preparation; do not hand-build proposal JSON. Other modes
retain publication.py's explicit report/packet/review/confirmation arguments.

Each draft base comes from its own native task receipt. It may advance during a
long run; the report source remains the original fixed snapshot. The helper checks
the destination separately and refuses conflicting target or governing-document
changes. Do not edit proposal revision fields or binding hashes to recover a
refusal. Re-prepare through the helper, or retain the genuine conflict. Label the
fixed source in the draft overview; do not claim the later destination base was
reviewed as report evidence. A report requiring newer facts needs fresh sources
and independent review.

The packet binds sources/content/HTML; the candidate ID binds the raw reply to that
packet. These consistency checks do not authenticate a reader or prove truth.
Evaluate real PraestoClaw output separately from helper tests and CI.

For an authorized consolidated weekly view, repeat preparation using its actual
new draft task, its `--base-revision`, and `--weekly --batch weekly`. Primary generation with `--weekly`
also links the index to the weekly view; both dependent drafts must be staged and
reported. Navigation remains its separate batch. The weekly renderer reuses the
same reviewed candidates, so it introduces no new business assessment.

On resume, use this run's `resume` output, not old successful PR messages or cached
status. `resume` only rebuilds diagnostic state; execute its returned `next_command`
to reserve and dispatch unfinished candidates without regenerating passed pages. Verify
prepared task IDs, source revision and change paths through kb_draft before calling
a PR this run's delivery. Local preview, prepared proposal, staged draft and
published page are different states.


A final chat message is not an alternative verdict: use the submitted canonical
file or report that the reader did not complete submission. Never compose a
verdict from a summary or label coordinator-authored text independent.
