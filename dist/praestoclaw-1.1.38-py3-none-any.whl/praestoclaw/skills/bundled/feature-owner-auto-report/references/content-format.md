# Report content

Use [source-first composition and review](source-review.md) before writing claims.

The owner can send one link whenever someone asks what the feature does, for
whom, how it is progressing, what impact exists, and how to use it. Keep the
facts traceable while letting the project's situation determine the presentation.
Lead the result with what the user can now do. Implementation-check totals and
issue/run identifiers are supporting evidence, not substitutes for that result or for measured impact.
Actual usage or test-scenario outcomes can be meaningful results when their scope
and sample are clear, especially for a testing capability.
Explain internal terms through their practical meaning; for example, 日常运行
instead of unexplained BAU. Keep familiar names such as Teams or PR. Prefer
“功能已完成开发与验证，PR 可评审” over
“FULL_FEATURE / acceptance PASS / READY_TO_REVIEW”. Explain repair as “返工”
and an evidence gap in ordinary Chinese. Put run IDs, F1–F8 codes and detailed
execution phases in folded evidence. Do not repeat the headline in a delivery
bullet or turn an unmeasured benefit into the dev's next assigned task.

Write for a reader who does not know this feature. The first sentence should name
the user and the practical job/problem in ordinary language (roughly 30–50 Chinese
characters), not list every capability or internal term. Keep the headline to one
current takeaway (roughly 25–40 characters). Put the decisive limitation beside
the affected result once. Do not repeat the same closure/readiness disclaimer
in the headline, roadmap, limit panel and every link. Keep different material
limitations, but remove duplicates. Use these as editing targets, not reasons to
drop a material fact.

Put a short user/pain/value purpose first, then the current result and limits.
Use the smallest set of sections that explains impact, roadmap/current position,
and adoption. Weekly goals stay in the project appendix and the consolidated
weekly page, not in the project's main narrative. A roadmap may show past actual,
current work and future plan; distinguish actual dates, commitments, forecasts and
proposals in the cited text. Missing dates remain missing. Show
important numbers with their sample/window and distinguish observed effect from
an intended benefit. Label human effort versus total elapsed time and retain
excluded waiting/exceptional work beside any time estimate. Keep proposals visibly
marked as suggestions pending confirmation, even when a source names an owner.
Put material limitations beside the result; detailed run IDs
and logs can be folded. Explain the next action by its concrete purpose; an
incidental contact's name is not an explanation. Use a recorded role when useful,
never invent a role, and keep contact details in sources when the main brief does
not need them. These are information priorities, not fixed headings.
The source `stage` is displayed separately from `status`; content cannot override
it or infer a stage/ETA from a merged PR. If the formal stage is absent but a cited
roadmap explicitly identifies the current position, omit the redundant missing-stage
badge; the raw missing value stays in source metadata. An unresolved source conflict should be
reported before staging a misleading page.

Keep source direction separate from presentation: the project brief, including
link targets and their context, uses the project's progress and captured artifacts.
`@cycle` is available only under `weekly`; a management summary or its link to an
original system cannot substitute for project evidence. When the project sources
do not establish a fact, omit it or state that boundary instead of importing the
cycle's assertion into the brief. Weekly assessments may combine both source types.

This is a schema example, not mandatory section names or a factual report. Its
source IDs, line numbers, dates and claim text are placeholders. For every claim,
choose the actual captured source ID and inclusive L numbers from this run's
sources.md; never copy these example line numbers as evidence.

```json
{
  "project_id": "the-source-project-id",
  "source_revision": "the-full-source-commit",
  "display_title": "面向读者的简短项目名称",
  "headline": {"text": "一句话说明当前成果与关键限制", "sources": [{"source_id": "the-source-project-id", "lines": [[20, 22]]}]},
  "purpose": {"text": "一句话说明项目要解决什么问题", "sources": [{"source_id": "the-source-project-id", "lines": [[12, 14]]}]},
  "as_of": {"text": "验证截至 2026-09-14", "sources": [{"source_id": "the-source-project-id", "lines": [[20, 20]]}]},
  "sections": [
    {
      "title": "本轮验证",
      "kind": "table",
      "headers": ["场景", "结果"],
      "rows": [
        [
          {"text": "截图功能", "sources": [{"source_id": "the-source-project-id", "lines": [[21, 21]]}]},
          {"text": "修改前后验证通过", "sources": [{"source_id": "the-source-project-id", "lines": [[21, 21]]}]}
        ]
      ]
    },
    {
      "title": "效果尚未证实",
      "kind": "callout",
      "items": [{"text": "样本少且缺人工投入记录，尚不能证明提效", "sources": [{"source_id": "the-source-project-id", "lines": [[22, 22]]}]}]
    },
    {
      "title": "下一步",
      "kind": "bullets",
      "items": [{"text": "建议增加样本并记录人工投入，待 owner 确认", "sources": [{"source_id": "the-source-project-id", "lines": [[24, 24]]}]}]
    }
  ],
  "evidence": [{"label": "验证证据", "target": "artifacts/evidence/README.md"}]
}
```

`headline`, `purpose`, `sections` and `evidence` are required. Sections and evidence
can be empty when genuinely unnecessary or unavailable. `display_title` is an
optional faithful Chinese shorthand for the source title, never a new project
definition. The original title remains in source details. `as_of` is an optional
cited statement of the business/evidence window; do not derive it from `updated`.

Before each counted render, run the author-task's read-only JSON syntax check.
Fix parser errors across the whole draft and recheck after edits until it parses;
the first reported error may hide repeated bracket/comma mistakes elsewhere.
This is draft preparation only. It does not check evidence or approve content,
consume a render slot, reset an exhausted version, or replace the renderer's
bounded source/date/number checks and independent review.

For new project review candidates, use nonempty plain `text` and explicitly
selected captured source IDs with inclusive 1-based line ranges:

```json
{
  "text": "可追溯的项目事实",
  "sources": [{"source_id": "the-source-id-from-sources.md", "lines": [[12, 14], [20, 20]]}]
}
```

Choose the actual factual lines after reading the complete source. The helper fills
only missing quotes from exactly those ranges before validation; disjoint ranges
become separate quote anchors and never include the intervening lines. Use the
`[[start, end]]` shape with integer bounds and no blank boundary lines. Unknown
sources, malformed/out-of-bounds ranges and unsupported facts still fail. The
frozen packet contains explicit source IDs and exact quotes. Your content input
is unchanged; a successful candidate also saves its original input beside its packet
as `<packet-stem>.authored-content.json` (for example, `review-packet.authored-content.json`).

Existing verbatim `quote` input remains supported; the renderer locates its unique source
lines. A supplied quote is never corrected or replaced from `lines`. A quote or
line range at the claim level defaults to that
project. To use one captured artifact or cycle source, put `source_id` beside
`text` and `quote`. For example:

```json
{
  "text": "可追溯的项目事实",
  "source_id": "the-repository-relative-path-from-source-view",
  "quote": "从该来源逐字复制的完整事实原句"
}
```

Multi-source claims select namespaces explicitly. An explicit `sources` list
takes precedence over the claim-level `source_id` or inherited default:

```json
{
  "text": "5个样本中4个通过，尚未覆盖完整范围。",
  "sources": [{"source_id": "the-project-id", "quote": "本轮5个样本中4个通过；完整范围尚未验证。"}]
}
```

This is illustrative text, not a factual default. Copy the actual Markdown excerpt
from the complete source receipt, including enough context to match once. Missing
matches fail. If the same exact quote occurs more than once, prefer a longer
verbatim excerpt; alternatively supply inclusive 1-based `lines` that match exactly
one occurrence's full line span. A range cannot select multiple occurrences or
distinguish two occurrences on the same line. The renderer reports source IDs and
matching line numbers but never chooses a source or occurrence on your behalf.
Project `--review-packet` generation fills missing quotes from explicitly selected
lines, then requires quotes for every claim. Weekly fields still default to the
project; select `@cycle` explicitly for cycle evidence. Link context inherits its
link's source, and each entry in an explicit `sources` list needs its own source ID.
Owner review inputs retain their existing exact-quote contract; legacy rendering
without a review packet continues to accept line ranges.
Supplying both a quote and lines requires them to agree. Never guess lines
from a heading offset. Every table cell is also a claim. A title/header labels the content;
factual assertions belong in cited claims. HTML/Markdown formatting is not needed.

With capture-bundle, directly linked project artifacts are complete receipts under
`supporting_sources`. Cite one with its repository-relative path as `source_id`,
as shown in source-view. Only same-revision, directly linked Markdown evidence in
the selected project's artifacts directory is accepted. The reviewer receives
that evidence too. Project lifecycle/acceptance still comes from canonical progress;
a limited owner report in an artifact must not silently change it.

Select the lines containing the actual facts, not just the section heading.
The helper rejects empty/heading-only citations and a fact cutoff backed only by
`updated`/`created`. This is a structural check, not an entailment test: read every
selected excerpt and split business assertions that need different evidence.
For example, a purpose sentence naming the target users and the value needs both
excerpts when the source records them separately. A value-only quotation does not
also cite the audience simply because that audience appears elsewhere in progress.
Evidence-limit qualifications describe what the cited observation does not prove,
not that an event failed to happen; apply the shared review contract. Quote an
explicit source caveat when available, and never disguise a new factual claim or
scope/acceptance decision as a qualification. For a dated run
plus a later owner update, state both windows. Never use “see source window” as
a substitute for stating the date or the specific unknown.

Project claims cannot introduce literal numeric quantities absent from their cited
business prose (frontmatter is excluded). Copy recorded numbers and their denominator;
do not derive an unrecorded metric just to fit the report. This catches a 19-case claim
cited to a nearby 39-case implementation row, but does not establish semantic support,
units or causality. Correct those through source review, not a validation bypass.

An `as_of` claim needs a source-stated YYYY-MM-DD or M/D business date in cited
business prose. A full date may be shortened to month/day, but a month/day source
cannot establish an added year; do not infer one from document metadata.
If a unified cutoff is genuinely absent, set `date_unknown: true` and explain
that limitation; known partial dates may remain visible without claiming a full
cutoff. Distinguish dates from labeled counts such as “反馈2/30”; quantities still
require matching source evidence. The renderer does not establish date semantics.
An edit date,
empty phrase such as “以源记录日期为准”, or an invented cutoff fails validation.

The **order and number of `sections` are author-selected**. Each has a short title
and one of these representations:

| `kind` | Content | Use when |
|---|---|---|
| `bullets` | `items`: list of claims | A few distinct outcomes or next actions |
| `table` | `headers`: 2–4 strings; `rows`: equal-width arrays of claims | Cases, results or alternatives need comparison |
| `callout` | `items`: list of claims | A material limit, blocker or recorded decision needs attention |
| `timeline` | `items`: cited milestone claims, or structured nodes below | Past/current/next position, preserving planned vs actual dates |
| `metrics` | `cards`: one to three objects, with cited `value`, `context`, and optional cited `label` | A meaningful before/after or prominent recorded number |
| `links` | `links`: objects with `label`, `target`, cited `context`, optional `source_id` | Visible design, onboarding, demo or usage resources |

There are no mandatory outcomes/limitations/next-steps/milestones panels in this
format. Do not generate empty panels. Preserve decision-relevant unknowns in the
headline or an appropriate claim instead. A tiny project does not need a table;
a validation report does not need its entire historical roadmap. It should still
answer where it is now and what the next supported milestone is.

Metric card value/context are both normal cited claims; no new numeric bypass is
introduced. Put “约 / owner 估算 / 小样本实测” in or beside the large value, and the
population, time window, baseline/after units and excluded effort in the adjacent
context. Before/after comparisons need comparable definitions and windows. Do not
turn a PMO goal-progress estimate into product impact or derive unrecorded savings.
If no trustworthy metric exists, use a concrete supported qualitative result or
explain the specific missing evidence in ordinary prose; omit an empty metric card.

### Scannable numbers and roadmap

Use metric cards for a meaningful outcome count, time/effort or comparable result.
A Bug/PR/build ID is a reference, not an impact number; put it in an evidence link.
If there is no useful metric, show the supported delivered capability as a short
result or comparison instead. Each metric card has one principal value, a short
label, and a compact context, not several numbers or a result paragraph. Keep
estimate/sample labels, sample window, denominator and material scope limits adjacent; comparison cards must use comparable units. Use qualitative
results when there is no defensible metric, rather than filling a card with zero.

Structured timeline nodes make the current position visible without a paragraph.
Each node has a cited `label`, optionally cited `status`, `when` and `detail`.
Status text is `已完成`, `当前`, `下一步` or `暂缓`; it is a business claim with its own
evidence, not an automatically inferred lifecycle. Every present field is a claim
object such as `{"text":"当前","sources":[{"source_id":"<captured source_id>","lines":[[start,end]]}]}`;
bare strings such as `"status":"当前"` are invalid. Node-level or sibling citations
do not cite another field. Omit an unknown optional field instead of supplying
uncited text. Prefer three or four real milestones
and a short current focus. Omit unknown dates instead of inventing them; do not
force every project into a generic development pipeline. Legacy timeline items
that are single cited claim objects remain supported.

```json
{"kind":"timeline","title":"走到哪了","items":[
  {"label":{"text":"按真实来源写阶段名称","quote":"复制支持该阶段的原句"},
   "status":{"text":"当前","quote":"复制支持当前状态的原句"},
   "detail":{"text":"一句当前重点","quote":"复制支持当前重点的原句"}}
]}
```

A claim may add `emphasis: ["exact phrase"]` for up to three short phrases already
in its `text`. Highlight a complete takeaway including any qualifier or negation;
do not highlight an isolated "完成" inside "尚未完成". Formatting adds no new claim
and cannot replace its citation. Prefer one or two emphasized phrases per module.

Use a link context to explain what the reader will find there; repeat a project-wide
limitation only when this particular resource would otherwise imply a different
readiness level. Describe unverified behavior plainly rather than listing unexplained
internal components, while preserving the distinction between unverified and failed.

A links section validates targets against the project's canonical source or its
captured directly linked artifact. An installation/design entry reported only by
the cycle belongs in the weekly management assessment with its pending project
sync boundary and cited cycle source, not in the project's adoption section.
“Cycle-reported” or “pending sync” does not waive the project-source requirement.
Pure navigation to the weekly page or PMO rules remains separate from business
evidence and does not establish project readiness.
The link's `source_id` is also the default for its `context` quote. A context's
own `source_id` overrides that default, and its explicit `sources` list takes
precedence over both. Every selected source must already be captured in this
project's source bundle. Folded `evidence` targets remain links from the canonical
project source. Unknown links fail together with other independent claim/link
errors; any suggested targets are existing source links, not automatic repairs.
The cited context describes the actual design
or usage boundary. A design document is not an onboarding guide, and a merged PR
is not proof that a customer can use it. Label each link accurately; expose a
known adoption gap instead of inventing a URL. These links belong in the main
brief, while raw logs and detailed proof remain in the folded evidence area.

For older saved generation inputs, the renderer still accepts the v1
`outcomes`, `limitations`, `next_steps`, and `milestones` lists. Use `sections`
for new reports. This compatibility path is not the new editorial default.

Aim for roughly 200–280 Chinese characters plus English words in the project brief.
This is an editorial target, not a hard gate. Use short labels and visual structure,
not tiny fonts, clipped text, or collapsed material risks, to reduce reading work. Titles and
table headers count; folded source excerpts do not. The renderer reports this
approximation and warns over the target without truncating facts or refusing to
preserve an important risk. The count is a writing aid, not a measured reading time.

Evidence targets must already be Markdown links/images or literal HTTPS resource
URLs in source prose or a standalone inline-code span. Markdown examples inside
code spans and URLs in fenced code blocks are excluded. A target may omit an
existing fragment to open the same resource root; its path and query must remain
the same. Do not add or replace an unrecorded fragment. HTTP and credential-bearing
URLs remain rejected by the URL safety check. Use the actual destination URL, without Markdown
syntax escapes; the parser handles parentheses, reference links and URL normalization.
Preserve the target apart from optional fragment removal;
relative links resolve at the source revision and absolute HTTPS links
retain their target. Evidence links, exact excerpts, and project acceptance/impact
metadata are available in the folded reference area, keeping the main brief short.
Valid citations do not establish semantic support; review the actual cited text.

Source receipts use the complete `kb_inspect(read)` shape:

```json
{
  "head": "full-commit-sha",
  "path": "10x-productivity/inner-loop/projects/project-id/progress.md",
  "from_line": 1,
  "total_lines": 100,
  "returned_lines": 100,
  "content": "The complete source document, including YAML frontmatter"
}
```

Save the actual receipt without reconstructing missing text. `capture` produces
this shape from a named local Git revision without fetching. The renderer's
repository URL is the verified credential-free HTTPS GitHub/GitHub Enterprise
repository URL. Temporary receipt/content files are generation inputs, not KB
records or a parallel status system.


For a combined project/weekly request, use the additional cycle receipt and assessment schema in
[weekly input](weekly-content.md). Goal/owner text is read from the source table,
not rewritten in the content JSON. Multi-source claims use explicit source IDs;
project and cycle citations never share an implicit line namespace.

For draft generation, render with `--review-packet` and follow
[source review](source-review.md). `purpose` must explain value, not repeat the
project name; a section must add information beyond the exact headline. These two
observed empty-content patterns are rejected without imposing fixed section names.

For manual multi-project drafts, a capture-bundle from the already authorized draft
worktree can be passed as --source. The renderer selects the unique project_id and
its same-revision cycle. Review candidates are write-once; use new version paths
after content changes. A citation failure names its content path.
