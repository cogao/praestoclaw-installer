# Refresh and publication

Use the same report skill for manual and scheduled generation. The model already
runs inside PraestoClaw; `report.py` validates and renders its selected content.
No report-config YAML parser, CI model client, Git hook or new deployment service
is needed for this first version. Skill metadata and KB frontmatter remain as-is.

## Manual entry

Resolve one feature/project, generate its report and prepare a KB draft:

> 给项目 08 刷新开发进度页面，面向我、manager 和 skip manager。

A named owner request creates one owner summary across their non-closed projects:

> 使用 feature-owner-auto-report，生成 Yue Liu 的个人开发进度报告，并准备 KB 草稿供我确认。

Use separate project pages only when requested. The owner summary is a derived
view, not an owner project record or a team PMO report.

In a personal Teams chat with the required KB capability, an ordinary manual
report request continues through the proposal flow below. A local HTML file is
an intermediate artifact, not the completed delivery. The agent may run the
manual request in a background worker without making it a read-only cron.
For several named owners/projects, render the requested pages and stage them
together. Add links only to an explicitly selected existing DRI page; do not
expand the scope to other reports or create a global directory.

Explicit “preview only”, “local only” or “no push” requests stop at the local
report directory; “no push” excludes the KB review-branch workflow. An explicit
“prepare a KB draft, do not publish yet” request allows a review branch and stops
after staging; it does not authorize the published KB branch. A prior completed
preview does not make later independent requests preview-only.

Temporary generation files default to
`<workspace>/reports/<project-id>/<run-id>/index.html` (owner mode:
`<workspace>/reports/owners/<owner-key>/<run-id>/index.html`), retaining the source and
content inputs beside it. For a local-only result, return the renderer's absolute
file path as plain code, state that it is on the PraestoClaw host and has not
entered the KB, and include a short brief. If a manual draft falls back to local
files because a capability failed, identify the actual failure and retain the
inputs; do not silently call it complete. Do not create a `sandbox:`, `file:` or localhost “open preview” link
for Teams. Do not launch a browser or start a preview server for ordinary generation.
Opening the file / visual QA is a separately requested action.

## Independent cron entry

Only configure a live job when the user requests a schedule. Use the existing
PraestoClaw `cron` tool in **prompt mode**: it runs the configured model, which
reads this skill, summarizes the fresh source, and invokes the HTML renderer.
Message mode sends static text; direct tool mode does not summarize new progress.
No scheduler/runtime change is required for this entry.

Use a separate report job with the selected project IDs and an explicit
`feature-owner-auto-report` invocation. For example, its saved prompt could be:

> 使用 feature-owner-auto-report，读取当前绑定 KB 中项目 08 的最新 progress，
> 生成供 dev、manager 和 skip manager 阅读的简短中文 HTML 预览。保留重要限制和
> 来源引用，在本次任务结果中返回简短回执及实际文件位置；如果缺少权限或工具，
> 说明原因并保留旧页面。本次只生成预览。

The prompt example does not choose a schedule. Establish the requested cadence,
projects, running instance and delivery destination before registering a job.
Use `cron list` and `info` to identify existing report jobs before an authorized
replacement; preserve their schedule, delivery and scope unless the user changes
them. Do not edit personal PMO or `kb-progress-sync-daily` jobs as a side effect.
Daily/weekly completion offers, shared team batching and changed-only refresh
are deferred; this version regenerates the selected projects on each invocation.

For jobs using the current personal Teams KB binding, explicitly set
`use_current_kb_scope=true`. Naming the report skill does **not** auto-capture
that scope. The existing runtime captures it only from trusted personal Teams
context as a **read-only** KB capability. Do not borrow another chat's identity,
bypass a refusal or assume a group/web job inherited that scope.
Preview rendering also needs the package and ordinary file/renderer capabilities
in the scheduled runtime; a successfully registered cron does not prove these work.

Use scheduler-managed delivery for scheduled results. Do not call notify again
to duplicate an automatically delivered receipt. Return the project, source
revision and actual preview location, or a short actionable failure. A local path
is not remotely accessible in Teams; identify it as local until an authorized
delivery/publication flow provides a verified remote link. Show local paths as
plain code, not clickable Markdown links, and do not invent a `sandbox:` URL. The job finishes after
its receipt and does not wait for an interactive answer or promise that a bare
“yes” resumes a pending publication.

Before describing scheduled refresh as working, run the authorized job once and
verify fresh source, actual generated HTML, failure behavior and delivery in that
runtime. Setup alone is not an execution receipt. This package adds instructions
for that integration; it does not install a job or grant unattended KB writes.

## Prepare a KB draft

Use this path by default for an ordinary manual report request in personal Teams,
as well as an explicit request to save to the KB, prepare a draft or publish.
Tell the user that this run prepares a KB draft for review; publication waits for
their confirmation. Explicit preview/local-only requests and scheduled runs stay
local. “No push” cannot use `kb_draft(stage)` as a local-only workaround: stage may
push a review branch and create a GitHub Draft PR. Preserve the selected intent
across retries and background handoff.

In personal Teams chat, reuse `pmo-grill`'s direct-proposal flow. No report-specific
card, Git wrapper or new publishing service is needed:

1. Resolve the target and read the current KB rules. A direct draft may be started
   early to obtain its fixed source worktree, but render and complete source review
   before staging any contents. Read the current target's KB rules,
   presentation contract and existing page. A project page belongs at
   `projects/<project-id>/index.html` under the discovered root. For an owner page,
   use the KB's established owner path. If none exists, include a proposed path
   such as `owners/yue-liu/index.html` in the draft summary for review; this is a
   new convention, not permission to change the team overview or project registry.
2. Start with `kb_draft(action="start", source="direct", user_request="<actual request and source evidence>")`.
   Report-only direct drafts do not require the optional units/select curation
   flow; do not introduce it merely to stage generated pages.
   Preserve its `task_id`, repo, base head and worktree across subsequent actions.
   Resume that exact task for later replies; `list`/`show` may recover it. Do not
   restart unrelated drafts or copy files directly into the managed KB clone.
   The direct source is personal-chat only; a shared-group report follows that
   group's existing capture/curation flow instead of borrowing personal scope.
3. Check the source against the draft's current KB snapshot. Re-read changed
   registry/progress inputs and regenerate when needed. A report must not conceal
   a material source conflict. No new claim is written to progress merely to make
   the HTML appear current.
4. Prepare the selected reports with `scripts/publication.py` below. It reads the
   returned task worktree's named Git base and emits the complete proposal file;
   supply each new report's matching packet/verdict as described in
   [source review](source-review.md). A source revision change requires regeneration
   and another review, not merely changing the packet's revision field;
   changing only the destination base does not change the evidence snapshot.
   For a prepared run use run.py prepare --base-revision <task-base-head>; direct
   publication.py calls use --revision <task-base-head> and, when different,
   --source-revision <fixed-report-source>. The helper does not fetch, edit the
   checkout or publish. Without an installed managed index, default output is report-only.
   Read the current presentation contract instead of following an old directory
   example. For requested DRI links, explicitly select the existing DRI page and
   verify its project IDs. Do not invent a missing DRI page or reuse another
   business space's reporting contract.
5. Stage the proposal using `kb_draft(action="stage", task_id=...,
   changes_file="<workspace>/reports/.../publication.json", message=..., overview=...)`.
   This personal-Teams input must be inside the actual workspace and bound to the
   same task/base revision. The tool retains its path/content/approval checks and
   freezes the parsed content. Use `changes` or `changes_file`, not both. The model
   should not copy large HTML through tool arguments or directly push to the KB.
   If the file input is unavailable, retain the prepared files and explain the gap.
6. Present the returned proposal summary, all changed paths and material limits
   as an ordinary Teams message. Include a real `review_url` / proposal review
   URL as a Draft PR link when available. A review mirror is best-effort and is
   not a rendered HTML preview. If it fails, retain the local KB proposal and
   state the actual outcome; do not fabricate a PR or repeat an identical stage.
   The managed KB draft worktree may itself live under `~/.praestoclaw`; the
   renderer's workspace path and the repository-relative target are different.
   Report the task/staging receipt and actual review URL, not a local file as proof
   of KB delivery. The user's separate KB checkout is unchanged until they pull
   after publication.
7. If the user explicitly wants only a draft for now, return the staged-draft
   receipt and stop. Otherwise ask one concrete question: “是否确认将这份报告发布到 KB？”
   Then end the turn. “Prepare draft” itself does not authorize publication. Keep
   the proposal identity so a later explicit publish request, or an affirmative
   reply to that publication question, applies to these exact contents.

## Selected reports and optional DRI links

All selected publication candidates must use schema 2, including standalone renders,
and require a rule
snapshot and the original `--rules-bundle <capture.json>` at
publication; `run.py prepare` supplies its frozen `sources.json` automatically.
The snapshot must match the candidate and the fixed Git source. Publication
checks rules for every actual changed path, including automatic navigation edits.
An index-only refresh with no new reports still requires a captured rules bundle
when it produces changes. Capture the existing report destinations whose return
navigation will change; their unchanged facts need no new semantic review.
If a destination's rules were omitted, capture that destination with
`--rule-target` and create a fresh candidate and reviews; do not expand an already
reviewed snapshot. Keeping the full snapshot here does not add unrelated project
rules to an individual reader's materials.
Rendering from a single receipt or a legacy bundle is a preview only: recapture
with `capture-bundle` and create a new candidate and both reviews before publishing.
Schema 1 packets remain readable as historical evidence but cannot prepare a new
publication. A self-declared schema and recomputed hash cannot prove legacy
provenance. Preserve old files and create a fresh captured candidate with both
reviews; changing the schema never grants a publication exception.

Standalone `render` and `render-owner` candidates also require two independent
readers. After the primary reader returns ready, generate the confirmation view:

```text
<python> <skill-dir>/scripts/report.py confirm-review --packet <absolute-packet.json> --review <absolute-raw-reader-response.json> --output <new-confirmation-directory>
```

Give a fresh independent reader the returned directory's `packet.md` and all
listed parts. Do not give that reader the primary reply. Preserve its raw response
with the distinct confirmation candidate ID. The command requires a ready,
independent primary reply and refuses an existing output directory. A material
blocker requires a new candidate and both reviews; never relabel a saved reply.

For the current Societas project layout, prepare the selected report with both replies:

```text
<python> <skill-dir>/scripts/publication.py --repo <returned-task-worktree> --revision <task-base-head> --task-id <task-id> --root 10x-productivity/inner-loop --report "10x-productivity/inner-loop/projects/<project-id>/index.html=<absolute-local-report.html>" --packet "10x-productivity/inner-loop/projects/<project-id>/index.html=<absolute-packet.json>" --review "10x-productivity/inner-loop/projects/<project-id>/index.html=<absolute-raw-reader-response.json>" --confirmation "10x-productivity/inner-loop/projects/<project-id>/index.html=<absolute-raw-confirmation-response.json>" --rules-bundle <original-capture.json> --output <workspace>/reports/<run-id>/publication.json
```

Repeat --report TARGET=LOCAL_HTML, --packet TARGET=PACKET_JSON,
--review TARGET=RAW_RESPONSE and --confirmation TARGET=CONFIRMATION_RESPONSE
for each new project/owner page. The raw response can
be one object, an array or JSON-fenced text, saved unchanged. The reader copies
only the short candidate ID from the generated view; packet paths are supplied by
the caller. Do not reconstruct replies or replace mismatching IDs/hashes. Missing, failed or stale review is a preparation
error. Schema 1 packets without a confirmation field remain readable only as
legacy evidence; new generation never emits them. Do not remove the field or
rewrite a frozen packet to downgrade review. Index-only navigation refresh retains
the existing pages without new review.
New project packets containing a weekly appendix must include the current
progress, evidence status, risk and next-action fields even when no consolidated
weekly page is requested. Legacy frozen inputs remain readable; generate a new
complete candidate instead of downgrading a new packet.
The helper returns structured `report_summary` counts (projects/closed/unclosed/
owners) and `review_modes`. New runs require independent reviews; use those counts,
and do not substitute a self pass for either required reader.
HTML hidden elements and reply prose are not a source of project counts. Default
output contains only those files. The former `--homepage` / directory generation
path has been removed: do not pass those old arguments. The 2026-09-21 Societas
contract explicitly forbids rebuilding `inner-loop/reports/`; no entry is created by default. An explicitly approved area index uses the
opt-in workflow below; the broader homepage is not changed.

If the user also requests the DRI card integration, add
`--dri-page <existing-repository-relative-DRI-page.html>`. It must exist at the
same draft base inside the selected KB area. Each selected project needs exactly
one card marked `data-project="<project-id>"`. The helper appends a “项目简报” link
inside that card, preserving the existing progress-source link and all other
content, and adds a return link on the corresponding project page. Links name the
actual `index.html` file. It refuses absent/duplicate cards and conflicting managed
links rather than guessing or rewriting the DRI layout. Report the gap if the DRI
page is not yet available; the project-only proposal remains a separate valid use.
Owner pages do not become project-card targets.

The generated JSON retains the exact `task_id`, destination `base_revision`,
fixed `source_revision` and full `changes` array. Identical inputs produce no extra changes. If nothing changed, report that
fact; do not stage an empty proposal or disturb an unrelated draft. Stage replaces
the complete pending proposal: when revising one, re-supply **all reports** it
should still contain, not just a repaired link. A changed draft base requires
re-preparation, not manually editing the JSON binding. Existing user-maintained
report HTML is not overwritten.

No new hosting or Actions workflow is provisioned. A published Git file or Draft
PR URL is not a rendered preview. Return a remotely rendered page URL only after
the existing authorized site has deployed it and access was verified. Otherwise
return the actual draft/change link and its correct delivery status.

### Approved lightweight report entry

When the user or current KB contract explicitly approves `<root>/index.html`,
add `--index` to the preparation command. It builds a directory from generated
report files actually present at the named base plus the selected new reports,
limited to the local registry. It lists project/owner links, report week and each
page's own generation date, with project search and an Owner filter. It does not
translate project names: directory labels use the registry's original `name`,
even when a detail page has a Chinese shorthand title. It does not
infer a team closeout or regenerate old owner summaries. Existing owner reports
retain their original facts and dates; this does not deliver the longitudinal
people-manager view.

The same proposal adds return links to existing generated report pages. Review
these navigation-only edits alongside the selected report updates. Once installed,
the helper keeps its marked index current on later report publication; it refuses
to overwrite a hand-maintained area homepage. The old `reports/` path remains
unused, and the broader 10x landing page and sibling spaces remain untouched.

The directory keeps one current row per project, defaults to non-closed projects,
and sorts by lifecycle then the project record's `updated` date, newest first.
Closed/all filters and date/number sorting remain available. These values come
from the report's source snapshot, not current Git commit time or generation time;
unknown state/date stays unknown. The original report generation date is shown
separately. Do not call document-update time a business-event date.

For legacy generated HTML, the helper reads an explicit weekly heading, lifecycle
badge and source-document update label. It never infers W38/W39 from the generation
date or from a historical citation. A nonweekly page is labelled 项目概览, and
conflicting explicit weeks fail for review. Historical versions remain in Git or
the saved KB history; they are not appended as new rows every week.

For an explicitly requested directory-only refresh, use `--index` with no
`--report`. Existing legacy pages are indexed without claiming regenerated facts.
Selected `--report` files must be emitted by the current renderer; legacy files
missing its metadata are rejected with a regeneration instruction. Metadata
validation does not prove fresh model execution or semantic correctness.
Current output carries `report-format=2`, identifying the newer source-validation
contract. Rerender older files from reviewed inputs; never add this tag by hand
to pass publication. Existing saved pages remain readable/indexable as before.

## Cadence and history for the pilot

For value validation, manual refresh before a project discussion is sufficient.
Propose weekly refresh as a pilot option after users confirm the page is useful;
confirm timing and the actual running instance before registering a live cron.
This is not a PMO completion hook, daily batch writer or unattended publisher.

## Readable history

For a request to view an earlier report, use the existing `kb_change_history`
`latest`/`show` actions to select the saved task/version and `file` to retrieve the
exact report path's HTML. `latest` means the conversation's latest publication,
not necessarily this project's latest version; use a known task ID or the native
KB draft list/show tools to locate the requested record when needed. Check the
saved status, repository, published SHA and
path together. A draft or local preview must not be presented as a published page.
Return the saved link/content and its original dates; do not regenerate, relabel
or add a second history ledger. These records cover retained KB changes, not
necessarily every Git commit. If the requested saved version is unavailable,
state that gap. No new draft, local multi-version site, source edit or cron is
needed merely to read history.
