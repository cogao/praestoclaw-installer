(function() {
  'use strict';

  // ── State ──
  const state = {
    ws: null,
    connected: false,
    waiting: false,
    estopActive: false,
    authFailed: false,
    reconnectDelay: 1000,
    reconnectTimer: null,
    healthTimer: null,
    apiKey: (() => {
      // Read temp key from URL fragment (#key=...) — set by server on auto-open.
      // Fragment is never sent to the server in HTTP requests.
      const m = location.hash.match(/[#&]key=([^&]+)/);
      if (m) {
        history.replaceState(null, '', location.pathname + location.search);
        sessionStorage.setItem('praestoclaw_temp_key', m[1]);
        return m[1];
      }
      return sessionStorage.getItem('praestoclaw_temp_key')
        || localStorage.getItem('praestoclaw_api_key') || '';
    })(),
    entraToken: null,      // Entra ID token (idToken preferred, accessToken fallback)
    entraAccount: null,    // MSAL account object
    msalInstance: null,     // MSAL PublicClientApplication
    entraConfig: null,      // {entra_enabled, entra_tenant_id, entra_client_id}
    // Stash for a WS ``response`` frame that arrived while the user was
    // viewing a foreign (read-only) session. Replayed on switch-back to
    // the local web view to recover from a server GET vs persist race.
    pendingForeignResponse: null,
    theme: localStorage.getItem('praestoclaw_theme') ||
           (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'),
  };

  // ── DOM refs ──
  const $ = id => document.getElementById(id);
  const chatArea = $('chatArea');
  const chatInput = $('chatInput');
  const sendBtn = $('sendBtn');
  const typingRow = $('typingRow');
  const welcomeScreen = $('welcomeScreen');
  const statusDot = $('statusDot');
  const statusText = $('statusText');
  const estopBtn = $('estopBtn');
  const estopBanner = $('estopBanner');
  const estopReason = $('estopReason');
  const estopResetLink = $('estopResetLink');
  const themeToggle = $('themeToggle');
  const sidebar = $('sidebar');
  const sidebarToggle = $('sidebarToggle');
  const sidebarOverlay = $('sidebarOverlay');
  const sessionsList = $('sessionsList');
  const toolsList = $('toolsList');
  const sidebarFooter = $('sidebarFooter');
  const charCount = $('charCount');
  const apiKeyBtn = $('apiKeyBtn');
  const apiKeyModal = $('apiKeyModal');
  const apiKeyClose = $('apiKeyClose');
  const apiKeyInput = $('apiKeyInput');
  const apiKeyToggleVis = $('apiKeyToggleVis');
  const apiKeyStatus = $('apiKeyStatus');
  const apiKeyClear = $('apiKeyClear');
  const apiKeySave = $('apiKeySave');
  const entraSection = $('entraSection');
  const entraSignedOut = $('entraSignedOut');
  const entraSignedIn = $('entraSignedIn');
  const entraDeviceCodeBtn = $('entraDeviceCodeBtn');
  const entraLoginBtn = $('entraLoginBtn');
  const entraLogoutBtn = $('entraLogoutBtn');
  const entraUserName = $('entraUserName');
  const deviceCodeDisplay = $('deviceCodeDisplay');
  const deviceCodeValue = $('deviceCodeValue');
  const deviceCodeLink = $('deviceCodeLink');
  const deviceCodeStatus = $('deviceCodeStatus');

  // ── Markdown setup ──
  if (typeof marked !== 'undefined') {
    marked.setOptions({
      highlight: function(code, lang) {
        if (typeof hljs !== 'undefined' && lang && hljs.getLanguage(lang)) {
          return hljs.highlight(code, { language: lang }).value;
        }
        if (typeof hljs !== 'undefined') {
          return hljs.highlightAuto(code).value;
        }
        return code;
      },
      breaks: true,
      gfm: true,
    });
  }

  function renderMarkdown(text) {
    if (typeof marked !== 'undefined') {
      let html = marked.parse(text);
      // Defense-in-depth sanitization (no DOMPurify dependency):
      // 1. Strip dangerous tags
      html = html.replace(/<(script|iframe|object|embed|form|input|meta|link|base|svg|math)[^>]*>[\s\S]*?<\/\1>/gi, '');
      html = html.replace(/<(script|iframe|object|embed|form|input|meta|link|base|svg|math)[^>]*\/?>/gi, '');
      // 2. Strip inline event handlers (onclick, onerror, onload, etc.)
      html = html.replace(/\son\w+\s*=/gi, ' data-blocked=');
      // 3. Neutralize javascript: / data: URLs in href/src attributes
      html = html.replace(/(href|src)\s*=\s*["']?\s*(javascript|data|vbscript)\s*:/gi, '$1="about:blank" data-blocked-url="$2:');
      return html;
    }
    return text.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
  }

  function escapeHtml(text) {
    const d = document.createElement('div');
    d.textContent = text;
    // innerHTML escapes < > & but not quotes — add quote escaping for safe attribute use
    return d.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  // ── Theme ──
  function applyTheme(theme) {
    state.theme = theme;
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('praestoclaw_theme', theme);
    themeToggle.textContent = theme === 'dark' ? '\u2600' : '\u263E';
  }
  applyTheme(state.theme);

  themeToggle.addEventListener('click', () => {
    applyTheme(state.theme === 'dark' ? 'light' : 'dark');
  });

  // ── Sidebar toggle (mobile) ──
  sidebarToggle.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    sidebarOverlay.classList.toggle('visible');
  });
  sidebarOverlay.addEventListener('click', () => {
    sidebar.classList.remove('open');
    sidebarOverlay.classList.remove('visible');
  });

  // ── API helpers ──
  function apiHeaders() {
    const h = { 'Content-Type': 'application/json' };
    if (state.apiKey) h['X-API-Key'] = state.apiKey;
    else if (state.entraToken) h['Authorization'] = `Bearer ${state.entraToken}`;
    return h;
  }

  async function apiFetch(url, opts = {}) {
    opts.headers = { ...apiHeaders(), ...(opts.headers || {}) };
    const resp = await fetch(url, opts);
    if (resp.status === 401) {
      onAuthFailure();
    }
    return resp;
  }

  function onAuthFailure() {
    if (state.authFailed) return;  // idempotent — prevent re-entrant loops
    state.authFailed = true;
    stopToolPoll();
    stopViewedSessionPoll();
    if (state.reconnectTimer) {
      clearTimeout(state.reconnectTimer);
      state.reconnectTimer = null;
    }
    closeStaleWs();
    state.connected = false;
    // Invalidate current token (but keep entraAccount for silent refresh)
    state.apiKey = '';
    state.entraToken = null;
    localStorage.removeItem('praestoclaw_api_key'); sessionStorage.removeItem('praestoclaw_temp_key');

    // If window is focused, try silent re-auth before showing modal
    if (document.hasFocus() && state.msalInstance && state.entraAccount) {
      updateStatus('re-authenticating…', false);
      state.msalInstance.acquireTokenSilent({
        account: state.entraAccount,
        scopes: ['openid'],
      }).then(result => {
        // Silent refresh succeeded — reconnect seamlessly
        state.authFailed = false;
        onEntraLogin(result);
      }).catch(() => {
        showAuthModal();
      });
      return;
    }

    showAuthModal();
  }

  function showAuthModal() {
    state.authFailed = false;  // allow wsConnect() after user re-authenticates
    state.entraAccount = null;
    // Stop background polling while unauthenticated
    if (state.healthTimer) { clearInterval(state.healthTimer); state.healthTimer = null; }
    const _entraOut = document.getElementById('entraSignedOut');
    const _entraIn = document.getElementById('entraSignedIn');
    if (_entraOut) _entraOut.style.display = '';
    if (_entraIn) _entraIn.style.display = 'none';
    updateKeyBtnState();
    updateStatus('auth required', false);
    openApiKeyModal();
  }

  // ── WebSocket ──
  /** Detach handlers and close a WebSocket without triggering reconnect. */
  function closeStaleWs() {
    if (!state.ws) return;
    state.ws.onclose = null;
    state.ws.onerror = null;
    state.ws.onmessage = null;
    state.ws.close();
    state.ws = null;
  }

  function wsConnect() {
    if (state.authFailed) return;
    if (state.ws && (state.ws.readyState === WebSocket.OPEN || state.ws.readyState === WebSocket.CONNECTING)) return;

    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    let wsUrl = `${proto}//${location.host}/api/ws`;
    if (state.apiKey) wsUrl += `?key=${encodeURIComponent(state.apiKey)}`;
    else if (state.entraToken) wsUrl += `?token=${encodeURIComponent(state.entraToken)}`;
    state.ws = new WebSocket(wsUrl);

    state.ws.onopen = async () => {
      state.connected = true;
      state.authFailed = false;
      state.reconnectDelay = 1000;
      updateStatus('connected', true);
      // Always seed via loadRecentHistory() so _localWebIds learns the
      // server-resolved local web alias before any deep-link kicks in —
      // otherwise opening ?session=<aliased-uuid> would mark the local
      // web view as foreign (read-only).
      await loadRecentHistory();
      const desired = _sessionFromUrl();
      if (desired && desired !== WEB_SESSION_ID && !_localWebIds.has(desired)) {
        await loadSession(desired, { pushUrl: false });
      }
      await reconcileApprovals();
    };

    state.ws.onmessage = (evt) => {
      let data;
      try { data = JSON.parse(evt.data); } catch { return; }

      // The WS represents the local web agent. While the user is viewing
      // a foreign (read-only) session we MUST NOT render local web frames
      // into that view — but we still update agent state (`state.waiting`,
      // poll timers, send button) so it's correct on switch-back.
      const localView = isLocalWebView();

      if (data.type === 'push' || data.kind === 'push') {
        if (!localView) return;  // don't leak push into foreign view
        // Push notification from scheduler/background job — don't affect waiting/typing state.
        // Server frames push as ``{response: <str>, kind: 'push'}`` — the
        // payload may be plain text or a structured JSON object
        // (approval_request / approval_resolved / task_progress).
        let pushPayload = data.content !== undefined ? data.content : data.response;
        try { pushPayload = JSON.parse(pushPayload); } catch { /* plain text */ }
        if (pushPayload && typeof pushPayload === 'object' && pushPayload.type === 'approval_request') {
          addApprovalCard(pushPayload);
        } else if (pushPayload && typeof pushPayload === 'object' && pushPayload.type === 'approval_resolved') {
          _handleApprovalResolved(pushPayload);
        } else if (pushPayload && typeof pushPayload === 'object' && pushPayload.type === 'task_progress') {
          upsertTaskCard(pushPayload);
        } else {
          addMessage('assistant', typeof pushPayload === 'string' ? pushPayload : JSON.stringify(pushPayload));
        }
        return;
      }

      if (data.type === 'tool_progress') {
        if (!localView) return;
        removeToolProgress();
        addToolProgress(data.content || 'tool');
        return;
      }

      if (data.type === 'stream' && !data.done) {
        return;
      }

      // Terminal frame — always update agent/UI state.
      state.waiting = false;
      typingRow.classList.remove('visible');
      removeToolProgress();
      stopToolPoll();
      updateSendState();

      // DOM-mutating branches below: skip when not viewing the local
      // web session. The full response is persisted server-side; the
      // user will see it next time they switch back via loadSession().
      if (data.type === 'approval_request') {
        if (localView) addApprovalCard(data);
      } else if (data.type === 'approval_resolved') {
        // Safe even on foreign view — querySelector misses gracefully.
        _handleApprovalResolved(data);
      } else if (data.error) {
        if (localView) addMessage('assistant', `Error: ${data.error}`);
        else state.pendingForeignResponse = _capStash(`Error: ${data.error}`);
      } else if (data.response !== undefined) {
        if (!localView) {
          // We're viewing a foreign (read-only) session — stash so we can
          // replay on switch-back. There's a real race where the WS frame
          // arrives while we're still on the foreign view, the user then
          // switches to local web, and loadSession's GET races the agent's
          // ``add_message(response)`` write — fetch may return [user] only
          // and the response would otherwise be silently lost until the
          // next user-driven refresh. The stash makes that recoverable.
          state.pendingForeignResponse = _capStash(data.response);
          return;
        }
        // Check if response is a structured approval_resolved JSON
        let parsed = null;
        try { parsed = JSON.parse(data.response); } catch { /* plain text */ }
        if (parsed && parsed.type === 'approval_resolved' && parsed.request_id) {
          // Verify this is a real resolution frame (has required fields)
          const rid = parsed.request_id;
          const card = chatArea.querySelector(`.approval-card[data-request-id="${CSS.escape(rid)}"]`);
          if (card) { _handleApprovalResolved(parsed); }
          else { addMessage('assistant', data.response); }  // no matching card → show as text
        } else {
          // Final poll catches all tool results (including errors, now persisted)
          pollToolCalls().then(() => {
            addMessage('assistant', data.response);
          });
        }
      }
    };

    state.ws.onclose = (evt) => {
      const wasConnected = state.connected;
      state.connected = false;
      stopToolPoll();
      // Code 1008 = Policy Violation (explicit auth rejection)
      // Code 1006 = Abnormal closure — treat as auth failure if credentials
      //   were sent but we never successfully connected
      const hadCredentials = !!(state.apiKey || state.entraToken);
      const authRejected = evt.code === 1008 ||
        (evt.code === 1006 && hadCredentials && !wasConnected);
      if (authRejected || state.authFailed) {
        updateStatus('auth required', false);
        onAuthFailure();
        return;
      }
      updateStatus('disconnected', false);
      scheduleReconnect();
    };

    state.ws.onerror = () => {
      state.connected = false;
      updateStatus('error', false);
    };
  }

  function scheduleReconnect() {
    if (state.authFailed) return;  // Don't reconnect after auth failure
    if (state.reconnectTimer) clearTimeout(state.reconnectTimer);
    state.reconnectTimer = setTimeout(() => {
      if (state.authFailed) return;
      wsConnect();
      state.reconnectDelay = Math.min(state.reconnectDelay * 2, 30000);
    }, state.reconnectDelay);
  }

  function updateStatus(text, ok) {
    statusText.textContent = text;
    statusDot.className = 'status-dot' + (ok ? ' ok' : '');
  }

  // ── Approval card (rendered via Adaptive Cards JS SDK) ──

  // Microsoft Teams HostConfig — loaded from static JSON files
  // Source: github.com/microsoft/AdaptiveCards/samples/HostConfig
  const _hostConfigCache = {};
  async function _getCardHostConfig() {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const key = isDark ? 'dark' : 'light';
    if (_hostConfigCache[key]) return _hostConfigCache[key];
    try {
      const resp = await fetch(`/static/hostconfig-teams-${key}.json`);
      const json = await resp.json();
      _hostConfigCache[key] = new AdaptiveCards.HostConfig(json);
    } catch {
      _hostConfigCache[key] = new AdaptiveCards.HostConfig({});
    }
    return _hostConfigCache[key];
  }

  // Build Adaptive Card JSON from flat fields
  const _AC_COLORS = { unknown: 'Accent', low: 'Good', medium: 'Warning', elevated: 'Warning', high: 'Attention', critical: 'Attention' };

  // Pending card: full card with actions (for live approval)
  function _buildCardFromFields(d) {
    const level = (d.risk_level || 'unknown').toUpperCase();
    const acColor = _AC_COLORS[(d.risk_level || 'unknown')] || 'Default';
    const scoreStr = d.score != null ? d.score + ' / 10' : '?';
    const body = [
      { type: 'ColumnSet', columns: [
        { type: 'Column', width: 'stretch', items: [{ type: 'TextBlock', text: '\u26a0 Approval Required', weight: 'Bolder', size: 'Medium', wrap: true }] },
        { type: 'Column', width: 'auto', verticalContentAlignment: 'Center', items: [{ type: 'TextBlock', text: level, weight: 'Bolder', size: 'Small', color: acColor }] },
      ]},
      { type: 'Container', style: 'emphasis', spacing: 'Small', items: [
        { type: 'TextBlock', text: d.action_preview || d.tool_name || '', fontType: 'Monospace', wrap: true, weight: 'Bolder' },
      ]},
      { type: 'TextBlock', text: d.reason || '', wrap: true, spacing: 'Small' },
    ];
    if (d.trigger) body.push({ type: 'TextBlock', text: d.trigger, size: 'Small', isSubtle: true, spacing: 'Small', wrap: true });
    body.push({ type: 'FactSet', spacing: 'Medium', facts: [
      { title: 'Tool', value: d.tool_name || '' },
      { title: 'Agent', value: d.agent_name || '' },
      { title: 'Score', value: scoreStr },
    ]});
    body.push({ type: 'TextBlock', text: 'Or reply **yes** / **no** / **always**', size: 'Small', isSubtle: true, spacing: 'None', wrap: true });
    if (d.always_allow === true && typeof d.always_allow_scope === 'string' && d.always_allow_scope.trim()) {
      body.push({ type: 'TextBlock', text: d.always_allow_scope, wrap: true, spacing: 'Small' });
    }
    const cardFields = { tool_name: d.tool_name || '', action_preview: d.action_preview || '', reason: d.reason || '', score: d.score, risk_level: d.risk_level || '', agent_name: d.agent_name || '', trigger: d.trigger || '' };
    function _submitData(action, outcome) {
      return { approval_action: action, approval_request_id: d.request_id, resolved_card: _buildResolvedCard(cardFields, outcome) };
    }
    const actions = [
      { type: 'Action.Submit', title: '\u2713 Approve', style: 'positive', data: _submitData('approve', 'approved') },
      { type: 'Action.Submit', title: '\u2717 Deny', style: 'destructive', data: _submitData('deny', 'denied') },
    ];
    if (d.always_allow !== false) {
      actions.push({ type: 'Action.Submit', title: 'Always Allow', data: _submitData('always', 'approved') });
    }
    return { $schema: 'http://adaptivecards.io/schemas/adaptive-card.json', type: 'AdaptiveCard', version: '1.4', body, actions };
  }

  // Resolved card: read-only with full context, no actions (for history + collapsed expand)
  const _OUTCOME_LABELS = { approved: '\u2705 Approved', approved_once: 'Approved once: the allowlist rule was not saved. Future requests may require approval.', approved_always: '\u2705 Always allowed', denied: '\u274c Denied', timeout: '\u23f1 Timed Out', resolved: '\u2611 Resolved' };
  const _OUTCOME_COLORS = { approved: 'Good', approved_once: 'Warning', approved_always: 'Good', denied: 'Attention', timeout: 'Warning', resolved: 'Default' };
  function _buildResolvedCard(d, outcome) {
    const label = _OUTCOME_LABELS[outcome] || _OUTCOME_LABELS.resolved;
    const color = _OUTCOME_COLORS[outcome] || 'Default';
    const scoreStr = d.score != null ? d.score + ' / 10' : '?';
    const body = [
      // Outcome header — no risk badge (decision done, risk level is noise)
      { type: 'TextBlock', text: `${label} \u00b7 ${d.tool_name || ''}`, weight: 'Bolder', color, wrap: true },
      // Action preview
      { type: 'Container', style: 'emphasis', spacing: 'Small', items: [
        { type: 'TextBlock', text: d.action_preview || d.tool_name || '', fontType: 'Monospace', wrap: true },
      ]},
      // Reason
      { type: 'TextBlock', text: d.reason || '', wrap: true, spacing: 'Small', isSubtle: true },
    ];
    // Trigger context
    if (d.trigger) body.push({ type: 'TextBlock', text: d.trigger, size: 'Small', isSubtle: true, spacing: 'Small', wrap: true });
    // Metadata
    body.push({ type: 'FactSet', spacing: 'Medium', facts: [
      { title: 'Tool', value: d.tool_name || '' },
      { title: 'Agent', value: d.agent_name || '' },
      { title: 'Score', value: scoreStr },
    ]});
    return { $schema: 'http://adaptivecards.io/schemas/adaptive-card.json', type: 'AdaptiveCard', version: '1.4', body };
  }

  // Handle real-time approval_resolved notification (cross-channel update)
  function _handleApprovalResolved(d) {
    const rid = d.request_id;
    if (!rid) return;
    const card = chatArea.querySelector(`.approval-card[data-request-id="${CSS.escape(rid)}"]`);
    if (card) {
      card.dataset.authoritativeOutcome = d.status || 'resolved';
      return _collapseApprovalCard(card, card.dataset.authoritativeOutcome);
    }
  }

  // Pre-scan messages to find which approval_requests have been resolved
  function _buildResolvedMap(messages) {
    const map = {};
    for (const m of messages) {
      if (m.role === 'approval_resolved') {
        try {
          const d = JSON.parse(m.content);
          if (d.request_id) map[d.request_id] = d.status || 'resolved';
        } catch (_) {}
      }
    }
    return map;
  }

  async function addApprovalCard(data, insertPoint) {
    if (welcomeScreen.parentNode) welcomeScreen.remove();
    const riskColor = data.risk_color || '#eab308';

    const card = document.createElement('div');
    card.className = 'approval-card';
    card.dataset.requestId = data.request_id;
    card.dataset.toolName = data.tool_name || '';
    card.dataset.actionPreview = data.action_preview || '';
    card.dataset.reason = data.reason || '';
    card.dataset.riskLevel = data.risk_level || '';
    card.dataset.agentName = data.agent_name || '';
    card.dataset.trigger = data.trigger || '';
    if (data.score != null) card.dataset.score = String(data.score);
    card.style.setProperty('--risk-color', riskColor);

    // Resolved bar (hidden until collapse)
    const resolvedBar = document.createElement('div');
    resolvedBar.className = 'approval-resolved-bar';
    resolvedBar.textContent = `${data.tool_name || ''} \u00b7 ${data.action_preview || ''}`;
    resolvedBar.addEventListener('click', () => card.classList.toggle('collapsed'));
    card.appendChild(resolvedBar);

    // Insert into DOM early (correct position), then render card content async
    chatArea.insertBefore(card, insertPoint || typingRow);

    // Build Adaptive Card JSON — use server-provided card or reconstruct from flat fields
    const cardJson = data.adaptive_card || _buildCardFromFields(data);
    if (cardJson && typeof AdaptiveCards !== 'undefined') {
      const ac = new AdaptiveCards.AdaptiveCard();
      ac.hostConfig = await _getCardHostConfig();
      ac.onExecuteAction = (action) => {
        if (action instanceof AdaptiveCards.SubmitAction && action.data) {
          if (card.dataset.actionSubmitted) return;
          card.dataset.actionSubmitted = '1';
          const d = action.data;
          const approved = d.approval_action !== 'deny';
          const always = d.approval_action === 'always';
          // Stash the pre-built resolved card for _collapseApprovalCard
          if (d.resolved_card) card._resolvedCardJson = d.resolved_card;
          resolveApproval(d.approval_request_id, approved, always);
        }
      };
      ac.parse(cardJson);
      const rendered = ac.render();
      if (rendered) card.appendChild(rendered);
    }

    // Countdown timer (outside Adaptive Card — AC is static)
    const timeoutVal = data.auto_timeout != null ? data.auto_timeout : data.reject_timeout;
    if (timeoutVal != null && timeoutVal > 0) {
      const timerEl = document.createElement('div');
      timerEl.style.cssText = 'font-size:12px;color:#888;padding:4px 16px;';
      const isAutoApprove = data.auto_timeout != null;
      const label = isAutoApprove ? 'Proceeding in' : 'Waiting for decision';
      card.appendChild(timerEl);
      const end = Date.now() + timeoutVal * 1000;
      const iv = setInterval(() => {
        const rem = Math.max(0, Math.ceil((end - Date.now()) / 1000));
        const m = Math.floor(rem / 60), s = rem % 60;
        timerEl.textContent = `\u23f1 ${label} ${m}:${String(s).padStart(2, '0')}`;
        if (rem <= 0) {
          clearInterval(iv);
          timerEl.remove();
          if (!card.classList.contains('collapsed')) {
            _collapseApprovalCard(card, isAutoApprove ? 'approved' : 'denied');
          }
        }
      }, 1000);
      card.dataset.approvalTimerId = String(iv);
    }

    if (!insertPoint) card.scrollIntoView({ behavior: 'smooth' });
    return card;  // return for callers that need to await + collapse
  }

  async function _collapseApprovalCard(card, outcome) {
    const cssClass = { approved: 'ok', approved_always: 'ok', denied: 'denied', resolved: '', timeout: 'denied' };
    const key = outcome || 'resolved';
    const previous = card.dataset.resolvedOutcome;
    if ((previous === 'approved_once' || previous === 'approved_always') &&
        (key === 'approved' || key === 'resolved')) return;
    card.dataset.resolvedOutcome = key;
    const revision = (card._resolutionRevision || 0) + 1;
    card._resolutionRevision = revision;

    // Stop countdown timer if running
    if (card.dataset.approvalTimerId) {
      clearInterval(Number(card.dataset.approvalTimerId));
      delete card.dataset.approvalTimerId;
    }

    // Replace the pending Adaptive Card with a resolved one (read-only, no actions)
    const oldAc = card.querySelector('.ac-adaptiveCard');
    if (oldAc) oldAc.remove();
    // Remove countdown timer
    card.querySelectorAll('[style*="font-size:12px"]').forEach(el => el.remove());

    // Use pre-built resolved card (from Python via submit data) or build from dataset
    const resolvedJson = (key !== 'approved_once' && key !== 'approved_always' && card._resolvedCardJson) || _buildResolvedCard({
      tool_name: card.dataset.toolName || '',
      action_preview: card.dataset.actionPreview || '',
      reason: card.dataset.reason || '',
      risk_level: card.dataset.riskLevel || '',
      agent_name: card.dataset.agentName || '',
      trigger: card.dataset.trigger || '',
      score: card.dataset.score != null ? Number(card.dataset.score) : null,
    }, key);
    if (typeof AdaptiveCards !== 'undefined') {
      const ac = new AdaptiveCards.AdaptiveCard();
      ac.hostConfig = await _getCardHostConfig();
      if (card._resolutionRevision !== revision) return;
      ac.parse(resolvedJson);
      const rendered = ac.render();
      if (rendered) card.appendChild(rendered);
    }

    // Update resolved bar
    card.classList.add('collapsed');
    const bar = card.querySelector('.approval-resolved-bar');
    if (bar) {
      bar.style.display = 'flex';
      bar.textContent = `${_OUTCOME_LABELS[key] || _OUTCOME_LABELS.resolved} \u00b7 ${card.dataset.toolName || ''} \u00b7 ${card.dataset.actionPreview || ''}`;
      bar.classList.remove('ok', 'denied');
      bar.style.color = key === 'approved_once' ? '#b45309' : '';
      if (cssClass[key]) bar.classList.add(cssClass[key]);
    }
  }

  async function addResolvedApprovalCard(d, insertPoint) {
    const outcome = d.status === 'approved_once' || d.status === 'approved_always' ? d.status
      : d.status?.startsWith('approved') ? 'approved' : d.status?.startsWith('denied') ? 'denied' : 'resolved';
    const card = document.createElement('div');
    card.className = 'approval-card collapsed';
    card.dataset.requestId = d.request_id || '';
    card.style.setProperty('--risk-color', d.risk_color || '#eab308');

    const cssClass = { approved: 'ok', approved_always: 'ok', denied: 'denied', resolved: '' };
    const bar = document.createElement('div');
    bar.className = `approval-resolved-bar ${cssClass[outcome] || ''}`;
    bar.style.display = 'flex';
    bar.textContent = `${_OUTCOME_LABELS[outcome]} \u00b7 ${d.tool_name || ''} \u00b7 ${d.action_preview || ''}`;
    if (outcome === 'approved_once') bar.style.color = '#b45309';
    bar.addEventListener('click', () => card.classList.toggle('collapsed'));
    card.appendChild(bar);

    // Insert into DOM early (correct position), then render async
    chatArea.insertBefore(card, insertPoint || typingRow);

    // Render resolved Adaptive Card (visible on expand)
    if (typeof AdaptiveCards !== 'undefined') {
      const resolvedJson = _buildResolvedCard(d, outcome);
      const ac = new AdaptiveCards.AdaptiveCard();
      ac.hostConfig = await _getCardHostConfig();
      ac.parse(resolvedJson);
      const rendered = ac.render();
      if (rendered) card.appendChild(rendered);
    }
    return card;
  }

  // Exposed globally for approval resolution (called via addEventListener on data-action buttons)
  window.resolveApproval = async function resolveApproval(requestId, approved, always = false) {
    const card = document.querySelector(`.approval-card[data-request-id="${requestId}"]`);
    if (card) {
      card.querySelectorAll('.ac-pushButton, .approval-btn').forEach(b => { b.disabled = true; });
    }
    try {
      const r = await apiFetch(`/api/approvals/${requestId}/resolve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ approved, always, resolver: state.user || 'web-user' }),
      });
      if (!r.ok) throw new Error(`Server returned ${r.status}`);
      const result = await r.json().catch(() => null);
      const outcome = !approved ? 'denied'
        : always && result?.allowlist_saved === false ? 'approved_once'
        : always && result?.allowlist_saved === true ? 'approved_always' : 'approved';
      if (card) {
        const pushed = card.dataset.authoritativeOutcome;
        const refinesApproval = pushed === 'approved' && always && typeof result?.allowlist_saved === 'boolean';
        await _collapseApprovalCard(card, pushed && !refinesApproval ? pushed : outcome);
      }
      // Agent continues after approval — show typing and resume polling
      if (approved) {
        state.waiting = true;
        typingRow.classList.add('visible');
        startToolPoll();
        scrollToBottom();
      }
    } catch (e) {
      if (card) card.querySelectorAll('.ac-pushButton, .approval-btn').forEach(b => { b.disabled = false; });
    }
  };

  // ── Messages ──
  function addMessage(role, content, insertPoint) {
    if (welcomeScreen.parentNode) welcomeScreen.remove();
    const row = document.createElement('div');
    row.className = `message-row ${role}`;
    const bubble = document.createElement('div');
    bubble.className = 'message';
    if (role === 'assistant') {
      bubble.innerHTML = renderMarkdown(content);
    } else {
      bubble.textContent = content;
    }
    row.appendChild(bubble);
    chatArea.insertBefore(row, insertPoint || typingRow);
    if (!insertPoint) scrollToBottom();
  }

  // ── Task progress card (single card per task_id, updated in place) ──
  function upsertTaskCard(payload) {
    if (welcomeScreen.parentNode) welcomeScreen.remove();
    const taskId = String(payload.task_id || '');
    if (!taskId) return;
    const md = String(payload.markdown || '');
    const sel = `.task-card[data-task-id="${CSS.escape(taskId)}"]`;
    let row = chatArea.querySelector(sel);
    let bubble;
    let actionsBar;
    const wasAtBottom = isNearBottom();
    if (row) {
      bubble = row.querySelector('.message');
      actionsBar = row.querySelector('.task-card-actions');
    } else {
      row = document.createElement('div');
      row.className = 'message-row assistant task-card';
      row.dataset.taskId = taskId;
      bubble = document.createElement('div');
      bubble.className = 'message';
      row.appendChild(bubble);
      actionsBar = document.createElement('div');
      actionsBar.className = 'task-card-actions';
      bubble.appendChild(actionsBar);
      chatArea.insertBefore(row, typingRow);
    }
    row.dataset.stage = String(payload.stage || '');
    row.dataset.terminal = payload.terminal ? '1' : '0';
    bubble.innerHTML = renderMarkdown(md);
    // Re-append the actions bar (innerHTML wiped it).
    if (!actionsBar) {
      actionsBar = document.createElement('div');
      actionsBar.className = 'task-card-actions';
    } else if (actionsBar.parentNode !== bubble) {
      // Was detached by innerHTML; recreate fresh.
      actionsBar = document.createElement('div');
      actionsBar.className = 'task-card-actions';
    }
    bubble.appendChild(actionsBar);
    _renderTaskCardButtons(actionsBar, payload, taskId);
    if (wasAtBottom) scrollToBottom();
  }

  function _renderTaskCardButtons(bar, payload, taskId) {
    bar.textContent = '';
    if (payload.terminal) return;
    const stage = String(payload.stage || '');
    const role = String(payload.role || '');
    const buttons = [];
    if (role === 'recipient' && stage === 'waiting_approval') {
      buttons.push({ label: 'Approve', cmd: `/task approve ${taskId}`, kind: 'primary' });
      buttons.push({ label: 'Deny', cmd: `/task deny ${taskId}`, kind: 'danger' });
    } else if (role === 'recipient' && stage === 'executing') {
      // docs/07 §10: receiver uses interrupt to stop a task they previously approved.
      buttons.push({ label: 'Interrupt', cmd: `/task interrupt ${taskId}`, kind: 'danger' });
    } else if (role === 'sender' && ['queued', 'gating', 'waiting_approval', 'executing'].includes(stage)) {
      buttons.push({ label: 'Cancel', cmd: `/task cancel ${taskId}`, kind: 'secondary' });
    }
    for (const b of buttons) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `task-card-btn ${b.kind}`;
      btn.textContent = b.label;
      btn.addEventListener('click', () => {
        if (!state.connected) return;
        // Disable all buttons in this card optimistically.
        bar.querySelectorAll('button').forEach(x => { x.disabled = true; });
        try {
          state.ws.send(JSON.stringify({ prompt: b.cmd, sender_id: 'web-user' }));
        } catch (e) {
          bar.querySelectorAll('button').forEach(x => { x.disabled = false; });
        }
      });
      bar.appendChild(btn);
    }
  }

  function isNearBottom() {
    const threshold = 120;
    return (chatArea.scrollHeight - chatArea.scrollTop - chatArea.clientHeight) < threshold;
  }

  function _maybeTaskProgress(content) {
    if (typeof content !== 'string' || !content.startsWith('{')) return null;
    try {
      const obj = JSON.parse(content);
      if (obj && typeof obj === 'object' && obj.type === 'task_progress' && obj.task_id) return obj;
    } catch (_) {}
    return null;
  }

  // ── Tool Call rendering ──
  function _buildToolCallItem(tc, isLive) {
    const fn = tc.function || {};
    const name = fn.name || tc.name || 'unknown';
    let argsStr = '';
    try {
      const args = typeof fn.arguments === 'string' ? JSON.parse(fn.arguments) : (fn.arguments || {});
      argsStr = JSON.stringify(args, null, 2);
    } catch { argsStr = fn.arguments || '{}'; }

    const item = document.createElement('div');
    item.className = 'tool-call-item';
    item.dataset.toolCallId = tc.id || '';

    const header = document.createElement('div');
    header.className = 'tool-call-header';
    const statusLabel = isLive ? '⏳ doing' : '⚙ called';
    header.innerHTML = `<span class="tool-call-name"></span><span class="tool-call-status running">${statusLabel}</span><span class="tool-call-duration"></span><span class="tool-call-chevron">&#9654;</span>`;
    header.querySelector('.tool-call-name').textContent = name;
    header.addEventListener('click', () => item.classList.toggle('expanded'));

    // Live elapsed timer
    if (isLive) {
      const startTime = Date.now();
      item.dataset.startTime = String(startTime);
      const durEl = header.querySelector('.tool-call-duration');
      const _timer = setInterval(() => {
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        durEl.textContent = elapsed + 's';
      }, 200);
      item.dataset.timerId = String(_timer);
    }

    const detail = document.createElement('div');
    detail.className = 'tool-call-detail';
    detail.innerHTML = `<div class="tool-call-detail-label">Arguments</div><pre class="tool-args-pre"></pre><div class="tool-call-detail-label">Result</div><pre class="tool-result-pre" style="color:var(--text-tertiary);font-style:italic">waiting...</pre>`;
    detail.querySelector('.tool-args-pre').textContent = argsStr;

    item.appendChild(header);
    item.appendChild(detail);
    return item;
  }

  function addToolCallGroup(assistantMsg, insertPoint, isLive) {
    if (welcomeScreen.parentNode) welcomeScreen.remove();
    const toolCalls = assistantMsg.tool_calls || [];
    if (!toolCalls.length) return;

    const group = document.createElement('div');
    group.className = 'tool-call-group';
    toolCalls.forEach(tc => group.appendChild(_buildToolCallItem(tc, !!isLive)));

    chatArea.insertBefore(group, insertPoint || typingRow);
    if (!insertPoint) scrollToBottom();
    return group;
  }

  function updateToolResult(toolCallId, content, isError) {
    const item = chatArea.querySelector(`.tool-call-item[data-tool-call-id="${CSS.escape(toolCallId)}"]`);
    if (!item) return;
    const statusEl = item.querySelector('.tool-call-status');
    const durEl = item.querySelector('.tool-call-duration');
    const resultPre = item.querySelector('.tool-result-pre');

    // Stop elapsed timer and show final duration
    if (item.dataset.timerId) {
      clearInterval(Number(item.dataset.timerId));
      delete item.dataset.timerId;
    }
    if (item.dataset.startTime && durEl) {
      const elapsed = ((Date.now() - Number(item.dataset.startTime)) / 1000).toFixed(1);
      durEl.textContent = elapsed + 's';
    }

    if (statusEl) {
      statusEl.textContent = isError ? '❌ error' : '✅ done';
      statusEl.className = `tool-call-status ${isError ? 'error' : 'done'}`;
    }
    if (resultPre) {
      resultPre.style.color = '';
      resultPre.style.fontStyle = '';
      const display = content.length > 2000 ? content.slice(0, 2000) + '\n... (truncated)' : content;
      resultPre.textContent = display;
    }
  }

  function addToolProgress(toolName) {
    if (welcomeScreen.parentNode) welcomeScreen.remove();
    const row = document.createElement('div');
    row.className = 'tool-progress-row';
    row.id = 'toolProgressCurrent';
    row.innerHTML = `<div class="tool-progress-spinner"></div><span>Running <strong></strong>...</span>`;
    row.querySelector('strong').textContent = toolName;
    chatArea.insertBefore(row, typingRow);
    scrollToBottom();
    return row;
  }

  function removeToolProgress() {
    const el = document.getElementById('toolProgressCurrent');
    if (el) el.remove();
  }

  // ── Live tool call polling ──
  // Poll the session every 1.5s while waiting to detect new tool calls
  // and render them with "doing" status + elapsed timer. Final poll on
  // response arrival updates remaining cards to "done".
  const WEB_SESSION_ID = 'local_webchat:web-user';
  const SESSION_URL = `/api/sessions/${encodeURIComponent(WEB_SESSION_ID)}`;
  let _lastSeenMsgCount = 0;
  let _pollTimer = null;

  let _viewedSessionId = WEB_SESSION_ID;
  let _viewedLastSeenCount = 0;
  let _viewedPollTimer = null;
  const _localWebIds = new Set([WEB_SESSION_ID]);

  // Bound the stash so a giant assistant response (e.g. a Copilot dump)
  // can't sit in memory indefinitely if the user never returns.
  const _STASH_MAX = 64 * 1024;
  function _capStash(s) {
    if (typeof s !== 'string' || s.length <= _STASH_MAX) return s;
    return s.slice(0, _STASH_MAX) + '\n…[truncated; reload session to view full]';
  }

  function startToolPoll() {
    stopToolPoll();
    _pollTimer = setInterval(pollToolCalls, 1500);
  }

  function stopToolPoll() {
    if (_pollTimer) { clearInterval(_pollTimer); _pollTimer = null; }
  }

  function startViewedSessionPoll() {
    stopViewedSessionPoll();
    _viewedPollTimer = setInterval(pollViewedSession, 2000);
  }

  function stopViewedSessionPoll() {
    if (_viewedPollTimer) { clearInterval(_viewedPollTimer); _viewedPollTimer = null; }
  }

  async function pollViewedSession() {
    if (state.authFailed) { stopViewedSessionPoll(); return; }
    if (!isViewingForeignSession()) {
      stopViewedSessionPoll();
      return;
    }
    // Capture id at request time so a late response from a previously-viewed
    // session can't render into a different view.
    const requestedId = _viewedSessionId;
    try {
      const resp = await apiFetch(`/api/sessions/${encodeURIComponent(requestedId)}`);
      if (!resp.ok) return;
      const data = await resp.json();
      if (requestedId !== _viewedSessionId) return;
      const allMsgs = data.messages || [];
      if (allMsgs.length <= _viewedLastSeenCount) return;
      const newMsgs = allMsgs.slice(_viewedLastSeenCount);
      _viewedLastSeenCount = allMsgs.length;
      await renderSessionMessages(newMsgs, false);
      if (requestedId === _viewedSessionId) scrollToBottom();
    } catch (_) { /* best-effort */ }
  }

  async function pollToolCalls() {
    if (state.authFailed) { stopToolPoll(); return; }
    // Don't render local-web tool calls into a foreign session view.
    // The poll keeps running so it stops cleanly on the terminal WS frame;
    // when the user switches back, loadSession() repaints history (which
    // includes any tool calls that arrived while away) and re-syncs
    // _lastSeenMsgCount, so we never re-render or miss anything.
    if (!isLocalWebView()) return;
    try {
      const resp = await apiFetch(SESSION_URL);
      if (!resp.ok) return;
      const data = await resp.json();
      const allMsgs = data.messages || [];
      const newMsgs = allMsgs.slice(_lastSeenMsgCount);
      _lastSeenMsgCount = allMsgs.length;

      for (const m of newMsgs) {
        if (m.role === 'assistant' && m.tool_calls && m.tool_calls.length) {
          removeToolProgress();
          addToolCallGroup(m, null, true);
        } else if (m.role === 'tool') {
          updateToolResult(m.tool_call_id || '', m.content || '', !!m.is_error);
          // After tool result, agent continues LLM call — show typing (only while waiting)
          if (state.waiting) {
            typingRow.classList.add('visible');
            scrollToBottom();
          }
        }
      }
    } catch (_) { /* best-effort */ }
  }

  function clearMessages() {
    // Stop any running tool-call elapsed timers before removing DOM
    chatArea.querySelectorAll('.tool-call-item[data-timer-id]').forEach(el => {
      clearInterval(Number(el.dataset.timerId));
    });
    chatArea.querySelectorAll('.message-row, .tool-call-group, .tool-progress-row, .history-divider, .history-load-more, .approval-card')
      .forEach(r => r.remove());
  }

  function scrollToBottom() {
    requestAnimationFrame(() => {
      chatArea.scrollTop = chatArea.scrollHeight;
    });
  }

  // ── Send ──
  const FOREIGN_SESSION_HINT = 'Read-only: Viewing a session not owned by the local web user.';
  const READY_INPUT_HINT = '';

  function isViewingForeignSession() {
    if (!_viewedSessionId) return false;
    // Only the local WS-fed web session is writable. Sends always land
    // there, so any other view (remote `webchat:*`, Teams, scheduler)
    // must be read-only — otherwise the user types into a foreign-looking
    // bubble but the agent answers from the local context.
    return !_localWebIds.has(_viewedSessionId);
  }

  // True while the chatArea is showing a session that the local agent loop
  // (and the WS attached to it) writes into. Used to gate live DOM updates
  // so the local web session's typing indicator / tool calls / responses
  // never leak into a read-only foreign session view.
  function isLocalWebView() {
    return _localWebIds.has(_viewedSessionId);
  }

  function sendMessage() {
    if (isViewingForeignSession()) return;
    const text = chatInput.value.trim();
    if (!text || !state.connected || state.waiting) return;

    addMessage('user', text);
    chatInput.value = '';
    chatInput.style.height = '44px';
    charCount.textContent = '0';
    updateSendState();

    state.waiting = true;
    typingRow.classList.add('visible');
    scrollToBottom();

    // Start polling for tool calls while the agent works
    startToolPoll();

    state.ws.send(JSON.stringify({ prompt: text, sender_id: 'web-user' }));
  }

  function updateSendState() {
    const foreign = isViewingForeignSession();
    const hasText = chatInput.value.trim().length > 0;
    chatInput.disabled = foreign;
    chatInput.title = foreign ? FOREIGN_SESSION_HINT : READY_INPUT_HINT;
    chatInput.placeholder = foreign ? 'Read-only session' : 'Type a message...';
    sendBtn.disabled = foreign || !hasText || !state.connected || state.waiting;
    sendBtn.title = foreign ? FOREIGN_SESSION_HINT : '';
  }

  sendBtn.addEventListener('click', sendMessage);
  chatInput.addEventListener('input', () => {
    charCount.textContent = chatInput.value.length;
    updateSendState();
    // Auto-resize
    chatInput.style.height = '44px';
    chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
    acUpdate();
  });

  // ── Slash-command autocomplete ──────────────────────────────────────────
  const SLASH_COMMANDS = [
    { cmd: '/new',        desc: 'Clear session, start fresh' },
    { cmd: '/help',       desc: 'Show all available commands' },
    { cmd: '/status',     desc: 'Show agent status and session info' },
    { cmd: '/memory',     desc: 'Show MEMORY.md content' },
    { cmd: '/tools',      desc: 'List available tools' },
    { cmd: '/skills',     desc: 'List loaded skills' },
    { cmd: '/history',    desc: 'Show last 10 messages in session' },
    { cmd: '/history 20', desc: 'Show last 20 messages in session' },
    { cmd: '/model',      desc: 'Show or switch LLM model' },
    { cmd: '/compact',    desc: 'Manually trigger context compaction' },
    { cmd: '/estop',      desc: 'Emergency stop — halt all activity' },
  ];

  const acEl = document.getElementById('slashAc');
  let acItems = [], acIdx = -1;

  function acUpdate() {
    const val = chatInput.value;
    if (!val.startsWith('/') || val.includes(' ')) { acHide(); return; }
    const q = val.toLowerCase();
    acItems = SLASH_COMMANDS.filter(c => c.cmd.startsWith(q));
    acIdx = -1;
    acEl.innerHTML = '';
    acItems.forEach((item, i) => {
      const d = document.createElement('div');
      d.className = 'slash-ac-item';
      d.setAttribute('role', 'option');
      d.setAttribute('aria-selected', 'false');
      d.id = `slash-ac-opt-${i}`;
      d.innerHTML = `<span class="slash-ac-cmd">${item.cmd}</span><span class="slash-ac-desc">${item.desc}</span>`;
      d.addEventListener('mousedown', e => { e.preventDefault(); acSelect(i); });
      acEl.appendChild(d);
    });
    const visible = acItems.length > 0;
    acEl.style.display = visible ? 'block' : 'none';
    chatInput.setAttribute('aria-expanded', visible ? 'true' : 'false');
  }

  function acHide() {
    acEl.style.display = 'none';
    chatInput.setAttribute('aria-expanded', 'false');
    chatInput.removeAttribute('aria-activedescendant');
    acItems = []; acIdx = -1;
  }

  function acHighlight(i) {
    [...acEl.querySelectorAll('.slash-ac-item')].forEach((el, j) => {
      el.classList.toggle('active', j === i);
      el.setAttribute('aria-selected', j === i ? 'true' : 'false');
    });
    chatInput.setAttribute('aria-activedescendant', `slash-ac-opt-${i}`);
    acIdx = i;
  }

  function acSelect(i) {
    const item = acItems[i];
    if (!item) return;
    chatInput.value = item.cmd + ' ';
    acHide();
    chatInput.dispatchEvent(new Event('input'));
    chatInput.focus();
  }

  chatInput.addEventListener('keydown', (e) => {
    if (acItems.length) {
      if (e.key === 'ArrowUp')   { e.preventDefault(); acHighlight((acIdx - 1 + acItems.length) % acItems.length); return; }
      if (e.key === 'ArrowDown') { e.preventDefault(); acHighlight((acIdx + 1) % acItems.length); return; }
      if (e.key === 'Tab')       { e.preventDefault(); acSelect(acIdx >= 0 ? acIdx : 0); return; }
      if (e.key === 'Escape')    { acHide(); return; }
    }
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); if (acIdx >= 0) { acSelect(acIdx); } else { sendMessage(); } }
  });

  chatInput.addEventListener('blur', () => setTimeout(acHide, 150));

  // ── Health polling ──
  async function reconcileApprovals() {
    // Fetch actually-pending approvals from the server, then:
    // 1. Add any pending approvals not already rendered
    // 2. Mark history approval cards that are no longer pending as resolved
    try {
      const resp = await apiFetch('/api/approvals');
      if (!resp.ok) return;
      const data = await resp.json();
      const pendingIds = new Set((data.pending || []).map(r => r.id));

      // Add truly pending approvals not yet in DOM
      (data.pending || []).forEach(req => {
        if (!chatArea.querySelector(`.approval-card[data-request-id="${CSS.escape(req.id)}"]`)) {
          addApprovalCard({
            type: 'approval_request',
            request_id: req.id,
            tool_name: req.tool_name,
            args: req.args || {},
            action_preview: req.action_preview,
            trigger: req.trigger,
            score: req.score,
            risk_level: req.risk_level,
            risk_color: req.risk_color,
            always_allow: req.always_allow,
            always_allow_scope: req.always_allow_scope,
            reason: req.reason || '',
            agent_name: req.agent_name || '',
            auto_timeout: null,
          });
        }
      });

      // Build resolved outcomes map from server
      const resolvedMap = {};
      (data.resolved || []).forEach(r => { resolvedMap[r.id] = r.status; });

      // Mark stale approval cards (from history) as resolved + collapse
      chatArea.querySelectorAll('.approval-card[data-request-id]').forEach(card => {
        const rid = card.dataset.requestId;
        const outcome = resolvedMap[rid] || 'resolved';
        if (!pendingIds.has(rid) && (!card.classList.contains('collapsed') ||
            (resolvedMap[rid] && outcome !== card.dataset.resolvedOutcome))) {
          if (card.dataset.approvalTimerId) {
            clearInterval(Number(card.dataset.approvalTimerId));
            delete card.dataset.approvalTimerId;
          }
          const timeoutEl = card.querySelector('.approval-timeout');
          if (timeoutEl) timeoutEl.remove();
          _collapseApprovalCard(card, outcome);
        }
      });
    } catch (_) {}
  }

  async function loadRecentHistory() {
    try {
      // Try to load full session history (including tool messages)
      const resp = await apiFetch(SESSION_URL);
      if (!resp.ok) {
        // Fallback to recent visible messages
        await loadRecentHistoryFallback();
        return;
      }
      const data = await resp.json();
      // Seed _localWebIds: this fetch is for the local web session
      // that the WS feeds, so we know that resolved id is WS-fed too.
      if (data.session_id) {
        _localWebIds.add(data.session_id);
      }
      const allMessages = data.messages || [];
      if (!allMessages.length) return;

      // Show last N messages (configurable), with a "load more" button
      const INITIAL_LIMIT = 30;
      const displayMessages = allMessages.length > INITIAL_LIMIT ? allMessages.slice(-INITIAL_LIMIT) : allMessages;
      const hasMore = allMessages.length > INITIAL_LIMIT;

      if (hasMore) {
        const loadMoreDiv = document.createElement('div');
        loadMoreDiv.className = 'history-load-more';
        const btn = document.createElement('button');
        btn.textContent = `Load earlier messages (${allMessages.length - INITIAL_LIMIT} more)`;
        btn.addEventListener('click', () => {
          loadMoreDiv.remove();
          renderSessionMessages(allMessages.slice(0, allMessages.length - INITIAL_LIMIT), true);
        });
        loadMoreDiv.appendChild(btn);
        chatArea.insertBefore(loadMoreDiv, typingRow);
      }

      const divider = document.createElement('div');
      divider.className = 'history-divider';
      divider.textContent = `— session history (${allMessages.length} messages) —`;
      chatArea.insertBefore(divider, typingRow);

      renderSessionMessages(displayMessages, false);
      _lastSeenMsgCount = allMessages.length;  // sync counter
    } catch (_) {
      await loadRecentHistoryFallback();
    }
  }

  async function loadRecentHistoryFallback() {
    try {
      const resp = await apiFetch('/api/session/recent?channel=local_webchat&sender_id=web-user&limit=20');
      if (!resp.ok) return;
      const messages = await resp.json();
      if (!messages.length) return;
      const divider = document.createElement('div');
      divider.className = 'history-divider';
      divider.textContent = `— last ${messages.length} messages —`;
      chatArea.insertBefore(divider, typingRow);
      // Pre-scan: collect resolved request IDs so we render the right card type
      const resolvedMap = _buildResolvedMap(messages);
      const cardPromises = [];
      messages.forEach(m => {
        if (m.role === 'user') addMessage('user', m.content || '');
        else if (m.role === 'assistant' && m.content) {
          const taskPayload = _maybeTaskProgress(m.content);
          if (taskPayload) upsertTaskCard(taskPayload);
          else addMessage('assistant', m.content);
        }
        else if (m.role === 'approval_request') {
          try {
            const d = JSON.parse(m.content);
            if (resolvedMap[d.request_id]) {
              cardPromises.push(addResolvedApprovalCard({ ...d, status: resolvedMap[d.request_id] }));
            } else {
              cardPromises.push(addApprovalCard({ type: 'approval_request', ...d, auto_timeout: null }));
            }
          } catch (_) {}
        }
        // approval_resolved already consumed by pre-scan
      });
      await Promise.allSettled(cardPromises);
      // Sync counter — fallback doesn't know total, so fetch it
      apiFetch(SESSION_URL).then(r => r.ok ? r.json() : null)
        .then(d => { if (d) _lastSeenMsgCount = (d.messages || []).length; })
        .catch(() => {});
    } catch (_) {}
  }

  async function renderSessionMessages(messages, prepend) {
    const insertPoint = prepend
      ? (chatArea.querySelector('.history-divider') || typingRow)
      : typingRow;

    // Pre-scan: collect resolved request IDs
    const resolvedMap = _buildResolvedMap(messages);
    const cardPromises = [];

    messages.forEach(m => {
      if (m.role === 'user') {
        addMessage('user', m.content || '', insertPoint);
      } else if (m.role === 'assistant') {
        if (m.tool_calls && m.tool_calls.length) {
          if (m.content) addMessage('assistant', m.content, insertPoint);
          addToolCallGroup(m, insertPoint);
        } else if (m.content) {
          const taskPayload = _maybeTaskProgress(m.content);
          if (taskPayload) {
            upsertTaskCard(taskPayload);
          } else {
            addMessage('assistant', m.content, insertPoint);
          }
        }
      } else if (m.role === 'tool') {
        const toolCallId = m.tool_call_id || '';
        if (toolCallId) {
          updateToolResult(toolCallId, m.content || '', !!m.is_error);
        }
      } else if (m.role === 'approval_request') {
        try {
          const d = JSON.parse(m.content);
          if (resolvedMap[d.request_id]) {
            cardPromises.push(addResolvedApprovalCard({ ...d, status: resolvedMap[d.request_id] }, insertPoint));
          } else {
            cardPromises.push(addApprovalCard({ type: 'approval_request', ...d, auto_timeout: null }, insertPoint));
          }
        } catch (_) {}
      }
      // approval_resolved already consumed by pre-scan
    });
    await Promise.allSettled(cardPromises);
  }

  async function fetchHealth() {
    try {
      const resp = await fetch('/api/health');  // public endpoint — no auth needed
      if (!resp.ok) return;
      const data = await resp.json();

      state.estopActive = data.estop?.halted || false;
      estopBanner.classList.toggle('visible', state.estopActive);
      estopReason.textContent = data.estop?.reason || '';
      estopBtn.classList.toggle('active', state.estopActive);

      sidebarFooter.textContent = `PraestoClaw ${data.version || ''}`;
    } catch { /* ignore */ }
  }

  // ── Sessions ──
  async function fetchSessions() {
    try {
      sessionsList.innerHTML = '<div class="sidebar-empty">Loading...</div>';
      const resp = await apiFetch('/api/sessions');
      if (!resp.ok) { sessionsList.innerHTML = '<div class="sidebar-empty">Failed to load</div>'; return; }
      const data = await resp.json();

      if (!data.length) {
        sessionsList.innerHTML = '<div class="sidebar-empty">No sessions yet</div>';
        return;
      }

      // Normalize: server may return either `id` or `session_id` per row.
      data.forEach(s => { s.session_id = s.session_id || s.id || ''; });

      // Split into regular sessions and scheduler sessions
      const regularSessions = data.filter(s => s.group !== 'scheduler');
      const schedSessions = data.filter(s => s.group === 'scheduler');

      const webSessions = regularSessions.filter(s => s.group === 'web');
      const teamsSessions = regularSessions.filter(s => s.group === 'teams');
      const otherSessions = regularSessions.filter(s => s.group !== 'web' && s.group !== 'teams');

      sessionsList.innerHTML = '';
      if (!regularSessions.length && !schedSessions.length) {
        sessionsList.innerHTML = '<div class="sidebar-empty">No sessions yet</div>';
        return;
      }

      function appendSessionItems(group, title, { stripPrefix = null, openByDefault = false } = {}) {
        if (!group.length) return;
        const details = document.createElement('details');
        details.style.cssText = 'margin-top:6px';
        const containsActive = isViewingForeignSession() &&
          group.some(s => s.session_id === _viewedSessionId);
        details.open = openByDefault || containsActive;
        details.innerHTML = `<summary style="font-size:10px;color:var(--text-tertiary);cursor:pointer;padding:4px 10px;user-select:none">${title} (${group.length})</summary>`;
        group.forEach(s => {
          const item = document.createElement('div');
          item.className = 'session-item';
          if (s.session_id === _viewedSessionId) item.classList.add('active');
          const count = s.message_count ?? '';
          const displayId = stripPrefix ? s.session_id.replace(stripPrefix, '') : s.session_id;
          item.innerHTML = `<span class="session-name" title="${escapeHtml(s.session_id)}">${escapeHtml(displayId)}</span><span class="count">${count}</span>`;
          item.addEventListener('click', () => loadSession(s.session_id));
          details.appendChild(item);
        });
        sessionsList.appendChild(details);
      }

      appendSessionItems(webSessions, 'Web', { openByDefault: true });
      appendSessionItems(teamsSessions, 'Teams');
      appendSessionItems(otherSessions, 'Other');
      appendSessionItems(schedSessions, 'Scheduler', { stripPrefix: /^scheduler[_:]/ });
    } catch(error) {
      console.error('Error fetching sessions:', error);
      sessionsList.innerHTML = '<div class="sidebar-empty">Error loading</div>';
    }
  }

  async function loadSession(sessionId, { pushUrl = true } = {}) {
    // Cancel any in-flight viewer poll — its late response would render into the new view.
    stopViewedSessionPoll();
    try {
      const resp = await apiFetch(`/api/sessions/${encodeURIComponent(sessionId)}`);
      if (!resp.ok) {
        if (resp.status === 404 && sessionId !== WEB_SESSION_ID) {
          _viewedSessionId = WEB_SESSION_ID;
          if (pushUrl) _pushSessionToUrl(WEB_SESSION_ID);
          clearMessages();
          await loadRecentHistory();
          updateSendState();
          scrollToBottom();
        }
        return;
      }
      const data = await resp.json();

      clearMessages();
      if (welcomeScreen.parentNode) welcomeScreen.remove();

      const messages = data.messages || [];
      renderSessionMessages(messages, false);
      // Trust the server-resolved id (handles ``channel:sender`` shorthand).
      _viewedSessionId = data.session_id || sessionId;
      _viewedLastSeenCount = messages.length;
      if (_localWebIds.has(_viewedSessionId)) {
        // WS already feeds this session — sync the tool-poll counter so
        // pollToolCalls doesn't re-render history rows, and skip the
        // viewer-poll to avoid double-rendering. Also restore the typing
        // indicator if the agent is still mid-response (user might have
        // navigated away during a wait).
        _lastSeenMsgCount = messages.length;
        if (state.waiting) typingRow.classList.add('visible');
        // Replay any response delivered via WS while we were on a foreign
        // view. Skip if the rendered history already ends with that text
        // (server's GET caught up and renderSessionMessages already drew it).
        if (state.pendingForeignResponse) {
          const last = messages[messages.length - 1];
          const alreadyRendered = !!(
            last && last.role === 'assistant'
            && !(last.tool_calls && last.tool_calls.length)
            && last.content === state.pendingForeignResponse
          );
          if (!alreadyRendered) {
            addMessage('assistant', state.pendingForeignResponse);
            _lastSeenMsgCount = messages.length + 1;
          }
          state.pendingForeignResponse = null;
        }
      } else {
        // Foreign / read-only view — make sure no local-web indicator
        // bleeds across (typing bubble or in-flight tool progress row).
        typingRow.classList.remove('visible');
        removeToolProgress();
        startViewedSessionPoll();
      }
      if (pushUrl) _pushSessionToUrl(_viewedSessionId);
      _updateSessionHighlight();
      updateSendState();
      scrollToBottom();

      // Close mobile sidebar
      sidebar.classList.remove('open');
      sidebarOverlay.classList.remove('visible');
    } catch { /* ignore */ }
  }

  function _updateSessionHighlight() {
    const items = sessionsList.querySelectorAll('.session-item');
    items.forEach(el => {
      const sid = el.querySelector('.session-name')?.getAttribute('title') || '';
      el.classList.toggle('active', sid === _viewedSessionId);
    });
  }

  function _sessionFromUrl() {
    return new URLSearchParams(location.search).get('session') || '';
  }

  function _pushSessionToUrl(sessionId) {
    const url = new URL(location.href);
    if (!sessionId || sessionId === WEB_SESSION_ID) {
      url.searchParams.delete('session');
    } else {
      url.searchParams.set('session', sessionId);
    }
    if (url.toString() === location.href) return;
    history.pushState({ session: sessionId || '' }, '', url.toString());
  }

  window.addEventListener('popstate', () => {
    const sid = _sessionFromUrl() || WEB_SESSION_ID;
    if (sid === _viewedSessionId) return;
    if (sid === WEB_SESSION_ID) {
      stopViewedSessionPoll();
      _viewedSessionId = WEB_SESSION_ID;
      clearMessages();
      loadRecentHistory().then(() => {
        // Restore typing indicator if agent is still mid-response.
        if (state.waiting) typingRow.classList.add('visible');
        // Replay a stashed foreign response if the rendered history
        // doesn't already end with it (mirrors the loadSession branch).
        if (state.pendingForeignResponse) {
          const lastBubble = chatArea.querySelector('.message-row.assistant:last-of-type .message');
          const alreadyRendered = !!(lastBubble && lastBubble.textContent
            && lastBubble.textContent.trim() === String(state.pendingForeignResponse).trim());
          if (!alreadyRendered) {
            addMessage('assistant', state.pendingForeignResponse);
          }
          state.pendingForeignResponse = null;
        }
        updateSendState();
        scrollToBottom();
      });
    } else {
      loadSession(sid, { pushUrl: false });
    }
  });

  // ── Tools ──
  async function fetchTools() {
    try {
      toolsList.innerHTML = '<div class="sidebar-empty">Loading...</div>';
      const resp = await apiFetch('/api/tools');
      if (!resp.ok) { toolsList.innerHTML = '<div class="sidebar-empty">Failed to load</div>'; return; }
      const data = await resp.json();

      if (!data.length) {
        toolsList.innerHTML = '<div class="sidebar-empty">No tools registered</div>';
        return;
      }

      toolsList.innerHTML = '';
      const builtin = data.filter(t => t.type === 'builtin');
      const mcpAll = data.filter(t => t.type === 'mcp_server' || t.type === 'mcp_tool');

      builtin.forEach(t => {
        const item = document.createElement('div');
        item.className = 'tool-item';
        item.title = t.description || '';
        const status = t.active ? 'active' : 'inactive';
        item.innerHTML = `<span class="status-dot ${status}"></span><span class="tool-name">${escapeHtml(t.name)}</span><span class="tool-type">${status}</span>`;
        toolsList.appendChild(item);
      });

      if (mcpAll.length) {
        const sep = document.createElement('div');
        sep.style.cssText = 'font-size:10px;color:var(--text-tertiary);padding:8px 10px 4px;text-transform:uppercase;letter-spacing:.06em;';
        sep.textContent = 'MCP';
        toolsList.appendChild(sep);
        mcpAll.forEach(t => {
          const item = document.createElement('div');
          item.className = 'tool-item';
          item.title = t.description || '';
          const statusCls = t.type === 'mcp_server' ? (t.state || 'idle') : (t.active ? 'active' : 'inactive');
          const label = t.type === 'mcp_server' ? (t.state || 'idle') : (t.active ? 'active' : 'inactive');
          const extra = t.tool_count ? ` (${t.tool_count})` : '';
          item.innerHTML = `<span class="status-dot ${statusCls}"></span><span class="tool-name">${escapeHtml(t.name)}</span><span class="tool-type">${label}${extra}</span>`;
          toolsList.appendChild(item);
        });
      }
    } catch (error) {
      console.error('Error fetching tools:', error);
      toolsList.innerHTML = '<div class="sidebar-empty">Error loading</div>';
    }
  }

  // ── E-stop ──
  estopBtn.addEventListener('click', async () => {
    if (state.estopActive) {
      // Already active — show info
      return;
    }
    if (!confirm('Trigger Emergency Stop? This will halt all agent processing.')) return;
    try {
      await apiFetch('/api/estop', {
        method: 'POST',
        body: JSON.stringify({ reason: 'Manual E-stop from web UI' }),
      });
      fetchHealth();
    } catch { /* ignore */ }
  });

  estopResetLink.addEventListener('click', async (e) => {
    e.preventDefault();
    try {
      await apiFetch('/api/reset', {
        method: 'POST',
        body: JSON.stringify({ actor: 'web-ui' }),
      });
      fetchHealth();
    } catch { /* ignore */ }
  });

  // ── Refresh buttons ──
  $('refreshSessions').addEventListener('click', fetchSessions);
  $('refreshTools').addEventListener('click', fetchTools);

  // ── API Key Modal ──
  function updateKeyBtnState() {
    const authed = !!state.apiKey || !!state.entraToken;
    apiKeyBtn.classList.toggle('key-active', authed);
    apiKeyBtn.title = state.entraToken ? 'Signed in (Entra ID)' : state.apiKey ? 'API Key (set)' : 'Authentication';
  }
  updateKeyBtnState();

  function openApiKeyModal() {
    apiKeyInput.value = state.apiKey;
    apiKeyStatus.textContent = '';
    apiKeyStatus.className = 'status-msg';
    apiKeyModal.classList.add('visible');
    setTimeout(() => apiKeyInput.focus(), 100);
  }

  function closeApiKeyModal() {
    apiKeyModal.classList.remove('visible');
  }

  apiKeyBtn.addEventListener('click', openApiKeyModal);
  apiKeyClose.addEventListener('click', closeApiKeyModal);
  apiKeyModal.addEventListener('click', (e) => {
    if (e.target === apiKeyModal) closeApiKeyModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && apiKeyModal.classList.contains('visible')) closeApiKeyModal();
  });

  apiKeyToggleVis.addEventListener('click', () => {
    const isPassword = apiKeyInput.type === 'password';
    apiKeyInput.type = isPassword ? 'text' : 'password';
    apiKeyToggleVis.textContent = isPassword ? 'Hide key' : 'Show key';
  });

  apiKeySave.addEventListener('click', async () => {
    const key = apiKeyInput.value.trim();
    state.apiKey = key;
    if (key) {
      localStorage.setItem('praestoclaw_api_key', key);
    } else {
      localStorage.removeItem('praestoclaw_api_key'); sessionStorage.removeItem('praestoclaw_temp_key');
    }
    updateKeyBtnState();

    // Test the key by hitting /api/tools (authed)
    apiKeyStatus.textContent = 'Testing...';
    apiKeyStatus.className = 'status-msg';
    try {
      const resp = await apiFetch('/api/tools');
      if (resp.ok) {
        apiKeyStatus.textContent = 'Authenticated';
        apiKeyStatus.className = 'status-msg ok';
        state.authFailed = false;  // clear auth failure so wsConnect works
        setTimeout(closeApiKeyModal, 800);
        // Reconnect WebSocket with new key
        closeStaleWs();
        wsConnect();
        fetchSessions();
        fetchTools();
        if (!state.healthTimer) state.healthTimer = setInterval(fetchHealth, 30000);
      } else if (resp.status === 401) {
        apiKeyStatus.textContent = 'Invalid key';
        apiKeyStatus.className = 'status-msg err';
      } else {
        apiKeyStatus.textContent = `Saved (server: ${resp.status})`;
        apiKeyStatus.className = 'status-msg';
        setTimeout(closeApiKeyModal, 800);
      }
    } catch {
      // Server not reachable — just save and close
      apiKeyStatus.textContent = 'Saved (offline)';
      apiKeyStatus.className = 'status-msg';
      setTimeout(closeApiKeyModal, 800);
    }
  });

  apiKeyClear.addEventListener('click', () => {
    apiKeyInput.value = '';
    state.apiKey = '';
    localStorage.removeItem('praestoclaw_api_key'); sessionStorage.removeItem('praestoclaw_temp_key');
    updateKeyBtnState();
    apiKeyStatus.textContent = 'Key cleared';
    apiKeyStatus.className = 'status-msg';
  });

  apiKeyInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') apiKeySave.click();
  });

  // ── Entra ID (MSAL.js) ──
  async function tryAzCliToken() {
    try {
      const resp = await fetch('/api/auth/azcli-token');
      if (!resp.ok) return false;
      const data = await resp.json();
      if (!data.token) return false;
      state.entraToken = data.token;
      state.azCliMode = true;
      const displayName = data.name || data.upn || 'Azure CLI';
      entraUserName.textContent = displayName;
      entraSignedOut.style.display = 'none';
      entraSignedIn.style.display = '';
      // Schedule a refresh 5 minutes before expiry (or in 30 minutes if exp missing).
      const nowSec = Math.floor(Date.now() / 1000);
      const ttl = data.exp ? Math.max(60, data.exp - nowSec - 300) : 1800;
      if (state.azCliRefreshTimer) clearTimeout(state.azCliRefreshTimer);
      state.azCliRefreshTimer = setTimeout(tryAzCliToken, ttl * 1000);
      return true;
    } catch {
      return false;
    }
  }

  async function fetchAuthConfig() {
    try {
      const resp = await fetch('/api/auth/config');
      if (!resp.ok) return;
      state.entraConfig = await resp.json();

      // Prefer the local az cli token — skips MSAL.js consent popup entirely
      // when the user is signed in via `az login` on the host machine.
      const azOk = state.entraConfig.entra_enabled ? await tryAzCliToken() : false;

      if (state.entraConfig.entra_enabled && !azOk) {
        entraSection.style.display = '';
        // Show popup (redirect) button as primary if MSAL.js loaded
        if (typeof msal !== 'undefined') {
          entraLoginBtn.style.display = 'flex';
          await initMsal(); // May set state.entraToken via silent refresh
        }
      }

      const authRequired = state.entraConfig.api_key_enabled || state.entraConfig.entra_enabled;
      if (state.authFailed || (authRequired && !state.apiKey && !state.entraToken)) {
        openApiKeyModal();
      } else {
        closeApiKeyModal();
        // Auth not required or already authenticated — connect now
        if (!state.ws || state.ws.readyState > WebSocket.OPEN) {
          wsConnect();
          fetchSessions();
          fetchTools();
        }
      }
    } catch { /* ignore */ }
  }

  async function initMsal() {
    const cfg = state.entraConfig;
    if (!cfg || !cfg.entra_enabled) return;

    const msalConfig = {
      auth: {
        clientId: cfg.entra_client_id,
        authority: `https://login.microsoftonline.com/${cfg.entra_tenant_id}`,
        redirectUri: window.location.origin + '/auth/spa-callback',
      },
      cache: { cacheLocation: 'localStorage' },
    };

    state.msalInstance = new msal.PublicClientApplication(msalConfig);
    await state.msalInstance.initialize();

    // Check for existing account
    const accounts = state.msalInstance.getAllAccounts();
    if (accounts.length > 0) {
      state.entraAccount = accounts[0];
      acquireTokenSilent();
    }
  }

  async function acquireTokenSilent() {
    if (!state.msalInstance || !state.entraAccount) return;
    try {
      const result = await state.msalInstance.acquireTokenSilent({
        account: state.entraAccount,
        scopes: ['openid'],
      });
      onEntraLogin(result);
    } catch {
      // Silent failed — user needs to re-login
      onEntraLogout();
    }
  }

  function onEntraLogin(result) {
    state.entraToken = result.idToken || result.accessToken;
    state.entraAccount = result.account;
    const name = result.account.name || result.account.username || 'Signed in';
    entraUserName.textContent = name;
    entraSignedOut.style.display = 'none';
    entraSignedIn.style.display = '';
    updateKeyBtnState();
    closeApiKeyModal();
    // Reconnect WS with new token
    closeStaleWs();
    wsConnect();
    fetchSessions();
    fetchTools();
    if (!state.healthTimer) state.healthTimer = setInterval(fetchHealth, 30000);
  }

  function onEntraLogout() {
    state.entraToken = null;
    state.entraAccount = null;
    entraSignedOut.style.display = '';
    entraSignedIn.style.display = 'none';
    entraUserName.textContent = '';
    updateKeyBtnState();
  }

  // ── Device code flow (no redirect URI needed) ──
  let deviceCodePollTimer = null;

  entraDeviceCodeBtn.addEventListener('click', async () => {
    entraDeviceCodeBtn.disabled = true;
    entraDeviceCodeBtn.style.opacity = '0.6';
    deviceCodeDisplay.style.display = 'none';
    deviceCodeStatus.textContent = 'Starting...';

    try {
      const resp = await fetch('/api/auth/device-code', { method: 'POST' });
      if (!resp.ok) {
        const err = await resp.json();
        apiKeyStatus.textContent = err.message || 'Failed to start';
        apiKeyStatus.className = 'status-msg err';
        entraDeviceCodeBtn.disabled = false;
        entraDeviceCodeBtn.style.opacity = '';
        return;
      }
      const data = await resp.json();
      deviceCodeValue.textContent = data.user_code;
      deviceCodeLink.href = data.verification_uri;
      deviceCodeStatus.textContent = 'Waiting for approval...';
      deviceCodeDisplay.style.display = '';

      // Start polling
      if (deviceCodePollTimer) clearInterval(deviceCodePollTimer);
      deviceCodePollTimer = setInterval(async () => {
        try {
          const pollResp = await fetch('/api/auth/device-code/poll', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_code: data.user_code }),
          });
          const pollData = await pollResp.json();

          if (pollData.status === 'complete') {
            clearInterval(deviceCodePollTimer);
            deviceCodePollTimer = null;
            state.entraToken = pollData.access_token;
            state.entraAccount = pollData.account;
            const name = pollData.account.name || pollData.account.username || 'Signed in';
            entraUserName.textContent = name;
            entraSignedOut.style.display = 'none';
            entraSignedIn.style.display = '';
            updateKeyBtnState();
            closeStaleWs();
            wsConnect();
            fetchSessions();
            fetchTools();
            if (!state.healthTimer) state.healthTimer = setInterval(fetchHealth, 30000);
            apiKeyStatus.textContent = 'Signed in';
            apiKeyStatus.className = 'status-msg ok';
            setTimeout(closeApiKeyModal, 600);
          } else if (pollData.status === 'error') {
            clearInterval(deviceCodePollTimer);
            deviceCodePollTimer = null;
            deviceCodeStatus.textContent = pollData.message || 'Failed';
            entraDeviceCodeBtn.disabled = false;
            entraDeviceCodeBtn.style.opacity = '';
          }
          // 'pending' — keep polling
        } catch { /* network error — keep polling */ }
      }, 3000);
    } catch {
      apiKeyStatus.textContent = 'Network error';
      apiKeyStatus.className = 'status-msg err';
      entraDeviceCodeBtn.disabled = false;
      entraDeviceCodeBtn.style.opacity = '';
    }
  });

  // ── Popup flow (requires redirect URI configured) ──
  entraLoginBtn.addEventListener('click', async () => {
    if (!state.msalInstance) return;
    try {
      const result = await state.msalInstance.loginPopup({
        scopes: ['openid'],
      });
      onEntraLogin(result);
      apiKeyStatus.textContent = 'Signed in';
      apiKeyStatus.className = 'status-msg ok';
      setTimeout(closeApiKeyModal, 600);
    } catch (err) {
      apiKeyStatus.textContent = err.errorMessage || 'Login failed';
      apiKeyStatus.className = 'status-msg err';
    }
  });

  entraLogoutBtn.addEventListener('click', () => {
    if (deviceCodePollTimer) { clearInterval(deviceCodePollTimer); deviceCodePollTimer = null; }
    deviceCodeDisplay.style.display = 'none';
    entraDeviceCodeBtn.disabled = false;
    entraDeviceCodeBtn.style.opacity = '';
    if (state.msalInstance && state.entraAccount) {
      state.msalInstance.logoutPopup({ account: state.entraAccount }).catch(() => {});
    }
    onEntraLogout();
    if (state.ws) { state.ws.close(); }
  });

  // ── Init ──
  fetchAuthConfig();  // Detect Entra ID config, init MSAL if available
  fetchHealth();
  // WS, sessions, and tools require auth — only connect if already authenticated.
  // On fresh login, the save/login handlers call wsConnect + fetchSessions + fetchTools.
  if (state.apiKey || state.entraToken) {
    wsConnect();
    fetchSessions();
    fetchTools();
  }

  state.healthTimer = setInterval(fetchHealth, 30000);

  // ── First-Run Experience: starter chips + background-task status bar ──
  // The CLI wizard (``praestoclaw init``) writes ~/.praestoclaw/.fre-state.json
  // when it fans out long tasks (Teams sideload, MCP token warm-up). The
  // Portal polls /api/fre/state to:
  //   1. greet the user by first_name in the welcome heading;
  //   2. render starter prompt chips so the user has something to click;
  //   3. surface still-pending background tasks in a small status bar
  //      with a Retry button that POSTs /api/fre/retry/{key}.
  //
  // All best-effort: a missing or malformed state never blocks the chat UI.
  const FRE_LABELS = {
    teams_sideload: 'Teams app',
    mcp_silent_acquire: 'MCP token cache',
    marketplace_install: 'Skill marketplace',
    external_import: 'Import from Claude/Copilot',
  };
  const freStatus = $('freStatus');
  const freStatusList = $('freStatusList');
  const freStatusClose = $('freStatusClose');
  const starterChips = $('starterChips');
  const welcomeHeading = $('welcomeHeading');
  let freDismissed = sessionStorage.getItem('praestoclaw_fre_dismissed') === '1';
  let frePollTimer = null;
  let freChipsRendered = false;

  function renderStarterChips(prompts) {
    if (!starterChips || freChipsRendered || !Array.isArray(prompts) || prompts.length === 0) return;
    freChipsRendered = true;
    starterChips.innerHTML = '';
    prompts.forEach(p => {
      if (!p || !p.prompt || !p.label) return;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'starter-chip';
      btn.dataset.promptId = p.id || '';
      const ico = document.createElement('span');
      ico.className = 'starter-chip-icon';
      ico.textContent = p.icon || '';
      const lbl = document.createElement('span');
      lbl.textContent = p.label;
      btn.appendChild(ico);
      btn.appendChild(lbl);
      btn.addEventListener('click', () => {
        chatInput.value = p.prompt;
        chatInput.focus();
        updateSendState();
        // Send immediately if we're connected; otherwise the user can edit first.
        if (state.connected && !state.waiting) sendMessage();
      });
      starterChips.appendChild(btn);
    });
  }

  function renderFreStatus(pending) {
    if (!freStatus || !freStatusList) return;
    if (freDismissed) { freStatus.classList.remove('visible'); return; }

    // Only show entries the user can act on — skip "done" rows.
    const visible = Object.entries(pending || {}).filter(
      ([, e]) => e && (e.status === 'pending' || e.status === 'running' || e.status === 'failed')
    );
    if (visible.length === 0) { freStatus.classList.remove('visible'); return; }

    freStatusList.innerHTML = '';
    visible.forEach(([key, entry]) => {
      const row = document.createElement('div');
      row.className = 'fre-status-item';
      const dot = document.createElement('span');
      dot.className = 'fre-status-dot ' + entry.status;
      const label = document.createElement('span');
      label.className = 'fre-status-label';
      // For marketplace install we surface the per-bundle progress
      // (``current_label`` + ``installed`` count) the worker stamps into
      // the pending entry's extras so the user sees forward motion
      // instead of a static "running" string for ~60 s.
      let suffix = entry.status;
      if (key === 'marketplace_install' && entry.status === 'running' && entry.current_label) {
        suffix = 'installing ' + entry.current_label;
      } else if (key === 'marketplace_install' && entry.status === 'done' &&
                 typeof entry.installed === 'number') {
        suffix = 'done \u2014 ' + entry.installed + ' skill(s) installed';
      }
      label.textContent = (FRE_LABELS[key] || key) + ' \u2014 ' + suffix;
      row.appendChild(dot);
      row.appendChild(label);
      if (entry.status === 'failed') {
        const retry = document.createElement('button');
        retry.type = 'button';
        retry.className = 'fre-status-retry';
        retry.textContent = 'Retry';
        retry.addEventListener('click', () => retryFre(key, retry));
        row.appendChild(retry);
      }
      freStatusList.appendChild(row);
    });
    freStatus.classList.add('visible');
  }

  function retryFre(key, btn) {
    if (btn) { btn.disabled = true; btn.textContent = 'Queued\u2026'; }
    // Use apiFetch so X-API-Key / Entra bearer header is included; otherwise
    // the server returns 401 under temp-key / Entra auth and the user sees
    // a stuck "Queued…" button.
    apiFetch('/api/fre/retry/' + encodeURIComponent(key), { method: 'POST' })
      .then(r => (r.ok ? r.json() : null))
      .then(() => fetchFreState())
      .catch(() => { if (btn) { btn.disabled = false; btn.textContent = 'Retry'; } });
  }

  function fetchFreState() {
    // Use apiFetch so polling works under temp-key / Entra auth — bare
    // fetch() omits headers and would silently 401, leaving the welcome
    // chips and status panel permanently blank.
    apiFetch('/api/fre/state', { cache: 'no-store' })
      .then(r => (r.ok ? r.json() : null))
      .then(data => {
        if (!data) return;
        // Greet the user once we know their first name.
        if (welcomeHeading && data.user && data.user.first_name) {
          welcomeHeading.textContent = '\u4f60\u597d, ' + data.user.first_name;
        }
        renderStarterChips(data.starter_prompts);
        renderFreStatus(data.pending);

        // Stop polling once everything is done/empty (and not dismissed).
        const stillPending = Object.values(data.pending || {}).some(
          e => e && (e.status === 'pending' || e.status === 'running')
        );
        if (!stillPending && frePollTimer) {
          clearInterval(frePollTimer);
          frePollTimer = null;
        }
      })
      .catch(() => { /* network blip — next tick will retry */ });
  }

  if (freStatusClose) {
    freStatusClose.addEventListener('click', () => {
      freDismissed = true;
      sessionStorage.setItem('praestoclaw_fre_dismissed', '1');
      freStatus.classList.remove('visible');
    });
  }
  fetchFreState();
  // Poll every 5 s while there's any pending work; the handler clears
  // the timer once everything is done.
  frePollTimer = setInterval(fetchFreState, 5000);
})();
