"""
Channel manager — lifecycle coordination for all enabled channels.
Dispatches outbound messages to the correct channel.
"""

from __future__ import annotations

from typing import Any

from loguru import logger

from praestoclaw.bus.events import EventType, OutboundMessage, StreamingChunk
from praestoclaw.bus.queue import MessageBus
from praestoclaw.channels.base import BaseChannel
from praestoclaw.config.schema import ChannelType


class ChannelManager:
    """Manages channel lifecycle and outbound message routing."""

    def __init__(self, bus: MessageBus) -> None:
        self._bus = bus
        self._channels: dict[ChannelType | str, BaseChannel] = {}
        # Register outbound handler
        bus.on_outbound(self._dispatch_outbound)
        # Subscribe to typing events
        bus.events.on(EventType.TYPING_STARTED, self._on_typing_started)
        bus.events.on(EventType.TYPING_STOPPED, self._on_typing_stopped)

    def add(self, channel: BaseChannel) -> None:
        self._channels[channel.name] = channel
        logger.debug(f"Channel registered: {channel.name}")

    async def start_all(self) -> None:
        for name, channel in self._channels.items():
            try:
                await channel.start()
                logger.info(f"Channel started: {name}")
            except Exception as exc:
                logger.error(f"Channel {name} failed to start: {exc}")

    async def stop_all(self) -> None:
        for name, channel in self._channels.items():
            try:
                await channel.stop()
            except Exception as exc:
                logger.error(f"Channel {name} stop error: {exc}")

    def get(self, name: ChannelType | str) -> BaseChannel | None:
        return self._channels.get(name)

    def active_channel_names(self) -> list[ChannelType]:
        """Return names of channels that have at least one connected client."""
        return [ChannelType.of(name) for name, ch in self._channels.items() if ch.is_connected]

    def remove(self, name: ChannelType | str) -> None:
        """Unregister a channel without stopping it (caller is responsible for stop())."""
        self._channels.pop(name, None)
        logger.debug(f"Channel unregistered: {name}")

    async def _on_typing_started(self, event_type: EventType, payload: dict[str, Any]) -> None:
        """Dispatch typing indicator to the target channel."""
        channel_name = payload.get("channel")
        channel_id = payload.get("channel_id")
        if not channel_name or not channel_id:
            return
        channel = self._channels.get(channel_name)
        if channel:
            try:
                await channel.send_typing(channel_id, **payload.get("metadata", {}))
            except Exception as exc:
                logger.debug(f"Typing indicator failed ({channel_name}): {exc}")

    async def _on_typing_stopped(self, event_type: EventType, payload: dict[str, Any]) -> None:
        """Handle typing stopped — currently a no-op (channels auto-expire typing)."""

    async def _dispatch_outbound(self, msg: OutboundMessage | StreamingChunk) -> bool:
        if isinstance(msg, StreamingChunk):
            # Route to the target channel's send_streaming() if available,
            # otherwise ignore (channel handles chunks via its own bus
            # subscription for a connected delivery surface.
            channel = self._channels.get(msg.channel)
            if not channel:
                logger.warning(f"No channel for streaming chunk: {msg.channel}")
                return False
            send_streaming = getattr(channel, "send_streaming", None)
            if callable(send_streaming):
                try:
                    result = await send_streaming(msg.channel_id, msg)
                    return True if result is None else bool(result)
                except Exception:
                    logger.exception(f"Streaming send failed ({msg.channel})")
            return False
        channel = self._channels.get(msg.channel)
        if not channel:
            logger.warning(f"No channel for outbound message: {msg.channel}")
            return False
        try:
            result = await channel.send(
                msg.channel_id,
                msg.content,
                thread_id=msg.thread_id,
                reply_to=msg.reply_to,
                route_hint=msg.route_hint,
                **msg.metadata,
            )
            # Same idiom as the streaming branch above: a channel that reports
            # delivery is believed, one that returns None is treated as "didn't
            # say" rather than as a failure. Without this, a channel that
            # dropped the message (no listener) still read as delivered here,
            # and callers who need to know — e.g. a background run's terminal
            # notification deciding whether to fall back to session history —
            # had nothing to test.
            return True if result is None else bool(result)
        except Exception as exc:
            logger.error(f"Outbound send failed ({msg.channel}): {exc}")
            return False
