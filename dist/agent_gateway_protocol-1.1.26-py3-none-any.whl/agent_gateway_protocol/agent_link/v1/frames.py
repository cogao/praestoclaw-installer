from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from typing import Any, Literal

from pydantic import Field

from agent_gateway_protocol.agent_link.v1._base import AgentLinkModel
from agent_gateway_protocol.agent_link.v1.capabilities import (
    ChannelCapabilities,
    DeliveryContext,
    PolicyContext,
    RenderingHints,
    StreamingState,
)
from agent_gateway_protocol.agent_link.v1.identities import (
    Attachment,
    ConversationIdentity,
    MessageContent,
    SourceIdentity,
    SupervisionContext,
)

AGENT_LINK_V1_SCHEMA: Literal["agent-link.v1"] = "agent-link.v1"


class LogicalChannel(StrEnum):
    INTERNAL = "internal"
    LOCAL_WEBCHAT = "local_webchat"
    CLOUD_TUI = "cloud_tui"
    SCHEDULER_LOCAL = "scheduler_local"
    TEAMS = "teams"
    A2A = "a2a"
    U2U = "u2u"
    SCHEDULER_REMOTE = "scheduler_remote"
    FUTURE_EXTERNAL = "future_external"


class FrameType(StrEnum):
    CHANNEL_INBOUND = "channel_inbound"
    CHANNEL_OUTBOUND = "channel_outbound"
    CONTROL = "control"


class ControlFrameKind(StrEnum):
    CAPABILITY_UPDATE = "capability_update"
    HEARTBEAT = "heartbeat"
    AGENT_HOST_REGISTERED = "agent_host_registered"
    AGENT_HOST_DRAINING = "agent_host_draining"
    TURN_CANCELLED = "turn_cancelled"
    DELIVERY_ACK = "delivery_ack"
    DELIVERY_FAILED = "delivery_failed"
    BACKPRESSURE = "backpressure"


class BaseFrame(AgentLinkModel):
    schema_version: Literal["agent-link.v1"] = AGENT_LINK_V1_SCHEMA
    frame_id: str
    trace_id: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class ChannelInboundFrame(BaseFrame):
    frame_type: Literal[FrameType.CHANNEL_INBOUND] = FrameType.CHANNEL_INBOUND
    agent_host_id: str
    agent_id: str
    logical_channel: LogicalChannel
    source_identity: SourceIdentity
    conversation_identity: ConversationIdentity
    proposed_session_key: str | None = None
    message: MessageContent
    capabilities: ChannelCapabilities = Field(default_factory=ChannelCapabilities)
    delivery_context: DeliveryContext = Field(default_factory=DeliveryContext)
    policy_context: PolicyContext = Field(default_factory=PolicyContext)
    supervision_context: SupervisionContext = Field(default_factory=SupervisionContext)


class ChannelOutboundFrame(BaseFrame):
    frame_type: Literal[FrameType.CHANNEL_OUTBOUND] = FrameType.CHANNEL_OUTBOUND
    in_reply_to_frame_id: str | None = None
    agent_id: str
    logical_channel: LogicalChannel
    delivery_context: DeliveryContext = Field(default_factory=DeliveryContext)
    content: str
    attachments: list[Attachment] = Field(default_factory=list)
    rendering_hints: RenderingHints = Field(default_factory=RenderingHints)
    streaming_state: StreamingState = Field(default_factory=StreamingState)
    requires_ack: bool = False


class ControlFrame(BaseFrame):
    frame_type: Literal[FrameType.CONTROL] = FrameType.CONTROL
    kind: ControlFrameKind
    agent_host_id: str | None = None
    agent_id: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)
