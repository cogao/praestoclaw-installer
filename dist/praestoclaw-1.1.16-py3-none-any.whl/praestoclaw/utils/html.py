"""HTML to Markdown conversion for rich text messages."""

from __future__ import annotations

import re
from collections.abc import Iterable

# Teams delivers @mentions in two markup forms depending on the source path:
#   1. Bot Framework activities:    ``<at id="0">Display Name</at>``
#   2. The message text/html body:  ``<span itemtype="http://schema.skype.com/
#      Mention" itemscope="" itemid="0">Display Name</span>``
# The gateway forwards the text/html body (to preserve URLs), so form 2 is what
# production actually sees. Match both, case-insensitively, across newlines.
_AT_MENTION_RE = re.compile(r"<at\b[^>]*>(.*?)</at>", re.IGNORECASE | re.DOTALL)
_SKYPE_MENTION_RE = re.compile(
    r'<span\b[^>]*itemtype="[^"]*schema\.skype\.com/Mention"[^>]*>(.*?)</span>',
    re.IGNORECASE | re.DOTALL,
)
_INNER_TAG_RE = re.compile(r"<[^>]+>")


def normalize_mentions(content: str, *, self_names: Iterable[str] = ()) -> str:
    """Rewrite Teams @mention markup for the LLM.

    Handles both the Bot Framework ``<at …>Name</at>`` form and the Skype schema
    ``<span itemtype="…schema.skype.com/Mention" …>Name</span>`` form emitted in
    the message text/html body (the one the gateway actually forwards).

    Two behaviours:

    * The bot's *own* mention — any mention whose display name is in
      ``self_names`` — is **removed entirely**. In a group the user @mentions the
      bot only to address it; leaving the bot's name inline makes the model treat
      it as a topic (observed: "PraestoClawStaging 这个群是…" got recorded as
      "PraestoClawStaging is the … group"). The bot already knows it's the one
      being addressed, so the token is pure noise.

    * Everyone else's mention is kept as ``@[Name]``. Stripping all mentions
      would lose a colleague when a message @mentions the bot *and* someone else;
      a bare ``@Name`` can't bound a multi-word display name ("loop in @Alice
      Chen on…"), so ``@[...]`` delimits it unambiguously. (Angle-bracket forms
      like ``@<Name>`` are avoided — markdownify treats them as HTML tags and
      deletes them.)
    """
    if not content:
        return content
    lowered = content.lower()
    if "<at" not in lowered and "schema.skype.com/mention" not in lowered:
        return content

    self_set = {n.strip().casefold() for n in self_names if n and n.strip()}

    def _repl(match: re.Match[str]) -> str:
        # Inner content is the display name; drop any nested tags and the
        # bracket chars that would otherwise unbalance the @[...] delimiter.
        name = _INNER_TAG_RE.sub("", match.group(1)).strip()
        name = name.replace("[", "").replace("]", "")
        if name.casefold() in self_set:
            return ""  # physically delete the bot's own @mention
        return f"@[{name}]"

    content = _SKYPE_MENTION_RE.sub(_repl, content)
    content = _AT_MENTION_RE.sub(_repl, content)
    return content


def html_to_markdown(html: str) -> str:
    """Convert HTML to Markdown. Uses markdownify if available, else regex fallback."""
    try:
        import markdownify

        return markdownify.markdownify(html, strip=["img"]).strip()
    except ImportError:
        pass
    except Exception as exc:
        from loguru import logger

        logger.debug("markdownify failed, using regex fallback: {}", exc)
    return _regex_fallback(html)


def _regex_fallback(html: str) -> str:
    """Best-effort HTML->Markdown using regex (no external deps)."""
    import html as html_mod
    import re

    # Convert <a href="url">text</a> -> [text](url)
    text = re.sub(
        r'<a\s+[^>]*href=["\']([^"\']*)["\'][^>]*>(.*?)</a>',
        r"[\2](\1)",
        html,
        flags=re.IGNORECASE | re.DOTALL,
    )
    # <b>/<strong> -> ** (allow attributes)
    text = re.sub(
        r"<(b|strong)\b[^>]*>(.*?)</\1>", r"**\2**", text, flags=re.IGNORECASE | re.DOTALL
    )
    # <i>/<em> -> * (allow attributes)
    text = re.sub(r"<(i|em)\b[^>]*>(.*?)</\1>", r"*\2*", text, flags=re.IGNORECASE | re.DOTALL)
    # <br> -> newline
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    # <p>...</p> -> paragraph with blank line (allow attributes)
    text = re.sub(r"<p\b[^>]*>(.*?)</p>", r"\1\n\n", text, flags=re.IGNORECASE | re.DOTALL)
    # Strip remaining tags
    text = re.sub(r"<[^>]+>", "", text)
    # Decode HTML entities, then strip any tags that unescape may have reintroduced
    text = html_mod.unescape(text)
    text = re.sub(r"<[^>]+>", "", text)
    # Clean up whitespace
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()
