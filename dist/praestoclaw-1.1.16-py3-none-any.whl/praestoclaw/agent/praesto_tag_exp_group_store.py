"""Praesto Tag Experiment — group-level shared knowledge store.

EXPERIMENTAL / THROWAWAY. Grep ``praesto_tag_exp`` to see the whole experiment.

A mock of the multi-level knowledge network (corp/org/team/project/group) we
eventually want. For now it is a single global store backed by a GitHub repo of
Markdown, synced locally and searched with the same SQLite FTS5 pattern as
``HistoryStore`` (agent/history.py).

Two buckets:
  * ``public``  — many kinds of memory coexist: group-level (keyed by cid) plus
    manually-curated project-level and team-level notes.
  * ``private`` — only group-level memory (keyed by cid).

Search scope depends on the asking group's visibility:
  * a ``public`` group   → its own group memory + the whole public corpus.
  * a ``private`` group  → its own private group memory + the public corpus.

Repo layout (created on first write if absent)::

    public/groups/<slug>.md      # bucket=public  scope=group   key=<cid>
    public/projects/<name>.md    # bucket=public  scope=project key=<name>
    public/teams/<name>.md       # bucket=public  scope=team    key=<name>
    private/groups/<slug>.md     # bucket=private scope=group   key=<cid>

A Teams ``cid`` (e.g. ``19:abc@thread.v2``) is not a safe filename, so group
files are named by a slug + short hash and carry the real cid in a front-matter
comment that the indexer treats as authoritative.
"""

from __future__ import annotations

import hashlib
import re
import sqlite3
import subprocess
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from loguru import logger

PRAESTO_TAG_EXP_VISIBILITY_PUBLIC = "public"
PRAESTO_TAG_EXP_VISIBILITY_PRIVATE = "private"

_SCOPE_GROUP = "group"
_SCOPE_PROJECT = "project"
_SCOPE_TEAM = "team"

# Front-matter marker the indexer reads as the authoritative source of a file's
# (bucket, scope, key). Kept on the first line of every store-managed file.
_FRONTMATTER_RE = re.compile(
    r"praesto_tag_exp:\s*bucket=(?P<bucket>\S+)\s+scope=(?P<scope>\S+)\s+key=(?P<key>.+?)\s*-->"
)
_ENTRY_HEADER = "## "


@dataclass(frozen=True)
class PraestoTagExpMemoryHit:
    bucket: str
    scope: str
    scope_key: str
    content: str
    created_at: str
    rank: float


def _slug(value: str) -> str:
    """Stable, filesystem-safe slug for a cid/name (cross-platform, incl. Windows)."""
    cleaned = re.sub(r"[^A-Za-z0-9._-]", "_", value).strip("_") or "x"
    digest = hashlib.sha1(value.encode("utf-8")).hexdigest()[:8]  # noqa: S324 — not security
    return f"{cleaned[:48]}-{digest}"


def _now_iso() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


class PraestoTagExpGroupStore:
    """Git-synced, FTS5-searchable public/private group knowledge store."""

    _DDL = [
        """
        CREATE TABLE IF NOT EXISTS entries (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            bucket     TEXT NOT NULL,
            scope      TEXT NOT NULL,
            scope_key  TEXT NOT NULL DEFAULT '',
            content    TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """,
        """
        CREATE VIRTUAL TABLE IF NOT EXISTS entries_fts
        USING fts5(content, tokenize='porter unicode61')
        """,
    ]

    def __init__(
        self,
        *,
        repo_url: str,
        base_dir: Path,
        branch: str = "main",
        default_visibility: str = PRAESTO_TAG_EXP_VISIBILITY_PUBLIC,
        write_mode: str = "direct_push",
    ) -> None:
        self._repo_url = repo_url
        self._branch = branch
        self._default_visibility = default_visibility
        self._write_mode = write_mode
        self._base_dir = base_dir
        self._repo_dir = base_dir / "repo"
        self._db_path = base_dir / "group_index.db"
        base_dir.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._db_path))
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        for stmt in self._DDL:
            self._conn.execute(stmt)
        self._conn.commit()

    # ── git sync ──────────────────────────────────────────────────────────
    def _git(self, *args: str, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
        return subprocess.run(  # noqa: S603
            ["git", *args],  # noqa: S607
            cwd=str(cwd or self._repo_dir),
            capture_output=True,
            text=True,
            timeout=120,
            check=False,
        )

    def sync(self) -> bool:
        """Clone (first run) or fast-forward pull, then rebuild the index.

        Best-effort: returns True on a successful sync+reindex, False otherwise.
        Never raises — an offline agent keeps serving whatever was last synced.
        """
        try:
            if not (self._repo_dir / ".git").exists():
                self._repo_dir.parent.mkdir(parents=True, exist_ok=True)
                res = self._git(
                    "clone",
                    "--branch",
                    self._branch,
                    self._repo_url,
                    str(self._repo_dir),
                    cwd=self._base_dir,
                )
                if res.returncode != 0:
                    logger.warning("praesto_tag_exp: clone failed: {}", res.stderr.strip())
                    return False
            else:
                res = self._git("pull", "--ff-only", "origin", self._branch)
                if res.returncode != 0:
                    logger.warning("praesto_tag_exp: pull failed: {}", res.stderr.strip())
            self.reindex()
            return True
        except Exception:  # noqa: BLE001 — mock must never break the turn.
            logger.exception("praesto_tag_exp: sync failed")
            return False

    # ── indexing ──────────────────────────────────────────────────────────
    def reindex(self) -> int:
        """Rebuild the FTS index from the on-disk Markdown. Returns entry count."""
        self._conn.execute("DELETE FROM entries")
        self._conn.execute("DELETE FROM entries_fts")
        count = 0
        for path in sorted(self._repo_dir.rglob("*.md")):
            if ".git" in path.parts:
                continue
            meta = self._classify_file(path)
            if meta is None:
                continue
            bucket, scope, scope_key = meta
            for content, created_at in self._iter_entries(path):
                cur = self._conn.execute(
                    "INSERT INTO entries(bucket,scope,scope_key,content,created_at)"
                    " VALUES(?,?,?,?,?)",
                    (bucket, scope, scope_key, content, created_at),
                )
                self._conn.execute(
                    "INSERT INTO entries_fts(rowid,content) VALUES(?,?)",
                    (cur.lastrowid, content),
                )
                count += 1
        self._conn.commit()
        return count

    def _classify_file(self, path: Path) -> tuple[str, str, str] | None:
        """Resolve (bucket, scope, scope_key) from front-matter, else from path."""
        try:
            first = path.read_text(encoding="utf-8", errors="replace").splitlines()[:1]
        except OSError:
            return None
        if first:
            m = _FRONTMATTER_RE.search(first[0])
            if m:
                return m.group("bucket"), m.group("scope"), m.group("key").strip()
        # Path fallback: <bucket>/<scope_plural>/<name>.md
        try:
            rel = path.relative_to(self._repo_dir)
        except ValueError:
            return None
        parts = rel.parts
        if len(parts) < 3:
            return None
        bucket = parts[0]
        if bucket not in (PRAESTO_TAG_EXP_VISIBILITY_PUBLIC, PRAESTO_TAG_EXP_VISIBILITY_PRIVATE):
            return None
        scope = {"groups": _SCOPE_GROUP, "projects": _SCOPE_PROJECT, "teams": _SCOPE_TEAM}.get(
            parts[1]
        )
        if scope is None:
            return None
        return bucket, scope, path.stem

    @staticmethod
    def _iter_entries(path: Path):
        """Yield (content, created_at) per ``## `` section, or the whole body once."""
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return
        lines = text.splitlines()
        # Drop the front-matter comment line if present.
        if lines and _FRONTMATTER_RE.search(lines[0]):
            lines = lines[1:]
        body = "\n".join(lines).strip()
        if not body:
            return
        if _ENTRY_HEADER not in body:
            yield body, _now_iso()
            return
        # Split on entry headers, keeping each header with its body.
        chunks = re.split(r"(?m)^(?=## )", body)
        for chunk in chunks:
            chunk = chunk.strip()
            if not chunk:
                continue
            created = _now_iso()
            header = chunk.splitlines()[0]
            ts = header[len(_ENTRY_HEADER) :].strip()
            if re.match(r"\d{4}-\d{2}-\d{2}", ts):
                created = ts
            yield chunk, created

    # ── search ────────────────────────────────────────────────────────────
    def _visibility_where(self, visibility: str) -> str:
        if visibility == PRAESTO_TAG_EXP_VISIBILITY_PRIVATE:
            return (
                "((e.bucket='private' AND e.scope='group' AND e.scope_key=:cid)"
                " OR e.bucket='public')"
            )
        # public group: its own group memory (already public) + whole public corpus.
        return "(e.bucket='public')"

    def search(
        self, query: str, *, cid: str, visibility: str, top_k: int = 10
    ) -> list[PraestoTagExpMemoryHit]:
        """Bucket-aware full-text search for the asking group."""
        terms = [t for t in query.split() if t]
        if not terms:
            return []
        where = self._visibility_where(visibility)
        fts = " ".join(f'"{t.replace(chr(34), "")}"' for t in terms)
        params = {"q": fts, "cid": cid, "k": top_k}
        sql = f"""
            SELECT e.bucket,e.scope,e.scope_key,e.content,e.created_at,
                   entries_fts.rank AS rank
            FROM entries_fts JOIN entries e ON e.id=entries_fts.rowid
            WHERE entries_fts MATCH :q AND {where}
            ORDER BY entries_fts.rank LIMIT :k
        """  # noqa: S608 — {where} is an internal constant; values are parameterized
        try:
            rows = self._conn.execute(sql, params).fetchall()
        except sqlite3.OperationalError as exc:
            logger.warning("praesto_tag_exp: FTS query failed ({}); LIKE fallback", exc)
            rows = self._search_like(terms, cid=cid, visibility=visibility, top_k=top_k)
        if not rows:
            rows = self._search_like(terms, cid=cid, visibility=visibility, top_k=top_k)
        return [
            PraestoTagExpMemoryHit(
                bucket=r["bucket"],
                scope=r["scope"],
                scope_key=r["scope_key"],
                content=r["content"],
                created_at=r["created_at"],
                rank=float(r["rank"]) if r["rank"] is not None else -1.0,
            )
            for r in rows
        ]

    def _search_like(self, terms, *, cid: str, visibility: str, top_k: int):
        """CJK/substring fallback (FTS5 unicode61 can't tokenize CJK)."""
        where = self._visibility_where(visibility)
        like = " AND ".join(f"e.content LIKE :t{i}" for i in range(len(terms)))
        params: dict[str, object] = {f"t{i}": f"%{t}%" for i, t in enumerate(terms)}
        params["cid"] = cid  # unused for public visibility; sqlite ignores extra keys
        params["k"] = top_k
        sql = f"""
            SELECT e.bucket,e.scope,e.scope_key,e.content,e.created_at,-1.0 AS rank
            FROM entries e WHERE ({like}) AND {where}
            ORDER BY e.created_at DESC LIMIT :k
        """  # noqa: S608 — {like}/{where} are internal constants; values parameterized
        try:
            return self._conn.execute(sql, params).fetchall()
        except sqlite3.OperationalError:
            return []

    # ── write ─────────────────────────────────────────────────────────────
    def add_group_memory(self, text: str, *, cid: str, visibility: str) -> bool:
        """Append an entry to the asking group's own memory file, reindex, push."""
        text = (text or "").strip()
        if not text or not cid:
            return False
        bucket = (
            PRAESTO_TAG_EXP_VISIBILITY_PRIVATE
            if visibility == PRAESTO_TAG_EXP_VISIBILITY_PRIVATE
            else PRAESTO_TAG_EXP_VISIBILITY_PUBLIC
        )
        rel = Path(bucket) / "groups" / f"{_slug(cid)}.md"
        path = self._repo_dir / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            header = (
                f"<!-- praesto_tag_exp: bucket={bucket} scope=group key={cid} -->\n"
                f"# Group memory ({cid})\n"
            )
            path.write_text(header, encoding="utf-8")
        with path.open("a", encoding="utf-8") as fh:
            fh.write(f"\n{_ENTRY_HEADER}{_now_iso()}\n- {text}\n")
        self.reindex()
        if self._write_mode == "direct_push":
            self._push(rel, cid)
        logger.debug(
            "group_memory: add cid={} visibility={} bucket={} write_mode={} path={}",
            cid,
            visibility,
            bucket,
            self._write_mode,
            str(rel),
        )
        return True

    def _push(self, rel: Path, cid: str) -> None:
        try:
            self._git("add", str(rel))
            res = self._git("commit", "-m", f"praesto_tag_exp: group memory {cid}")
            if res.returncode != 0 and "nothing to commit" not in (res.stdout + res.stderr):
                logger.warning("praesto_tag_exp: commit failed: {}", res.stderr.strip())
                return
            push = self._git("push", "origin", self._branch)
            if push.returncode != 0:
                logger.warning("praesto_tag_exp: push failed: {}", push.stderr.strip())
        except Exception:  # noqa: BLE001
            logger.exception("praesto_tag_exp: push failed")

    def close(self) -> None:
        try:
            self._conn.close()
        except Exception:  # noqa: BLE001
            pass
