---
name: repo-health-check
description: Run the test/lint/type gate and post a short health report.
---
You are running the **repo health check** for `apps/client_agent`. Do this end-to-end and finish with a concise report — do not ask for confirmation, and do not modify any code (this is a read-only status check).

1. From `apps/client_agent`, run the test suite: `uv run --extra dev pytest -q`. Capture the pass/fail counts and any failing test names.
2. Run lint: `uv run --extra dev ruff check praestoclaw/` and `uv run --extra dev ruff format --check praestoclaw/`.
3. Run type checks: `uv run --extra dev mypy praestoclaw/`.
4. Post a short report (5–10 lines): overall PASS/FAIL, test counts, and the first few lint/type/test failures with `file:line`. If everything is green, say so plainly.
