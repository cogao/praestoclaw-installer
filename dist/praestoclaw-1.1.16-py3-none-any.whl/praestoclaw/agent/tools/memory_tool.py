"""Memory tool — persistent memory read/write for the agent.

Allows the agent to save durable facts (user preferences, environment details,
tool quirks, conventions) to MEMORY.md or USER.md during conversations.

Actions:
  add     — append a new entry (rejects duplicates)
  replace — find entry by substring, replace with new content
  remove  — find entry by substring, delete it
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.risk import RiskAssessment, RiskScore

_MAX_MEMORY_BYTES = 16_384  # 16 KB cap per target file


class MemoryTool(Tool):
    """Read and write persistent memory (MEMORY.md / USER.md)."""

    risk_range = (0, 2)

    def __init__(
        self, memory: Any, *, user_file: str | None = None, workspace: Path | None = None
    ) -> None:
        self._memory = memory  # AgentMemory
        self._user_file = user_file  # AgentConfig.user_file override
        self._workspace = workspace  # for resolving relative user_file paths

    @property
    def name(self) -> str:
        return "memory"

    @property
    def description(self) -> str:
        return (
            "Manage persistent memory across sessions. "
            "Actions: add (append entry), replace (update entry), remove (delete entry). "
            "Targets: 'memory' (MEMORY.md — your notes) or 'user' (USER.md — user profile). "
            "Write memories as declarative facts, not instructions. "
            "'User prefers dark mode' ✓ — 'Always use dark mode' ✗. "
            "Procedures and workflows belong in skills (use skill_manage), not memory."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=10, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(1, reason="Write to local memory file")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["add", "replace", "remove"],
                    "description": "Action to perform.",
                },
                "content": {
                    "type": "string",
                    "description": "Entry to add (for 'add' action).",
                },
                "old_text": {
                    "type": "string",
                    "description": "Substring to find (for 'replace' and 'remove').",
                },
                "new_text": {
                    "type": "string",
                    "description": "Replacement text (for 'replace' action).",
                },
                "target": {
                    "type": "string",
                    "enum": ["memory", "user"],
                    "default": "memory",
                    "description": "Target file: 'memory' (MEMORY.md) or 'user' (USER.md).",
                },
            },
            "required": ["action"],
        }

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "")
        target = kwargs.get("target", "memory")

        if action == "add":
            return self._add(kwargs.get("content", ""), target)
        elif action == "replace":
            return self._replace(kwargs.get("old_text", ""), kwargs.get("new_text", ""), target)
        elif action == "remove":
            return self._remove(kwargs.get("old_text", ""), target)
        else:
            return f"Error: unknown action '{action}'. Use add, replace, or remove."

    # ── Internal ─────────────────────────────────────────────────────────

    def _resolve_user_path(self) -> Path:
        """Resolve USER.md path using same logic as PromptBuilder._resolve_identity_file.

        Priority: absolute config path → relative to workspace → ~/.praestoclaw/USER.md.
        """
        if self._user_file:
            p = Path(self._user_file).expanduser()
            if p.is_absolute():
                return p
            # Relative path → resolve against workspace
            if self._workspace:
                return self._workspace / p
        from praestoclaw.utils.helpers import get_data_dir

        return get_data_dir() / "USER.md"

    def _read(self, target: str) -> str:
        if target == "user":
            user_path = self._resolve_user_path()
            if user_path.is_file():
                return user_path.read_text(encoding="utf-8")
            return ""
        result: str = self._memory.read_memory()
        return result

    def _write(self, content: str, target: str) -> None:
        if target == "user":
            user_path = self._resolve_user_path()
            user_path.parent.mkdir(parents=True, exist_ok=True)
            user_path.write_text(content, encoding="utf-8")
        else:
            self._memory.write_memory(content)

    def _add(self, content: str, target: str) -> str:
        if not content or not content.strip():
            return "Error: content is empty."
        content = content.strip()

        existing = self._read(target)

        # Duplicate detection
        if content in existing:
            return f"Skipped: this entry already exists in {target}."

        # Size guard
        new_content = (
            existing.rstrip() + "\n" + content + "\n" if existing.strip() else content + "\n"
        )
        if len(new_content.encode("utf-8")) > _MAX_MEMORY_BYTES:
            return (
                f"Error: adding this entry would exceed the {_MAX_MEMORY_BYTES // 1024} KB limit "
                f"for {target}. Remove old entries first."
            )

        self._write(new_content, target)
        dest = (
            str(self._resolve_user_path())
            if target == "user"
            else str(getattr(self._memory, "_memory_path", "MEMORY.md"))
        )
        logger.debug(
            "memory tool: add target={} bytes={} dest={}",
            target,
            len(content.encode("utf-8")),
            dest,
        )
        return f"Added to {target}."

    def _replace(self, old_text: str, new_text: str, target: str) -> str:
        if not old_text:
            return "Error: old_text is empty."
        if not new_text:
            return "Error: new_text is empty. Use 'remove' action to delete entries."

        existing = self._read(target)
        if old_text not in existing:
            return f"Error: '{old_text[:60]}...' not found in {target}."

        updated = existing.replace(old_text, new_text, 1)
        self._write(updated, target)
        return f"Replaced in {target}."

    def _remove(self, old_text: str, target: str) -> str:
        if not old_text:
            return "Error: old_text is empty."

        existing = self._read(target)
        if old_text not in existing:
            return f"Error: '{old_text[:60]}...' not found in {target}."

        # Remove the matching text and clean up blank lines
        updated = existing.replace(old_text, "", 1)
        # Collapse multiple blank lines
        while "\n\n\n" in updated:
            updated = updated.replace("\n\n\n", "\n\n")
        self._write(updated.strip() + "\n" if updated.strip() else "", target)
        return f"Removed from {target}."
