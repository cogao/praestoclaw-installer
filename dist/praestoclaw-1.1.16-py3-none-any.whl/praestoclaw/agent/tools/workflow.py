"""Workflow tool — run a reusable single-agent recipe in an isolated session.

A workflow recipe is a Markdown file with YAML frontmatter, parsed with the
skill loader. **Honored frontmatter fields:** ``name``, ``description``, the
Markdown body (``content``), and the opt-in ``plan: true`` flag (run-as-Plan —
when set, ``run`` prepends a plan-driving preamble so the recipe executes as a
tracked, ``PlanStore``-persisted Plan; see ``_plan_preamble``). All other skill
frontmatter (``safe_tools``, ``keywords``, ``requires_*``, ``patterns``,
``workflow`` …) is IGNORED — in particular ``safe_tools`` is NOT applied, so a
recipe cannot grant itself approval-free tools; the spawned agent's shell/check
still go through the normal ApprovalGate.

Recipes live in the data dir's ``workflows/`` (default ``~/.praestoclaw/
workflows/*.md``, overridable via ``PRAESTOCLAW_DATA_DIR`` and different on
staging) plus a bundled dir shipped with the package (user recipes override
bundled by name). ``run`` executes the recipe body as a single ``default``
agent in a fresh isolated background session (reusing ``BackgroundTaskManager``);
the result is delivered back to the originating channel when it finishes.
"""

from __future__ import annotations

import json
import os
import re
import tempfile
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any

import yaml

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.host.background_tasks import origin_from_kwargs
from praestoclaw.skills.loader import Skill, parse_skill_file

_BUNDLED_DIR = Path(__file__).parent / "bundled_workflows"

_MAX_NAME_LEN = 80
_MAX_DESC_LEN = 500
_MAX_BODY_LEN = 20000

# Windows reserved device names — a file whose stem is one of these cannot be
# created on Windows (e.g. "con.md" fails / opens the console device). The slug
# is the filename stem, so guard against a user naming a workflow "con"/"nul"/
# "com1" etc. Compared case-insensitively.
_WIN_RESERVED = frozenset(
    {"con", "prn", "aux", "nul"}
    | {f"com{i}" for i in range(1, 10)}
    | {f"lpt{i}" for i in range(1, 10)}
)

BackgroundFn = Callable[..., Awaitable[tuple[str | None, str]]]

# Channel names accepted for a scheduled workflow's result delivery (ordered for
# display). The scheduler coerces unknown names via ChannelType.of(...), which
# silently maps a typo to CLI — so validate here and reject unknowns before
# scheduling. Mirrors the ChannelType values the scheduler can deliver to.
_NOTIFY_CHANNELS = ("cloud", "web", "local_webchat", "cli", "*")
_VALID_NOTIFY_CHANNELS = frozenset(_NOTIFY_CHANNELS)
_NOTIFY_CHANNELS_HELP = ", ".join(_NOTIFY_CHANNELS)


def _as_bool(value: Any) -> bool:
    """Coerce a tool arg that *should* be a bool but may arrive as a string.

    LLMs don't always honor the declared JSON type, so ``replace`` can show up
    as the string ``"false"`` — and ``bool("false")`` is ``True``, which would
    silently overwrite an existing recipe. Only an intentional true (real
    ``True``, or a ``"true"``-ish string) counts; everything else stays
    ``False`` so a stray value can't clobber a saved recipe.
    """
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"true", "1", "yes", "on"}
    # Anything else (None, numbers, dict/list/object) is NOT an intentional
    # true — stay False so a stray value can never clobber a saved recipe.
    return False


def _slugify(name: str) -> str:
    """Lowercase; keep unicode letters/digits; collapse everything else to a
    single dash; trim dashes.

    Returns "" if nothing usable remains (the caller rejects). The slug is both
    the filename stem and the recipe's frontmatter ``name`` (what ``run`` keys
    off), so ``add`` and ``run`` agree on the identifier. Unicode letters
    (e.g. 中文) are kept so a non-ASCII name isn't silently rejected.
    """
    slug = re.sub(r"[^\w]+", "-", name.strip().lower(), flags=re.UNICODE).replace("_", "-")
    slug = re.sub(r"-+", "-", slug).strip("-")
    slug = slug[:_MAX_NAME_LEN].strip("-")  # re-trim: truncation can land on a dash
    if slug.lower() in _WIN_RESERVED:
        # "con.md" et al. can't be created on Windows — suffix so the id stays usable.
        slug = f"{slug}-wf"
    return slug


def _load_recipes(user_dir: Path) -> dict[str, Skill]:
    """Recipe name -> Skill, from bundled dir + user dir (user overrides bundled)."""
    recipes: dict[str, Skill] = {}
    for d in (_BUNDLED_DIR, user_dir):
        if not d.is_dir():
            continue
        for md in sorted(d.glob("*.md")):
            skill = parse_skill_file(md)
            if skill and skill.name:
                recipes[skill.name] = skill
    return recipes


def make_recipe_resolver(workflow_dir: Path) -> Callable[[str], str | None]:
    """Public factory: a resolver mapping a recipe name to its current body.

    The scheduler calls this at each fire so a scheduled workflow always runs the
    latest recipe. Returns ``None`` when the recipe no longer exists. Exposed so
    runtime wires the scheduler without reaching into a private helper.

    Scans user dir first (to preserve user-overrides-bundled semantics) and stops
    at the first file whose frontmatter ``name`` matches — avoiding parsing every
    recipe on every fire while still matching by name (not filename) and staying
    fresh (no cache).
    """

    def _resolve(name: str) -> str | None:
        for d in (workflow_dir, _BUNDLED_DIR):
            if not d.is_dir():
                continue
            # reverse-sorted + first-match == _load_recipes' "last-sorted wins"
            # (it overwrites dict entries while iterating sorted()), so the
            # scheduler resolves the SAME body list/run would for duplicate names.
            for md in sorted(d.glob("*.md"), reverse=True):
                skill = parse_skill_file(md)
                if skill and skill.name == name:
                    return skill.content
        return None

    return _resolve


def _plan_preamble(name: str) -> str:
    """Preamble that makes a ``plan: true`` recipe run as a tracked Plan.

    Prepended to the recipe body at run time (see ``_run``). It steers the
    spawned single-agent run to create + drive a persisted plan (keyed to its
    own forked session id, ``workflow=<name>``) so the run has visible steps,
    per-step verification, optional HITL gates, and an audit file that survives
    restart — all through the existing ``plan`` tool, no new engine. Guidance,
    not enforcement: the agent still derives the concrete steps from the body.
    """
    # The recipe name is interpolated into the example call. Names are slugs in
    # practice (``add`` enforces ``[a-z0-9-]``) but a hand-authored recipe could
    # carry quotes/newlines, which would break a single-quoted literal. Use a
    # collapsed name for the bold header and a JSON literal (quote/newline-safe)
    # for the ``workflow=`` example value.
    display = " ".join(str(name).split()) or name
    workflow_lit = json.dumps(name)
    return (
        f"🧭 You are running the reusable workflow **{display}** as a tracked plan.\n\n"
        f"STEP 1 — Before doing any work, call "
        f"plan(action='create', workflow={workflow_lit}, items=[...]) to break the "
        "steps below into ordered items. Give each item a short `acceptance` "
        "(how you'll know it's done) and, where a step can be objectively "
        "verified, a `check` shell command.\n\n"
        "STEP 2 — Work through the plan one item at a time: call "
        "plan(action='update', id=<n>, status='in_progress') before starting an "
        "item, then after finishing it run its `check` (if any) and call "
        "plan(action='update', id=<n>, status='done', evidence=<result>). If an "
        "item needs the user's go-ahead before proceeding, use "
        "plan(action='checkpoint', ask_user=true).\n\n"
        "STEP 3 — When every item is done, give your final answer with the "
        "actual result the user asked for.\n\n"
        "--- workflow steps ---\n"
    )


def _resolve_params(
    specs: list[dict[str, Any]] | None, provided: Any
) -> tuple[dict[str, str], list[str]]:
    """Resolve a recipe's declared parameters to string substitution values.

    Returns ``(name -> str value, errors)``. For each declared param the value
    is ``provided[name]`` if given (and non-null), else its ``default``, else
    "" for optional / an error for ``required``. Light validation: an
    ``integer``/``float`` value must coerce; a ``select`` value must be in
    ``options``. Values are stringified for **plain-text** substitution — there
    is no template engine (the Societas SSTI→RCE lesson, §1.8). ``provided`` may
    be a dict or a JSON object string (LLMs sometimes stringify the arg).
    """
    if not specs:
        return {}, []
    if isinstance(provided, str):
        try:
            provided = json.loads(provided)
        except (ValueError, TypeError):
            provided = {}
    if not isinstance(provided, dict):
        provided = {}
    values: dict[str, str] = {}
    errors: list[str] = []
    for spec in specs:
        name = str(spec.get("name") or "").strip()
        if not name:
            continue
        ptype = str(spec.get("type") or "string").strip().lower()
        if name in provided and provided[name] is not None:
            raw: Any = provided[name]
        elif spec.get("default") is not None:
            raw = spec.get("default")
        elif _as_bool(spec.get("required")):
            errors.append(f"missing required parameter {name!r}")
            continue
        else:
            raw = ""
        if ptype in ("integer", "int"):
            text = str(raw).strip()
            try:
                int(text)
            except (ValueError, TypeError):
                errors.append(f"parameter {name!r} must be an integer (got {raw!r})")
                continue
            raw = text  # substitute the validated (stripped) form, not the raw
        elif ptype in ("float", "number"):
            text = str(raw).strip()
            try:
                float(text)
            except (ValueError, TypeError):
                errors.append(f"parameter {name!r} must be a number (got {raw!r})")
                continue
            raw = text
        elif ptype == "select":
            raw_opts = spec.get("options")
            # Guard: only a list of options gates the value — a scalar/str
            # ``options`` must NOT be char-iterated into per-character choices.
            options = [str(o) for o in raw_opts] if isinstance(raw_opts, list) else []
            if options and str(raw) not in options:
                errors.append(f"parameter {name!r} must be one of {options} (got {raw!r})")
                continue
        values[name] = str(raw)
    return values, errors


def _substitute_params(body: str, values: dict[str, str]) -> str:
    """Replace ``{name}`` with ``values[name]`` for declared names only.

    Plain-text, **single-pass** (a value that itself contains ``{other}`` is NOT
    re-expanded), and unknown ``{…}`` tokens are left verbatim (recipe prose /
    code samples must not be mangled). No template engine — SSTI-safe.
    """
    if not values:
        return body
    pattern = re.compile(r"\{(" + "|".join(re.escape(k) for k in values) + r")\}")
    return pattern.sub(lambda m: values[m.group(1)], body)


class WorkflowTool(Tool):
    """List and run reusable single-agent workflow recipes (opt-in, flag-gated)."""

    def __init__(
        self,
        workflow_dir: Path,
        background_fn: BackgroundFn,
        scheduler: Any = None,
        inflight_fn: Any = None,
    ) -> None:
        self._dir = workflow_dir
        self._background_fn = background_fn
        # SchedulerService handle (duck-typed: add_job / remove_job / list_jobs).
        # None when the cron subsystem is disabled — schedule/unschedule then
        # return a clear error instead of silently doing nothing.
        self._scheduler = scheduler
        # Callable(*, owner) -> list of active workflow runs (BackgroundTaskManager.
        # list_workflow_runs) for the status "running now" view. None = no on-demand
        # run visibility (e.g. in tests / if not wired).
        self._inflight_fn = inflight_fn

    @property
    def name(self) -> str:
        return "workflow"

    @property
    def description(self) -> str:
        return (
            "Manage and run reusable single-agent workflow recipes. "
            "action='list' shows available recipes (⏰ marks scheduled ones); "
            "action='run' name=<recipe> runs one in a fresh isolated background "
            "session (result posted back when done); "
            "action='add' name=.. description=.. body=.. saves a new recipe "
            "(compose the body as the step-by-step instructions the agent will follow); "
            "action='schedule' name=<recipe> schedule='0 9 * * *' runs a recipe "
            "automatically on a cron/interval schedule (result delivered to your "
            "active channels); action='unschedule' name=<recipe> stops it; "
            "action='status' shows scheduled workflows and their last/next run "
            "(add name=<recipe> for that one's recent run history)."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "run", "add", "schedule", "unschedule", "status"],
                },
                "name": {
                    "type": "string",
                    "description": (
                        "Recipe name (for 'run' / 'add' / 'schedule' / 'unschedule'; "
                        "optional for 'status' to see one workflow's run history)."
                    ),
                },
                "description": {
                    "type": "string",
                    "description": "Short one-line description (for 'add').",
                },
                "body": {
                    "type": "string",
                    "description": (
                        "For 'add': the recipe body — the natural-language, "
                        "step-by-step instructions a single agent will follow."
                    ),
                },
                "params": {
                    "type": "object",
                    "description": (
                        "For 'run': values for a parameterized recipe's declared "
                        "parameters, e.g. {'pr_number': 566}. A missing value falls "
                        "back to that parameter's default; a required parameter with "
                        "no default errors (the run does not start)."
                    ),
                },
                "replace": {
                    "type": "boolean",
                    "description": "For 'add': overwrite an existing recipe of the same name.",
                },
                "schedule": {
                    "type": "string",
                    "description": (
                        "For 'schedule': cron expression (e.g. '0 9 * * *'), interval "
                        "seconds (e.g. '3600'), or a one-shot ('at:+300' / 'at:<ISO>')."
                    ),
                },
                "notify_channels": {
                    "anyOf": [
                        {"type": "string", "enum": list(_NOTIFY_CHANNELS)},
                        {
                            "type": "array",
                            "items": {"type": "string", "enum": list(_NOTIFY_CHANNELS)},
                        },
                    ],
                    "description": (
                        "For 'schedule': where to deliver the result — a single channel "
                        "name or a list (defaults to all active channels). Use '*' alone "
                        "for all active; don't combine '*' with specific channels."
                    ),
                },
            },
            "required": ["action"],
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(tier="standard")

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "")
        if action == "list":
            return self._list()
        if action == "run":
            return await self._run(kwargs)
        if action == "add":
            return self._add(kwargs)
        if action == "schedule":
            return self._schedule(kwargs)
        if action == "unschedule":
            return self._unschedule(kwargs)
        if action == "status":
            return self._status(kwargs)
        return (
            f"Unknown action: {action!r}. "
            "Use 'list', 'run', 'add', 'schedule', 'unschedule', or 'status'."
        )

    def _list(self) -> str:
        recipes = _load_recipes(self._dir)
        if not recipes:
            return f"No workflow recipes found. Add one to {self._dir}/*.md"
        scheduled = self._scheduled_map()
        lines = []
        for r in recipes.values():
            sched = scheduled.get(r.name)
            suffix = f"  ⏰ {sched}" if sched else ""
            lines.append(f"- {r.name}: {r.description}{suffix}")
        return "Available workflows:\n" + "\n".join(lines)

    def _scheduled_map(self) -> dict[str, Any]:
        """Recipe name -> its schedule, for workflow-backed cron jobs.

        Keyed off each job's structured ``workflow_recipe`` field — NOT the job
        name — so a plain cron job that merely happens to be named ``wf-…`` can't
        be mis-annotated as a scheduled workflow.
        """
        if self._scheduler is None:
            return {}
        try:
            jobs = self._scheduler.list_jobs()
        except Exception:  # noqa: BLE001 - listing is best-effort UI sugar
            return {}
        out: dict[str, Any] = {}
        for j in jobs:
            recipe = j.get("workflow_recipe")
            if recipe:
                out[recipe] = j.get("schedule")
        return out

    def _status(self, kwargs: dict[str, Any]) -> str:
        name = str(kwargs.get("name") or "").strip()  # explicit null → "", not "None"
        # Scheduled workflows (needs the scheduler); in-flight on-demand runs
        # are scheduler-independent, so status still works with cron off.
        wf_jobs: list[dict[str, Any]] = []
        sched_read_failed = False
        if self._scheduler is not None:
            try:
                jobs = self._scheduler.list_jobs()
                wf_jobs = [j for j in jobs if j.get("workflow_recipe")]
            except Exception:  # noqa: BLE001 - degrade to "no scheduled"; the
                # in-flight on-demand runs section (scheduler-independent) must
                # still render even if reading scheduled jobs fails.
                sched_read_failed = True
        if name:
            if self._scheduler is None:
                return (
                    "Error: workflow status detail needs the cron subsystem (config.cron.enabled)."
                )
            if sched_read_failed:
                # Don't claim "not scheduled" when we simply couldn't read it.
                return f"Error: could not read scheduler status for {name!r}; try again."
            job = next((j for j in wf_jobs if j.get("workflow_recipe") == name), None)
            if job is None:
                return (
                    f"Workflow {name!r} is not scheduled. Use action='status' for all "
                    "scheduled workflows, or action='schedule' to add one."
                )
            return self._status_detail(job)
        # Overview: scheduled workflows + on-demand runs in flight now.
        inflight = self._inflight_runs(kwargs)
        parts: list[str] = []
        if wf_jobs:
            parts.append(
                f"Scheduled workflows ({len(wf_jobs)}):\n"
                + "\n".join(self._status_line(j) for j in wf_jobs)
            )
        if inflight:
            run_lines = [
                f"- {r.get('workflow')} — ▶ running "
                f"{self._fmt_elapsed(r.get('elapsed_seconds', 0))}"
                for r in inflight
            ]
            parts.append(f"Running now ({len(inflight)}):\n" + "\n".join(run_lines))
        if sched_read_failed:
            # Be honest that the scheduled list is missing, not empty — prepend a
            # note whether or not there are in-flight runs to show alongside.
            parts.insert(0, "⚠️ Could not read scheduled workflows (try again).")
        if parts:
            return "\n\n".join(parts)
        if self._scheduler is None:
            return "No workflows are scheduled and none are running. (Scheduling needs config.cron.enabled.)"
        return (
            "No workflows are scheduled. Schedule one with: "
            "workflow(action='schedule', name=<recipe>, schedule='0 9 * * *')."
        )

    def _inflight_runs(self, kwargs: dict[str, Any]) -> list[dict[str, Any]]:
        """Active on-demand workflow runs (owner-scoped to the caller's session)."""
        if self._inflight_fn is None:
            return []
        try:
            return self._inflight_fn(owner=kwargs.get("_session_id")) or []
        except Exception:  # noqa: BLE001 - status is read-only best-effort
            return []

    @staticmethod
    def _fmt_elapsed(seconds: Any) -> str:
        """Compact elapsed like '45s' / '3m' / '1h05m' from a seconds count."""
        try:
            s = int(float(seconds))
        except (TypeError, ValueError):
            return "?"
        if s < 60:
            return f"{s}s"
        if s < 3600:
            return f"{s // 60}m"
        return f"{s // 3600}h{(s % 3600) // 60:02d}m"

    @staticmethod
    def _fmt_ts(iso: Any) -> str:
        """Compact 'YYYY-MM-DD HH:MM' from an ISO timestamp, or '—' if absent.

        String-sliced (not parsed) so it's deterministic and timezone-agnostic —
        good enough for a status glance and testable without a clock.
        """
        if not isinstance(iso, str) or len(iso) < 16:
            return "—"
        return iso[:16].replace("T", " ")

    @classmethod
    def _fmt_last(cls, job: dict[str, Any]) -> str:
        last_at = job.get("last_run_at")
        if not last_at:
            return "never run"
        status = job.get("last_status")
        if status == "success":
            return f"✓ ran {cls._fmt_ts(last_at)}"
        # last_status persists as "error"; render as "failed" to match the run
        # history vocabulary so a summary line and its detail don't disagree.
        if status == "error":
            return f"✗ failed {cls._fmt_ts(last_at)}"
        return f"ran {cls._fmt_ts(last_at)}"

    @classmethod
    def _fmt_state(cls, job: dict[str, Any]) -> str:
        """Current state for the status view: prefer 'running now' (from the
        scheduler's computed ``status``) over the stale last-run summary, so an
        in-progress run isn't shown as its previous outcome."""
        if job.get("status") == "running":
            return "▶ running now"
        return cls._fmt_last(job)

    def _status_line(self, job: dict[str, Any]) -> str:
        dis = "" if job.get("enabled", True) else " (disabled)"
        return (
            f"- {job.get('workflow_recipe')} — ⏰ {job.get('schedule')}{dis} — "
            f"{self._fmt_state(job)} — next {self._fmt_ts(job.get('next_run'))}"
        )

    def _status_detail(self, job: dict[str, Any]) -> str:
        dis = "" if job.get("enabled", True) else " (disabled)"
        out = [
            f"Workflow {job.get('workflow_recipe')!r} — ⏰ {job.get('schedule')}{dis}",
            f"  last: {self._fmt_state(job)} · next: {self._fmt_ts(job.get('next_run'))}",
        ]
        if job.get("last_error"):
            out.append(f"  last error: {job['last_error']}")
        try:
            runs = self._scheduler.get_history(job.get("name"), limit=5) or []
        except Exception:  # noqa: BLE001 - history is best-effort
            runs = []
        if runs:
            out.append("  recent runs:")
            for r in reversed(runs):  # newest first
                icon = "✓" if r.get("status") == "success" else "✗"
                dur = r.get("duration_s")
                dur_s = f" ({dur}s)" if dur is not None else ""
                extra = f" {r['error_type']}" if r.get("error_type") else ""
                out.append(
                    f"  - {self._fmt_ts(r.get('triggered_at'))} {icon} "
                    f"{r.get('status')}{dur_s}{extra}"
                )
        return "\n".join(out)

    async def _run(self, kwargs: dict[str, Any]) -> str:
        name = str(kwargs.get("name") or "").strip()  # explicit null → "", not "None"
        if not name:
            return "Error: 'name' is required for run."
        recipe = _load_recipes(self._dir).get(name)
        if recipe is None:
            return f"Error: workflow {name!r} not found. Use action='list' to see recipes."
        # Parameterization (5b): resolve declared params against the caller's
        # ``params`` (provided ?? default; required-without-value errors), then
        # substitute ``{name}`` into the body. Plain-text, no template engine.
        param_values, param_errors = _resolve_params(
            getattr(recipe, "parameters", None), kwargs.get("params")
        )
        if param_errors:
            return f"Error: {'; '.join(param_errors)}."
        # Shared public helper (also used by SpawnTool) — no private coupling.
        origin = origin_from_kwargs(kwargs)
        if origin is None:
            return (
                "Error: no originating channel; run a workflow from a chat / web / "
                "Teams context so its result can be delivered back."
            )
        # Forward the caller's session (so the background task is *owned* — an
        # unowned task is cancellable from any session) and the registry-injected
        # metadata (cron/heartbeat provenance the ApprovalGate keys off), mirroring
        # SpawnTool. Our workflow marker is merged on top.
        injected = kwargs.get("_metadata")
        metadata = dict(injected) if isinstance(injected, dict) else {}
        metadata["workflow"] = name
        # run-as-Plan: a recipe that opts in (`plan: true`) gets a plan-driving
        # preamble prepended so the spawned run creates + steps through a
        # persisted Plan keyed to its own session (its plan file is the audit +
        # progress source `status` reads back). Plain recipes are unchanged.
        prompt = _substitute_params(recipe.content, param_values)
        if getattr(recipe, "plan_mode", False):
            prompt = _plan_preamble(name) + prompt
        task_id, message = await self._background_fn(
            agent="default",
            prompt=prompt,
            origin=origin,
            metadata=metadata,
            parent_session=kwargs.get("_session_id"),
        )
        if task_id is None:
            # start() returns (None, <error message>) on shutdown / capacity —
            # don't claim the workflow is running when it isn't.
            return f"Workflow {name!r} could not start: {message}"
        return f"▶ Workflow {name!r} started in an isolated background session.\n{message}"

    def _add(self, kwargs: dict[str, Any]) -> str:
        # Strip first, then pre-cap the raw name before slugifying: stripping
        # first keeps leading whitespace from eating the cap budget (a name that
        # is 512 spaces + real text would otherwise slice down to all-whitespace
        # and be wrongly rejected), and the cap still bounds the regex work in
        # _slugify against a pathological megastring (the slug is capped again).
        slug = _slugify(str(kwargs.get("name") or "").strip()[:512])
        if not slug:
            return (
                "Error: 'name' is required and must contain letters or digits "
                "(it becomes the recipe id you run)."
            )
        # The shared skill parser strips the body on load (skills/loader.py), so
        # run receives a stripped prompt regardless of what we save — match that
        # here. Strip, then cap, then re-check non-empty so a body that is all
        # whitespace before the cap can't slip through.
        body = str(kwargs.get("body", "") or "").strip()[:_MAX_BODY_LEN]
        if not body:
            return "Error: 'body' is required — the step-by-step instructions the agent follows."
        # Collapse all whitespace to single spaces — description is one line (it
        # appears in the list output; a multi-line value would become a YAML
        # block scalar and break formatting).
        description = " ".join(str(kwargs.get("description", "") or "").split())[:_MAX_DESC_LEN]
        path = self._dir / f"{slug}.md"
        # width=10**6 keeps the (single-line) description from being wrapped/
        # folded by the YAML dumper.
        frontmatter = yaml.safe_dump(
            {"name": slug, "description": description},
            allow_unicode=True,
            sort_keys=False,
            width=10**6,
        ).strip()
        content = f"---\n{frontmatter}\n---\n{body}\n"
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            # e.g. a parent path component is a file — on Windows this surfaces
            # as FileExistsError, so keep it out of the write's collision branch.
            return f"Error: could not save workflow {slug!r}: {exc}"
        try:
            if _as_bool(kwargs.get("replace")):
                # Atomic durable overwrite: write to a securely-created unique
                # temp file in the same dir (NamedTemporaryFile owns the fd, so
                # it can't leak even if the write raises), then os.replace() it
                # into place. Cleanup is best-effort and can't mask the original
                # error.
                tmp: Path | None = None
                try:
                    with tempfile.NamedTemporaryFile(
                        dir=self._dir,
                        suffix=".md.tmp",
                        delete=False,
                        mode="w",
                        encoding="utf-8",
                    ) as fh:
                        tmp = Path(fh.name)
                        fh.write(content)
                    os.replace(tmp, path)
                finally:
                    if tmp is not None:
                        tmp.unlink(missing_ok=True)
            else:
                # Atomic exclusive create — no TOCTOU window vs a concurrent add.
                with open(path, "x", encoding="utf-8") as fh:
                    fh.write(content)
        except FileExistsError:
            return f"Error: workflow {slug!r} already exists. Pass replace=true to overwrite."
        except OSError as exc:
            return f"Error: could not save workflow {slug!r}: {exc}"
        return f"✅ Saved workflow {slug!r}. Run it with: workflow(action='run', name='{slug}')."

    def _schedule(self, kwargs: dict[str, Any]) -> str:
        if self._scheduler is None:
            return (
                "Error: scheduling needs the cron subsystem — enable config.cron.enabled "
                "and restart."
            )
        name = str(kwargs.get("name") or "").strip()  # explicit null → "", not "None"
        if not name:
            return "Error: 'name' (the recipe to schedule) is required."
        schedule = str(kwargs.get("schedule", "")).strip()
        if not schedule:
            return (
                "Error: 'schedule' is required — a cron expression (e.g. '0 9 * * *'), "
                "interval seconds ('3600'), or a one-shot ('at:+300' or 'at:<ISO>')."
            )
        recipe = _load_recipes(self._dir).get(name)
        if recipe is None:
            return f"Error: workflow {name!r} not found. Use action='list' to see recipes."
        # Unattended-run guard (5b): a scheduled run supplies no param values, so
        # a required param with no default could never resolve — refuse to
        # schedule it (clearer than a silent failure on every fire).
        needs_value = [
            str(p.get("name"))
            for p in (getattr(recipe, "parameters", None) or [])
            if _as_bool(p.get("required")) and p.get("default") is None
        ]
        if needs_value:
            return (
                f"Error: workflow {name!r} needs parameter(s) {needs_value} at run time, "
                "but scheduled runs are unattended. Give each a `default` in the recipe "
                "to schedule it."
            )
        # Normalize notify_channels: absent/None means "all active channels"; a
        # bare string (schema-violating but common from LLMs) becomes a 1-element
        # list. An *explicitly empty* value ("" / []) is rejected rather than
        # silently broadening delivery to all channels; other types error too.
        notify = kwargs.get("notify_channels")
        if notify is None:
            notify_channels = None
        elif isinstance(notify, str):
            if not notify.strip():
                return (
                    "Error: 'notify_channels' is empty — omit it for all active "
                    f"channels, or name specific ones ({_NOTIFY_CHANNELS_HELP})."
                )
            notify_channels = [notify]
        elif isinstance(notify, list):
            if not notify:
                return (
                    "Error: 'notify_channels' is empty — omit it for all active "
                    f"channels, or name specific ones ({_NOTIFY_CHANNELS_HELP})."
                )
            notify_channels = [str(c) for c in notify]
        else:
            return "Error: 'notify_channels' must be a string or a list of channel names."
        # Validate/normalize (strip + lower) each entry against the supported set
        # and reject unknowns clearly — otherwise the scheduler coerces a typo to
        # CLI and the scheduled result silently lands on the wrong channel.
        if notify_channels is not None:
            normalized: list[str] = []
            for c in notify_channels:
                cc = c.strip().lower()
                if cc not in _VALID_NOTIFY_CHANNELS:
                    return (
                        f"Error: unknown notify_channels value {c!r}. "
                        f"Valid values: {_NOTIFY_CHANNELS_HELP} ('*' = all active)."
                    )
                if cc not in normalized:  # de-dupe (avoids duplicate deliveries)
                    normalized.append(cc)
            if "*" in normalized and len(normalized) > 1:
                # '*' expands to all active channels, so it can't be meaningfully
                # combined with specific ones — the extras would be discarded.
                return (
                    "Error: notify_channels '*' (all active) can't be combined with "
                    "specific channels."
                )
            notify_channels = normalized or None
        try:
            # workflow_recipe (not a static prompt): the scheduler re-resolves the
            # recipe body fresh at each fire, so edits take effect without rescheduling.
            self._scheduler.add_job(
                name=f"wf-{recipe.name}",
                schedule=schedule,
                workflow_recipe=recipe.name,
                notify_channels=notify_channels,
                channel=kwargs.get("_channel"),
                channel_id=kwargs.get("_channel_id"),
                description=f"workflow: {recipe.name}",
            )
        except ValueError as exc:
            # Bad cron/interval expression, reserved name, etc.
            return f"Error: could not schedule {recipe.name!r}: {exc}"
        # Reflect the actual delivery target. '*' means all active channels —
        # spell that out rather than echo a bare "*".
        where = (
            ", ".join(notify_channels)
            if notify_channels and notify_channels != ["*"]
            else "your active channels"
        )
        return (
            f"✅ Scheduled workflow {recipe.name!r} ({schedule}). Its result posts to "
            f"{where} each run. Stop it with: "
            f"workflow(action='unschedule', name='{recipe.name}')."
        )

    def _unschedule(self, kwargs: dict[str, Any]) -> str:
        if self._scheduler is None:
            return "Error: scheduling needs the cron subsystem (config.cron.enabled)."
        name = str(kwargs.get("name") or "").strip()  # explicit null → "", not "None"
        if not name:
            return "Error: 'name' (the recipe to unschedule) is required."
        # schedule() always registers the job as ``wf-<recipe>``, so try the
        # prefixed form first; also try the raw name so a job id copied from
        # `cron list` works. Prefixed-first correctly handles a recipe whose own
        # name starts with "wf-" (scheduled as wf-wf-<name>). Don't require the
        # recipe to still exist — allow clearing a dangling schedule.
        for job_name in (f"wf-{name}", name):
            try:
                self._scheduler.remove_job(job_name)
            except ValueError:
                continue
            return f"✅ Unscheduled workflow {name!r}."
        return f"Error: workflow {name!r} is not scheduled."


def maybe_register_workflow_tool(
    registry: Any,
    *,
    enabled: bool,
    workflow_dir: Path,
    background_fn: BackgroundFn,
    scheduler: Any = None,
    inflight_fn: Any = None,
) -> bool:
    """Register ``WorkflowTool`` iff ``enabled``. Returns whether it registered.

    Extracted from ``runtime`` so the feature-flag gate is behaviorally testable.
    ``scheduler`` (the SchedulerService, or None when cron is disabled) enables
    the ``schedule`` / ``unschedule`` actions. ``inflight_fn`` (BackgroundTaskManager.
    list_workflow_runs) surfaces in-flight on-demand runs in ``status``.
    """
    if not enabled:
        return False
    registry.register(
        WorkflowTool(
            workflow_dir=workflow_dir,
            background_fn=background_fn,
            scheduler=scheduler,
            inflight_fn=inflight_fn,
        )
    )
    return True
