"""Praesto Tag Experiment — group_memory tool.

EXPERIMENTAL / THROWAWAY. LLM-facing surface for the group-level shared
knowledge store (see agent/praesto_tag_exp_group_store.py). Grep
``praesto_tag_exp`` to find the whole experiment.

Only meaningful inside a group shared-employee turn. The group ``cid`` and
visibility are taken from trusted runtime metadata (``_metadata`` injected by
the tool registry), never from LLM args — so the model cannot read or write
another group's memory.
"""

from __future__ import annotations

from typing import Any

from praestoclaw.agent.praesto_tag_exp_group_store import (
    PRAESTO_TAG_EXP_VISIBILITY_PRIVATE,
    PRAESTO_TAG_EXP_VISIBILITY_PUBLIC,
    PraestoTagExpGroupStore,
)
from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.praesto_tag_exp import praesto_tag_exp_is_active
from praestoclaw.security.risk import RiskAssessment, RiskScore


class GroupMemoryTool(Tool):
    """Read/write the current group's shared knowledge (recall is also auto-injected)."""

    risk_range = (0, 2)

    def __init__(
        self, store: PraestoTagExpGroupStore, *, default_visibility: str = "public"
    ) -> None:
        self._store = store
        self._default_visibility = default_visibility

    @property
    def name(self) -> str:
        return "group_memory"

    @property
    def description(self) -> str:
        return (
            "Manage this Teams group's persistent memory across sessions — the "
            "shared digital employee's memory for THIS group (the group's equivalent "
            "of your personal memory). "
            "Actions: add (save a durable group fact), search (look up group + shared "
            "knowledge). The group is determined automatically — you cannot target "
            "another group. Write memories as declarative facts, not instructions. "
            "'This group owns the Atlas rollout' \u2713 — 'Always ping this group' \u2717. "
            "Relevant group knowledge is also injected automatically each turn."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=120, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(1, reason="Read/write the group's own shared memory")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["add", "search"],
                    "description": "'add' saves a group fact; 'search' looks up group + shared knowledge.",
                },
                "content": {
                    "type": "string",
                    "description": "For action=add: the declarative fact to remember.",
                },
                "query": {
                    "type": "string",
                    "description": "For action=search: the search terms.",
                },
                "top_k": {
                    "type": "integer",
                    "description": "For action=search: max results (default 5).",
                },
            },
            "required": ["action"],
        }

    def _resolve_visibility(self, metadata: dict[str, Any]) -> str:
        # The public/private *designation* mechanism is deferred; honour an
        # explicit gateway-provided value if present, else the configured default.
        explicit = str(metadata.get("praesto_tag_exp_visibility") or "").strip().lower()
        if explicit in (PRAESTO_TAG_EXP_VISIBILITY_PUBLIC, PRAESTO_TAG_EXP_VISIBILITY_PRIVATE):
            return explicit
        return self._default_visibility

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata") or {}
        if not praesto_tag_exp_is_active(metadata):
            return "group_memory is only available inside a group shared-employee session."
        cid = str(metadata.get("cid") or "").strip()
        if not cid:
            return "group_memory: no group conversation id is available for this turn."
        visibility = self._resolve_visibility(metadata)
        action = str(kwargs.get("action") or "").strip().lower()

        if action == "add":
            # Accept ``content`` (mirrors the personal ``memory`` tool, so a model
            # treating this like memory just works) or the legacy ``text`` key.
            text = str(kwargs.get("content") or kwargs.get("text") or "").strip()
            if not text:
                return "group_memory: 'content' is required for action=add."
            ok = self._store.add_group_memory(text, cid=cid, visibility=visibility)
            return "Saved to group memory." if ok else "group_memory: nothing was saved."

        if action == "search":
            query = str(
                kwargs.get("query") or kwargs.get("content") or kwargs.get("text") or ""
            ).strip()
            if not query:
                return "group_memory: 'query' is required for action=search."
            top_k = kwargs.get("top_k")
            top_k = int(top_k) if isinstance(top_k, int) and top_k > 0 else 5
            hits = self._store.search(query, cid=cid, visibility=visibility, top_k=min(top_k, 50))
            if not hits:
                return "No matching group knowledge found."
            lines = []
            for h in hits:
                tag = f"[{h.bucket}/{h.scope}]"
                lines.append(f"{tag} {h.content.strip()}")
            return "\n\n".join(lines)

        return "group_memory: unknown action (use 'add' or 'search')."
