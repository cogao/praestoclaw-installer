"""Detached background sub-agent tasks with proactive result delivery.

A long task delegated via ``spawn(mode=background)`` should not block the
originating conversation. The :class:`BackgroundTaskManager` owns the lifecycle
of such detached sub-agent runs:

- starts the sub-agent on its own ``asyncio`` task (the spawning turn returns
  immediately, freeing the main session lane and the channel's sync window);
- enforces a hard wall-clock timeout and a concurrency cap;
- when the task finishes (success / failure / timeout / cancellation), delivers
  the outcome proactively back to the originating conversation through the
  message bus (reusing the same ``keep_context=True`` intermediate-emit path the
  scheduler and notify tool use, so it never consumes a synchronous waiter);
- retains a bounded history of finished tasks so the main agent can poll status
  and results via the ``tasks`` tool.
"""

from __future__ import annotations

import asyncio
import re
import time
import uuid
from collections import OrderedDict
from collections.abc import Awaitable, Callable, Coroutine
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

from loguru import logger

from praestoclaw.bus.events import OutboundMessage
from praestoclaw.bus.queue import MessageBus
from praestoclaw.config.schema import ChannelType
from praestoclaw.host.execution_chains import (
    ExecutionChainRunner,
    ExecutionLane,
    detached_chain_context,
)
from praestoclaw.utils.helpers import (
    REPLY_QUOTE_SNIPPET_MAX,
    contains_cjk,
    truncate_ellipsis,
)

if TYPE_CHECKING:
    from praestoclaw.session.store import SessionStore

# Runtime spawn callback. Signature: spawn_fn(agent, prompt, *, metadata) -> str
SpawnFn = Callable[..., Awaitable[str]]

TaskState = Literal["running", "completed", "failed", "cancelled", "timeout"]

_TERMINAL_STATES: frozenset[str] = frozenset({"completed", "failed", "cancelled", "timeout"})

# The ``adopt(label=…)`` value that flags a record as an event-loop promoted
# worker (as opposed to a normal ``spawn(mode=background)``). Used to gate the
# fold-back history append and the bare-result delivery format.
_PROMOTED_LABEL = "promoted"


# Match the snippet AND optional ``task=<id>`` marker inside a fold-back row's
# ``[回复：「…」]`` (zh) or ``[Re: "…"]`` (en) attribution. Anchored at start
# because both completion (``[回复…`` / ``[Re…``) and non-completion
# (``(已取消) [回复…``) paths put the attribution at — or very near — the
# start of the row. We allow a short non-bracket prefix to absorb the optional
# ``(已取消) `` / ``(cancelled) `` / ``(超时) `` / ``(失败：…) `` tag.
# ``re.DOTALL`` on the snippet capture so multi-line user questions (URLs
# after newlines, pasted blocks, …) match the full snippet — the ack row's
# ``[Q] …`` captures everything up to the row's end via the same DOTALL trick,
# so the two sides agree on the full text.
#
# The ``task=<id>`` marker is the load-bearing part for the reaper's idempotency
# check: snippet-only matching gets fooled by repeat questions ("today's
# weather?" twice in a row) and by 80-char truncation collisions, both of which
# would let an orphan ack be silently dropped because some *other* foldback
# happened to share the same snippet. The marker is appended to the attribution
# (not separately to content) so the legacy `^[^\[]{0,40}\[回复…` / `^[^\[]…\[Re:`
# anchor still wraps the whole closure-token in one match. Older rows that pre-
# date the marker still match (the `(?: · task=…)?` group is optional) and fall
# back to snippet matching — so an existing session's ack→foldback pairing is
# preserved across the upgrade.
_FOLDBACK_ZH_RE = re.compile(r"^[^\[]{0,80}\[回复：「(.*?)」(?: · task=([0-9a-f]+))?\]", re.DOTALL)
_FOLDBACK_EN_RE = re.compile(r'^[^\[]{0,80}\[Re: "(.*?)"(?: · task=([0-9a-f]+))?\]', re.DOTALL)
# Lost-on-restart phrasing emitted by ``_compose_lost_on_restart_content``.
# Reaper uses these in addition to the ``[Re: …]`` / ``[回复:「…」]`` patterns
# when matching ack→foldback closures, so a session whose orphan was already
# reaped on a previous startup is not re-reaped on the next one. Same
# task-marker scheme: appended at the end of the row, optional for back-compat.
_LOST_RESTART_ZH_RE = re.compile(
    r"^⚠️ 「(.*?)」这条任务在重启时丢失了.*?(?:\(task=([0-9a-f]+)\))?$", re.DOTALL
)
_LOST_RESTART_EN_RE = re.compile(
    r'^⚠️ "(.*?)" was lost when the service restarted.*?(?:\(task=([0-9a-f]+)\))?$',
    re.DOTALL,
)


def _extract_foldback_marker(content: str) -> tuple[str, str | None] | None:
    """Return ``(snippet, task_id_or_None)`` for a fold-back / lost-on-restart row.

    Returns ``None`` when *content* is not a recognized closure row. The
    ``task_id`` is ``None`` for legacy rows written before the task marker
    was added — the reaper falls back to snippet-only matching for those,
    which preserves pre-upgrade idempotency.

    Recognises four forms (regular fold-back zh/en + lost-on-restart zh/en),
    matching whichever pattern fires first. Inputs that fail every pattern
    return ``None``.
    """
    if not isinstance(content, str):
        return None
    for pattern in (
        _FOLDBACK_ZH_RE,
        _FOLDBACK_EN_RE,
        _LOST_RESTART_ZH_RE,
        _LOST_RESTART_EN_RE,
    ):
        m = pattern.match(content)
        if m is not None:
            snippet = m.group(1)
            task_id = m.group(2) if m.lastindex and m.lastindex >= 2 else None
            return snippet, task_id
    return None


def _extract_foldback_snippet(content: str) -> str | None:
    """Back-compat wrapper around :func:`_extract_foldback_marker`.

    Returns just the snippet (or ``None``). Retained for callers that do
    not need the task-id discrimination — but the reaper itself uses the
    full marker form so that snippet-collisions cannot mask orphans.
    """
    parsed = _extract_foldback_marker(content)
    return parsed[0] if parsed is not None else None


@dataclass(slots=True)
class BackgroundOrigin:
    """Where a detached task's result should be delivered.

    push_target is intentionally omitted — the cloud channel re-classifies it
    from ``channel_id`` at send time, so freezing it here would just risk
    going stale.

    ``teams_conversation_id`` IS captured (the originating Teams
    ``conversation.Id``) because a background delivery can outlive the
    in-memory Teams route table: the parent turn's promotion fold-back calls
    ``forget_teams_route`` when it completes, so a spawned task that finishes
    later would otherwise lose its Teams route and fall back to webchat
    (issue #473). Freezing the cid here makes the delivery self-contained —
    ``_deliver`` forwards it so the result lands in the originating chat.
    """

    channel: ChannelType
    channel_id: str
    thread_id: str | None = None
    route_hint: str | None = None
    teams_conversation_id: str | None = None


def origin_from_kwargs(kwargs: dict[str, Any]) -> BackgroundOrigin | None:
    """Build a delivery origin from registry-injected conversation context.

    Shared by SpawnTool and WorkflowTool (single source of truth). ``push_target``
    is intentionally not captured — the cloud channel re-classifies it from
    ``channel_id`` at send time, so freezing it here would risk stale state.
    """
    channel = kwargs.get("_channel")
    channel_id = kwargs.get("_channel_id")
    if not isinstance(channel, ChannelType) or not channel_id:
        return None
    raw_metadata = kwargs.get("_metadata")
    metadata = raw_metadata if isinstance(raw_metadata, dict) else {}
    thread_id = kwargs.get("_thread_id")
    route_hint = metadata.get("route_hint")
    return BackgroundOrigin(
        channel=channel,
        channel_id=str(channel_id),
        thread_id=str(thread_id) if thread_id is not None else None,
        route_hint=str(route_hint) if route_hint is not None else None,
        teams_conversation_id=str(metadata.get("cid") or "").strip() or None,
    )


@dataclass(slots=True)
class BackgroundTask:
    """Tracking record for one detached background sub-agent run."""

    task_id: str
    agent: str
    origin: BackgroundOrigin
    # Owner = the originating conversation's session key. Used to scope
    # status/result/cancel/list so one conversation cannot read or disturb
    # another conversation's background tasks. ``None`` = unowned (CLI / legacy)
    # and is visible to any caller for back-compat.
    owner: str | None = None
    state: TaskState = "running"
    started_at: float = field(default_factory=time.monotonic)
    finished_at: float | None = None
    result: str | None = None
    error: str | None = None
    task: asyncio.Task[str] | None = field(default=None, repr=False)
    # The user-visible question that kicked this task off. Used by the
    # fold-back step to attribute the proactive answer (e.g.
    # ``[Re: "<question>"]``). Empty string when unknown (legacy spawn paths).
    question: str = ""
    # Recipe name when this task is a workflow run (from metadata["workflow"]),
    # else None — lets the status view label/filter workflow runs vs plain spawns.
    workflow: str | None = None

    @property
    def elapsed_seconds(self) -> float:
        end = self.finished_at if self.finished_at is not None else time.monotonic()
        return max(0.0, end - self.started_at)


@dataclass(frozen=True, slots=True)
class BackgroundTaskSnapshot:
    """Lightweight view of one active background task, scoped by owner.

    Returned from :meth:`BackgroundTaskManager.list_for_owner` to feed the
    event-loop status fast-path: it lets ``_publish_status_ack`` cite how
    many workers are still running for the user without exposing the raw
    :class:`BackgroundTask` (which carries ``asyncio.Task`` handles and
    ``error`` strings that should never appear in user-facing copy). The
    ``label`` mirrors :attr:`BackgroundTask.agent`, kept under a more
    snapshot-natural name because adopted promotion tasks use ``"promoted"``
    rather than a real agent name.
    """

    task_id: str
    label: str
    question: str
    started_at: float
    elapsed_s: float


class BackgroundTaskManager:
    """Owns detached background sub-agent tasks and their proactive delivery."""

    def __init__(
        self,
        bus: MessageBus,
        spawn_fn: SpawnFn,
        *,
        delivery_enabled: bool = True,
        max_tasks: int = 16,
        result_retention: int = 50,
        task_timeout_seconds: float = 1800,
        session_store: SessionStore | None = None,
        execution_runner: ExecutionChainRunner | None = None,
    ) -> None:
        self._bus = bus
        self._spawn_fn = spawn_fn
        self._delivery_enabled = delivery_enabled
        self._max_tasks = max_tasks
        self._result_retention = result_retention
        self._task_timeout_seconds = task_timeout_seconds
        # ``session_store`` + ``execution_runner`` are optional: legacy ``spawn``
        # bg tasks don't need a fold-back, and CLI/test setups may skip them.
        # When either is missing the fold-back step is a no-op (logged at
        # ``_fold_back_append``), but channel delivery still happens. Promotion
        # call sites (``AgentLoopV2._promote_turn_to_worker``) MUST wire both,
        # which the runtime does at construction.
        self._session_store = session_store
        self._execution_runner = execution_runner
        self._active: dict[str, BackgroundTask] = {}
        self._terminal: OrderedDict[str, BackgroundTask] = OrderedDict()
        self._deliveries: set[asyncio.Task[None]] = set()
        self._foldbacks: set[asyncio.Task[None]] = set()
        self._closed = False

    @property
    def pending_count(self) -> int:
        return len(self._active)

    # ── Lifecycle ────────────────────────────────────────────────────────

    async def start(
        self,
        agent: str,
        prompt: str,
        *,
        origin: BackgroundOrigin,
        metadata: dict[str, Any] | None = None,
        parent_session: str | None = None,
    ) -> tuple[str | None, str]:
        """Start a detached sub-agent task.

        ``parent_session`` is the originating conversation's session id; it is
        forwarded so the sub-agent's forked session links to the real
        conversation instead of the ``cli:local`` default (absent in
        web/cloud deployments). Returns ``(task_id, message)``. ``task_id`` is
        ``None`` when the task could not be started (manager closed, capacity
        reached); ``message`` is always the human-readable string the spawn
        tool surfaces to the user.
        """
        if self._closed:
            return None, "Error: agent is shutting down; cannot start a background task now."
        if len(self._active) >= self._max_tasks:
            return None, (
                f"Error: too many background tasks running ({len(self._active)}/"
                f"{self._max_tasks}). Wait for one to finish or cancel it first."
            )

        task_id = uuid.uuid4().hex[:12]
        # Normalize the workflow label (strip + first line, capped) so a stray
        # newline/whitespace in metadata can't garble the ``workflow status`` view.
        _wf = (metadata or {}).get("workflow")
        _wf_label = (str(_wf).strip().split("\n", 1)[0].strip()[:200] or None) if _wf else None
        record = BackgroundTask(
            task_id=task_id,
            agent=agent,
            origin=origin,
            owner=parent_session,
            workflow=_wf_label,
        )

        sub_metadata = dict(metadata or {})
        # Overwrite (not setdefault): detached background tasks MUST run on
        # the SUBAGENT lane so they stay independent of MAIN saturation;
        # letting upstream metadata force this back to "main" would defeat
        # the whole feature (the spawning turn's main-lane backpressure
        # would block the detached run too).
        sub_metadata["execution_lane"] = "subagent"
        sub_metadata["background_task_id"] = task_id

        async def _run() -> str:
            spawn_kwargs: dict[str, Any] = {"metadata": sub_metadata}
            if parent_session is not None:
                spawn_kwargs["_parent_session"] = parent_session
            return await asyncio.wait_for(
                self._spawn_fn(agent, prompt, **spawn_kwargs),
                timeout=self._task_timeout_seconds,
            )

        # Run in a context with the spawning turn's chain-reentry vars reset, so
        # the detached run is scheduled as an independent session rather than a
        # reentry of the turn that called spawn().
        self._register_task(record, _run(), task_name=f"bg-task-{task_id}")

        logger.info("Background task started: id={} agent={}", task_id, agent)
        message = (
            f"Background task started (id={task_id}, agent={agent}). "
            "It runs independently — keep chatting normally. I'll send the result "
            f"to this conversation when it's done; ask me to check task {task_id} anytime."
        )
        return task_id, message

    def adopt(
        self,
        coro_factory: Callable[[], Awaitable[str]],
        *,
        origin: BackgroundOrigin,
        owner: str | None,
        question: str,
        label: str = "promoted",
    ) -> str | None:
        """Adopt an already-built continuation into the background lifecycle.

        Unlike :meth:`start`, which *launches* a sub-agent through ``spawn_fn``,
        ``adopt`` takes a pre-built coroutine factory (e.g. the worker's
        ``_drive_turn(state)`` re-entry) and wraps it in the same hard timeout,
        concurrency cap, done callback, and proactive delivery machinery.

        Returns the new ``task_id``, or ``None`` if the manager is closed or
        the worker cap is full. The caller MUST handle ``None`` by degrading
        inline (the cap pre-check here is intentionally cheap and side-effect
        free so a refused adoption does not corrupt the main session).
        """
        if self._closed or len(self._active) >= self._max_tasks:
            return None

        task_id = uuid.uuid4().hex[:12]
        record = BackgroundTask(task_id=task_id, agent=label, origin=origin, owner=owner)
        record.question = question

        async def _run() -> str:
            return await asyncio.wait_for(coro_factory(), timeout=self._task_timeout_seconds)

        self._register_task(record, _run(), task_name=f"worker-{task_id}")

        logger.info("Background task adopted: id={} label={}", task_id, label)
        return task_id

    def _register_task(
        self, record: BackgroundTask, coro: Coroutine[Any, Any, str], *, task_name: str
    ) -> None:
        """Schedule *coro* on its own detached asyncio task and track *record*.

        Shared tail of :meth:`start` and :meth:`adopt`: both create a detached
        task (chain-reentry vars reset), strong-ref it on the record, register
        the record in ``_active``, and wire the terminal-state callback. The
        only thing that differs between the two entry points is how ``coro`` is
        built — so everything past that point lives here.
        """
        task_id = record.task_id
        task = asyncio.create_task(coro, name=task_name, context=detached_chain_context())
        record.task = task
        self._active[task_id] = record

        def _on_done(t: asyncio.Task[str], tid: str = task_id) -> None:
            self._on_task_done(tid, t)

        task.add_done_callback(_on_done)

    def _on_task_done(self, task_id: str, task: asyncio.Task[str]) -> None:
        record = self._active.pop(task_id, None)
        if record is None:
            return
        record.finished_at = time.monotonic()

        if task.cancelled():
            record.state = "cancelled"
            record.error = "Task was cancelled."
        else:
            exc = task.exception()
            if exc is None:
                record.state = "completed"
                record.result = task.result()
            elif isinstance(exc, TimeoutError):
                record.state = "timeout"
                record.error = f"Task timed out after {self._task_timeout_seconds}s."
                logger.warning("Background task {} timed out", record.task_id)
                # Promoted workers also emit the canonical event_loop.timeout
                # line so the §5.2 grep recipes find the hard-timeout case
                # without having to parse the generic "timed out" string.
                # Non-promoted spawn() background tasks keep only the legacy
                # warning above so the §5.2 log surface stays event-loop-only.
                if record.agent == _PROMOTED_LABEL:
                    logger.warning(
                        "event_loop.timeout task_id={} elapsed_s={:.2f}",
                        record.task_id,
                        record.elapsed_seconds,
                    )
            else:
                record.state = "failed"
                record.error = f"{type(exc).__name__}: {exc}"
                logger.error("Background task {} failed: {}", record.task_id, exc)

        self._remember_terminal(record)

        # Emit the canonical terminal-state line for promoted (event-loop)
        # workers. §5.2 requires task_id / state / elapsed_s / result_len so a
        # single conversation's full chain — ``event_loop.promote → adopt →
        # worker_done → foldback`` — can be reconstructed by grepping a single
        # task id. ``result_len`` is the assistant text length (or 0 on
        # non-completion) so an operator can spot empty / truncated outputs.
        # Non-promoted ``spawn(mode=background)`` records are intentionally
        # not logged here: the §5.2 surface is event-loop-only, and the
        # legacy delivery path already emits per-task lifecycle lines.
        if record.agent == _PROMOTED_LABEL:
            result_len = len(record.result or "") if record.state == "completed" else 0
            logger.info(
                "event_loop.worker_done task_id={} state={} elapsed_s={:.2f} result_len={}",
                record.task_id,
                record.state,
                record.elapsed_seconds,
                result_len,
            )

        # Don't spam the user with cancellations triggered by shutdown.
        if self._delivery_enabled and not (self._closed and record.state == "cancelled"):
            delivery = asyncio.create_task(
                self._deliver(record), name=f"bg-deliver-{record.task_id}"
            )
            self._deliveries.add(delivery)
            delivery.add_done_callback(self._deliveries.discard)

        # Fold-back is event-loop-only: promoted workers (adopt(label="promoted"))
        # must also append a self-describing assistant row to the OWNER main
        # session via the per-session serial queue, so the next main turn reads
        # the answer in its assembled history (docs §2.5 / D-attribution). Bare
        # ``spawn(mode=background)`` tasks keep the legacy delivery-only path.
        if self._should_fold_back(record):
            foldback = asyncio.create_task(
                self._fold_back(record), name=f"bg-foldback-{record.task_id}"
            )
            self._foldbacks.add(foldback)
            foldback.add_done_callback(self._foldbacks.discard)

    def _remember_terminal(self, record: BackgroundTask) -> None:
        self._terminal[record.task_id] = record
        while len(self._terminal) > self._result_retention:
            self._terminal.popitem(last=False)

    async def _deliver(self, record: BackgroundTask) -> None:
        origin = record.origin
        promoted = record.agent == _PROMOTED_LABEL
        if promoted:
            # Promoted (event-loop) workers: deliver the bare final text so the
            # cloud channel's ``_teams_timeout_quote`` → ``_prefix_reply_quote``
            # path produces the user-visible ``↩️ Re your earlier question
            # "…":`` envelope without a redundant "📋 Background task done"
            # header. For non-completion states surface a localized terse
            # note (so the channel ↩️ quote still attributes the message and
            # the durable fold-back row matches char-for-char).
            content = self._compose_promoted_delivery(record)
        elif record.state == "completed":
            content = (
                f"📋 Background task done (id={record.task_id}):\n\n"
                f"{record.result or '(no output)'}"
            )
        else:
            content = (
                f"⚠️ Background task {record.task_id} {record.state}: "
                f"{record.error or 'unknown error'}"
            )

        metadata: dict[str, Any] = {
            # Intermediate side-emit: must NOT consume a pending sync waiter on
            # the carrier channel, and lets the cloud channel promote a
            # remembered Teams/webchat route to the proactive /api/notify path.
            "keep_context": True,
            "notify_category": "background_task",
            "background_task_id": record.task_id,
        }
        if promoted:
            # Promoted workers' delivery IS the user-visible final reply for
            # that turn (even though it's "intermediate" relative to the
            # already-consumed sync carrier slot). The cloud channel's
            # ↩️ quote-prefix path is gated on ``not is_intermediate`` to
            # protect normal mid-turn cards / status pings, so we opt this
            # one emission back in via an explicit flag. Without it the
            # late notify went out as the raw worker answer (prod
            # 2026-06-14 line 14382), losing the question attribution
            # the whole event-loop design depends on.
            metadata["promoted_final"] = True

        # Self-contained Teams routing: when the originating conversation id was
        # captured at task-creation time, force the delivery back to that Teams
        # chat regardless of whether the in-memory route table still remembers
        # this channel_id. A spawned background task can finish AFTER the parent
        # turn's promotion fold-back already called ``forget_teams_route`` — so
        # without this the late result falls back to webchat instead of the
        # originating group/DM (issue #473). ``committed_teams_conversation_id``
        # is consumed by ``CloudChannel._send_notify``.
        committed_cid = (origin.teams_conversation_id or "").strip()
        if committed_cid:
            metadata["push_target"] = "teams"
            metadata["committed_teams_conversation_id"] = committed_cid

        try:
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=origin.channel,
                    channel_id=origin.channel_id,
                    content=content,
                    thread_id=origin.thread_id,
                    route_hint=origin.route_hint,
                    metadata=metadata,
                )
            )
        except Exception as exc:  # noqa: BLE001 — delivery must never crash the loop
            logger.error("Background task {} delivery failed: {}", record.task_id, exc)

    # ── Fold-back (event-loop promoted workers) ──────────────────────────

    def _should_fold_back(self, record: BackgroundTask) -> bool:
        """Whether *record* warrants a fold-back history append.

        Fold-back is only meaningful for event-loop promoted workers, which we
        identify by the ``adopt(label="promoted")`` flag (legacy ``spawn`` bg
        tasks have an agent name, not ``"promoted"``). It also requires an
        owner main session (the destination) and the runtime wiring
        (``session_store`` + ``execution_runner``); when either is missing
        the manager logs and skips silently.
        """
        if record.agent != _PROMOTED_LABEL:
            return False
        if record.owner is None:
            return False
        if self._session_store is None or self._execution_runner is None:
            return False
        # Suppress fold-back on shutdown cancellations: aclose() cancels all
        # pending workers, which would otherwise post a "(cancelled)" row to
        # every conversation right before the runtime tears down (matching the
        # same guard in the delivery path above).
        if self._closed and record.state == "cancelled":
            return False
        return True

    async def _fold_back(self, record: BackgroundTask) -> None:
        """Enqueue the self-describing assistant row on the main session lane.

        The append is submitted as a zero-LLM ``execute=`` callable to
        :meth:`ExecutionChainRunner.run` on the OWNER main session key, so it
        serializes behind any active main turn and its compaction
        (docs §3.3 / D-serialization). ``ExecutionLane.SYSTEM`` keeps the
        op from consuming a user-facing ``MAIN`` slot. The fold-back never
        raises into the bg-task lifecycle: any error is logged and swallowed
        so a fold-back failure cannot leak into another worker's path.
        """
        assert self._execution_runner is not None  # gated by _should_fold_back
        owner = record.owner
        assert owner is not None  # gated by _should_fold_back
        try:
            await self._execution_runner.run(
                session_key=owner,
                turn_id=f"foldback:{record.task_id}",
                lane=ExecutionLane.SYSTEM,
                execute=lambda: self._fold_back_append(record),
            )
        except Exception as exc:  # noqa: BLE001 — fold-back must never crash the loop
            logger.error(
                "event_loop.foldback_failed task_id={} owner={} error={}",
                record.task_id,
                owner,
                exc,
            )

    async def _fold_back_append(
        self,
        record: BackgroundTask,
        *,
        content_override: str | None = None,
    ) -> None:
        """Append one self-describing assistant row to the main session.

        Runs *inside* the main session's serial lane (see :meth:`_fold_back`),
        so it is already serialized against any concurrent main turn / its
        compaction. Reads ``session_exists`` first: if the main session was
        deleted (``pc sessions delete``) while the worker was running we log
        ``event_loop.foldback_skipped`` and return — channel delivery still
        happened, but writing a row into a non-existent session would just
        re-create a stale row (docs §3.8).
        """
        assert self._session_store is not None  # gated by _should_fold_back
        owner = record.owner
        assert owner is not None  # gated by _should_fold_back
        try:
            exists = await self._session_store.session_exists(owner)
        except Exception as exc:  # noqa: BLE001 — store check must be defensive
            logger.warning(
                "event_loop.foldback_skipped task_id={} owner={} reason=store_error error={}",
                record.task_id,
                owner,
                exc,
            )
            return
        if not exists:
            logger.info(
                "event_loop.foldback_skipped task_id={} owner={} reason=session_gone",
                record.task_id,
                owner,
            )
            return

        content = (
            content_override
            if content_override is not None
            else self._compose_foldback_content(record)
        )
        try:
            rowid = await self._session_store.add_message(
                owner, {"role": "assistant", "content": content}
            )
        except Exception as exc:  # noqa: BLE001 — append must be defensive
            logger.error(
                "event_loop.foldback_append_failed task_id={} owner={} error={}",
                record.task_id,
                owner,
                exc,
            )
            return

        logger.info(
            "event_loop.foldback main={} task_id={} foldback_rowid={} channel_delivered=true",
            owner,
            record.task_id,
            rowid,
        )

    def _compose_foldback_content(self, record: BackgroundTask) -> str:
        """Build the self-describing assistant content for the fold-back row.

        Format (docs §2.5 / §3.2):

        * completed → ``[回复：「<snip>」 · task=<id>]\n\n<final_text>`` (zh) /
          ``[Re: "<snip>" · task=<id>]\n\n<final_text>`` (en)
        * cancelled → ``(已取消) [回复…]`` / ``(cancelled) [Re…]``
        * timeout   → ``(超时) [回复…]`` / ``(timeout) [Re…]``
        * failed    → ``(失败：<short>) [回复…]`` / ``(failed: <short>) [Re…]``

        Language is picked from the original question via CJK detection so the
        row reads natural in the conversation's language even when the answer
        text is mixed-script.

        The ``· task=<id>`` suffix is the reaper's idempotency token; without
        it, an orphan whose ack snippet collides with a *different* completed
        task's snippet (repeat questions, 80-char truncation collisions) would
        be silently skipped on restart and never closed. See
        :func:`_extract_foldback_marker` for the matching side.
        """
        question = record.question or ""
        snippet = self._foldback_snippet(question)
        lang_zh = contains_cjk(question)
        marker = f" · task={record.task_id}" if record.task_id else ""
        if lang_zh:
            attribution = f"[回复：「{snippet}」{marker}]"
        else:
            attribution = f'[Re: "{snippet}"{marker}]'

        if record.state == "completed":
            body = record.result or ""
            return f"{attribution}\n\n{body}".rstrip()

        # Non-completion: short prefix + attribution; never include the full
        # exception trace (which can contain user-private detail). Also bound
        # the length AND strip ``[`` characters so the prefix tag fits inside
        # the ``[^\[]{0,80}`` window the ``_FOLDBACK_*_RE`` patterns reserve
        # for it — without the cleanup, a long error like
        # ``ConnectionResetError: [Errno 104] Connection reset by peer …``
        # would either push the ``[回复:「…`` bracket past the 80-codepoint
        # limit or — even worse — embed a ``[`` inside the prefix that
        # short-circuits the negated character class, in both cases making
        # ``_extract_foldback_marker`` return None and the reaper write a
        # duplicate lost-on-restart on the next daemon startup.
        short_error = (record.error or "").strip().splitlines()[0] if record.error else ""
        # Strip ``[`` / ``]`` so the negated-bracket regex prefix never bails
        # out early on an embedded bracket from e.g. ``[Errno 104]``.
        short_error = short_error.replace("[", "").replace("]", "")
        short_error = truncate_ellipsis(short_error, 28)
        if record.state == "cancelled":
            tag = "(已取消)" if lang_zh else "(cancelled)"
        elif record.state == "timeout":
            tag = "(超时)" if lang_zh else "(timeout)"
        else:  # "failed" (or any future terminal we forgot to enumerate)
            if lang_zh:
                tag = f"(失败：{short_error})" if short_error else "(失败)"
            else:
                tag = f"(failed: {short_error})" if short_error else "(failed)"
        return f"{tag} {attribution}"

    def _compose_lost_on_restart_content(self, record: BackgroundTask) -> str:
        """Build the user-facing row for a task lost across a process restart.

        Distinct from ``_compose_foldback_content`` because the regular
        fold-back attribution (``[回复:「…」]`` / ``[Re: "…"]``) reads as
        "(failed) reply: «…»" — a confusing self-loop. Lost-on-restart is
        not a reply at all; it's a status update telling the user their
        in-flight task did not survive the daemon restart and offering the
        option to retry.

        Format:
            zh: ``⚠️ 「<snippet>」这条任务在重启时丢失了，需要我重新跑吗？(task=<id>)``
            en: ``⚠️ "<snippet>" was lost when the service restarted. Want me to retry? (task=<id>)``

        The trailing ``(task=<id>)`` mirrors the regular fold-back's
        idempotency token (a parenthesised tail rather than the inline
        ``· task=…`` form so the lead sentence keeps its natural cadence).
        Snippet truncation reuses the fold-back limit so the row matches
        the channel ↩️ bubble width. Language is keyed on the question's
        CJK content (same heuristic as the fold-back composer).
        """
        question = record.question or ""
        snippet = self._foldback_snippet(question)
        marker = f" (task={record.task_id})" if record.task_id else ""
        if contains_cjk(question):
            return f"⚠️ 「{snippet}」这条任务在重启时丢失了，需要我重新跑吗？{marker}"
        return f'⚠️ "{snippet}" was lost when the service restarted. Want me to retry?{marker}'

    @staticmethod
    def _foldback_snippet(question: str) -> str:
        """Cap the quoted question at the same width as the channel ↩️ quote.

        Truncation collapses to ``…`` (matching ``_prefix_reply_quote``) so the
        channel-side bubble and the durable fold-back row read identically.
        """
        return truncate_ellipsis((question or "").strip(), REPLY_QUOTE_SNIPPET_MAX)

    def _compose_promoted_delivery(self, record: BackgroundTask) -> str:
        """Build the carrier-bound text for a promoted (adopted) worker.

        The cloud channel will subsequently call ``_prefix_reply_quote`` to
        wrap this with ``↩️ Re your earlier question "…"`` (the request_id was
        stashed at promotion time by ``_stash_promotion_quote``). For other
        channels (CLI / web) this text stands on its own. Non-completion
        states surface a short, self-attributed note — same shape as the
        fold-back row so the user-visible bubble and the durable history row
        match.
        """
        if record.state == "completed":
            return record.result or ""
        # Reuse the fold-back composer so the channel ↩️ bubble and the
        # durable assistant row stay byte-identical for non-completion paths.
        return self._compose_foldback_content(record)

    async def reap_orphan_acks(
        self,
        session_store: Any,
        *,
        limit: int = 100,
        recent_threshold_s: float = 600.0,
    ) -> int:
        """Replace orphan ``[BG task=…]`` ack rows with lost-on-restart fold-backs.

        Walks recent main sessions (newest first, capped by *limit*) and
        identifies ack rows whose ``task_id`` is not in ``self._active`` and
        which do not already have a fold-back row in the same session. For
        each, append a ``(failed: lost-on-restart) [Re: "<snip>"]`` /
        ``(失败：lost-on-restart) [回复:「<snip>」]`` row to that session by
        calling :meth:`_fold_back_append` directly.

        For Teams-sourced sessions whose orphan ack is within
        *recent_threshold_s* of now, additionally schedule a proactive
        ``OutboundMessage`` so the Teams client (which does not read sqlite)
        learns the work was lost. Older orphans only get the durable
        sqlite row — Web Chat / Desktop clients read sqlite directly.
        Non-Teams sessions never receive a proactive notify (CLI prints on
        the next prompt, Web Chat/Desktop reads sqlite).

        The recency threshold targets the IM mental model: a user who just
        restarted the daemon at 0:07 with a turn in flight should see a
        notification immediately on Teams; a 3-hour-old leftover from a
        crash they've already moved past should not retroactively spam.

        Idempotent: a session whose orphan acks have already been "closed"
        with a lost-on-restart row will not re-trigger because the prior
        fold-back row makes the snippet match the existing-foldback set.

        Returns the number of ack rows that were converted to fold-backs.
        """
        from praestoclaw.agent.loop_v2 import parse_promotion_ack

        if self._session_store is None:
            logger.debug("event_loop.reap_skip reason=no_session_store")
            return 0

        start_t = time.monotonic()
        sessions_scanned = 0
        acks_found = 0
        orphans_reaped = 0
        notifies_sent = 0

        try:
            session_ids = await session_store.list_main_sessions(limit=limit)
        except Exception as exc:  # noqa: BLE001 — defensive
            logger.warning("event_loop.reap_failed reason=list_sessions error={}", exc)
            return 0

        for session_id in session_ids:
            sessions_scanned += 1
            try:
                rows_with_ts = await self._read_assistant_rows_with_ts(session_store, session_id)
            except Exception as exc:  # noqa: BLE001 — per-session defensive
                logger.warning(
                    "event_loop.reap_session_skipped session={} error={}", session_id, exc
                )
                continue

            ack_by_task: dict[str, tuple[str, str]] = {}  # task_id → (snippet, created_at)
            # Two parallel closure indexes, both consulted before deciding an
            # ack is orphaned:
            #
            #   ``closed_task_ids`` — task_ids that already have a fold-back
            #   row written for them (extracted from the new ``· task=<id>``
            #   marker on the attribution). This is the load-bearing dedupe
            #   key. Two acks with the same snippet but different task_ids
            #   close independently; an old fold-back's snippet cannot mask
            #   a fresh orphan with the same question text.
            #
            #   ``closed_snippets`` — fallback for legacy fold-back rows
            #   written before the task marker existed. Without this we'd
            #   re-reap any session that was already closed on a previous
            #   release. The two-tier check (task_id first, snippet second)
            #   means upgraded sessions get the strict guarantee while
            #   pre-upgrade sessions degrade gracefully to the old behavior.
            closed_task_ids: set[str] = set()
            closed_snippets: set[str] = set()
            for content, created_at in rows_with_ts:
                parsed = parse_promotion_ack(content)
                if parsed is not None:
                    task_id, snippet = parsed
                    ack_by_task[task_id] = (snippet, created_at)
                    continue
                marker = _extract_foldback_marker(content)
                if marker is not None:
                    snip, foldback_task_id = marker
                    if foldback_task_id is not None:
                        closed_task_ids.add(foldback_task_id)
                    else:
                        closed_snippets.add(snip)

            # ``:teams:`` substring in the session id marks a Teams-sourced
            # main session whose user expects proactive Teams notifies (see
            # ``cloud.py`` session-id construction at line ~2206). Web Chat
            # and CLI sessions do not appear in the Teams notify path.
            session_is_teams = ":teams:" in session_id

            for task_id, (snippet, created_at) in ack_by_task.items():
                acks_found += 1
                if task_id in self._active:
                    continue
                if task_id in closed_task_ids:
                    continue
                # Snippet fallback only applies when nothing else has
                # closed this task. Don't conflate distinct task_ids whose
                # snippets happen to collide (repeat questions, 80-char
                # truncation): the task_id is authoritative when present.
                if snippet in closed_snippets:
                    continue
                origin = BackgroundOrigin(
                    channel=ChannelType.CLOUD if session_is_teams else ChannelType.CLI,
                    channel_id=session_id,
                )
                fake = BackgroundTask(
                    task_id=task_id,
                    agent=_PROMOTED_LABEL,
                    origin=origin,
                    owner=session_id,
                    state="failed",
                    error="lost-on-restart",
                    question=snippet,
                )
                fake.finished_at = time.monotonic()
                # Reaper-specific copy: the regular fold-back attribution
                # (``[回复:「…」]`` / ``[Re: "…"]``) reads as "(failed) reply:
                # «…»" — confusing self-loop. We use a status-update
                # phrasing instead (see ``_compose_lost_on_restart_content``).
                lost_content = self._compose_lost_on_restart_content(fake)
                try:
                    await self._fold_back_append(fake, content_override=lost_content)
                except Exception as exc:  # noqa: BLE001 — per-orphan defensive
                    logger.warning(
                        "event_loop.reap_append_failed session={} task_id={} error={}",
                        session_id,
                        task_id,
                        exc,
                    )
                    continue
                orphans_reaped += 1
                logger.info(
                    "event_loop.reap_orphan_ack main={} task_id={} snippet_len={}",
                    session_id,
                    task_id,
                    len(snippet),
                )

                # Proactive Teams notify for fresh orphans. Two gates:
                # (1) session id contains ``:teams:`` so the cloud channel
                #     can route the notify to Teams; (2) ack row's
                #     ``created_at`` is within the recency threshold.
                # Web Chat / Desktop / CLI sessions read sqlite directly,
                # so the durable fold-back row from above already covers
                # them; pushing a notify on those would either no-op or
                # mis-route.
                if (
                    session_is_teams
                    and recent_threshold_s > 0
                    and self._is_recent(created_at, recent_threshold_s)
                ):
                    try:
                        await self._reap_push_teams_notify(fake)
                        notifies_sent += 1
                    except Exception as exc:  # noqa: BLE001 — push is best-effort
                        logger.warning(
                            "event_loop.reap_push_failed session={} task_id={} error={}",
                            session_id,
                            task_id,
                            exc,
                        )

        elapsed_ms = int((time.monotonic() - start_t) * 1000)
        logger.info(
            "event_loop.reap_summary sessions_scanned={} acks_found={} "
            "orphans_reaped={} notifies_sent={} elapsed_ms={}",
            sessions_scanned,
            acks_found,
            orphans_reaped,
            notifies_sent,
            elapsed_ms,
        )
        return orphans_reaped

    async def _read_assistant_rows_with_ts(
        self, session_store: Any, session_id: str
    ) -> list[tuple[str, str]]:
        """Return ``(content, created_at)`` for every assistant row in the
        session, ordered by id. ``_row_to_message`` does not project
        ``created_at`` so the reaper bypasses it via direct SQL — read-only,
        no schema change.
        """
        cursor = await session_store._conn.execute(
            "SELECT content, created_at FROM messages "
            "WHERE session_id = ? AND role = 'assistant' ORDER BY id ASC",
            (session_id,),
        )
        rows = await cursor.fetchall()
        return [(r["content"] or "", r["created_at"] or "") for r in rows]

    @staticmethod
    def _is_recent(created_at: str, threshold_s: float) -> bool:
        """True iff ``created_at`` (ISO 8601 UTC) is within ``threshold_s``
        seconds of now. Defensive: a malformed timestamp logs at debug and
        is treated as "not recent" so the reaper falls back to sqlite-only
        behavior rather than spamming on garbage data.
        """
        if not created_at:
            return False
        try:
            from datetime import UTC, datetime

            ts = datetime.fromisoformat(created_at)
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=UTC)
            age = (datetime.now(UTC) - ts).total_seconds()
        except (ValueError, TypeError) as exc:
            logger.debug(
                "event_loop.reap_recency_parse_failed created_at={} error={}", created_at, exc
            )
            return False
        return 0 <= age <= threshold_s

    async def _reap_push_teams_notify(self, record: BackgroundTask) -> None:
        """Send a proactive ``OutboundMessage`` for a freshly-reaped orphan
        on a Teams session.

        Body uses the lost-on-restart phrasing (not the regular fold-back
        ``[Re: …]`` envelope, which would read as "(failed) reply: «…»"
        — see ``_compose_lost_on_restart_content``). The phrasing already
        embeds the original question, so we deliberately do NOT set
        ``promoted_final=True``: that flag would trigger the cloud
        channel's ``↩️ 回复你刚才的提问「…」`` quote-prefix, duplicating
        the question and reading "(reply re: A) ⚠️ A was lost…" — wordy
        and confusing. ``push_target="teams"`` is set explicitly because
        the in-memory ``_teams_routed_channel_ids`` set is empty on a
        fresh process — the carrier route was lost with the previous run.
        """
        content = self._compose_lost_on_restart_content(record)
        metadata: dict[str, Any] = {
            "keep_context": True,
            "notify_category": "background_task",
            "background_task_id": record.task_id,
            # Force Teams routing — the per-session route table is empty on
            # restart, so without this the notify would default to webchat.
            "push_target": "teams",
        }
        await self._bus.publish_outbound(
            OutboundMessage(
                channel=record.origin.channel,
                channel_id=record.origin.channel_id,
                content=content,
                thread_id=record.origin.thread_id,
                route_hint=record.origin.route_hint,
                metadata=metadata,
            )
        )

    async def aclose(self) -> None:
        """Cancel all pending tasks and await in-flight deliveries."""
        self._closed = True
        pending = [
            r.task for r in self._active.values() if r.task is not None and not r.task.done()
        ]
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        # Let done callbacks scheduled by the cancellations run.
        await asyncio.sleep(0)
        deliveries = [d for d in self._deliveries if not d.done()]
        if deliveries:
            await asyncio.gather(*deliveries, return_exceptions=True)
        foldbacks = [f for f in self._foldbacks if not f.done()]
        if foldbacks:
            await asyncio.gather(*foldbacks, return_exceptions=True)

    # ── Status / control (read by the ``tasks`` tool) ────────────────────

    @staticmethod
    def _owner_ok(record: BackgroundTask, owner: str | None) -> bool:
        """Whether *owner* may see/control *record*.

        ``owner=None`` callers (system / CLI / legacy) see everything. Records
        with no owner are visible to everyone for back-compat. Otherwise the
        caller's session must match the task's owning session.
        """
        if owner is None or record.owner is None:
            return True
        return record.owner == owner

    def status(self, task_id: str, *, owner: str | None = None) -> dict[str, Any] | None:
        record = self._find(task_id)
        if record is None or not self._owner_ok(record, owner):
            return None
        return self._snapshot(record)

    def list_tasks(self, *, owner: str | None = None) -> list[dict[str, Any]]:
        records = [*self._active.values(), *self._terminal.values()]
        return [self._snapshot(r) for r in records if self._owner_ok(r, owner)]

    def list_workflow_runs(self, *, owner: str | None = None) -> list[dict[str, Any]]:
        """Active workflow runs (records that carry a ``workflow`` recipe name),
        for the ``workflow status`` in-flight view. Active only (a finished run's
        outcome is delivered back to its channel, not here).

        Owner scoping is STRICT (unlike :meth:`list_tasks`): ``owner=None`` sees
        all, but a non-None owner sees ONLY its own runs — an unowned task does
        NOT bleed into a specific conversation's status (mirrors list_for_owner)."""
        out: list[dict[str, Any]] = []
        for r in self._active.values():
            if not r.workflow:
                continue
            if owner is not None and r.owner != owner:
                continue
            out.append(
                {
                    "workflow": r.workflow,
                    "task_id": r.task_id,
                    "elapsed_seconds": round(r.elapsed_seconds, 1),
                }
            )
        return out

    def list_for_owner(self, owner: str) -> list[BackgroundTaskSnapshot]:
        """Return active tasks owned by *owner*.

        Used by the event-loop status fast-path (``AgentLoopV2._schedule_inbound``):
        when a "how's it going?" check arrives, the loop counts how many of the
        caller's promoted workers are still in flight and emits a count-aware ack
        instead of enqueuing the status check behind the work it asks about
        (which would deadlock the serial main lane). Terminal records are
        intentionally excluded — the ack only cares about *running* work.

        Unlike :meth:`list_tasks` this requires a non-None owner and ignores
        records that lack one (unowned legacy tasks should not bleed into a
        specific conversation's status answer).
        """
        snaps: list[BackgroundTaskSnapshot] = []
        for record in self._active.values():
            if record.owner is None or record.owner != owner:
                continue
            snaps.append(
                BackgroundTaskSnapshot(
                    task_id=record.task_id,
                    label=record.agent,
                    question=record.question,
                    started_at=record.started_at,
                    elapsed_s=round(record.elapsed_seconds, 1),
                )
            )
        return snaps

    def cancel_by_owner(self, owner: str) -> int:
        """Cancel every active task owned by *owner* and return the count.

        Used by the event-loop interrupt fast-path: a "stop" / "取消" message
        scoped to a conversation must cancel all of that conversation's
        promoted workers (not just the inline turn). Iterates a snapshot of
        ``self._active`` because cancellation can mutate the dict via the
        done-callback. Records without an explicit owner are NOT cancelled —
        legacy / CLI callers manage those through :meth:`cancel`.

        Returns the number of cancel requests issued (a record may finish
        before the cooperative ``CancelledError`` actually propagates; the
        terminal fold-back path handles the eventual state transition).
        """
        cancelled = 0
        for record in list(self._active.values()):
            if record.owner is None or record.owner != owner:
                continue
            task = record.task
            if task is None or task.done():
                continue
            task.cancel()
            cancelled += 1
            # Emit the canonical cancel line per record so a fan-out
            # ``/stop`` shows up once per worker, matching the §5.2 grep
            # recipe (filter by task_id and you see promote → cancel →
            # worker_done → foldback for that exact worker).
            if record.agent == _PROMOTED_LABEL:
                logger.info(
                    "event_loop.cancel task_id={} reason={} by=owner",
                    record.task_id,
                    "owner_interrupt",
                )
        return cancelled

    def get_result(self, task_id: str, *, owner: str | None = None) -> str | None:
        """Return the result/error string for a finished task, else None."""
        record = self._find(task_id)
        if record is None or not self._owner_ok(record, owner):
            return None
        if record.state not in _TERMINAL_STATES:
            return None
        return record.result if record.state == "completed" else record.error

    async def cancel(self, task_id: str, *, owner: str | None = None) -> str:
        record = self._find(task_id)
        # Treat a non-owner's request as "unknown" so task existence is not
        # disclosed across conversations.
        if record is None or not self._owner_ok(record, owner):
            return f"Unknown task {task_id}."
        if record.task is None or record.task.done():
            return f"Task {task_id} already finished."
        record.task.cancel()
        # Emit the canonical cancel line for promoted (event-loop) workers
        # so a ``/stop <id>`` shows up in the §5.2 chain alongside its
        # eventual ``event_loop.worker_done state=cancelled`` line. The
        # ``by`` field distinguishes a targeted single-worker stop
        # (``by=id``) from a fan-out owner interrupt
        # (``cancel_by_owner`` emits ``by=owner``).
        if record.agent == _PROMOTED_LABEL:
            logger.info(
                "event_loop.cancel task_id={} reason={} by=id",
                record.task_id,
                "stop_command",
            )
        return f"Cancellation requested for task {task_id}."

    # ── Internals ────────────────────────────────────────────────────────

    def _find(self, task_id: str) -> BackgroundTask | None:
        return self._active.get(task_id) or self._terminal.get(task_id)

    @staticmethod
    def _snapshot(record: BackgroundTask) -> dict[str, Any]:
        return {
            "task_id": record.task_id,
            "agent": record.agent,
            "state": record.state,
            "elapsed_seconds": round(record.elapsed_seconds, 1),
        }
