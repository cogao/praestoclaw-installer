"""
Approval workflow — gates agent actions that require human confirmation.

When the PolicyEngine resolves an autonomy level of APPROVAL (level 1),
the agent creates an ApprovalRequest here.  The request stays pending
until a human resolves it (approve / deny) or the request exceeds its
configured maximum age. Expiry is fail-closed: the tool is not executed.
Timeout configuration may be used by callers for reminders or escalation,
but never for an automatic approval decision.

In v0.2+ the manager supports async wait/resume: the agent loop blocks
on an asyncio.Event until a human responds via CLI prompt or Cloud/Web
channel command.
"""

from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from enum import Enum
from typing import Any

from loguru import logger

from praestoclaw.config.schema import ApprovalConfig, AutonomyLevel, ChannelType

# ── Data model ──────────────────────────────────────────────────────────────


class ApprovalStatus(str, Enum):
    """Lifecycle states for an approval request."""

    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    TIMEOUT = "timeout"
    EXPIRED = "expired"


@dataclass
class ApprovalRequest:
    """A single pending-approval record.

    Attributes
    ----------
    id:
        Unique request identifier (UUID4).
    tool_name:
        The tool that triggered the approval requirement.
    args:
        The arguments the tool would be called with.
    agent_name:
        The agent that requested the action.
    autonomy_level:
        The resolved autonomy level at creation time.
    channel:
        Channel through which the approval was requested.
    status:
        Current lifecycle state.
    created_at:
        UTC timestamp of request creation.
    resolved_at:
        UTC timestamp of resolution, or ``None`` if still pending.
    resolver:
        Identity of the human who resolved the request, or ``None``.
    """

    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    tool_name: str = ""
    args: dict[str, Any] = field(default_factory=dict)
    agent_name: str = ""
    autonomy_level: AutonomyLevel = AutonomyLevel.APPROVAL
    channel: ChannelType = ChannelType.CLI
    channel_id: str = ""
    score: int | None = None  # v2: risk score 0-10 or None
    reason: str = ""
    always_allow: bool = True  # whether "Always Allow" is available (from policy table)
    trigger: str = ""  # e.g. "📅 Scheduled: daily-cleanup", "" for interactive
    status: ApprovalStatus = ApprovalStatus.PENDING
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    resolved_at: datetime | None = None
    resolver: str | None = None
    action: str = ""  # "approve", "deny", "always" — set on resolution
    teams_activity_id: str | None = None  # Teams card ActivityId for cross-channel updates


# ── Manager ─────────────────────────────────────────────────────────────────


class ApprovalManager:
    """Manages the lifecycle of approval requests.

    Parameters
    ----------
    config:
        Approval workflow settings (timeout, escalation channels, etc.).
    """

    def __init__(self, config: ApprovalConfig) -> None:
        self._config = config
        self._pending: dict[str, ApprovalRequest] = {}
        self._waiters: dict[str, asyncio.Event] = {}
        self._resolved: dict[str, ApprovalRequest] = {}
        logger.debug(
            "ApprovalManager initialised — timeout={}s, max_age={}s, auto_approve={}s, escalation={}",
            config.timeout_seconds,
            config.max_age_seconds,
            config.auto_approve_timeout,
            config.escalation_channels,
        )

    # ── Cleanup ───────────────────────────────────────────────────────

    def _cleanup_stale_resolved(self) -> None:
        """Remove resolved entries older than 60 seconds."""
        cutoff = datetime.now(UTC) - timedelta(seconds=60)
        stale = [
            rid
            for rid, req in self._resolved.items()
            if req.resolved_at and req.resolved_at < cutoff
        ]
        for rid in stale:
            del self._resolved[rid]

    # ── Create request ──────────────────────────────────────────────────

    async def request_approval(
        self,
        tool_name: str,
        args: dict[str, Any],
        agent_name: str,
        channel: ChannelType | None,
        channel_id: str = "",
        score: int | None = None,
        reason: str = "",
        always_allow: bool = True,
        trigger: str = "",
    ) -> ApprovalRequest:
        """Create an approval request and register it as pending.

        Parameters
        ----------
        tool_name:
            The tool requiring approval.
        args:
            Proposed tool call arguments.
        agent_name:
            Agent identity requesting the action.
        channel:
            Channel the approval prompt should be sent through.

        Returns
        -------
        ApprovalRequest
            The newly created (PENDING) request.
        """
        self._cleanup_stale_resolved()

        request = ApprovalRequest(
            tool_name=tool_name,
            args=args,
            agent_name=agent_name,
            autonomy_level=AutonomyLevel.APPROVAL,
            channel=ChannelType.of(channel, self._config.default_channel),
            channel_id=channel_id,
            score=score,
            reason=reason,
            always_allow=always_allow,
            trigger=trigger,
        )
        self._pending[request.id] = request
        self._waiters[request.id] = asyncio.Event()
        logger.info(
            "Approval requested: id={} tool={} agent={} channel={}",
            request.id,
            tool_name,
            agent_name,
            channel,
        )
        return request

    # ── Generic semantic ask ────────────────────────────────────────────

    async def request_ask(
        self,
        *,
        prompt: str,
        agent_name: str,
        channel: ChannelType | None,
        channel_id: str = "",
        next_step: str = "",
        reason: str = "",
    ) -> ApprovalRequest:
        """Register a generic, semantic user-approval ("ask") request.

        Unlike :meth:`request_approval`, this is **not** tied to a
        tool-permission decision. It lets an agent pause at an SOP gate (e.g.
        a plan ``checkpoint(ask_user=true)`` dry-run) and block on
        :meth:`wait_for_resolution` until the user approves or denies — out of
        band, via the same ``/api/approvals/{id}/resolve`` path the permission
        cards use. That out-of-band resolve is exactly what lets a **detached
        background worker** await user input it could otherwise never receive
        (its forked session has no inbound message routing).

        Returns the newly created PENDING request; the caller delivers a card
        and then awaits :meth:`wait_for_resolution`.
        """
        args: dict[str, Any] = {"summary": prompt}
        if next_step:
            args["next_step"] = next_step

        # Delegate the construct + register + cleanup to request_approval — an
        # ask is just an approval with no tool-permission semantics (no score,
        # never "always allow"). The ``plan:checkpoint`` tool name tags it in
        # the logs so it's still distinguishable from a permission approval.
        return await self.request_approval(
            tool_name="plan:checkpoint",
            args=args,
            agent_name=agent_name,
            channel=channel,
            channel_id=channel_id,
            score=None,
            reason=reason or "User confirmation requested at a plan checkpoint.",
            always_allow=False,  # semantic gate — "always allow" is meaningless here
            trigger="",
        )

    # ── Resolve ─────────────────────────────────────────────────────────

    def discard(self, request_id: str) -> None:
        """Drop a pending request that was never delivered to a user.

        Used when an approval card could not be pushed to a live surface: the
        caller will not block on :meth:`wait_for_resolution`, so the pending
        entry and its (un-awaited) waiter must be removed to avoid a leak. No
        waiter is signalled — nothing is awaiting it.
        """
        self._pending.pop(request_id, None)
        self._waiters.pop(request_id, None)
        logger.debug("Approval discarded (undelivered): id={}", request_id)

    def _finish(
        self,
        request_id: str,
        *,
        status: ApprovalStatus,
        resolver: str,
        action: str,
    ) -> ApprovalRequest:
        if request_id not in self._pending:
            raise KeyError(f"Approval request not found: {request_id}")

        request = self._pending[request_id]
        if request.status != ApprovalStatus.PENDING:
            raise ValueError(f"Request {request_id} already resolved as {request.status.value}")

        request.status = status
        request.resolved_at = datetime.now(UTC)
        request.resolver = resolver
        request.action = action

        logger.info(
            "Approval resolved: id={} status={} resolver={}",
            request_id,
            request.status.value,
            resolver,
        )

        del self._pending[request_id]
        self._resolved[request_id] = request
        waiter = self._waiters.pop(request_id, None)
        if waiter:
            waiter.set()
        return request

    def resolve(self, request_id: str, approved: bool, resolver: str, *, action: str = "") -> None:
        """Resolve a pending request.

        Parameters
        ----------
        request_id:
            The UUID of the request to resolve.
        approved:
            ``True`` to approve, ``False`` to deny.
        resolver:
            Identity of the human resolving the request.
        action:
            Original action verb ("approve", "deny", "always").

        Raises
        ------
        KeyError
            If ``request_id`` is not found among pending requests.
        ValueError
            If the request has already been resolved.
        """
        self._finish(
            request_id,
            status=ApprovalStatus.APPROVED if approved else ApprovalStatus.DENIED,
            resolver=resolver,
            action=action or ("approve" if approved else "deny"),
        )

    def expire(self, request_id: str, *, resolver: str = "max-age") -> ApprovalRequest:
        """Expire a pending request without treating it as user denial."""
        return self._finish(
            request_id,
            status=ApprovalStatus.EXPIRED,
            resolver=resolver,
            action="expired",
        )

    def _max_age_seconds(self, override: float | None = None) -> float:
        return float(self._config.max_age_seconds if override is None else override)

    def expire_if_stale(
        self,
        request_id: str,
        *,
        max_age_seconds: float | None = None,
        now: datetime | None = None,
        resolver: str = "max-age",
    ) -> ApprovalRequest | None:
        """Expire *request_id* if it exceeds max age; return expired request."""
        request = self._pending.get(request_id)
        if request is None:
            return None
        max_age = self._max_age_seconds(max_age_seconds)
        if max_age <= 0:
            return None
        elapsed = ((now or datetime.now(UTC)) - request.created_at).total_seconds()
        if elapsed < max_age:
            return None
        return self.expire(request_id, resolver=resolver)

    def expire_stale(
        self,
        *,
        max_age_seconds: float | None = None,
        now: datetime | None = None,
        resolver: str = "max-age",
    ) -> list[ApprovalRequest]:
        """Expire all pending requests older than max age."""
        expired: list[ApprovalRequest] = []
        for request_id in list(self._pending):
            request = self.expire_if_stale(
                request_id,
                max_age_seconds=max_age_seconds,
                now=now,
                resolver=resolver,
            )
            if request is not None:
                expired.append(request)
        return expired

    # ── Async wait/resume ───────────────────────────────────────────────

    async def wait_for_resolution(
        self,
        request_id: str,
        auto_approve_timeout: int | None = None,
        reject_timeout: int | None = None,
        expire_timeout: float | None = None,
    ) -> ApprovalRequest:
        """Block until a pending request is manually resolved or expires.

        Parameters
        ----------
        request_id:
            The UUID of the pending request.
        auto_approve_timeout:
            Deprecated compatibility argument. Ignored; requests remain
            pending until a manual decision.
        reject_timeout:
            Deprecated compatibility argument. Ignored; requests remain
            pending until a manual decision.
        expire_timeout:
            Maximum request age in seconds before expiring fail-closed.
            ``None`` uses ``ApprovalConfig.max_age_seconds``; ``0`` disables
            expiry.

        Returns
        -------
        ApprovalRequest
            The resolved request. Timeout arguments are accepted for backward
            compatibility but no longer auto-approve or auto-reject the request.
        """
        waiter = self._waiters.get(request_id)
        if waiter is None:
            # Already resolved (e.g. by CLI inline prompt)
            resolved = self._resolved.pop(request_id, None)
            if resolved:
                return resolved
            raise KeyError(f"No waiter for request {request_id}")

        request = self._pending.get(request_id)
        if request is None:
            resolved = self._resolved.pop(request_id, None)
            if resolved:
                self._waiters.pop(request_id, None)
                return resolved
            raise KeyError(f"Approval request not found: {request_id}")
        max_age = self._max_age_seconds(expire_timeout)
        if max_age <= 0:
            await waiter.wait()
        else:
            elapsed = (datetime.now(UTC) - request.created_at).total_seconds()
            remaining = max(0.0, max_age - elapsed)
            try:
                await asyncio.wait_for(waiter.wait(), timeout=remaining)
            except TimeoutError:
                resolved = self._resolved.pop(request_id, None)
                if resolved:
                    self._waiters.pop(request_id, None)
                    return resolved
                try:
                    return self.expire(request_id, resolver="max-age")
                except KeyError:
                    resolved = self._resolved.pop(request_id, None)
                    if resolved:
                        self._waiters.pop(request_id, None)
                        return resolved
                    raise

        # Resolved by human — pick up the result
        resolved = self._resolved.pop(request_id, None)
        self._waiters.pop(request_id, None)
        if resolved:
            return resolved
        raise KeyError(f"Resolved request {request_id} not found in results")

    # ── Partial wait (for escalation) ────────────────────────────────

    async def wait_partial(self, request_id: str, timeout: float) -> bool:
        """Wait up to *timeout* seconds for resolution without auto-resolving.

        Returns ``True`` if the request was resolved within the window,
        ``False`` if the timeout elapsed while still PENDING.  Unlike
        :meth:`wait_for_resolution`, this does **not** auto-approve or reject
        on timeout — the caller decides what to do next.
        """
        waiter = self._waiters.get(request_id)
        if waiter is None:
            # Already resolved (e.g. by CLI inline prompt) or unknown
            return request_id in self._resolved
        try:
            await asyncio.wait_for(waiter.wait(), timeout=timeout)
            return True
        except TimeoutError:
            return False

    def is_pending(self, request_id: str) -> bool:
        """Return ``True`` if *request_id* is still awaiting resolution."""
        return request_id in self._pending

    @property
    def timeout_seconds(self) -> int:
        """Configured approval escalation/reminder interval in seconds."""
        return self._config.timeout_seconds

    @property
    def max_age_seconds(self) -> int:
        """Maximum approval age before fail-closed expiry; 0 disables it."""
        return self._config.max_age_seconds

    @property
    def escalation_channels(self) -> list[ChannelType]:
        """Static fallback channels from ``ApprovalConfig``."""
        return self._config.escalation_channels

    # ── Queries ─────────────────────────────────────────────────────────

    def get_request(self, request_id: str) -> ApprovalRequest | None:
        """Get a request by ID from pending or resolved."""
        return self._pending.get(request_id) or self._resolved.get(request_id)

    def get_pending(self) -> list[ApprovalRequest]:
        """Return all currently pending approval requests."""
        self.expire_stale()
        return [req for req in self._pending.values() if req.status == ApprovalStatus.PENDING]

    def check_timeout(self, request_id: str) -> bool:
        """Return ``False``; approval requests no longer auto-timeout.

        Retained for compatibility with older callers that periodically
        swept pending approvals. Manual approval/rejection is now the only
        terminal path.

        Parameters
        ----------
        request_id:
            The UUID of the request to check.

        Returns
        -------
        bool
            Always ``False``.
        """
        return False
