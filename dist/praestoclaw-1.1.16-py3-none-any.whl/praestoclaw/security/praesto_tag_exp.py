"""Praesto Tag Experiment — borrowed-identity capability gate.

EXPERIMENTAL / THROWAWAY. Pairs with the gateway/channel ``praesto_tag_exp``
glue (grep that prefix to see the whole experiment).

Context: in this mock the bot acts as a group's shared digital employee, but it
is physically backed by a *real* employee's agent — it borrows that employee's
identity and permissions. A real digital employee would have its own
permissions; until that exists we must not let the borrowed session silently
use permissions the lending employee never agreed to lend.

Policy (the gentleman's-mock trade-off):
  * Default-borrow — reading the CURRENT group via the Teams MCP server. This is
    the one capability the bot needs to do its job in the group, so it runs
    without bothering the employee.
  * Everything else — reads of OTHER conversations, enumerations across chats,
    Teams writes, agency-MCP operations, host filesystem read/write, shell, and
    any other tool — borrows the employee's real permissions and therefore
    requires their explicit confirmation (the approval prompt is delivered to
    the employee's private chat with the bot by the existing group→DM redirect).

This module only *classifies*; the ``ApprovalGate`` in ``hooks/handlers.py``
turns an ``"approve"`` classification into a real human-in-the-loop prompt.
"""

from __future__ import annotations

from typing import Any

PRAESTO_TAG_EXP_METADATA_KEY = "praesto_tag_exp"

# The Teams MCP server is conventionally registered under the key ``teams`` and
# surfaces tools named ``MCP_teams_<tool>`` (see mcp/adapter.py).
_TEAMS_MCP_SERVER = "teams"

# Prefix marking an MCP-server-targeting ``tools`` meta-tool call (connecting a
# server can exercise the employee's agency creds, so it stays gated).
_MCP_PREFIX_FOR_GATE = "MCP_"

# Internal tools that ARE the default-borrow surface (the group's own shared
# data), auto-allowed alongside Teams-MCP current-group reads.
_PRAESTO_TAG_EXP_BORROWED_TOOLS = frozenset({"group_memory"})

# Personal tools that must NOT surface in a borrowed-identity group turn: the
# shared employee persists facts via ``group_memory`` (the group's store), never
# the lending employee's private MEMORY.md / history. Canonical source shared by
# the loop (schema exclusion + prompt guidance) and the ``tools`` meta-tool (so
# it neither lists nor re-activates these behind the exclusion's back).
PRAESTO_TAG_EXP_PERSONAL_TOOLS: frozenset[str] = frozenset({"memory", "search_history"})

# Read-verb prefixes on the raw (post-``MCP_teams_``) tool name. Single-item
# reads are safe to borrow implicitly; enumerations must be pinned to the
# current group so they can't leak the employee's other chats.
_SINGLE_READ_VERBS = ("get", "read", "fetch", "view", "show", "describe")
_ENUM_READ_VERBS = ("list", "search", "find", "query")

# Argument keys the Teams MCP uses to scope a call to a conversation/channel
# (mirrors security/allowlist.py:_mcp_teams_scope).
_TEAMS_SCOPE_KEYS = ("conversationId", "chatId", "channelId", "teamId")

# Classification tokens returned to the gate.
PRAESTO_TAG_EXP_ALLOW = "allow"
PRAESTO_TAG_EXP_APPROVE = "approve"


def praesto_tag_exp_is_active(metadata: dict[str, Any] | None) -> bool:
    """Whether the current turn is a praesto tag exp borrowed-identity turn."""
    return bool((metadata or {}).get(PRAESTO_TAG_EXP_METADATA_KEY))


def _mcp_server_and_raw(tool_name: str) -> tuple[str, str]:
    """Split an ``MCP_<server>_<tool>`` name into ``(server, raw_tool)`` lowered.

    Returns ``("", "")`` for non-MCP (built-in / host) tools.
    """
    if not tool_name or not tool_name.startswith("MCP_"):
        return "", ""
    rest = tool_name[len("MCP_") :]
    server, _, raw = rest.partition("_")
    return server.lower(), raw.lower()


def _scope_value(args: dict[str, Any], key: str) -> str:
    value = args.get(key)
    return value.strip() if isinstance(value, str) else ""


def _has_explicit_scope(args: dict[str, Any]) -> bool:
    return any(_scope_value(args, key) for key in _TEAMS_SCOPE_KEYS)


def _is_current_group(args: dict[str, Any], current_cid: str) -> bool:
    if not current_cid:
        return False
    return any(_scope_value(args, key) == current_cid for key in _TEAMS_SCOPE_KEYS)


def praesto_tag_exp_classify_capability(
    tool_name: str, args: dict[str, Any] | None, *, current_cid: str
) -> str:
    """Return ``PRAESTO_TAG_EXP_ALLOW`` or ``PRAESTO_TAG_EXP_APPROVE``.

    ``current_cid`` is the Teams conversation id of the group this turn came
    from (``metadata["cid"]``). Only a Teams-MCP read of *that* group is
    auto-borrowed; everything else is routed to the employee for confirmation.
    """
    args = args or {}
    # The group's own shared store is part of the default-borrow surface.
    if tool_name in _PRAESTO_TAG_EXP_BORROWED_TOOLS:
        return PRAESTO_TAG_EXP_ALLOW
    # The ``tools`` meta-tool only manages the LOCAL tool registry (list /
    # describe / enable / disable a built-in tool). That is not a borrowed action
    # — any tool it enables is independently re-gated here when actually called.
    # So don't spam the employee with an approval just to inspect/enable a local
    # tool (e.g. the model poking at group_memory). Connecting an MCP server
    # (name starts with ``MCP_``) can exercise the employee's agency creds, so
    # that still confirms.
    if tool_name == "tools":
        target = str(args.get("name") or "").strip()
        if not target.startswith(_MCP_PREFIX_FOR_GATE):
            return PRAESTO_TAG_EXP_ALLOW
        return PRAESTO_TAG_EXP_APPROVE
    server, raw = _mcp_server_and_raw(tool_name)
    if server != _TEAMS_MCP_SERVER:
        return PRAESTO_TAG_EXP_APPROVE

    if raw.startswith(_SINGLE_READ_VERBS):
        # Implicit current-conversation read (no scope arg) or an explicit scope
        # that matches this group → borrow. A different conversation → confirm.
        if not _has_explicit_scope(args) or _is_current_group(args, current_cid):
            return PRAESTO_TAG_EXP_ALLOW
        return PRAESTO_TAG_EXP_APPROVE

    if raw.startswith(_ENUM_READ_VERBS):
        # Enumerations must be pinned to the current group; an unscoped list /
        # search could enumerate the employee's other (private) chats.
        if _is_current_group(args, current_cid):
            return PRAESTO_TAG_EXP_ALLOW
        return PRAESTO_TAG_EXP_APPROVE

    # Teams writes (send/create/update/delete/...) and anything else → confirm.
    return PRAESTO_TAG_EXP_APPROVE
