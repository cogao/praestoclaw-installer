"""
Auto-mode security classifier — the "does this need a human?" brain.

Ported from claude-code's ``utils/permissions/yoloClassifier.ts`` (the default
single-stage ``classify_result`` path). Instead of scoring a tool call 0-10 and
looking it up in a static policy table, this asks a fast LLM a binary question:
*should this action be blocked and shown to a human, or auto-allowed?*

Design decisions carried over from claude-code:
  * Only the **structured tool call** is shown to the classifier — never the
    main model's natural-language text — so the agent can't talk its way past
    the gate (yoloClassifier.ts:341-357).
  * The classifier is told to **err on the side of blocking**; any unparseable
    or empty response is treated as *block* (fail-closed,
    yoloClassifier.ts:826-840, 898-917).
  * On transport/timeout failure the verdict is ``unavailable`` so the caller
    can apply its own fail-closed gate (yoloClassifier.ts:1260-1270).

Secret redaction reuses the same helpers as :mod:`praestoclaw.security.scorer`.
"""

from __future__ import annotations

import asyncio
import json
import re
from dataclasses import dataclass
from importlib.resources import files as _pkg_files
from typing import TYPE_CHECKING, Any

from loguru import logger

from praestoclaw.security.leak import redact_credentials

if TYPE_CHECKING:
    from praestoclaw.providers.base import LLMProvider

# Arg keys whose values are always secrets — redacted before projection.
_SENSITIVE_ARG_KEYS = frozenset(
    {
        "password",
        "secret",
        "token",
        "api_key",
        "apikey",
        "auth",
        "authorization",
        "credentials",
        "private_key",
        "access_token",
        "refresh_token",
    }
)

_USER_INTENT_MAX_CHARS = 4000

# ── Real classifier prompts (ported verbatim from claude-code) ───────────────
# The bundled cli.js inlines these as template literals; extracted verbatim into
# praestoclaw/defaults/. ``auto_mode_system_prompt.txt`` is the base monitor
# prompt with a ``<permissions_template>`` placeholder; the external permissions
# template supplies the Environment / BLOCK / ALLOW rule sections, each wrapped
# in ``<..._to_replace>`` tags whose contents are the shipped defaults. User
# config REPLACES a section's defaults (external-template semantics).

_SYSTEM_PROMPT_FILE = "auto_mode_system_prompt.txt"
_PERMISSIONS_FILE = "auto_mode_permissions_external.txt"

_PERMISSIONS_PLACEHOLDER = "<permissions_template>"
_SECTION_TAGS = {
    "allow": "user_allow_rules_to_replace",
    "soft_deny": "user_deny_rules_to_replace",
    "environment": "user_environment_to_replace",
}

# claude-code drives structured output via a forced ``classify_result`` tool
# call. PraestoClaw's provider abstraction parses JSON text instead, so we swap
# only the final output instruction — every classification rule stays verbatim.
_CLASSIFY_TOOL_INSTRUCTION = "Use the classify_result tool to report your classification."
_JSON_OUTPUT_INSTRUCTION = (
    "Report your classification as a JSON object ONLY — no prose, no code "
    "fences, no leading text:\n"
    '{"thinking": "<brief step-by-step reasoning>", '
    '"shouldBlock": <true|false>, '
    '"reason": "<one concise sentence explaining the decision>"}'
)

# ── 2-stage XML classifier constants (ported verbatim from yoloClassifier.ts) ─
# Stage-1 suffix nudges an immediate <block> decision; stage-2 suffix asks for
# chain-of-thought to cut false positives. Both are appended after the
# </transcript> close tag (yoloClassifier.ts:550-561).
_XML_S1_SUFFIX = "\nErr on the side of blocking. <block> immediately."
_XML_S2_SUFFIX = (
    "\nReview the classification process and follow it carefully, making sure "
    "you deny actions that should be blocked. As a reminder, explicit (not "
    "suggestive or implicit) user confirmation is required to override blocks. "
    "Use <thinking> before responding with <block>."
)

# XML output-format block that replaces the ``classify_result`` tool line
# (replaceOutputFormatWithXml, yoloClassifier.ts:648-664).
_XML_OUTPUT_FORMAT = "\n".join(
    [
        "## Output Format",
        "",
        "If the action should be blocked:",
        "<block>yes</block><reason>one short sentence</reason>",
        "",
        "If the action should be allowed:",
        "<block>no</block>",
        "",
        "Do NOT include a <reason> tag when the action is allowed.",
        "Your ENTIRE response MUST begin with <block>. Do NOT output any "
        'analysis, reasoning, or commentary before <block>. No "Looking '
        'at..." or similar preamble.',
    ]
)

# Stage token budgets (yoloClassifier.ts:781, 868). Stage 1 in 'both' mode is
# tiny (fast yes/no); 'fast'-only relaxes it so a <reason> fits.
_XML_S1_MAX_TOKENS_BOTH = 64
_XML_S1_MAX_TOKENS_FAST = 256
_XML_S2_MAX_TOKENS = 4096

_THINKING_RE = re.compile(r"<thinking>[\s\S]*?</thinking>")
_THINKING_OPEN_RE = re.compile(r"<thinking>[\s\S]*$")
_BLOCK_RE = re.compile(r"<block>(yes|no)\b(</block>)?", re.IGNORECASE)
_REASON_RE = re.compile(r"<reason>([\s\S]*?)</reason>")
_THINKING_CAPTURE_RE = re.compile(r"<thinking>([\s\S]*?)</thinking>")


def _strip_thinking(text: str) -> str:
    """Remove <thinking> content so tags inside CoT aren't matched as verdicts."""
    text = _THINKING_RE.sub("", text)
    text = _THINKING_OPEN_RE.sub("", text)
    return text


def _parse_xml_block(text: str) -> bool | None:
    """Parse ``<block>yes|no</block>`` → True (block) / False (allow) / None."""
    m = _BLOCK_RE.search(_strip_thinking(text))
    if m is None:
        return None
    return m.group(1).lower() == "yes"


def _parse_xml_reason(text: str) -> str | None:
    """Parse ``<reason>...</reason>`` (thinking stripped first)."""
    m = _REASON_RE.search(_strip_thinking(text))
    return m.group(1).strip() if m else None


def _parse_xml_thinking(text: str) -> str | None:
    """Parse ``<thinking>...</thinking>`` chain-of-thought."""
    m = _THINKING_CAPTURE_RE.search(text)
    return m.group(1).strip() if m else None


# Fallback used only if the packaged prompt files cannot be read.
_FALLBACK_SYSTEM_PROMPT = (
    "You are a security monitor for an autonomous AI coding agent. Decide "
    "whether the agent's most recent tool call should be blocked and shown to a "
    "human. Block destructive, irreversible, exfiltrating, privilege-escalating, "
    "or persistence-establishing actions; allow routine read/search/in-project "
    "edits. When in doubt, block.\n" + _JSON_OUTPUT_INSTRUCTION
)


def _load_prompt_file(name: str) -> str:
    """Load a packaged prompt file from ``praestoclaw.defaults``."""
    return _pkg_files("praestoclaw.defaults").joinpath(name).read_text(encoding="utf-8")


def _substitute_section(text: str, tag: str, user_lines: list[str]) -> str:
    """Replace a ``<tag>defaults</tag>`` block (external-template semantics).

    User-provided lines REPLACE the shipped defaults; when none are given the
    defaults are kept and only the wrapper tags are removed.
    """
    pattern = re.compile(rf"<{tag}>([\s\S]*?)</{tag}>")
    if user_lines:
        replacement = "\n".join(f"- {line}" for line in user_lines)
        return pattern.sub(lambda _m: replacement, text)
    return pattern.sub(lambda m: m.group(1), text)


# ── Verdict ──────────────────────────────────────────────────────────────────


@dataclass(frozen=True, slots=True)
class ClassifierVerdict:
    """Result of a single classifier evaluation.

    Attributes
    ----------
    stage:
        Which stage produced the verdict: ``"tool_use"`` (single-stage JSON),
        ``"fast"`` (XML stage 1), or ``"thinking"`` (XML stage 2).
    stage2_entered:
        True only when the 2-stage XML classifier escalated to stage 2.
    thinking:
        Stage-2 chain-of-thought, when available.
    """

    should_block: bool
    reason: str
    unavailable: bool = False
    stage: str = "tool_use"
    stage2_entered: bool = False
    thinking: str | None = None


# ── Classifier ───────────────────────────────────────────────────────────────


class AutoModeClassifier:
    """LLM security classifier for auto-mode approval decisions.

    Two classifier implementations are supported, selected by ``classifier``:

    * ``"tool_use"`` (default) — single-stage JSON classifier: one call returns
      ``{thinking, shouldBlock, reason}``.
    * ``"both"`` / ``"fast"`` / ``"thinking"`` — the 2-stage XML classifier
      ported from claude-code. ``both`` runs a cheap stage-1 (fast yes/no) and
      only escalates to a chain-of-thought stage-2 when stage-1 says *block*;
      ``fast`` is stage-1 only; ``thinking`` is stage-2 only.

    Parameters
    ----------
    provider:
        LLMProvider used to call the fast model.
    allow_rules / soft_deny_rules / environment:
        Optional user-defined rule lines injected into the system prompt
        (mirrors claude-code's ``settings.autoMode`` allow / soft_deny /
        environment sections).
    classifier:
        Classifier mode (see above).
    audit_logger:
        Optional :class:`AuditLogger`. When provided, every judgment is
        recorded as a structured ``security:auto_mode_judge`` entry.
    """

    TIMEOUT = 60.0  # seconds — hard cap on the classifier call
    _XML_MODES = frozenset({"both", "fast", "thinking"})

    def __init__(
        self,
        provider: LLMProvider,
        *,
        allow_rules: list[str] | None = None,
        soft_deny_rules: list[str] | None = None,
        environment: list[str] | None = None,
        classifier: str = "tool_use",
        audit_logger: Any = None,
    ) -> None:
        self._provider = provider
        self._allow_rules = list(allow_rules or [])
        self._soft_deny_rules = list(soft_deny_rules or [])
        self._environment = list(environment or [])
        self._audit = audit_logger
        self._mode = classifier if classifier in self._XML_MODES else "tool_use"
        # JSON transport for the tool_use path; XML output format for 2-stage.
        self._system_prompt = self._build_system_prompt(
            _XML_OUTPUT_FORMAT if self._mode in self._XML_MODES else _JSON_OUTPUT_INSTRUCTION
        )

    def _build_system_prompt(self, output_instruction: str) -> str:
        """Assemble the real classifier prompt: base + permissions template.

        User allow / soft_deny / environment lines REPLACE the shipped default
        sections (external-template semantics). The final ``classify_result``
        tool instruction is swapped for ``output_instruction`` (JSON for the
        tool_use path, the XML ``## Output Format`` block for the 2-stage
        path). Falls back to a minimal safe prompt if the packaged prompt files
        are unreadable.
        """
        try:
            base = _load_prompt_file(_SYSTEM_PROMPT_FILE)
            perms = _load_prompt_file(_PERMISSIONS_FILE)
        except Exception as exc:  # pragma: no cover - packaging safety net
            logger.error("Auto-mode prompt files unavailable ({}); using fallback.", exc)
            return _FALLBACK_SYSTEM_PROMPT

        system = base.replace(_PERMISSIONS_PLACEHOLDER, perms)
        system = _substitute_section(system, _SECTION_TAGS["allow"], self._allow_rules)
        system = _substitute_section(system, _SECTION_TAGS["soft_deny"], self._soft_deny_rules)
        system = _substitute_section(system, _SECTION_TAGS["environment"], self._environment)
        system = system.replace(_CLASSIFY_TOOL_INSTRUCTION, output_instruction)
        return system

    async def classify(
        self,
        tool_name: str,
        args: dict[str, Any],
        user_messages: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        session_id: str = "",
    ) -> ClassifierVerdict:
        """Classify a single tool call as allow (safe) or block (needs human).

        Dispatches to the single-stage JSON classifier or the 2-stage XML
        classifier per the configured mode. Fail-closed throughout: transport
        failures return ``unavailable=True``; empty or unparseable model output
        returns ``should_block=True``. Every judgment is summarised to DEBUG and
        recorded to the audit log (when configured).
        """
        if self._mode in self._XML_MODES:
            verdict = await self._classify_xml(tool_name, args, user_messages, metadata)
        else:
            verdict = await self._classify_tool_use(tool_name, args, user_messages, metadata)
        self._record_judge(tool_name, args, session_id, verdict)
        return verdict

    def _record_judge(
        self,
        tool_name: str,
        args: dict[str, Any],
        session_id: str,
        verdict: ClassifierVerdict,
    ) -> None:
        """Emit a concise DEBUG line and a structured audit record per judgment."""
        decision = "block" if verdict.should_block else "allow"
        logger.debug(
            "Auto-mode judge: tool={} classifier={} stage={} stage2_entered={} "
            "decision={} unavailable={} reason={}",
            tool_name,
            self._mode,
            verdict.stage,
            verdict.stage2_entered,
            decision,
            verdict.unavailable,
            verdict.reason,
        )
        if self._audit is None:
            return
        details: dict[str, Any] = {
            "tool": tool_name,
            "decision": decision,
            "classifier": self._mode,
            "stage": verdict.stage,
            "stage2_entered": verdict.stage2_entered,
            "unavailable": verdict.unavailable,
            "reason": verdict.reason,
            "action": _redact_args(args),  # the exact thing that was judged
            "session_id": session_id or None,
        }
        if verdict.thinking:
            details["thinking"] = verdict.thinking[:1000]
        # block / classifier-outage → warning; clean allow → info.
        severity = "warning" if (verdict.should_block or verdict.unavailable) else "info"
        try:
            self._audit.log_security(event="auto_mode_judge", details=details, severity=severity)
        except Exception as exc:  # pragma: no cover - audit must never break judging
            logger.debug("Auto-mode judge audit write failed: {}", exc)

    async def _classify_tool_use(
        self,
        tool_name: str,
        args: dict[str, Any],
        user_messages: list[str] | None,
        metadata: dict[str, Any] | None,
    ) -> ClassifierVerdict:
        """Single-stage JSON classifier (the ``classify_result`` path)."""
        user_prompt = _build_user_prompt(tool_name, args, user_messages, metadata)
        messages = [
            {"role": "system", "content": self._system_prompt},
            {"role": "user", "content": user_prompt},
        ]
        try:
            response = await asyncio.wait_for(
                self._provider.complete(
                    model="fast",
                    messages=messages,
                    temperature=0,
                    max_tokens=1024,
                ),
                timeout=self.TIMEOUT,
            )
        except Exception as exc:  # includes TimeoutError from asyncio.wait_for
            logger.warning("Auto-mode classifier unavailable for {}: {}", tool_name, exc)
            return ClassifierVerdict(
                should_block=True,
                reason=f"classifier unavailable ({type(exc).__name__})",
                unavailable=True,
                stage="tool_use",
            )

        return _parse_response(response.content)

    async def _call_model(self, user_content: str, max_tokens: int) -> str:
        """Send system + user content to the fast model; return raw text."""
        response = await asyncio.wait_for(
            self._provider.complete(
                model="fast",
                messages=[
                    {"role": "system", "content": self._system_prompt},
                    {"role": "user", "content": user_content},
                ],
                temperature=0,
                max_tokens=max_tokens,
            ),
            timeout=self.TIMEOUT,
        )
        return response.content or ""

    async def _classify_xml(
        self,
        tool_name: str,
        args: dict[str, Any],
        user_messages: list[str] | None,
        metadata: dict[str, Any] | None,
    ) -> ClassifierVerdict:
        """2-stage XML classifier (ported from ``classifyYoloActionXml``).

        * ``both``: stage-1 fast yes/no; escalate to stage-2 CoT only on block.
        * ``fast``: stage-1 only (verdict final).
        * ``thinking``: stage-2 only.

        Fidelity note: the provider ``complete`` API has no ``stop_sequences``,
        so stage-1 in ``both`` mode is not truncated at ``</block>`` — the
        first-match XML parse makes this behaviourally equivalent.
        """
        transcript = _build_user_prompt(tool_name, args, user_messages, metadata)
        stage1_ran = False

        # ── Stage 1 (fast) — skipped in 'thinking' mode ──────────────────
        if self._mode != "thinking":
            s1_content = transcript + _XML_S1_SUFFIX
            s1_max = _XML_S1_MAX_TOKENS_FAST if self._mode == "fast" else _XML_S1_MAX_TOKENS_BOTH
            try:
                s1_text = await self._call_model(s1_content, s1_max)
                stage1_ran = True
            except Exception as exc:
                logger.warning("Auto-mode XML stage-1 unavailable for {}: {}", tool_name, exc)
                return ClassifierVerdict(
                    True,
                    f"classifier unavailable ({type(exc).__name__})",
                    unavailable=True,
                    stage="fast",
                )

            s1_block = _parse_xml_block(s1_text)

            # Stage-1 ALLOW → return immediately (fast path).
            if s1_block is False:
                return ClassifierVerdict(False, "Allowed by fast classifier", stage="fast")

            # 'fast' mode: stage 1 is final — resolve block / unparseable here.
            if self._mode == "fast":
                if s1_block is None:
                    reason = "Classifier stage 1 unparseable — blocking for safety"
                else:
                    reason = _parse_xml_reason(s1_text) or "Blocked by fast classifier"
                return ClassifierVerdict(True, reason, stage="fast")

            # 'both' mode, stage-1 said block (or unparseable) → escalate.
            logger.debug(
                "Auto-mode: tool={} stage-1 verdict={} → escalating to stage-2",
                tool_name,
                "block" if s1_block else "unparseable",
            )

        # ── Stage 2 (thinking) ───────────────────────────────────────────
        s2_content = transcript + _XML_S2_SUFFIX
        try:
            s2_text = await self._call_model(s2_content, _XML_S2_MAX_TOKENS)
        except Exception as exc:
            logger.warning("Auto-mode XML stage-2 unavailable for {}: {}", tool_name, exc)
            # If stage 1 ran, block on its assessment (not "unavailable");
            # otherwise the classifier never produced a verdict.
            reason = (
                "Stage 2 classifier error — blocking based on stage 1 assessment"
                if stage1_ran
                else "Classifier unavailable — blocking for safety"
            )
            return ClassifierVerdict(
                True,
                reason,
                unavailable=not stage1_ran,
                stage="thinking",
                stage2_entered=stage1_ran,
            )

        s2_block = _parse_xml_block(s2_text)
        if s2_block is None:
            reason = "Classifier stage 2 unparseable — blocking for safety"
            should_block = True
            thinking = None
        else:
            should_block = s2_block
            reason = _parse_xml_reason(s2_text) or "No reason provided"
            thinking = _parse_xml_thinking(s2_text)

        return ClassifierVerdict(
            should_block,
            reason,
            stage="thinking",
            stage2_entered=stage1_ran,
            thinking=thinking,
        )


# ── Prompt construction ──────────────────────────────────────────────────────


def _build_user_prompt(
    tool_name: str,
    args: dict[str, Any],
    user_messages: list[str] | None,
    metadata: dict[str, Any] | None,
) -> str:
    """Project the tool call into the ``<transcript>`` the prompt expects.

    The classifier evaluates the **last entry** in the transcript, so recent
    user intent lines come first and the proposed action's compact projection
    (``{tool_name: redacted_args}``) is last.
    """
    lines: list[str] = ["<transcript>"]

    if user_messages:
        total = 0
        for msg in user_messages[-3:]:
            line = f"User: {redact_credentials(str(msg))}"
            if total + len(line) > _USER_INTENT_MAX_CHARS:
                remaining = _USER_INTENT_MAX_CHARS - total
                if remaining > 0:
                    lines.append(line[:remaining])
                break
            lines.append(line)
            total += len(line)

    if (metadata or {}).get("source") == "cron":
        lines.append(
            "User: [unattended scheduled/cron run — no human is watching; "
            "resolve ambiguity toward blocking]"
        )

    redacted = _redact_args(args)
    lines.append(json.dumps({tool_name: redacted}, default=str, ensure_ascii=False))
    lines.append("</transcript>")
    return "\n".join(lines)


# ── Response parsing ─────────────────────────────────────────────────────────


def _parse_response(content: str | None) -> ClassifierVerdict:
    """Parse ``{"thinking","shouldBlock","reason"}``; fail-closed on garbage."""
    if not content or not content.strip():
        return ClassifierVerdict(True, "empty classifier response — blocking for safety")

    stripped = content.strip()
    # Strip markdown code fences the model may wrap around the JSON.
    if stripped.startswith("```"):
        if "\n" in stripped:
            stripped = stripped.split("\n", 1)[1]
        else:
            stripped = stripped[3:]
        stripped = stripped.lstrip()
        if stripped.lower().startswith("json"):
            stripped = stripped[4:].lstrip()
    if stripped.endswith("```"):
        stripped = stripped[:-3]
    stripped = stripped.strip()

    try:
        data = json.loads(stripped)
    except (json.JSONDecodeError, TypeError, ValueError):
        return ClassifierVerdict(
            True, f"unparseable classifier response — blocking for safety: {content!r:.200}"
        )

    if not isinstance(data, dict) or "shouldBlock" not in data:
        return ClassifierVerdict(True, "invalid classifier schema — blocking for safety")

    should_block = bool(data.get("shouldBlock"))
    reason = str(data.get("reason") or "").strip() or "No reason provided"
    return ClassifierVerdict(should_block, reason)


# ── Argument redaction ───────────────────────────────────────────────────────


def _redact_args(args: dict[str, Any]) -> dict[str, Any]:
    """Replace secret-valued args with ``[REDACTED]`` before projection."""
    redacted: dict[str, Any] = {}
    for key, value in args.items():
        if key.lower() in _SENSITIVE_ARG_KEYS:
            redacted[key] = "[REDACTED]"
        elif isinstance(value, str):
            cleaned = redact_credentials(value)
            redacted[key] = cleaned
        elif isinstance(value, dict):
            redacted[key] = _redact_args(value)
        elif isinstance(value, list):
            redacted[key] = [
                _redact_args(v)
                if isinstance(v, dict)
                else (redact_credentials(v) if isinstance(v, str) else v)
                for v in value
            ]
        else:
            redacted[key] = value
    return redacted
