"""
Denial tracking for the auto-mode approval decider.

Ported from claude-code's ``utils/permissions/denialTracking.ts``. Tracks how
many times in a row (and in total, per session) the auto-mode classifier has
decided to block an action. Once either limit is hit the decider stops trusting
the classifier for that session and falls back to plain human prompting, so a
misbehaving classifier can never silently stall an agent in a block loop.

A "success" here means the classifier *allowed* an action (an AUTO decision),
mirroring claude-code where ``recordSuccess`` is called on the allow path. It
resets the consecutive counter but never the cumulative total.
"""

from __future__ import annotations

from dataclasses import dataclass

# Limits mirror claude-code (denialTracking.ts:12-15).
MAX_CONSECUTIVE_DENIALS = 3
MAX_TOTAL_DENIALS = 20


@dataclass
class DenialTrackingState:
    """Per-session block counters for the auto-mode classifier."""

    consecutive_denials: int = 0
    total_denials: int = 0

    def record_denial(self) -> None:
        """Register a classifier block (HUMAN decision)."""
        self.consecutive_denials += 1
        self.total_denials += 1

    def record_success(self) -> None:
        """Register a classifier allow (AUTO decision); clears the streak."""
        self.consecutive_denials = 0

    def should_fallback_to_prompting(self) -> bool:
        """True once too many blocks accumulate — force manual review."""
        return (
            self.consecutive_denials >= MAX_CONSECUTIVE_DENIALS
            or self.total_denials >= MAX_TOTAL_DENIALS
        )
