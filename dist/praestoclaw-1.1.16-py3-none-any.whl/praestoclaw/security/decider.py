"""
Approval deciders — the pluggable "does this tool call need a human?" step.

The :class:`~praestoclaw.hooks.handlers.ApprovalGate` delegates the AUTO / HUMAN
/ REJECT decision to an :class:`ApprovalDecider`. Everything *downstream* of the
decision — building the approval request, pushing the review card to Teams / Web
/ CLI, and awaiting the human's Approve / Deny — is unchanged and shared by every
decider. Only the decision itself is swappable via ``security.approval.decider``.

Two implementations ship:

* :class:`ScoringDecider` (``decider="scoring"``, default) — the original
  behaviour: risk score (tool ``assess_risk`` → LLM scorer) looked up in the
  static ``score × profile`` policy table (:mod:`praestoclaw.security.risk`).
* :class:`AutoModeDecider` (``decider="auto"``) — claude-code's *auto mode*: a
  fast binary LLM classifier decides allow vs block, with a safe-tool fast path,
  a fail-closed gate when the classifier is unavailable, and per-session denial
  tracking that falls back to prompting after too many blocks.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

from loguru import logger

from praestoclaw.security.risk import (
    PolicyAction,
    RiskPrompt,
    RiskScore,
    SecurityProfile,
    lookup_policy,
)

if TYPE_CHECKING:
    from praestoclaw.hooks.manager import PreToolHookContext
    from praestoclaw.security.auto_classifier import AutoModeClassifier
    from praestoclaw.security.denial_tracking import DenialTrackingState
    from praestoclaw.security.scorer import RiskScorer


# ── Decision result ──────────────────────────────────────────────────────────


@dataclass(frozen=True, slots=True)
class ApprovalDecision:
    """Outcome of an approval decision, consumed by the ApprovalGate.

    Attributes
    ----------
    action:
        ``AUTO`` (run immediately), ``HUMAN`` / ``TIMEOUT_AUTO`` (send a review
        card and wait), or ``REJECT`` (block, return an error to the agent).
    reason:
        Human-readable rationale, shown on the approval card / in logs.
    always_allow:
        Whether the review card should offer an "Always Allow" button.
    score:
        Risk score 0-10 or ``None`` — for card display only. Auto-mode
        decisions leave this ``None`` (the classifier is binary).
    """

    action: PolicyAction
    reason: str
    always_allow: bool = False
    score: int | None = None


# ── Decider protocol ─────────────────────────────────────────────────────────


@runtime_checkable
class ApprovalDecider(Protocol):
    """Produces an :class:`ApprovalDecision` for a proposed tool call."""

    async def decide(self, ctx: PreToolHookContext) -> ApprovalDecision: ...


def _is_cron(ctx: PreToolHookContext) -> bool:
    return bool(ctx.metadata) and ctx.metadata.get("source") == "cron"


# ── Scoring decider (default — original behaviour) ───────────────────────────


class ScoringDecider:
    """Risk-score + policy-table decider (the original ApprovalGate logic).

    Extracted verbatim so ``decider="scoring"`` is byte-for-byte identical to
    the pre-refactor behaviour.
    """

    def __init__(
        self,
        scorer: RiskScorer | None,
        security_profile: str | SecurityProfile = "standard",
    ) -> None:
        self._scorer = scorer
        self._security_profile = security_profile

    async def decide(self, ctx: PreToolHookContext) -> ApprovalDecision:
        cron = _is_cron(ctx)

        # No scorer wired -> deterministic assess_risk + policy only.
        if self._scorer is None:
            tool_ref = ctx.tool_ref
            if tool_ref is not None and hasattr(tool_ref, "assess_risk"):
                assessment = tool_ref.assess_risk(ctx.args)
                if isinstance(assessment, RiskScore):
                    score = assessment.score
                    reason = assessment.reason
                    if cron and score is not None:
                        score = min(score + 1, 10)
                        reason = f"{reason} [+1 cron elevation]"
                    action, always_allow = lookup_policy(score, self._security_profile)
                    return ApprovalDecision(action, reason, always_allow, score)
                # RiskPrompt but no scorer → fail closed.
                if isinstance(assessment, RiskPrompt):
                    return ApprovalDecision(
                        PolicyAction.REJECT,
                        "No risk scorer available for LLM evaluation",
                        False,
                        None,
                    )
            # No assess_risk at all → allow.
            return ApprovalDecision(PolicyAction.AUTO, "", False, None)

        # Scorer path: assess_risk → scorer → policy table.
        risk_score = await self._scorer.score(
            ctx.tool_name,
            ctx.args,
            tool_ref=ctx.tool_ref,
            user_messages=ctx.user_messages or [],
        )
        score = risk_score.score
        reason = risk_score.reason
        if cron and score is not None:
            score = min(score + 1, 10)
            reason = f"{reason} [+1 cron elevation]"
        action, always_allow = lookup_policy(score, self._security_profile)
        return ApprovalDecision(action, reason, always_allow, score)


# ── Auto-mode decider (claude-code port) ─────────────────────────────────────

# Read-only / metadata tools that never need classification — the auto-mode
# fast path (mirrors claude-code's classifierDecision.ts SAFE_YOLO_ALLOWLISTED).
DEFAULT_AUTO_SAFE_TOOLS: frozenset[str] = frozenset(
    {
        "read_file",
        "list_dir",
        "search_files",
        "search_history",
        "web_search",
        "tasks",
        "tools",
        "plan",
        "github_copilot_status",
        "github_copilot_models",
        "claude_code_status",
        "check_update",
        "megaphone_state",
    }
)


class AutoModeDecider:
    """Classifier-driven decider — claude-code *auto mode*.

    Decision order for one tool call:

    1. **Safe-tool fast path** — read-only / metadata tools → ``AUTO`` without
       an LLM call.
    2. **Denial fallback** — if this session has hit the consecutive/total block
       limits, stop trusting the classifier and force ``HUMAN``.
    3. **Classify** — ask the binary LLM classifier ``shouldBlock``.
       * classifier ``unavailable`` → fail-closed ``HUMAN`` (a review card is
         still sent; nothing is auto-run on a classifier outage).
       * ``shouldBlock`` → ``HUMAN`` (record a denial).
       * otherwise → ``AUTO`` (record a success, resetting the streak).

    Blocked / fallback decisions still flow through the normal approval-card
    pipeline, so "send a card to a human for review" is entirely unchanged.
    """

    def __init__(
        self,
        classifier: AutoModeClassifier,
        *,
        safe_tools: frozenset[str] | None = None,
    ) -> None:
        self._classifier = classifier
        self._safe_tools = safe_tools if safe_tools is not None else DEFAULT_AUTO_SAFE_TOOLS
        self._states: dict[str, DenialTrackingState] = {}

    def _state_for(self, session_id: str) -> DenialTrackingState:
        from praestoclaw.security.denial_tracking import DenialTrackingState

        key = session_id or "<no-session>"
        state = self._states.get(key)
        if state is None:
            state = DenialTrackingState()
            self._states[key] = state
        return state

    async def decide(self, ctx: PreToolHookContext) -> ApprovalDecision:
        # 1. Safe-tool fast path.
        if ctx.tool_name in self._safe_tools:
            return ApprovalDecision(PolicyAction.AUTO, "auto-mode safe tool", False, None)

        state = self._state_for(ctx.session_id)

        # 2. Denial fallback — too many blocks, stop auto-classifying.
        if state.should_fallback_to_prompting():
            logger.info(
                "Auto-mode denial limit reached (consec={} total={}) — "
                "forcing manual review for tool '{}'",
                state.consecutive_denials,
                state.total_denials,
                ctx.tool_name,
            )
            return ApprovalDecision(
                PolicyAction.HUMAN,
                "Auto mode paused after repeated blocks — manual review required.",
                always_allow=True,
                score=None,
            )

        # 3. Classify.
        verdict = await self._classifier.classify(
            ctx.tool_name,
            ctx.args,
            user_messages=ctx.user_messages or [],
            metadata=ctx.metadata or {},
            session_id=ctx.session_id,
        )

        if verdict.unavailable:
            # Fail-closed gate: a classifier outage must not auto-run anything.
            state.record_denial()
            return ApprovalDecision(
                PolicyAction.HUMAN,
                f"Auto-mode classifier unavailable — manual review: {verdict.reason}",
                always_allow=False,
                score=None,
            )

        if verdict.should_block:
            state.record_denial()
            return ApprovalDecision(
                PolicyAction.HUMAN, verdict.reason, always_allow=True, score=None
            )

        state.record_success()
        return ApprovalDecision(PolicyAction.AUTO, verdict.reason, False, None)


# ── Factory ──────────────────────────────────────────────────────────────────


def build_decider(
    *,
    mode: str,
    scorer: RiskScorer | None,
    provider: Any = None,
    security_profile: str | SecurityProfile = "standard",
    allow_rules: list[str] | None = None,
    soft_deny_rules: list[str] | None = None,
    environment: list[str] | None = None,
    safe_tools: frozenset[str] | None = None,
    classifier: str = "tool_use",
    audit_logger: Any = None,
) -> ApprovalDecider:
    """Construct the approval decider selected by ``security.approval.decider``.

    ``mode="auto"`` requires an LLM ``provider`` for the classifier; it falls
    back to the scoring decider (with a warning) when none is available, so a
    misconfiguration degrades to the safe default rather than crashing.
    ``classifier`` selects the auto-mode implementation (``tool_use`` single
    stage, or ``both``/``fast``/``thinking`` XML stages). ``audit_logger``, when
    provided, records every judgment as a structured audit entry.
    """
    if mode == "auto":
        if provider is None:
            logger.warning(
                "approval.decider='auto' requested but no LLM provider is "
                "available — falling back to the scoring decider."
            )
            return ScoringDecider(scorer, security_profile)
        from praestoclaw.security.auto_classifier import AutoModeClassifier

        clf = AutoModeClassifier(
            provider,
            allow_rules=allow_rules,
            soft_deny_rules=soft_deny_rules,
            environment=environment,
            classifier=classifier,
            audit_logger=audit_logger,
        )
        logger.info("Approval decider: auto mode (classifier={})", classifier)
        return AutoModeDecider(clf, safe_tools=safe_tools)

    if mode != "scoring":
        logger.warning("Unknown approval.decider '{}' — using scoring.", mode)
    return ScoringDecider(scorer, security_profile)
