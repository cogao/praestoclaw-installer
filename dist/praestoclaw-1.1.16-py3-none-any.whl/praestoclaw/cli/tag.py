"""Praesto tag experiment toggle — praestoclaw tag on|off|status.

Quickly enable/disable the group-chat shared digital-employee experiment
(config key ``praesto_tag_exp.enabled``). Changes are persisted to the
user-level ``praestoclaw.local.yaml`` and take effect on the next restart.
"""

from __future__ import annotations

import typer

from praestoclaw.cli.commands import (
    _load_config_safe,
    console,
    tag_app,
)

_CONFIG_KEY = "praesto_tag_exp.enabled"

_CONFIG_OPT = typer.Option(".", "--config", "-c", help="Config file or directory")
_PROFILE_OPT = typer.Option(None, "--profile", "-p", help="Config profile")


def _current_enabled(config: str, profile: str | None) -> bool:
    cfg = _load_config_safe(config, profile)
    return bool(getattr(getattr(cfg, "praesto_tag_exp", None), "enabled", False))


def _print_status(config: str, profile: str | None) -> None:
    enabled = _current_enabled(config, profile)
    if enabled:
        console.print("praesto tag: [green]ON[/green]")
    else:
        console.print("praesto tag: [dim]OFF[/dim]")


def _apply(value: bool) -> None:
    from praestoclaw.config.loader import set_local_config_value

    set_local_config_value(_CONFIG_KEY, value)


@tag_app.callback(invoke_without_command=True)
def _tag_main(
    ctx: typer.Context,
    config: str = _CONFIG_OPT,
    profile: str | None = _PROFILE_OPT,
) -> None:
    """Toggle the praesto tag experiment. Run with no subcommand to see status."""
    if ctx.invoked_subcommand is None:
        _print_status(config, profile)


@tag_app.command("on")
def tag_on(
    config: str = _CONFIG_OPT,
    profile: str | None = _PROFILE_OPT,
) -> None:
    """Enable praesto tag mode."""
    _apply(True)
    console.print("praesto tag: [green]ON[/green]")
    console.print("[yellow]Restart PraestoClaw for the change to take effect.[/yellow]")


@tag_app.command("off")
def tag_off(
    config: str = _CONFIG_OPT,
    profile: str | None = _PROFILE_OPT,
) -> None:
    """Disable praesto tag mode."""
    _apply(False)
    console.print("praesto tag: [dim]OFF[/dim]")
    console.print("[yellow]Restart PraestoClaw for the change to take effect.[/yellow]")


@tag_app.command("status")
def tag_status(
    config: str = _CONFIG_OPT,
    profile: str | None = _PROFILE_OPT,
) -> None:
    """Show whether praesto tag mode is currently enabled."""
    _print_status(config, profile)
