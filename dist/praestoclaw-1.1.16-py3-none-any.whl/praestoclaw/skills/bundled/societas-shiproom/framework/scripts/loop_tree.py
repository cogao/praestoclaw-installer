"""Rebuild the Loop's outline tree from print text annotated with [SR_H:<px>]
markers (injected at fetch time by loop_fetch._inline_heading_levels).

Design
------
Each heading line carries one or more `[SR_H:<px>]` markers encoding the
heading's computed font-size in pixels. Larger font-size == higher outline
level. We rank the distinct heading sizes (descending) into levels 1..N, then
build a nested tree with a level stack -- exactly like the HTML outline
algorithm for h1..h6. This means we need ZERO hard-coded section keywords: the
dashboard simply mirrors whatever structure the Loop has.

A node's body is every non-heading line until the next heading. Links / images
inside the body keep their `[SR_LINK:]` / `[SR_IMAGE:]` markers so the renderer
can surface them.
"""
from __future__ import annotations

import re

_H_RE = re.compile(r"\[SR_H:(\d+)\]")
_BARE_ORDINAL_RE = re.compile(r"^[\(]?\d+[\.\)]?$")
_LETTER_RE = re.compile(r"[A-Za-z\u4e00-\u9fa5]")
_EDGE_PUNCT = " \t.,:;()[]{}【】·"


class Node:
    __slots__ = ("title", "size", "level", "body_lines", "children")

    def __init__(self, title: str = "", size: int = 0, level: int = 0):
        self.title = title
        self.size = size
        self.level = level  # 1-based outline level (1 == biggest font)
        self.body_lines: list[str] = []
        self.children: list["Node"] = []

    @property
    def body(self) -> str:
        return "\n".join(self.body_lines).strip("\n")

    def __repr__(self) -> str:  # pragma: no cover - debug helper
        return f"Node({self.title!r}, lvl={self.level}, kids={len(self.children)})"


def _clean_title(line: str) -> str:
    s = re.sub(r"\s+", " ", _H_RE.sub("", line)).strip()
    # Loop splits "2." into "2" + "." spans -> collapse "2 ." back to "2.".
    s = re.sub(r"^(\d+)\s+\.", r"\1.", s)
    s = s.strip(_EDGE_PUNCT)
    return s


def _is_real_heading(title: str) -> bool:
    """A real section heading must contain at least one letter / CJK char.
    This rejects bold punctuation the Loop emits at heading font-size, e.g. the
    "&" between two owner chips or a stray ")" closing a link -- which would
    otherwise become junk nodes (and worse, steal the following body)."""
    return bool(_LETTER_RE.search(title))


def _parse_blocks(text: str) -> list[tuple]:
    """Return ordered blocks: ('h', size, title) or ('body', line).
    Heading lines whose title is not a real heading (pure punctuation) are
    demoted to body so they don't create junk nodes."""
    blocks: list[tuple] = []
    for line in text.splitlines():
        sizes = _H_RE.findall(line)
        if sizes:
            title = _clean_title(line)
            if title and _is_real_heading(title):
                blocks.append(("h", int(sizes[0]), title))
            elif title:
                blocks.append(("body", title))
        else:
            blocks.append(("body", line))
    return blocks


def _merge_split_ordinals(blocks: list[tuple]) -> list[tuple]:
    """Loop renders a heading's number prefix ("0.", "1") as a separate text
    span from its title, so we get two same-size heading blocks in a row. Merge
    a bare-ordinal heading into the following same-size heading."""
    out: list[tuple] = []
    i = 0
    n = len(blocks)
    while i < n:
        b = blocks[i]
        if b[0] == "h":
            size, title = b[1], b[2]
            while (
                _BARE_ORDINAL_RE.match(title)
                and i + 1 < n
                and blocks[i + 1][0] == "h"
                and blocks[i + 1][1] == size
            ):
                title = re.sub(r"\s+", " ", f"{title} {blocks[i + 1][2]}").strip()
                i += 1
            out.append(("h", size, title))
        else:
            out.append(b)
        i += 1
    return out


def build_tree(text: str) -> Node:
    """Parse [SR_H:px]-annotated Loop text into a Node tree. The returned root
    is a synthetic container; its `children` are the top-level groups."""
    blocks = _merge_split_ordinals(_parse_blocks(text))
    sizes = sorted({b[1] for b in blocks if b[0] == "h"}, reverse=True)
    level_of = {s: i + 1 for i, s in enumerate(sizes)}

    root = Node(title="ROOT", level=0)
    stack: list[Node] = [root]
    for b in blocks:
        if b[0] == "h":
            _, size, title = b
            if not title:
                continue
            lvl = level_of[size]
            while stack and stack[-1].level >= lvl:
                stack.pop()
            if not stack:
                stack.append(root)
            node = Node(title=title, size=size, level=lvl)
            stack[-1].children.append(node)
            stack.append(node)
        else:
            stack[-1].body_lines.append(b[1])
    return root


def has_outline(text: str) -> bool:
    """True if the text carries [SR_H:] markers (i.e. came from the new fetch)."""
    return "[SR_H:" in (text or "")


def content_root(root: Node) -> Node:
    """Skip the Loop's cover / document-title wrappers. The page title
    ("Shiproom Current") and the cover emoji are headings that nest the whole
    agenda one or two levels deep; descend through any single-child chain until
    we reach the node whose children are the actual top-level groups."""
    node = root
    while len(node.children) == 1 and node.children[0].children:
        node = node.children[0]
    return node


def slug(title: str) -> str:
    """Stable anchor / overlay-filename slug for a node title. MUST match
    render_view._slug so overlays line up with rendered sections."""
    s = re.sub(r"\[SR_[^\]]*\]", "", title)
    s = re.sub(r"[^0-9A-Za-z\u4e00-\u9fa5]+", "-", s).strip("-").lower()
    return s or "section"


def iter_nodes(root: Node):
    """Yield every section node under the content root (depth-first)."""
    def walk(n: Node):
        for c in n.children:
            yield c
            yield from walk(c)
    yield from walk(content_root(root))


def find_node(root: Node, query: str) -> Node | None:
    """Resolve a free-text node reference to a node. Tries, in order: exact
    slug, slug-contains, title-contains (case-insensitive)."""
    q = (query or "").strip().lower()
    qslug = slug(query)
    nodes = list(iter_nodes(root))
    for n in nodes:
        if slug(n.title) == qslug:
            return n
    for n in nodes:
        if qslug and qslug in slug(n.title):
            return n
    for n in nodes:
        if q and q in n.title.lower():
            return n
    return None
