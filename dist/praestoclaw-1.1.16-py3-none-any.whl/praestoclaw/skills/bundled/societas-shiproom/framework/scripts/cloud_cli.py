"""Agent-facing CLI for the SharePoint backend.

Subcommands map 1:1 to the slash commands in AGENT.md when storage.backend == "sharepoint".

All operations target the Shiproom channel folder configured in shiproom-config.yaml
under storage.sharepoint. Identity is taken from the signed-in MSAL token.

Usage:
    python framework/scripts/cloud_cli.py status
    python framework/scripts/cloud_cli.py update <section> <text...>
    python framework/scripts/cloud_cli.py notes <text...>
    python framework/scripts/cloud_cli.py upload-loop <local-pdf>
    python framework/scripts/cloud_cli.py upload-notes <local-pdf>
    python framework/scripts/cloud_cli.py archive [<YYYY-MM-DD>]
    python framework/scripts/cloud_cli.py whoami
    python framework/scripts/cloud_cli.py url [<path-under-base>]
"""
from __future__ import annotations

import argparse
import datetime as dt
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Optional

THIS = Path(__file__).resolve()
sys.path.insert(0, str(THIS.parent))

from cloud_io import ShiproomCloud, get_identity, short_name  # noqa: E402

# Config lookup order (first existing wins):
#   1. --config <path>   (explicit CLI arg)
#   2. <workspace>/shiproom-config.yaml          -- team override
#   3. <skill>/shiproom-config.yaml              -- bundled default
SKILL_ROOT = THIS.parents[2]              # societas-shiproom/
WORKSPACE_ROOT = THIS.parents[3]          # repo root (parent of skill)
WORKSPACE_CONFIG = WORKSPACE_ROOT / "shiproom-config.yaml"
BUNDLED_CONFIG = SKILL_ROOT / "shiproom-config.yaml"


def _maybe_self_update() -> None:
    """Best-effort self-update for git-tracked installs.

    Goal: keep skill users on latest main with zero manual steps *when the
    skill directory lives inside a git checkout*.

    Safety rules:
    - no-op when git is unavailable or this is a copied (non-git) bundle
    - no-op when worktree has local changes (never auto-overwrite)
    - fast-forward only (no merge commits / no rebases)
    - only auto-pull from origin/main for approved remotes
    """
    if os.environ.get("SR_DISABLE_SELF_UPDATE", "").strip().lower() in {"1", "true", "yes"}:
        return

    def _git(args: list[str]) -> tuple[int, str]:
        cmd = ["git", *args]
        proc = subprocess.run(
            cmd,
            cwd=str(SKILL_ROOT),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=12,
            check=False,
        )
        return proc.returncode, (proc.stdout or "")

    try:
        code, top = _git(["rev-parse", "--show-toplevel"])
    except Exception:
        return
    if code != 0:
        return

    # Restrict auto-update to trusted remotes to avoid surprising behavior
    # in arbitrary forks or unrelated repositories.
    code, remote = _git(["remote", "get-url", "origin"])
    if code != 0:
        return
    remote_l = remote.strip().lower()
    trusted = (
        "github.com/gim-home/praesto-claw",
        "github.com:gim-home/praesto-claw",
        "github.com/tajie_microsoft/societas-shiproom",
        "github.com:tajie_microsoft/societas-shiproom",
    )
    if not any(t in remote_l for t in trusted):
        return

    code, _ = _git(["diff", "--quiet"])
    if code != 0:
        return
    code, _ = _git(["diff", "--cached", "--quiet"])
    if code != 0:
        return

    # Keep it quiet unless an actual update happened.
    code, _ = _git(["fetch", "origin", "main", "--quiet"])
    if code != 0:
        return

    code, behind = _git(["rev-list", "--count", "HEAD..origin/main"])
    if code != 0:
        return
    try:
        need = int(behind.strip())
    except ValueError:
        return
    if need <= 0:
        return

    code, _ = _git(["pull", "--ff-only", "origin", "main"])
    if code == 0:
        print(f"ℹ️  Auto-updated skill from origin/main (+{need} commit{'s' if need != 1 else ''}).", file=sys.stderr)


def _resolve_config(explicit: Path | None) -> Path:
    if explicit is not None:
        return explicit
    if WORKSPACE_CONFIG.exists():
        return WORKSPACE_CONFIG
    return BUNDLED_CONFIG


def _load_cloud(cfg_path: Path) -> ShiproomCloud:
    import yaml
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    return ShiproomCloud.from_config(cfg)


# ============================================================================
# Subcommand handlers
# ============================================================================

def cmd_whoami(_args, _cloud) -> int:
    ident = get_identity()
    print(f"upn  : {ident['upn']}")
    print(f"name : {ident['name']}")
    print(f"short: {short_name()}")
    return 0


def cmd_status(_args, cloud: ShiproomCloud) -> int:
    print(f"=== Shiproom cloud status ===")
    print(f"folder: {cloud.web_url('current') or '(empty)'}")
    print()
    items = cloud.list_dir("current")
    if not items:
        print("(current/ is empty — run /sr-prep)")
        return 0
    print("current/")
    for it in sorted(items, key=lambda x: x["name"]):
        kind = "DIR " if "folder" in it else "FILE"
        size = it.get("size", 0)
        print(f"  [{kind}] {it['name']}  ({size} B)")
    sub = cloud.list_dir("current", "updates")
    if sub:
        print("\ncurrent/updates/")
        for it in sorted(sub, key=lambda x: x["name"]):
            size = it.get("size", 0)
            print(f"  [FILE] {it['name']}  ({size} B)")
    return 0


def cmd_update(args, cloud: ShiproomCloud) -> int:
    section = args.section
    body = " ".join(args.text).strip()
    if not body:
        print("ERROR: update text is empty", file=sys.stderr)
        return 2
    # The live dashboard is rendered from the Loop outline + the overlay layer.
    # Legacy `current/updates/<section>.md` section files are NO LONGER shown by
    # render_view_tree, so a plain `update <section>` used to silently vanish
    # from view.html. Route every section to its matching Loop node's overlay
    # (which always renders) so the update actually appears — the section number
    # is ignored (it drifts between skill versions).
    print(
        f"ℹ️  '{section}' 是旧版 section 文件，新架构不再渲染它；"
        f"已改挂到匹配的 Loop 节点 overlay。",
        file=sys.stderr,
    )
    rc = _append_overlay(cloud, _section_node_candidates(section), body)
    if rc != 0:
        # Node match failed — don't lose the content: fall back to the legacy
        # file and warn loudly so it can be re-homed manually.
        res = cloud.append_signed_entry(section, body)
        print(
            f"⚠️  未匹配到 Loop 节点，已回退写入 current/updates/{section}.md"
            f"（注意：该文件不会出现在 view.html，请用 `overlay <节点>` 重发）。",
            file=sys.stderr,
        )
        print(f"   {res.get('webUrl', '')}")
        return 0
    return rc


# Legacy `current/updates/<N>-<stem>.md` section stems -> ordered Loop-node
# query candidates. The section NUMBER is ignored (it drifts between skill
# versions: productivity has been 6- and 9-), so mapping keys off the stem only.
# Each candidate is fuzzy-matched against the live Loop outline by
# loop_tree.find_node (slug exact -> slug contains -> title contains).
_SECTION_NODE_ALIASES = {
    "todo": ["action item", "action items", "shiproom current"],
    "action": ["action item"],
    "data": ["business metric", "business metrics"],
    "ocv": ["customer voice", "ocv"],
    "release": ["consumer release", "release"],
    "mythos": ["mythos security", "security"],
    "security": ["security"],
    "productivity": ["10x productivity", "productivity"],
    "showcase": ["showcase"],
    "capabilities": ["capabilities"],
    "capability": ["capabilities"],
    "skill": ["capabilities"],
    "skill-quality": ["capabilities"],
    "excel": ["excel", "capabilities"],
    "word": ["word", "capabilities"],
    "ppt": ["ppt", "capabilities"],
    "foundation": ["foundation"],
}


def _section_node_candidates(section: str) -> list[str]:
    """Turn a legacy section name (e.g. '9-productivity', '1-todo') into an
    ordered list of Loop-node query strings to try, ignoring the section number."""
    stem = re.sub(r"^\d+[-_]", "", section.lower()).strip()
    candidates = list(_SECTION_NODE_ALIASES.get(stem, []))
    spaced = stem.replace("-", " ").replace("_", " ").strip()
    for extra in (stem, spaced):
        if extra and extra not in candidates:
            candidates.append(extra)
    return candidates


def _append_overlay(cloud: ShiproomCloud, queries, body: str) -> int:
    """Append a signed team update to the Loop node's overlay file
    (current/overlay/<node-slug>.md). ``queries`` is a node query string or an
    ordered list of candidate queries (first match wins), resolved against the
    live Loop outline. Shared by `overlay` and the redirected legacy `update`."""
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import loop_tree

    if isinstance(queries, str):
        queries = [queries]
    queries = [q for q in queries if q and q.strip()]
    if not queries:
        print("ERROR: no node query provided", file=sys.stderr)
        return 2

    loop_text = cloud.read_text("current", "currentloop.md", default="")
    if loop_tree.has_outline(loop_text):
        root = loop_tree.build_tree(loop_text)
        node = None
        for q in queries:
            node = loop_tree.find_node(root, q)
            if node is not None:
                break
        if node is None:
            print(
                f"ERROR: no Loop node matches any of {queries!r}. Available nodes:",
                file=sys.stderr,
            )
            for n in loop_tree.iter_nodes(root):
                print(f"   - {loop_tree.slug(n.title)}   ({n.title})", file=sys.stderr)
            return 2
        target_slug, target_title = loop_tree.slug(node.title), node.title
    else:
        target_slug, target_title = loop_tree.slug(queries[0]), queries[0]

    ts = dt.datetime.now().astimezone().isoformat(timespec="seconds")
    entry = f"### @{short_name()} · {ts}\n\n{body}\n"
    res = cloud.append_text(
        entry, "current", "overlay", f"{target_slug}.md",
        ensure_header=f"# Overlay — {target_title}\n\n",
    )
    print(f"✅ Overlay appended -> current/overlay/{target_slug}.md  (node: {target_title})")
    print(f"   by @{short_name()}")
    print(f"   {res.get('webUrl', '')}")
    return 0


def cmd_overlay(args, cloud: ShiproomCloud) -> int:
    """Append a signed team update to a Loop node's overlay file
    (current/overlay/<node-slug>.md). The overlay is a thin layer keyed by the
    Loop node's title; render_view shows it under the matching section without
    touching the Loop itself."""
    body = " ".join(args.text).strip()
    if not body:
        print("ERROR: overlay text is empty", file=sys.stderr)
        return 2
    return _append_overlay(cloud, args.node, body)


def cmd_notes(args, cloud: ShiproomCloud) -> int:
    body = " ".join(args.text).strip()
    if not body:
        print("ERROR: notes text is empty", file=sys.stderr)
        return 2
    ts = dt.datetime.now().astimezone().isoformat(timespec="seconds")
    entry = f"### @{short_name()} · {ts}\n\n{body}\n"
    cloud.append_text(entry, "current", "notes.md", ensure_header="# Notes\n\n")
    print(f"✅ Notes appended (current/notes.md)")
    return 0


def cmd_upload(args, cloud: ShiproomCloud, remote_name: str) -> int:
    local = Path(args.path)
    if not local.exists():
        print(f"ERROR: file not found: {local}", file=sys.stderr)
        return 2
    res = cloud.upload_file(local, "current", remote_name)
    print(f"✅ Uploaded {local.name} → current/{remote_name}")
    print(f"   {res.get('webUrl', '')}")
    return 0


def cmd_upload_loop(args, cloud):
    """Upload a host-exported Loop PDF, then auto-extract text and run the
    same section splitter as /sr-fetch-loop. PDF text extraction works well
    for the Loop “Print & PDF export” output -- no fidelity loss observed.
    """
    rc = cmd_upload(args, cloud, "currentloop.pdf")
    if rc != 0:
        return rc
    # Best-effort: extract PDF text and sync sections.
    local = Path(args.path)
    try:
        from pdfminer.high_level import extract_text
    except ImportError:
        print("⚠️  pdfminer.six not installed; skipping section auto-split.", file=sys.stderr)
        print("   Install with: pip install pdfminer.six", file=sys.stderr)
        return 0
    try:
        text = extract_text(str(local)) or ""
    except Exception as exc:  # noqa: BLE001
        print(f"⚠️  PDF text extraction failed: {exc}", file=sys.stderr)
        print("   currentloop.pdf is uploaded; section files NOT updated.", file=sys.stderr)
        return 0
    if len(text) < 200:
        print(f"⚠️  PDF text suspiciously short ({len(text)} chars); skipping auto-split.", file=sys.stderr)
        return 0
    import yaml
    cfg_path = _resolve_config(args.config)
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    sync_cfg = cfg.get("loop_sync") or {}
    if not sync_cfg.get("enabled", True):
        return 0
    web_url = cloud.web_url("current", "currentloop.pdf") or ""
    try:
        _sync_loop_to_updates(cloud, text, sync_cfg, web_url)
    except Exception as exc:  # noqa: BLE001
        print(f"⚠️  Auto-split failed: {exc}", file=sys.stderr)
    return 0


def cmd_upload_notes(args, cloud):
    return cmd_upload(args, cloud, "notes.pdf")


def cmd_fetch_notes(args, cloud: ShiproomCloud) -> int:
    """Find the latest meeting-notes Loop URL in the configured Teams group
    chat (notes_source.teams_chat_topic), fetch its content silently via
    headless Chrome, and upload as current/notes.md.

    UX contract:
    - Default path is fully silent: scan chat -> headless fetch -> upload.
    - On silent fetch failure (typically: this machine has never accessed
      the organizer's OneDrive Loop before), we automatically reopen the
      same URL in a visible browser so the host can SSO / approve
      "request access" once. Subsequent /sr-fetch-notes runs on this
      machine are silent again.
    - Final fallback: instruct the host to upload a PDF themselves
      via /sr-upload-notes.
    """
    import yaml
    from notes_finder import find_recent_meeting_notes, NotesFinderError
    from loop_fetch import (
        LoopFetchError, fetch_loop_markdown, fetch_loop_with_fallback,
    )

    cfg_path = _resolve_config(args.config)
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    ns = cfg.get("notes_source") or {}
    topic = (ns.get("teams_chat_topic") or "").strip()
    if not topic:
        print("ERROR: notes_source.teams_chat_topic is not set in shiproom-config.yaml.",
              file=sys.stderr)
        print("       Set it to a substring of the Teams group-chat title,", file=sys.stderr)
        print("       e.g. 'Stride Shiproom'.", file=sys.stderr)
        return 2

    n = max(1, int(getattr(args, "n", 1) or 1))
    print(f"🔍 Scanning Teams chat {topic!r} for the latest meeting notes ...")
    try:
        entries = find_recent_meeting_notes(topic, n=n)
    except NotesFinderError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 3

    latest = entries[0]
    print(f"   found {len(entries)} candidate(s); latest = {latest.timestamp}")

    interactive = bool(getattr(args, "interactive", False))
    print(f"📥 Fetching Loop content ({'headed (interactive)' if interactive else 'headless'}) ...")
    try:
        if interactive:
            markdown = fetch_loop_markdown(latest.url, headless=False, wait_for_user=True)
        else:
            markdown = fetch_loop_with_fallback(latest.url)
    except LoopFetchError as exc:
        print(f"⚠️  Could not fetch Loop content automatically: {exc}", file=sys.stderr)
        print("", file=sys.stderr)
        print("Please open the meeting-notes Loop below and export to PDF", file=sys.stderr)
        print("(Print & PDF export -> Save as PDF), then upload via /sr-upload-notes:", file=sys.stderr)
        print(f"  {latest.url}", file=sys.stderr)
        return 4
    except Exception as exc:  # noqa: BLE001
        print(f"⚠️  Unexpected error: {exc}", file=sys.stderr)
        print(f"  Loop URL: {latest.url}", file=sys.stderr)
        return 1

    import tempfile
    tmp = Path(tempfile.gettempdir()) / "shiproom_meeting_notes.md"
    # Stamp the source so we know which meeting / where it came from later.
    header = (f"<!-- meeting-notes auto-fetched {dt.datetime.now().isoformat(timespec='seconds')} -->\n"
              f"<!-- source-meeting: {latest.timestamp} -->\n"
              f"<!-- source-url: {latest.url} -->\n\n")
    tmp.write_text(header + markdown, encoding="utf-8")
    res = cloud.upload_file(tmp, "current", "notes.md")
    web_url = res.get("webUrl", "")
    print(f"✅ Fetched meeting notes -> current/notes.md ({len(markdown)} chars)")
    print(f"   meeting: {latest.timestamp}")
    print(f"   {web_url}")
    return 0


def cmd_fetch_loop(args, cloud: ShiproomCloud) -> int:
    """Auto-fetch the Current Loop page, upload as current/currentloop.md,
    then auto-split it into per-section update files (1-todo / 4-release /
    5-mythos / 6-skill-quality / 7-excel / 8-showcase / 9-productivity)
    preserving any human entries in those files.

    Reads the loop URL from config: prefers loop_source.url, falls back to
    references.loop_current. On any fetch failure, prints actionable
    instructions including the loop URL so the host can open it directly
    and upload manually.
    """
    import yaml
    from loop_fetch import LoopFetchError, fetch_loop_markdown, fetch_loop_with_fallback

    cfg_path = _resolve_config(args.config)
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    loop_cfg = cfg.get("loop_source") or {}
    refs = cfg.get("references") or {}
    loop_url = (loop_cfg.get("url") or refs.get("loop_current") or "").strip()
    if not loop_url:
        print("ERROR: no Loop URL configured (set loop_source.url or references.loop_current).", file=sys.stderr)
        return 2

    if getattr(args, "interactive", False):
        print(f"Fetching Loop content (headed interactive browser) ...")
    else:
        print(f"Fetching Loop content (silent headless; headed fallback if needed) ...")
    try:
        if getattr(args, "interactive", False):
            markdown = fetch_loop_markdown(loop_url, headless=False, wait_for_user=True)
        else:
            markdown = fetch_loop_with_fallback(loop_url)
    except LoopFetchError as exc:
        print(f"⚠️  Auto-fetch failed: {exc}", file=sys.stderr)
        print("", file=sys.stderr)
        print("Please open the Loop page, export to PDF (Print & PDF export -> Save as PDF),", file=sys.stderr)
        print("then upload it via /sr-upload-loop. Loop URL:", file=sys.stderr)
        print(f"  {loop_url}", file=sys.stderr)
        return 3
    except Exception as exc:  # noqa: BLE001
        print(f"⚠️  Unexpected error: {exc}", file=sys.stderr)
        print(f"  Loop URL: {loop_url}", file=sys.stderr)
        return 1

    import tempfile
    tmp = Path(tempfile.gettempdir()) / "shiproom_currentloop.md"
    tmp.write_text(markdown, encoding="utf-8")
    res = cloud.upload_file(tmp, "current", "currentloop.md")
    web_url = res.get("webUrl", "")
    print(f"✅ Fetched Loop -> current/currentloop.md ({len(markdown)} chars)")
    print(f"   {web_url}")

    # Auto-split into per-section update files (1-todo / 4-release / ...).
    sync_cfg = (cfg.get("loop_sync") or {})
    if sync_cfg.get("enabled", True):
        try:
            _sync_loop_to_updates(cloud, markdown, sync_cfg, web_url)
        except Exception as exc:  # noqa: BLE001
            print(f"⚠️  Loop content uploaded, but auto-split failed: {exc}", file=sys.stderr)
            print("   The Loop file is fine; sections were not synced.", file=sys.stderr)
    return 0


def _sync_loop_to_updates(cloud: ShiproomCloud, loop_text: str,
                           sync_cfg: dict, source_url: str) -> None:
    """Split currentloop.md into snippets per target file and merge them into
    each target's LOOP-SYNC block. Human /sr-update entries (outside the
    markers) are preserved."""
    from loop_split import (default_section_map, default_stop_headings,
                            file_header_for, merge_block, render_sync_block,
                            split_loop)

    section_map = sync_cfg.get("targets") or default_section_map()

    # HARD GUARDRAIL: 2-data.md and 3-ocv.md are owned by external sources
    # only (Claire's manual upload, and the OCV xlsx via fetch-ocv). Loop
    # content must NEVER touch them, even if the config is wrong.
    PROTECTED = {"2-data.md", "3-ocv.md"}
    bad = PROTECTED & set(section_map)
    if bad:
        print(f"⚠️  loop_sync.targets contains protected files {sorted(bad)}; "
              "ignoring those entries.", file=sys.stderr)
        section_map = {k: v for k, v in section_map.items() if k not in PROTECTED}

    stops = sync_cfg.get("stop_headings") or default_stop_headings()
    sliced = split_loop(loop_text, section_map, stop_headings=stops)

    print("--- Auto-syncing Loop sections into team updates ---")
    for target, snippets in sliced.items():
        try:
            existing = cloud.read_text("current", "updates", target)
        except Exception:
            existing = ""
        block = render_sync_block(snippets, source_url=source_url)
        new_text = merge_block(existing, block, file_header_for(target))
        if new_text == existing:
            print(f"  [skip] {target} (no change)")
            continue
        import tempfile
        tmp = Path(tempfile.gettempdir()) / f"shiproom_sync_{target}"
        tmp.write_text(new_text, encoding="utf-8")
        cloud.upload_file(tmp, "current", "updates", target)
        tag = f"{len(snippets)} snippet(s)" if snippets else "empty (no match)"
        print(f"  [sync] current/updates/{target}  ({tag})")


def cmd_split_loop(args, cloud: ShiproomCloud) -> int:
    """Re-run the loop section splitter on the existing current/currentloop.md.
    Useful after manually editing the section_map or when /sr-fetch-loop already
    ran but the per-section sync was skipped."""
    import yaml
    cfg_path = _resolve_config(args.config)
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    try:
        loop_text = cloud.read_text("current", "currentloop.md")
    except Exception as exc:  # noqa: BLE001
        print(f"ERROR: could not read current/currentloop.md: {exc}", file=sys.stderr)
        print("Run /sr-fetch-loop first.", file=sys.stderr)
        return 2
    sync_cfg = cfg.get("loop_sync") or {}
    web_url = cloud.web_url("current", "currentloop.md") or ""
    _sync_loop_to_updates(cloud, loop_text, sync_cfg, web_url)
    return 0


def cmd_archive(args, cloud: ShiproomCloud) -> int:
    date_str = args.date or dt.date.today().isoformat()
    # validate
    try:
        dt.date.fromisoformat(date_str)
    except ValueError:
        print(f"ERROR: invalid date '{date_str}' (expected YYYY-MM-DD)", file=sys.stderr)
        return 2

    # safety: don't overwrite an existing history entry
    existing = cloud.list_dir("history")
    if any(it["name"] == date_str for it in existing):
        print(f"ERROR: history/{date_str}/ already exists. Pick a different date or delete it first.", file=sys.stderr)
        return 2

    print(f"Archiving current/ → history/{date_str}/ ...")
    clear = bool(getattr(args, "clear", False))
    res = cloud.archive_current(date_str, clear=clear)
    mode = "cleared current/" if res.get("cleared") else "carry-forward (current/ untouched)"
    print(f"✅ Archived to {res['history_path']}  [{mode}]")
    print(f"   {cloud.web_url('history', date_str)}")
    if not res.get("cleared"):
        print("   Note: current/ files keep their previous mtime, so /sr-prep checklist will")
        print("   still flag last-week content as [STALE]/[LEFT] until you re-fetch.")
    return 0


def cmd_url(args, cloud: ShiproomCloud) -> int:
    parts = args.path.split("/") if args.path else []
    print(cloud.web_url(*parts) or "(not found)")
    return 0


# Expected files in current/ for a "ready" pre-meeting state.
# kind:
#   refresh    -- MUST be re-fetched every /sr-prep run (live external sources).
#                 Stale = older than the start of the current ISO week, or > 48h old.
#   accumulate -- grown across the week by team /sr-update calls; presence is enough.
#   generate   -- written by the agent after analysing the others; should be the
#                 newest file when prep is "done".
PREP_CHECKLIST = [
    ("currentloop.{md|pdf}",             "current",         "refresh",    "auto: /sr-fetch-loop  |  manual: /sr-upload-loop <pdf>"),
    ("updates/2-data.md",                 "current/updates", "refresh",    "Claire posts the weekly usage-analysis report, /sr-update 2-data"),
    ("updates/3-ocv.md",                  "current/updates", "refresh",    "host paste latest OCV snapshot, /sr-upload-md"),
    ("updates/1-todo.md",                 "current/updates", "accumulate", "team /sr-update entries"),
    ("updates/4-release.md",              "current/updates", "accumulate", "team /sr-update entries"),
    ("updates/5-mythos.md",               "current/updates", "accumulate", "team /sr-update entries"),
    ("updates/6-skill-quality.md",        "current/updates", "accumulate", "Core Workstream 1 (auto-filled by fetch-loop, plus team /sr-update 6-skill-quality)"),
    ("updates/7-excel.md",                "current/updates", "accumulate", "Core Workstream 2 (auto-filled by fetch-loop, plus team /sr-update 7-excel)"),
    ("updates/8-showcase.md",             "current/updates", "accumulate", "Core Workstream 3 (auto-filled by fetch-loop, plus team /sr-update 8-showcase)"),
    ("updates/9-productivity.md",         "current/updates", "accumulate", "Core Workstream 4 (auto-filled by fetch-loop, plus team /sr-update 9-productivity)"),
    ("updates/0-meeting-prep-summary.md", "current/updates", "generate",   "agent writes LAST after analysing the above"),
]


def _parse_year(raw: str | None, default_year: int) -> int:
    if not raw:
        return default_year
    y = int(raw)
    if y < 100:
        return 2000 + y
    return y


def _extract_data_period_end(text: str, reference: dt.datetime) -> Optional[dt.date]:
    """Best-effort extract of period end-date from 2-data markdown.

    Supports common patterns like:
    - 2026-05-19 ~ 2026-05-25
    - 5/19-5/25, 5/19 to 5/25, 5/19/2026-5/25/2026
    """
    candidates: list[dt.date] = []

    iso_range = re.compile(
        r"\b(20\d{2})-(\d{1,2})-(\d{1,2})\b\s*(?:to|~|\-|–|—|至)\s*\b(20\d{2})-(\d{1,2})-(\d{1,2})\b",
        flags=re.IGNORECASE,
    )
    for m in iso_range.finditer(text):
        try:
            end = dt.date(int(m.group(4)), int(m.group(5)), int(m.group(6)))
            candidates.append(end)
        except ValueError:
            continue

    md_range = re.compile(
        r"\b(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?\b\s*(?:to|~|\-|–|—|至)\s*\b(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?\b",
        flags=re.IGNORECASE,
    )
    for m in md_range.finditer(text):
        try:
            y1 = _parse_year(m.group(3), reference.year)
            y2 = _parse_year(m.group(6), y1)
            end = dt.date(y2, int(m.group(4)), int(m.group(5)))
            candidates.append(end)
        except ValueError:
            continue

    if not candidates:
        return None
    return max(candidates)


def _is_two_data_stale(item: dict, cloud: ShiproomCloud,
                       cutoff: Optional[dt.datetime]) -> tuple[bool, str]:
    """Special stale policy for 2-data.md.

    Problem addressed: Claire may upload weekly data before /sr-archive writes
    a new cutoff; strict mtime < cutoff would misclassify fresh data as stale.

    Rules:
    1) If mtime >= cutoff, it's fresh.
    2) If mtime < cutoff but file content declares a period end-date and that
       end-date is within the last 7 days from cutoff, treat as fresh.
    3) If no period can be extracted, allow a 24h grace window before cutoff.
    4) Keep the existing >48h age guardrail for refresh files.
    """
    stale, info = _is_stale(item, "refresh", cutoff=cutoff)
    if not stale:
        return (False, info)

    iso = item.get("lastModifiedDateTime")
    if not iso or cutoff is None:
        return (True, info)
    try:
        mtime = dt.datetime.fromisoformat(iso.replace("Z", "+00:00"))
    except ValueError:
        return (True, info)
    if cutoff.tzinfo is None:
        cutoff = cutoff.replace(tzinfo=dt.timezone.utc)

    # Case 2: use declared data period if present.
    text = cloud.read_text("current", "updates", "2-data.md", default="")
    period_end = _extract_data_period_end(text, reference=cutoff)
    if period_end is not None:
        if period_end >= (cutoff.date() - dt.timedelta(days=7)):
            return (
                False,
                f"data period ends {period_end.isoformat()} (accepted for current cycle)",
            )
        return (
            True,
            f"data period ends {period_end.isoformat()} (older than current cycle)",
        )

    # Case 3: mtime grace window when period is not declared.
    if mtime < cutoff and (cutoff - mtime) <= dt.timedelta(hours=24):
        return (
            False,
            f"uploaded {int((cutoff - mtime).total_seconds() // 3600)}h before last archive (grace)",
        )
    return (True, info)


def _is_stale(item: dict, kind: str, cutoff: Optional[dt.datetime] = None) -> tuple[bool, str]:
    """Return (stale, reason).
    refresh    : stale if mtime < cutoff, or > 48h old.
    accumulate : stale if mtime < cutoff (=> probably leftover from last cycle;
                 host likely forgot to /sr-archive).
    generate   : never auto-stale (agent always regenerates explicitly).

    cutoff defaults to the start of this ISO week (Monday 00:00 UTC) when no
    archive marker exists. When `current/.last-archive` is present, the caller
    passes that timestamp instead — this lets us support multi-meeting weeks
    (e.g. Wednesday + Friday cadences) without hard-coding a schedule.
    """
    if kind == "generate":
        return (False, "")
    iso = item.get("lastModifiedDateTime")
    if not iso:
        return (True, "no mtime")
    try:
        # Graph returns "2026-05-08T03:14:21Z"
        mtime = dt.datetime.fromisoformat(iso.replace("Z", "+00:00"))
    except ValueError:
        return (True, f"unparseable mtime {iso}")
    now = dt.datetime.now(dt.timezone.utc)
    if cutoff is None:
        today = now.date()
        cutoff = dt.datetime.combine(
            today - dt.timedelta(days=today.weekday()),
            dt.time.min,
            tzinfo=dt.timezone.utc,
        )
    elif cutoff.tzinfo is None:
        cutoff = cutoff.replace(tzinfo=dt.timezone.utc)
    if mtime < cutoff:
        return (True, f"from {mtime.astimezone().strftime('%Y-%m-%d %H:%M')} (before last archive {cutoff.astimezone().strftime('%Y-%m-%d %H:%M')})")
    if kind == "refresh" and (now - mtime) > dt.timedelta(hours=48):
        return (True, f"{int((now - mtime).total_seconds() // 3600)}h old")
    return (False, mtime.astimezone().strftime("%Y-%m-%d %H:%M"))


def cmd_prep(_args, cloud: ShiproomCloud) -> int:
    """Print a pre-meeting checklist comparing current/ to expected files,
    flagging stale 'refresh' artifacts that must be re-fetched."""
    cur_root = {it["name"]: it for it in cloud.list_dir("current")}
    cur_updates = {it["name"]: it for it in cloud.list_dir("current", "updates")}
    cutoff = _load_archive_cutoff(cloud)

    print("=== Shiproom pre-meeting checklist ===")
    print(f"folder: {cloud.web_url('current')}")
    if cutoff:
        print(f"cutoff: {cutoff.astimezone().isoformat(timespec='minutes')}  (from current/.last-archive)")
    else:
        print("cutoff: this-week-Monday 00:00 UTC  (no current/.last-archive marker yet)")
    print()
    must_refresh: list[tuple[str, str]] = []   # (relpath, why)
    missing: list[tuple[str, str]] = []
    ok = 0
    stale_accumulate: list[tuple[str, str]] = []  # leftover from last cycle
    for relpath, parent, kind, hint in PREP_CHECKLIST:
        name = relpath.split("/")[-1]
        bag = cur_updates if parent.endswith("updates") else cur_root
        # Special-case the loop file: accept either currentloop.md or currentloop.pdf.
        if name == "currentloop.{md|pdf}":
            item = bag.get("currentloop.md") or bag.get("currentloop.pdf")
            display = ("currentloop.md" if bag.get("currentloop.md")
                       else ("currentloop.pdf" if bag.get("currentloop.pdf") else "currentloop.{md|pdf}"))
        else:
            item = bag.get(name)
            display = relpath
        if not item:
            missing.append((display, hint))
            print(f"  [MISS] {display:<40} ({kind:<10}) <- {hint}")
            continue
        size = item.get("size", 0)
        if display == "updates/2-data.md" and kind == "refresh":
            stale, info = _is_two_data_stale(item, cloud, cutoff=cutoff)
        else:
            stale, info = _is_stale(item, kind, cutoff=cutoff)
        if stale and kind == "accumulate":
            stale_accumulate.append((display, info))
            print(f"  [LEFT] {display:<40} ({kind:<10}) {size} B  ⚠️ {info} -- leftover from last cycle")
        elif stale:
            must_refresh.append((display, info))
            print(f"  [STALE]{display:<40} ({kind:<10}) {size} B  ⚠️ {info} -- re-fetch before meeting")
        else:
            ok += 1
            tag = info or "ok"
            print(f"  [OK]   {display:<40} ({kind:<10}) {size} B  {tag}")

    print()
    total = len(PREP_CHECKLIST)
    print(f"ready: {ok} / {total}    missing: {len(missing)}    stale: {len(must_refresh)}    leftover: {len(stale_accumulate)}")

    if stale_accumulate:
        if cutoff:
            print("\n📎 Carry-forward leftover files (expected right after /sr-archive):")
            for rel, why in stale_accumulate:
                print(f"  - {rel}  ({why})")
            print("\nThese files were carried forward from the previous cycle. They will NOT")
            print("appear in this cycle's view.html (render_view filters manual entries by the")
            print("cutoff above). Next steps for this meeting cycle:")
            print("  1. /sr-fetch-loop      → refreshes LOOP-SYNC blocks in 1/4/5/6/7-*.md")
            print("  2. /sr-fetch-ocv       → refreshes 3-ocv.md")
            print("  3. ask Claire for new 2-data.md (or upload-md if she sends markdown)")
            print("  4. team /sr-update entries land naturally as they happen")
            print("  5. /sr-prep            → regenerate prep summary + view.html")
            print("If you DID NOT just run /sr-archive, see archive.md before continuing —")
            print("the cutoff in current/.last-archive may be stale.")
        else:
            print("\n⚠️ Leftover team-update files from last cycle:")
            for rel, why in stale_accumulate:
                print(f"  - {rel}  ({why})")
            print("\nNo current/.last-archive marker found. Likely cause: last meeting was not")
            print("archived (or this is a legacy repo). Recommended fix:")
            print("  1. Pick the date of the last meeting, then run:")
            print("     python framework/scripts/cloud_cli.py archive <YYYY-MM-DD>")
            print("     (default = carry-forward; current/ keeps content. Add --clear to also wipe.)")
            print("  2. After archive, run fetch-loop / fetch-ocv / ask Claire for new 2-data.")
            print("  3. Re-run `cloud_cli.py prep` to confirm.")

    if missing or must_refresh:
        print("\nNext steps the agent MUST perform (in order):")
        for rel, why in must_refresh:
            print(f"  - REFRESH {rel}  ({why})")
        for rel, hint in missing:
            kind = next((k for r, _, k, _ in PREP_CHECKLIST if r == rel), "")
            print(f"  - FETCH   {rel}  [{kind}]  {hint}")
        print("\nDo not skip the REFRESH step even if a file with the same name already exists.")
    elif not stale_accumulate:
        print("\nAll prep artifacts present and fresh. Generate/refresh 0-meeting-prep-summary.md last.")
    return 0


def cmd_upload_md(args, cloud: ShiproomCloud) -> int:
    """Upload a local markdown file to a path under base.

    For files in AUTO_MERGED (e.g. current/updates/2-data.md), the local file
    is treated as an auto-source snapshot and is merged into the remote
    file's <!-- BEGIN LOOP-SYNC --> ... <!-- END LOOP-SYNC --> block instead
    of overwriting the whole file. This preserves any human /sr-update
    entries below the block.
    """
    local = Path(args.local)
    if not local.exists():
        print(f"ERROR: file not found: {local}", file=sys.stderr)
        return 2
    parts = [p for p in args.remote.split("/") if p]
    if not parts:
        print("ERROR: remote path is empty", file=sys.stderr)
        return 2

    rel = "/".join(parts)
    if rel in AUTO_MERGED:
        header, default_label = AUTO_MERGED[rel]
        body_md = local.read_text(encoding="utf-8")
        _merge_auto_into(
            cloud, body_md,
            parts=tuple(parts),
            header=header,
            source_label=f"manual upload: {local.name}",
            summary=f"{local.stat().st_size} B from {local.name}",
        )
        return 0

    res = cloud.upload_file(local, *parts)
    print(f"✅ Uploaded {local.name} → {args.remote}  ({local.stat().st_size} B)")
    print(f"   {res.get('webUrl', '')}")
    return 0


def cmd_read(args, cloud: ShiproomCloud) -> int:
    """Print contents of a cloud file to stdout (raw utf-8 bytes, LF preserved).

    NOTE: do NOT use shell redirection (`> file.md`) on Windows PowerShell -- it will
    re-encode the stream to UTF-16 and corrupt the file. Use the `download` subcommand
    instead when you want to save to disk.
    """
    parts = [p for p in args.remote.split("/") if p]
    if not parts:
        print("ERROR: remote path is empty", file=sys.stderr)
        return 2
    try:
        text = cloud.read_text(*parts)
    except Exception as exc:  # noqa: BLE001
        print(f"ERROR: could not read {args.remote}: {exc}", file=sys.stderr)
        return 1
    sys.stdout.buffer.write(text.encode("utf-8"))
    return 0


def cmd_download(args, cloud: ShiproomCloud) -> int:
    """Download a cloud file to a local path (binary-safe, no shell pipe involved)."""
    parts = [p for p in args.remote.split("/") if p]
    if not parts:
        print("ERROR: remote path is empty", file=sys.stderr)
        return 2
    local = Path(args.local)
    try:
        cloud.download_file(local, *parts)
    except Exception as exc:  # noqa: BLE001
        print(f"ERROR: could not download {args.remote}: {exc}", file=sys.stderr)
        return 1
    size = local.stat().st_size
    print(f"\u2705 Downloaded {args.remote} -> {local}  ({size} B)")
    return 0


def cmd_list_history(_args, cloud: ShiproomCloud) -> int:
    """List archived dates under history/."""
    items = cloud.list_dir("history")
    dirs = sorted([it["name"] for it in items if "folder" in it], reverse=True)
    if not dirs:
        print("(history/ is empty)")
        return 0
    print(f"=== History ({len(dirs)} entries) ===")
    for d in dirs:
        print(f"  {d}    {cloud.web_url('history', d)}")
    return 0


def _load_archive_cutoff(cloud: ShiproomCloud) -> Optional[dt.datetime]:
    """Read current/.last-archive ISO timestamp written by archive_current().

    Returns None if the marker is absent (first run / legacy repo) so callers
    fall back to their own default (e.g. this week's Monday).
    """
    raw = cloud.read_text("current", ".last-archive", default="").strip()
    if not raw:
        return None
    try:
        ts = dt.datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return None
    return ts


def _read_overlays(cloud: ShiproomCloud) -> dict:
    """Read current/overlay/<slug>.md into {slug: markdown} for the tree
    renderer's team-update overlay layer. Missing folder -> empty dict."""
    overlays: dict[str, str] = {}
    try:
        for item in cloud.list_dir("current", "overlay"):
            name = item.get("name", "")
            if name.endswith(".md"):
                overlays[name[:-3]] = cloud.read_text("current", "overlay", name, default="")
    except Exception:
        pass
    return overlays


def cmd_render_view(args, cloud: ShiproomCloud) -> int:
    """Render current/view.html with the hard-coded Shiproom dashboard template."""
    from render_view import SECTION_SOURCES, ViewInput, render_view, render_view_tree
    from loop_tree import has_outline

    cutoff = _load_archive_cutoff(cloud)
    loop_text = cloud.read_text("current", "currentloop.md", default="")
    missing = []

    if has_outline(loop_text):
        # New dynamic path: the Loop is the directory tree. Only Data + OCV are
        # injected from non-Loop sources.
        texts = {
            "loop": loop_text,
            "data": cloud.read_text("current", "updates", "2-data.md", default=""),
            "ocv": cloud.read_text("current", "updates", "3-ocv.md", default=""),
            "prep_summary": cloud.read_text("current", "updates", "0-meeting-prep-summary.md", default=""),
            "live_notes": cloud.read_text("current", "live-notes.md", default=""),
        }
        html_text = render_view_tree(ViewInput(texts=texts, archive_cutoff=cutoff, overlays=_read_overlays(cloud)))
    else:
        # Legacy path: fixed section files.
        texts = {}
        for key, remote in SECTION_SOURCES.items():
            parts = [p for p in remote.split("/") if p]
            text = cloud.read_text(*parts, default="")
            texts[key] = text
            if not text and key not in {"prep_summary", "loop", "live_notes"}:
                missing.append(remote)
        html_text = render_view(ViewInput(texts=texts, archive_cutoff=cutoff))

    res = cloud.write_text(html_text, "current", "view.html", content_type="text/html")

    if getattr(args, "local", None):
        local = Path(args.local)
        local.parent.mkdir(parents=True, exist_ok=True)
        local.write_text(html_text, encoding="utf-8")
        print(f"✅ Rendered local copy -> {local}  ({local.stat().st_size} B)")
    if missing:
        print("⚠️  Rendered with missing sections:")
        for remote in missing:
            print(f"   - {remote}")
    cutoff_msg = f" (manual entries since {cutoff.isoformat(timespec='minutes')})" if cutoff else " (no .last-archive — using this-week-Monday cutoff)"
    print(f"✅ Rendered hard-coded dashboard → current/view.html  ({len(html_text.encode('utf-8'))} B){cutoff_msg}")
    print(f"   {res.get('webUrl', cloud.web_url('current', 'view.html'))}")
    return 0


# ============================================================================
# fetch-ocv  (auto-refresh OCV snapshot for /sr-prep)
# ============================================================================


def cmd_fetch_ocv(args, cloud: ShiproomCloud) -> int:
    """Try to read the OCV xlsx via Graph and upload a markdown summary.
    Preferred source is a workbook path under the Shiproom SharePoint folder.
    Falls back to a share URL source for backward compatibility.
    """
    import yaml

    cfg_path = _resolve_config(args.config)
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    from cloud_io import _request
    ocv_cfg = cfg.get("ocv_source") or {}

    remote_path = (ocv_cfg.get("remote_path") or "").strip().strip("/")
    if not remote_path:
        print("ERROR: set ocv_source.remote_path in shiproom-config.yaml", file=sys.stderr)
        return 2

    parts = [p for p in remote_path.split("/") if p]
    r = _request("GET", cloud._item_url(*parts))
    if r.status_code == 404:
        print(f"ERROR: OCV workbook not found at {cloud.base_path}/{remote_path}", file=sys.stderr)
        print("Set ocv_source.remote_path to the correct file under Shiproom/.", file=sys.stderr)
        return 2
    r.raise_for_status()
    item = r.json()
    drive_id = cloud.drive_id
    item_id = item["id"]
    source_label = cloud.web_url(*parts) or f"{cloud.base_path}/{remote_path}"

    # List worksheets
    ws = _request("GET", f"https://graph.microsoft.com/v1.0/drives/{drive_id}/items/{item_id}/workbook/worksheets")
    ws.raise_for_status()
    sheets = [s["name"] for s in ws.json().get("value", [])]
    if not sheets:
        print("ERROR: OCV workbook has no sheets", file=sys.stderr)
        return 1

    pick = ((cfg.get("ocv_source") or {}).get("sheet_pick") or "last")
    if pick == "first":
        sheet = sheets[0]
    elif pick == "by_name":
        sheet = sorted(sheets)[-1]
    else:
        sheet = sheets[-1]

    # Read used range as values
    rng = _request("GET", f"https://graph.microsoft.com/v1.0/drives/{drive_id}/items/{item_id}/workbook/worksheets('{sheet}')/usedRange(valuesOnly=true)?$select=values,address")
    rng.raise_for_status()
    payload = rng.json()
    rows = payload.get("values") or []
    if not rows:
        print(f"ERROR: sheet '{sheet}' is empty", file=sys.stderr)
        return 1

    max_rows = int((cfg.get("ocv_source") or {}).get("max_rows", 30))
    header, *body = rows
    body = body[:max_rows]

    # Bug IDs are ADO work-item numbers; SharePoint's download strips the cell
    # hyperlinks, so rebuild a clickable link on the leading number from a config
    # template. Empty template => leave the text as-is.
    bug_tmpl = ((cfg.get("ocv_source") or {}).get("bug_url_template") or "").strip()
    _bug_re = re.compile(r"^(\s*)(\d{5,})(\b.*)$", re.S)

    def _linkify_bug(text: str) -> str:
        if not bug_tmpl:
            return text
        m = _bug_re.match(text)
        if not m:
            return text
        bid = m.group(2)
        url = bug_tmpl.replace("{id}", bid)
        return f"{m.group(1)}[{bid}]({url}){m.group(3)}"

    def _cell(v):
        if v is None or v == "":
            return ""
        s = str(v).replace("|", "\\|").replace("\n", " ")
        return _linkify_bug(s)

    md_lines = [
        f"# OCV snapshot — sheet `{sheet}` ({payload.get('address', '?')})",
        "",
        f"_Auto-fetched from {source_label}_",
        "",
        "| " + " | ".join(_cell(c) for c in header) + " |",
        "|" + "|".join(["---"] * len(header)) + "|",
    ]
    for row in body:
        md_lines.append("| " + " | ".join(_cell(c) for c in row) + " |")
    if len(rows) - 1 > max_rows:
        md_lines.append("")
        md_lines.append(f"_Truncated to first {max_rows} rows; full sheet has {len(rows) - 1} data rows._")

    import tempfile
    body = "\n".join(md_lines) + "\n"
    _merge_auto_into(cloud, body,
                     parts=("current", "updates", "3-ocv.md"),
                     header="# 3 \u2014 OCV\n",
                     source_label=source_label,
                     summary=f"sheet '{sheet}', {len(body)} rows")
    return 0


# ============================================================================
# Generic auto-sync merger (used by fetch-ocv, upload-md for protected files)
# ============================================================================

# Files where ANY auto-source upload (Claire's data report, OCV xlsx fetch)
# must NOT clobber human /sr-update entries. Auto content lives between
# <!-- BEGIN LOOP-SYNC --> ... <!-- END LOOP-SYNC --> markers; everything
# outside survives.
AUTO_MERGED = {
    "current/updates/2-data.md": ("# 2 \u2014 Data\n", "Claire's weekly usage-analysis report"),
    "current/updates/3-ocv.md":  ("# 3 \u2014 OCV\n",  "OCV xlsx via fetch-ocv"),
}


def _merge_auto_into(cloud: ShiproomCloud, body_md: str, *, parts: tuple,
                     header: str, source_label: str, summary: str = "") -> dict:
    """Wrap body_md in a LOOP-SYNC block and merge into the remote file at
    parts, preserving anything outside the markers (i.e. human /sr-update
    entries). Uploads and prints a confirmation."""
    from loop_split import BEGIN_MARK, END_MARK, merge_block
    ts = dt.datetime.now().astimezone().isoformat(timespec="seconds")
    block = (
        f"{BEGIN_MARK}\n"
        f"<!-- Auto-synced at {ts}. Do NOT edit between these markers --\n"
        f"     human /sr-update entries should go OUTSIDE this block; they will be preserved. -->\n"
        f"_Source: {source_label}_\n\n"
        f"{body_md.rstrip()}\n"
        f"{END_MARK}\n"
    )
    try:
        existing = cloud.read_text(*parts)
    except Exception:
        existing = ""
    new_text = merge_block(existing, block, header)
    import tempfile
    tmp = Path(tempfile.gettempdir()) / f"shiproom_auto_{parts[-1]}"
    tmp.write_text(new_text, encoding="utf-8")
    res = cloud.upload_file(tmp, *parts)
    rel = "/".join(parts)
    extra = f"  ({summary})" if summary else ""
    print(f"\u2705 Auto-synced \u2192 {rel}{extra}")
    print(f"   {res.get('webUrl', '')}")
    return res


# ============================================================================
# Argparse
# ============================================================================

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="cloud_cli.py", description=__doc__)
    p.add_argument("--config", type=Path, default=None,
                   help=f"Path to shiproom-config.yaml (default: {WORKSPACE_CONFIG} "
                        f"if present, else bundled {BUNDLED_CONFIG})")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("whoami", help="print signed-in identity")
    sub.add_parser("status", help="list current/ contents")

    u = sub.add_parser("update", help="append signed entry to current/updates/<section>.md")
    u.add_argument("section", help="e.g. 1-todo, 2-data, 3-ocv, 4-release")
    u.add_argument("text", nargs="+", help="update body (joined with spaces)")

    ov = sub.add_parser("overlay", help="append signed team update to a Loop node's overlay (current/overlay/<slug>.md)")
    ov.add_argument("node", help="Loop node slug or title fragment, e.g. consumer-release-status or showcase")
    ov.add_argument("text", nargs="+", help="update body (joined with spaces)")

    n = sub.add_parser("notes", help="append signed line to current/notes.md")
    n.add_argument("text", nargs="+")

    ul = sub.add_parser("upload-loop", help="upload <pdf> as current/currentloop.pdf")
    ul.add_argument("path")

    un = sub.add_parser("upload-notes", help="upload <pdf> as current/notes.pdf")
    un.add_argument("path")

    a = sub.add_parser("archive", help="copy current/ → history/<date>/ (default: carry-forward; use --clear to also wipe current/)")
    a.add_argument("date", nargs="?", default=None, help="YYYY-MM-DD (default: today)")
    a.add_argument("--clear", action="store_true", help="legacy: also delete contents of current/ after copy. Default: carry-forward (current/ untouched).")

    url = sub.add_parser("url", help="print SharePoint web URL of a file/folder")
    url.add_argument("path", nargs="?", default="")

    sub.add_parser("prep", help="show pre-meeting checklist (what's missing in current/)")

    um = sub.add_parser("upload-md", help="upload local markdown to <remote-path-under-base>")
    um.add_argument("local", help="local file path")
    um.add_argument("remote", help="cloud path under base, e.g. current/updates/2-data.md")

    rd = sub.add_parser("read", help="print a cloud file to stdout")
    rd.add_argument("remote", help="cloud path under base, e.g. current/notes.md or history/2026-05-08/notes.md")

    dl = sub.add_parser("download", help="download a cloud file to a local path (binary-safe)")
    dl.add_argument("remote", help="cloud path under base")
    dl.add_argument("local", help="local destination path")

    sub.add_parser("list-history", help="list archived meeting dates under history/")

    rv = sub.add_parser("render-view", help="render current/view.html with the hard-coded dashboard template")
    rv.add_argument("--local", default="./view.html", help="optional local preview path (default: ./view.html)")

    sub.add_parser("fetch-ocv", help="build current/updates/3-ocv.md from the OCV xlsx (Graph)")
    fl = sub.add_parser("fetch-loop", help="auto-fetch Current Loop -> current/currentloop.md (headless Chrome)")
    fl.add_argument("--interactive", action="store_true", help="force a visible browser and wait for ENTER before capture")
    fn = sub.add_parser("fetch-notes", help="auto-fetch latest meeting-notes Loop from Teams chat -> current/notes.md")
    fn.add_argument("--n", type=int, default=1, help="how many recent meetings to consider (default: 1, fetch only the latest)")
    fn.add_argument("--interactive", action="store_true", help="force a visible browser (skip silent attempt)")
    sub.add_parser("split-loop", help="re-run loop section splitter on the existing current/currentloop.md")

    return p


HANDLERS = {
    "whoami": cmd_whoami,
    "status": cmd_status,
    "update": cmd_update,
    "overlay": cmd_overlay,
    "notes": cmd_notes,
    "upload-loop": cmd_upload_loop,
    "upload-notes": cmd_upload_notes,
    "archive": cmd_archive,
    "url": cmd_url,
    "prep": cmd_prep,
    "upload-md": cmd_upload_md,
    "read": cmd_read,
    "download": cmd_download,
    "list-history": cmd_list_history,
    "render-view": cmd_render_view,
    "fetch-ocv": cmd_fetch_ocv,
    "fetch-loop": cmd_fetch_loop,
    "fetch-notes": cmd_fetch_notes,
    "split-loop": cmd_split_loop,
}


def _force_utf8_stdio() -> None:
    """Windows consoles default to a legacy code page (cp1252 / cp936), so
    printing the CLI's ✅ / emoji / CJK status lines raises UnicodeEncodeError
    and makes a successful write look like a crash. Force UTF-8 on stdout/stderr.
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def main(argv=None) -> int:
    _force_utf8_stdio()
    _maybe_self_update()
    args = build_parser().parse_args(argv)
    cfg_path = _resolve_config(args.config)
    if args.cmd != "whoami" and not cfg_path.exists():
        print(f"ERROR: config not found: {cfg_path}", file=sys.stderr)
        return 2
    cloud = _load_cloud(cfg_path) if args.cmd != "whoami" else None
    handler = HANDLERS[args.cmd]
    return handler(args, cloud)


if __name__ == "__main__":
    sys.exit(main())
