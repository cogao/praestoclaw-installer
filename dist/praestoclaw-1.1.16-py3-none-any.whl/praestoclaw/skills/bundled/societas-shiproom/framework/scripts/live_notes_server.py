"""Local HTTP bridge for Shiproom live notes.

view.html is static and cannot safely write to SharePoint directly. This server
runs on localhost, receives notes from the dashboard, and writes them to
current/live-notes.md via the existing MSAL/Graph SharePoint backend.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

THIS = Path(__file__).resolve()
sys.path.insert(0, str(THIS.parent))

from cloud_cli import BUNDLED_CONFIG, WORKSPACE_CONFIG, _load_cloud  # noqa: E402
from cloud_io import short_name  # noqa: E402

SECTION_LABELS = {
    "todo": "0. Todo",
    "data": "Data",
    "ocv": "OCV",
    "release": "Release",
    "security": "Security Bug",
    "productivity": "10x Productivity Research",
    "showcase": "Showcase",
    "capabilities": "Capabilities",
    "foundation": "Foundation",
}


def resolve_config(explicit: Path | None) -> Path:
    if explicit is not None:
        return explicit
    return BUNDLED_CONFIG


def append_live_note(cloud, section: str, text: str) -> dict:
    section = (section or "general").strip()
    label = SECTION_LABELS.get(section, section)
    body = (text or "").strip()
    if not body:
        raise ValueError("note text is empty")
    ts = dt.datetime.now().astimezone().isoformat(timespec="seconds")
    entry = f"## {label}\n\n### @{short_name()} · {ts}\n\n{body}\n"
    return cloud.append_text(entry, "current", "live-notes.md", ensure_header="# Live Shiproom Notes\n")


class Handler(BaseHTTPRequestHandler):
    server_version = "ShiproomLiveNotes/0.1"

    def _send_json(self, status: int, payload: dict) -> None:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(raw)

    def do_OPTIONS(self) -> None:  # noqa: N802
        self._send_json(204, {})

    def do_GET(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path == "/health":
            self._send_json(200, {"ok": True})
            return
        if path == "/notes":
            text = self.server.cloud.read_text("current", "live-notes.md", default="# Live Shiproom Notes\n")
            self._send_json(200, {"ok": True, "text": text})
            return
        self._send_json(404, {"ok": False, "error": "not found"})

    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path != "/notes":
            self._send_json(404, {"ok": False, "error": "not found"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            res = append_live_note(self.server.cloud, payload.get("section", "general"), payload.get("text", ""))
            self._send_json(200, {"ok": True, "webUrl": res.get("webUrl", "")})
        except Exception as exc:  # noqa: BLE001
            self._send_json(400, {"ok": False, "error": str(exc)})

    def log_message(self, fmt: str, *args) -> None:
        print(f"[{dt.datetime.now().isoformat(timespec='seconds')}] {self.address_string()} {fmt % args}")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Local SharePoint bridge for Shiproom live notes")
    parser.add_argument("--config", type=Path, default=None)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args(argv)

    cloud = _load_cloud(resolve_config(args.config))
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    server.cloud = cloud  # type: ignore[attr-defined]
    print(f"Shiproom live notes server listening at http://{args.host}:{args.port}")
    print("Open view.html and use each section's Live notes box to sync notes to current/live-notes.md.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Stopping live notes server.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
