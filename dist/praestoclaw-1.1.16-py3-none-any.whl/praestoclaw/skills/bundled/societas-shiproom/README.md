# Societas Shiproom — 使用指南

一个 skill，扔进任意 IDE 就能跑团队每周的 shiproom。所有数据都在共享的 SharePoint 文件夹里，不用本地存数据，也不会因为每个人配置不同而走样。

## 它能做什么

- **会前**：团队任何成员用 `/sr-update <节点> <内容>` 给 Loop 里某个节点加一条团队补充（写到 overlay，**不动 Loop 本身**）；host 用 `/sr-prep` 拓最新 Loop + 数据/OCV 快照，生成 `view.html`。
- **会中**：用 `/sr-notes` 实时记录决策，自动签上你的名字。
- **会后**：host 用 `/sr-archive` 先从 Teams meeting/chat 抓最新 notes，再把 `current/` 归档到 `history/<日期>/` 并清空，准备下一周。
- **任何时候**：用 `/sr-ask` 提问，agent 会从 `current/` 和 `history/*/` 里翻答案。

> **核心理念：Loop 就是议程目录。** dashboard 直接按 Loop 的标题结构（字号 = 大纲层级）动态生成，**零硬编码关键词**。你改 Loop 的结构，dashboard 自动跟着变。整个流程里只有两个不是 Loop 产的文档：**Data**（Claire 上传）和 **OCV**（fetch-ocv 抓），它们被注入到 Loop 对应节点。

所有数据都存在这里：[Societas / Shiproom channel / Files / Shiproom/](https://microsoftapc.sharepoint.com/teams/Societas/Shared%20Documents/Shiproom)

## 首次设置（每个人一次就够）

1. **把 `societas-shiproom/` 文件夹放进 IDE 的 skill 目录**。不需要 `git clone`，拷贝过去就行。位置取决于 IDE：
   - **Claude Code / Cursor**：`~/.claude/skills/societas-shiproom/`（用户级）或 `<项目>/.claude/skills/societas-shiproom/`（项目级）
   - **GitHub Copilot (VS Code)**：放在 workspace 的任何位置，agent 会从 `SKILL.md` 的 frontmatter 识别它
   - **其他 IDE**：按各自的 skill 加载约定
2. 装一次 Python 依赖：
   ```bash
   pip install -r societas-shiproom/framework/scripts/requirements.txt
   ```
3. 登录一次：
   ```bash
   python societas-shiproom/framework/scripts/cloud_cli.py whoami
   ```
   会弹一个微软登录窗，用你的 `@microsoft.com` 工作账号。后续运行全部静默。
4. 确认你是 Societas Teams team 的成员。如果 403，去 channel 里找 owner 拉你进去。

## 已安装用户如何升级到“默认自动更新”

从现在开始，`cloud_cli.py` 会在每次运行前尝试安全自更新（仅在 skill 目录位于 git 仓库时生效，且只做 fast-forward，不会覆盖本地改动）。

如果你之前是直接拷贝文件夹安装，请做一次性迁移：

1. 用 git clone 这个仓库到本地任意固定位置。
2. IDE 里把 skill 路径指向 clone 后的 `societas-shiproom/` 目录（不是仓库根目录）。
3. 跑一次：
   ```bash
   python <your-clone>/societas-shiproom/framework/scripts/cloud_cli.py whoami
   ```

之后就不需要手动更新 skill 了：每次跑任意 `/sr-*` 对应命令时会自动检查并拉取最新版本。

### 已经是 git 安装的用户

如果你的 skill 本来就在 git 仓库里，直接保持现状即可。需要立即刷新时，手动执行一次：

```bash
git -C <your-clone-root> pull --ff-only origin main
```

### 临时关闭自动更新（排查问题时）

可设置环境变量：`SR_DISABLE_SELF_UPDATE=1`

## 常见场景

### 作为团队成员，会前

> “我要给 todo 加一条：VFS bug 修好了，alice 负责，周三上线。”

Agent 会把它当作一条**团队补充**挂到 Loop 里最匹配的节点（比如 Action Items），调 `cloud_cli overlay <节点> "..."` 写到 `current/overlay/<节点slug>.md`，签上 `@<你的 handle>`。渲染时它会显在该 section 下方的绿色「团队补充」块里。**Loop 本身不被改动**。

### 作为 host，会前

> “帮我准备一下 shiproom。”

Agent 会走一遍 checklist（详见 [`framework/rules/prep.md`](framework/rules/prep.md)）：
1. 自动抓最新 Loop（`cloud_cli fetch-loop`，静默 headless）。抓取时给每个标题打上层级标记 `[SR_H:<px>]`、把嵌入图片截图内嵌。**不再按关键词拆 section**——Loop 的标题结构本身就是议程目录。失败时弹可见窗口让你 SSO；再不行把 Loop URL 给你导出 PDF 后 `/sr-upload-loop`。
2. 提醒你：Claire 应该已经上传了 `2-data.md`；如果没传或太旧会 ping 一下。
3. 自动重抓 OCV（`cloud_cli fetch-ocv` → `3-ocv.md`）。`2-data.md` 和 `3-ocv.md` 是**仅有的两个非 Loop 文档**，会被注入到 Loop 的 “Business Metrics” / “Customer Voice - OCV” 节点。
4. 生成会前总结（`0-meeting-prep-summary.md`，给各节点提供 intro）。
5. 用 `cloud_cli render-view` **直接把 Loop 大纲渲染成 `view.html`**（动态树、零关键词），Data/OCV 注入、团队 overlay 挂在各节点下。Agent 给你一条 SharePoint 链接，并下载一份本地预览。

### 任何人，会中或会后

> “Notes: 决策——保留两个 branch 满足 compliance。”

Agent 调 `cloud_cli notes "..."`，自动签上你的 @handle。

### 作为 host，会后

> “把这周归档了。”

Agent 会走完会后收尾流程（详见 [`framework/rules/archive.md`](framework/rules/archive.md)）：
1. 跑 `cloud_cli status` 看 `current/` 里什么趋势。
2. 从 Teams 群里自动抓最新会议 notes 的 Loop（`cloud_cli fetch-notes`）。和 `fetch-loop` 同一套三层 fallback：静默 → 可见窗口 SSO → 手动 PDF 上传 `/sr-upload-notes`。
3. 问你要不要补一个总结性的 `/sr-notes`。
4. 确认归档日期，再推次确认（这个操作会清空 current/），然后跑 `cloud_cli archive`。`current/` → `history/<日期>/`，然后 `current/` 被清空。

### 任何人，任何时候

> “上个月关于 enterprise compliance 我们决定了什么？”

Agent 跑 `cloud_cli list-history`，挑 1–3 个可能的日期，读其 `notes.md` 和 `updates/*.md`，总结出答案并带上 SharePoint 链接引用。

## 文件与目录结构

整个 `Shiproom/` 就两部分：

- **`current/`** —— 本周正在跑的内容
- **`history/<日期>/`** —— 每次 `/sr-archive` 把 `current/` 整个拷贝过来的一份存档（结构和 `current/` 一模一样）

`current/` 内部长这样：

```
current/
├── currentloop.md         /sr-fetch-loop 抓取(含 [SR_H:<px>] 标题层级标记 + 内嵌图片)
├── currentloop.pdf        抓取失败时 host 兜底上传的 PDF
├── notes.md               /sr-fetch-notes 自动抓 + 任何人 /sr-notes 追加
├── notes.pdf              抓取失败时 host 兜底上传的 PDF
├── view.html              /sr-prep 用 render-view 从 Loop 大纲动态生成的 dashboard
├── updates/               仅有的两个非 Loop 文档 + 会前总结
│   ├── 0-meeting-prep-summary.md   agent 在 /sr-prep 生成(给各节点 intro)
│   ├── 2-data.md                   Claire 每周上传的数据快照 → 注入 Loop 的 Business Metrics 节点
│   └── 3-ocv.md                    /sr-fetch-ocv 抓的 OCV 表 → 注入 Loop 的 Customer Voice / OCV 节点
└── overlay/               团队 /sr-update 的人工补充,按 Loop 节点标题挂
    └── <节点slug>.md       例:1-showcase.md、3-consumer-release-status.md …
```

**结构来自 Loop 本身。** `render-view` 读 `currentloop.md`,按标题字号还原出大纲树,直接渲染——不再有 `1-todo`…`9-*` 那套固定 section 文件,也没有关键词切片。`2-data` / `3-ocv` 是仅有的两个外部数据,注入到对应 Loop 节点;团队 `/sr-update` 写进 `overlay/<节点>.md`,渲染时挂在该节点下方的绿色「团队补充」块里。

> 兼容性:`currentloop.md` 若没有 `[SR_H:]` 标记(旧版抓取),`render-view` 会回退到老的固定 section 文件路径。

## 故障排查

- **MSAL 窗口反复弹** — token 缓存在 `%LOCALAPPDATA%\.IdentityService\msal.cache.bin3`，删掉重新登录。
- **SharePoint 返回 403** — 你不是 Societas team 成员，去 channel 里说一声让 owner 拉你进去。
- **`/sr-fetch-loop` 或 `/sr-fetch-notes` 弹出可见浏览器** — 这台机器首次 SSO，或者是你第一次访问某个组织者的 OneDrive。登录 / 同意 “request access” 后回 terminal 按 ENTER。后续运行静默。
- **连可见浏览器都失败** — 脚本会在 stderr 打出 Loop URL。手动打开 → `Print & PDF export` → 保存 PDF → `/sr-upload-loop <pdf>` 或 `/sr-upload-notes <pdf>`。Agent 会接手后续。
- **PowerShell 把文件转乱了** — Windows 上千万别用 `cloud_cli read ... > file.md`这种重定向，它会重编码为 UTF-16。请用 `cloud_cli download <remote> <local>`。

## 参考

- 斜杠命令定义 → [AGENT.md](./AGENT.md)
- 各命令 playbook（update / prep / archive / ask）→ [framework/rules/](./framework/rules/)
- 权限与安全约定 → [PERMISSIONS.md](./PERMISSIONS.md)
- Workspace 配置 → [shiproom-config.yaml](./shiproom-config.yaml)
