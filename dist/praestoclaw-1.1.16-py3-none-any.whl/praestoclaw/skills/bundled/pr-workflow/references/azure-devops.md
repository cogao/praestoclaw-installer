# Azure DevOps Provider Reference

Read this for Azure DevOps PR creation, policies, statuses, pipeline/build logs,
comments, review threads, and work-item linkage.

## Establish

Use `az` with the Azure DevOps extension. Resolve these values from the remote
URL or ask if parsing is ambiguous:

```text
ORG_URL=https://dev.azure.com/<organization>
PROJECT=<project>
REPO=<repository name>
```

Handle common Azure Repos remote shapes before asking:

```text
https://dev.azure.com/<org>/<project>/_git/<repo>
https://<org>@dev.azure.com/<org>/<project>/_git/<repo>
git@ssh.dev.azure.com:v3/<org>/<project>/<repo>
https://<org>.visualstudio.com/<project>/_git/<repo>
```

URL-decode `<project>` and `<repo>` from the remote. For REST `curl` URLs,
URL-encode `PROJECT`:

```bash
PYTHON="${PYTHON:-python3}"
PROJECT_ENCODED="$("$PYTHON" -c 'import sys, urllib.parse; print(urllib.parse.quote(sys.argv[1], safe=""))' "$PROJECT")"
```

Then:

```bash
az repos show --repository "$REPO" --org "$ORG_URL" --project "$PROJECT" -o json
REPO_ID="$(az repos show --repository "$REPO" --org "$ORG_URL" --project "$PROJECT" --query id -o tsv)"
BRANCH="$(git branch --show-current)"
az repos pr list --source-branch "$BRANCH" --status active --repository "$REPO" --org "$ORG_URL" --project "$PROJECT" -o json
```

If the Azure DevOps extension or authentication is missing, stop with the exact
error and ask the user to authenticate or install the extension.

Do not silently mutate global Azure DevOps CLI defaults. Prefer explicit
`--org`, `--project`, and `--detect true` flags. If a subcommand cannot accept
`--project` and detection fails, tell the user which default is missing before
running `az devops configure --defaults`.

For REST calls, create one auth header and reuse it. Support both PAT and Entra
auth without printing tokens:

```bash
if [ -n "${AZURE_DEVOPS_EXT_PAT:-}" ]; then
  AZDO_B64=$(printf ':%s' "$AZURE_DEVOPS_EXT_PAT" | base64 | tr -d '\n')
  AZDO_AUTH_HEADER="Authorization: Basic $AZDO_B64"
else
  AZDO_TOKEN=$(az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798 --query accessToken -o tsv)
  AZDO_AUTH_HEADER="Authorization: Bearer $AZDO_TOKEN"
fi
```

## Create Or Update PR

Create:

```bash
az repos pr create \
  --source-branch "$BRANCH" \
  --target-branch "$BASE_BRANCH" \
  --title "$TITLE" \
  --description "$BODY" \
  --repository "$REPO" \
  --org "$ORG_URL" \
  --project "$PROJECT" \
  -o json
```

Show or update:

```bash
az repos pr show --id "$PR" --org "$ORG_URL" --detect true -o json
az repos pr update --id "$PR" --title "$TITLE" --description "$BODY" --org "$ORG_URL" --detect true -o json
```

Link work items when requested:

```bash
az repos pr work-item add --id "$PR" --work-items "$WORK_ITEM_ID" --org "$ORG_URL" --detect true
az repos pr work-item list --id "$PR" --org "$ORG_URL" --detect true -o json
```

Reviewers:

```bash
az repos pr reviewer list --id "$PR" --org "$ORG_URL" --detect true -o json
az repos pr reviewer add --id "$PR" --reviewers "<user-or-group>" --org "$ORG_URL" --detect true
```

## CI, Policies, And Statuses

Start with branch policies because they are the merge gate:

```bash
az repos pr policy list --id "$PR" --org "$ORG_URL" --detect true -o json
az repos pr show --id "$PR" --org "$ORG_URL" --detect true --query "{status:status,mergeStatus:mergeStatus,isDraft:isDraft}" -o json
```

Fetch PR statuses through the Git REST API:

```bash
curl -fsS -H "$AZDO_AUTH_HEADER" \
  "$ORG_URL/$PROJECT_ENCODED/_apis/git/repositories/$REPO_ID/pullRequests/$PR/statuses?api-version=7.1"
```

Correlate failing build or pipeline statuses to runs:

```bash
az pipelines runs list --org "$ORG_URL" --project "$PROJECT" --branch "$BRANCH" --top 20 -o json
az pipelines runs show --org "$ORG_URL" --project "$PROJECT" --id "$RUN_ID" -o json
```

For build logs, use the Build REST API when the run maps to a build id:

```bash
curl -fsS -H "$AZDO_AUTH_HEADER" \
  "$ORG_URL/$PROJECT_ENCODED/_apis/build/builds/$RUN_ID/logs?api-version=7.1"
curl -fsS -H "$AZDO_AUTH_HEADER" \
  "$ORG_URL/$PROJECT_ENCODED/_apis/build/builds/$RUN_ID/logs/$LOG_ID?api-version=7.1"
```

After each pushed fix, start a fresh monitor round with the commands above; do
not reuse stale policy, status, or thread state from before the push.

## Comments And Threads

List threads:

```bash
curl -fsS -H "$AZDO_AUTH_HEADER" \
  "$ORG_URL/$PROJECT_ENCODED/_apis/git/repositories/$REPO_ID/pullRequests/$PR/threads?api-version=7.1"
```

Treat active, non-closed threads as unresolved unless the payload clearly marks
them obsolete or fixed. For each actionable thread, read the referenced file and
surrounding code before deciding.

Reply to a thread:

```bash
curl -fsS -X POST \
  -H "$AZDO_AUTH_HEADER" \
  -H "Content-Type: application/json" \
  -d '{"content":"<reply>","commentType":"text"}' \
  "$ORG_URL/$PROJECT_ENCODED/_apis/git/repositories/$REPO_ID/pullRequests/$PR/threads/$THREAD_ID/comments?api-version=7.1"
```

Close or resolve a thread only after the fix is pushed or the response is
sufficient:

```bash
curl -fsS -X PATCH \
  -H "$AZDO_AUTH_HEADER" \
  -H "Content-Type: application/json" \
  -d '{"status":"fixed"}' \
  "$ORG_URL/$PROJECT_ENCODED/_apis/git/repositories/$REPO_ID/pullRequests/$PR/threads/$THREAD_ID?api-version=7.1"
```

Use `fixed` after a code fix. Use `wontFix` or `byDesign` only when the reply
explains why the requested change is intentionally not made. Use `closed` for
non-actionable administrative closure. If a project uses a different Azure
thread status convention, follow the payload schema and prefer the platform's
current value set over guessing.

Do not leave handled threads active. After patching the thread status, re-fetch
threads and verify the handled thread no longer appears active/non-closed. If it
still appears unresolved, continue handling it before the completion audit.

For comment- or gate-driven fixes, follow the shared decision policy in
`SKILL.md`; keep this provider reference focused on live Azure DevOps state and
commands.

## Completion Audit

```bash
az repos pr show --id "$PR" --org "$ORG_URL" --detect true -o json
az repos pr policy list --id "$PR" --org "$ORG_URL" --detect true -o json
```

Re-fetch statuses and threads through REST. Prove required policies/statuses are
green, every handled thread is fixed, closed, `wontFix`, or `byDesign`, and no
unresolved actionable thread remains.
