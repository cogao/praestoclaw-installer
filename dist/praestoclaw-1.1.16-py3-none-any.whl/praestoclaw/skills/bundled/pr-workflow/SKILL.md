---
name: pr-workflow
description: End-to-end PR and pull request delivery workflow for GitHub and Azure DevOps. Use when the user asks to create, open, raise, update, or follow through a PR/pull request for current changes, local changes, staged changes, this change, this work, or a repository path, including Chinese requests such as "为本次改动创建 PR", "创建 PR", "开 PR", "提 PR", "发起 PR", "提交并创建 PR", "push 后建 PR", "创建 pull request", or "跟进 PR". Also use when asked to commit staged changes, push a branch, choose or remember the PR target/base branch, monitor CI or PR policies, inspect or fix review comments, resolve threads, link GitHub issues or Azure work items, or finish only after the PR is green and review feedback is handled.
metadata:
  activation:
    keywords: [pull request, 创建 PR, 开 PR, 提 PR, 发起 PR, pr-workflow, create PR]
    patterns:
      - "(?i)\\b(create|open|raise|update)\\b.*\\b(PR|pull request)\\b"
      - "(?i)\\b(为|给|把).*(创建|开|提|发起).*PR\\b"
  workflow:
    phases: [commit, push, create_pr, monitor, handle_comments, audit]
    requires_user_confirm: [create_pr]
    max_turns: 200
---

# PR Workflow

Drive a PR from local changes to a verified green state.

## Load Order

Always read only the reference files needed for the current provider and task:

- Read [references/git-and-config.md](references/git-and-config.md) before
  committing, pushing, or resolving the project default target branch.
- For GitHub remotes, read [references/github.md](references/github.md).
- For Azure DevOps remotes, read
  [references/azure-devops.md](references/azure-devops.md).
- If the repo has local PR instructions, read them too. Discover them from the
  current repository instead of assuming a GitHub layout. Prefer this order:
  agent instruction files, contribution docs, PR templates, repo-local PR or
  review skills, then provider workflow files only when gate metadata or failed
  jobs require them.

When a command needs bundled files, set:

```bash
SKILL_DIR=<absolute path to this pr-workflow skill directory>
```

Use the actual loaded skill path for `SKILL_DIR`; do not assume this skill lives
under any repository-specific skill directory.

## Core Rules

- Use live platform state as the source of truth. Never infer PR, CI, policy, or
  comment state from memory.
- Do not include untracked or unstaged user files in the initial commit unless
  the user explicitly asks.
- For the initial user-provided change, inspect the staged diff and commit only
  what is already staged. If nothing is staged and there is no existing PR to
  work on, stop and ask the user to stage files or clarify the PR.
- For CI or review fixes made by this workflow, stage only files you edited in
  that iteration after inspecting the diff.
- Do not use `--no-verify` unless the user explicitly chooses to bypass hooks
  after seeing the hook error.
- For new PR branches, use `users/<alias>/<short-change-name>` unless the user
  explicitly supplied the source branch name for this invocation. Do not create
  generated branches such as `feat/...`, `fix/...`, `chore/...`, or `pr/...`.
- Critically evaluate comments. Fix real issues; answer stale or incorrect
  comments with evidence.
- Do not resolve review threads before the relevant fix is pushed or the reply
  is sufficient.
- Do not leave handled review threads unresolved. After a fix is pushed or a
  reply sufficiently explains why no fix is needed, resolve or close the
  provider thread when the platform supports it. For PR-level comments without a
  resolvable thread, reply with the handling decision and verify it during the
  completion audit.
- After creating or updating a PR, immediately monitor live CI/policy and review
  state. Do not stop with "CI is still running; tell me if it fails."
- Do not mark the workflow complete while required checks or policies are
  queued, pending, running, or unknown.
- Do not merge unless the user explicitly asks, repo automation merges it, or
  the current objective explicitly includes merging.

## Shared Workflow

### 1. Select Repository

Before running git or provider commands, determine the working repository:

1. If the user specified a repository path for this invocation, `cd` there and
   verify it is inside a git worktree with `git rev-parse --show-toplevel`.
2. If the user did not specify a repository, run
   `git rev-parse --show-toplevel` in the current directory.
3. If that command fails, pause and ask the user which repository to use. Do not
   guess from nearby directories, recent memory, open files, or remote state.
4. If the user did specify a path but it is not a git worktree, stop and ask for
   a valid repository path.

Use the resolved repository root as `REPO_ROOT` and run the rest of the workflow
from that worktree.

### 2. Establish Local State

Run:

```bash
git status --short --branch
git remote -v
git branch --show-current
git rev-parse --show-toplevel
```

Resolve the remote before detecting the provider:

1. Use the remote configured as the current branch upstream.
2. If there is no upstream and the user specified a remote, use that remote.
3. If there is exactly one obvious push remote such as `origin`, use it.
4. If multiple remotes could be used, ask the user which remote to use.

Use the resolved remote as `REMOTE`. Detect the provider from `REMOTE`:

- GitHub: remote URL contains `github.com`, or `gh repo view` succeeds for the
  selected remote.
- Azure DevOps: remote URL contains `dev.azure.com` or `visualstudio.com`.
- If ambiguous, ask the user which provider to use before running provider
  commands.

Use these variable names consistently:

```text
PROVIDER=github|azure
REMOTE=<git remote used for push and provider detection>
BRANCH=<current branch>
BASE_BRANCH=<target branch for the PR>
PR=<pull request number/id>
```

### 3. Resolve Target Branch

Resolve the PR target/base branch in this order:

1. Use the branch explicitly named by the user for this invocation.
2. Use this project's saved default from `~/.pr-workflow/config.json` under the
   `branches` section.
3. If no branch was explicitly named and no saved default exists, ask: "What
   target/base branch should PRs from this project use by default?" Then save
   the answer before creating the PR.

Use `scripts/target_branch.py` from the git/config reference to read and write
the project default. Store target branches by project name. Never store tokens,
PR bodies, comments, or secrets under `~/.pr-workflow`.

Do not overwrite the saved default just because the user gives a one-off branch.
Only update it when the user says to remember or change the default.

### 4. Commit And Push

Follow [references/git-and-config.md](references/git-and-config.md):

- Enforce the source branch naming rule unless the user supplied a source branch
  name for this invocation. A branch name generated by the agent is not
  user-supplied.
- Inspect staged changes with `git status` and `git diff --staged`.
- Use English Conventional Commits.
- Handle hook failures by asking the user whether to fix or explicitly bypass.
- Push with the provider-appropriate command.

After pushing, verify:

```bash
git status --short --branch
git log -1 --oneline --decorate
```

### 5. Create Or Update PR

Use the provider reference for live commands:

- GitHub: [references/github.md](references/github.md)
- Azure DevOps: [references/azure-devops.md](references/azure-devops.md)

Create a PR if none exists for the branch. Otherwise update or continue the
existing PR. Link GitHub issues or Azure work items only when requested or when
repo-local instructions require it.

For repos with PR-title lint, align the PR title with the commit title unless
the repo policy says otherwise.

After creating or updating the PR, immediately enter the monitor loop in the
next step. Do not end the turn after reporting the PR URL when checks, policies,
reviews, or review threads are still pending.

### 6. Monitor Gates

Use provider-native gates:

- GitHub: checks, merge state, review decision, status rollup, and review
  threads.
- Azure DevOps: PR policies, PR statuses, pipeline/build runs, merge status, and
  discussion threads.

For failures, inspect exact job logs before editing. Classify the failure as
code regression, lint/type/style, PR metadata, policy/configuration, flake, or
infrastructure.

Keep polling live provider state until one of these terminal conditions occurs:

- Required checks or policies are green and review/comment state has no
  unresolved actionable feedback.
- A check, policy, or review item fails and a small fix can be applied; fix it,
  validate, commit, push, and restart this monitor loop from live state.
- A correct failure or comment requires a large fix; pause and ask for approval
  with the root cause, proposed files, risk, and validation plan.
- The provider reports a persistent authentication, rate-limit, or service
  outage that prevents further monitoring; report the blocker with the last
  successful live state.

When gates are queued, pending, running, or unknown, wait a reasonable interval
and poll again. Do not ask the user to come back if a check later fails.

### 7. Handle Comments

Inspect PR-level comments, inline comments, reviews, and unresolved threads. For
each unresolved, non-obsolete comment or failing CI/policy gate:

1. Read the referenced file and surrounding code.
2. Decide whether it is correct, partially correct, stale, or wrong.
3. Estimate fix size before editing.
4. If correct and small, patch the root cause directly.
5. If correct but large, pause and ask for approval before editing.
6. If wrong or intentionally not addressed, reply with concise evidence.
7. Run the smallest meaningful local validation.
8. Stage only workflow-owned edits, commit, and push any code or metadata fix.
9. Resolve or close the provider thread after the pushed fix or sufficient
   reply. For PR-level comments that cannot be resolved, leave a reply and
   treat the item as answered only after re-fetching it.
10. Start a fresh monitor round from live provider state and verify the handled
   thread no longer appears as unresolved.

Treat a fix as large when it requires broad refactoring, public API or schema
changes, dependency or lockfile changes, changes across several unrelated
modules, risky behavior changes outside the reviewed surface, or enough files
that the blast radius is no longer obvious. For a large fix, summarize the root
cause, proposed approach, expected files, risk, and validation plan, then wait
for user approval. If the fix is small and localized, do not stop for approval.

### 8. Completion Audit

Before stopping, prove current state:

- Local branch is clean except unrelated user-owned files explicitly left alone.
- Latest commit exists locally and on remote.
- PR exists against the resolved `BASE_BRANCH`.
- Requested issue or Azure work-item linkage is present.
- Required GitHub checks or Azure policies/statuses are green, or the PR is
  already merged with successful gates.
- Human or bot comments and review threads have no unresolved actionable
  feedback; every handled review thread is resolved or closed, and every
  handled PR-level comment without a resolve action has an explicit reply.

Final response should report: provider, PR URL/id, commit, target branch, CI or
policy state, comment/thread state, issue/work-item linkage, and unrelated local
files left untouched.
