"""Meeting-aware task-group automation."""

from praestoclaw.meeting_automation.models import (
    MeetingOccurrence,
    MeetingTaskGroupInstance,
    MeetingTaskGroupTemplate,
    RoutingContext,
    TaskGroupConfig,
)
from praestoclaw.meeting_automation.service import MeetingAutomationService

__all__ = [
    "MeetingAutomationService",
    "MeetingOccurrence",
    "MeetingTaskGroupInstance",
    "MeetingTaskGroupTemplate",
    "RoutingContext",
    "TaskGroupConfig",
]
