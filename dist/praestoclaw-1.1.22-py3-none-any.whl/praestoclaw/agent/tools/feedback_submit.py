"""Submit a PraestoClaw feedback issue without exposing shell or filesystem access."""

from __future__ import annotations

import asyncio
import json
import os
import re
from dataclasses import dataclass
from typing import Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.leak import redact_credentials
from praestoclaw.security.risk import RiskAssessment, RiskScore

_TITLE_PREFIXES = ("[Feedback] ", "[fix societas bug] ")
_MAX_SUMMARY_CHARS = 80
_MAX_BODY_BYTES = 256 * 1024
_REPO = "gim-home/PraestoClaw"
_ACTIONS = frozenset({"create", "comment", "edit"})
_ISSUE_URL_RE = re.compile(r"https://github\.com/gim-home/PraestoClaw/issues/(?P<number>[1-9]\d*)")
_EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE)
_POSIX_HOME_RE = re.compile(r"(?P<prefix>/(?:Users|home)/)[^/\s]+")
_WINDOWS_HOME_RE = re.compile(r"(?P<prefix>[A-Z]:\\Users\\)[^\\\s]+", re.IGNORECASE)


@dataclass(frozen=True, slots=True)
class _IssueRef:
    number: int
    url: str


class FeedbackSubmitTool(Tool):
    """Create and amend session-owned feedback issues through fixed ``gh`` calls."""

    risk_range = (6, 6)

    def __init__(self, *, command: tuple[str, ...] = ("gh",)) -> None:
        self._command = command
        self._issues_by_session: dict[str, dict[int, _IssueRef]] = {}

    @property
    def name(self) -> str:
        return "feedback_submit"

    @property
    def description(self) -> str:
        return (
            "Create, comment on, or edit a PraestoClaw feedback issue using in-memory "
            "text. The repository and create label are fixed. Follow-ups can target "
            "only issue IDs this tool created in the current conversation session."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=120, tier="core")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": sorted(_ACTIONS),
                    "description": "Create an issue, add a comment, or edit it.",
                },
                "issue_number": {
                    "type": "integer",
                    "minimum": 1,
                    "description": (
                        "For comment/edit: an issue ID returned by create in this session."
                    ),
                },
                "title": {
                    "type": "string",
                    "description": (
                        "For create/edit: title beginning with '[Feedback] ' or the "
                        "workflow-specific '[fix societas bug] '."
                    ),
                    "maxLength": max(map(len, _TITLE_PREFIXES)) + _MAX_SUMMARY_CHARS,
                },
                "body": {
                    "type": "string",
                    "description": "Issue body, comment, or replacement body.",
                },
            },
            "required": ["action"],
            "additionalProperties": False,
        }

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        action = str(args.get("action") or "create")
        return RiskScore(6, reason=f"{action.title()} a public issue in {_REPO}")

    def audit_args(self, args: dict[str, Any]) -> dict[str, Any]:
        body = args.get("body") if isinstance(args.get("body"), str) else ""
        title = args.get("title") if isinstance(args.get("title"), str) else ""
        return {
            "action": str(args.get("action") or ""),
            **({"issue_number": args["issue_number"]} if "issue_number" in args else {}),
            **({"title": self._sanitize_text(title)} if title else {}),
            **({"body": f"[omitted: {len(body)} chars]"} if body else {}),
        }

    @staticmethod
    def _validate_title(title: str) -> str:
        prefix = next(
            (candidate for candidate in _TITLE_PREFIXES if title.startswith(candidate)), ""
        )
        if not prefix or not title[len(prefix) :].strip():
            return (
                "Refused: title must begin with '[Feedback] ' or "
                "'[fix societas bug] ' and include a summary."
            )
        if len(title[len(prefix) :]) > _MAX_SUMMARY_CHARS:
            return f"Refused: title summary exceeds {_MAX_SUMMARY_CHARS} characters."
        if any(char in title for char in ("\0", "\r", "\n")):
            return "Refused: title contains an invalid control character."
        return ""

    @staticmethod
    def _sanitize_text(value: str) -> str:
        sanitized = redact_credentials(value)
        sanitized = _EMAIL_RE.sub("[email]", sanitized)
        sanitized = _POSIX_HOME_RE.sub(r"\g<prefix>~", sanitized)
        return _WINDOWS_HOME_RE.sub(r"\g<prefix>~", sanitized)

    @staticmethod
    def _encode_body(body: str) -> tuple[bytes, str]:
        if not body.strip():
            return b"", "Refused: body must not be empty."
        sanitized = FeedbackSubmitTool._sanitize_text(body)
        try:
            encoded = sanitized.encode("utf-8")
        except UnicodeEncodeError:
            return b"", "Refused: body contains invalid Unicode."
        if len(encoded) > _MAX_BODY_BYTES:
            return b"", f"Refused: body is too large (maximum {_MAX_BODY_BYTES} bytes)."
        return encoded, ""

    def _session_issue(self, session_id: str, issue_number: Any) -> _IssueRef | str:
        if not session_id:
            return "Refused: a trusted session is required for feedback follow-ups."
        if isinstance(issue_number, bool) or not isinstance(issue_number, int) or issue_number < 1:
            return "Refused: issue_number must be a positive integer."
        issue = self._issues_by_session.get(session_id, {}).get(issue_number)
        if issue is None:
            return "Refused: that issue was not created by feedback_submit in the current session."
        return issue

    @staticmethod
    def _result(action: str, issue: _IssueRef) -> str:
        return json.dumps(
            {"action": action, "issue_number": issue.number, "url": issue.url},
            ensure_ascii=False,
        )

    async def _run(self, argv: tuple[str, ...], stdin_data: bytes) -> tuple[str, str, int] | str:
        try:
            process = await asyncio.create_subprocess_exec(
                *argv,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env={**os.environ, "GH_PROMPT_DISABLED": "1"},
            )
        except FileNotFoundError:
            return "Feedback submission unavailable: GitHub CLI (`gh`) is not installed."
        except OSError as exc:
            return f"Feedback submission unavailable: {exc}"

        try:
            stdout, stderr = await process.communicate(stdin_data)
        except asyncio.CancelledError:
            if process.returncode is None:
                process.kill()
            await process.wait()
            raise
        except Exception as exc:
            if process.returncode is None:
                process.kill()
            await process.wait()
            return f"Feedback submission failed before completion: {exc}"

        return (
            stdout.decode("utf-8", errors="replace").strip(),
            stderr.decode("utf-8", errors="replace").strip(),
            int(process.returncode or 0),
        )

    async def execute(self, **kwargs: Any) -> str:
        action = str(kwargs.get("action") or "").strip().lower()
        if action not in _ACTIONS:
            return f"Refused: action must be one of {', '.join(sorted(_ACTIONS))}."

        session_id = str(kwargs.get("_session_id") or "").strip()
        raw_title = kwargs.get("title")
        raw_body = kwargs.get("body")
        title: str = raw_title if isinstance(raw_title, str) else ""
        body: str = raw_body if isinstance(raw_body, str) else ""

        if action == "create":
            refusal = self._validate_title(title)
            if refusal:
                return refusal
            body_bytes, refusal = self._encode_body(body)
            if refusal:
                return refusal
            if not session_id:
                return "Refused: a trusted session is required to create feedback."
            sanitized_title = self._sanitize_text(title)
            try:
                sanitized_title.encode("utf-8")
            except UnicodeEncodeError:
                return "Refused: title contains invalid Unicode."
            argv = (
                *self._command,
                "issue",
                "create",
                "--repo",
                _REPO,
                "--title",
                sanitized_title,
                "--body-file",
                "-",
                "--label",
                "bug",
            )
            outcome = await self._run(argv, body_bytes)
            if isinstance(outcome, str):
                return outcome
            stdout_text, stderr_text, returncode = outcome
            if returncode != 0:
                detail = stderr_text or stdout_text or "no error output"
                return f"Feedback submission failed (exit {returncode}): {detail}"
            match = _ISSUE_URL_RE.search(stdout_text)
            if match is None:
                return "Feedback issue may have been created, but its URL could not be parsed."
            created_issue = _IssueRef(number=int(match.group("number")), url=match.group(0))
            self._issues_by_session.setdefault(session_id, {})[created_issue.number] = created_issue
            return self._result(action, created_issue)

        if action == "edit" and not title and not body:
            return "Refused: edit requires a title or body."

        session_issue = self._session_issue(session_id, kwargs.get("issue_number"))
        if isinstance(session_issue, str):
            return session_issue

        if action == "comment":
            body_bytes, refusal = self._encode_body(body)
            if refusal:
                return refusal
            argv = (
                *self._command,
                "issue",
                "comment",
                str(session_issue.number),
                "--repo",
                _REPO,
                "--body-file",
                "-",
            )
        else:
            argv_parts = [
                *self._command,
                "issue",
                "edit",
                str(session_issue.number),
                "--repo",
                _REPO,
            ]
            if title:
                refusal = self._validate_title(title)
                if refusal:
                    return refusal
                sanitized_title = self._sanitize_text(title)
                try:
                    sanitized_title.encode("utf-8")
                except UnicodeEncodeError:
                    return "Refused: title contains invalid Unicode."
                argv_parts.extend(("--title", sanitized_title))
            if body:
                body_bytes, refusal = self._encode_body(body)
                if refusal:
                    return refusal
                argv_parts.extend(("--body-file", "-"))
            else:
                body_bytes = b""
            argv = tuple(argv_parts)

        outcome = await self._run(argv, body_bytes)
        if isinstance(outcome, str):
            return outcome
        stdout_text, stderr_text, returncode = outcome
        if returncode != 0:
            detail = stderr_text or stdout_text or "no error output"
            return f"Feedback submission failed (exit {returncode}): {detail}"
        return self._result(action, session_issue)
