"""SQLite-backed session CLI: list, show, delete, and export."""

from __future__ import annotations

import asyncio
import json
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any, TypeVar

import typer
from rich.table import Table

from praestoclaw.cli.commands import console, sessions_app
from praestoclaw.session.store import SessionStore
from praestoclaw.utils.helpers import get_data_dir

_T = TypeVar("_T")


async def _with_store(operation: Callable[[SessionStore], Awaitable[_T]]) -> _T:
    store = SessionStore(get_data_dir() / "sessions.db")
    await store.initialize()
    try:
        return await operation(store)
    finally:
        await store.close()


@sessions_app.command("list")
def sessions_list() -> None:
    """List all sessions from the canonical SQLite database."""

    async def _list(store: SessionStore) -> list[dict[str, Any]]:
        return await store.list_sessions(limit=None)

    sessions = asyncio.run(_with_store(_list))
    if not sessions:
        console.print("[dim]No sessions found.[/dim]")
        return

    table = Table(title="Sessions")
    table.add_column("Session ID", style="bold")
    table.add_column("Channel")
    table.add_column("Messages", justify="right")
    table.add_column("Updated")
    for row in sessions:
        table.add_row(
            str(row.get("session_id") or row.get("id") or ""),
            str(row.get("channel") or ""),
            str(row.get("message_count") or 0),
            str(row.get("updated_at") or ""),
        )
    console.print(table)


async def _load_session(store: SessionStore, session_id: str) -> list[dict[str, Any]] | None:
    if not await store.session_exists(session_id):
        return None
    return await store.get_messages(session_id)


@sessions_app.command("show")
def sessions_show(
    session_id: str = typer.Argument(..., help="Session ID to show"),
    lines: int = typer.Option(20, "--lines", "-n", help="Number of recent messages to show"),
) -> None:
    """Show recent messages from one SQLite session."""

    async def _show(store: SessionStore) -> list[dict[str, Any]] | None:
        return await _load_session(store, session_id)

    messages = asyncio.run(_with_store(_show))
    if messages is None:
        console.print(f"[red]Session not found:[/red] {session_id}")
        raise typer.Exit(1)

    console.print(f"\n[bold]Session:[/bold] {session_id}")
    console.print(f"[bold]Messages:[/bold] {len(messages)}\n")
    tail = messages[-lines:] if len(messages) > lines else messages
    for message in tail:
        role = str(message.get("role") or "unknown")
        raw_content = message.get("content") or ""
        if isinstance(raw_content, list):
            raw_content = " ".join(
                str(part.get("text") or "") for part in raw_content if isinstance(part, dict)
            )
        snippet = str(raw_content)[:200].encode("ascii", errors="replace").decode("ascii")
        style = "cyan" if role == "user" else "green" if role == "assistant" else "dim"
        console.print(f"  [{style}]{role}[/{style}]: {snippet}")


@sessions_app.command("delete")
def sessions_delete(
    session_id: str = typer.Argument(..., help="Session ID to delete"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Delete a session and its message history from SQLite."""
    if not yes:
        typer.confirm(f"Delete session '{session_id}'?", abort=True)

    async def _delete(store: SessionStore) -> bool:
        if not await store.session_exists(session_id):
            return False
        await store.delete_session(session_id)
        return True

    deleted = asyncio.run(_with_store(_delete))
    if not deleted:
        console.print(f"[red]Session not found:[/red] {session_id}")
        raise typer.Exit(1)
    console.print(f"  [green]+[/green] Deleted session [bold]{session_id}[/bold]")


@sessions_app.command("export")
def sessions_export(
    session_id: str = typer.Argument(..., help="Session ID to export"),
    output: str = typer.Option("", "--output", "-o", help="Output file (default: <id>.md)"),
    fmt: str = typer.Option("md", "--format", "-f", help="Format: md or json"),
) -> None:
    """Export a SQLite session to Markdown or JSON."""
    if fmt not in {"md", "json"}:
        raise typer.BadParameter("format must be 'md' or 'json'")

    async def _export(store: SessionStore) -> list[dict[str, Any]] | None:
        return await _load_session(store, session_id)

    messages = asyncio.run(_with_store(_export))
    if messages is None:
        console.print(f"[red]Session not found:[/red] {session_id}")
        raise typer.Exit(1)

    safe_id = session_id.replace(":", "_").replace("/", "_")
    out_path = Path(output) if output else Path(f"{safe_id}.{fmt}")
    if fmt == "json":
        out_path.write_text(json.dumps(messages, indent=2, ensure_ascii=False), encoding="utf-8")
    else:
        output_lines = [f"# Session: {session_id}\n"]
        for message in messages:
            role = message.get("role", "?")
            content = message.get("content") or ""
            if isinstance(content, list):
                content = " ".join(
                    str(part.get("text") or "") for part in content if isinstance(part, dict)
                )
            if role == "user":
                output_lines.append(f"**You:** {content}\n")
            elif role == "assistant":
                output_lines.append(f"**PraestoClaw:** {content}\n")
        out_path.write_text("\n".join(output_lines), encoding="utf-8")
    console.print(f"  [green]+[/green] Exported to [cyan]{out_path}[/cyan]")
