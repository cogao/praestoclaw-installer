"""Group-scoped skills for the praesto-tag experiment.

This subsystem intentionally has no dependency on ``SkillLoader``.  A group
skill is a snapshot owned by one Teams conversation and has its own registry,
matching lifecycle, and cache.
"""

from praestoclaw.group_skills.core import (
    GroupSkillError,
    GroupSkillLoader,
    GroupSkillRecord,
    GroupSkillRegistry,
)

__all__ = [
    "GroupSkillError",
    "GroupSkillLoader",
    "GroupSkillRecord",
    "GroupSkillRegistry",
]
