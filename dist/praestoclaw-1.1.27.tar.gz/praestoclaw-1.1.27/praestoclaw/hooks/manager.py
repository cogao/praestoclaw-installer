"""
Hook manager — 4-hook safety pipeline with priority-ordered dispatch.

Hook points: on_message_received, pre_tool_use, post_tool_use, on_message_sent.
Each handler returns HookResult (Allow/Reject/Skip). First Reject wins.

Backward-compatible: legacy handlers that return data (not HookResult) are
treated as data transformers — the original dispatch() signature still works.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from loguru import logger

from praestoclaw.config.schema import ChannelType

# ── Hook points ──────────────────────────────────────────────────────────────

HOOK_POINTS = frozenset(
    {
        "on_message_received",
        "pre_tool_use",
        "post_tool_use",
        "on_message_sent",
    }
)

# ── Hook results ─────────────────────────────────────────────────────────────


class HookVerdict(str, Enum):
    ALLOW = "allow"
    REJECT = "reject"
    SKIP = "skip"


@dataclass
class HookResult:
    """Result from a hook handler."""

    verdict: HookVerdict
    reason: str = ""
    data: Any = None  # optional modified data (for post_tool_use redaction, etc.)

    @classmethod
    def allow(cls, data: Any = None) -> HookResult:
        return cls(verdict=HookVerdict.ALLOW, data=data)

    @classmethod
    def reject(cls, reason: str) -> HookResult:
        return cls(verdict=HookVerdict.REJECT, reason=reason)

    @classmethod
    def skip(cls) -> HookResult:
        return cls(verdict=HookVerdict.SKIP)


# ── Hook context types ───────────────────────────────────────────────────────


@dataclass
class MessageHookContext:
    """Context for on_message_received and on_message_sent hooks."""

    content: str
    channel: ChannelType = ChannelType.INTERNAL
    sender_id: str = ""
    session_id: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class PreToolHookContext:
    """Context for pre_tool_use hooks."""

    tool_name: str
    args: dict[str, Any]
    agent_name: str = "default"
    session_id: str = ""
    tool_call_id: str = ""  # LLM-assigned call ID for result pairing / tracing
    tool_ref: Any = None  # Tool instance (for assess_risk)
    # Channel context — added for human-in-the-loop approval routing.
    # None = no triggering channel (e.g. cron/scheduler).
    channel: ChannelType | None = None
    channel_id: str = ""
    sender_id: str = ""
    user_messages: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class PostToolHookContext:
    """Context for post_tool_use hooks."""

    tool_name: str
    args: dict[str, Any]
    result: str
    success: bool = True
    duration_ms: float = 0.0
    agent_name: str = "default"
    session_id: str = ""
    tool_call_id: str = ""  # LLM-assigned call ID for result pairing / tracing
    # Channel context — populated by ``_execute_tools`` so post-flight hooks
    # can route user-visible status updates back to the originating surface
    # (e.g. ToolStatusCard pushing a "✓ done" Adaptive Card to Teams).
    # ``None`` / empty for cron, scheduler, or any non-user-driven turn.
    channel: ChannelType | None = None
    channel_id: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


# ── Handler type ─────────────────────────────────────────────────────────────

HookHandler = Callable[..., Awaitable[Any]]

# ── Hook Manager ─────────────────────────────────────────────────────────────


class HookManager:
    """Register and dispatch lifecycle hooks with priority ordering.

    Supports two dispatch modes:
    - ``dispatch_checked(phase, context)`` — returns HookResult (Allow/Reject/Skip).
      Handlers must return HookResult. First Reject wins.
    - ``dispatch(phase, data)`` — legacy mode. Handlers return transformed data.
      Backward-compatible with v0.1 handler signature.
    """

    def __init__(self) -> None:
        self._hooks: dict[str, list[tuple[int, HookHandler]]] = {}

    def register(self, phase: str, handler: HookHandler, *, priority: int = 100) -> None:
        """Register a handler for a hook phase.

        Lower priority numbers execute first. Default is 100.
        """
        self._hooks.setdefault(phase, []).append((priority, handler))
        self._hooks[phase].sort(key=lambda x: x[0])

    async def dispatch_checked(
        self,
        phase: str,
        context: Any,
        *,
        exclude_types: tuple[type, ...] | None = None,
    ) -> HookResult:
        """Dispatch to handlers that return HookResult. First Reject wins.

        Args:
            exclude_types: Handler types to skip (e.g. ``(ApprovalGate,)``
                for cron tool-mode where approval was done at scheduling time).
        """
        handlers = self._hooks.get(phase, [])
        for _priority, handler in handlers:
            if exclude_types and isinstance(handler, exclude_types):
                continue
            try:
                result = await handler(context)
                if isinstance(result, HookResult):
                    if result.verdict == HookVerdict.REJECT:
                        logger.warning("Hook rejected ({}): {}", phase, result.reason)
                        return result
                    if result.verdict == HookVerdict.ALLOW and result.data is not None:
                        context = result.data
                    # SKIP: continue to next handler
                # Legacy handler returned non-HookResult → treat as data transform
                elif result is not None:
                    context = result
            except Exception as exc:
                logger.error("Hook error ({}): {}", phase, exc)
                # Fail-secure: reject on pre_tool_use hook crash to prevent
                # security bypass (e.g., ApprovalGate exception = tool allowed).
                if phase == "pre_tool_use":
                    return HookResult.reject("Security hook failed; tool execution blocked")
        return HookResult.allow(data=context)

    async def dispatch(self, phase: str, data: Any) -> Any:
        """Legacy dispatch — handlers return transformed data. Backward-compatible."""
        handlers = self._hooks.get(phase, [])
        result = data
        for _priority, handler in handlers:
            try:
                out = await handler(result)
                if isinstance(out, HookResult):
                    # New-style handler in legacy dispatch: extract data if Allow
                    if out.verdict == HookVerdict.REJECT:
                        return result  # stop chain, return last good data
                    if out.data is not None:
                        result = out.data
                elif out is not None:
                    result = out
            except Exception as exc:
                logger.error("Hook error ({}): {}", phase, exc)
        return result

    def has(self, phase: str) -> bool:
        return bool(self._hooks.get(phase))
