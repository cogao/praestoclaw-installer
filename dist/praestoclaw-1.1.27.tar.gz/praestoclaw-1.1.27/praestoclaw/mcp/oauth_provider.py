"""MCP OAuth provider factory — creates httpx.Auth instances for MCP servers.

Wraps the MCP Python SDK's :class:`~mcp.client.auth.OAuthClientProvider` and
:class:`~mcp.client.auth.extensions.client_credentials.ClientCredentialsOAuthProvider`
to provide:

* **Explicit OAuth** — ``auth.type: "oauth"`` gets a fully configured
  provider (authorization-code or client-credentials).
* **Auto-discovery** — ``auth.type: "none"`` (default) gets a passive
  ``OAuthClientProvider`` that activates only when a 401 is received.
* **Silent auto-discovery** — ``auth.type: "implicit"`` gets the same
  provider but with no-op redirect/callback handlers. SDK discovers
  scopes and uses cached tokens silently; never opens a browser.
* ``bearer`` returns ``None`` — uses static token headers only.

Token persistence uses :class:`~praestoclaw.mcp.oauth_storage.MCPTokenStorage`
(OS keyring via PraestoClaw secret store, with encrypted-file overflow).
"""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING

import httpx
from loguru import logger

if TYPE_CHECKING:
    from praestoclaw.config.schema import MCPServerConfig, ProvidersConfig


async def create_oauth_auth(
    server_name: str,
    config: MCPServerConfig,
    providers: ProvidersConfig | None = None,
    resolved_url: str | None = None,
) -> httpx.Auth | None:
    """Create an :class:`httpx.Auth` for an MCP server's OAuth requirements.

    Args:
        resolved_url: URL with ``{var}`` placeholders already resolved.
            Used for SDK auto-discovery (resource metadata). Falls back
            to ``config.url`` if not provided.

    Returns ``None`` for ``bearer`` (static headers) and stdio transports.
    Returns a **silent** provider for ``implicit`` (no browser, uses cached tokens).
    Returns a full interactive provider for ``oauth`` and ``none``.
    """
    if config.auth.type == "bearer":
        return None
    effective_url = resolved_url or config.url
    if effective_url is None:
        return None

    if config.auth.type == "oauth":
        grant = _resolve_grant_type(config)
        if grant == "client_credentials":
            return _create_client_credentials(server_name, config, effective_url)

    # authorization_code — explicit, auto-discovery, or implicit (silent)
    return await _create_authorization_code(server_name, config, effective_url)


def _resolve_grant_type(config: MCPServerConfig) -> str:
    """Determine effective grant type with backward-compatibility handling."""
    auth = config.auth
    if auth.grant_type is not None:
        return auth.grant_type
    if auth.client_secret is not None:
        warnings.warn(
            "MCPAuthConfig: 'oauth' with client_secret but no explicit grant_type. "
            "Defaulting to 'client_credentials' for backward compatibility. "
            "Please set grant_type explicitly.",
            FutureWarning,
            stacklevel=3,
        )
        return "client_credentials"
    return "authorization_code"


async def _create_authorization_code(
    server_name: str,
    config: MCPServerConfig,
    effective_url: str,
) -> httpx.Auth:
    """Authorization Code + PKCE provider.

    Handles explicit ``auth.type: "oauth"``, passive auto-discovery
    (``auth.type: "none"``), and silent cached-token mode (``"implicit"``).

    For ``implicit``: SDK auto-discovers scopes and uses cached tokens
    (from a prior ``pc mcp login``), but redirect/callback handlers
    silently fail so a browser is never opened.
    """
    from mcp.shared.auth import OAuthClientInformationFull, OAuthClientMetadata
    from pydantic import AnyUrl

    from praestoclaw.mcp.oauth_client import RefreshingOAuthClientProvider
    from praestoclaw.mcp.oauth_storage import MCPTokenStorage

    auth = config.auth
    is_implicit = config.auth.type == "implicit"
    storage = MCPTokenStorage(server_name)

    from praestoclaw.mcp.oauth_callback import create_oauth_handlers

    if is_implicit:
        # Silent handlers — never open browser, never block.
        # SDK still discovers scopes and uses cached tokens via refresh.
        # Both redirect and callback are no-ops: redirect skips the browser,
        # callback raises immediately so the SDK doesn't hang waiting.
        _, _, port = create_oauth_handlers(0)

        async def _silent_redirect(url: str) -> None:
            logger.debug("MCP implicit: skipping browser redirect for '{}'", server_name)

        async def _silent_callback() -> tuple[str, str | None]:
            raise RuntimeError("implicit mode — no interactive login")

        redirect_handler = _silent_redirect  # type: ignore[assignment]
        callback_handler = _silent_callback  # type: ignore[assignment]
    else:
        redirect_handler, callback_handler, port = create_oauth_handlers(auth.callback_port or 0)  # type: ignore[assignment]

    redirect_uri = AnyUrl(f"http://localhost:{port}/")

    client_metadata = OAuthClientMetadata(
        redirect_uris=[redirect_uri],
        client_name="PraestoClaw",
        grant_types=["authorization_code", "refresh_token"],
        response_types=["code"],
        token_endpoint_auth_method="client_secret_post" if auth.client_secret else "none",
        scope=" ".join(auth.scopes) if auth.scopes else None,
    )

    # Write client_info when client_id is configured (redirect_uris change
    # with each random port). Without client_id, SDK handles it via dynamic
    # registration or CIMD. Servers that need a specific client_id should
    # configure it in praestoclaw.yaml.
    if auth.client_id:
        await storage.set_client_info(
            OAuthClientInformationFull(
                client_id=auth.client_id,
                client_secret=(
                    auth.client_secret.get_secret_value() if auth.client_secret else None
                ),
                redirect_uris=client_metadata.redirect_uris,
                client_name="PraestoClaw",
                grant_types=client_metadata.grant_types,
                response_types=client_metadata.response_types,
                token_endpoint_auth_method=client_metadata.token_endpoint_auth_method,
            )
        )

    logger.debug("MCP OAuth: authorization_code provider for '{}'", server_name)
    provider = RefreshingOAuthClientProvider(
        server_url=effective_url,  # type: ignore[arg-type]  # resolved {var} URL
        client_metadata=client_metadata,
        storage=storage,
        redirect_handler=redirect_handler,
        callback_handler=callback_handler,
    )
    if auth.auth_server_url:
        provider.context.auth_server_url = auth.auth_server_url
    return provider


def _create_client_credentials(
    server_name: str,
    config: MCPServerConfig,
    effective_url: str,
) -> httpx.Auth:
    """Client Credentials grant (M2M)."""
    from mcp.client.auth.extensions.client_credentials import ClientCredentialsOAuthProvider

    from praestoclaw.mcp.oauth_storage import MCPTokenStorage

    auth = config.auth
    if not auth.client_id or not auth.client_secret:
        raise RuntimeError(
            f"MCP server '{server_name}': client_credentials grant requires "
            "both client_id and client_secret"
        )

    logger.debug("MCP OAuth: client_credentials provider for '{}'", server_name)
    return ClientCredentialsOAuthProvider(
        server_url=effective_url,  # type: ignore[arg-type]  # resolved {var} URL
        storage=MCPTokenStorage(server_name),
        client_id=auth.client_id,
        client_secret=auth.client_secret.get_secret_value(),
        scopes=" ".join(auth.scopes) if auth.scopes else None,
    )
