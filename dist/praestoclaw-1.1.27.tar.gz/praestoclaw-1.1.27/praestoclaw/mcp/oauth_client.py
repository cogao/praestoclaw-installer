"""SDK OAuth integration that refreshes cached tokens rejected after reconnect."""

from collections.abc import AsyncGenerator

import httpx
from mcp.client.auth import OAuthClientProvider
from mcp.client.auth.utils import (
    build_oauth_authorization_server_metadata_discovery_urls,
    build_protected_resource_metadata_discovery_urls,
    create_oauth_metadata_request,
    extract_resource_metadata_from_www_auth,
    handle_auth_metadata_response,
    handle_protected_resource_response,
)


class RefreshingOAuthClientProvider(OAuthClientProvider):
    """Try refresh before interactive authorization on a cached-token 401.

    MCP SDK 1.29 loads persisted tokens without their expiry time and goes
    straight to authorization on 401. Wrap its flow so existing caches can
    renew silently, including group MCP connections after a daemon restart.
    The SDK flow holds its context lock throughout discovery, refresh and retry.
    """

    async def async_auth_flow(
        self, request: httpx.Request
    ) -> AsyncGenerator[httpx.Request, httpx.Response]:
        flow = super().async_auth_flow(request)
        refreshed = False
        try:
            outgoing = await anext(flow)
            while True:
                response = yield outgoing
                if (
                    outgoing is request
                    and response.status_code == 401
                    and not refreshed
                    and self.context.can_refresh_token()
                ):
                    refreshed = True
                    # A new provider has no discovered metadata. Resolve the
                    # issuer and token endpoint before asking the SDK to refresh;
                    # its fallback /token is not correct for all MCP servers.
                    if self.context.oauth_metadata is None:
                        resource_metadata_url = extract_resource_metadata_from_www_auth(response)
                        for url in build_protected_resource_metadata_discovery_urls(
                            resource_metadata_url, self.context.server_url
                        ):
                            discovery = yield create_oauth_metadata_request(url)
                            metadata = await handle_protected_resource_response(discovery)
                            if metadata:
                                await self._validate_resource_match(metadata)
                                self.context.protected_resource_metadata = metadata
                                self.context.auth_server_url = str(
                                    metadata.authorization_servers[0]
                                )
                                break

                        for url in build_oauth_authorization_server_metadata_discovery_urls(
                            self.context.auth_server_url, self.context.server_url
                        ):
                            discovery = yield create_oauth_metadata_request(url)
                            ok, oauth_metadata = await handle_auth_metadata_response(discovery)
                            if not ok:
                                break
                            if oauth_metadata:
                                self.context.oauth_metadata = oauth_metadata
                                break

                    refresh_response = yield await self._refresh_token()
                    if await self._handle_refresh_response(refresh_response):
                        self._add_auth_header(request)
                        response = yield request
                    # Hand a failed refresh/retry back to the SDK's normal
                    # authorization flow (silent group mode reports login needed).
                try:
                    outgoing = await flow.asend(response)
                except StopAsyncIteration:
                    return
        finally:
            await flow.aclose()
