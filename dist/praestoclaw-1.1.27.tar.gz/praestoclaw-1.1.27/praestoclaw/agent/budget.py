from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class TurnExit(str, Enum):
    MODEL_FINISHED = "model_finished"
    BUDGET_EXHAUSTED = "budget_exhausted"
    PROMOTED = "promoted"


@dataclass(frozen=True)
class GoalTurnResult:
    text: str
    exit: TurnExit
    iterations_used: int
    tool_successes: int
    tool_failures: int
    last_tool_name: str | None
    last_tool_succeeded: bool | None


@dataclass
class IterationBudget:
    max_total: int = 90
    _used: int = field(default=0, init=False, repr=False)
    _grace_consumed: bool = field(default=False, init=False, repr=False)

    @classmethod
    def for_subagent(cls, max_total: int = 50) -> IterationBudget:
        return cls(max_total=max_total)

    @property
    def remaining(self) -> int:
        return max(0, self.max_total - self._used)

    @property
    def used(self) -> int:
        return self._used

    @property
    def grace_available(self) -> bool:
        return self.remaining == 0 and not self._grace_consumed

    def consume(self) -> bool:
        if self._used >= self.max_total:
            return False
        self._used += 1
        return True

    def refund(self) -> None:
        self._used = max(0, self._used - 1)

    def consume_grace(self) -> bool:
        if not self.grace_available:
            return False
        self._grace_consumed = True
        return True
