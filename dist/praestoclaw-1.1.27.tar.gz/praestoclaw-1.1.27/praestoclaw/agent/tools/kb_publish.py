"""Publish a locally committed KB proposal after its one draft confirmation.

The group confirms its detailed file-level summary once; that approval closes
any optional Draft PR mirror and authorizes this tool to update the real branch,
squash the local proposal onto it, create one commit, and push immediately.
"""

from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.agent.tools.kb_base import KbToolBase
from praestoclaw.kb.draft import (
    DECISION_APPROVED,
    DECISION_DRAFT,
    STATUS_AWAITING_PUBLISH,
    STATUS_PUBLISHED,
    CurationTask,
    CurationTaskStore,
    commit_message_for,
)
from praestoclaw.kb.github_review import close_draft_review
from praestoclaw.kb.repo import KbAuthRequiredError, KbPathError, KbRepo, KbRepoError
from praestoclaw.security.kb_curation import kb_curation_is_active
from praestoclaw.security.risk import RiskAssessment, RiskScore


def _now() -> str:
    return datetime.now(UTC).isoformat()


class KbPublishTool(KbToolBase, Tool):
    """Squash and push a proposal approved in ordinary group chat."""

    risk_range = (6, 6)

    @property
    def name(self) -> str:
        return "kb_publish"

    @property
    def description(self) -> str:
        return (
            "Publish the current conversation's local KB proposal. This tool has its "
            "own durable natural-language gate: it refuses unless the detailed draft "
            "approval, including the group's exact words, matches the current proposal "
            "fingerprint. There is no second publish confirmation or Adaptive Card. "
            "Once approved it closes any optional Draft PR, updates the real branch "
            "from origin, squash-merges the local proposal, commits, pushes, and "
            "returns a minimal user-facing outcome."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=300, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(6, reason="Commit and push to the shared team knowledge base")

    def handles_approval_internally(self, args: dict[str, Any], metadata: dict[str, Any]) -> bool:
        """Tell the generic gate not to create a third, card-based confirmation.

        This says only that the tool owns the gate, not that approval exists.
        ``execute`` validates the durable chat decisions and otherwise performs
        no repository mutation.
        """
        del args
        return kb_curation_is_active(metadata)

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "Which task; defaults to this conversation's active one.",
                },
                "message": {
                    "type": "string",
                    "description": (
                        "Optional assertion of the already-confirmed commit message. A "
                        "different message is refused."
                    ),
                },
            },
            "required": [],
        }

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata") or {}
        if not kb_curation_is_active(metadata):
            return (
                "kb_publish is only available in a Teams group experiment or personal Teams chat."
            )
        if not self._enabled():
            return "Knowledge-base curation is disabled in this PraestoClaw config."

        cid = str(metadata.get("cid") or "")
        if not cid:
            return "Error: kb_publish needs a Teams conversation id on this turn."

        store = CurationTaskStore(cid)
        task = store.resolve(str(kwargs.get("task_id") or ""))
        if task is None:
            return "No curation task found for this conversation."
        if task.status == STATUS_PUBLISHED:
            return self._success_result(task)
        if not task.is_active:
            return f"Task {task.task_id} is {task.status} and cannot be published."
        if task.status != STATUS_AWAITING_PUBLISH or not task.changes or not task.proposal_sha:
            return self._dump(
                {
                    "ok": False,
                    "task_id": task.task_id,
                    "refused": "No approved local proposal is ready to publish.",
                }
            )

        refusal = self._approval_refusal(task)
        if refusal:
            return refusal
        if task.open_blockers:
            return self._dump(
                {
                    "ok": False,
                    "task_id": task.task_id,
                    "refused": "Unanswered rule conflicts — this cannot be published.",
                    "open_blockers": [item.to_dict() for item in task.open_blockers],
                }
            )

        passed_message = str(kwargs.get("message") or "").strip()
        if passed_message and commit_message_for(passed_message, task) != task.commit_message:
            return self._dump(
                {
                    "ok": False,
                    "task_id": task.task_id,
                    "refused": "That commit message is not the one the group confirmed.",
                }
            )

        resolved = self._repo_for_task(task.repo)
        if isinstance(resolved, str):
            return self._failure_result(store, task, resolved)

        try:
            return await self._publish(store, task, resolved)
        except (KbAuthRequiredError, KbPathError, KbRepoError, OSError) as exc:
            logger.warning("kb_publish failed for {}: {}", task.task_id, exc)
            return self._failure_result(store, task, str(exc))

    def _approval_refusal(self, task: CurationTask) -> str:
        draft = task.latest_decision(DECISION_DRAFT)
        if draft is None or draft.decision != DECISION_APPROVED:
            return self._dump(
                {
                    "ok": False,
                    "task_id": task.task_id,
                    "refused": "The group has not approved the detailed draft in chat.",
                }
            )
        if task.draft_approval() is None:
            return self._dump(
                {
                    "ok": False,
                    "task_id": task.task_id,
                    "refused": "The local proposal changed after draft confirmation.",
                }
            )
        return ""

    async def _publish(self, store: CurationTaskStore, task: CurationTask, repo: KbRepo) -> str:
        target_branch = task.base_branch or await asyncio.to_thread(repo.branch)
        current_branch = await asyncio.to_thread(repo.branch)
        logger.info(
            "kb_publish.status step=publish outcome=start task={} proposal={} "
            "current_branch={} target_branch={} review_number={}",
            task.task_id,
            task.proposal_sha[:12],
            current_branch,
            target_branch,
            int(task.proposal_review.get("number") or 0),
        )
        if current_branch != target_branch:
            logger.debug(
                "kb_publish.status step=checkout outcome=start from_branch={} to_branch={}",
                current_branch,
                target_branch,
            )
            await asyncio.to_thread(repo.checkout, target_branch)
            logger.debug(
                "kb_publish.status step=checkout outcome=succeeded branch={}", target_branch
            )

        if task.proposal_review:
            logger.info(
                "kb_publish.status step=review_cleanup outcome=start number={} branch={}",
                int(task.proposal_review.get("number") or 0),
                task.proposal_branch,
            )
            task.proposal_review = await asyncio.to_thread(
                close_draft_review,
                repo,
                task.proposal_review,
                fallback_branch=task.proposal_branch,
            )
            store.save(task)
            logger.info(
                "kb_publish.status step=review_cleanup outcome=complete state={} "
                "api_closed={} branch_removed={}",
                task.proposal_review.get("state") or "unknown",
                bool(task.proposal_review.get("api_closed")),
                bool(task.proposal_review.get("remote_branch_removed")),
            )

        # Synchronisation and merge are intentionally part of the automatic
        # publish operation. They do not create another confirmation round.
        logger.info(
            "kb_publish.status step=sync outcome=start branch={} timeout_s={}",
            target_branch,
            self._sync_timeout(),
        )
        status = await asyncio.to_thread(repo.sync, timeout=self._sync_timeout())
        publish_base = status.head
        paths = [change.path for change in task.changes]
        logger.info(
            "kb_publish.status step=sync outcome=succeeded branch={} head={} files={}",
            target_branch,
            publish_base[:12],
            len(paths),
        )
        try:
            logger.info(
                "kb_publish.status step=squash outcome=start proposal_branch={}",
                task.proposal_branch,
            )
            await asyncio.to_thread(repo.squash_merge, task.proposal_branch)
            logger.info(
                "kb_publish.status step=squash outcome=succeeded proposal_branch={}",
                task.proposal_branch,
            )
            logger.info(
                "kb_publish.status step=commit outcome=start branch={} files={}",
                target_branch,
                len(paths),
            )
            sha = await asyncio.to_thread(repo.commit, paths, task.commit_message)
            logger.info(
                "kb_publish.status step=commit outcome=succeeded branch={} sha={}",
                target_branch,
                sha[:12],
            )
            logger.info(
                "kb_publish.status step=push outcome=start branch={} timeout_s={}",
                target_branch,
                self._sync_timeout(),
            )
            branch = await asyncio.to_thread(repo.push, timeout=self._sync_timeout())
            logger.info(
                "kb_publish.status step=push outcome=succeeded branch={} sha={}",
                branch,
                sha[:12],
            )
        except Exception as exc:
            logger.warning(
                "kb_publish.status step=publish outcome=failed error_type={} action=rollback "
                "base={}",
                type(exc).__name__,
                publish_base[:12],
            )
            await asyncio.to_thread(repo.rollback, publish_base, paths)
            logger.info(
                "kb_publish.status step=rollback outcome=complete base={}", publish_base[:12]
            )
            raise

        removed = True
        try:
            logger.debug(
                "kb_publish.status step=local_cleanup outcome=start branch={}",
                task.proposal_branch,
            )
            removed = await asyncio.to_thread(repo.delete_local_branch, task.proposal_branch)
        except KbRepoError as exc:
            removed = False
            logger.warning(
                "kb_publish.status step=local_cleanup outcome=failed branch={} error_type={}",
                task.proposal_branch,
                type(exc).__name__,
            )
        else:
            logger.debug(
                "kb_publish.status step=local_cleanup outcome={} branch={}",
                "removed" if removed else "unavailable",
                task.proposal_branch,
            )

        approval = task.draft_approval()
        task.status = STATUS_PUBLISHED
        task.published = {
            "proposal_commit": task.proposal_sha,
            "proposal_review": task.proposal_review or None,
            "commit": sha,
            "branch": branch,
            "url": repo.commit_url(sha),
            "message": task.commit_message,
            "overview": task.overview,
            "paths": paths,
            "files": [
                {
                    "path": change.path,
                    "operation": change.operation,
                    "summary": change.summary,
                    "details": change.details,
                    "units": change.units,
                }
                for change in task.changes
            ],
            "overrode_rules": [item.to_dict() for item in task.overridden_blockers],
            "approved_by": approval.by if approval else "",
            "approval_quote": approval.quote if approval else "",
            "approval_stage": DECISION_DRAFT,
            "proposal_branch_removed": removed,
            "published_at": _now(),
            "fingerprint": task.change_fingerprint(),
        }
        task.publish_attempts.append(
            {
                "at": task.published["published_at"],
                "outcome": "succeeded",
                "proposal_commit": task.proposal_sha,
                "commit": sha,
                "branch": branch,
                "url": task.published["url"],
                "message": task.commit_message,
                "paths": paths,
                "approved_by": task.published["approved_by"],
                "approval_quote": task.published["approval_quote"],
                "fingerprint": task.published["fingerprint"],
            }
        )
        store.save(task)
        logger.info(
            "kb_publish: task={} proposal={} commit={} paths={}",
            task.task_id,
            task.proposal_sha[:8],
            sha[:8],
            ", ".join(paths),
        )
        return self._success_result(task)

    def _success_result(self, task: CurationTask) -> str:
        published = task.published
        link = str(published.get("url") or published.get("commit") or "").strip()
        reply = (
            f"知识库已更新：[查看更新]({link})"
            if link.startswith(("https://", "http://"))
            else "知识库已更新。"
        )
        return self._dump({"ok": True, "task_id": task.task_id, "reply": reply})

    def _failure_result(self, store: CurationTaskStore, task: CurationTask, reason: str) -> str:
        detail = " ".join((reason or "unknown error").split())[:4000]
        short = detail[:180]
        task.publish_attempts.append(
            {
                "at": _now(),
                "outcome": "failed",
                "reason": detail,
                "proposal_commit": task.proposal_sha,
                "message": task.commit_message,
                "paths": [change.path for change in task.changes],
                "fingerprint": task.change_fingerprint(),
            }
        )
        store.save(task)
        return self._dump(
            {
                "ok": False,
                "task_id": task.task_id,
                "reply": f"知识库暂时没有更新成功：{short}",
            }
        )

    @staticmethod
    def _dump(payload: dict[str, Any]) -> str:
        return json.dumps(payload, ensure_ascii=False, indent=2)
