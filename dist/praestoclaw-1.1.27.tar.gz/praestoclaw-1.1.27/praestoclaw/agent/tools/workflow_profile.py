"""Per-project configuration for workflow recipes — the mechanism, none of the policy.

A recipe opts in with a ``profile:`` block in its own frontmatter, and that block is
where every value this module enforces comes from: which scalars a configuration must
declare, where a repository-local one lives, what to tell a user who has none. The
tool that runs recipes holds none of it — `target_branch` and a checkout strategy
mean something only to a workflow that opens pull requests, and `workflow` runs any
recipe at all.

The seam back to that tool is deliberately three things: ``prepare_run`` (may refuse,
may append to the prompt), ``init_project`` (one action's body), and
``SCHEMA_PROPERTIES``. Making the tool *entirely* unaware would need a preparer
registry — a new extension mechanism for a single consumer, which costs more than the
dozen lines it would save.

TWO LAYERS, merged by DIFFERENT rules:

- PROSE — the first candidate with a body wins, WHOLE. A half-GitHub, half-ADO
  operating manual is worse than either one used straight, and the tier order is a
  security property: a repository's own file must not shadow a configuration the
  caller named by name.
- SCALARS — merged key by key, lowest tier first, so a repository can override ONE
  value without restating anything. A candidate whose body is empty after its
  frontmatter contributes scalars and does NOT compete for the prose layer; that rule
  is the whole ergonomic point.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import subprocess
import tempfile
from pathlib import Path, PurePosixPath
from typing import Any, NamedTuple
from urllib.parse import urlsplit

import yaml

from praestoclaw.utils.text import MAX_NAME_LEN, as_bool, slugify

_BUNDLED_PROFILES = Path(__file__).parent / "bundled_workflows" / "profiles"


# Project-configuration mechanism. Deliberately carries NO recipe's policy: which
# scalars a configuration must declare, where a repository-local one lives, and what
# to tell a user who has none are all read from the recipe's own `profile:`
# frontmatter block — the same split `parameters:`, `limits:` and `concurrency:`
# already use. A recipe's configuration keys mean something only to that recipe,
# and this tool runs any recipe at all.
#
# A project name is interpolated into a path, so it must be an identifier and not a
# path fragment. Leading char is alphanumeric, which rejects `.`, `..` and
# `.hidden`; the class carries no separator, which rejects `../x` and `sub/x`.
#
# This read is the one thing the design takes AWAY from the tool pipeline — no risk
# scoring, no hook pipeline, no leak scan, no audit log — and `project` is chosen by
# a model that has been reading an untrusted issue body.
_PROJECT_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
# The whole configuration rides in the prompt, so this is a prompt-budget bound as
# much as a safety one. The two bundled profiles are ~5 KB.
_MAX_PROFILE_BYTES = 64_000
# Frontmatter delimiter. See _split_frontmatter for why this is a fourth copy.
#
# The trailing newline after the closing `---` is OPTIONAL, which the three existing
# copies in this package get wrong. It never bit them because a skill always has a
# body; it bites here immediately, because the headline case is a configuration that
# is NOTHING BUT frontmatter, and an editor that omits the final newline would turn
# those three lines into prose.
_PROFILE_FRONTMATTER_RE = re.compile(
    r"\A\s*---\s*\n(?P<meta>.*?)\n---[ \t]*(?:\r?\n(?P<body>.*))?\Z",
    re.DOTALL,
)


class _ProfileSpec(NamedTuple):
    """A recipe's project-configuration contract, from its own frontmatter.

    ``declared`` is the opt-in: a recipe without a ``profile:`` block gets no
    configuration resolution at all and this whole subsystem stays out of its way.

    Note what is absent: a list of sections a configuration must contain. That check
    lived here once and bought nothing — a configuration missing its auth or PR
    section fails VISIBLY, because the run has no command to run and the recipe that
    wanted it forbids inventing one. It cost the generic tool a hardcoded list of one
    recipe's headings, which is the trade this split exists to undo.
    """

    declared: bool = False
    repo_file: str = ""
    scalars: tuple[dict[str, Any], ...] = ()
    elsewhere: str = ""


def _profile_spec(recipe: Any) -> _ProfileSpec:
    """Read a recipe's contract. Anything malformed degrades to "not declared".

    "Malformed" has to include a ``scalars`` that is not a list. Filtering a string
    or a mapping down to an empty tuple would leave ``declared=True`` with nothing
    required — quietly ACTIVATING this subsystem for a recipe whose contract does not
    parse, which is the opposite of degrading.

    ``repo_file`` is joined onto the caller's ``repo_path``, so it must be a plain
    relative path. Recipes are trusted — a hostile one has far better options than
    reading a file — but this read bypasses risk scoring, the hook pipeline, the leak
    scan and the audit log, and inlines what it finds into the protected head of the
    prompt. A typo'd ``../`` should not be the thing that discovers that.
    """
    raw = getattr(recipe, "profile", None)
    if not isinstance(raw, dict):
        return _ProfileSpec()
    raw_scalars = raw.get("scalars")
    if raw_scalars is not None and not isinstance(raw_scalars, list):
        return _ProfileSpec()
    scalars = tuple(
        spec
        for spec in (raw_scalars or [])
        if isinstance(spec, dict) and str(spec.get("name") or "").strip()
    )
    repo_file = str(raw.get("repo_file") or "").strip()
    if repo_file and not _is_safe_relative(repo_file):
        return _ProfileSpec()
    return _ProfileSpec(
        declared=True,
        repo_file=repo_file,
        scalars=scalars,
        elsewhere=str(raw.get("elsewhere") or "").strip(),
    )


def _is_safe_relative(candidate: str) -> bool:
    """A path that stays under whatever it is joined to.

    Lexical, like the project-name check: ``..`` is collapsed without touching the
    filesystem, and an absolute path is rejected outright because ``Path(a) / "/b"``
    silently discards ``a``.
    """
    path = PurePosixPath(candidate.replace("\\", "/"))
    if path.is_absolute() or (len(candidate) > 1 and candidate[1] == ":"):
        return False
    return ".." not in path.parts


def _required_scalar_names(spec: _ProfileSpec) -> list[str]:
    return [str(s["name"]).strip() for s in spec.scalars if as_bool(s.get("required"))]


class _Profile(NamedTuple):
    """A resolved project configuration. ``error`` non-empty means refuse the run.

    ``text`` is the winning prose layer with its frontmatter stripped, so raw YAML
    never reaches the prompt. ``scalars`` is the merged result of EVERY candidate's
    frontmatter, not just the winner's — that is the whole point of splitting the
    layers, and it is what lets a repository ship a three-line file.

    Which keys those are is the RECIPE's business (``_ProfileSpec``), so this is a
    mapping rather than named fields. ``None`` rather than ``{}`` as the default: a
    mutable default on a NamedTuple is shared across every instance.
    """

    text: str
    source: str
    error: str
    scalars: dict[str, str] | None = None
    # "github" / "ado", already resolved from the origin remote. Carried so the
    # setup directive can propose provider-appropriate discovery without paying a
    # second `git remote get-url`.
    provider: str = ""


_ADO_HOSTS = ("dev.azure.com", "visualstudio.com")


def _remote_host(url: str) -> str:
    """Hostname of a git remote URL, lowercased; "" when there isn't one.

    Handles both forms git actually emits: a real URL
    (``https://dev.azure.com/org/proj/_git/repo``) and scp-style syntax
    (``git@ssh.dev.azure.com:v3/org/proj/repo``), which ``urlsplit`` reads as a
    path with no host.
    """
    text = url.strip()
    if not text:
        return ""
    if "://" in text:
        return (urlsplit(text).hostname or "").lower()
    # scp-style: [user@]host:path — the colon is a separator, not a port.
    _, _, rest = text.rpartition("@")
    host, _, _ = rest.partition(":")
    return host.strip().lower()


async def _remote_kind(repo_path: str) -> str:
    """``ado`` or ``github`` for ``repo_path``'s origin remote; ``github`` by default.

    Matching is on the parsed HOST, and on a full label boundary. A substring
    test over the raw URL — ``"dev.azure.com" in url`` — accepts
    ``https://github.com/evil/dev.azure.com-mirror`` and would hand that
    repository the ADO profile, which is what decides its authentication and PR
    commands. CodeQL flags the shape (``py/incomplete-url-substring-sanitization``)
    and is right to: the profile choice is a security decision.

    Off the event loop with a timeout, for the reason ``_fill_agent_repo_path``
    gives: a blocking ``git`` call starves every other coroutine, and this one can
    hang on an odd credential-helper config.
    """
    try:
        out = await asyncio.to_thread(
            subprocess.run,
            ["git", "-C", repo_path, "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        url = out.stdout.strip() if out.returncode == 0 else ""
    except Exception:  # noqa: BLE001 - no remote is not an error, just no signal
        url = ""
    host = _remote_host(url)
    # `host == h` or `*.h` — never a bare suffix, which would accept
    # `notvisualstudio.com`.
    if any(host == h or host.endswith(f".{h}") for h in _ADO_HOSTS):
        return "ado"
    return "github"


def _read_profile_candidate(raw_path: Path) -> tuple[str, str]:
    """Read one profile candidate. Returns ``(text, error)``; both empty = absent.

    Deliberately strict, because this read is the one thing this change takes AWAY
    from the tool pipeline. Fetched through ``shell`` a profile passes risk
    scoring, the hook pipeline, leak scanning and the audit log; read here it
    passes none of them. So refuse everything that is not a plain, bounded,
    regular UTF-8 file, and let the caller log what it accepted.

    Every failure comes back through ``error`` rather than as an exception,
    because the caller's whole job is to turn a bad candidate into a refusal that
    names it. ``expanduser`` is inside the guard for the same reason: a
    ``~nosuchuser/`` path raises ``RuntimeError``, which is not an ``OSError``.
    """
    try:
        path = raw_path.expanduser()
        if path.is_symlink():
            return "", f"{path} is a symlink; a profile must be a regular file"
        if not path.exists():
            return "", ""
        if not path.is_file():
            return "", f"{path} is not a regular file"
        size = path.stat().st_size
        if size > _MAX_PROFILE_BYTES:
            return "", f"{path} is {size} bytes; the profile cap is {_MAX_PROFILE_BYTES}"
        return path.read_text(encoding="utf-8"), ""
    except UnicodeDecodeError:
        return "", f"{raw_path} is not valid UTF-8; a profile must be a text file"
    except (OSError, ValueError, RuntimeError) as exc:
        return "", f"{raw_path} could not be read: {exc}"


def _split_frontmatter(text: str) -> tuple[dict[str, Any], str, str]:
    """Split ``---`` frontmatter off a profile. Returns ``(meta, body, error)``.

    Absent frontmatter is NOT an error — it yields ``({}, text, "")``, which is
    what every profile written before this layer existed looks like.

    This package already has three frontmatter parsers (``skills/loader.py``,
    ``skills/marketplace.py``, ``group_skills/core.py``) and not one of them takes
    TEXT: they all take a ``Path`` and hand back a constructed object. Hence a
    fourth — and with the guard ``loader.py`` is missing. A frontmatter of
    ``- a\\n- b`` is perfectly valid YAML that parses to a LIST, and loader.py walks
    straight into ``meta.get(...)`` and an uncaught ``AttributeError``.
    """
    match = _PROFILE_FRONTMATTER_RE.match(text)
    if not match:
        return {}, text, ""
    # ``body`` is None when the closing ``---`` is the end of the file — a profile
    # that is nothing but frontmatter, which is the shape this whole layer exists
    # to make possible.
    body = match.group("body") or ""
    try:
        meta = yaml.safe_load(match.group("meta"))
    except yaml.YAMLError as exc:
        return {}, "", f"has frontmatter that is not valid YAML: {exc}"
    if meta is None:
        return {}, body, ""
    if not isinstance(meta, dict):
        return {}, "", f"has frontmatter that is a {type(meta).__name__}, not a mapping"
    return meta, body, ""


def _profile_scalars(meta: dict[str, Any], spec: _ProfileSpec) -> tuple[dict[str, str], str]:
    """Keep the scalars the recipe declared; validate any it constrained.

    Unknown keys are IGNORED, not refused. Refusing them was redundant: a typo like
    ``target_brach:`` leaves the real key unresolved, and the required-scalar gate
    below already catches that with a message that walks the author through fixing
    it — strictly more useful than "unknown key". One check, not two.
    """
    values: dict[str, str] = {}
    for declared in spec.scalars:
        key = str(declared["name"]).strip()
        raw = str(meta.get(key) or "").strip()
        if not raw:
            continue
        options = declared.get("options")
        if isinstance(options, list) and options and raw not in [str(o) for o in options]:
            return {}, f"sets {key} to {raw!r}; it must be one of {[str(o) for o in options]}"
        values[key] = raw
    return values, ""


def _apply_profile_scalars(values: dict[str, Any], profile: _Profile, spec: _ProfileSpec) -> str:
    """Fill parameter slots the caller left empty from the merged scalar layer.

    Only-when-blank, so the one precedence rule holds with no exception: explicit
    run parameter > project configuration. Runs after ``_resolve_params`` so
    substitution, the Plan's ``workflow_params``, and the resume path all see the
    resolved value.

    Also the one place a CALLER-supplied value is checked against the recipe's
    ``options``. A recipe declares these parameters ``type: string`` rather than
    ``select`` on purpose: ``_resolve_params`` resolves an optional parameter with
    no default to ``""``, and ``""`` is never in an ``options`` list, so a
    ``select`` would refuse every run that left the value to the configuration.
    """
    resolved = profile.scalars or {}
    for declared in spec.scalars:
        key = str(declared["name"]).strip()
        if resolved.get(key) and not str(values.get(key) or "").strip():
            values[key] = resolved[key]
        final = str(values.get(key) or "").strip()
        options = declared.get("options")
        if final and isinstance(options, list) and options:
            allowed = [str(o) for o in options]
            if final not in allowed:
                return f"parameter {key!r} must be one of {allowed} (got {final!r})"
    return ""


async def _resolve_profile(recipe: Any, values: dict[str, Any], user_dir: Path) -> _Profile:
    """Resolve, read and validate a recipe's project profile, in-process.

    The alternative — having the run resolve it with shell and read it back — was
    tried and is what this replaces. Two things killed it. The resolution chain is
    model-executed prose, so it can simply be skipped, and a run that skips it
    falls back to the model's own provider habits: a PR opened against a guessed
    target branch looks exactly like a correct one. And the profile arrived as a
    mid-conversation tool result, which compaction is free to drop, so the recipe
    needed a re-read ritual at every step — another unverifiable paragraph.

    Returning the TEXT (rather than staging a file the run reads) is what fixes the
    second half: the caller concatenates it onto the recipe body, so it rides in
    the first user message, which the compactor protects, on ``run`` and ``resume``
    alike.

    TWO PASSES, because the two layers merge by different rules. Scalars accumulate
    bottom-up across every candidate so a repository can override one value; prose
    takes the highest tier that has a body, whole, so an operating manual is never
    half one provider's and half another's.

    A candidate whose body is empty after its frontmatter contributes scalars and
    does NOT compete for the prose layer. That rule is the entire ergonomic point:
    it is what lets a repository ship three lines of frontmatter and inherit the
    bundled provider profile's prose whole.

    Opt-in is the recipe's own ``profile:`` frontmatter block, which is also where
    every value this function enforces comes from. Without it the recipe gets no
    configuration resolution and this subsystem stays out of its way — which is what
    keeps one recipe's contract from being imposed on every other one.
    """
    spec = _profile_spec(recipe)
    if not spec.declared:
        return _Profile("", "", "")

    project = str(values.get("project") or "").strip()
    repo = str(values.get("repo_path") or "").strip()

    # Highest tier first. The bool is "missing is an error": a named project is an
    # instruction, so silently using a different profile is the whole class of
    # failure this function exists to remove. It must also outrank the repository's
    # own file — `repo_path` is required, so ordering the repository first would
    # let ANY target repo that happens to ship the recipe's `repo_file` shadow the
    # profile the caller asked for, handing the decision to the least trusted input
    # in the chain: repository content, read in-process, that never passes risk
    # scoring, the hook pipeline, the leak scan, or the audit log.
    candidates: list[tuple[str, Path, bool]] = []
    if project:
        named, name_error = _project_profile_path(project, user_dir)
        if name_error:
            return _Profile("", "", f"the project parameter {name_error}")
        candidates.append((f"project profile {project!r}", named, True))
    elif derived := _derived_project_name(repo):
        # No name given, so look one up BY REPOSITORY — the lookup the setup
        # directive's output depends on. Missing here is NOT an error, unlike an
        # explicit name: the caller named nothing, so there is nothing to silently
        # substitute for, and falling through to the repository's own file is the
        # correct next question.
        derived_path, derived_error = _project_profile_path(derived, user_dir)
        if not derived_error:
            candidates.append(
                (f"project profile {derived!r} (derived from the checkout)", derived_path, False)
            )
    kind = ""
    if repo:
        if spec.repo_file:
            candidates.append(("the repository's own profile", Path(repo) / spec.repo_file, False))
        kind = await _remote_kind(repo)
        candidates.append((f"bundled {kind} profile", _BUNDLED_PROFILES / f"{kind}.md", False))

    layers: list[tuple[str, dict[str, str], str]] = []
    for label, path, required in candidates:
        text, error = _read_profile_candidate(path)
        if error:
            return _Profile("", "", error)
        if not text:
            if required:
                return _Profile(
                    "", "", f"no profile at {path} (from the project parameter {project!r})"
                )
            continue
        source = f"{label} ({path})"
        meta, body, split_error = _split_frontmatter(text)
        if split_error:
            return _Profile("", "", f"the profile at {source} {split_error}")
        scalars, scalar_error = _profile_scalars(meta, spec)
        if scalar_error:
            return _Profile("", "", f"the profile at {source} {scalar_error}")
        layers.append((source, scalars, body))

    merged: dict[str, str] = {}
    for _, scalars, _ in reversed(layers):
        merged.update(scalars)

    for source, _, body in layers:
        if body.strip():
            return _resolved_profile(body, source, merged, kind)

    tried = (
        ", ".join(str(p) for _, p, _ in candidates) or "no candidate paths (repo_path was empty)"
    )
    return _Profile("", "", f"no project profile found. Tried: {tried}")


def _resolved_profile(text: str, source: str, scalars: dict[str, str], provider: str) -> _Profile:
    """Assemble the resolved configuration.

    There used to be a required-sections check here, enforcing a hardcoded list of
    one recipe's headings. It is gone, and the reason it could go is the same test
    the rest of this design uses: does getting it wrong fail VISIBLY? A profile
    missing its auth or PR section leaves the run with no command to run, and the
    recipe that wanted that section already forbids inventing one — so the run stops
    on its own. Enforcing it here bought a late-vs-early refusal and cost the generic
    tool a list of Chinese headings that mean nothing to any other recipe.
    """
    return _Profile(text, source, "", dict(scalars), provider)


def _project_profile_path(project: str, user_dir: Path) -> tuple[Path, str]:
    """Where a named project's configuration lives. Returns ``(path, error)``.

    Shared by the reader and the writer on purpose: the same validation that
    refuses a traversal on the way in refuses it on the way out, so
    ``init_project`` cannot create a file the resolver would then reject.
    """
    if not _PROJECT_NAME_RE.match(project):
        return Path(), (
            f"{project!r} is not a valid project name; it must start with a letter or "
            "digit and contain only letters, digits, '.', '_' and '-' (no path separators)"
        )
    named = user_dir / "profiles" / f"{project}.md"
    # Belt and braces: the regex already forbids separators, so this only fires if
    # someone loosens it. Cheap, and the failure it guards is an in-process read of
    # an arbitrary local file.
    #
    # LEXICAL, not `resolve()`. Resolving would follow a symlink out of the
    # directory and refuse it here — correct outcome, wrong guard: symlinks are
    # `_read_profile_candidate`'s job and it names them, while this one would report
    # a confusing "escapes" for a file the author can see sitting right there.
    # `normpath` collapses `..` without touching the filesystem, which is exactly
    # the level a traversal check belongs at.
    root = Path(os.path.normpath(user_dir / "profiles"))
    if not Path(os.path.normpath(named)).is_relative_to(root):
        return Path(), f"{project!r} escapes {root}"
    return named, ""


def _derived_project_name(repo_path: str) -> str:
    """The project name a checkout implies, for a caller who did not name one.

    This is what makes "this repository has no configuration yet" a sentence the
    harness can act on, and it is what lets the setup directive write a file the
    NEXT run finds by itself. Without it the user would have to remember to pass
    ``project=`` forever, and a setup flow whose output you must keep quoting is
    not a setup flow.
    """
    if not repo_path:
        return ""
    slug = slugify(Path(repo_path.rstrip("/\\")).name)
    return slug if _PROJECT_NAME_RE.match(slug) else ""


def _project_setup_directive(
    *,
    recipe_name: str,
    repo_path: str,
    project: str,
    missing: list[str],
    provider: str,
    spec: _ProfileSpec,
) -> str:
    """Refusal that onboards instead of just complaining.

    The FRAME is generic — refuse, propose, confirm, write, self-check — and every
    word of subject matter comes from the recipe's own ``profile:`` block. That is
    the split: any recipe with a configuration contract gets this onboarding, and
    none of them puts its nouns in this file.

    Follows the shape the other directives in this module use: numbered steps, a
    literal tool call per step, ``<UPPER_SNAKE>`` placeholders, and a mandatory
    read-back self-check. Every placeholder inside a shell command is quoted and no
    command carries ``;`` or ``&&``, so a user with terminal auto-approve is not
    surprised.

    ``json.dumps`` for interpolated values rather than an f-string: a checkout path
    can carry a quote, and this string is handed to a model that will paste pieces
    of it into commands.
    """
    repo_q = json.dumps(repo_path, ensure_ascii=False)
    which = "、".join(f"`{key}`" for key in missing)
    by_name = {str(s["name"]).strip(): s for s in spec.scalars}

    what: list[str] = []
    how: list[str] = []
    for key in missing:
        declared = by_name.get(key, {})
        help_text = str(declared.get("help") or "").strip()
        what.append(f"- **`{key}`** —— {help_text}" if help_text else f"- **`{key}`**")
        found = declared.get("discover")
        command = ""
        if isinstance(found, dict):
            command = str(found.get(provider) or found.get("*") or "").strip()
        note = str(declared.get("discover_note") or "").strip()
        if command:
            how.append(
                f"   - `{key}`：跑 `{command}` 得到建议值。" + (f"\n     {note}" if note else "")
            )
        else:
            how.append(
                f"   - `{key}`：**这个 provider 没有可用的发现命令，必须问用户。**"
                + (f"\n     {note}" if note else "")
            )

    # A checkout whose basename slugifies to nothing — `repo_path="."` is the
    # reachable case — still has to be refused. Bailing out here instead would make
    # an underivable name a free pass past the one gate that enforces these values,
    # and a gate with a quiet escape hatch is worse than no gate: it reads as covered.
    if project:
        project_q = json.dumps(project, ensure_ascii=False)
        naming = f"   配置会落在项目名 {project_q} 下（由检出目录名推导，用户想改就用用户给的）。"
    else:
        project_q = "'<PROJECT>'"
        naming = (
            f"   **{repo_q} 推导不出可用的项目名**（比如它是 `.` 这样的相对路径）。"
            "让用户给一个 `project=` 名字，或者改用仓库的绝对路径重跑 —— 不要自己编一个。"
        )
    assignments = ", ".join(f"'{key}': '<{key.upper()}>'" for key in missing)
    elsewhere = f"\n5. 最后告诉用户一句：{spec.elsewhere}" if spec.elsewhere else ""
    what_block = "\n".join(what)
    how_block = "\n".join(how)
    return f"""

---
【项目配置缺失】{repo_q} 的 {recipe_name} 项目配置没有声明 {which}。**这个 run 没有启动**，
后台任务一个都没建。不要重试、不要换个参数再试、不要替用户猜一个值填进去 —— 先把配置建起来。

缺的这些值**没有默认值**，任何一层都不提供：

{what_block}

按以下步骤走，不要跳：
1. **先提出建议值，别空手问。**
{how_block}
2. 把建议值连同理由一起给用户确认。用户改了就用用户的。
{naming}
3. `workflow(action='init_project', name='{recipe_name}', project={project_q}, repo_path={repo_q}, scalars={{{assignments}}})` 写入配置。
   已经存在同名配置（只缺一部分值的情况）要加 `replace=true` —— 它会保留文件里已有的正文笔记，只重写 frontmatter。
4. **建完自检（必做，别跳）**：把工具回显的路径念给用户，然后重发原来那次
   `workflow(action='run', name='{recipe_name}', ...)`。这次它应该真的启动。仍然被拒就把拒绝原文
   念出来，别自己改配置反复试。{elsewhere}
---"""


def _project_setup_hint(recipe: Any, name: str, values: dict[str, Any], profile: _Profile) -> str:
    """Onboarding directive when a required scalar is unresolved, else "".

    Conditions ordered cheapest first and every failure degrading to "" — the same
    shape ``_societas_setup_hint`` uses, for the same reason: a detector that can
    itself fail must never be the thing that blocks a run.

    Inert for any recipe with no ``profile:`` block, which is every recipe that
    never asked for a configuration contract.
    """
    try:
        spec = _profile_spec(recipe)
        if not spec.declared:
            return ""
        missing = [
            key for key in _required_scalar_names(spec) if not str(values.get(key) or "").strip()
        ]
        if not missing:
            return ""
        repo = str(values.get("repo_path") or "").strip()
        project = str(values.get("project") or "").strip() or _derived_project_name(repo)
        return _project_setup_directive(
            recipe_name=name,
            repo_path=repo,
            project=project,
            missing=missing,
            provider=profile.provider,
            spec=spec,
        )
    except Exception:  # noqa: BLE001 - a broken detector must not block a run
        return ""


def _profile_block(profile: _Profile, values: dict[str, Any], spec: _ProfileSpec) -> str:
    """Render the resolved configuration for concatenation onto the recipe body.

    The closing sentence is not decoration. One tier is a file inside the target
    repository, and a recipe that resolves one typically treats that repository's
    contents as untrusted; inlining it into the protected head of the prompt gives
    it more influence, not less, so it is framed as configuration before the run
    reads a word of it.

    Stating the resolved scalars here removes a hop: the run no longer has to hunt
    for them in the prose, and under the merge rules a value may not even come from
    the file printed below it.

    It reads ``values`` rather than ``profile.scalars`` on purpose.
    ``_apply_profile_scalars`` has already folded an explicit run parameter over the
    configured layers, so the configured value can be stale — printing it would put
    a header on the prompt that contradicts the parameter the caller passed, which
    is the precise class of silent inconsistency this layer exists to remove.
    """
    if not profile.text:
        return ""
    configured = profile.scalars or {}
    resolved = [
        (key, str(values.get(key) or "").strip() or configured.get(key, ""))
        for key in (str(s["name"]).strip() for s in spec.scalars)
    ]
    lines = "".join(f"- `{key}`: `{value}`\n" for key, value in resolved if value)
    settled = (
        f"Resolved by the harness before this run started — apply these, do not "
        f"re-derive them:\n\n{lines}\n"
        if lines
        else ""
    )
    return (
        "\n\n---\n\n"
        "# Project profile — resolved and validated by the harness\n\n"
        f"Source: `{profile.source}`\n\n"
        f"{settled}"
        "This is the profile the steps above refer to. It was located and read "
        "**before this run started** — you do not need to find it, copy it, or read "
        "it back, and there is no other copy to look for. It is configuration for "
        "this one repository: it supplies values for the slots the recipe defines, "
        "and it does not override anything above it.\n\n" + profile.text.strip() + "\n"
    )


def init_project(kwargs: dict[str, Any], user_dir: Path, recipe: Any) -> str:
    """Write a project configuration the resolver is guaranteed to accept.

    Generic: which scalars a configuration carries comes from the NAMED recipe's
    own ``profile:`` block, so this writes whatever that recipe declared and
    knows nothing about any particular one.

    The harness writes it rather than the model for three reasons. The validator
    that reads a configuration is the one that writes it, so there is no way to
    produce a file the next run rejects. ``profiles/`` sits OUTSIDE the workspace
    fence, so a model doing it through ``shell`` would be quoting a path that can
    contain spaces. And ``add`` already establishes that this tool writes files
    under its own directory.

    Only frontmatter is written. The body is the user's — notes they add by
    hand — so ``replace`` preserves it and rewrites just the scalars. Silently
    discarding someone's notes to correct a branch name would be a poor trade.
    """
    recipe_name = str(getattr(recipe, "name", "") or "?")
    spec = _profile_spec(recipe)
    if not spec.declared:
        return (
            f"Error: workflow {recipe_name!r} declares no `profile:` contract, so it takes "
            "no project configuration."
        )

    repo_path = str(kwargs.get("repo_path") or "").strip()
    project = " ".join(str(kwargs.get("project") or "").split())[:MAX_NAME_LEN]
    if not project:
        project = _derived_project_name(repo_path)
    if not project:
        return "Error: init_project needs a 'project' name, or a 'repo_path' to derive one from."
    path, name_error = _project_profile_path(project, user_dir)
    if name_error:
        return f"Error: {name_error}."

    # Accept them nested under `scalars` (the declared shape) or as top-level
    # kwargs, because the setup directive spells out a call and a model that
    # flattens it should not be punished for a shape this tool does not care
    # about.
    nested = kwargs.get("scalars")
    nested = nested if isinstance(nested, dict) else {}
    supplied = {}
    for declared in spec.scalars:
        key = str(declared["name"]).strip()
        raw = nested.get(key)
        if raw is None:
            raw = kwargs.get(key)
        supplied[key] = str(raw or "").strip()
    missing = [key for key in _required_scalar_names(spec) if not supplied.get(key, "").strip()]
    if missing:
        return (
            f"Error: init_project needs {missing} for workflow {recipe_name!r}. They are "
            "required and nothing supplies a default, so writing a configuration "
            "without them would only move the refusal to the next run."
        )
    scalars, scalar_error = _profile_scalars({k: v for k, v in supplied.items() if v}, spec)
    if scalar_error:
        return f"Error: the configuration {scalar_error}."

    replace = as_bool(kwargs.get("replace"))
    body = ""
    if path.exists():
        if not replace:
            return (
                f"Error: {path} already exists. Pass replace=true to update it — "
                "your notes in the file body are kept."
            )
        existing, read_error = _read_profile_candidate(path)
        if read_error:
            return f"Error: {read_error}."
        _, body, split_error = _split_frontmatter(existing)
        if split_error:
            return f"Error: the existing configuration at {path} {split_error}."

    frontmatter = yaml.safe_dump(scalars, allow_unicode=True, sort_keys=False, width=10**6).strip()
    content = f"---\n{frontmatter}\n---\n{body.lstrip()}"
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return f"Error: could not create {path.parent}: {exc}"
    try:
        if replace:
            tmp: Path | None = None
            try:
                with tempfile.NamedTemporaryFile(
                    dir=path.parent,
                    suffix=".md.tmp",
                    delete=False,
                    mode="w",
                    encoding="utf-8",
                ) as fh:
                    tmp = Path(fh.name)
                    fh.write(content)
                os.replace(tmp, path)
            finally:
                if tmp is not None:
                    tmp.unlink(missing_ok=True)
        else:
            with open(path, "x", encoding="utf-8") as fh:
                fh.write(content)
    except FileExistsError:
        return f"Error: {path} already exists. Pass replace=true to update it."
    except OSError as exc:
        return f"Error: could not write {path}: {exc}"

    settled = "".join(f"   {key}: {value}\n" for key, value in scalars.items())
    tail = f"\n{spec.elsewhere}" if spec.elsewhere else ""
    return (
        f"✅ Project {project!r} configured at {path}\n"
        f"{settled}"
        f"Runs of {recipe_name!r} against this checkout now resolve it without a "
        f"`project` parameter.{tail}"
    )


class Prepared(NamedTuple):
    """What the calling tool needs, and nothing that names this subsystem.

    ``refusal`` non-empty means the caller returns it and starts nothing.
    ``prompt_suffix`` is appended to the substituted recipe body.
    """

    refusal: str = ""
    prompt_suffix: str = ""
    log: str = ""


async def prepare_run(recipe: Any, name: str, values: dict[str, Any], user_dir: Path) -> Prepared:
    """Resolve a recipe's project configuration, or refuse the run.

    Mutates ``values`` to fill parameter slots the caller left empty — the same
    contract ``_fill_agent_repo_path`` already has — so substitution, the Plan's
    persisted params and the resume path all see the resolved values.

    Inert for a recipe with no ``profile:`` block, which is every recipe that never
    asked for a configuration contract.
    """
    spec = _profile_spec(recipe)
    if not spec.declared:
        return Prepared()
    profile = await _resolve_profile(recipe, values, user_dir)
    if profile.error:
        return Prepared(refusal=f"Error: {profile.error}.")
    scalar_error = _apply_profile_scalars(values, profile, spec)
    if scalar_error:
        return Prepared(refusal=f"Error: {scalar_error}.")
    # Nothing supplies a default for a declared-required scalar, so an unresolved one
    # refuses HERE rather than letting the run reach its first step and stop there.
    setup = _project_setup_hint(recipe, name, values, profile)
    if setup:
        return Prepared(refusal=setup)
    return Prepared(
        prompt_suffix=_profile_block(profile, values, spec),
        log=f"profile resolved from {profile.source}" if profile.text else "",
    )


SCHEMA_PROPERTIES: dict[str, Any] = {
    "project": {
        "type": "string",
        "description": (
            "Names a per-project configuration under the workflows directory. Omit "
            "it and one is derived from 'repo_path', which is also how a run finds "
            "the file without naming one."
        ),
    },
    "repo_path": {
        "type": "string",
        "description": "For 'init_project': the checkout this configuration describes.",
    },
    "scalars": {
        "type": "object",
        "description": (
            "For 'init_project': the values the named recipe's `profile:` block "
            "declares, as {name: value}. Which names those are, what each means and "
            "which are required all come from that recipe. The refusal that sent you "
            "here names the ones it needs."
        ),
    },
}
