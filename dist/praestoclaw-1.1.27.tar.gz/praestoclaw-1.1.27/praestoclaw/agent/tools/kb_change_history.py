"""Read persisted knowledge-base change records for the current conversation.

The publication acknowledgement is intentionally terse.  This tool is the
durable, on-demand counterpart: it lets a later turn answer questions about a
change without putting the full receipt back into every conversation context.

Access is structurally conversation-scoped.  The caller cannot supply a cid;
the store is always constructed from the trusted turn metadata injected by the
runtime.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.kb.draft import STATUS_PUBLISHED, CurationTask, CurationTaskStore
from praestoclaw.security.kb_curation import kb_curation_is_active
from praestoclaw.security.risk import RiskAssessment, RiskScore

_ACTIONS = ("latest", "show", "file")


def _text(value: Any) -> str:
    return str(value or "").strip()


class KbChangeHistoryTool(Tool):
    """Query curation tasks owned by the current Teams conversation."""

    risk_range = (1, 2)

    def __init__(self, *, tasks_root: Path | None = None) -> None:
        super().__init__()
        self._tasks_root = tasks_root

    @property
    def name(self) -> str:
        return "kb_change_history"

    @property
    def description(self) -> str:
        return (
            "Read previously saved team knowledge-base changes for this Teams "
            "conversation. 'latest' returns the most recently published change "
            "(never an active draft); 'show' returns a task's structured summary, "
            "knowledge units/evidence, approvals and publish receipt; 'file' "
            "returns one saved file's content and summary. Identify a change by "
            "task_id or published commit. Read-only and conversation-scoped."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=30, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        if _text(args.get("action")) == "file":
            return RiskScore(2, reason="Read saved knowledge-base file content for this group")
        return RiskScore(1, reason="Read saved knowledge-base change metadata for this group")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": list(_ACTIONS),
                    "description": (
                        "latest = most recent published change; show = full structured "
                        "change record; file = saved content and summary for one path."
                    ),
                },
                "task_id": {
                    "type": "string",
                    "description": "Saved curation task id. Optional for latest.",
                },
                "commit": {
                    "type": "string",
                    "description": "Published/proposal commit SHA (or an unambiguous prefix).",
                },
                "path": {
                    "type": "string",
                    "description": "For file: exact repository-relative saved path.",
                },
            },
            "required": ["action"],
        }

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata") or {}
        if not kb_curation_is_active(metadata):
            return "kb_change_history is only available in a Teams group experiment or personal Teams chat."

        cid = _text(metadata.get("cid"))
        if not cid:
            return "Error: kb_change_history needs a Teams conversation id on this turn."

        action = _text(kwargs.get("action"))
        if action not in _ACTIONS:
            return f"Error: action must be one of {', '.join(_ACTIONS)}."

        store = CurationTaskStore(cid, root=self._tasks_root)
        if action == "latest":
            task = self._latest_published(store)
            if task is None:
                return self._dump(
                    {"found": False, "reason": "No published KB change for this conversation."}
                )
            return self._dump({"found": True, "change": self._view(task)})

        task, error = self._resolve_task(
            store,
            task_id=_text(kwargs.get("task_id")),
            commit=_text(kwargs.get("commit")),
        )
        if error:
            return error
        if task is None:
            return "Error: no matching KB change was found for this conversation."

        if action == "show":
            return self._dump({"found": True, "change": self._view(task)})
        return self._file(task, _text(kwargs.get("path")))

    @staticmethod
    def _latest_published(store: CurationTaskStore) -> CurationTask | None:
        published = [task for task in store.all_tasks() if task.status == STATUS_PUBLISHED]
        if not published:
            return None

        def publication_key(task: CurationTask) -> tuple[str, str, str]:
            data = task.to_dict()
            published = data.get("published")
            receipt = published if isinstance(published, dict) else {}
            published_at = _text(data.get("published_at")) or _text(receipt.get("published_at"))
            published_at = published_at or _text(receipt.get("at")) or _text(data.get("updated_at"))
            return published_at, _text(data.get("updated_at")), task.task_id

        return max(published, key=publication_key)

    def _resolve_task(
        self, store: CurationTaskStore, *, task_id: str, commit: str
    ) -> tuple[CurationTask | None, str]:
        if task_id and commit:
            return None, "Error: pass either task_id or commit, not both."
        if task_id:
            task = store.load(task_id)
            # ``CurationTaskStore.load`` sanitises filenames. Confirm the id as
            # well so a crafted alias cannot resolve a differently named task.
            if task is None or task.task_id != task_id:
                return None, "Error: no matching KB change was found for this conversation."
            return task, ""
        if not commit:
            return None, "Error: show/file needs task_id or commit."

        needle = commit.casefold()
        matches = [
            task
            for task in store.all_tasks()
            if any(candidate.casefold().startswith(needle) for candidate in self._commit_ids(task))
        ]
        if not matches:
            return None, "Error: no matching KB change was found for this conversation."
        if len(matches) > 1:
            return None, "Error: commit prefix is ambiguous in this conversation; use a longer SHA."
        return matches[0], ""

    @staticmethod
    def _commit_ids(task: CurationTask) -> set[str]:
        data = task.to_dict()
        published = data.get("published")
        receipt = published if isinstance(published, dict) else {}
        values = {
            data.get("proposal_sha"),
            data.get("preview_sha"),
            data.get("published_sha"),
            receipt.get("commit"),
            receipt.get("commit_sha"),
            receipt.get("sha"),
            receipt.get("proposal_sha"),
            receipt.get("published_sha"),
        }
        return {_text(value) for value in values if _text(value)}

    @staticmethod
    def _change_view(change: dict[str, Any], task_data: dict[str, Any]) -> dict[str, Any]:
        path = _text(change.get("path"))
        inherited: dict[str, Any] = {}
        for key in ("file_summaries", "change_summaries"):
            mapping = task_data.get(key)
            if isinstance(mapping, dict) and isinstance(mapping.get(path), dict):
                inherited.update(mapping[path])

        summary = change.get("summary") or inherited.get("summary") or change.get("rationale") or ""
        details = change.get("details") or inherited.get("details") or change.get("rationale") or ""
        content = _text(change.get("content"))
        return {
            "path": path,
            "operation": _text(change.get("operation")),
            "summary": summary,
            "details": details,
            "rationale": change.get("rationale") or "",
            "units": list(change.get("units") or []),
            "bytes": len(content.encode("utf-8")),
        }

    @classmethod
    def _view(cls, task: CurationTask) -> dict[str, Any]:
        data = task.to_dict()
        changes = [item for item in (data.get("changes") or []) if isinstance(item, dict)]
        approval_fields = {
            key: value
            for key, value in data.items()
            if ("approval" in key or key == "decisions") and value not in (None, "", [], {})
        }
        receipt = data.get("published") or data.get("publish_receipt") or None
        return {
            "task_id": task.task_id,
            "status": task.status,
            "created_at": data.get("created_at") or "",
            "updated_at": data.get("updated_at") or "",
            "published_at": data.get("published_at")
            or (receipt.get("published_at", "") if isinstance(receipt, dict) else ""),
            "conversation_name": data.get("conversation_name") or "",
            "started_by": data.get("started_by") or "",
            "user_request": data.get("user_request") or "",
            "capture_path": data.get("capture_path") or "",
            "repo": data.get("repo") or "",
            "base_head": data.get("base_head") or "",
            "overview": data.get("overview") or data.get("change_overview") or "",
            "commit_message": data.get("commit_message") or "",
            "proposal_sha": data.get("proposal_sha") or data.get("preview_sha") or "",
            "published_sha": data.get("published_sha")
            or (receipt.get("commit", "") if isinstance(receipt, dict) else ""),
            "files": [cls._change_view(change, data) for change in changes],
            "units": list(data.get("units") or []),
            "blockers": list(data.get("blockers") or []),
            "approvals": approval_fields,
            "publish_attempts": list(data.get("publish_attempts") or []),
            "published": receipt,
        }

    def _file(self, task: CurationTask, path: str) -> str:
        if not path:
            return "Error: file needs a path."
        wanted = path.replace("\\", "/")
        data = task.to_dict()
        for raw in data.get("changes") or []:
            if not isinstance(raw, dict) or _text(raw.get("path")).replace("\\", "/") != wanted:
                continue
            view = self._change_view(raw, data)
            view["content"] = str(raw.get("content") or "")
            return self._dump({"found": True, "task_id": task.task_id, "file": view})
        return f"Error: path '{path}' is not part of KB change '{task.task_id}'."

    @staticmethod
    def _dump(payload: dict[str, Any]) -> str:
        return json.dumps(payload, ensure_ascii=False, indent=2)


__all__ = ["KbChangeHistoryTool"]
