"""Durable per-run records for on-demand ``workflow run`` runs (6d-2).

Scheduled workflow runs already have a durable history via the cron subsystem
(``SchedulerService.get_history`` → ``cron/runs/<job>.jsonl``). On-demand runs
(``workflow run``) are tracked only in-memory by ``BackgroundTaskManager`` and
were lost on restart. This store gives them the same append-only history —
``<data_dir>/workflows/runs/<recipe>.jsonl`` — so ``workflow status`` can show
"what did this recipe do last time" across restarts (audit + post-mortem), and
6d-3 (resume) has a durable record of which runs finished.

Mirrors the cron run-history shape (``triggered_at`` / ``status`` /
``result_preview`` / ``duration_s`` / ``error_type``) so both render the same,
plus a ``finished_at`` wall-clock stamp (``triggered_at`` is derived as
``finished_at - duration``). Best-effort throughout: a read/write failure never
raises into the caller — audit must never break a run or its status view.
"""

from __future__ import annotations

import json
import re
import threading
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from hashlib import sha256
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

if TYPE_CHECKING:
    from praestoclaw.host.background_tasks import BackgroundTask


def _safe_filename(name: str) -> str:
    """Sanitize a recipe name into a collision-resistant ``.jsonl`` stem.

    Appends a short stable hash of the ORIGINAL name so two distinct names that
    sanitize to the same stem (e.g. ``a/b`` vs ``a:b`` → ``a_b``) don't merge
    their run histories.
    """
    safe = re.sub(r"[^A-Za-z0-9_\-.]", "_", name)[:180] or "default"
    return f"{safe}-{sha256(name.encode('utf-8')).hexdigest()[:8]}"


class WorkflowRunStore:
    """Append-only per-recipe run history under ``workflows/runs/<recipe>.jsonl``."""

    MAX = 50  # entries kept per recipe (oldest pruned)

    def __init__(self, data_dir: Path | None = None) -> None:
        if data_dir is None:
            from praestoclaw.utils.helpers import get_data_dir

            data_dir = get_data_dir()
        # Lazily created on first record() — constructing the store does NOT
        # touch the filesystem, so wiring it when the feature is off is free.
        self._root = data_dir / "workflows" / "runs"
        # record() runs from a thread pool (BackgroundTaskManager offloads it),
        # and _prune rewrites the whole file — serialize append+prune so
        # concurrent records for the same recipe can't interleave / lose writes.
        self._lock = threading.Lock()

    def record(
        self,
        recipe: str,
        task_id: str,
        status: str,
        *,
        result: str = "",
        error_type: str = "",
        duration_s: float = 0.0,
        workflow_params: dict[str, Any] | None = None,
    ) -> None:
        """Append one terminal run record. Best-effort — never raises."""
        try:
            now = datetime.now(UTC)
            # Round once and use the SAME value for both triggered_at and
            # duration_s so ``finished_at - duration_s == triggered_at`` holds.
            dur = round(max(float(duration_s), 0.0), 2)
            rec: dict[str, Any] = {
                "task_id": str(task_id),
                "triggered_at": (now - timedelta(seconds=dur)).isoformat(),
                "finished_at": now.isoformat(),
                "status": str(status),
                "result_preview": (str(result) if result else "")[:500],
                "duration_s": dur,
            }
            if error_type:
                rec["error_type"] = str(error_type)
            if workflow_params:
                rec["workflow_params"] = dict(workflow_params)
            path = self._root / f"{_safe_filename(str(recipe))}.jsonl"
            with self._lock:
                self._root.mkdir(parents=True, exist_ok=True)
                with path.open("a", encoding="utf-8") as f:
                    f.write(json.dumps(rec, ensure_ascii=False) + "\n")
                self._prune(path)
        except Exception as exc:  # noqa: BLE001 - audit is best-effort
            logger.debug("WorkflowRunStore.record failed for {!r}: {}", recipe, exc)

    def _prune(self, path: Path) -> None:
        """Keep only the last ``MAX`` lines — **atomically** (temp + replace).

        The atomic rename means a concurrent lock-free ``get_history`` read never
        sees a half-rewritten file (it opens either the pre- or post-prune inode
        in full), so reads don't need to take ``self._lock`` and thus can't block
        the event-loop thread that ``status`` calls them from.
        """
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
            if len(lines) > self.MAX:
                tmp = path.with_suffix(".jsonl.tmp")
                tmp.write_text("\n".join(lines[-self.MAX :]) + "\n", encoding="utf-8")
                tmp.replace(path)  # atomic on POSIX/Windows
        except Exception:  # noqa: BLE001
            pass

    def get_history(self, recipe: str, limit: int = 20) -> list[dict[str, Any]]:
        """Return the last ``limit`` run records for ``recipe`` (oldest→newest).

        Lock-free: ``_prune`` rewrites atomically (see there), and each line is
        parsed independently so a partial trailing line from an in-flight append
        is skipped rather than corrupting the result.
        """
        if limit <= 0:
            return []  # ``entries[-0:]`` would surprisingly return everything.
        path = self._root / f"{_safe_filename(str(recipe))}.jsonl"
        if not path.is_file():
            return []
        entries: list[dict[str, Any]] = []
        try:
            for raw in path.read_text(encoding="utf-8").splitlines():
                line = raw.strip()
                if not line:
                    continue
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        except OSError:
            return []
        # Cap the read at MAX too, so a file that somehow overgrew the cap
        # (e.g. a best-effort _prune that failed) can't return an oversized list.
        return entries[-min(limit, self.MAX) :]


# Module singleton so the runtime wires the SAME store to both the recorder
# (BackgroundTaskManager) and the reader (WorkflowTool status).
_default_store: WorkflowRunStore | None = None


def get_workflow_run_store() -> WorkflowRunStore:
    global _default_store  # noqa: PLW0603
    if _default_store is None:
        _default_store = WorkflowRunStore()
    return _default_store


def plan_waiting_for_approval(plan: Any) -> bool:
    """Whether an incomplete persisted plan stopped at a user checkpoint."""
    try:
        done, total = plan.progress
    except Exception:  # noqa: BLE001 - duck-typed persisted plan
        return False
    checkpoints = getattr(plan, "checkpoints", None) or []
    if not (total and done < total and checkpoints):
        return False
    last = checkpoints[-1]
    # An approved checkpoint keeps asked_user=true (no follow-up checkpoint is
    # appended), so require it to still be UNRESOLVED to count as "waiting".
    return bool(getattr(last, "asked_user", False) and not getattr(last, "resolved", False))


def make_run_recorder(
    store: WorkflowRunStore,
    *,
    active_plans_fn: Callable[[], list[Any]] | None = None,
) -> Callable[[BackgroundTask], None]:
    """Build the ``run_recorder`` callback BackgroundTaskManager fires on terminal.

    Maps a finished ``BackgroundTask`` (workflow run) to a durable record:
    ``completed`` → ``success`` unless its persisted plan stopped at a user
    checkpoint, which is ``waiting_approval``; any other terminal state →
    ``error`` with the state as ``error_type`` and the error/result text as the
    preview.
    """

    def _record(task: BackgroundTask) -> None:
        completed = task.state == "completed"
        waiting_approval = False
        incomplete = False
        disposition_status = ""
        if completed and active_plans_fn is not None:
            try:
                matching_plan = next(
                    (
                        plan
                        for plan in active_plans_fn()
                        if str(getattr(plan, "origin_task", "") or "") == task.task_id
                    ),
                    None,
                )
                if matching_plan is not None:
                    from praestoclaw.agent.tools.plan import get_plan_disposition

                    disposition = get_plan_disposition(matching_plan)
                    disposition_status = str(getattr(disposition, "value", disposition) or "")
                    waiting_approval = plan_waiting_for_approval(matching_plan)
                    try:
                        done, total = matching_plan.progress
                        incomplete = bool(total and done < total)
                    except Exception:  # noqa: BLE001 - duck-typed persisted plan
                        incomplete = False
            except Exception as exc:  # noqa: BLE001 - history is best-effort
                logger.debug("Workflow approval-state lookup failed for {}: {}", task.task_id, exc)
        status = (
            disposition_status
            if completed
            and disposition_status
            in {
                "parked",
                "callout_terminal",
            }
            else (
                "waiting_approval"
                if waiting_approval
                else ("incomplete" if incomplete else ("success" if completed else "error"))
            )
        )
        store.record(
            task.workflow or "",
            task.task_id,
            status,
            result=(task.result or "") if completed else (task.error or ""),
            error_type="" if completed else str(task.state),
            duration_s=task.elapsed_seconds,
            workflow_params=getattr(task, "workflow_params", None),
        )

    return _record
