"""Read-only mechanical validation for the bundled fix-bug reader protocol.

This stdlib-only module also runs by absolute filename with the host interpreter,
so a workflow targeting a non-Python repository needs no dependency installation.
It checks provenance and coordinates, not the reader's semantic classification.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shlex
import sys
from pathlib import Path, PurePosixPath
from typing import Any

_LABELS = ("OUTCOME", "REPORT", "PATH", "EXPECTED", "DECIDER", "TARGET", "PROOF")
_LANES = {
    "B0": ("RENDERED_PAIR", {"RENDERED_OURS"}),
    "B1": ("RESPONSE_PAIR", {"NONRENDERED"}),
    "B2": ("ARTIFACT_PAIR", {"NONRENDERED"}),
    "B3": ("SEAM_OBJECT", {"NONRENDERED", "RENDERED_ELSEWHERE"}),
    "B4": ("IN_PROCESS_OBJECT", {"NONRENDERED"}),
}
_ADO_TEXT_FIELDS = (
    "System.Title",
    "System.Description",
    "Microsoft.VSTS.TCM.ReproSteps",
    "Microsoft.VSTS.Common.AcceptanceCriteria",
)


def report_texts(issue: dict[str, Any]) -> dict[str, str]:
    """Keep decoded report fields separate; never concatenate fields or metadata."""
    texts = {f"/{key}": issue[key] for key in ("title", "body") if isinstance(issue.get(key), str)}
    fields = issue.get("fields")
    if isinstance(fields, dict):
        for key in _ADO_TEXT_FIELDS:
            if isinstance(fields.get(key), str):
                texts[f"/fields/{key}"] = fields[key]
    comments = issue.get("comments", [])
    prefix = "/comments"
    if isinstance(comments, dict):
        key = "nodes" if "nodes" in comments else "comments"
        comments = comments.get(key, [])
        prefix += f"/{key}"
    if isinstance(comments, list):
        for index, comment in enumerate(comments):
            if isinstance(comment, dict):
                for key in ("body", "text"):
                    if isinstance(comment.get(key), str):
                        texts[f"{prefix}/{index}/{key}"] = comment[key]
    return texts


def quote_sources(issue: dict[str, Any], quote: str) -> list[str]:
    """Exact substrings of individual decoded report lines, with field provenance."""
    return [
        f"{field}:{number}"
        for field, text in report_texts(issue).items()
        for number, line in enumerate(text.splitlines(), 1)
        if quote and quote in line
    ]


def _quoted(value: str) -> str:
    if len(value) < 3 or not value.startswith('"') or not value.endswith('"'):
        raise ValueError("Expected a non-empty double-quoted report value.")
    # These are protocol delimiters, not a second JSON serialization layer.
    return value[1:-1]


def _classification(response: str, issue: dict[str, Any]) -> tuple[dict[str, str], dict[str, Any]]:
    lines = response.splitlines()
    selected = [
        (i, line)
        for i, line in enumerate(lines)
        if line.startswith(tuple(f"{k}:" for k in _LABELS))
    ]
    if len(selected) != 7 or [line.split(":", 1)[0] for _, line in selected] != list(_LABELS):
        raise ValueError("Classification must contain each of the seven labels once, in order.")
    if selected[-1][0] - selected[0][0] != 6 or any(
        not line.startswith(f"{key}: ") for key, (_, line) in zip(_LABELS, selected)
    ):
        raise ValueError(
            "Classification must be one contiguous seven-line block with ': ' separators."
        )
    values = {key: line[len(key) + 2 :] for key, (_, line) in zip(_LABELS, selected)}
    report_kind, sep, quoted_report = values["REPORT"].partition(" — ")
    if not sep or not re.fullmatch(
        r"RENDERED_OURS|NONRENDERED|RENDERED_ELSEWHERE \S.*", report_kind
    ):
        raise ValueError("Invalid REPORT form.")
    quotes = {"REPORT": [_quoted(quoted_report)]}
    for key in ("PATH", "EXPECTED"):
        value = values[key]
        if value in {"MISSING", "N/A"}:
            continue
        if key == "EXPECTED" and value.startswith("CONFLICT — "):
            match = re.fullmatch(r'CONFLICT — (".+") <> (".+")', value)
            if match is None:
                raise ValueError("Invalid EXPECTED conflict form.")
            quotes[key] = [_quoted(match[1]), _quoted(match[2])]
        else:
            quotes[key] = [_quoted(value)]
    sources: dict[str, Any] = {}
    for key, entries in quotes.items():
        sources[key] = []
        for quote in entries:
            matches = quote_sources(issue, quote)
            if not matches:
                raise ValueError(f"{key}: quote is absent from decoded report fields.")
            sources[key].append({"quote": quote, "sources": matches})

    outcome, proof = values["OUTCOME"], values["PROOF"]
    decider, target = values["DECIDER"], values["TARGET"]
    if outcome in _LANES:
        lane, kinds = _LANES[outcome]
        valid = (
            proof == lane
            and report_kind.split(" ", 1)[0] in kinds
            and values["PATH"].startswith('"')
            and values["EXPECTED"].startswith('"')
            and decider.startswith("OURS — ")
            and target not in {"NONE", "N/A", "UNKNOWN"}
        )
    elif outcome == "UNKNOWN":
        valid = proof == "RETRY" and decider == "UNKNOWN" and target == "NONE"
    else:
        valid = proof == "CALLOUT" and target == "NONE"
        if outcome == "FEATURE":
            valid = valid and decider == "N/A"
        elif outcome == "X1":
            valid = (
                valid
                and decider == "N/A"
                and (
                    values["EXPECTED"] == "MISSING" or values["EXPECTED"].startswith("CONFLICT — ")
                )
            )
        elif outcome == "X2":
            valid = valid and bool(re.fullmatch(r"EXTERNAL — \S.* — .+", decider))
        elif outcome == "X3":
            valid = valid and decider.startswith("OURS — ")
        elif outcome == "NEEDS_EVIDENCE":
            valid = (
                valid
                and decider == "N/A"
                and values["PATH"] == "MISSING"
                and values["EXPECTED"].startswith('"')
            )
        else:
            valid = False
    if not valid:
        raise ValueError("Classification does not satisfy the OUTCOME / REPORT / PROOF matrix.")
    return values, sources


def _source_path(root: Path, name: str) -> Path:
    relative = PurePosixPath(name)
    if (
        relative.is_absolute()
        or "\\" in name
        or any(p.casefold() in {"..", ".git"} for p in relative.parts)
    ):
        raise ValueError("Source anchors must stay in the working tree and outside .git.")
    path = (root / name).resolve()
    if not path.is_relative_to(root) or any(
        p.casefold() == ".git" for p in path.relative_to(root).parts
    ):
        raise ValueError("Source anchor escapes the working tree or resolves into .git.")
    return path


def _anchor_parts(value: str) -> tuple[str, int, str]:
    match = re.fullmatch(r"([^:]+):([1-9][0-9]*) — (.+)", value)
    if match is None:
        raise ValueError("Anchor must be path:line — literal source line.")
    return match[1], int(match[2]), match[3]


def _anchor(root: Path, value: str) -> tuple[str, str | None]:
    name, number, literal = _anchor_parts(value)
    path = _source_path(root, name)
    if path.is_file():
        source = path.read_text(encoding="utf-8").splitlines()
        if number <= len(source) and source[number - 1] == literal:
            return value, None
    occurrences: list[tuple[Path, int, str]] = []
    visited: set[Path] = set()
    for directory, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = [d for d in dirs if d.casefold() != ".git"]
        for filename in files:
            candidate = Path(directory) / filename
            try:
                physical = _source_path(root, candidate.relative_to(root).as_posix())
                if physical in visited or not physical.is_file():
                    continue
                visited.add(physical)
                rows = physical.read_text(encoding="utf-8").splitlines()
            except (ValueError, OSError, UnicodeError):
                continue
            for index, row in enumerate(rows, 1):
                first = row.find(literal)
                if first < 0:
                    continue
                if occurrences or row.find(literal, first + 1) >= 0:
                    raise ValueError(
                        "Anchor literal is not a unique fixed substring of one physical source line."
                    )
                occurrences.append((physical, index, row))
    if not occurrences:
        raise ValueError(f"Anchor literal does not occur in the working tree ({name}:{number}).")
    physical, number, line = occurrences[0]
    canonical = f"{physical.relative_to(root).as_posix()}:{number} — {line}"
    return canonical, value


def validate_response(response: str, issue: dict[str, Any], root: Path) -> dict[str, Any]:
    """Return canonical coordinates without repairing quotes, literals or semantics."""
    try:
        values, sources = _classification(response, issue)
        anchors = {}
        for key in ("DECIDER", "TARGET"):
            value = values[key]
            if (key == "DECIDER" and value in {"N/A", "UNKNOWN"}) or (
                key == "TARGET" and value == "NONE"
            ):
                continue
            prefix = ""
            if key == "DECIDER":
                if value.startswith("OURS — "):
                    prefix, value = "OURS — ", value[len("OURS — ") :]
                else:
                    parts = value.split(" — ", 2)
                    prefix, value = " — ".join(parts[:2]) + " — ", parts[2]
            _anchor_parts(value)
            anchors[key] = (prefix, value)
        root = root.resolve(strict=True)
        if not root.is_dir():
            raise ValueError("Working tree must be a directory.")
        # Check every anchor before any source read, including a valid DECIDER
        # paired with a malformed or escaping TARGET.
        for _, value in anchors.values():
            _source_path(root, _anchor_parts(value)[0])
        changes = []
        for key, (prefix, value) in anchors.items():
            canonical, old = _anchor(root, value)
            values[key] = prefix + canonical
            if old is not None:
                changes.append({"field": key, "raw": prefix + old, "canonical": values[key]})
        return {
            "valid": True,
            "binding": "\n".join(f"{key}: {values[key]}" for key in _LABELS),
            "quote_sources": sources,
            "coordinate_changes": changes,
        }
    except (ValueError, OSError, UnicodeError) as exc:
        return {"valid": False, "error": str(exc)}


def runtime_hint() -> str:
    """The trusted host supplies its interpreter and installed script, including resume."""
    paths = [sys.executable, str(Path(__file__).resolve())]
    if sys.platform == "win32":
        command = "& " + " ".join("'" + p.replace("'", "''") + "'" for p in paths)
        shell = "powershell"
    else:
        command = shlex.join(paths)
        shell = "bash"
    return (
        "\n\n## Bundled Triage validator — host-resolved\n\n"
        f'Use shell with `shell="{shell}"` and this exact command prefix; append separately quoted '
        "`--issue <raw JSON path> --response <complete reader response path> "
        "--tree <recorded baseline tree>`. Do not use the target repository's "
        "Python, install dependencies, edit the validator, or generate a replacement.\n\n"
        f"```\n{command}\n```\n"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--issue", required=True, type=Path)
    parser.add_argument("--response", required=True, type=Path)
    parser.add_argument("--tree", required=True, type=Path)
    args = parser.parse_args()
    try:
        issue = json.loads(args.issue.read_text(encoding="utf-8"))
        if not isinstance(issue, dict):
            raise ValueError("Raw issue must be a JSON object.")
        result = validate_response(args.response.read_text(encoding="utf-8"), issue, args.tree)
    except (ValueError, OSError, UnicodeError) as exc:
        result = {"valid": False, "error": str(exc)}
    # ASCII JSON is lossless and works with Windows console code pages as well.
    print(json.dumps(result))
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
