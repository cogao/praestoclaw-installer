"""Workflow auto-suggest core (P2): cheap, LLM-free matching of a user message
against saved recipes, so the on_message_sent suggester can nudge "run workflow
X?" (match) or "save this as a workflow?" (capture). Deterministic + fast — never
calls a model. Suggest-only: nothing here runs a workflow.
"""

from __future__ import annotations

import re
from collections import OrderedDict
from collections.abc import Callable, Mapping
from typing import TYPE_CHECKING

from loguru import logger

from praestoclaw.bus.events import ChannelType, OutboundMessage
from praestoclaw.hooks.manager import HookResult
from praestoclaw.security.leak import redact_credentials
from praestoclaw.security.sanitizer import Sanitizer
from praestoclaw.skills.loader import Skill

if TYPE_CHECKING:
    from praestoclaw.bus.queue import MessageBus
    from praestoclaw.hooks.manager import MessageHookContext

# Common English + filler tokens that must never, on their own, drive a match —
# else a recipe description sharing "the"/"for" with any message would false-hit.
_STOPWORDS = frozenset(
    {
        "the",
        "this",
        "that",
        "these",
        "those",
        "and",
        "for",
        "you",
        "your",
        "please",
        "can",
        "could",
        "would",
        "should",
        "now",
        "with",
        "from",
        "into",
        "have",
        "has",
        "had",
        "was",
        "were",
        "are",
        "its",
        "all",
        "any",
        "some",
        "what",
        "whats",
        "when",
        "then",
        "than",
        "there",
        "here",
        "about",
        "just",
        "like",
        "want",
        "need",
        "let",
        "get",
        "got",
        "run",
        "make",
        "made",
        "use",
        "using",
        "app",
        "does",
        "did",
        "done",
        "stuff",
        "thing",
        "things",
        "not",
        "but",
        "out",
        "off",
        "yes",
        "one",
        "two",
    }
)

# Weights: an explicit keyword or a distinctive name token is a strong intent
# signal; a bare description word is weak (two are needed to reach the threshold).
_KEYWORD_WEIGHT = 2
_NAME_WEIGHT = 2
_DESC_WEIGHT = 1
_DEFAULT_MIN_SCORE = 2


# CJK / kana / hangul ranges — matched as overlapping bigrams below, since these
# scripts don't delimit words with spaces (a lone char is too common to be a
# useful signal, a bigram is a reasonable cheap unit). Chinese workflow names are
# explicitly allowed (workflow._slugify), so the matcher must not be ASCII-only.
_CJK = "一-鿿぀-ヿ가-힯"
_CJK_RUN = re.compile(f"[{_CJK}]+")


def _tokens(text: str) -> set[str]:
    """Match units for overlap scoring: ASCII alphanumeric words (≥3 chars,
    stopwords dropped) plus overlapping CJK/kana/hangul bigrams (so Chinese/
    Japanese/Korean recipe names and messages can match, not just English). A lone
    CJK char (a run of length 1) yields no token — too common to be a useful
    signal — so only runs of ≥2 chars contribute bigrams."""
    s = str(text or "").lower()
    toks = {t for t in re.split(r"[^a-z0-9]+", s) if len(t) >= 3 and t not in _STOPWORDS}
    for run in _CJK_RUN.findall(s):
        toks.update(run[i : i + 2] for i in range(len(run) - 1))
    return toks


def _recipe_signature(recipe: Skill) -> dict[str, int]:
    """Token → weight for a recipe (keyword/name strong, description weak)."""
    sig: dict[str, int] = {}

    def _add(text: str, weight: int) -> None:
        for tok in _tokens(text):
            if sig.get(tok, 0) < weight:
                sig[tok] = weight  # keep the strongest source's weight per token

    _add(recipe.description, _DESC_WEIGHT)
    _add(" ".join(recipe.name.replace("-", " ").replace("_", " ").split()), _NAME_WEIGHT)
    for kw in recipe.keywords or []:
        _add(str(kw), _KEYWORD_WEIGHT)
    return sig


def score_recipe(text: str, recipe: Skill) -> int:
    """Overlap score of ``text`` against ``recipe`` (0 = no meaningful overlap)."""
    msg = _tokens(text)
    if not msg:
        return 0
    return sum(weight for tok, weight in _recipe_signature(recipe).items() if tok in msg)


def match_recipe(
    text: str, recipes: list[Skill], *, min_score: int = _DEFAULT_MIN_SCORE
) -> Skill | None:
    """Best-matching recipe for ``text``, or None below ``min_score``.

    Deterministic: highest score wins, ties broken by recipe name. Cheap token
    overlap — no model. A single weak (description) word can't reach the default
    threshold, so unrelated / weakly-overlapping messages return None.
    """
    scored = [(score_recipe(text, r), r) for r in recipes]
    scored = [(s, r) for s, r in scored if s >= min_score]
    if not scored:
        return None
    scored.sort(key=lambda sr: (-sr[0], sr[1].name))
    return scored[0][1]


# ── Anti-nag rate limiter ─────────────────────────────────────────────────────
# User directive (2026-07-16): "宁愿100次thread里有一次提示，也不要反复提示100次" —
# err HARD toward silence. This gate emits AT MOST ONE workflow suggestion per
# session, ever (in-memory, bounded LRU; resets on restart, which is fine — a
# fresh process nagging once more is acceptable, repeated nagging is not).

_GATE_MAX_SESSIONS = 4096


class SuggestionGate:
    """At most one workflow suggestion per session. ``allow(session_id)`` returns
    True exactly once per session id (recording it), then False while that record
    survives. A blank/None session id can't be deduped safely, so it returns False
    (stay silent).

    The record set is a bounded LRU of the ``max_sessions`` most-recently-active
    sessions. An already-suggested session is refreshed on every hit, so a *live*
    session is never evicted and can never be nagged twice. Only a session that has
    gone quiet long enough to fall out of the LRU (i.e. ``max_sessions`` other
    distinct sessions have been active since) could be suggested to again — and a
    fresh process resets the set entirely. Both are acceptable: the guarantee that
    matters is "never nag an active session", not "remember forever".
    """

    def __init__(self, max_sessions: int = _GATE_MAX_SESSIONS) -> None:
        self._suggested: OrderedDict[str, None] = OrderedDict()
        self._max = max_sessions

    def allow(self, session_id: str) -> bool:
        sid = str(session_id or "").strip()
        if not sid:
            return False
        if sid in self._suggested:
            self._suggested.move_to_end(sid)  # refresh: a live session stays un-evicted
            return False
        self._suggested[sid] = None
        if len(self._suggested) > self._max:
            self._suggested.popitem(last=False)  # evict least-recently-active
        return True

    def already_suggested(self, session_id: str) -> bool:
        """True if this session already got its one suggestion (refreshing its LRU
        recency so a live session stays on record). Non-consuming — lets a caller
        cheaply short-circuit the expensive match work once the one-shot is spent."""
        sid = str(session_id or "").strip()
        if sid and sid in self._suggested:
            self._suggested.move_to_end(sid)
            return True
        return False


# ── High-precision capture trigger ────────────────────────────────────────────
# A (capture) fires ONLY on an explicit "this is a repeatable procedure" cue in
# the user's message — NOT on tool-call volume (which would nag). Precision over
# recall: miss many, never nag.

_CUE_PATTERNS = tuple(
    re.compile(p, re.IGNORECASE)
    for p in (
        r"每次",
        r"以后(遇到|再|都|这)",
        r"下次(也|就|遇到|再)",
        r"总是这[么样]",
        r"(存|保存|记)成\s*workflow",
        r"存成(一个)?(流程|workflow)",
        r"把(这个|这套).{0,6}(流程|步骤).{0,4}(存|记|保存)",
        r"记(一?下|住)(这个|这套).{0,4}(流程|步骤)",
        r"next time\b",
        r"every time\b",
        r"each time\b",
        r"save (this|it) as .{0,20}workflow",  # must name "workflow" (not "…as a pdf")
        r"make (a|this into a) workflow",
        r"turn this into a workflow",
    )
)


def detect_repeatable_cue(text: str) -> bool:
    """True if the message explicitly signals a repeatable procedure worth saving
    (high precision — used to trigger the 'save as workflow?' capture nudge)."""
    s = str(text or "")
    return any(p.search(s) for p in _CUE_PATTERNS)


# ── on_message_sent / on_message_received handler ─────────────────────────────
# Assembles the pure cores above into a hook handler that, at most ONCE per
# session, emits a SEPARATE proactive 💡 bubble suggesting the user run a matching
# workflow, or save a just-described repeatable procedure as one. It NEVER runs a
# workflow and NEVER modifies/blocks the reply — it only side-emits a suggestion.
#
# Isolation: this handler is only registered when ``config.workflow.suggest`` is
# on (see hooks/handlers.py). Flag off → not registered → zero diff, no cost.
#
# Delivery: a separate OutboundMessage is the only reliable surface — appending to
# the reply is silently dropped on streamed channels (see the message-hook notes).
# We keep channel_id as the channel's natural id and put the session key in
# route_hint (the dedicated per-connection routing field); WebChannel.send checks
# the route_hint push queue BEFORE any broadcast fallback, so the push lands on the
# originating connection.

# Which surfaces a route_hint push reliably reaches the one local user on. This is
# keyed on the SESSION KEY, not the loop-level channel: the local desktop webchat
# WS is dispatched as ChannelType.WEB (web/server.py), yet its agent_session_key is
# "local_webchat:<sender>:<conv>" and the web channel registers a push alias under
# exactly that key — so route_hint=session_key reaches the one desktop client. A
# plain HTTP/SSE web turn instead carries a "web:" key with NO push alias (a bubble
# there would broadcast or drop), and CLOUD is a multi-connection relay. We fire
# only on the CLI and that local-webchat prefix, staying silent everywhere else
# (err toward silence — the same principle as the anti-nag gate).
_LOCAL_WEBCHAT_PREFIX = f"{ChannelType.LOCAL_WEBCHAT.value}:"  # "local_webchat:"


def _is_local_surface(channel: ChannelType, session_id: str) -> bool:
    """True where a route_hint push reliably reaches the one local user: the CLI
    (stdout, ignores routing), and the desktop webchat WS (a ChannelType.WEB turn
    whose session key starts with 'local_webchat:', which has a push alias)."""
    if channel == ChannelType.INTERNAL:
        return True
    return session_id.startswith(_LOCAL_WEBCHAT_PREFIX)


_STASH_MAX_SESSIONS = 4096


class WorkflowSuggester:
    """Hook handler that suggests (never runs) a workflow at most once per session.

    Registered on two hook points sharing one instance:

    - ``record`` (on_message_received) — stash the user's latest message in memory
      (no store I/O). Read-only; never rejects or modifies the message.
    - ``suggest`` (on_message_sent) — after the reply, decide whether to emit ONE
      proactive 💡 suggestion (run a matched recipe, or save a cued repeatable
      procedure), gated to at most once per session. Never modifies/blocks the
      reply.
    """

    def __init__(
        self,
        *,
        message_bus: MessageBus,
        recipes_provider: Callable[[], Mapping[str, Skill]],
        gate: SuggestionGate | None = None,
        max_sessions: int = _STASH_MAX_SESSIONS,
    ) -> None:
        self._bus = message_bus
        self._recipes = recipes_provider
        self._gate = gate or SuggestionGate()
        self._last_user: OrderedDict[str, str] = OrderedDict()
        self._max = max_sessions

    async def record(self, ctx: MessageHookContext) -> HookResult:
        """on_message_received: remember the user's latest message. Never rejects."""
        try:
            sid = str(ctx.session_id or "").strip()
            text = str(ctx.content or "")
            if sid and text:
                self._last_user[sid] = text
                self._last_user.move_to_end(sid)
                if len(self._last_user) > self._max:
                    self._last_user.popitem(last=False)  # evict oldest
        except Exception as exc:  # never let a suggestion helper break a turn
            logger.debug("workflow suggester record skipped: {}", exc)
        return HookResult.allow()  # pass-through — no data= → message unchanged

    async def suggest(self, ctx: MessageHookContext) -> HookResult:
        """on_message_sent: maybe emit one 💡. Never modifies/blocks the reply."""
        try:
            await self._maybe_emit(ctx)
        except Exception as exc:
            logger.debug("workflow suggester skipped: {}", exc)
        return HookResult.allow()  # pass-through — reply is never touched

    async def _maybe_emit(self, ctx: MessageHookContext) -> None:
        sid = str(ctx.session_id or "").strip()
        if not sid:
            return
        if not _is_local_surface(ctx.channel, sid):
            return  # not a reliably-routable local surface → stay silent
        # Fast path: once this session has had its one nudge, skip the recipe
        # load + matching entirely (keeps post-suggestion overhead near-zero).
        if self._gate.already_suggested(sid):
            return
        user_text = self._last_user.get(sid)
        if not user_text:
            return

        recipes = list(self._recipes().values())
        match = match_recipe(user_text, recipes) if recipes else None
        cue = detect_repeatable_cue(user_text)
        if match is None and not cue:
            return  # nothing worth surfacing

        # Consume the one-shot ONLY once we actually have something to suggest, so
        # the single per-session suggestion isn't wasted on an empty turn.
        if not self._gate.allow(sid):
            return  # already suggested this session → never nag

        # Publishing via the bus bypasses the on_message_sent hook chain, so the
        # OutboundLeakScanner never sees this bubble. The text embeds a recipe
        # name (author/user-controlled), so scrub credentials/env values here the
        # same way the leak scanner and ToolStatusCard do, before it goes out.
        content = _compose_suggestion(match, cue)
        scrubbed = Sanitizer.redact_env_values(redact_credentials(content))
        if scrubbed != content:
            # Redaction changed the text → it hit the embedded recipe name, so a
            # "reply 跑 <name>" instruction would point at a [REDACTED] token the
            # user can't run. Fall back to a name-free nudge instead.
            scrubbed = _SUGGEST_FALLBACK
        await self._bus.publish_outbound(
            OutboundMessage(
                channel=ctx.channel,
                # channel_id stays the channel's natural id (per bus/events'
                # contract); route_hint carries the precise per-connection
                # destination. WebChannel.send checks route_hint's push queue
                # BEFORE any broadcast fallback, so this targets the originating
                # connection without misdelivering to other clients.
                channel_id=ctx.channel.value,
                content=scrubbed,
                route_hint=sid,
                metadata={"keep_context": True, "workflow_suggestion": True},
            )
        )


# Name-free fallback used when redaction alters the composed text (i.e. the recipe
# name held a credential-like substring) — a "run <name>" instruction would then
# point at a [REDACTED] token, so we send this instead.
_SUGGEST_FALLBACK = (
    "💡 有个已保存的 workflow 看起来可能适合这个任务 —— 发 `workflow list` 看看有哪些？"
)


def _compose_suggestion(match: Skill | None, cue: bool) -> str:
    """The 💡 bubble text. A concrete recipe match beats a generic capture nudge —
    'run this existing one' is more actionable than 'save a new one'."""
    if match is not None:
        return (
            f"💡 这个任务看起来能用现成的 workflow「{match.name}」跑 —— "
            f"要我直接跑吗？(回一句「跑 {match.name}」就行)"
        )
    return "💡 这套流程看起来以后还会重复 —— 要不要我把它存成一个 workflow？(下次一句话就能重跑)"
