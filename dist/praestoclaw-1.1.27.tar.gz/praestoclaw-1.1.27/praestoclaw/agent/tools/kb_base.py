"""Shared repository resolution for the knowledge-base tools.

The three KB tools each used to carry their own copy of "map what the model
asked for onto the operator's allowlist". The copies drifted, and all of them
matched by substring — fine when the allowlist held one repository, actively
dangerous once it holds every repository the employee can reach, because a
short word typed in a group chat could select the wrong one and still report
success.

Resolution now lives here, once, and answers a different question than it used
to. The operator's allowlist says what *may* be written to; the group's own
binding (``kb_scope``) says what this conversation actually uses. A tool asks
for "this group's repository" and gets either that, or an explanation of what
is missing — never a guess.
"""

from __future__ import annotations

from typing import Any

from praestoclaw.kb.repo import KbRepo
from praestoclaw.kb.scope import (
    GroupScopeStore,
    KbScope,
    RepoAmbiguousError,
    RepoNotAllowedError,
    allowlist,
    resolve_allowed_repo,
)


def validate_scheduled_scope(
    scopes: GroupScopeStore | None,
    kb_config: Any,
    capability: Any,
) -> KbScope | str:
    """Revalidate a scheduled snapshot against the original conversation binding."""
    if scopes is None:
        return "Error: scheduled KB capability has no scope store wired."
    scope = scopes.read(capability.conversation_id)
    if scope is None:
        return "Error: scheduled KB capability is blocked because its KB scope was cleared."
    try:
        current_repo = resolve_allowed_repo(allowlist(kb_config), scope.repo)
        snapshot_repo = resolve_allowed_repo(allowlist(kb_config), capability.repo)
    except (RepoNotAllowedError, RepoAmbiguousError):
        return "Error: scheduled KB capability targets a repository that is no longer allowed."
    if (
        current_repo != snapshot_repo
        or scope.subfolder != capability.subfolder
        or scope.set_at != capability.scope_set_at
        or scope.subject_id != capability.subject_id
        or scope.tenant_id != capability.tenant_id
    ):
        return (
            "Error: scheduled KB capability is blocked because the original conversation "
            "scope changed; recreate the scheduled job from that personal Teams chat."
        )
    return scope


class KbToolBase:
    """Configuration, allowlist and group-binding lookup shared by the KB tools."""

    def __init__(self, kb_config: Any = None, scope_store: Any = None) -> None:
        self._config = kb_config
        self._scopes: GroupScopeStore | None = scope_store

    # ── configuration ────────────────────────────────────────────────────

    def _enabled(self) -> bool:
        return bool(getattr(self._config, "enabled", True))

    def _sync_timeout(self) -> int:
        return int(getattr(self._config, "sync_timeout_s", 180) or 180)

    def _allowlist(self) -> list[str]:
        return allowlist(self._config)

    # ── group binding ────────────────────────────────────────────────────

    def _scope(self, cid: str) -> KbScope | None:
        if self._scopes is None or not cid:
            return None
        return self._scopes.read(cid)

    def _resolve_entry(self, requested: str) -> str | None:
        """Allowlist entry for *requested*, or ``None`` when it is not allowed."""
        try:
            return resolve_allowed_repo(self._allowlist(), requested)
        except (RepoNotAllowedError, RepoAmbiguousError):
            return None

    def _repo_for_group(self, cid: str, requested: str = "") -> KbRepo | str:
        """This group's repository, or a message explaining what to do first.

        An explicit *requested* repository is honoured only when it resolves to
        the same entry the group is bound to. Silently working against a
        different repository than the one the group configured is precisely the
        surprise the binding exists to prevent — so a mismatch is reported and
        the group is pointed at ``kb_scope`` to change it deliberately.
        """
        allowed = self._allowlist()
        if not allowed:
            return (
                "No knowledge base is configured for this agent at all. The person "
                "running it has to list one under praesto_tag_exp.kb.repos in "
                "praestoclaw.local.yaml and restart."
            )

        scope = self._scope(cid)
        if scope is None:
            return self._unconfigured_message()

        entry = self._resolve_entry(scope.repo)
        if entry is None:
            return (
                f"This group is bound to '{scope.repo}', which is no longer in the "
                "allowed list — it may have been removed from the config. Allowed "
                f"now: {', '.join(allowed)}. Re-configure with kb_scope(action='set')."
            )

        wanted = (requested or "").strip()
        if wanted and self._resolve_entry(wanted) != entry:
            return (
                f"This group's knowledge base is '{entry}', not '{wanted}'. Use the "
                "configured one, or change the binding with kb_scope(action='set') "
                "after the group agrees."
            )
        return KbRepo(entry)

    def _repo_for_scheduled(self, capability: Any, requested: str = "") -> KbRepo | str:
        scope = validate_scheduled_scope(self._scopes, self._config, capability)
        if isinstance(scope, str):
            return scope
        entry = self._resolve_entry(capability.repo)
        if entry is None:
            return "Error: scheduled KB capability repository is no longer allowed."
        wanted = (requested or "").strip()
        if wanted and self._resolve_entry(wanted) != entry:
            return (
                "Error: scheduled KB reads are pinned to the scope captured when the job "
                "was created; recreate the job to use another repository."
            )
        return KbRepo(entry)

    @staticmethod
    def _unconfigured_message() -> str:
        return (
            "This group has not chosen a knowledge base yet, so there is nothing to "
            "work against. Call kb_scope(action='show') to see what may be chosen, "
            "ask the group which repository (and optionally which folder) to use, "
            "and record their answer with kb_scope(action='set')."
        )

    def _repo_for_task(self, task_repo: str) -> KbRepo | str:
        """Repository an in-flight task is pinned to.

        Deliberately resolved against the allowlist rather than the group's
        current binding: a task carries the repository the group reviewed a diff
        against, and re-pointing it because someone re-ran ``kb_scope`` midway
        would publish approved content somewhere nobody approved.
        """
        allowed = self._allowlist()
        entry = self._resolve_entry(task_repo)
        if entry is None:
            return (
                f"This task targets '{task_repo}', which is not an allowed knowledge "
                f"base. Allowed: {', '.join(allowed) or '(none)'}."
            )
        return KbRepo(entry)
