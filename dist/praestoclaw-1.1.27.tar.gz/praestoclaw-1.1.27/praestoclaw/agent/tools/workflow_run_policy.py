"""Per-recipe approval ownership and preflight policy registration."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any, Protocol

from praestoclaw.agent.tools.fix_bug_preflight import FixBugRunPolicy


class WorkflowRunPolicy(Protocol):
    """Runtime-registered approval ownership and validation for one recipe."""

    def handles_approval_internally(self, args: dict[str, Any], metadata: dict[str, Any]) -> bool:
        """Declare internal approval ownership without consuming authorization."""
        ...

    async def preflight(self, params: dict[str, Any], metadata: dict[str, Any]) -> str:
        """Return a refusal message, or an empty string to allow the run."""
        ...


def default_run_policies(
    selector_revalidate_fn: Callable[..., Awaitable[str]] | None = None,
) -> dict[tuple[str, str], WorkflowRunPolicy]:
    """Keep bundled launch guards fail-closed, including for legacy callers."""
    return {("bundled", "fix-bug"): FixBugRunPolicy(selector_revalidate_fn)}
