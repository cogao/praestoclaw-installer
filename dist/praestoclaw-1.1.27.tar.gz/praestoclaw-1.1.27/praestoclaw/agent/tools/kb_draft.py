"""Turn captured evidence into a reviewable set of knowledge-base changes.

This is the middle of the two-stage flow and it exists to make one durable group
confirmation possible:

1. ``stage`` creates a local proposal commit and a detailed, file-level summary
   which the group confirms in ordinary chat. GitHub repositories may also get
   a best-effort Draft PR mirror for inspecting the actual diff.
2. An approval of that exact proposal authorizes ``kb_publish`` immediately.
   There is no second publish question or Adaptive Card.

The local branch remains authoritative. Any Draft PR is removed before
``kb_publish`` continues with the existing local squash-and-push workflow.

The tool does not decide what counts as a decision, where a document belongs,
or which convention applies — those come from ``kb_inspect(action="rules")``
and the model's reading of them. Encoding them here would freeze one snapshot
of a knowledge base that is expected to keep changing.
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.agent.tools.kb_base import KbToolBase
from praestoclaw.kb import captures_dir
from praestoclaw.kb.draft import (
    BLOCKER_OVERRIDDEN,
    BLOCKER_RESOLVED,
    DECISION_APPROVED,
    DECISION_STAGES,
    DECISIONS,
    MAX_CHANGES,
    STATUS_AWAITING_DRAFT,
    STATUS_AWAITING_PUBLISH,
    STATUS_CANCELLED,
    STATUS_DRAFTING,
    CurationTask,
    CurationTaskStore,
    GroupDecision,
    KnowledgeUnit,
    RuleBlocker,
    StagedChange,
    commit_message_for,
    machine_authored_quote,
    proposal_branch_name,
    validate_change,
)
from praestoclaw.kb.github_review import close_draft_review, upsert_draft_review
from praestoclaw.kb.repo import KbPathError, KbRepo, KbRepoError
from praestoclaw.security.kb_curation import kb_curation_is_active
from praestoclaw.security.risk import RiskAssessment, RiskScore

_ACTIONS = (
    "start",
    "restart",
    "units",
    "select",
    "blockers",
    "resolve_blocker",
    "stage",
    "approve",
    "show",
    "list",
    "cancel",
)
_UNIT_TYPES = ("fact", "decision", "action", "risk", "question", "background", "status")


def _normalize_change_content(content: str) -> str:
    return content.replace("\r\n", "\n").replace("\r", "\n")


def _turn_id(kwargs: dict[str, Any]) -> str:
    """Identity of the inbound turn this call belongs to.

    Any of the three is fine — they are all stamped per inbound message by the
    cloud channel — but one of them has to be present for the same-turn check to
    mean anything.
    """
    metadata = kwargs.get("_metadata") or {}
    for key in ("turn_id", "message_id", "request_id"):
        value = str(metadata.get(key) or "").strip()
        if value:
            return value
    return ""


_MAX_UNITS = 100


def _diff_materials(task: CurationTask) -> dict[str, Any]:
    """Describe the files and evidence references used to build a KB proposal.

    This is intentionally metadata-only: raw Teams messages and transcript text
    stay in the capture/cache files and never get copied into the debug log.
    """
    payload: dict[str, Any] = {
        "task_id": task.task_id,
        "capture_file": task.capture_path,
        "kb_repo": task.repo,
        "kb_base_head": task.base_head,
        "kb_target_files": [change.path for change in task.changes],
        "selected_units": [],
        "capture_records": [],
        "teams_web_dirs": [],
        "teams_web_files": [],
    }
    for unit in task.selected_units:
        refs: list[dict[str, Any]] = []
        for evidence in unit.evidence:
            if not isinstance(evidence, dict):
                continue
            ref = {
                key: evidence[key]
                for key in ("capture_record", "message_id", "call_id", "transcript_id")
                if evidence.get(key) not in (None, "")
            }
            if ref:
                refs.append(ref)
        payload["selected_units"].append({"id": unit.id, "evidence_refs": refs})

    capture = Path(task.capture_path) if task.capture_path else None
    if capture is None or not capture.is_file():
        payload["capture_error"] = "capture file is missing"
        return payload
    try:
        document = json.loads(capture.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        payload["capture_error"] = f"{type(exc).__name__}: {exc}"
        return payload
    if not isinstance(document, dict):
        payload["capture_error"] = "capture root is not an object"
        return payload

    teams_dirs: set[str] = set()
    teams_files: set[str] = set()
    for index, record in enumerate(document.get("records") or []):
        if not isinstance(record, dict):
            continue
        record_meta: dict[str, Any] = {
            "index": index,
            "type": record.get("type") or record.get("kind") or record.get("record_type"),
        }
        for key in ("provenance", "source", "conversation_id", "rendition"):
            if record.get(key) not in (None, ""):
                record_meta[key] = record[key]
        checked_paths = record.get("checked_paths")
        if isinstance(checked_paths, list):
            record_meta["checked_paths"] = [str(path) for path in checked_paths]
        payload["capture_records"].append(record_meta)

        cache_dir = str(record.get("cache_dir") or "").strip()
        if cache_dir:
            teams_dirs.add(cache_dir)
            for segment in record.get("segments") or []:
                if isinstance(segment, dict) and segment.get("file"):
                    teams_files.add(str(Path(cache_dir) / str(segment["file"])))
        cache_path = str(record.get("cache_path") or "").strip()
        if cache_path:
            teams_files.add(cache_path)
            teams_dirs.add(str(Path(cache_path).parent))

    payload["teams_web_dirs"] = sorted(teams_dirs)
    payload["teams_web_files"] = sorted(teams_files)
    return payload


def _log_diff_materials(task: CurationTask) -> None:
    """Emit source metadata only when a DEBUG sink will consume it."""
    logger.opt(lazy=True).debug(
        "kb_draft.diff_materials {}",
        lambda: json.dumps(_diff_materials(task), ensure_ascii=False, sort_keys=True),
    )


class KbDraftTool(KbToolBase, Tool):
    """Assemble and revise a proposed knowledge-base change set."""

    risk_range = (3, 5)

    @property
    def name(self) -> str:
        return "kb_draft"

    @property
    def description(self) -> str:
        return (
            "Build a reviewable knowledge-base change set from captured or direct chat evidence. "
            "Actions: 'start' opens a task against a capture snapshot, or with "
            "source='direct' in a Teams personal chat for a PMO grill evidence packet; 'restart' "
            "MUST replace an unfinished task when the human makes a new KB request: "
            "it verifies deletion of the old local proposal branch, cancels the old "
            "task, and immediately opens a fresh task. If normal deletion fails it "
            "hard-resets the managed checkout and may rebuild that local clone; "
            "'units' records the knowledge you extracted (facts, "
            "decisions, actions, risks, questions) with evidence pointers; "
            "'select' records which units the proposal includes; 'blockers' "
            "records rules this material appears to violate — record them BEFORE "
            "staging, because an open blocker stops staging until the group "
            "answers it; 'resolve_blocker' records that answer (the draft "
            "changed, or the group knowingly overrode the rule); 'stage' writes "
            "the full documents to a local proposal branch, commits them, optionally "
            "mirrors the diff as a GitHub Draft PR, and returns the detailed "
            "draft-confirmation summary; 'approve' records "
            "the group's ordinary-chat reply to that staged proposal and, when "
            "approved, requires immediate kb_publish with no second question; "
            "'show' resumes a task; 'list' shows this conversation's "
            "tasks and directs new requests to 'restart'; 'cancel' abandons one. "
            "Only the optional review branch/Draft PR may reach the remote before "
            "kb_publish; the real KB branch never does."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=120, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        if str(args.get("action") or "") in {"stage", "restart", "cancel"}:
            return RiskScore(
                5,
                reason="Create, update, or remove a disposable KB Draft PR review mirror",
            )
        return RiskScore(
            3,
            reason="Manage a local knowledge-base proposal",
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": list(_ACTIONS)},
                "task_id": {
                    "type": "string",
                    "description": "Which task; defaults to this conversation's active one.",
                },
                "capture": {
                    "type": "string",
                    "description": (
                        "For 'start'/'restart' with captured evidence: the capture snapshot "
                        "filename saved by team_knowledge_capture. Omit to use the newest one."
                    ),
                },
                "source": {
                    "type": "string",
                    "enum": ["capture", "direct"],
                    "description": (
                        "For 'start'/'restart': 'capture' uses a team_knowledge_capture "
                        "snapshot. 'direct' is only for Teams personal-chat PMO grill flows "
                        "where the current conversation already contains the evidence packet."
                    ),
                },
                "repo": {
                    "type": "string",
                    "description": "For 'start': target repository, as 'owner/name'.",
                },
                "user_request": {
                    "type": "string",
                    "description": "For 'start': what the group asked for, in their words.",
                },
                "units": {
                    "type": "array",
                    "description": (
                        "For 'units': the knowledge you extracted. Each item needs "
                        "type, title, content and evidence pointing back to the "
                        "capture record and original source URL."
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "type": {"type": "string", "enum": list(_UNIT_TYPES)},
                            "title": {"type": "string"},
                            "content": {"type": "string"},
                            "confidence": {"type": "string"},
                            "evidence": {
                                "type": "array",
                                "items": {"type": "object", "additionalProperties": True},
                            },
                        },
                        "required": ["type", "title"],
                    },
                },
                "unit_ids": {
                    "type": "array",
                    "description": "For 'select': the unit ids the group kept.",
                    "items": {"type": "string"},
                },
                "all": {
                    "type": "boolean",
                    "description": "For 'select': keep every unit.",
                },
                "blockers": {
                    "type": "array",
                    "description": (
                        "For 'blockers': rules this material appears to violate. "
                        "Quote the rule and name the document it came from, so the "
                        "group can judge it without re-reading the repository."
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "rule_source": {
                                "type": "string",
                                "description": "Path of the rule document, e.g. "
                                "'context/sources.md'.",
                            },
                            "rule": {
                                "type": "string",
                                "description": "The rule, quoted.",
                            },
                            "conflict": {
                                "type": "string",
                                "description": "How this material conflicts with it.",
                            },
                        },
                        "required": ["rule_source", "rule", "conflict"],
                    },
                },
                "blocker_id": {
                    "type": "string",
                    "description": "For 'resolve_blocker': which blocker.",
                },
                "resolution": {
                    "type": "string",
                    "enum": [BLOCKER_RESOLVED, BLOCKER_OVERRIDDEN],
                    "description": (
                        "For 'resolve_blocker': 'resolved' = the draft changed so the "
                        "conflict is gone; 'overridden' = the group chose to proceed "
                        "anyway, which is recorded in the commit message."
                    ),
                },
                "note": {
                    "type": "string",
                    "description": "For 'resolve_blocker': what the group decided and why.",
                },
                "decided_by": {
                    "type": "string",
                    "description": "For 'resolve_blocker': who in the group decided.",
                },
                "stage": {
                    "type": "string",
                    "enum": list(DECISION_STAGES),
                    "description": "For 'approve': always 'draft', the single proposal gate.",
                },
                "decision": {
                    "type": "string",
                    "enum": list(DECISIONS),
                    "description": (
                        "For 'approve': how you read their reply. 'approved' only for "
                        "a clear yes; use 'changes_requested' when they want edits and "
                        "'rejected' when they refuse. If the reply is ambiguous, do not "
                        "guess — ask them to confirm."
                    ),
                },
                "quote": {
                    "type": "string",
                    "description": (
                        "For 'approve': the group's own words, verbatim. Required — it "
                        "is what makes a chat-read decision auditable. Must come from a "
                        "message a person sent; tool output and checkpoint verdicts are "
                        "rejected."
                    ),
                },
                "by": {
                    "type": "string",
                    "description": "For 'approve': who answered. Defaults to the sender.",
                },
                "message": {
                    "type": "string",
                    "description": (
                        "For 'stage': the commit message, in the repository's own style "
                        "(conventional commits). The group reviews the real commit, so "
                        "this is part of what they approve — changing it later voids "
                        "their approval."
                    ),
                },
                "overview": {
                    "type": "string",
                    "description": (
                        "For 'stage': macro summary of the whole proposal, shown in the "
                        "first natural-language confirmation."
                    ),
                },
                "changes": {
                    "type": "array",
                    "description": (
                        "For 'stage': the proposed documents. Provide the COMPLETE "
                        "new content of each file, not a patch."
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "path": {"type": "string"},
                            "operation": {"type": "string", "enum": ["create", "update"]},
                            "content": {"type": "string"},
                            "summary": {
                                "type": "string",
                                "description": "One-line summary retained in publish history.",
                            },
                            "details": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Complete semantic detail for draft confirmation.",
                            },
                            "rationale": {"type": "string"},
                            "units": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["path", "operation", "content", "summary", "details"],
                    },
                },
            },
            "required": ["action"],
        }

    # ── execution ────────────────────────────────────────────────────────

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata") or {}
        if not kb_curation_is_active(metadata):
            return "kb_draft is only available in a Teams group experiment or personal Teams chat."
        if not self._enabled():
            return "Knowledge-base curation is disabled in this PraestoClaw config."

        cid = str(metadata.get("cid") or "")
        if not cid:
            return "Error: kb_draft needs a Teams conversation id on this turn."

        action = str(kwargs.get("action") or "").strip()
        if action not in _ACTIONS:
            return f"Error: action must be one of {', '.join(_ACTIONS)}."

        store = CurationTaskStore(cid)
        try:
            if action == "start":
                return await self._action_start(store, metadata, kwargs)
            if action == "restart":
                return await self._action_restart(store, metadata, kwargs)
            if action == "list":
                payload: dict[str, Any] = {
                    "tasks": [task.summary() for task in store.all_tasks()[:20]]
                }
                if active := store.active():
                    payload["active_task"] = active.summary()
                    if (
                        active.status == STATUS_AWAITING_PUBLISH
                        and active.draft_approval() is not None
                    ):
                        payload["required_for_approved_proposal"] = (
                            "This proposal is already approved. Call kb_publish now; "
                            "do not ask for publish confirmation."
                        )
                    payload["required_for_new_request"] = (
                        "This conversation has an unfinished proposal. If the current "
                        "human message is a NEW knowledge-base update or assessment "
                        "request (not an answer about this proposal), call "
                        "kb_draft(action='restart', user_request=<current request>) now; "
                        "add source='direct' for a Teams personal-chat PMO evidence "
                        "packet, or capture=<snapshot> for captured group material. Do "
                        "not merely describe the old proposal or ask whether to replace it."
                    )
                return self._dump(payload)

            task = store.resolve(str(kwargs.get("task_id") or ""))
            if task is None:
                return (
                    "No curation task found for this conversation. "
                    "Run kb_draft(action='start') first."
                )
            if action == "show":
                return await self._action_show(store, task)
            if not task.is_active:
                return (
                    f"Task {task.task_id} is {task.status} and cannot be modified. "
                    "Start a new task instead."
                )
            if action == "units":
                return self._action_units(store, task, kwargs)
            if action == "select":
                return self._action_select(store, task, kwargs)
            if action == "blockers":
                return self._action_blockers(store, task, kwargs)
            if action == "resolve_blocker":
                return self._action_resolve_blocker(store, task, kwargs)
            if action == "stage":
                return await self._action_stage(store, task, kwargs)
            if action == "approve":
                return self._action_approve(store, task, kwargs, metadata)
            return await self._action_cancel(store, task)
        except KbPathError as exc:
            return f"Refused: {exc}"
        except KbRepoError as exc:
            return f"Knowledge base unavailable: {exc}"

    # ── actions ──────────────────────────────────────────────────────────

    def _resolve_capture(self, requested: str) -> Path | str:
        """Find the capture snapshot to curate, newest-first by default."""
        root = captures_dir()
        available = sorted(root.glob("*.json")) if root.is_dir() else []
        if not available:
            return (
                "No capture snapshot exists yet. Collect the material first — load "
                "tools(name='team-knowledge-capture', action='skill') and follow it, "
                "then run kb_draft(action='start') again."
            )
        wanted = (requested or "").strip()
        if not wanted:
            return available[-1]
        for candidate in reversed(available):
            if wanted in (candidate.name, candidate.stem) or wanted in candidate.name:
                return candidate
        names = ", ".join(path.name for path in available[-5:])
        return f"No capture matches '{wanted}'. Recent captures: {names}"

    @staticmethod
    def _capture_inventory(path: Path) -> dict[str, Any]:
        """Summarise a capture so the group can frame the scope from it.

        Deliberately a summary: the snapshot embeds whole transcripts, and
        returning those verbatim would spend the turn's context on material the
        model is about to read selectively anyway.
        """
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            return {"error": f"Capture {path.name} is unreadable: {exc}"}
        records = payload.get("records") or []
        inventory: list[dict[str, Any]] = []
        for index, record in enumerate(records):
            kind = str(record.get("type") or "unknown")
            entry: dict[str, Any] = {"record": index, "type": kind}
            if kind == "chat_messages":
                entry.update(
                    {
                        "provenance": record.get("provenance"),
                        "count": record.get("count"),
                        "covered_from": record.get("covered_from"),
                        "covered_to": record.get("covered_to"),
                    }
                )
            elif kind == "meeting_transcript":
                pointer = record.get("pointer") or {}
                entry.update(
                    {
                        "provenance": record.get("provenance"),
                        "speaker_attribution": record.get("speaker_attribution"),
                        "title": pointer.get("title"),
                        "arrival_time": pointer.get("arrival_time"),
                        "vtt_chars": len(str(record.get("vtt") or "")),
                    }
                )
            elif kind == "source_gap":
                entry.update(
                    {
                        "source": record.get("source"),
                        "status": record.get("status"),
                        "reason": record.get("reason"),
                    }
                )
            inventory.append(entry)
        return {
            "captured_at": payload.get("captured_at"),
            "user_request": (payload.get("request_context") or {}).get("user_request"),
            "records": inventory,
        }

    @staticmethod
    def _direct_start_requested(kwargs: dict[str, Any]) -> bool:
        source = str(kwargs.get("source") or "").strip().lower()
        if source:
            return source == "direct"
        direct = kwargs.get("direct")
        return direct is True or str(direct).strip().lower() in {"1", "true", "yes"}

    @staticmethod
    def _personal_chat(metadata: dict[str, Any]) -> bool:
        ctype = str(metadata.get("ctype") or metadata.get("teams_conversation_type") or "")
        return ctype.strip().lower() == "personal"

    async def _action_start(
        self, store: CurationTaskStore, metadata: dict[str, Any], kwargs: dict[str, Any]
    ) -> str:
        existing = store.active()
        if existing is not None:
            return self._dump(
                {
                    "refused": "A curation task is already open in this conversation.",
                    "guidance": (
                        "If the human is replying to this proposal, use "
                        "kb_draft(action='show') to resume it. If their message is a "
                        "new knowledge-base update or assessment request, call "
                        "kb_draft(action='restart') now; include source='direct' for a "
                        "Teams personal-chat PMO evidence packet, or capture=<snapshot> "
                        "for captured group material. Restart removes the old local Git "
                        "branch and starts the replacement task without another question."
                    ),
                    "active_task": existing.summary(),
                }
            )

        direct = self._direct_start_requested(kwargs)
        capture: Path | None = None
        if direct:
            if not self._personal_chat(metadata):
                return "Error: source='direct' is only available in a Teams personal chat."
        else:
            capture_resolved = self._resolve_capture(str(kwargs.get("capture") or ""))
            if isinstance(capture_resolved, str):
                return capture_resolved
            capture = capture_resolved

        resolved = self._repo_for_group(store.cid, str(kwargs.get("repo") or ""))
        if isinstance(resolved, str):
            return resolved
        repo = resolved
        scope = self._scope(store.cid)
        subfolder = scope.subfolder if scope else ""

        status = await asyncio.to_thread(repo.sync, timeout=self._sync_timeout())
        task = CurationTask(
            task_id=store.new_task_id(),
            cid=store.cid,
            status=STATUS_DRAFTING,
            conversation_name=str(metadata.get("conversation_name") or ""),
            started_by=str(metadata.get("sender_name") or ""),
            user_request=str(kwargs.get("user_request") or ""),
            capture_path=str(capture) if capture is not None else "",
            repo=repo.remote_url,
            base_head=status.head,
            base_branch=status.branch,
        )
        store.save(task)
        payload: dict[str, Any] = {
            "task": task.summary(),
            "source": "direct" if direct else "capture",
            "must_continue": (
                "Do not send a final recommendation list or say that no KB draft was "
                "created while this task remains in drafting state. The allowed exits "
                "are: stage a proposal, establish that no defensible change exists, or "
                "surface a blocker that requires a human answer."
            ),
        }
        if capture is not None:
            payload["capture"] = self._capture_inventory(capture)
            payload["next"] = (
                "Read the repository's own rules with kb_inspect(action='rules') "
                "before extracting anything, then record units with "
                "kb_draft(action='units'). Continue through select and stage in this "
                "same turn whenever the evidence warrants an update."
            )
        else:
            payload["next"] = (
                "This task uses the current personal-chat PMO evidence packet directly. "
                "Read the repository's own rules with kb_inspect(action='rules'), then "
                "stage complete target file contents with kb_draft(action='stage') when "
                "the evidence warrants an update. Record blockers first if repository "
                "rules conflict with the proposed change."
            )
        if subfolder:
            payload["preferred_subfolder"] = subfolder
            payload["subfolder_note"] = (
                f"This group keeps its knowledge in '{subfolder}'. Read that folder's "
                "rules first and draft there by default. It is a preference, not a "
                "limit — if the repository's own conventions place this material "
                "elsewhere, follow them and say why."
            )
        return self._dump(payload)

    async def _action_restart(
        self, store: CurationTaskStore, metadata: dict[str, Any], kwargs: dict[str, Any]
    ) -> str:
        """Drop an unfinished local proposal and immediately open a fresh task.

        This is intentionally fail-closed around the Git branch: marking the old
        task cancelled while its proposal branch survives would make a response
        claiming "dropped" untrue and leave the next run ambiguous.
        """
        existing = store.active()
        if existing is None:
            return await self._action_start(store, metadata, kwargs)

        old_task_id = existing.task_id
        old_branch = existing.proposal_branch
        cleanup = await self._discard_proposal(existing)
        if old_branch and not cleanup:
            return self._dump(
                {
                    "refused": (
                        "The old local proposal could not be discarded even after "
                        "hard-reset/reclone recovery."
                    ),
                    "old_task": existing.summary(),
                    "old_proposal_branch": old_branch,
                    "guidance": (
                        "The old task remains active and no new task was started. "
                        "The old task remains active. Repair access to the managed KB "
                        "checkout, then call kb_draft(action='restart') again."
                    ),
                }
            )

        existing.status = STATUS_CANCELLED
        store.save(existing)
        started = await self._action_start(store, metadata, kwargs)
        replacement = {
            "task_id": old_task_id,
            "status": STATUS_CANCELLED,
            "proposal_branch": old_branch,
            "proposal_branch_removed": bool(old_branch and cleanup),
            "proposal_cleanup": cleanup or "not_needed",
        }
        try:
            payload = json.loads(started)
        except json.JSONDecodeError:
            return self._dump(
                {
                    "replaced_task": replacement,
                    "restart_error": started,
                    "guidance": (
                        "The old proposal is cancelled and its branch is gone, but the "
                        "fresh task could not start. Fix the reported problem and call "
                        "kb_draft(action='start') without asking whether to resume the old task."
                    ),
                }
            )
        if isinstance(payload, dict):
            payload["replaced_task"] = replacement
            payload["restart"] = (
                "Old proposal dropped and fresh curation task started. Continue through "
                "rules, units, selection and stage in this turn; do not stop at a prose scan."
            )
        return self._dump(payload)

    def _action_units(
        self, store: CurationTaskStore, task: CurationTask, kwargs: dict[str, Any]
    ) -> str:
        incoming = kwargs.get("units")
        if not isinstance(incoming, list) or not incoming:
            return "Error: units needs a non-empty array."
        if len(task.units) + len(incoming) > _MAX_UNITS:
            return f"Error: a task holds at most {_MAX_UNITS} knowledge units."

        added: list[dict[str, Any]] = []
        for item in incoming:
            if not isinstance(item, dict):
                return "Error: every unit must be an object."
            unit_type = str(item.get("type") or "").strip()
            title = str(item.get("title") or "").strip()
            if unit_type not in _UNIT_TYPES:
                return f"Error: unit type must be one of {', '.join(_UNIT_TYPES)}."
            if not title:
                return "Error: every unit needs a title."
            unit = KnowledgeUnit(
                id=task.next_unit_id(),
                type=unit_type,
                title=title,
                content=str(item.get("content") or ""),
                evidence=list(item.get("evidence") or []),
                confidence=str(item.get("confidence") or ""),
            )
            task.units.append(unit)
            added.append({"id": unit.id, "type": unit.type, "title": unit.title})

        task.status = STATUS_DRAFTING
        store.save(task)
        return self._dump(
            {
                "task_id": task.task_id,
                "status": task.status,
                "added": added,
                "unit_count": len(task.units),
                "next": (
                    "Choose the units represented by the proposal with "
                    "kb_draft(action='select'), then build the complete documents. "
                    "The group confirms the resulting file-level draft, not a separate "
                    "unit list. Continue to stage in this same turn."
                ),
                "must_continue": (
                    "Do not stop with extracted units or recommendations; a warranted "
                    "update must become a staged proposal before the final reply."
                ),
            }
        )

    def _action_select(
        self, store: CurationTaskStore, task: CurationTask, kwargs: dict[str, Any]
    ) -> str:
        if not task.units:
            return "Error: nothing to select — record units first."
        if kwargs.get("all"):
            chosen = [unit.id for unit in task.units]
        else:
            raw = kwargs.get("unit_ids")
            if not isinstance(raw, list) or not raw:
                return "Error: select needs unit_ids, or all=true."
            chosen = [str(item).strip() for item in raw if str(item).strip()]
            unknown = [uid for uid in chosen if task.unit(uid) is None]
            if unknown:
                return f"Error: unknown unit id(s): {', '.join(unknown)}."

        for unit in task.units:
            unit.selected = unit.id in chosen
        task.status = STATUS_DRAFTING
        store.save(task)
        return self._dump(
            {
                "task_id": task.task_id,
                "selected": chosen,
                "dropped": [unit.id for unit in task.units if not unit.selected],
                "next": (
                    "Check the governing repository rules, record any conflict, then "
                    "stage the complete documents with their macro, one-line, and "
                    "detailed summaries in this same turn."
                ),
                "must_continue": (
                    "Do not answer with a candidate list or say no proposal exists. "
                    "Call kb_draft(action='stage') before replying unless a real blocker "
                    "prevents a reviewable proposal."
                ),
            }
        )

    def _action_blockers(
        self, store: CurationTaskStore, task: CurationTask, kwargs: dict[str, Any]
    ) -> str:
        incoming = kwargs.get("blockers")
        if not isinstance(incoming, list) or not incoming:
            return "Error: blockers needs a non-empty array."

        added: list[dict[str, Any]] = []
        for item in incoming:
            if not isinstance(item, dict):
                return "Error: every blocker must be an object."
            rule_source = str(item.get("rule_source") or "").strip()
            rule = str(item.get("rule") or "").strip()
            conflict = str(item.get("conflict") or "").strip()
            if not (rule_source and rule and conflict):
                return "Error: every blocker needs rule_source, rule and conflict."
            blocker = RuleBlocker(
                id=task.next_blocker_id(),
                rule_source=rule_source,
                rule=rule,
                conflict=conflict,
            )
            task.blockers.append(blocker)
            added.append(blocker.to_dict())

        store.save(task)
        return self._dump(
            {
                "task_id": task.task_id,
                "recorded": added,
                "open_blockers": len(task.open_blockers),
                "next": (
                    "Staging is blocked until the group answers these. Put each rule "
                    "and the conflict in front of them, then record their decision "
                    "with kb_draft(action='resolve_blocker'). Do not quietly draft "
                    "around a rule."
                ),
            }
        )

    def _action_resolve_blocker(
        self, store: CurationTaskStore, task: CurationTask, kwargs: dict[str, Any]
    ) -> str:
        blocker_id = str(kwargs.get("blocker_id") or "").strip()
        resolution = str(kwargs.get("resolution") or "").strip()
        blocker = task.blocker(blocker_id)
        if blocker is None:
            return f"Error: unknown blocker id '{blocker_id}'."
        if resolution not in (BLOCKER_RESOLVED, BLOCKER_OVERRIDDEN):
            return f"Error: resolution must be '{BLOCKER_RESOLVED}' or '{BLOCKER_OVERRIDDEN}'."
        note = str(kwargs.get("note") or "").strip()
        if resolution == BLOCKER_OVERRIDDEN and not note:
            return (
                "Error: an override needs a note. It goes into the commit message, so "
                "the reason a stated rule was broken lives in the repository's history."
            )

        blocker.status = resolution
        blocker.resolution = note
        blocker.decided_by = str(kwargs.get("decided_by") or "").strip()
        store.save(task)
        return self._dump(
            {
                "task_id": task.task_id,
                "blocker": blocker.to_dict(),
                "open_blockers": len(task.open_blockers),
                "note": (
                    "This override will be recorded in the commit message."
                    if resolution == BLOCKER_OVERRIDDEN
                    else "The rule conflict is resolved; continue staging the proposal."
                ),
            }
        )

    async def _action_stage(
        self, store: CurationTaskStore, task: CurationTask, kwargs: dict[str, Any]
    ) -> str:
        incoming = kwargs.get("changes")
        if not isinstance(incoming, list) or not incoming:
            return "Error: stage needs a non-empty changes array."
        message = str(kwargs.get("message") or "").strip()
        overview = str(kwargs.get("overview") or "").strip()
        if not message:
            return (
                "Error: message is required — it is shown in both natural-language "
                "confirmations and used for the final squashed commit."
            )
        if not overview:
            return "Error: overview is required for the draft confirmation."
        if len(incoming) > MAX_CHANGES:
            return f"Error: at most {MAX_CHANGES} documents per task."
        if not task.selected_units and task.units:
            return "Error: select the knowledge units represented by this proposal before staging."
        # An open rule conflict stops here rather than at publish. A polished
        # proposal summary that silently walked past a rule is exactly the
        # artefact that gets approved by mistake.
        if task.open_blockers:
            return self._dump(
                {
                    "refused": "This draft conflicts with rules the knowledge base states.",
                    "open_blockers": [item.to_dict() for item in task.open_blockers],
                    "next": (
                        "Show each rule and conflict to the group and ask how to "
                        "proceed. Either change the draft so the conflict disappears "
                        "and record kb_draft(action='resolve_blocker', "
                        f"resolution='{BLOCKER_RESOLVED}'), or — if they explicitly "
                        "decide to proceed anyway — record "
                        f"resolution='{BLOCKER_OVERRIDDEN}' with their reason, which "
                        "will appear in the commit message."
                    ),
                }
            )

        resolved = self._repo_for_task(task.repo)
        if isinstance(resolved, str):
            return resolved
        repo = resolved

        staged: list[StagedChange] = []
        seen_paths: set[str] = set()
        for item in incoming:
            if not isinstance(item, dict):
                return "Error: every change must be an object."
            path = str(item.get("path") or "").strip()
            operation = str(item.get("operation") or "").strip()
            content = _normalize_change_content(str(item.get("content") or ""))
            summary = str(item.get("summary") or "").strip()
            raw_details = item.get("details")
            problem = validate_change(path, operation, content)
            if problem:
                return f"Error: {problem}"
            if path in seen_paths:
                return f"Error: duplicate change path '{path}'."
            seen_paths.add(path)
            if not summary:
                return f"Error: change to '{path}' needs a one-line summary."
            if not isinstance(raw_details, list) or not any(str(x).strip() for x in raw_details):
                return f"Error: change to '{path}' needs non-empty details."
            details = [str(value).strip() for value in raw_details if str(value).strip()]
            # Path safety first: resolve_within raises for anything outside the
            # checkout. Existence is then judged against HEAD, not the working
            # tree, so an untracked leftover cannot be mistaken for KB content.
            repo.resolve_within(path)
            tracked = repo.file_at_head(path) is not None
            if operation == "create" and tracked:
                return (
                    f"'{path}' already exists — use operation='update' and supply the "
                    "complete new content."
                )
            if operation == "update" and not tracked:
                return f"'{path}' does not exist — use operation='create'."
            unit_ids = [str(u) for u in (item.get("units") or [])]
            resolved_units = {uid: task.unit(uid) for uid in unit_ids}
            unknown = [uid for uid, unit in resolved_units.items() if unit is None]
            unselected = [
                uid
                for uid, unit in resolved_units.items()
                if unit is not None and not unit.selected
            ]
            if unknown:
                return (
                    f"Error: change to '{path}' references unknown unit(s): {', '.join(unknown)}."
                )
            if unselected:
                return (
                    f"Error: change to '{path}' references unselected unit(s): "
                    f"{', '.join(unselected)}."
                )
            staged.append(
                StagedChange(
                    path=path,
                    operation=operation,
                    content=content,
                    summary=summary,
                    details=details,
                    rationale=str(item.get("rationale") or ""),
                    units=unit_ids,
                )
            )

        covered_units = {unit_id for change in staged for unit_id in change.units}
        missing_units = [unit.id for unit in task.selected_units if unit.id not in covered_units]
        if missing_units:
            return (
                "Error: every selected knowledge unit must be represented by at least "
                f"one file; missing: {', '.join(missing_units)}."
            )

        task.changes = staged
        task.commit_message = commit_message_for(message, task)
        task.overview = overview
        task.status = STATUS_AWAITING_DRAFT
        task.draft_presented_turn = _turn_id(kwargs)
        _log_diff_materials(task)
        await self._refresh_proposal(task, repo)
        store.save(task)
        return self._draft_confirmation(task)

    async def _refresh_proposal(self, task: CurationTask, repo: KbRepo) -> None:
        """Refresh the local proposal and its best-effort Draft PR mirror."""
        branch = proposal_branch_name(task.task_id)
        home = task.base_branch or await asyncio.to_thread(repo.branch)
        base = task.base_head or await asyncio.to_thread(repo.head)
        paths = [change.path for change in task.changes]
        logger.info(
            "kb_draft_pr.status step=proposal outcome=start task={} branch={} home={} "
            "base={} files={}",
            task.task_id,
            branch,
            home,
            base[:12],
            len(paths),
        )
        try:
            current_branch = await asyncio.to_thread(repo.branch)
            if current_branch != home:
                logger.debug(
                    "kb_draft_pr.status step=proposal_checkout outcome=start from_branch={} "
                    "to_branch={}",
                    current_branch,
                    home,
                )
                await asyncio.to_thread(repo.checkout, home)
                logger.debug(
                    "kb_draft_pr.status step=proposal_checkout outcome=succeeded branch={}", home
                )
            logger.debug(
                "kb_draft_pr.status step=proposal_branch outcome=start branch={} base={}",
                branch,
                base[:12],
            )
            await asyncio.to_thread(repo.start_branch, branch, base)
            logger.debug(
                "kb_draft_pr.status step=proposal_branch outcome=succeeded branch={}", branch
            )
            try:
                logger.debug(
                    "kb_draft_pr.status step=proposal_write outcome=start files={}", len(paths)
                )
                for change in task.changes:
                    target = repo.resolve_within(change.path)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_text(change.content, encoding="utf-8", newline="\n")
                logger.debug(
                    "kb_draft_pr.status step=proposal_write outcome=succeeded files={}", len(paths)
                )
                logger.info(
                    "kb_draft_pr.status step=proposal_commit outcome=start branch={} files={}",
                    branch,
                    len(paths),
                )
                sha = await asyncio.to_thread(repo.commit, paths, task.commit_message)
                logger.info(
                    "kb_draft_pr.status step=proposal_commit outcome=succeeded branch={} sha={}",
                    branch,
                    sha[:12],
                )
            except Exception as exc:
                logger.warning(
                    "kb_draft_pr.status step=proposal outcome=failed branch={} "
                    "error_type={} action=rollback",
                    branch,
                    type(exc).__name__,
                )
                await asyncio.to_thread(repo.rollback, base, paths)
                logger.info(
                    "kb_draft_pr.status step=proposal_rollback outcome=complete branch={} base={}",
                    branch,
                    base[:12],
                )
                raise
        finally:
            current_branch = await asyncio.to_thread(repo.branch)
            if current_branch != home:
                logger.debug(
                    "kb_draft_pr.status step=proposal_restore outcome=start from_branch={} "
                    "to_branch={}",
                    current_branch,
                    home,
                )
                await asyncio.to_thread(repo.checkout, home)
                logger.debug(
                    "kb_draft_pr.status step=proposal_restore outcome=succeeded branch={}", home
                )

        task.proposal_branch = branch
        task.proposal_sha = sha
        logger.info(
            "kb_draft_pr.status step=review_mirror outcome=start branch={} sha={}",
            branch,
            sha[:12],
        )
        task.proposal_review = await asyncio.to_thread(
            upsert_draft_review,
            repo,
            branch=branch,
            sha=sha,
            base=home,
            title=task.commit_message.splitlines()[0],
            overview=task.overview,
            changes=[{"path": change.path, "summary": change.summary} for change in task.changes],
            current=task.proposal_review,
        )
        logger.info(
            "kb_draft_pr.status step=review_mirror outcome={} branch={} number={}",
            "available" if task.proposal_review.get("url") else "unavailable",
            branch,
            int(task.proposal_review.get("number") or 0),
        )
        logger.info("kb_draft: local proposal commit {} on {}", sha[:8], branch)

    @staticmethod
    def _draft_confirmation(task: CurationTask) -> str:
        payload: dict[str, Any] = {
            "task_id": task.task_id,
            "status": task.status,
            "repo": task.repo,
            "base_head": task.base_head,
            "commit_message": task.commit_message,
            "proposal_sha": task.proposal_sha,
            "proposal_review": task.proposal_review or None,
            "confirmation": {
                "overview": task.overview,
                "files": [
                    {
                        "path": change.path,
                        "operation": change.operation,
                        "summary": change.summary,
                        "details": change.details,
                    }
                    for change in task.changes
                ],
            },
            "next": (
                "Present confirmation.overview, every file path, and every details item "
                "as an ordinary chat message. If proposal_review.url exists, present it "
                "as a Markdown link labeled with the Draft PR number instead of a naked "
                "URL. Ask whether this draft is correct, then END YOUR TURN. Record the "
                "next human reply with kb_draft(action='approve', stage='draft', ...). "
                "Do not paste the diff into chat or use an Adaptive Card."
            ),
        }
        review = task.proposal_review
        if (
            review.get("state") == "open"
            and review.get("synced_sha") == task.proposal_sha
            and review.get("url")
        ):
            payload["review_url"] = review["url"]
            payload["review_note"] = (
                "Include this optional Draft PR link with the ordinary-chat summary so "
                "the group can inspect the actual diff. Approval still happens in chat."
            )
        return json.dumps(payload, ensure_ascii=False, indent=2)

    def _action_approve(
        self,
        store: CurationTaskStore,
        task: CurationTask,
        kwargs: dict[str, Any],
        metadata: dict[str, Any],
    ) -> str:
        """Record the group's answer to the staged proposal, in their words."""
        stage = str(kwargs.get("stage") or "").strip()
        if stage not in DECISION_STAGES:
            return f"Error: stage must be one of {', '.join(DECISION_STAGES)}."
        decision = str(kwargs.get("decision") or "").strip()
        if decision not in DECISIONS:
            return f"Error: decision must be one of {', '.join(DECISIONS)}."
        quote = str(kwargs.get("quote") or "").strip()
        if not quote:
            return (
                "Error: quote is required — paste the group's own words. A decision "
                "read out of chat is only auditable if what was read is recorded."
            )
        laundered = machine_authored_quote(quote)
        if laundered:
            return f"Error: {laundered}"

        if not task.changes or not task.proposal_sha:
            return "Error: no local proposal commit exists — run kb_draft(action='stage') first."
        presented = task.draft_presented_turn
        turn = _turn_id(kwargs)
        # An answer cannot arrive on the same inbound turn that produced the
        # question. Without this the model could propose, "approve" and publish
        # in one breath, having shown the group nothing.
        if turn and presented and turn == presented:
            return (
                "Error: this is the same turn the material was put to the group on, so "
                "no one can have answered yet. Post it, end your turn, and record their "
                "reply when it arrives."
            )
        if not turn or not presented:
            logger.warning(
                "kb_draft.approve: no turn identity (turn={!r} presented={!r}) — "
                "recording without the same-turn check",
                turn,
                presented,
            )

        record = GroupDecision(
            stage=stage,
            decision=decision,
            by=str(kwargs.get("by") or metadata.get("sender_name") or "").strip(),
            quote=quote,
            turn_id=turn,
            fingerprint=task.change_fingerprint(),
        )
        task.decisions.append(record)

        payload: dict[str, Any] = {
            "task_id": task.task_id,
            "recorded": record.to_dict(),
        }
        if decision != DECISION_APPROVED:
            task.status = STATUS_AWAITING_DRAFT
            payload["next"] = (
                "Not an approval. Do not publish. If they requested changes, restage "
                "the local proposal and put the updated summary to the group again; "
                "otherwise cancel the task."
            )
        else:
            task.status = STATUS_AWAITING_PUBLISH
            payload["next"] = (
                "The staged proposal is approved. Call kb_publish NOW in this same "
                "turn without asking a second publish-confirmation question. It will "
                "validate this fingerprint, merge origin/main automatically, squash "
                "the local proposal, push, persist the detailed receipt, and return "
                "a minimal outcome. Use that outcome as factual input for one short, "
                "nontechnical sentence in the user's language; preserve its clickable "
                "link and do not explain Git mechanics unless asked."
            )
        store.save(task)
        return self._dump(payload)

    async def _action_show(self, store: CurationTaskStore, task: CurationTask) -> str:
        payload: dict[str, Any] = {
            "task": task.summary(),
            "user_request": task.user_request,
            "units": [unit.to_dict() for unit in task.units],
            "blockers": [item.to_dict() for item in task.blockers],
            "required_for_new_request": (
                "If the current human message is a NEW knowledge-base update or "
                "assessment request rather than a reply about this task, call "
                "kb_draft(action='restart', user_request=<current request>) now; "
                "add source='direct' for a Teams personal-chat PMO evidence packet, "
                "or capture=<snapshot> for captured group material. This must delete "
                "the old proposal branch and start a fresh task before you continue."
            ),
        }
        resolved = self._repo_for_task(task.repo)
        if isinstance(resolved, KbRepo) and resolved.is_cloned:
            current = await asyncio.to_thread(resolved.head)
            payload["repo_moved"] = bool(task.base_head and current != task.base_head)
            payload["current_head"] = current
        if task.status == STATUS_AWAITING_PUBLISH and task.draft_approval() is not None:
            payload["required_next"] = (
                "Call kb_publish now without asking for publish confirmation; then give "
                "one short, nontechnical result sentence in the user's language, preserving "
                "the returned clickable link."
            )
        return self._dump(payload)

    async def _action_cancel(self, store: CurationTaskStore, task: CurationTask) -> str:
        branch = task.proposal_branch
        cleanup = await self._discard_proposal(task)
        if branch and not cleanup:
            return self._dump(
                {
                    "refused": "The local proposal branch could not be removed.",
                    "task_id": task.task_id,
                    "status": task.status,
                    "proposal_branch": branch,
                    "guidance": "The task remains active; fix branch cleanup and retry cancel.",
                }
            )
        task.status = STATUS_CANCELLED
        store.save(task)
        return self._dump(
            {
                "task_id": task.task_id,
                "status": task.status,
                "proposal_branch_removed": bool(branch and cleanup),
                "proposal_cleanup": cleanup or "not_needed",
            }
        )

    async def _discard_proposal(self, task: CurationTask) -> str:
        """Drop the optional Draft PR mirror and authoritative local branch."""
        branch = task.proposal_branch
        if not branch and not task.proposal_review:
            return "not_needed"
        resolved = self._repo_for_task(task.repo)
        if not isinstance(resolved, KbRepo) or not resolved.is_cloned:
            return ""
        try:
            task.proposal_review = await asyncio.to_thread(
                close_draft_review,
                resolved,
                task.proposal_review,
                fallback_branch=branch,
            )
            if not branch:
                return "not_needed"
            current = await asyncio.to_thread(resolved.branch)
            if current == branch and task.base_branch:
                await asyncio.to_thread(resolved.checkout, task.base_branch)
            removed = await asyncio.to_thread(resolved.delete_local_branch, branch)
            cleanup = "delete"
            if not removed:
                logger.warning(
                    "kb_draft: ordinary branch deletion failed; forcing checkout recovery: {}",
                    branch,
                )
                cleanup = await asyncio.to_thread(
                    resolved.force_discard_local_proposal,
                    branch,
                    base_branch=task.base_branch,
                    base_head=task.base_head,
                    timeout=self._sync_timeout(),
                )
        except KbRepoError as exc:
            logger.info("kb_draft: could not remove proposal branch {} — {}", branch, exc)
            return ""
        task.proposal_branch = ""
        return cleanup

    @staticmethod
    def _dump(payload: dict[str, Any]) -> str:
        return json.dumps(payload, ensure_ascii=False, indent=2)
