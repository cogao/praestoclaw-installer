"""Conversation-scoped Teams capture for the praesto tag exp group turn.

This replaces the Teams MCP as the evidence source. The difference that matters
is not fidelity but *scope*: the MCP search tools have no ``chatId`` filter at
all — the only thing keeping a transcript search inside one meeting was the
wording of a prompt, enforced by a model. A date-only query was observed
returning 34 unrelated chatIds while missing the very meeting it was asked
about.

Here the conversation id is taken from the turn's own metadata. ``chat_id`` may
be passed, but only to be checked against it; a mismatch is refused. There is
no code path in this tool, or in the ``teams_web`` package beneath it, that can
read another conversation.

Captures accumulate rather than replace. Each ``messages`` call pulls only what
is newer than the cache and writes it as its own time-ranged segment, so a
narrow follow-up query can no longer destroy a broad earlier capture.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Literal

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.praesto_tag_exp import praesto_tag_exp_is_active
from praestoclaw.security.risk import RiskAssessment, RiskScore
from praestoclaw.teams_web.chatsvc import (
    DEFAULT_MAX_PAGES,
    ChatsvcAuthError,
    ChatsvcError,
    TeamsChatsvcClient,
    build_message_digest,
    parse_message_time,
    summarize_message,
)
from praestoclaw.teams_web.recordings import (
    ALL_RENDITIONS,
    RENDITION_AMS,
    RENDITION_ODSP,
    RecordingPointer,
    TranscriptCue,
    TranscriptFetchError,
    cues_to_text,
    fetch_ams_transcript,
    fetch_odsp_transcript,
    parse_recording_pointers,
    parse_vtt,
)
from praestoclaw.teams_web.store import TeamsWebChatStore
from praestoclaw.teams_web.tokens import (
    IC3_AUDIENCE,
    TeamsWebTokenError,
    TeamsWebTokenProvider,
    default_token_cache_path,
)

_ACTIONS = ("messages", "read", "materials", "transcripts", "read_transcript", "status")
_DEFAULT_READ_LIMIT = 50
_MAX_READ_LIMIT = 200
_DEFAULT_CUE_LIMIT = 200
_MAX_CUE_LIMIT = 1000
_SYSTEM_TYPE_PREFIXES = ("ThreadActivity/", "Event/", "RichText/Media_")
_GRAPH_AUDIENCE = "graph.microsoft.com"


def _parse_when(value: str) -> datetime | None:
    """Accept ``2026-07-20``, ``2026-07-20T08:00:00`` or a full ISO timestamp.

    Delegates to the chatsvc parser so a caller-supplied bound and a message
    timestamp are always comparable — both come back aware.
    """
    text = (value or "").strip()
    if not text:
        return None
    return parse_message_time(text)


def _iso(moment: datetime | None) -> str | None:
    return moment.astimezone(UTC).isoformat() if moment else None


def _is_system(message_type: str) -> bool:
    return any(message_type.startswith(prefix) for prefix in _SYSTEM_TYPE_PREFIXES)


class TeamsGroupFetchTool(Tool):
    """Read the current Teams conversation and its meeting transcripts."""

    risk_range = (3, 3)

    def __init__(self, teams_web_config: Any = None) -> None:
        self._config = teams_web_config
        self._token_provider: TeamsWebTokenProvider | None = None

    @property
    def name(self) -> str:
        return "teams_group_fetch"

    @property
    def description(self) -> str:
        return (
            "Read the CURRENT Teams group conversation and its meeting transcripts "
            "directly from the Teams Web session. Actions: 'messages' pulls what is "
            "not cached yet (including the system events Graph hides: renames, call "
            "boundaries and transcript pointers) and appends it as a new time-ranged "
            "segment; 'read' returns cached messages across segments; 'materials' "
            "downloads message-linked images and common document files to this "
            "conversation's local cache (never audio/video); 'transcripts' downloads "
            "the verbatim VTT renditions the chat itself points at; "
            "'read_transcript' returns all matching cached transcript dialogue as one "
            "globally paged cue stream; 'status' reports "
            "what is already cached and the range it covers. Every action is locked "
            "to this conversation — it cannot read any other chat, and it never "
            "searches the tenant."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=300, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(3, reason="Read-only capture of the current Teams conversation")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": list(_ACTIONS),
                    "description": (
                        "messages = pull whatever is not cached yet and append it as a new "
                        "segment; read = page through cached messages; "
                        "materials = download cached message-linked images/common documents "
                        "(not audio/video); transcripts = download meeting transcripts; "
                        "read_transcript = page through all matching cached "
                        "transcripts as one global cue stream; status = what is cached already "
                        "and the range it covers."
                    ),
                },
                "chat_id": {
                    "type": "string",
                    "description": (
                        "Optional. Must equal this turn's conversation id; supplied only so "
                        "the call can be checked. Omit it to use the current conversation."
                    ),
                },
                "since": {
                    "type": "string",
                    "description": "ISO date/time lower bound, e.g. 2026-07-20 or "
                    "2026-07-20T00:00:00Z.",
                },
                "until": {
                    "type": "string",
                    "description": "ISO date/time upper bound (applies to 'read').",
                },
                "refresh": {
                    "type": "boolean",
                    "description": (
                        "For 'messages': discard every cached segment and re-capture from "
                        "scratch. Only needed when older messages may have been edited or "
                        "deleted — an ordinary call already picks up everything new."
                    ),
                },
                "max_pages": {
                    "type": "integer",
                    "description": "Page budget for 'messages' (default 20).",
                },
                "types": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter 'read' to these messagetype values, "
                    "e.g. ['RichText/Html'].",
                },
                "include_system": {
                    "type": "boolean",
                    "description": "Include ThreadActivity/Event/Media system messages in "
                    "'read'. Default true.",
                },
                "offset": {
                    "type": "integer",
                    "description": "Paging offset for read actions; for 'read_transcript' this "
                    "is a global cue offset across all matching transcripts.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Paging limit for read actions (messages default 50/max 200; "
                    "transcript cues default 200/max 1000).",
                },
                "call_id": {
                    "type": "string",
                    "description": "Restrict 'transcripts'/'read_transcript' to one recorded call, "
                    "including every transcript part belonging to it.",
                },
                "renditions": {
                    "type": "array",
                    "items": {"type": "string", "enum": list(ALL_RENDITIONS)},
                    "description": "'ams' has ground-truth speaker tags; 'odsp' has none but is "
                    "more durable. Default: both.",
                },
                "rendition": {
                    "type": "string",
                    "enum": list(ALL_RENDITIONS),
                    "description": "Which cached rendition 'read_transcript' should read for "
                    "each matching transcript. Default: ams, falling back to odsp.",
                },
            },
            "required": ["action"],
        }

    # ── Execution ────────────────────────────────────────────────────────────

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata") or {}
        if not praesto_tag_exp_is_active(metadata):
            return "teams_group_fetch is only available in a praesto tag exp group session."
        if not self._enabled():
            return "teams_group_fetch is disabled in this agent's configuration."

        cid = str(metadata.get("cid") or "").strip()
        if not cid:
            return "teams_group_fetch: this turn has no Teams conversation id."

        requested = str(kwargs.get("chat_id") or "").strip()
        if requested and requested != cid:
            logger.warning(
                "[teams_web] refused cross-conversation request: asked={} current={}",
                requested,
                cid,
            )
            return (
                "teams_group_fetch is scoped to the conversation this request came from "
                f"({cid}). It cannot read {requested}. Omit chat_id to use the current chat."
            )

        action = str(kwargs.get("action") or "").strip()
        if action not in _ACTIONS:
            return f"Error: action must be one of {', '.join(_ACTIONS)}."

        store = TeamsWebChatStore(cid, root=self._cache_root())
        try:
            if action == "status":
                return self._action_status(store)
            if action == "messages":
                return await self._action_messages(store, kwargs)
            if action == "read":
                return self._action_read(store, kwargs)
            if action == "materials":
                return await self._action_materials(store, kwargs)
            if action == "transcripts":
                return await self._action_transcripts(store, kwargs)
            return self._action_read_transcript(store, kwargs)
        except TeamsWebTokenError as exc:
            return f"Teams Web session unavailable: {exc}"
        except ChatsvcError as exc:
            return f"Teams chat service error: {exc}"

    # ── Actions ──────────────────────────────────────────────────────────────

    def _action_status(self, store: TeamsWebChatStore) -> str:
        stored = store.load_messages()
        token = self._provider().peek()
        high_water = store.high_water()
        return self._dump(
            {
                "conversation_id": store.cid,
                "cache_dir": str(store.root),
                "messages_cached": stored.count,
                "messages_fetched_at": stored.fetched_at or None,
                "region": stored.region or None,
                "covered_from": _iso(store.earliest_cached()),
                "covered_to": _iso(high_water),
                "segments": [segment.to_index_entry() for segment in store.load_segments()],
                "recordings_known": len(store.load_transcript_inventory()),
                "teams_web_token": (
                    {"cached": True, "seconds_left": token.seconds_left()}
                    if token
                    else {"cached": False}
                ),
            }
        )

    async def _action_messages(self, store: TeamsWebChatStore, kwargs: dict[str, Any]) -> str:
        since = _parse_when(str(kwargs.get("since") or ""))
        if kwargs.get("since") and since is None:
            return "Error: 'since' must be an ISO date or timestamp."

        refresh = bool(kwargs.get("refresh"))
        mode, fetch_since = self._plan_pull(store, since=since, refresh=refresh)

        max_pages = int(kwargs.get("max_pages") or self._config_int("max_pages", DEFAULT_MAX_PAGES))
        token = await self._provider().get_token(IC3_AUDIENCE)
        try:
            result = await self._fetch(
                store.cid, token.secret, since=fetch_since, max_pages=max_pages
            )
        except ChatsvcAuthError:
            # The classic race: a stale token was cached moments before Teams
            # renewed it. Force one re-acquisition before giving up.
            logger.info("[teams_web] ic3 token rejected; forcing re-acquisition")
            token = await self._provider().get_token(IC3_AUDIENCE, force_refresh=True)
            result = await self._fetch(
                store.cid, token.secret, since=fetch_since, max_pages=max_pages
            )

        page_metadata = [page.get("_metadata") for page in result.raw_pages]
        if refresh:
            written = store.replace_messages(
                result.messages, region=result.region, page_metadata=page_metadata
            )
        else:
            written = store.append_messages(
                result.messages, region=result.region, page_metadata=page_metadata
            )

        # Recording pointers are re-derived from every cached message, not just
        # this delta, so an incremental pull never drops a meeting captured
        # earlier.
        everything = store.load_messages()
        pointers = parse_recording_pointers(everything.messages)
        store.save_transcript_inventory([p.to_dict() for p in pointers])

        window = store.load_messages(since=since) if since else everything
        digest = build_message_digest(store.cid, window.messages)
        return self._dump(
            {
                "source": "teams",
                "pull_mode": mode,
                "pulled_since": _iso(fetch_since),
                "region": result.region,
                "pages_fetched": result.pages_fetched,
                "reached_requested_start": result.reached_start,
                "foreign_messages_dropped": result.foreign_messages_dropped,
                "new_messages": sum(segment.count for segment in written),
                "new_segments": [segment.to_index_entry() for segment in written],
                "total_cached": everything.count,
                "covered_from": _iso(store.earliest_cached()),
                "covered_to": _iso(store.high_water()),
                "segments": [segment.to_index_entry() for segment in store.load_segments()],
                "cache_dir": str(store.messages_dir),
                **digest,
                "recordings": [p.to_dict() for p in pointers],
            }
        )

    @staticmethod
    def _plan_pull(
        store: TeamsWebChatStore, *, since: datetime | None, refresh: bool
    ) -> tuple[str, datetime | None]:
        """Decide how far back this pull has to reach.

        A delta anchored on the newest cached message is the common case and
        usually costs one page. It is only valid when the cache already covers
        everything the caller asked for — a ``since`` older than the earliest
        segment needs a backfill instead, or the gap would never be filled.
        """
        if refresh:
            return "full_refresh", since
        segments = store.load_segments()
        if not segments:
            return "initial", since
        earliest = store.earliest_cached()
        if since is not None and earliest is not None and since < earliest:
            return "backfill", since
        return "delta", store.high_water()

    def _action_read(self, store: TeamsWebChatStore, kwargs: dict[str, Any]) -> str:
        since = _parse_when(str(kwargs.get("since") or ""))
        until = _parse_when(str(kwargs.get("until") or ""))
        cached = store.load_messages(since=since, until=until)
        if not cached.count:
            if not store.load_segments():
                return "No cached messages for this conversation yet. Run action='messages' first."
            return self._dump(
                {
                    "conversation_id": store.cid,
                    "matched": 0,
                    "returned": 0,
                    "messages": [],
                    "note": "No cached message falls in that window.",
                    "covered_from": _iso(store.earliest_cached()),
                    "covered_to": _iso(store.high_water()),
                }
            )

        wanted = {str(t) for t in (kwargs.get("types") or []) if str(t).strip()}
        include_system = kwargs.get("include_system")
        include_system = True if include_system is None else bool(include_system)

        selected: list[dict[str, Any]] = []
        for message in cached.messages:
            message_type = str(message.get("messagetype") or "")
            if wanted and message_type not in wanted:
                continue
            if not include_system and _is_system(message_type):
                continue
            selected.append(message)

        offset = max(0, int(kwargs.get("offset") or 0))
        limit = min(_MAX_READ_LIMIT, max(1, int(kwargs.get("limit") or _DEFAULT_READ_LIMIT)))
        window = selected[offset : offset + limit]
        return self._dump(
            {
                "conversation_id": store.cid,
                "fetched_at": cached.fetched_at,
                "segments_read": [segment.name for segment in cached.segments],
                "matched": len(selected),
                "offset": offset,
                "returned": len(window),
                "has_more": offset + len(window) < len(selected),
                "messages": [summarize_message(m) for m in window],
            }
        )

    async def _action_materials(self, store: TeamsWebChatStore, kwargs: dict[str, Any]) -> str:
        """Download only file/image URLs directly present in cached messages."""
        from praestoclaw.agent.attachments.preprocessor import (
            AttachmentRef,
            FetchedAttachment,
            extract_text_content,
            is_supported_text_attachment,
        )
        from praestoclaw.teams_web.chatsvc import normalize_message_for_capture
        from praestoclaw.teams_web.materials import MaterialFetchError, fetch_message_material

        cached = store.load_messages()
        if not cached.count:
            return "No cached messages for this conversation yet. Run action='messages' first."
        token = await self._provider().get_token(IC3_AUDIENCE)
        graph_token = ""
        try:
            graph_token = (await self._provider().get_token(_GRAPH_AUDIENCE)).secret
        except TeamsWebTokenError:
            # A signed upload URL or IC3-authorized item can still be fetched;
            # only ordinary OneDrive share links need the Graph fallback.
            logger.debug("[teams_web] Graph token unavailable for OneDrive share-link fallback")
        results: list[dict[str, Any]] = []
        downloads: dict[str, Any] = {}
        by_id = {
            str(message.get("id") or ""): message
            for message in cached.messages
            if message.get("id")
        }
        for message in cached.messages:
            normalized = normalize_message_for_capture(message)
            message_id = message.get("id")
            groups: list[tuple[str, list[dict[str, Any]], Literal["image", "file"], Any]] = [
                ("message", normalized["images"], "image", message_id),
                ("message", normalized["file_attachments"], "file", message_id),
            ]
            quote = normalized.get("quoted_original")
            if isinstance(quote, dict):
                groups.extend(
                    [
                        ("quoted_preview", quote["images"], "image", message_id),
                        ("quoted_preview", quote["file_attachments"], "file", message_id),
                    ]
                )
                quote_id = str(quote.get("referenced_message_id") or "")
                if original := by_id.get(quote_id):
                    original_view = normalize_message_for_capture(original)
                    groups.extend(
                        [
                            (
                                "quoted_original",
                                original_view["images"],
                                "image",
                                original.get("id"),
                            ),
                            (
                                "quoted_original",
                                original_view["file_attachments"],
                                "file",
                                original.get("id"),
                            ),
                        ]
                    )
            for origin, refs, material_kind, source_message_id in groups:
                for ref in refs:
                    url = str(ref.get("url") or "").strip()
                    if not url:
                        continue
                    source = {
                        "message_id": source_message_id,
                        "origin": origin,
                        "raw_reference": ref.get("raw"),
                    }
                    try:
                        downloaded = downloads.get(url)
                        if downloaded is None:
                            downloaded = await fetch_message_material(
                                url,
                                access_token=token.secret,
                                graph_access_token=graph_token,
                            )
                            downloads[url] = downloaded
                        metadata = store.save_artifact(
                            downloaded.data,
                            name=str(ref.get("name") or ""),
                            content_type=downloaded.content_type,
                            source=source,
                        )
                        attachment = AttachmentRef(
                            index=1,
                            url=url,
                            kind=material_kind,
                            name=str(ref.get("name") or ""),
                            content_type=downloaded.content_type,
                            file_type=str(ref.get("extension") or ""),
                            source="teams_web_capture",
                            requires_auth=True,
                        )
                        if (
                            is_supported_text_attachment(attachment)
                            and "text_cache_path" not in metadata
                        ):
                            try:
                                text, extraction = await extract_text_content(
                                    attachment,
                                    FetchedAttachment(downloaded.data, downloaded.content_type),
                                )
                                metadata = (
                                    store.save_artifact_text(
                                        metadata["sha256"], text, extraction=extraction
                                    )
                                    or metadata
                                )
                            except Exception as exc:  # noqa: BLE001 - keep raw artifact on converter failure
                                metadata["text_extraction_error"] = str(exc)
                                results.append(
                                    {
                                        "status": "source_gap",
                                        "message_id": source_message_id,
                                        "origin": origin,
                                        "raw_reference": ref.get("raw"),
                                        "reason": f"text extraction failed: {exc}",
                                    }
                                )
                        results.append({"status": "downloaded", **metadata})
                    except (MaterialFetchError, OSError, ValueError) as exc:
                        results.append(
                            {
                                "status": "source_gap",
                                "message_id": source_message_id,
                                "origin": origin,
                                "raw_reference": ref.get("raw"),
                                "url": url,
                                "reason": str(exc),
                            }
                        )
                    except Exception as exc:  # noqa: BLE001 - one malformed item must not abort capture
                        logger.exception(
                            "[teams_web] material processing failed for message {}",
                            source_message_id,
                        )
                        results.append(
                            {
                                "status": "source_gap",
                                "message_id": source_message_id,
                                "origin": origin,
                                "raw_reference": ref.get("raw"),
                                "url": url,
                                "reason": f"material processing failed: {exc}",
                            }
                        )
        return self._dump(
            {
                "conversation_id": store.cid,
                "artifacts": results,
                "cached_artifact_count": len(store.load_artifact_metadata()),
                "note": "Audio and video references are retained in messages but never fetched.",
            }
        )

    async def _action_transcripts(self, store: TeamsWebChatStore, kwargs: dict[str, Any]) -> str:
        cached = store.load_messages()
        if not cached.count:
            return (
                "No cached messages for this conversation yet. Run action='messages' first — "
                "the transcript pointer lives inside the chat's own system messages."
            )

        # Never trust a persisted inventory over the current message cache. Teams
        # posts several versions of a recording card: early versions often have
        # empty transcript URLs, while the finalized card can arrive later and
        # expose a generated transcript even when the user only started recording.
        # Re-deriving here prevents an earlier transcript-only inventory from
        # hiding that later recording-backed transcript.
        inventory = [p.to_dict() for p in parse_recording_pointers(cached.messages)]
        store.save_transcript_inventory(inventory)
        if not inventory:
            recording_messages = sum(
                1
                for message in cached.messages
                if str(message.get("messagetype") or "") == "RichText/Media_CallRecording"
            )
            return self._dump(
                {
                    "conversation_id": store.cid,
                    "recordings": [],
                    "source_gap": (
                        "Recording media exists, but its finalized transcript links are not in "
                        "the cached messages yet. Teams may attach a generated transcript after "
                        "recording processing finishes; run action='messages' again, then retry "
                        "action='transcripts'."
                        if recording_messages
                        else "This conversation contains no RichText/Media_CallRecording message, "
                        "so no transcript is reachable from it. Any meeting held here was either "
                        "not recorded or its recording was never posted back to the chat."
                    ),
                }
            )

        call_filter = str(kwargs.get("call_id") or "").strip()
        renditions = [
            r for r in (kwargs.get("renditions") or list(ALL_RENDITIONS)) if r in ALL_RENDITIONS
        ] or list(ALL_RENDITIONS)
        refresh = bool(kwargs.get("refresh"))

        token = await self._provider().get_token(IC3_AUDIENCE)
        results: list[dict[str, Any]] = []
        for entry in inventory:
            pointer = RecordingPointer.from_dict(entry)
            if call_filter and pointer.call_id != call_filter:
                continue
            record: dict[str, Any] = {
                "call_id": pointer.call_id,
                "title": pointer.title,
                "original_name": pointer.original_name,
                "transcript_id": pointer.transcript_id,
                "ical_uid": pointer.ical_uid,
                "timestamp": pointer.timestamp,
                "duration": pointer.duration,
                "content_types": pointer.content_types,
                "renditions": {},
            }
            for rendition in renditions:
                record["renditions"][rendition] = await self._one_rendition(
                    store, pointer, rendition, token.secret, refresh=refresh
                )
            results.append(record)

        return self._dump(
            {
                "conversation_id": store.cid,
                "cache_dir": str(store.transcripts_dir),
                "recordings": results,
                "note": (
                    "'ams' speaker tags are ground truth. 'odsp' has no speaker attribution but "
                    "splits utterances more finely; keep both as cross-checks."
                ),
            }
        )

    async def _one_rendition(
        self,
        store: TeamsWebChatStore,
        pointer: RecordingPointer,
        rendition: str,
        access_token: str,
        *,
        refresh: bool,
    ) -> dict[str, Any]:
        if not refresh:
            existing = store.load_transcript(
                call_id=pointer.call_id, transcript_id=pointer.transcript_id, rendition=rendition
            )
            if existing:
                cues = parse_vtt(existing)
                return {
                    "status": "cached",
                    "cues": len(cues),
                    "cues_with_speaker": sum(1 for c in cues if c.speaker),
                    "path": str(
                        store.transcript_dir(pointer.call_id, pointer.transcript_id)
                        / f"{rendition}.vtt"
                    ),
                }
        try:
            if rendition == RENDITION_AMS:
                download = await fetch_ams_transcript(pointer, access_token=access_token)
            elif rendition == RENDITION_ODSP:
                download = await fetch_odsp_transcript(
                    pointer, profile_dir=self._provider().profile_dir
                )
            else:  # pragma: no cover - guarded by the enum
                return {"status": "unsupported", "rendition": rendition}
        except TranscriptFetchError as exc:
            # A missing rendition is a documented gap, never a failed capture.
            return {"status": "source_gap", "reason": str(exc)}

        path = store.save_transcript(
            call_id=pointer.call_id,
            transcript_id=pointer.transcript_id,
            rendition=rendition,
            vtt=download.vtt,
            meta={
                "rendition": rendition,
                "provenance": pointer.to_dict(),
                "content_type": download.content_type,
                "bytes": len(download.vtt),
                "cues": len(download.cues),
                "cues_with_speaker": download.speaker_cue_count,
                "downloaded_at": datetime.now(UTC).isoformat(),
            },
        )
        return {
            "status": "downloaded",
            "cues": len(download.cues),
            "cues_with_speaker": download.speaker_cue_count,
            "bytes": len(download.vtt),
            "path": str(path),
        }

    def _action_read_transcript(self, store: TeamsWebChatStore, kwargs: dict[str, Any]) -> str:
        inventory = store.load_transcript_inventory()
        if not inventory:
            return "No transcripts known for this conversation. Run action='transcripts' first."

        call_filter = str(kwargs.get("call_id") or "").strip()
        candidates = [
            RecordingPointer.from_dict(entry)
            for entry in inventory
            if not call_filter or str(entry.get("call_id") or "") == call_filter
        ]
        if not candidates:
            return f"No recorded call with call_id={call_filter} in this conversation."

        preferred = str(kwargs.get("rendition") or "").strip()
        order = [preferred] if preferred in ALL_RENDITIONS else [RENDITION_AMS, RENDITION_ODSP]
        loaded: list[tuple[RecordingPointer, str, list[TranscriptCue]]] = []
        seen: set[tuple[str, str]] = set()
        for pointer in candidates:
            storage_key = (pointer.call_id, pointer.transcript_id)
            if storage_key in seen:
                continue
            seen.add(storage_key)
            for rendition in order:
                vtt = store.load_transcript(
                    call_id=pointer.call_id,
                    transcript_id=pointer.transcript_id,
                    rendition=rendition,
                )
                if not vtt:
                    continue
                loaded.append((pointer, rendition, parse_vtt(vtt)))
                # One rendition per transcript. With no explicit preference AMS
                # wins and ODSP remains its fallback, matching the old behavior.
                break

        if not loaded:
            return "The transcript is not downloaded yet. Run action='transcripts' first."

        # Treat every matching transcript as one logical cue stream. Applying
        # the limit globally keeps the response bounded when one call was split
        # into several transcript files, while still allowing offset to advance
        # from one file into the next.
        offset = max(0, int(kwargs.get("offset") or 0))
        limit = min(_MAX_CUE_LIMIT, max(1, int(kwargs.get("limit") or _DEFAULT_CUE_LIMIT)))
        total_cues = sum(len(cues) for _, _, cues in loaded)
        page_end = min(total_cues, offset + limit)
        cursor = 0
        transcripts: list[dict[str, Any]] = []
        dialogue_parts: list[str] = []
        for pointer, rendition, cues in loaded:
            transcript_end = cursor + len(cues)
            local_start = min(len(cues), max(0, offset - cursor))
            local_end = min(len(cues), max(0, page_end - cursor))
            window = cues[local_start:local_end]
            dialogue = cues_to_text(window)
            if dialogue:
                dialogue_parts.append(dialogue)
            transcripts.append(
                {
                    "call_id": pointer.call_id,
                    "title": pointer.title,
                    "transcript_id": pointer.transcript_id,
                    "rendition": rendition,
                    "speaker_attribution": (
                        "ground_truth" if rendition == RENDITION_AMS else "absent"
                    ),
                    "total_cues": len(cues),
                    "offset": local_start,
                    "returned": len(window),
                    "has_more": local_start + len(window) < len(cues),
                    "dialogue": dialogue,
                }
            )
            cursor = transcript_end

        returned = max(0, page_end - min(offset, total_cues))
        payload: dict[str, Any] = {
            "conversation_id": store.cid,
            "total_transcripts": len(loaded),
            "total_cues": total_cues,
            "offset": offset,
            "returned": returned,
            "has_more": offset + returned < total_cues,
            "dialogue": "".join(dialogue_parts),
            "transcripts": transcripts,
        }
        call_ids = {pointer.call_id for pointer, _, _ in loaded}
        if len(call_ids) == 1:
            payload.update(
                {
                    "call_id": loaded[0][0].call_id,
                    "title": loaded[0][0].title,
                }
            )
        if len(loaded) == 1:
            pointer, rendition, _ = loaded[0]
            # Preserve the original single-transcript response fields for
            # existing callers; ``transcripts`` adds the richer uniform view.
            payload.update(
                {
                    "transcript_id": pointer.transcript_id,
                    "rendition": rendition,
                    "speaker_attribution": (
                        "ground_truth" if rendition == RENDITION_AMS else "absent"
                    ),
                }
            )
        return self._dump(payload)

    # ── Helpers ──────────────────────────────────────────────────────────────

    async def _fetch(self, cid: str, access_token: str, *, since: datetime | None, max_pages: int):
        client = TeamsChatsvcClient(
            cid, access_token=access_token, region=self._config_str("region")
        )
        return await client.fetch_messages(since=since, max_pages=max_pages)

    def _provider(self) -> TeamsWebTokenProvider:
        if self._token_provider is None:
            profile_dir = self._config_str("profile_dir")
            self._token_provider = TeamsWebTokenProvider(
                cache_path=default_token_cache_path(),
                profile_dir=Path(profile_dir).expanduser() if profile_dir else None,
                allow_headed_login=bool(self._config_get("allow_headed_login", False)),
                login_timeout_s=self._config_int("login_timeout_s", 180),
                skew_s=self._config_int("token_skew_s", 300),
            )
        return self._token_provider

    @property
    def token_provider(self) -> TeamsWebTokenProvider:
        """Shared audience-aware provider for other Teams Web-backed features."""
        return self._provider()

    def _cache_root(self) -> Path | None:
        root = self._config_str("cache_root")
        return Path(root).expanduser() if root else None

    def _enabled(self) -> bool:
        return bool(self._config_get("enabled", True))

    def _config_get(self, key: str, default: Any) -> Any:
        if self._config is None:
            return default
        value = getattr(self._config, key, None)
        return default if value is None else value

    def _config_str(self, key: str) -> str:
        return str(self._config_get(key, "") or "").strip()

    def _config_int(self, key: str, default: int) -> int:
        try:
            return int(self._config_get(key, default))
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _dump(payload: dict[str, Any]) -> str:
        return json.dumps(payload, ensure_ascii=False, indent=2)


def default_since_for_days(days: int) -> datetime:
    """Convenience for callers reasoning in relative windows."""
    return datetime.now(UTC) - timedelta(days=max(1, days))
