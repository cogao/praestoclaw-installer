"""Direct download of message-linked image/file material."""

from __future__ import annotations

import base64
from collections.abc import Callable
from dataclasses import dataclass
from urllib.parse import urljoin, urlparse

import httpx

MAX_MATERIAL_BYTES = 50 * 1024 * 1024
_MAX_REDIRECTS = 3
_IC3_TRUSTED_SUFFIXES = (".teams.microsoft.com", ".skype.com")
_IC3_TRUSTED_HOSTS = {"teams.microsoft.com", "skype.com"}
_GRAPH_HOST = "graph.microsoft.com"
_HTML_MIMES = {"text/html", "application/xhtml+xml"}


class MaterialFetchError(Exception):
    """A message-linked material URL could not be retrieved."""


@dataclass(frozen=True, slots=True)
class MaterialDownload:
    data: bytes
    content_type: str


async def fetch_message_material(
    url: str,
    *,
    access_token: str,
    graph_access_token: str = "",
    max_bytes: int = MAX_MATERIAL_BYTES,
    transport: httpx.AsyncBaseTransport | None = None,
) -> MaterialDownload:
    """Fetch exactly one message URL, never a user-chosen drive search.

    Generic/upload URLs are first requested without credentials.  The IC3
    bearer is sent only to Teams/Skype service hosts.  A SharePoint share URL
    may instead be resolved via Graph's single-item ``/shares`` endpoint with
    a Graph bearer that is *only* ever sent to graph.microsoft.com.
    """
    try:
        return await _http_fetch(
            url,
            access_token=access_token,
            credential_hosts=_ic3_hosts,
            max_bytes=max_bytes,
            transport=transport,
        )
    except MaterialFetchError as direct_error:
        if not (graph_access_token and _is_onedrive_url(url)):
            raise
        try:
            return await _http_fetch(
                _graph_share_content_url(url),
                access_token=graph_access_token,
                credential_hosts=lambda host: host == _GRAPH_HOST,
                max_bytes=max_bytes,
                transport=transport,
            )
        except MaterialFetchError:
            raise direct_error


async def _http_fetch(
    url: str,
    *,
    access_token: str,
    credential_hosts: Callable[[str], bool],
    max_bytes: int,
    transport: httpx.AsyncBaseTransport | None,
) -> MaterialDownload:
    current = url
    original_origin = _origin(url)
    async with httpx.AsyncClient(
        timeout=60.0, follow_redirects=False, transport=transport
    ) as client:
        for _ in range(_MAX_REDIRECTS + 1):
            # Never forward a bearer across an origin boundary.  This matters
            # for Graph /content redirects to a pre-signed SharePoint blob URL.
            may_auth = _origin(current) == original_origin and credential_hosts(_host(current))
            headers = {"Accept": "*/*"}
            if may_auth and access_token:
                headers["Authorization"] = f"Bearer {access_token}"
            try:
                async with client.stream("GET", current, headers=headers) as response:
                    if 300 <= response.status_code < 400 and response.headers.get("location"):
                        current = urljoin(current, str(response.headers["location"]))
                        continue
                    if response.status_code != 200:
                        raise MaterialFetchError(f"material returned HTTP {response.status_code}")
                    content_type = response.headers.get("content-type", "").split(";", 1)[0].lower()
                    if content_type.startswith(("audio/", "video/")):
                        raise MaterialFetchError("audio/video material is not supported")
                    if content_type in _HTML_MIMES:
                        raise MaterialFetchError("material URL returned an HTML landing/error page")
                    body = bytearray()
                    total = 0
                    async for chunk in response.aiter_bytes():
                        total += len(chunk)
                        if total > max_bytes:
                            raise MaterialFetchError(
                                f"material exceeds {max_bytes} byte download limit"
                            )
                        body.extend(chunk)
                    return _validated_download(
                        bytes(body),
                        content_type,
                        max_bytes,
                    )
            except httpx.HTTPError as exc:
                raise MaterialFetchError(f"material request failed: {exc}") from exc
    raise MaterialFetchError("material exceeded redirect limit")


def _validated_download(
    data: bytes,
    content_type: str,
    max_bytes: int,
) -> MaterialDownload:
    if not data:
        raise MaterialFetchError("material returned no bytes")
    if len(data) > max_bytes:
        raise MaterialFetchError(f"material exceeds {max_bytes} byte download limit")
    if content_type in _HTML_MIMES or _looks_like_html(data):
        raise MaterialFetchError("material URL returned an HTML landing/error page")
    if _looks_like_audio_video(data):
        raise MaterialFetchError("audio/video material is not supported")
    return MaterialDownload(data=data, content_type=content_type)


def _looks_like_html(data: bytes) -> bool:
    prefix = data[:1024].lstrip(b"\xef\xbb\xbf\t\r\n ").lower()
    return prefix.startswith((b"<!doctype html", b"<html", b"<head", b"<body"))


def _looks_like_audio_video(data: bytes) -> bool:
    return (
        (data.startswith(b"RIFF") and data[8:12] in {b"WAVE", b"AVI "})
        or data.startswith((b"ID3", b"OggS", b"fLaC", b"\x1aE\xdf\xa3"))
        or (len(data) >= 12 and data[4:8] == b"ftyp")
    )


def _ic3_hosts(host: str) -> bool:
    return host in _IC3_TRUSTED_HOSTS or host.endswith(_IC3_TRUSTED_SUFFIXES)


def _host(url: str) -> str:
    return (urlparse(url).hostname or "").lower()


def _origin(url: str) -> tuple[str, str, int | None]:
    parsed = urlparse(url)
    return parsed.scheme.lower(), _host(url), parsed.port


def _graph_share_content_url(url: str) -> str:
    encoded = base64.urlsafe_b64encode(url.encode("utf-8")).decode("ascii").rstrip("=")
    return f"https://{_GRAPH_HOST}/v1.0/shares/u!{encoded}/driveItem/content"


def _is_onedrive_url(url: str) -> bool:
    host = _host(url)
    return (
        host.endswith((".sharepoint.com", ".sharepoint-df.com", ".onedrive.com"))
        or host == "1drv.ms"
    )
