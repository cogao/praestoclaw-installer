"""Per-conversation on-disk cache for Teams Web captures.

Every artefact lives under a directory whose name carries the conversation id,
so two groups can never read each other's material by accident — the cid is
part of the path, not a field inside a shared file.

Layout::

    <data_dir>/teams-web/chats/<cid-slug>/
        conversation.json                    high-water mark + bookkeeping
        messages/segments.json               ordered segment index
        messages/ts-<from>-<to>.json         one capture, verbatim
        artifacts/<sha256>.<ext>              message-linked image/file bytes
        artifacts/<sha256>.json               provenance + content metadata
        transcripts/inventory.json           recording pointers from the chat
        transcripts/<callId>-<tid>/<rendition>.vtt / .json

``<cid-slug>`` is a sanitised rendering of the cid plus a short digest of the
*exact* cid. Sanitising alone is not injective — ``19:a@thread.v2`` and
``19_a_thread.v2`` would collide, and on Windows the raw cid is not even a legal
path — so the digest is what actually guarantees isolation.

**Messages are segmented; transcripts are not.** A meeting transcript is
immutable once generated, so re-downloading it simply overwrites an identical
file. A conversation, by contrast, keeps growing, and a single ``messages.json``
made every capture destroy the last one: pull two weeks, then pull one day, and
the fortnight vanished with nothing on disk to show it ever existed. That is the
same silent-overwrite failure already seen when two transcripts of one meeting
shared a filename and the shorter chunk clobbered the longer.

So each capture appends its own time-ranged segment, named
``ts-<from>-<to>.json`` in UTC basic format. Lexicographic order is chronological
order, the range is legible without opening the file, and a long span is split
so no segment covers more than ``max_segment_days`` (default 14).
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from loguru import logger

from praestoclaw.teams_web.chatsvc import message_time, parse_message_time

_SLUG_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")
_SLUG_READABLE_MAX = 72
_DIGEST_LEN = 12

SEGMENT_PREFIX = "ts-"
SEGMENT_SUFFIX = ".json"
DEFAULT_MAX_SEGMENT_DAYS = 14
_STAMP_FORMAT = "%Y%m%dT%H%M%SZ"


def cid_slug(cid: str) -> str:
    """Return a filesystem-safe, collision-free directory name for *cid*."""
    normalized = (cid or "").strip()
    if not normalized:
        raise ValueError("cid is required")
    digest = hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:_DIGEST_LEN]
    readable = _SLUG_UNSAFE.sub("_", normalized).strip("_.")[:_SLUG_READABLE_MAX]
    return f"{readable}-{digest}" if readable else digest


def default_cache_root() -> Path:
    """``<data_dir>/teams-web`` — the root of every cached conversation."""
    from praestoclaw.utils.helpers import get_data_dir

    return get_data_dir() / "teams-web"


def _safe_component(value: str, fallback: str) -> str:
    cleaned = _SLUG_UNSAFE.sub("_", (value or "").strip()).strip("_.")[:64]
    return cleaned or fallback


def _stamp(moment: datetime) -> str:
    return moment.astimezone(UTC).strftime(_STAMP_FORMAT)


def segment_filename(start: datetime, end: datetime) -> str:
    """``ts-<from>-<to>.json`` — sorts chronologically, reads as a range."""
    return f"{SEGMENT_PREFIX}{_stamp(start)}-{_stamp(end)}{SEGMENT_SUFFIX}"


@dataclass(frozen=True, slots=True)
class MessageSegment:
    """One capture: a contiguous, time-bounded slice of the conversation."""

    name: str
    start: datetime
    end: datetime
    count: int
    fetched_at: str = ""
    region: str = ""

    def to_index_entry(self) -> dict[str, Any]:
        return {
            "file": self.name,
            "from": self.start.astimezone(UTC).isoformat(),
            "to": self.end.astimezone(UTC).isoformat(),
            "count": self.count,
            "fetched_at": self.fetched_at,
            "region": self.region,
        }

    @classmethod
    def from_index_entry(cls, entry: dict[str, Any]) -> MessageSegment | None:
        name = str(entry.get("file") or "")
        start = parse_message_time(str(entry.get("from") or ""))
        end = parse_message_time(str(entry.get("to") or ""))
        if not name or start is None or end is None:
            return None
        return cls(
            name=name,
            start=start,
            end=end,
            count=int(entry.get("count") or 0),
            fetched_at=str(entry.get("fetched_at") or ""),
            region=str(entry.get("region") or ""),
        )

    def overlaps(self, since: datetime | None, until: datetime | None) -> bool:
        if since is not None and self.end < since:
            return False
        return not (until is not None and self.start > until)


@dataclass(frozen=True, slots=True)
class StoredMessages:
    """The union of every cached segment that matched a query."""

    messages: list[dict[str, Any]] = field(default_factory=list)
    segments: list[MessageSegment] = field(default_factory=list)

    @property
    def count(self) -> int:
        return len(self.messages)

    @property
    def fetched_at(self) -> str:
        stamps = [s.fetched_at for s in self.segments if s.fetched_at]
        return max(stamps) if stamps else ""

    @property
    def region(self) -> str:
        for segment in reversed(self.segments):
            if segment.region:
                return segment.region
        return ""


class TeamsWebChatStore:
    """Reads and writes the cache for exactly one conversation id."""

    def __init__(self, cid: str, *, root: Path | None = None) -> None:
        cid = (cid or "").strip()
        if not cid:
            raise ValueError("TeamsWebChatStore requires a conversation id")
        self._cid = cid
        self._root = (root or default_cache_root()) / "chats" / cid_slug(cid)

    @property
    def cid(self) -> str:
        return self._cid

    @property
    def root(self) -> Path:
        return self._root

    @property
    def messages_dir(self) -> Path:
        return self._root / "messages"

    @property
    def transcripts_dir(self) -> Path:
        return self._root / "transcripts"

    @property
    def artifacts_dir(self) -> Path:
        """Content-addressed bytes linked from messages in this conversation."""
        return self._root / "artifacts"

    def save_artifact(
        self,
        data: bytes,
        *,
        name: str = "",
        content_type: str = "",
        source: dict[str, Any],
    ) -> dict[str, Any]:
        """Persist one downloaded message artifact without embedding bytes in JSON.

        The SHA-256 makes repeat references idempotent.  The metadata sidecar
        deliberately records the source descriptor exactly as it appeared in
        the message so an eventual KB capture has a durable provenance trail.
        """
        digest = hashlib.sha256(data).hexdigest()
        suffix = Path(name).suffix.lower()
        if not re.fullmatch(r"\.[a-z0-9]{1,12}", suffix):
            suffix = ""
        self.artifacts_dir.mkdir(parents=True, exist_ok=True)
        blob = self.artifacts_dir / f"{digest}{suffix}"
        if not blob.exists():
            blob.write_bytes(data)
        sidecar = self.artifacts_dir / f"{digest}.json"
        existing = self._read_json(sidecar)
        metadata: dict[str, Any] = (
            existing
            if isinstance(existing, dict)
            and str(existing.get("conversation_id") or "") == self._cid
            else {
                "conversation_id": self._cid,
                "sha256": digest,
                "size": len(data),
                "content_type": content_type,
                "name": name,
                "cache_path": str(blob),
                "saved_at": datetime.now(UTC).isoformat(),
            }
        )
        sources = metadata.get("sources")
        if not isinstance(sources, list):
            sources = [metadata.pop("source")] if isinstance(metadata.get("source"), dict) else []
        source_key = json.dumps(source, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        if all(
            not isinstance(item, dict)
            or json.dumps(item, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            != source_key
            for item in sources
        ):
            sources.append(source)
        metadata["sources"] = sources
        self._write_json(sidecar, metadata)
        return metadata

    def load_artifact_metadata(self) -> list[dict[str, Any]]:
        """Return only sidecars belonging to this exact conversation."""
        records: list[dict[str, Any]] = []
        for path in sorted(self.artifacts_dir.glob("*.json")):
            record = self._read_json(path)
            if isinstance(record, dict) and str(record.get("conversation_id") or "") == self._cid:
                records.append(record)
        return records

    def save_artifact_text(
        self, sha256: str, text: str, *, extraction: str
    ) -> dict[str, Any] | None:
        """Attach derived, reviewable text to an existing artifact sidecar."""
        sidecar = self.artifacts_dir / f"{sha256}.json"
        record = self._read_json(sidecar)
        if not isinstance(record, dict) or str(record.get("conversation_id") or "") != self._cid:
            return None
        text_path = self.artifacts_dir / f"{sha256}.extracted.md"
        text_path.write_text(text, encoding="utf-8", newline="\n")
        record["text_cache_path"] = str(text_path)
        record["text_chars"] = len(text)
        record["text_extraction"] = extraction
        self._write_json(sidecar, record)
        return record

    # ── Message segments ─────────────────────────────────────────────────────

    def load_segments(self) -> list[MessageSegment]:
        """Return the segment index, oldest first."""
        doc = self._read_json(self.messages_dir / "segments.json")
        if not isinstance(doc, dict) or str(doc.get("conversation_id") or "") != self._cid:
            return []
        entries = doc.get("segments")
        if not isinstance(entries, list):
            return []
        segments = [
            segment
            for segment in (
                MessageSegment.from_index_entry(e) for e in entries if isinstance(e, dict)
            )
            if segment is not None
        ]
        segments.sort(key=lambda s: s.start)
        return segments

    def high_water(self) -> datetime | None:
        """Newest cached message time — the anchor for the next delta pull."""
        segments = self.load_segments()
        return max((s.end for s in segments), default=None)

    def earliest_cached(self) -> datetime | None:
        """Oldest cached message time — anything before it needs a backfill."""
        segments = self.load_segments()
        return min((s.start for s in segments), default=None)

    def append_messages(
        self,
        messages: list[dict[str, Any]],
        *,
        region: str = "",
        page_metadata: list[Any] | None = None,
        max_segment_days: int = DEFAULT_MAX_SEGMENT_DAYS,
    ) -> list[MessageSegment]:
        """Write the messages not already cached as one or more new segments.

        Messages already present in an existing segment are dropped, so a delta
        pull that overlaps the boundary does not duplicate them. A batch
        spanning more than *max_segment_days* is split so a single file never
        covers an unbounded stretch of history.
        """
        known = self._known_message_ids()
        fresh = [
            message
            for message in messages
            if isinstance(message, dict) and str(message.get("id") or "") not in known
        ]
        if not fresh:
            return []

        fresh.sort(key=message_time)
        fetched_at = datetime.now(UTC).isoformat()
        existing = {segment.name for segment in self.load_segments()}
        written: list[MessageSegment] = []

        for bucket in self._split_by_span(fresh, max_segment_days):
            segment = self._write_segment(
                bucket,
                region=region,
                page_metadata=page_metadata,
                fetched_at=fetched_at,
                taken=existing,
            )
            written.append(segment)
            existing.add(segment.name)

        self._rewrite_index(self.load_segments() + written)
        newest = max((segment.end for segment in written), default=None)
        self._touch_conversation(
            last_message_fetch=fetched_at,
            region=region,
            high_water_at=newest.astimezone(UTC).isoformat() if newest else None,
        )
        return written

    def replace_messages(
        self,
        messages: list[dict[str, Any]],
        *,
        region: str = "",
        page_metadata: list[Any] | None = None,
        max_segment_days: int = DEFAULT_MAX_SEGMENT_DAYS,
    ) -> list[MessageSegment]:
        """Discard every cached segment and re-segment *messages* from scratch.

        This is what ``refresh`` means: a fresh full capture supersedes the old
        one. Appending instead would leave segments whose ranges overlap the new
        ones, with no way to tell which reading is current.
        """
        self.clear_messages()
        return self.append_messages(
            messages,
            region=region,
            page_metadata=page_metadata,
            max_segment_days=max_segment_days,
        )

    def clear_messages(self) -> None:
        for path in self.messages_dir.glob(f"{SEGMENT_PREFIX}*{SEGMENT_SUFFIX}"):
            path.unlink(missing_ok=True)
        (self.messages_dir / "segments.json").unlink(missing_ok=True)

    def load_messages(
        self, *, since: datetime | None = None, until: datetime | None = None
    ) -> StoredMessages:
        """Read every segment intersecting the window, deduped and time-sorted."""
        matched: list[MessageSegment] = []
        collected: dict[str, dict[str, Any]] = {}
        undated: list[dict[str, Any]] = []

        for segment in self.load_segments():
            if not segment.overlaps(since, until):
                continue
            payload = self._read_segment(segment.name)
            if payload is None:
                continue
            matched.append(segment)
            for message in payload:
                when = parse_message_time(message_time(message))
                if when is None:
                    undated.append(message)
                    continue
                if since is not None and when < since:
                    continue
                if until is not None and when > until:
                    continue
                collected.setdefault(str(message.get("id") or id(message)), message)

        merged = sorted(collected.values(), key=message_time)
        merged.extend(undated)
        return StoredMessages(messages=merged, segments=matched)

    # ── Transcripts ──────────────────────────────────────────────────────────
    #
    # Deliberately NOT segmented. A meeting transcript is generated once and
    # never changes, so a repeat download writes identical bytes; overwriting is
    # the honest outcome. Only the (callId, transcriptId, rendition) triple
    # distinguishes files, which is what keeps the two renditions of one meeting
    # from clobbering each other.

    def transcript_dir(self, call_id: str, transcript_id: str = "") -> Path:
        leaf = _safe_component(call_id, "call")
        if transcript_id:
            leaf = f"{leaf}-{_safe_component(transcript_id, 'transcript')[:12]}"
        return self.transcripts_dir / leaf

    def save_transcript(
        self,
        *,
        call_id: str,
        transcript_id: str,
        rendition: str,
        vtt: str,
        meta: dict[str, Any],
    ) -> Path:
        directory = self.transcript_dir(call_id, transcript_id)
        directory.mkdir(parents=True, exist_ok=True)
        name = _safe_component(rendition, "transcript")
        vtt_path = directory / f"{name}.vtt"
        vtt_path.write_text(vtt, encoding="utf-8", newline="\n")
        self._write_json(directory / f"{name}.json", {**meta, "conversation_id": self._cid})
        return vtt_path

    def load_transcript(self, *, call_id: str, transcript_id: str, rendition: str) -> str | None:
        path = (
            self.transcript_dir(call_id, transcript_id) / f"{_safe_component(rendition, 'x')}.vtt"
        )
        try:
            return path.read_text(encoding="utf-8")
        except OSError:
            return None

    def save_transcript_inventory(self, inventory: list[dict[str, Any]]) -> None:
        self.transcripts_dir.mkdir(parents=True, exist_ok=True)
        self._write_json(
            self.transcripts_dir / "inventory.json",
            {"conversation_id": self._cid, "recordings": inventory},
        )

    def load_transcript_inventory(self) -> list[dict[str, Any]]:
        doc = self._read_json(self.transcripts_dir / "inventory.json")
        if not isinstance(doc, dict) or str(doc.get("conversation_id") or "") != self._cid:
            return []
        recordings = doc.get("recordings")
        return (
            [r for r in recordings if isinstance(r, dict)] if isinstance(recordings, list) else []
        )

    # ── Internals ────────────────────────────────────────────────────────────

    @staticmethod
    def _split_by_span(
        messages: list[dict[str, Any]], max_segment_days: int
    ) -> list[list[dict[str, Any]]]:
        """Chop a time-sorted batch so no bucket spans more than the limit."""
        if max_segment_days <= 0:
            return [messages]
        span = timedelta(days=max_segment_days)
        buckets: list[list[dict[str, Any]]] = []
        current: list[dict[str, Any]] = []
        anchor: datetime | None = None
        for message in messages:
            when = parse_message_time(message_time(message))
            if current and anchor is not None and when is not None and when - anchor > span:
                buckets.append(current)
                current = []
                anchor = None
            if anchor is None and when is not None:
                anchor = when
            current.append(message)
        if current:
            buckets.append(current)
        return buckets

    def _write_segment(
        self,
        messages: list[dict[str, Any]],
        *,
        region: str,
        page_metadata: list[Any] | None,
        fetched_at: str,
        taken: set[str],
    ) -> MessageSegment:
        times = [t for t in (parse_message_time(message_time(m)) for m in messages) if t]
        fallback = parse_message_time(fetched_at) or datetime.now(UTC)
        start = min(times) if times else fallback
        end = max(times) if times else fallback

        name = segment_filename(start, end)
        if name in taken:
            # Two captures can only land on the same name if their bounds match
            # exactly (a forced re-pull of a single instant). Keep both rather
            # than silently replacing one.
            stem = name[: -len(SEGMENT_SUFFIX)]
            counter = 2
            while f"{stem}-{counter}{SEGMENT_SUFFIX}" in taken:
                counter += 1
            name = f"{stem}-{counter}{SEGMENT_SUFFIX}"

        self._write_json(
            self.messages_dir / name,
            {
                "conversation_id": self._cid,
                "segment": {
                    "from": start.astimezone(UTC).isoformat(),
                    "to": end.astimezone(UTC).isoformat(),
                    "count": len(messages),
                },
                "fetched_at": fetched_at,
                "region": region,
                # Paging bookkeeping (syncState / backwardLink) kept for
                # provenance; the message objects below are byte-for-byte as
                # chatsvc returned them.
                "page_metadata": page_metadata or [],
                "messages": messages,
            },
        )
        return MessageSegment(
            name=name,
            start=start,
            end=end,
            count=len(messages),
            fetched_at=fetched_at,
            region=region,
        )

    def _read_segment(self, name: str) -> list[dict[str, Any]] | None:
        doc = self._read_json(self.messages_dir / name)
        if not isinstance(doc, dict):
            return None
        # Defence in depth: refuse a segment that belongs to another chat.
        if str(doc.get("conversation_id") or "") != self._cid:
            logger.warning("[teams_web] segment {} does not belong to cid={}", name, self._cid)
            return None
        messages = doc.get("messages")
        return [m for m in messages if isinstance(m, dict)] if isinstance(messages, list) else []

    def _known_message_ids(self) -> set[str]:
        known: set[str] = set()
        for segment in self.load_segments():
            for message in self._read_segment(segment.name) or []:
                message_id = str(message.get("id") or "")
                if message_id:
                    known.add(message_id)
        return known

    def _rewrite_index(self, segments: list[MessageSegment]) -> None:
        ordered = sorted(segments, key=lambda s: (s.start, s.name))
        self._write_json(
            self.messages_dir / "segments.json",
            {
                "conversation_id": self._cid,
                "segments": [segment.to_index_entry() for segment in ordered],
            },
        )

    def _touch_conversation(self, **fields: Any) -> None:
        doc = self._read_json(self._root / "conversation.json")
        state: dict[str, Any] = doc if isinstance(doc, dict) else {}
        state["conversation_id"] = self._cid
        state.update({k: v for k, v in fields.items() if v is not None})
        self._root.mkdir(parents=True, exist_ok=True)
        self._write_json(self._root / "conversation.json", state)

    @staticmethod
    def _write_json(path: Path, payload: Any) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
            newline="\n",
        )

    @staticmethod
    def _read_json(path: Path) -> Any:
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
