"""Meeting-aware task-group automation."""

from praestoclaw.meeting_automation.models import (
    MeetingOccurrence,
    MeetingRelativeSchedule,
    MeetingTaskGroupInstance,
    MeetingTaskGroupTemplate,
    RoutingContext,
    TaskGroupConfig,
    TaskGroupSkillConfig,
    WeeklySchedule,
)
from praestoclaw.meeting_automation.service import MeetingAutomationService

__all__ = [
    "MeetingAutomationService",
    "MeetingOccurrence",
    "MeetingRelativeSchedule",
    "MeetingTaskGroupInstance",
    "MeetingTaskGroupTemplate",
    "RoutingContext",
    "TaskGroupConfig",
    "TaskGroupSkillConfig",
    "WeeklySchedule",
]
