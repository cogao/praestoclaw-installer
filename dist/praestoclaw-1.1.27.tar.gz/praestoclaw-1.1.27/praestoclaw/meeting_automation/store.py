"""Per-meeting task-flow profile persistence."""

from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import uuid
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from threading import RLock
from typing import Any

from praestoclaw.meeting_automation.models import (
    MeetingTaskGroupInstance,
    MeetingTaskGroupTemplate,
)

_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")


def meeting_id_slug(meeting_id: str) -> str:
    """Stable readable directory name for a Teams meeting thread id."""
    value = str(meeting_id or "").strip()
    if not value:
        raise ValueError("meeting id is required")
    readable = _UNSAFE.sub("_", value).strip("_.")[:72]
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()[:12]
    return f"{readable}-{digest}" if readable else digest


class MeetingAutomationStore:
    """Store each flow under ``<data_dir>/meetings/<meeting-id>/flow.json``."""

    def __init__(self, data_dir: Path) -> None:
        self._root = data_dir / "meetings"
        self._lock = RLock()
        self._templates: dict[str, MeetingTaskGroupTemplate] = {}
        self._instances: dict[str, MeetingTaskGroupInstance] = {}
        self._load()

    def profile_dir(self, meeting_chat_id: str) -> Path:
        return self._root / meeting_id_slug(meeting_chat_id)

    def flow_path(self, meeting_chat_id: str) -> Path:
        return self.profile_dir(meeting_chat_id) / "flow.json"

    def revision_path(self, meeting_chat_id: str, version: int) -> Path:
        return self.profile_dir(meeting_chat_id) / "revisions" / f"{version}.json"

    def change_path(self, meeting_chat_id: str, change_id: str) -> Path:
        return self.profile_dir(meeting_chat_id) / "changes" / f"{change_id}.json"

    def get_template(self, meeting_chat_id: str) -> MeetingTaskGroupTemplate | None:
        with self._lock:
            value = self._templates.get(meeting_chat_id)
            return deepcopy(value) if value is not None else None

    def put_template(self, template: MeetingTaskGroupTemplate) -> None:
        if not template.meeting_chat_id:
            raise ValueError("meeting template requires meeting_chat_id")
        with self._lock:
            self._templates[template.meeting_chat_id] = deepcopy(template)
            self._persist_profile(template.meeting_chat_id)

    def apply_revision(
        self,
        template: MeetingTaskGroupTemplate,
        *,
        expected_version: int,
        revision: dict[str, Any],
        change_id: str,
    ) -> None:
        """CAS the current template and publish its files under the store lock."""
        meeting_id = template.meeting_chat_id
        with self._lock:
            current = self._templates.get(meeting_id)
            current_version = current.version if current is not None else 0
            if current_version != expected_version:
                raise ValueError(
                    f"expected_version {expected_version} does not match current version {current_version}"
                )
            self._templates[meeting_id] = deepcopy(template)
            self._persist_profile(meeting_id)
            self._write_json(self.revision_path(meeting_id, template.version), revision)
            self._write_json(self.change_path(meeting_id, change_id), revision)

    def record_change(self, meeting_chat_id: str, change: dict[str, Any]) -> str:
        change_id = str(change.get("change_id") or uuid.uuid4().hex)
        change["change_id"] = change_id
        with self._lock:
            self._write_json(self.change_path(meeting_chat_id, change_id), change)
        return change_id

    def finalize_revision(self, meeting_chat_id: str, revision: dict[str, Any]) -> None:
        with self._lock:
            self._write_json(
                self.revision_path(meeting_chat_id, int(revision["version"])), revision
            )
            self._write_json(
                self.change_path(meeting_chat_id, str(revision["change_id"])), revision
            )

    def history(self, meeting_chat_id: str, version: int | None = None) -> list[dict[str, Any]]:
        directory = self.profile_dir(meeting_chat_id) / "revisions"
        if version is not None:
            path = directory / f"{version}.json"
            return [json.loads(path.read_text(encoding="utf-8"))] if path.is_file() else []
        values: list[dict[str, Any]] = []
        for path in directory.glob("*.json") if directory.is_dir() else []:
            values.append(json.loads(path.read_text(encoding="utf-8")))
        return sorted(values, key=lambda item: int(item.get("version") or 0), reverse=True)

    def changes(self, meeting_chat_id: str) -> list[dict[str, Any]]:
        directory = self.profile_dir(meeting_chat_id) / "changes"
        values = [
            json.loads(path.read_text(encoding="utf-8"))
            for path in directory.glob("*.json")
            if directory.is_dir()
        ]
        return sorted(values, key=lambda item: str(item.get("requested_at") or ""), reverse=True)

    def templates(self) -> list[MeetingTaskGroupTemplate]:
        with self._lock:
            return deepcopy(list(self._templates.values()))

    def get_instance(self, instance_id: str) -> MeetingTaskGroupInstance | None:
        with self._lock:
            value = self._instances.get(instance_id)
            return deepcopy(value) if value is not None else None

    def put_instance(self, instance: MeetingTaskGroupInstance) -> None:
        meeting_chat_id = instance.meeting.chat_id
        if not meeting_chat_id:
            raise ValueError("meeting instance requires meeting.chat_id")
        with self._lock:
            self._instances[instance.instance_id] = deepcopy(instance)
            self._persist_profile(meeting_chat_id)

    def instances(self, *, meeting_chat_id: str | None = None) -> list[MeetingTaskGroupInstance]:
        with self._lock:
            values = deepcopy(list(self._instances.values()))
        if meeting_chat_id is None:
            return values
        return [item for item in values if item.meeting.chat_id == meeting_chat_id]

    def find_by_background_task(self, task_id: str) -> MeetingTaskGroupInstance | None:
        with self._lock:
            value = next(
                (item for item in self._instances.values() if item.background_task_id == task_id),
                None,
            )
            return deepcopy(value) if value is not None else None

    def claim_cycle(self, meeting_chat_id: str, cycle_key: str, cycle_start: str) -> bool:
        """Advance the cycle watermark under the profile lock; return False when stale."""
        with self._lock:
            template = self._templates[meeting_chat_id]
            current = (
                datetime.fromisoformat(template.latest_started_cycle_start)
                if template.latest_started_cycle_start
                else None
            )
            candidate = datetime.fromisoformat(cycle_start)
            if template.latest_started_cycle_key == cycle_key:
                if candidate != current:
                    template.latest_started_cycle_start = cycle_start
                    self._persist_profile(meeting_chat_id)
                return True
            if current is not None and candidate < current:
                return False
            if current is None or candidate > current:
                template.latest_started_cycle_key = cycle_key
                template.latest_started_cycle_start = cycle_start
                self._persist_profile(meeting_chat_id)
            return True

    def _load(self) -> None:
        if not self._root.is_dir():
            return
        for path in self._root.glob("*/flow.json"):
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
                if raw.get("version") != 2:
                    continue
                template = MeetingTaskGroupTemplate.from_dict(raw.get("template"))
                if not template.meeting_chat_id:
                    continue
                self._templates[template.meeting_chat_id] = template
                instances = raw.get("instances") or {}
                if isinstance(instances, dict):
                    for key, value in instances.items():
                        instance = MeetingTaskGroupInstance.from_dict(value)
                        if instance.meeting.chat_id == template.meeting_chat_id:
                            self._instances[str(key)] = instance
            except (OSError, ValueError, TypeError):
                # Leave an unreadable profile intact for operator inspection.
                continue

    def _persist_profile(self, meeting_chat_id: str) -> None:
        template = self._templates.get(meeting_chat_id)
        if template is None:
            return
        directory = self.profile_dir(meeting_chat_id)
        directory.mkdir(parents=True, exist_ok=True)
        id_path = directory / "MEETING_ID"
        if not id_path.exists():
            id_path.write_text(meeting_chat_id + "\n", encoding="utf-8")
        payload: dict[str, Any] = {
            "version": 2,
            "template": template.to_dict(),
            "instances": {
                key: value.to_dict()
                for key, value in self._instances.items()
                if value.meeting.chat_id == meeting_chat_id
            },
        }
        fd, tmp_name = tempfile.mkstemp(
            prefix="flow-", suffix=".json.tmp", dir=directory, text=True
        )
        tmp = Path(tmp_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2, ensure_ascii=False)
                handle.write("\n")
            os.replace(tmp, self.flow_path(meeting_chat_id))
        finally:
            tmp.unlink(missing_ok=True)

    @staticmethod
    def _write_json(path: Path, payload: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_name = tempfile.mkstemp(prefix=path.stem + "-", suffix=".tmp", dir=path.parent)
        tmp = Path(tmp_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2, ensure_ascii=False)
                handle.write("\n")
            os.replace(tmp, path)
        finally:
            tmp.unlink(missing_ok=True)
