---
name: kb-progress-sync
description: "Summarize all of the current owner's KB Progress Sync Draft PRs together, then publish, merge into main, or revise one explicitly numbered PR at a time."
metadata:
  activation:
    keywords:
      - KB Progress Sync
      - kb progress sync
      - progress sync draft
      - progress draft review
      - review my KB progress PR
      - review my progress draft
      - 审阅 progress 草案
      - 审阅进展草案
      - 发布 progress 草案
      - 发布 KB 草案
    patterns:
      - "(?i)\\b(kb[ -]?progress[ -]?sync|progress[ -]?sync)\\b.{0,32}(draft|pr|review|publish|public)"
      - "(?i)(review|publish|public|发布|审阅).{0,32}(kb|progress|进展).{0,32}(draft|草案|pr)?"
  os: [win32, darwin, linux]
  requires:
    bins: [gh]
  safe-tools:
    - tool: kb_scope
      match:
        action: "^show$"
    - tool: shell
      match:
        command: "^gh[ \\t]+pr[ \\t]+(list|view|diff)(?:[ \\t][^;|&$`<>\\n\\r]*)?\\Z"
    - tool: shell
      match:
        command: "^gh[ \\t]+auth[ \\t]+status(?:[ \\t][^;|&$`<>\\n\\r]*)?\\Z"
---

# KB Progress Sync

Use this skill in a **personal PraestoClaw chat** to help the current owner
review the Draft PRs created by the KB Progress Sync tool. It is for externally
created, repository-backed progress updates; do not start a `kb_draft` task and
do not use `kb_publish` for this flow.

The user should be able to review all Draft PRs from one natural-language
overview, without first selecting a PR. Every subsequent write requires exactly
one explicit PR number in the owner's current message:

- `publish #123` (also `public #123` or `发布 #123`): make that Draft PR
  **ready for review**, not merge it.
- `批准 #123`: **merge that PR into main**, not just submit a GitHub approval.
- `#123 修改意见：...`: revise that PR's changed content on its existing branch.

Never infer a number from the previous message, even if only one PR exists.
Bare `publish`, `批准`, or feedback without a number requires asking for the
number without making changes. Reject multi-PR and bulk instructions (including
`publish #123 #124` or `批准全部`); ask the owner to send one PR per message.
If the action or feedback is ambiguous, clarify before making changes.

## Scope and identity

- Only operate in a personal chat. In a group chat, give the current user a
  compact private-chat handoff and do not list or change PRs.
- Only list Draft PRs authored by the authenticated current GitHub user. Use
  `--author @me`; never infer another person's GitHub account from a display
  name or list all repository drafts.
- The KB repository comes from `kb_scope(action="show")`. If it is not bound,
  ask the user for the KB repository URL or `OWNER/REPO`. Do not guess it from
  the local workspace.
- Only consider open Draft PRs whose body contains `<!-- kb-progress-sync -->`.
  This marker is the boundary between this tool's PRs and ordinary code/KB
  drafts. If no matching draft exists, say so plainly.

## Read and summarize

1. Read the current binding with `kb_scope(action="show")` and identify the
   GitHub `OWNER/REPO` target.
2. List the current user's open drafts:

   ```text
   gh pr list --repo OWNER/REPO --author @me --draft --state open --json number,title,url,updatedAt,body
   ```

3. Keep only marker-bearing PRs. Retrieve all results, increasing `--limit` and
   repeating the list if the returned count reaches the limit; do not silently
   truncate the overview to the CLI's default result limit.
4. For every matching PR, inspect its metadata and changed files. Do not ask the
   owner to select a PR before providing summaries:

   ```text
   gh pr view NUMBER --repo OWNER/REPO --json number,title,url,author,state,isDraft,body,updatedAt,baseRefName,headRefName,headRefOid,files
   gh pr diff NUMBER --repo OWNER/REPO
   ```

5. Build one consolidated Chinese overview containing a separate concise summary
   for every matching PR, labeled with its number, title, and updated time.
   Read the marker-adjacent PR metadata when
   available for the source time window, source sessions, work-item identity,
   and known limitations. Inspect the diff to explain the update; never invent
   a time window, progress result, owner, evidence, or risk that is absent from
   the PR.

Each PR's summary must contain:

- the time window, or `时间窗口：PR 中未提供`;
- which progress documents were added or updated;
- for each changed progress document, what changed in plain language (for
  example: a milestone advanced, a blocker was added, an evidence link was
  attached, or a next action changed);
- any missing owner, source, evidence, conflict, or low-confidence callout;
- one clickable Draft PR link.

End the entire overview with exactly one instruction (not one per PR):
`回复 publish #编号，发布为 Ready for review；回复 批准 #编号，合并到 main；回复 #编号 修改意见：具体内容，修改对应 PR。每次只能操作一个 PR，必须明确编号。`
Track the shown head SHA and update identity separately for each PR. If reading
one PR fails, label its summary unavailable and continue summarizing the others;
do not offer a write on a PR whose current content has not been summarized.

Do not paste a raw diff, expose internal planning, or make the owner inspect
GitHub merely to understand the proposal. The PR link is an optional deeper
review surface, not the only explanation.

## Single-PR authorization

Before any publish, merge, or revision, all conditions below must hold in the
**same personal conversation**:

1. You have already shown the current summary for one exact PR number and URL.
2. The owner's current message contains exactly one explicit PR number and a
   clear action or concrete modification feedback. Acknowledgements such as
   `好的`, `看到了`, or a thumbs-up are not authorization.
3. Re-read the PR immediately before mutation and confirm it is still open,
   still contains `<!-- kb-progress-sync -->`, and its author is the
   authenticated current user. Publish additionally requires it to be a Draft;
   merge and revision may target a Draft or an already Ready for review PR,
   including one published earlier in this conversation.
4. The PR's head SHA / update identity has not changed since the shown summary.
   If it changed, summarize the new revision and ask again for the numbered
   action; never mutate a revision the owner has not seen. Refresh the recorded
   identity after this skill's own successful mutation.

Before the mutation, run `gh auth status`. If it is not authenticated, report
the exact problem and stop. Resolve the number only within the bound repository;
do not act on unrelated PRs or switch repositories implicitly.

## Publish command

For `publish #NUMBER`, `public #NUMBER`, or `发布 #NUMBER`, after the shared
authorization checks, run only:

```text
gh pr ready NUMBER --repo OWNER/REPO
```

This write follows the owner's explicit numbered publish instruction; do not ask a
second confirmation. On success, state that the PR is now Ready for review and
include its link. On failure, report the short `gh` error and re-read the PR to
report its actual state. Publish never authorizes merging.

## Merge command

For `批准 #NUMBER`, after the shared authorization checks:

1. Confirm `baseRefName` is exactly `main`; otherwise stop and explain the
   mismatch. Never retarget the PR automatically.
2. Inspect mergeability, required checks, and branch protection/review
   requirements. If blocked, pending, conflicting, or unknown, explain the
   blocker and stop. Never bypass protections, use `--admin`, or approve your
   own PR with `gh pr review --approve`.
3. If still Draft, make this one PR ready with `gh pr ready NUMBER --repo
   OWNER/REPO` as part of the explicit merge request. Re-read it and check the
   head SHA, base, and requirements again before merging.
4. Use a repository-permitted merge method (shown here as `--merge`; substitute
   `--squash` or `--rebase` only to match repository policy):

   ```text
   gh pr merge NUMBER --repo OWNER/REPO --merge --match-head-commit REVIEWED_HEAD_SHA
   ```

Do not enable auto-merge as a substitute for immediate merge. Verify the PR is
actually merged into `main` before claiming completion; if queued or blocked,
report that state instead. If publishing succeeded but merging failed, explain
that it remains Ready for review. Include the PR link in the result.

## Revision command

For `#NUMBER 修改意见：...`, after the shared authorization checks, inspect the
selected PR's existing head repository and branch. Apply the requested edits to
the actual changed progress documents, not merely the PR description or a review
comment. Use an isolated worktree/checkout for that exact branch and preserve
unrelated local edits. If the branch cannot be safely edited, report the blocker.

Validate the changed documents using the repository's existing checks. Before
pushing, re-read the PR and verify its state, author, marker, base, and head SHA
still match the reviewed revision. If any changed, stop and obtain a fresh
numbered instruction. Push only the requested commit(s) to that PR's existing
head branch, using a normal non-force push; never push directly to `main`, force
push, create a replacement PR, or touch another PR.

Keep the Draft/Ready status unchanged. Verify the updated PR content and give a
new concise summary and link. Revision does not authorize publish or merge;
either requires a separate numbered instruction for the new revision.

## Scheduled reminder mode

When invoked by the managed daily reminder for the personal owner, perform the same read-only
scan. Combine all new or changed `<!-- kb-progress-sync -->` Draft PRs into one
personal reminder, with a separate natural-language summary and link for each,
and the same single numbered-action instruction at the end. Do not require
selection before summarizing. Scheduled runs are read-only: never publish,
merge, edit, or push; they cannot obtain live authorization.

Keep a durable per-PR notification key consisting of repository, PR number, and
head SHA. Do not repeat a reminder for an unchanged PR. A new commit creates a
new revision and earns one new reminder. If scheduler state is unavailable,
record that deduplication could not be verified in scheduler history rather than
sending notifications. An empty scan or a scan containing only previously notified
head SHAs must produce **no notification**, not a "no drafts" message.

The product can register `kb-progress-sync-daily` after explicit opt-in at **19:00
every day in the machine's local timezone**. It reads the latest installed bundled
skill each run, uses deterministic read-only GitHub collection, and sends one
consolidated notification through the owner's Teams bot only for new revisions.
It records notification keys only after a successful Teams delivery receipt.
Prerequisites: `praestoclaw serve` stays running, cloud login and the Teams bot
are connected, `gh` is authenticated, and `kb_scope(set)` has bound an allowed
GitHub repository in a verified personal Teams chat. Legacy/group-only bindings
are not inferred. Multiple personal KB repositories require clearing obsolete
bindings rather than guessing which repository a numbered reply would target.
Missing prerequisites and failed reads are recorded as errors
in scheduler history, not treated as empty results or sent as daily setup spam.

Opt in with `cron.kb_progress_sync.enabled: true` in local config, or create/enable
`kb-progress-sync-daily` using the cron UI/tool. Persisted user choices survive
restart. Optional `cron.kb_progress_sync.timezone` accepts an IANA timezone;
`schedule` can be customized when the job is first registered. Edit an existing
job's schedule/timezone through cron. Global `cron.enabled: false` also stops it.
The reminder is not live authorization: before a numbered write in personal chat,
re-read and summarize the exact revision there if it has not been shown in that
conversation, then apply the existing single-PR authorization checks.

## Failure handling

- If `gh pr list`, `view`, or `diff` cannot read the repository, name the
  command/capability that failed and ask for the PR URL or repository binding.
- If publishing a PR that is no longer a draft, say it is already Ready for
  review; never try to republish it. Explicitly numbered merge or revision
  requests may still proceed through their respective authorization checks.
- If the marker is absent, treat it as an ordinary PR and leave it untouched.
- If the draft has merge conflicts or the PR describes unresolved conflicts,
  include that in the summary and do not present publish or merge as a safe next
  step; ask for numbered modification feedback to resolve the conflicts.
