---
name: pmo-weekly-check
description: "Use in PraestoClaw private chat or group chat for PMO weekly project closeout reporting: summarize the ending week, @mention needed follow-ups, and run PMO grill pre-send self-check."
metadata:
  activation:
    keywords:
      - PMO weekly check
      - PMO 周检查
      - PMO 周报
      - 每周项目整理
      - 周文档归档
      - 周度风险检查
      - weekly PMO
      - weekly project closeout
      - weekly report knowledge base
    patterns:
      - "(?i)(pmo).{0,16}(weekly|week|周|周报|周检查|周度)"
      - "(?i)(每周|周度|本周|上周).{0,20}(pmo|项目).{0,20}(整理|归档|检查|周报|close)"
      - "(?i)(weekly).{0,20}(project|pmo).{0,20}(report|archive|closeout|check)"
      - "(?i)(整理|归档|关闭|close).{0,20}(本周|上周|周文档|weekly).{0,20}(知识库|kb|周报)"
  os: [win32]
  safe-tools:
    - tool: kb_scope
      match:
        action: "^show$"
    - tool: kb_inspect
      match:
        action: "^repos$"
    - tool: kb_inspect
      match:
        action: "^sync$"
    - tool: kb_inspect
      match:
        action: "^rules$"
    - tool: kb_inspect
      match:
        action: "^tree$"
    - tool: kb_inspect
      match:
        action: "^read$"
    - tool: kb_inspect
      match:
        action: "^search$"
    - tool: kb_change_history
      match:
        action: "^latest$"
    - tool: kb_change_history
      match:
        action: "^show$"
    - tool: kb_change_history
      match:
        action: "^file$"
---

# PMO Weekly Check

Use this skill in a direct PraestoClaw private chat or in the relevant project
group chat. It generates a read-only weekly closeout report, uses `pmo-grill`
only as a pre-send self-check on that report, and does not archive or modify
project documents.

## Conversation visibility

Keep the visible chat quiet. Keep internal plan progress, checklist progress,
step-by-step verification messages, and background status cards out of the
visible conversation. The user should see only the compact weekly summary,
action-needed follow-ups, up to three PMO focus items, and one short source
blocker when KB/source access is unavailable.

Follow the runtime's Teams native-mention guidance. Send a live Teams
`groupChat` or `channel` report through
`group_notify(content="...", teams_mentions=[...])`; use
`notify(channel="cloud", content="...", teams_mentions=[...])` only for a
personal/non-group cloud turn. After successful delivery, reply only with a
short receipt such as `已发送 PMO weekly check。` and do not repeat the report.

Mention every distinct human represented in the report or follow-up list, not
only the sender. Match each visible `@Full Name` with one
`{"name": "<display name>", "type": "user"}` object, adding `upn` or `id` when
available. A display-name-only identity with `type="user"` remains a structured
best-effort mention. Do not substitute `@所有人`, `@everyone`, or `type="all"`
unless the user explicitly requests a Teams-wide mention.

If the required delivery tool is unavailable, emit the complete report in the
normal final reply with visible `@Full Name` text and no `teams_mentions`. Do not
claim native delivery or include mention-tool/fallback diagnostics.

Teams reports must be readable without horizontal scrolling. Do not use a wide
Markdown table for owner status. Use one compact summary table with at most four
short columns, followed only by rows that need action and up to three PMO focus
bullets. Do not repeat table content in owner sections, narrate how the report
was produced, or add a conclusion paragraph. Use one short line per follow-up.

## Permission and approval model

Follow the same KB permission model as `pmo-grill`: KB tools are optional
capabilities for discovery and stay out of hard `requires.tools`. Safe KB read/discovery
actions are declared in `safe-tools`; KB write actions are outside this skill.
Use `kb_scope show`,
`kb_inspect` repos/sync/rules/tree/read/search, and `kb_change_history`
latest/show/file as the only KB read path. These KB read/discovery actions,
including `kb_inspect(action="sync")` even when it creates or updates the local
checkout, must run without interactive human approval. Do not ask the user to
approve KB reads, and do not substitute `shell`, `git`, `Remove-Item`, `curl`, or
filesystem commands for KB read/sync/discovery work. If a safe KB read tool is
missing or refused, report that exact capability as blocked and ask for the
needed KB text/link instead of requesting a shell approval. Do not call
KB write or KB binding mutation tools from weekly check.

## External source boundary

Default evidence sources are the configured KB, the current PraestoClaw turn,
and text or links the user explicitly provides in this weekly-check conversation.
Do not call Teams, M365 Copilot, M365 user, mail, calendar, SharePoint, WorkIQ,
or similar external MCP tools to inventory work, resolve people, search chat
history, inspect meetings, or fill missing evidence unless the current user
explicitly asks for that external search in this turn.

In particular, do not use or discover tools such as `MCP_teams_*`,
`MCP_m365-copilot_*`, `MCP_m365-user_*`, `MCP_mail_*`, `MCP_calendar_*`,
`MCP_sharepoint_*`, `MCP_workiq_*`, `teams_group_fetch`, or
`team_knowledge_capture` for a normal PMO weekly check. If the user explicitly
asks to search Teams/M365, keep that search narrowly scoped to the named chat,
person, meeting, date range, or message link, and label the result as external
evidence. Otherwise preserve missing material as an unresolved evidence gap,
carry-over item, or incomplete closeout instead of trying to recover it from
Teams/M365.

For follow-up mentions, use mention metadata already present in the KB or in the
current turn. Do not query Teams/M365 only to resolve a mention; fall back to
plain `@Full Name` text only when the required delivery tool is unavailable.

Weekly check does not write KB content. Do not include a handoff code block,
structured handoff payload, private-chat copy instructions, KB recommendations,
target-file suggestions, or document-maintenance actions in the visible report.

## Mandatory preflight

Before weekly work starts, perform the same KB preflight as `pmo-grill`:

1. Run `kb_scope(action="show")`.
2. If no KB is configured and the current user provided a GitHub URL under
  `gim-home/SocietasKnowledgeBase/tree/main/...`, derive the repo and subfolder
  for this run without saving a conversation binding. Ask the user for a KB URL
  or PMO folder scope only when no KB binding and no usable KB URL are present.
3. Run `kb_inspect(action="sync")` so a missing clone is created and an existing
  checkout is updated to the latest remote state. This is a safe KB read/sync
  action and must not be replaced by an approval-gated shell/git command.
4. If a KB capability is unavailable in the current chat context, keep the weekly
  check moving. Ask the user for the KB URL or PMO folder scope when the
  destination cannot be resolved, continue from that provided source, and mark
  only the unavailable capability as blocked. Report the exact blocked
  capability: binding, live sync, or read.

## Reminder semantics

The weekly check message itself is the reminder. Send the check result without
waiting for member responses inside this skill. Read previous daily/weekly PMO
records and check whether each requested evidence/update has been supplied. Carry
unresolved items forward and increment or state the reminder count.

Every missing closeout/evidence row must @mention the responsible member when a
mention form is known, using the same spelling supplied by the KB or current
conversation. Example: `@Member：请在 <date/time> 前补 <goal> 的 closing evidence；这是第 2 次提醒。`

If a member replies later, the next daily/weekly check should detect the new
evidence or owner update and close or carry forward the follow-up in the next
report. Keep the current weekly check on its scheduled path.

## Mentions and follow-up list

After the weekly report, list exactly who still needs to do what. Mention the
member in the same spelling the KB or current conversation provides, using
`@Full Name` in the content and a matching item in `teams_mentions` whenever a
structured mention form is known. Include the reminder count when the same
missing closeout/update was already requested in a prior check:

- `@Full Name`: provide closing evidence for `<goal>` by `<date>`; reminder #N.
- `@Full Name`: confirm carry-over risk/mitigation for `<goal>` by `<date>`; reminder #N.
- `@Full Name`: make the weekly go/no-go or ship/no-ship decision for `<goal>` by `<date>`; reminder #N.
- `@Full Name`: unblock dependency with `<team/person>` by `<date>`; reminder #N.

The weekly report itself must also use the visible `@Full Name` form for each
owner or member row, and the `teams_mentions` array must contain one object for
every distinct mentioned human. Owner section headings must also be visible
mentions, for example `@Coraline Gao`, not plain `Coraline Gao`. If the same
person appears in multiple rows, mention them once in `teams_mentions` and use
the same visible spelling everywhere.

When the weekly result contains any member row or follow-up, use the delivery
tool selected above: `group_notify` for a live Teams group/channel turn, or
`notify` for a personal/non-group cloud turn. The `content` must contain the
visible `@Full Name` text, and each `teams_mentions` item must identify the same
person with `name`, `type="user"`, and the best available `upn` or `id`. Use one
mention object per mentioned member, for example:

```json
[
  {"name": "Coraline Gao", "type": "user", "upn": "cogao@microsoft.com"},
  {"name": "Wenkai Jiang", "type": "user", "upn": "wenkaij@microsoft.com"}
]
```

If only a display name is available, include
`{"name": "<display name>", "type": "user"}` so the channel layer can attempt
best-effort resolution. If richer identity fields are unavailable, keep the
visible `@Full Name` text and that display-name-only identity object without
adding fallback or tool diagnostics to the report.

Do not append a handoff code block or instructions to copy content into private
chat. The follow-up line itself must contain the owner, goal, missing evidence
or decision, due date, and reminder count when applicable.

## Weekly workflow

1. Determine the ending week. Use the current runtime date when the user says
   "this week", "last week", or equivalent. If the week boundary is ambiguous,
   ask one short question.
2. Inventory the week's project material:
   - goals committed for the week;
   - documents, PRs, issues, demos, release/deploy notes, test evidence, meeting
     decisions, customer/user signals, and metrics;
   - open risks, closed risks, new blockers, escalations, and carried-over work;
   - documents that should be closed, archived, or marked superseded.
3. Organize the week into three buckets:
   - `closed`: finished work with evidence and no further weekly follow-up;
   - `carry-over`: still active work with owner, next action, date, and risk;
   - `insufficient`: claims or tasks without enough evidence to close or assess.
4. Generate a weekly report draft suitable for KB curation:
  - one-line week range and project scope;
  - a compact table of closed, carry-over, and insufficient goals;
  - action-needed owner follow-ups;
  - up to three risk changes, decisions, or PMO focus items.
5. Before sending the weekly report, apply
  the `pmo-grill` evidence standard as an inline self-check on the draft. Use
  the standard directly inside weekly check: every closeout/carry-over/risk row
  needs status versus expectation,
  evidence or evidence gap, blocker/dependency, next action with date, and risk
  reason.
6. If the self-check finds a defect, revise the draft before sending. Ask a new
  question only when the defect makes the weekly report materially misleading
  and the row cannot be represented as incomplete, carried-over, or unresolved
  risk.
7. Represent the ended week's document status in the report. Mark work complete
  when evidence supports completion. For unfinished work, name the carry-over
  owner and checkpoint. This logical closeout does not archive, supersede, or
  modify documents.
8. After sending the weekly closeout/report, stop. Weekly check remains
  read-only.

Keep the visible report compact:

- no prose introduction beyond a one-line week/scope heading;
- one table row per goal, with at most four short columns;
- follow-up lines only for goals that need owner action;
- at most three PMO focus bullets, omitting the section when empty;
- no repeated summary, methodology, source inventory, handoff code block, or
  closing narrative;
- no KB recommendation, target-file list, or document-maintenance section.

## Required weekly table

Present the weekly result as a compact table with these columns:

| Weekly goal | Owner | Close status | Evidence / risk |
|---|---|---|---|

`Close status` must be one of `closed`, `carry-over`, or `insufficient`. The
`Owner` cell must contain the visible `@Full Name` form used by
`teams_mentions`. One row represents one weekly goal. Include the shortest
concrete closeout evidence or evidence gap and delivery risk with its reason in
`Evidence / risk`.

Immediately after the table, use short per-goal or per-owner bullets only for
action-needed follow-ups, then list PMO focus separately. `Next action` and
`PMO focus` must not be table columns.

## Weekly close criteria

The ended week is closeable only when all of these are true:

- every completed item has concrete evidence;
- every carry-over item has owner, next action, and date;
- every red/yellow risk has reason, mitigation, owner, and PMO follow-up;
- unresolved evidence gaps are listed with accountable people;
- the report distinguishes facts from PMO judgment.

If these criteria are not met, revise the weekly report so the missing criteria
are explicit. Ask targeted follow-up questions only when the report would
otherwise mislead the group; if the user cannot provide more information, close
the week as `incomplete` and preserve the missing evidence list.
Do not append KB recommendations or document-maintenance actions.

