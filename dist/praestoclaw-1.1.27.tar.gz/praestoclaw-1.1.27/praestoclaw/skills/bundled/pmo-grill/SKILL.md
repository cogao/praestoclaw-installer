---
name: pmo-grill
description: "Use in PraestoClaw chat to PMO-grill the current user only for their own project risks, progress evidence, missing updates, and knowledge-base follow-up."
metadata:
  activation:
    keywords:
      - PMO grill
      - PMO 风险追问
      - PMO 风险检查
      - PMO 项目风险
      - 项目风险识别
      - 项目进展证据
      - grill 用户
      - 风险判断证据
      - progress evidence
      - project risk review
      - risk grilling
    patterns:
      - "(?i)(pmo).{0,16}(grill|risk|evidence|progress|check)"
      - "(?i)(grill|追问|盘问).{0,16}(pmo|项目|风险|进展|证据)"
      - "(?i)(pmo|项目).{0,20}(风险|进展|证据|阻塞|blocker).{0,20}(检查|识别|追问|判断)"
      - "(?i)(检查|识别|判断).{0,20}(项目|pmo).{0,20}(风险|进展|证据|blocker)"
  os: [win32, darwin, linux]
  safe-tools:
    - tool: kb_scope
      match:
        action: "^show$"
    - tool: kb_inspect
      match:
        action: "^repos$"
    - tool: kb_inspect
      match:
        action: "^sync$"
    - tool: kb_inspect
      match:
        action: "^rules$"
    - tool: kb_inspect
      match:
        action: "^tree$"
    - tool: kb_inspect
      match:
        action: "^read$"
    - tool: kb_inspect
      match:
        action: "^search$"
    - tool: kb_change_history
      match:
        action: "^latest$"
    - tool: kb_change_history
      match:
        action: "^show$"
    - tool: kb_change_history
      match:
        action: "^file$"
---

# PMO Grill

Use this skill in any PraestoClaw conversation where the current user can be
identified. It may question the current user in private chat or group chat, but
its scope is always the current user's own goals. KB write-back is a private-chat
operation: in group chat, stop after the PMO evidence packet and give the current
user a copyable private-chat continuation prompt instead of starting a KB draft.

Your job is to identify the current user's project risk, force their missing
facts into the open, and keep asking until their progress and evidence are
sufficient to support a PMO risk judgment. The tone is firm and specific, not
adversarial.

## Conversation visibility

Keep the visible chat quiet. Keep internal plan progress, checklist progress,
step-by-step verification messages, and background status cards out of the
visible conversation while running this skill. The user should see only:

- the initial current-user goal queue and progress-update request;
- goal-level question batches;
- concise acknowledgements when an answer materially changes a risk judgment;
- the PMO evidence packet together with the KB proposal confirmation request, or
  the KB publish result after approval.

Use internal planning if needed, and keep that planning private. If a tool or
runtime emits a progress card automatically, let that card stand on its own and
keep prose focused on the user's goals and questions.

Use the grill conversation itself as the visible workflow. Keep any plan, task,
progress checklist, or multi-step status tracking internal. If the host
environment automatically creates one, keep subsequent replies focused on the
user's goals and questions and omit plan-state labels such as `in_progress`,
`done`, or `Verify partial` from chat.

## Permission and approval model

Minimize approval prompts by separating read, draft, and publish capabilities.
Run safe reads directly instead of asking the user to approve them one by one.
KB read/discovery actions, including `kb_inspect(action="sync")` when it creates
or updates the local checkout, must run without interactive human approval. Do not
ask the user to approve KB reads, and do not substitute `shell`, `git`,
`Remove-Item`, `curl`, or filesystem commands for KB read/sync/discovery work. If a safe KB read tool is missing or refused, report that
exact capability as blocked and ask for the needed KB text/link instead of
requesting a shell approval.

## External source boundary

Default evidence sources are the configured KB, the current PraestoClaw turn,
and text or links the user explicitly provides in this grill conversation. Do not
call Teams, M365 Copilot, M365 user, mail, calendar, SharePoint, WorkIQ, or
Azure DevOps/ADO tools, or similar external MCP tools to discover updates,
resolve people, search chat history, inspect meetings, or fill missing evidence
unless the current user explicitly asks for that external search in this turn.

In particular, do not use or discover tools such as `MCP_teams_*`,
`MCP_m365-copilot_*`, `MCP_m365-user_*`, `MCP_mail_*`, `MCP_calendar_*`,
`MCP_sharepoint_*`, `MCP_workiq_*`, `teams_group_fetch`, or
`MCP_ado_*`, `az boards`, `az devops`, or `team_knowledge_capture` for a normal
PMO grill. If the user explicitly asks to search an external system, keep that
search narrowly scoped to the named chat, person, meeting, project, work item,
date range, or message link, and label the result as external evidence.
Otherwise record unavailable information as missing evidence, an unresolved
dependency, `no update after reminders`, or `insufficient update` instead of
trying to recover it from Teams/M365.

KB tools are optional capabilities for skill discovery. Keep them out of hard
`requires.tools`, because this skill has fallback behavior when a capability is
unavailable. When a capability exists, use it. When it is missing or refused by
context, report that exact capability and continue with the fallback path
described below.

Read / discovery actions must run without interactive approval when available:

- `kb_scope(action="show")`: read the current KB binding;
- `kb_inspect(action="repos|sync|rules|tree|read|search")`: read or sync the
  configured KB checkout;
- `kb_change_history(action="latest|show|file")`: read previous KB write records
  for this conversation;

These are declared in this skill's `safe-tools` frontmatter so the runtime can
register narrow ephemeral allowlist entries. This is similar in spirit to
`/feedback`, but narrower: `/feedback` has a dedicated `ApprovalGate` exception
for the protected `feedback_submit` tool, while PMO Grill only auto-allows fixed
read/discovery actions. The allowlist still preserves tool execution checks,
conversation scoping, KB repo allowlists, and repository rules.

Write-related actions are different:

- `kb_scope(action="set")` records the conversation's KB binding and may verify a
  folder by cloning; use it only after the user or group has named the repo and
  optional folder.
- `kb_draft(action="stage")` creates a local KB proposal and may create/update a
  disposable Draft PR review mirror. In a human-requested grill flow, use the
  staged proposal summary as the review surface instead of adding a separate
  approval card. In private-chat PMO grill flows, start the draft task with
  `kb_draft(action="start", source="direct", user_request="<PMO evidence packet>")`
  so the current conversation's evidence packet is used directly instead of a
  group `team_knowledge_capture` snapshot.
- `kb_publish()` is the real shared-KB write. For normal updates, use the approval
  model: publish only after the staged proposal has the required natural-language
  approval recorded by `kb_draft(action="approve", ...)`; then publish immediately
  with no second approval prompt. No-response statuses use the same ordinary
  approval path as every other KB write.

If an approval prompt still appears for a read-only action above, treat it as a
runtime allowlist/config issue and report the exact tool/action. Keep read-only
discovery on the automatic read path.

## Bounded waiting and reminders

Use bounded waiting. The goal of this skill is to update the user's latest status
for today; no reply is also a status after bounded reminders.

## Scheduled/background PMO grill mode

If the turn is an unattended scheduled/background run, such as a prompt prefixed
with `[Scheduled task` or metadata `source="cron"`, treat it as a non-interactive
triage note, not as an interactive grill session. The scheduled run can read and
sync the KB, classify currently visible risk, and prepare a pickup path, but it
cannot collect same-day user answers or obtain approval in that turn.

When creating this kind of job with `cron(action="add", ...)`, set
`use_current_kb_scope=true` so the scheduler captures the current personal-chat
KB binding as an immutable read-only scope. If the cron tool cannot capture that
trusted binding, do not create a degraded job; report the creation error and ask
the user to rebind the KB scope before retrying.

The cron runtime keeps KB-backed jobs in one persistent scheduler session. On
each run, inspect the preceding scheduled PMO output in that session before
choosing the highest-priority goal. Carry forward the previous question,
reminder count, cutoff, risk, and expected evidence. Increment the reminder count
only when the same unresolved owner/goal/evidence gap remains; reset it when the
fresh KB read shows a useful update or the selected goal changes. Do not emit
`reminder_count=0` merely because the current invocation is a new day.

For scheduled/background runs:

- Do not produce a full interactive grill transcript with question batches for
  every goal. Show a brief goal queue, then select only the single
  highest-priority goal and ask its next compact question batch. Do not ask
  follow-up questions for any other goal in the same scheduled output unless the
  scheduled task explicitly requests a full summary or report.
- Do not mark the user as `no update after reminders` or `insufficient update`
  merely because the first scheduled run received no reply. Resume the
  persistent reminder state on later runs and use those statuses only after the
  recorded final reminder or cutoff has passed without a useful KB/user update.
- Do not display internal owner-selection reasoning such as `为什么属于你`, owner
  matching proofs, delegation matching, or reviewer-match explanations. The
  visible queue should contain the actionable project item, evidence gap, risk,
  and next action only.
- Do not use wide Markdown tables. Use compact bullets or a table with at most
  four short columns. If the report would require horizontal scrolling in Teams,
  switch to owner/goal sections with bullets.
- Say plainly that this scheduled run cannot collect live answers or approve KB
  publishing. Do not phrase this as `不会自动写 KB` or as a failed write-back; say
  that KB write-back requires a live private-chat follow-up with explicit
  approval.
- When runtime context says direct PMO continuation is enabled, tell the user to
  reply directly to the scheduled message with the requested evidence. Do not
  include a copyable `PMO grill prompt`; the runtime routes the next reply back
  into this skill. Otherwise include exactly one copyable `PMO grill prompt` for
  the selected highest-priority follow-up, using the multi-line `key: value`
  handoff format described below.

The scheduled output shape is:

1. KB freshness: repo/scope, synced commit if known, check time.
2. Brief current-user goal queue: one short bullet per goal with title, due date,
  and latest KB state only.
3. Highest-priority follow-up: one compact question batch for one goal, asking
  only for missing facts that could change its risk judgment.
4. Continuation: direct-reply instruction when runtime handoff is enabled;
  otherwise one multi-line `PMO grill prompt` for that selected goal.
5. KB write-back status: `not staged in scheduled run; requires live private
  chat approval` unless a concrete KB tool blocker should be named.

If the job's purpose is specifically to deliver a daily reminder, prefer a short
actionable reminder over a complete PMO evidence packet. A scheduled PMO grill
should help the user start the next private-chat update; it should not simulate
the whole interactive grill without the user.

For each goal, use this default reminder policy unless the PMO file states a
stricter cadence:

1. Ask the first goal-level question batch.
2. If there is no useful reply by the next PMO check-in point, send one concise
  reminder for that same goal.
3. If there is still no useful reply by the daily cutoff / target checkpoint,
  send one final reminder.
4. After the final reminder or missed cutoff, stop waiting and record the goal as
  `no update after reminders` or `insufficient update`, with the best supported
  risk judgment from the KB and conversation context.

After the no-reply threshold, move to the next goal and include the no-reply
status in the visible PMO summary. Treat the absence of a KB update for that
person/day as the durable signal that daily or weekly check can read later.

Before the final reminder, tell the user exactly what will remain unresolved if
they do not respond, for example: `如果 <cutoff> 前没有回复，我会把 <goal> 在本次
PMO grill 中标记为 no update after reminders / <risk>；KB 只会在你明确确认后更新。`
If the cutoff passes with no useful reply, continue without a KB write. Keep
completion marks, goal changes, no-response statuses, and unrelated content on
the ordinary approval path.

If the session is interrupted, resume from the last unresolved goal and reminder
state. Preserve answered questions and continue from the current unresolved item.
If the last visible question has passed its cutoff with no human answer, classify
that goal from non-response and continue.

If a goal's next meaningful evidence is scheduled for a future checkpoint, keep
the current grill moving. Record the current goal as `pending checkpoint`, with the
checkpoint time, expected evidence, current risk, and reminder/no-response rule.
Then move immediately to the next current-user goal. Write the current `pending
checkpoint` state to KB only after ordinary user approval; otherwise keep it in
the visible PMO summary for the next daily/weekly check to interpret.

## Scope boundary

Grill only the current user. Keep the review scoped to goals connected to that
user instead of producing a team-wide risk review or listing every owner in the
weekly PMO file.

Other people may appear only when they are directly relevant to the current
user's work, for example as dependency owners, reviewers, blockers, or people who
owe evidence needed to assess the current user's goal. Keep those references
minimal and tied to the current user's risk judgment.

## Mandatory preflight

Do this before any PMO analysis, questioning, report generation, or KB update:

0. Resolve who the current user is.

  Prefer the sender identity supplied by the PraestoClaw runtime or Teams
  metadata; it can usually provide the current user's display name directly in
  both private and group conversations. If the runtime gives a display name,
  mail alias, AAD identity, or owner name, use it without asking the user to
  repeat who they are. Use the trusted sender identity directly while it is
  available. If identity is available but no KB row
  matches it, keep that identity and ask for the PMO/KB scope instead of
  re-asking who the user is. If identity is not available at all, ask one short
  question before reading the PMO ledger:

  ```text
  你在这个 PMO / weekly 文件里的 owner 名称是哪一个？
  ```

  Continue once you have either a trusted runtime identity or an explicit
  user-provided owner name. If the user says they are standing in for someone
  else, record that explicitly and grill only the delegated scope they name.

1. Check whether this conversation has a knowledge-base destination:

   ```
   kb_scope(action="show")
   ```

  If no KB is configured and the current private-chat request already includes
  a GitHub KB URL, treat that URL as the user's named KB target. Derive the repo
  and subfolder from the URL and call `kb_scope(action="set", repo="<repo>",
  subfolder="<path after tree/main>")` directly; do not ask for a second
  confirmation just to set the current conversation's KB scope. For example,
  `https://github.com/gim-home/SocietasKnowledgeBase/tree/main/10x-productivity/inner-loop`
  means `repo="https://github.com/gim-home/SocietasKnowledgeBase.git"` and
  `subfolder="10x-productivity/inner-loop"`.

  If no KB is configured and the user has not provided a usable KB URL, ask the
  user which allowed repository and optional subfolder to use. Record only what
  they actually name:

   ```
   kb_scope(action="set", repo="<repo they chose>", subfolder="<optional folder they named>")
   ```

  Use only a repository or folder the user or group named. If `kb_scope` is
  unavailable, refuses the current chat context, or cannot confirm a destination,
  ask the user for the KB URL or PMO folder scope, then continue the grill using
  that scope as user-provided evidence. Be precise when reporting tool state:
  report the exact blocked capability, such as "KB destination binding is not
  available", "KB draft staging is not available", or "KB publishing is not
  available".

2. Sync the knowledge-base checkout before relying on it:

   ```
   kb_inspect(action="sync")
   ```

  Treat first-use clone and normal pull as the same required freshness step. Do
  not ask the user to pull, clone, approve a shell command, or browse the KB by
  hand before attempting tool-based sync. If sync fails or `kb_inspect` is
  unavailable, ask the user for a KB URL or file scope and continue from the
  provided source. Clearly mark any conclusion as "not verified by live KB sync".
  If read/sync succeeds but `kb_draft` or
  `kb_publish` later refuses, keep the KB read result authoritative and report
  only the blocked staging/publishing capability.

3. PMO KB updates are performed directly in this skill by the current model. Use
  the KB tools directly for PMO grill write-back: read repository rules with
  `kb_inspect`, stage complete file contents with `kb_draft`, and publish with
  `kb_publish` after the required approval state is satisfied.

4. Read and follow the KB's own placement rules before asking where evidence
  should go. If the repository README or area rules say raw evidence,
  screenshots, run logs, or detailed trial notes belong under `artifacts`, use
  `artifacts` directly. Ask only when the repository rules are unavailable,
  conflicting, or ambiguous.

## Evidence standard

For each current-user project goal, risk, blocker, or claim, gather enough of the
following to make the risk judgment auditable:

- owner and accountable reviewer;
- expected outcome and acceptance criteria;
- current progress percentage and what changed since the last check;
- concrete evidence: PR, issue, design doc, test result, deployment, demo,
  customer/user confirmation, metric, incident record, or meeting decision;
- target date, next checkpoint, and confidence in the date;
- blocker, dependency owner, escalation path, and requested help;
- risk level, risk reason, impact, likelihood, mitigation, and trigger for PMO
  attention.

Evidence may be missing, and missing evidence must be explicitly labeled. Treat
unsupported status claims as unsupported facts.

## Goal-first collection

Use the goal as the unit of conversation and KB update. Gather status fields
goal by goal.

Before asking the user a question, resolve facts that are directly available
from configured read sources. Use KB documents, `kb_change_history`, current
turn metadata, and explicit links or identifiers the user gave in this
conversation. Do not ask the user to report facts the agent can verify from
those sources, including GitHub PR state, CI/check state, merge/release status,
previous PMO write-back status, scheduled-task configuration, or group/owner
membership already visible in the KB or current Teams metadata. Ask only for
facts that remain missing after those reads, or when the read capability is
blocked; if blocked, name the blocked capability instead of asking the user to
manually do the lookup.

For a GitHub PR URL, PR number, issue URL, release URL, tag, workflow run, or
commit SHA that appears in the KB or current conversation, first read the
available repository metadata before questioning the user. In particular, do not
ask what a PR fixed, whether it merged, whether CI passed, whether reviewers
approved it, whether it was included in a release, or which issue it closes when
that information is available from the PR title/body, linked issue, commits,
changed files, checks, reviews, merge state, release notes, tags, or changelog.
Use the same rule for scheduled jobs, meeting/task cards, and rollout notices:
read the configured source, current turn, KB history, or explicit link first;
ask only for the remaining management judgment or missing evidence.

At the start, list all goals that belong to the current user. Build this list
from the current PMO / weekly file and linked progress documents by filtering to
rows where the current user is owner, co-owner, reviewer, explicitly delegated
owner, or named next-action owner. Treat the owner/co-owner/reviewer/delegation
match as internal selection logic, not as explanatory content. Include only goals
whose connection to the current user is proven from runtime identity, KB owner
fields, or explicit user delegation. The visible output starts with the working
queue itself: goal title, due date, latest KB note, evidence gap, and the first
question to answer next.

Use neutral wording in the initial queue before the user updates progress:
`needs update`, `evidence missing`, `due soon`, or `KB has no current check-in`.
Reserve final statuses and final risk colors for the post-grill judgment. A
preliminary risk signal may be named only as a reason to ask for an update.

The first visible output after reading the KB must ask the user to update the
progress for the listed goals. Use `done`, `partial`, or `blocked` only after the
user update or the no-response threshold supports those conclusions.
Use wording like:

```text
我找到了这些属于你的目标。请按目标更新当前进展：已经完成了什么、有什么证据、还有什么阻塞或风险、下一步是什么。
```

Once the goal queue is known, work through it automatically one goal at a time
until every current-user goal has a risk judgment and KB write-back
recommendation, or until the user explicitly stops the session.

Treat that queue as the completion checklist for the whole grill session. After
each goal reaches a supported judgment, explicitly compare it with the working
queue and select the next goal that has not yet been grilled. A completed goal,
an approved proposal, or a successful `kb_publish` is not evidence that the
other queued goals were grilled. Do not announce that the grill is complete
while any queued goal lacks a current judgment and write-back recommendation.

Persist the queue in the visible conversation so it survives multi-turn replies:
every interactive question or acknowledgement must include one compact line in
this shape: `Grill progress: <done>/<total>; current: <goal>; remaining: <exact
goal titles or none>`. Carry the exact remaining titles forward on every turn;
do not replace them with a count alone. After a per-goal KB publish, show the
updated progress line and ask the next ungrilled goal's question in the same
reply. This compact line is workflow state, not an internal reasoning dump.

If the user starts from a daily/weekly follow-up and names a specific goal,
missing evidence item, or `Use pmo-grill` handoff line, treat the handoff as a
structured input contract. Parse any supplied fields such as `source`, `week`,
`date`, `owner`, `goal`, `缺口`, `风险`, `next_action`, `due`, `reminder_count`,
and `KB` whether they appear on one line as `key="value"` pairs or as a
multi-line code block with `key: value` fields. Also accept the older daily
handoff aliases `更新 goal="..."`, `缺口="..."`, and `KB="..."`.

Handoff mode identifies the first goal to grill; it does not narrow a scheduled
goal queue to that one goal. If the handoff includes or follows a scheduled
output with a current-user goal queue, preserve that queue as the session scope
and continue through its remaining goals after the focused goal. If the sender
identity is trusted and the handoff omits `owner`, use the current user as the
owner for this run.
If `owner` is present and differs from the trusted current user, ask one short
delegation question before continuing. When KB live sync/read is unavailable,
continue from the handoff fields as user-provided scope and mark the result
`not verified by live KB sync`; do not stop to request the PMO file and do not
rebuild the full current-user goal queue. Bind to the supplied KB scope when it
matches an allowed repository or explicit user-provided URL, but treat binding
failure as a write-back blocker rather than a blocker for the focused question.

Ask only the missing facts named by `缺口` plus any fact required to make the PMO
risk judgment auditable. Avoid asking owner/reviewer/next-action-role questions
when the handoff already identifies the owner or when the prompt was sent by the
current user in private chat. When the focused goal is assessed, record its
per-goal write-back candidate, then inspect the preserved queue and continue to
the next ungrilled goal. Start the direct KB update only after every goal in that
queue satisfies the completion barrier below.

For a daily or weekly handoff, the first visible grill question should
acknowledge the source and goal, state any live-KB limitation in one short
sentence only when relevant, and ask for only the missing update named by
`缺口`. Use this shape:

```text
我接着 <daily/weekly> check 里的这个目标继续：<goal>。现在只需要补齐：<缺口>。请给当前状态、证据链接/缺口、阻塞/依赖、下一步和日期。
```

In the final whole-session KB update, mark each handoff result so the next daily
or weekly check can close or carry it forward: include the source date/week,
goal, owner, resolved/missing evidence, risk judgment, next action, and reminder
count in the KB write-back candidate. If an earlier proposal was already
published before all queued goals were grilled, treat that publish as one goal's
write-back only and immediately continue with the next ungrilled goal.

For each current-user goal:

1. Identify the goal title, owner role, due date, acceptance criteria, and linked
  progress/evidence documents from the KB.
2. Ask a compact batch of the most important remaining questions for that goal:
  usually 2
  to 4 questions, capped at 5. Every question must target a missing fact that
  could change this goal's risk judgment or KB write-back. Keep each question
  batch scoped to one goal.
  Prefer the standard batch: current progress versus expectation, evidence link
  or evidence gap, blocker / dependency, and next action with date.
3. After each answer, update only that goal's status, evidence, risk, blocker,
  and next-action state. If the answer covers only part of the batch, keep the
  remaining unanswered items as explicit gaps.
4. Stop asking about that goal when its risk judgment is supported, or when the
  remaining gap is explicitly recorded as missing evidence or unresolved risk.
  Stay at PMO risk depth rather than implementation-debug depth. A goal is
  sufficiently assessed when you can answer: current status versus expectation,
  risk level, risk reason, evidence quality, blocker category, next owner action,
  and whether the KB needs an update.
  There is no requirement to identify root cause, reproduce the failure, or
  debug the implementation before assigning risk.
  If the only remaining uncertainty is a future go/no-go, validation run,
  release gate, or other scheduled checkpoint, classify the current state now,
  record it as `pending checkpoint`, and continue to the next goal instead of
  ending the turn or delaying KB write-back.
5. Produce a per-goal KB write-back candidate before moving to the next goal.
  The write-back candidate must separate management judgment from raw evidence:
  weekly/progress documents get concise status, risk, next action, and links;
  screenshots, run logs, transcripts, detailed trial notes, and other raw
  evidence go to the artifact location required by the KB rules.

Move to another goal only after the current goal has a clear `green`, `yellow`,
`red`, or `unknown` judgment and a concrete write-back recommendation.
`pending checkpoint` is also a valid current-goal outcome when the risk can be
classified now but final evidence is scheduled for later; continue the remaining
goal queue and include this state in the current grill's KB update.

## Sufficiency threshold

The purpose of grilling is risk classification. Stop drilling into details once
the collected information is enough to classify the goal:

- Ask for an exact log, PR, commit, screenshot, or run artifact only when that
  artifact is the difference between `green` and `yellow/red`.
- If the user says there are local errors before formal testing starts, record
  blocker category `local errors before formal test` and classify
  the goal from that fact. Ask for exact stack traces only when the KB write-back
  must link a specific error artifact.
- If the user says a capability is not passed / still in progress, record that
  as status and assess schedule risk. Stop at the PMO risk call once it is clear.
- If the user says the update effort is too high or the questions are too fine
  grained, stop asking details for that goal, record the remaining gaps, assign
  the appropriate risk, and move to the next goal.

For each goal, ask at most two substantive question batches by default. The
first batch collects the PMO essentials: progress versus expectation, evidence
or evidence gap, blocker/dependency, and next action with date. The second batch
is allowed only when the first answer leaves a gap that could change the risk
level or whether the KB should be updated. After two substantive batches, make
the best supported PMO risk judgment, record remaining gaps, and move on.

Reminders stay outside the substantive question-batch count when they only
repeat the same unanswered questions and add no new information requests. A
reminder becomes a substantive question batch when it adds a new question,
changes the scope, or asks for deeper detail.

The default two-batch limit is an instruction-level PMO cost-control rule, not a
runtime-enforced hard stop. It exists because the skill's purpose is daily status
and risk classification, not exhaustive investigation. Use the two batches to
reach one of these outcomes: `green`, `yellow`, `red`, `unknown`,
`no update after reminders`, or `insufficient update`. If product behavior must
hard-enforce this count across interrupted sessions, implement persisted per-goal
state in the runtime; the skill text can only direct the model to follow it.

## Grill loop

1. Build the compact working queue from rows where the current user is owner,
  co-owner, reviewer, explicitly delegated owner, or named next-action owner. If
  the KB contains a wider team baseline, apply that filter internally. The
  visible queue contains the actionable project items only: goal, due date,
  latest KB note, evidence gap, and first question.
2. Build a risk ledger with one row per current-user goal, milestone, or blocker.
  Mark every unknown as `missing` rather than filling it in.
3. Choose the single current-user goal whose missing information has the highest
  PMO risk value. Ask a short batch of the top questions for that goal. Keep the
  batch scoped to that single goal.
4. After each user answer, update that goal's ledger row and decide whether the
  remaining gaps can still change that goal's risk judgment.
5. Continue grilling the current goal until one of these is true:
   - every high/medium risk judgment has evidence or a named evidence gap;
   - every blocker has owner, next action, and date;
   - every progress percentage is tied to a concrete artifact or explicitly
     marked unsupported;
   - asking another question would not change the PMO risk call;
   - the user refuses or cannot provide more information, in which case record
     the insufficiency as a risk.
6. Write down the current goal's KB update candidate, then move to the next
  current-user goal if another one still needs grilling. Continue automatically
  between goals until the user explicitly stops or redirects the session.

If the user asks to pause current-goal details, postpone updates for this goal,
or reduce detail depth, interpret that first as a request to stop asking more
details for the current goal. Record the current goal's best available risk
judgment and continue to the next goal. Cancel KB writing only when the user
explicitly says to skip the KB write for the whole grill session.

## Risk classification

Use this compact classification unless the target KB has its own rules:

- `red`: blocked, date likely to slip, no credible mitigation, or evidence is
  insufficient for an important claim;
- `yellow`: meaningful risk or dependency exists but there is an owner, next
  action, and plausible mitigation;
- `green`: progress is supported by evidence, no material blocker is known, and
  the next checkpoint is clear;
- `unknown`: the user has not supplied enough evidence to classify the risk.

Use evidence, not owner confidence, as the basis for risk classification.

## Output before direct KB update

When the grill loop is complete, produce a concise PMO evidence packet:

- project scope and date/time of the check;
- current-user goal table with owner, progress, evidence, risk, and next action;
- risk ledger with reason, impact, likelihood, mitigation, owner, due date, and
  evidence status;
- per-goal missing evidence and who must provide it;
- per-goal KB write-back candidates: target document, status/risk row to add or
  update, artifact evidence to create or link, and whether the update should
  happen now or after more evidence arrives;
- PMO attention list: escalations, decisions needed, and follow-up checkpoints;
- recommendation on whether the KB should be updated and what should be written.

Keep the evidence packet readable in Teams. Do not use wide Markdown tables;
limit any table to at most four short columns, then use per-goal bullets for
evidence gaps, risk reason, next action, and KB write-back candidate. Do not
include an internal `why this belongs to you` column or section.

This evidence packet is a transition point into KB write-back. After producing
"本轮 Grill 结论" / "PMO evidence packet", immediately continue to the direct KB
update workflow below when staging is available and the user has not opted out of
KB writing. In Teams personal chat, do not end the turn with wording such as
`下一步我可以整理成 PMO evidence packet` or `然后准备 KB write-back 草稿`. The
next action after the evidence packet must be a KB tool call: read rules if they
have not been read, then call `kb_draft(action="start", source="direct", ...)`
or `kb_draft(action="restart", source="direct", ...)`, and continue to
`kb_draft(action="stage", ...)` unless a concrete blocker prevents staging.

## Direct KB update

Update the KB after every current-user goal in the working queue has a current
risk judgment and write-back recommendation, including goals whose current
outcome is `pending checkpoint`. Start KB write-back after the whole goal queue
is complete, and include future checkpoints as current status rather than a
reason to defer. The only normal reason to skip KB writing is an explicit user
instruction to skip the KB write for the whole grill session.

Before `kb_draft(action="start"|"restart")`, `kb_draft(action="stage")`, and
`kb_publish()`, re-check the working queue. The gate passes only when every goal
has one of `green`, `yellow`, `red`, `unknown`, or `pending checkpoint` plus a
concrete write-back recommendation. If any goal is missing either field, ask the
next goal's compact question batch instead of calling a KB write tool.

If the user does not reply for a goal, follow bounded reminders and then mark
`no update after reminders` / `insufficient update` in the visible PMO summary.
Do not write that silence to KB automatically. No other missing evidence, future
date, open risk, blocked dependency, or pending checkpoint may stop the grill
from completing all goals and preparing ordinary approval-based KB candidates.

After the PMO evidence packet is ready in Teams personal chat, update the KB
directly from this skill in the same run. The normal successful private-chat path
is: finish all goal judgments -> create the PMO evidence packet -> read KB rules
-> start a direct KB draft task -> stage a KB proposal -> ask for the required
proposal confirmation. Start the direct draft task immediately after the evidence
packet is ready. A visible PMO summary without a staged KB proposal is incomplete
unless one of the permitted stopping points below applies.

In group chat, do not call `kb_draft(action="start", source="direct", ...)` or
`kb_draft(action="restart", source="direct", ...)`; that direct source is
personal-chat only. Instead, present the PMO evidence packet plus one visible
`PMO grill prompt` code block that the current user can copy into private chat.
The prompt must include the current owner, goal, missing evidence, risk,
next_action, due date, reminder_count when known, and KB scope.

1. Read the repository rules and nearby documents for every target path with
  `kb_inspect(action="rules")`, `kb_inspect(action="tree")`, and
  `kb_inspect(action="read")` as needed.
2. In Teams personal chat only, start or restart the draft task with
  `kb_draft(action="start", source="direct", user_request="<PMO evidence packet>")`
  or `kb_draft(action="restart", source="direct", user_request="<PMO evidence packet>")`
  if an unrelated unfinished task is already open. This private-chat direct path
  intentionally does not require `team_knowledge_capture`.
3. Convert each per-goal write-back candidate into complete target file content.
  Weekly/progress documents get concise status, risk, next action, and links;
  raw evidence goes to the artifact location required by the KB rules. Do not
  skip weekly-cycle, progress, or README updates just because an existing KB
  file uses CRLF line endings; submit complete intended file contents and let
  `kb_draft` normalize line endings to LF.
4. Stage the proposal with `kb_draft(action="stage", ...)`. Include a clear
  overview, complete per-file summaries, evidence links, and the PMO risk
  judgment for each affected goal.
5. Present the staged proposal summary for the required human confirmation when
  the KB tooling requires it. Use the KB rules for evidence placement; when they
  specify `artifacts`, write evidence there. Every proposal needs explicit
  approval, including no-response / insufficient-update proposals.
6. After approval is recorded, call `kb_publish()` in the same workflow. If the
  KB tooling refuses because the current chat context cannot publish, report the
  blocker and keep the PMO evidence packet as the direct-write fallback artifact.

Permitted stopping points after the grill loop are only:

- waiting for the user's confirmation of a normal staged KB proposal, with a
  deadline and reminder state recorded;
- `kb_draft` or `kb_publish` explicitly refuses or is unavailable, in which case
  say which capability is blocked and provide the intended write-back candidates;
- the user explicitly says not to write or update the KB at all.

Use bounded approval reminders. Send at most two concise approval reminders for
normal proposals. If confirmation is still absent, leave the normal proposal
staged and unpublished, report the approval gap, and include that gap in the next
PMO update. If approval later arrives for a normal proposal, resume the staged
proposal and publish without re-grilling goals while the underlying status is
unchanged.

Treat a user's correction such as "不是，我是说要更新 KB" as confirmation that KB
write-back should happen for the whole grill session. Finish the remaining goals
first, then stage one complete KB proposal for the whole grill session.
