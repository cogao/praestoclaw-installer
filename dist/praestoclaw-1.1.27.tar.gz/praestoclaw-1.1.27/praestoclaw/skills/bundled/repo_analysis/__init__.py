"""
repo-analysis skill — public API.

Exports the three main engine classes and supporting types so callers can
import directly from the package root:

    from praestoclaw.skills.bundled.repo_analysis import (
        FullAnalyzer,
        IncrementalUpdater,
        OnDemandDeepener,
        AnalysisConfig,
        KBSearcher,
    )
"""

__all__ = [
    # Analyzers
    "FullAnalyzer",
    "AnalysisStatusReader",
    "IncrementalUpdater",
    "OnDemandDeepener",
    # Config & models
    "AnalysisConfig",
    "ModuleInfo",
    "RepoFacts",
    "collect_repo_facts",
    # Search
    "KBSearcher",
    "SearchResult",
    "QACacheEntry",
    # Templates & helpers
    "render_template",
    "state_to_json",
    "DEFAULT_CONFIG",
    "STATE_SCHEMA",
    "AUDIENCE_DOCS",
    # Exceptions
    "AnalysisError",
    "RateLimitError",
    # Types
    "LLMCaller",
    # Cron / auto-trigger helpers
    "schedule_kb_updates",
    "unschedule_kb_updates",
    "kb_already_initialized",
]

_EXPORT_MODULES = {
    "FullAnalyzer": ".analyzer",
    "AnalysisStatusReader": ".analyzer",
    "IncrementalUpdater": ".analyzer",
    "OnDemandDeepener": ".analyzer",
    "AnalysisConfig": ".analyzer",
    "ModuleInfo": ".analyzer",
    "RepoFacts": ".collector",
    "collect_repo_facts": ".collector",
    "AnalysisError": ".analyzer",
    "RateLimitError": ".analyzer",
    "LLMCaller": ".analyzer",
    "KBSearcher": ".searcher",
    "SearchResult": ".searcher",
    "QACacheEntry": ".searcher",
    "render_template": ".templates",
    "state_to_json": ".templates",
    "DEFAULT_CONFIG": ".templates",
    "STATE_SCHEMA": ".templates",
    "AUDIENCE_DOCS": ".templates",
    "schedule_kb_updates": ".auto_trigger",
    "unschedule_kb_updates": ".auto_trigger",
    "kb_already_initialized": ".auto_trigger",
}


def __getattr__(name: str):  # type: ignore[no-untyped-def]
    if name not in _EXPORT_MODULES:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    from importlib import import_module

    module = import_module(_EXPORT_MODULES[name], __name__)
    value = getattr(module, name)
    globals()[name] = value
    return value
