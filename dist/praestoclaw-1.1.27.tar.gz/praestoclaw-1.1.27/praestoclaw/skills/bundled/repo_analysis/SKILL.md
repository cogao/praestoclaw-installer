---
name: repo-analysis
description: >
  将代码仓库的知识沉淀为结构化 Markdown 文档，支持自然语言问答。
  当用户提到"分析仓库"、"建知识库"、"全量分析"、"更新知识库"、"kb status"、
  "kb init"、"kb update"、"kb sync"，或者询问关于代码的自然语言问题（模块功能、
  接口参数、功能实现位置、最近变更等），触发本 Skill。
metadata:
    activation:
        keywords:
            - repo-analysis
            - repo analysis
            - repo知识库
            - repo 知识库
            - codebase analysis
            - repository analysis
            - analyze repo
            - analyze repository
            - 分析仓库
            - 分析这个仓库
            - 分析 repo
            - 分析代码库
            - 建知识库
            - 创建知识库
            - 全量分析
            - 更新知识库
            - 增量更新
            - 同步最新代码
            - 知识库状态
            - kb status
            - kb init
            - kb update
            - kb sync
            - 定期更新
            - 自动更新
            - 周期更新
            - 定时更新
            - 每隔几小时
            - 每几小时
            - schedule update
            - schedule kb
            - auto update kb
            - periodic update
            - 停止定期更新
            - 取消定期更新
            - unschedule kb
        patterns:
            - "(?i)(analyze|分析|总结|了解|提炼|沉淀).{0,30}(repo|repository|codebase|仓库|代码库)"
            - "(?i)(repo|repository|codebase|仓库|代码库).{0,30}(analysis|analyze|knowledge|kb|知识库|分析|总结)"
            - "(?i)\\bkb\\s+(status|init|update|sync|schedule|unschedule)\\b"
            - "(?i)(定期|自动|周期|定时|每\\s*\\d+\\s*小时).{0,15}(更新|刷新|同步).{0,15}(知识库|kb|repo|仓库)"
            - "(?i)(知识库|kb|repo|仓库).{0,15}(定期|自动|周期|定时).{0,15}(更新|刷新|同步)"
            - "(?i)(停止|取消|关闭).{0,15}(定期|自动|周期).{0,15}(更新|刷新)"
---

# Skill: Repo Knowledge Base

## 描述
将代码仓库的知识沉淀为结构化 Markdown 文档，支持自然语言问答。
知识库存储在 `kb/` 目录下，按仓库、模块、文件三层组织，并在每一层按角色拆分：
PM、Developer、Tester、Team Lead。文档只保存对应角色为了完成工作需要知道的内容。

## 触发条件

以下用户意图触发本 Skill：

### 知识库构建 / 更新
- "分析这个仓库" / "帮我建知识库" / "全量分析"
- "更新知识库" / "同步最新代码" / "增量更新"

### 问答查询
- "这个模块是做什么的？"
- "XXX 功能在哪里实现？"
- "XXX 接口有什么参数？"
- "上次改了什么？"
- 任何关于 repo 代码的自然语言问题

### 显式管理
- "kb status" / "知识库状态"
- "kb init" / "初始化知识库"
- "kb update" / "kb sync"

## 行为流程

### 场景 A：首次使用 / 全量分析
```
用户: "帮我分析这个 repo / 建知识库"
    │
    ▼
1. 检查 kb/ 是否存在
   - 存在 → 询问是否覆盖重建
   - 不存在 → 直接开始
    │
    ▼
2. 执行全量分析（FullAnalyzer）
    - Layer 1：识别模块边界，并为 PM / Developer / Tester / Team Lead 标注关注原因
    - Layer 2：抽取文件级角色入口，包括产品入口、代码入口、测试入口、负责人风险信号
    - Layer 3：按模块生成四个角色视角的知识
    │
    ▼
3. 汇报结果：模块数、文档数、耗时
```

### 场景 B：增量更新
```
用户: "更新知识库" 或检测到 HEAD 变更
    │
    ▼
1. 读取 kb/.state.json 中的 last_commit
2. git diff last_commit..HEAD --name-only
3. 执行增量更新（IncrementalUpdater）
    │
    ▼
4. 汇报：变更模块数、更新文档数
```

> ⚠️ **不要自己用 shell 跑 `git pull` / `git reset --hard` / `git checkout -f` 来"把仓库同步到最新"**。
> analyzer 的 CLI 入口在执行 `--action full` / `--action incremental` 前会自动:
>   1. 仓库目录不存在 → 按 `BUILTIN_PROJECTS[*].clone_url` 自动 `git clone`(只 clone 一次,后续 run 不会重复)。
>   2. 仓库已存在 → `git fetch` + `git merge --ff-only @{u}`,仅当工作区干净且 ff 可行时才推进 HEAD;dirty tree 或 diverged history 一律跳过 sync,直接分析当前 HEAD。
> 这两步全在 Python 里做,不需要 agent 干预。任何"我帮你 reset 一下仓库"之类的提议都是错的。

### 场景 C：自然语言问答
```
用户问题
    │
    ▼
1. 关键词提取 → 搜索 kb/（grep 级别）
2. 命中 → 直接回答，附注来源文档
3. 未命中 / 答案模糊 → 触发按需深化（OnDemandDeepener）
    │
    ▼
4. 回答问题 + 更新 qa_cache.md
```

## 角色化分析

Skill 在分析 repo 时，不生成泛化的“技术文档集合”，而是按角色生成不同知识面：

| 角色 | 生成文档 | 保存内容 |
|------|----------|----------|
| PM | `pm.md` | 用户价值、产品行为、关键流程、指标、需要追问的问题 |
| Developer | `developer.md` | 代码入口、核心实现、依赖接口、扩展点、开发风险 |
| Tester | `tester.md` | 测试范围、关键场景、测试数据与环境、回归风险、测试缺口 |
| Team Lead | `team_lead.md` | 职责边界、维护成本、交付风险、跨团队依赖、建议行动 |
| Designer / UX | `designer.md` | 用户旅程、关键界面/组件、设计系统、可达性、设计债 |
| Product Marketing / GTM | `marketing.md` | 目标用户、价值主张、卖点、上市材料缺口、竞品提示 |
| Security / Compliance | `security.md` | 敏感数据流、认证授权、外部依赖、合规要求、修复优先级 |
| SRE / DevOps | `sre.md` | 部署单元、可观测性、SLO/告警、故障域、运维负担 |
| Data / Analytics | `data.md` | 数据流、埋点事件、指标定义、数据契约、分析缺口 |

回答问题时，优先检索与用户角色匹配的文档；如果用户未说明角色，则综合 README 与相关模块的角色文档回答。

## 知识库结构

```
kb/
  README.md              # Repo 全局概览（唯一入口）
  code_index.md          # 功能→文件→函数索引
  qa_cache.md            # 问答缓存
  .state.json            # 状态文件（last_commit, 模块列表, 更新时间）
  .config.json           # 用户配置（可选）
  .warnings.log          # 分析警告日志
  modules/
    <module_name>/
            pm.md              # PM 需要知道的产品价值、行为、流程和指标
            developer.md       # Developer 需要知道的代码入口、实现和风险
            tester.md          # Tester 需要知道的测试范围、场景和缺口
            team_lead.md       # Team Lead 需要知道的职责、复杂度和交付风险
            designer.md        # Designer / UX 视角：用户旅程、关键界面、设计债
            marketing.md       # Product Marketing / GTM 视角：目标用户、卖点、上市材料
            security.md        # Security / Compliance 视角：数据流、认证授权、合规
            sre.md             # SRE / DevOps 视角：部署、可观测性、SLO、故障域
            data.md            # Data / Analytics 视角：数据流、埋点、指标
```

## 配置

在 `kb/.config.json` 中可覆盖默认值：

```json
{
  "max_concurrency": 20,
  "retry_max_attempts": 3,
  "retry_base_delay_ms": 2000,
  "layer2_batch_size": 20,
  "layer2_file_char_limit": 4000,
  "layer3_file_char_limit": 4000,
  "skip_patterns": ["vendor/", "node_modules/", "*.lock", "*.generated.*"],
  "large_repo_module_limit": 50
}
```

## 实现模块

- `analyzer.py` — 核心分析引擎（FullAnalyzer / IncrementalUpdater / OnDemandDeepener）
- `collector.py` — 确定性仓库事实收集，LLM 调用前收集目录树、文件统计、关键文件和 git 活动
- `templates.py` — 所有 Markdown 文档模板
- `searcher.py` — 知识库搜索
- `__init__.py` — 对外导出

增量更新需要先定位受影响模块，再按 changed files 路由到对应角色文档：测试变更优先更新 Tester，文档/产品入口更新 PM，源码实现更新 Developer，所有变更都保留 Team Lead 变更历史；大范围变更更新全部角色文档。

Full analysis 必须使用 KB 目录下的 `.run.lock` 防止重复运行，并用 `.progress.json` / `.checkpoint.json` 暴露状态；当用户询问“repo 分析跑完了吗 / 跑到哪里了 / 还在跑吗”时，必须使用 `AnalysisStatusReader.snapshot()` 或 CLI `--action status` 读取 `.progress.json`、`.checkpoint.json`、`.run.lock` 和已写出的 KB 文件来回答，绝不能为了查进度再次启动 full analysis，也不能只靠日志猜测。分析过程需要分阶段落盘：Layer 2 完成后写 `code_index.md`，Layer 3 每完成一个 module 就写该 module 的角色文档，最终再写仓库级 README 和正式 `.state.json`。`.checkpoint.json` 必须保存 module map、Layer 2 draft、已完成 module 和结构化 analyzed_modules；`--resume` / `resume=True` 要沿用 checkpoint 的 run_id，跳过已完成且有结构化结果的 module，只补未完成部分。增量更新遇到活跃 `.run.lock` 或未 completed checkpoint 时，应返回运行中/建议 resume 的状态，而不是写 KB。

## 调用方式

`analyzer.py` 的所有引擎类通过 `LLMCaller` 回调调用 LLM，**不自行创建 provider**。
当通过 shell 独立运行时，使用内置 CLI entry point（读取 PraestoClaw 配置自动创建 provider）：

> ⚠️ **`--action full` / `--action incremental` 必须用 shell 的 background 模式运行**：完整分析在中大型 repo 上常常超过 10 分钟（observed 60+ min on Societas），同步 shell 调用会被 600s timeout 杀掉，导致分析白跑、checkpoint 反复重启。**通过 agent 的 shell tool 调用时，必须传 `timeout=0`**；进程立刻返回 PID，analyzer 在后台继续写 `.run.log` / `.progress.json` / `.checkpoint.json`，agent 后续轮次或下次 cron 触发时通过 `--action status` 读状态文件即可。`--action status` / `--action ask` / `--action schedule` 是短任务，正常同步即可。

```bash
# 全量分析（kb 默认存到 ~/.praestoclaw/kb/<repo-name>/）
python -m praestoclaw.skills.bundled.repo_analysis.analyzer \
    --action full \
    --repo /path/to/repo \
    --model auto

# 断点继续上一次未完成的 full analysis
python -m praestoclaw.skills.bundled.repo_analysis.analyzer \
    --action full \
    --repo /path/to/repo \
    --model auto \
    --resume

# 全量分析（自定义 kb 路径）
python -m praestoclaw.skills.bundled.repo_analysis.analyzer \
    --action full \
    --repo /path/to/repo \
    --kb-path /custom/kb/path \
    --model auto

# 增量更新
python -m praestoclaw.skills.bundled.repo_analysis.analyzer \
    --action incremental \
    --repo /path/to/repo

# 查询 full analysis 进度（只读状态文件，不调用 LLM）
python -m praestoclaw.skills.bundled.repo_analysis.analyzer \
    --action status \
    --repo /path/to/repo

# 自然语言问答
python -m praestoclaw.skills.bundled.repo_analysis.analyzer \
    --action ask \
    --repo /path/to/repo \
    --question "XXX 模块是做什么的？"

# 用户明确同意后注册定期更新（silent，会在 ~60s 后跑一次 bootstrap）
python -m praestoclaw.skills.bundled.repo_analysis.analyzer \
    --action schedule \
    --repo /path/to/repo \
    --interval-hours 6        # 用户指定的间隔

# 注册定期更新但希望每次都把结果发给用户的频道
python -m praestoclaw.skills.bundled.repo_analysis.analyzer \
    --action schedule \
    --repo /path/to/repo \
    --interval-hours 6 \
    --notify

# 取消该 repo 的所有定期更新
python -m praestoclaw.skills.bundled.repo_analysis.analyzer \
    --action unschedule \
    --repo /path/to/repo
```

## 定期更新流程

定期更新只在用户明确要求后注册。用户在做完一次手动 full analysis 后，agent 会念出
   `followup_prompt`（“要让我每隔几小时自动增量更新一次吗？”），如果用户答“好/默认/每 6 小时”，
agent 必须再次调用本 skill 的 `--action schedule --interval-hours <N>`，禁止用 generic
shell/cron 命令绕过本 skill。同理“停止更新”走 `--action unschedule`。

所有 cron job 的 prompt 都写死要求“使用 repo-analysis skill”，确保每次定时唤醒都通过本
skill 的 analyzer 路径运行，不会被其它任意工具/脚本顶替。

## 注意事项

1. **并发控制**：所有 LLM 调用通过 `asyncio.Semaphore` 限制并发（默认 `AnalysisConfig.max_concurrency=20`，可在 `kb/.config.json` 调）。
2. **退避重试**：遭遇 429 / Rate Limit 时自动指数退避 + jitter 重试（最多3次）。
3. **大仓库保护**：文件数 > 2000 时降级策略，模块数上限50。
4. **LLM 调用**：`analyzer.py` 通过注入的 `LLMCaller` 回调调用 LLM，不内部创建 provider。
   独立运行时由 `__main__` entry point 加载 PraestoClaw 配置并封装为回调。
5. **失败降级**：模块分析失败时写占位文档，不中断整体流程。
