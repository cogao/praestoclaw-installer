"""Cron-based scheduling for repo-analysis KB updates.

This module is the **single entry point** for explicitly registering periodic
KB updates through ``analyzer.py --action schedule`` or user prompts like
"每 6 小时更新一次". The cron entries are
written directly to ``~/.praestoclaw/cron/jobs.json`` (the format
loaded by :class:`praestoclaw.cron.service.SchedulerService`) so this
helper works even when no runtime/scheduler is alive — the user's next
agent start picks the jobs up.

The scheduled prompt is **deliberately worded** to force use of the
``repo-analysis`` skill — no parallel code path is permitted.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

from loguru import logger

from praestoclaw.utils.helpers import get_data_dir

__all__ = [
    "JOB_NAME_PREFIX",
    "schedule_kb_updates",
    "unschedule_kb_updates",
    "kb_already_initialized",
]

JOB_NAME_PREFIX = "repo-analysis:"
_BOOTSTRAP_DELAY_SECONDS = 60  # initial full analysis runs ~1 min after agent start
_DEFAULT_INTERVAL_SECONDS = 7200  # 2 hours
_RUN_LOCK_FRESH_SECONDS = 24 * 3600  # treat .run.lock newer than 24h as live


def _default_kb_path(repo_path: Path) -> Path:
    """Match the default kb-path convention used by the analyzer CLI."""
    return get_data_dir() / "kb" / repo_path.name


def _pid_alive(pid: int) -> bool:
    """Return True if *pid* names a currently-running process.

    Cross-platform, stdlib-only. On Windows we use OpenProcess; on POSIX
    we use ``os.kill(pid, 0)``. Any error or non-positive pid returns
    False so callers treat the lock as stale.
    """
    if not isinstance(pid, int) or pid <= 0:
        return False
    import os
    import sys

    if sys.platform == "win32":
        import ctypes
        from ctypes import wintypes

        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        STILL_ACTIVE = 259
        kernel32 = ctypes.windll.kernel32
        # Default ctypes restype is c_int, which truncates 64-bit HANDLE
        # values on 64-bit Windows and gives unreliable PID-liveness results.
        # Pin the prototypes explicitly so the HANDLE round-trips correctly.
        kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.GetExitCodeProcess.argtypes = [
            wintypes.HANDLE,
            ctypes.POINTER(wintypes.DWORD),
        ]
        kernel32.GetExitCodeProcess.restype = wintypes.BOOL
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel32.CloseHandle.restype = wintypes.BOOL
        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not handle:
            return False
        try:
            exit_code = wintypes.DWORD()
            ok = kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code))
            return bool(ok) and exit_code.value == STILL_ACTIVE
        finally:
            kernel32.CloseHandle(handle)
    else:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return False
        except PermissionError:
            # POSIX: signal-0 raises EPERM when the process exists but is
            # owned by another user; treat that as alive, not stale.
            return True
        except OSError:
            return False
        return True


def _run_lock_is_live(lock_path: Path) -> bool:
    """True if *lock_path* points to a still-running analyzer.

    Validates against two signals:
      1. PID recorded in the JSON body is still alive.
      2. Lock mtime is within the freshness window.
    Either signal alone is not enough — a PID gets reused over time,
    and an mtime is not invalidated by Ctrl-C.
    """
    if not lock_path.is_file():
        return False
    import time

    age = time.time() - lock_path.stat().st_mtime
    if age >= _RUN_LOCK_FRESH_SECONDS:
        return False
    try:
        data = json.loads(lock_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        # Corrupt lock — treat as stale; the analyzer will overwrite it.
        return False
    pid = data.get("pid")
    return _pid_alive(pid) if isinstance(pid, int) else False


def kb_already_initialized(repo_path: Path, kb_path: Path | None = None) -> bool:
    """True when the KB for ``repo_path`` has been built or is actively building.

    Returning True means bootstrap (initial full analysis) is unnecessary
    — the recurring incremental job is enough to keep things fresh.
    Checks, in order:

    1. ``.state.json`` exists — a completed full analysis run.
    2. ``.checkpoint.json`` exists with structured progress — a partial
       run that ``--resume`` can pick up.
    3. ``.run.lock`` exists, is fresh (<24h), **and** its recorded PID
       is still alive — an analysis is currently running, so kicking
       off another bootstrap would just hit the lock and fail.
    """
    kb = (kb_path or _default_kb_path(repo_path)).resolve()
    if not kb.is_dir():
        return False
    if (kb / ".state.json").is_file():
        return True
    checkpoint = kb / ".checkpoint.json"
    if checkpoint.is_file() and checkpoint.stat().st_size > 0:
        try:
            json.loads(checkpoint.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            # Corrupt/unreadable checkpoint — let bootstrap rebuild it.
            pass
        else:
            return True
    return _run_lock_is_live(kb / ".run.lock")


def _jobs_file() -> Path:
    return get_data_dir() / "cron" / "jobs.json"


def _load_jobs() -> list[dict]:
    path = _jobs_file()
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return data
    except Exception as exc:  # pragma: no cover - corrupt file
        logger.warning("repo-analysis: failed to read {}: {}", path, exc)
    return []


def _save_jobs(jobs: list[dict]) -> None:
    path = _jobs_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(jobs, indent=2, ensure_ascii=False), encoding="utf-8")


def _job_name(repo_path: Path, suffix: str = "") -> str:
    base = f"{JOB_NAME_PREFIX}{repo_path.name.lower()}"
    return f"{base}:{suffix}" if suffix else base


def _build_prompt(repo_path: Path, kb: Path) -> str:
    """Prompt that forces the agent through the repo-analysis skill."""
    return (
        f"使用 repo-analysis skill 对仓库 {repo_path} 执行知识库更新。"
        f"必须通过该 skill 调用 analyzer，不要使用任何其它方式分析代码。"
        f"决策规则：先查看 {kb} 是否存在以及 .state.json / .checkpoint.json 状态。"
        f"如果 .state.json 已存在 → 走增量更新（--action incremental）；"
        f"如果只有 .checkpoint.json（上次 full 未完成）→ 走 --action full --resume 续跑，"
        f"务必加 --resume 复用 checkpoint，不要重新开始；"
        f"如果两者都不存在 → 走 --action full 完整分析。"
    )


def schedule_kb_updates(
    repo_path: Path,
    *,
    interval_seconds: int = _DEFAULT_INTERVAL_SECONDS,
    bootstrap: bool | str = "auto",
    silent: bool = True,
    kb_path: Path | None = None,
) -> tuple[str, str | None]:
    """Register cron jobs that keep the KB for ``repo_path`` fresh.

    Returns ``(recurring_job_name, bootstrap_job_name | None)``.

    ``bootstrap`` controls the one-shot initial run:

    * ``True`` — always add it (analysis runs ~1 min after next agent start).
    * ``False`` — never add it (only register the recurring incremental).
    * ``"auto"`` (default) — skip when the KB is already built or an
      analysis is currently running. This makes repeated calls (every
      ``update.ps1`` runs ``init --quick`` which retriggers FRE)
      idempotent: the recurring incremental keeps the KB fresh and we
      don't burn LLM tokens kicking off redundant full runs.

    ``silent=True`` suppresses delivery to user channels (notify_channels
    set to ``[]``).

    ``repo_path`` does not need to exist on disk yet: the analyzer will
    clone it from the project registry's ``clone_url`` on first run.
    Existing-but-non-directory paths are still rejected.
    """
    repo_path = repo_path.resolve()
    if repo_path.exists() and not repo_path.is_dir():
        raise ValueError(f"repo_path is not a directory: {repo_path}")

    if bootstrap == "auto":
        bootstrap = not kb_already_initialized(repo_path, kb_path)
    elif not isinstance(bootstrap, bool):
        raise ValueError(f"bootstrap must be True, False, or 'auto'; got {bootstrap!r}")

    jobs = _load_jobs()
    recurring_name = _job_name(repo_path)
    # Bootstrap name is always computed so a previously-scheduled bootstrap
    # gets cleaned up even when this call decides not to add a new one.
    bootstrap_slot = _job_name(repo_path, "bootstrap")
    bootstrap_name = bootstrap_slot if bootstrap else None
    # Thread the *effective* kb path into the prompt so callers that pass a
    # custom kb_path don't get a prompt referencing the default location.
    effective_kb = (kb_path or _default_kb_path(repo_path)).resolve()
    prompt = _build_prompt(repo_path, effective_kb)
    notify = [] if silent else ["*"]
    now_iso = datetime.now(UTC).isoformat()

    # Drop any existing entries for this repo (recurring + stale bootstrap).
    keep = [j for j in jobs if j.get("name") not in {recurring_name, bootstrap_slot}]

    recurring_entry = {
        "name": recurring_name,
        "schedule": int(interval_seconds),
        "agent": "default",
        "prompt": prompt,
        "session_mode": "isolated",
        "notify_channels": notify,
        "enabled": True,
        "created_at": now_iso,
        "description": f"Repo-analysis KB refresh for {repo_path.name}",
    }
    keep.append(recurring_entry)

    if bootstrap_name:
        keep.append(
            {
                "name": bootstrap_name,
                "schedule": f"at:+{_BOOTSTRAP_DELAY_SECONDS}",
                "agent": "default",
                "prompt": prompt,
                "session_mode": "isolated",
                "notify_channels": notify,
                "enabled": True,
                "created_at": now_iso,
                "description": f"Repo-analysis KB initial run for {repo_path.name}",
            }
        )

    _save_jobs(keep)
    logger.info(
        "repo-analysis: scheduled KB updates for {} (interval={}s, bootstrap={}, silent={})",
        repo_path,
        interval_seconds,
        bootstrap,
        silent,
    )
    return recurring_name, bootstrap_name


def unschedule_kb_updates(repo_path: Path) -> list[str]:
    """Remove any repo-analysis cron jobs for ``repo_path``.

    Returns the list of removed job names.
    """
    repo_path = repo_path.resolve()
    targets = {_job_name(repo_path), _job_name(repo_path, "bootstrap")}
    jobs = _load_jobs()
    removed = [j["name"] for j in jobs if j.get("name") in targets]
    keep = [j for j in jobs if j.get("name") not in targets]
    if removed:
        _save_jobs(keep)
        logger.info("repo-analysis: removed cron jobs {}", removed)
    return removed
