"""
Enterprise audit logger — records all significant actions for compliance.

Every tool execution, channel message, and auth event is logged with
correlation IDs and automatic secret redaction. Writes to a daily-rotated
JSONL file under ~/.praestoclaw/audit/ (or a configured path).
"""

from __future__ import annotations

import json
import re
from collections.abc import Iterator
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger

from praestoclaw.config.schema import AuditConfig
from praestoclaw.security.leak import redact_credentials

_REDACT_KEYS = frozenset(
    {
        "password",
        "secret",
        "token",
        "key",
        "credential",
        "authorization",
        "apikey",
        "api_key",
        "pat",
        "api_secret",
        "client_secret",
        "app_password",
        "webhook_secret",
    }
)

_SECRET_PATTERNS = [
    re.compile(r"(eyJ[A-Za-z0-9_-]{10,}\.){1,2}[A-Za-z0-9_-]{10,}"),  # JWT
    re.compile(r"AKIA[0-9A-Z]{16}"),  # AWS
    re.compile(r"gh[pousr]_[A-Za-z0-9_]{36,}"),  # GitHub PAT/OAuth/user tokens
    re.compile(r"xox[bpors]-[A-Za-z0-9-]+"),  # Slack
    re.compile(r"sk-[A-Za-z0-9]{20,}"),  # OpenAI-style
]

_EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE)
_POSIX_HOME_RE = re.compile(r"(?P<prefix>/(?:Users|home)/)[^/\s]+")
_WINDOWS_HOME_RE = re.compile(r"(?P<prefix>[A-Z]:\\Users\\)[^\\\s]+", re.IGNORECASE)
_TEAMS_CONVERSATION_RE = re.compile(r"\b19:[^\s]+@thread\.(?:v2|skype)\b", re.IGNORECASE)
_UUID_RE = re.compile(
    r"\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b",
    re.IGNORECASE,
)
_MAX_DIAGNOSTIC_EVENTS = 200
_MAX_DIAGNOSTIC_CHARS = 32_000


def _redact_dict(obj: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for k, v in obj.items():
        if k.lower() in _REDACT_KEYS:
            result[k] = "[REDACTED]"
        elif isinstance(v, dict):
            result[k] = _redact_dict(v)
        elif isinstance(v, str):
            result[k] = _redact_string(v)
        else:
            result[k] = v
    return result


def _redact_string(value: str) -> str:
    # Preserve the audit log's historical generic marker for its existing
    # patterns, including token variants (for example ``ghu_`` / ``ghr_``)
    # that are not all part of the shared detector yet.  Then apply the broader
    # outbound detector for the remaining credential formats.
    for pattern in _SECRET_PATTERNS:
        value = pattern.sub("[REDACTED]", value)
    return redact_credentials(value)


def sanitize_diagnostic_text(value: str, *, max_chars: int = 1000) -> str:
    """Remove identities, host usernames and credentials from diagnostic text."""
    # Keep this aligned with the outbound leak detector rather than the audit
    # file's older, deliberately small compatibility pattern set.  Session
    # diagnostics may be attached to a public issue, so formats such as Azure
    # storage strings, private keys, Google/Stripe keys, and high-entropy hex
    # need the same coverage as every other outbound payload.
    value = redact_credentials(value)
    value = _EMAIL_RE.sub("[email]", value)
    value = _POSIX_HOME_RE.sub(r"\g<prefix>~", value)
    value = _WINDOWS_HOME_RE.sub(r"\g<prefix>~", value)
    value = _TEAMS_CONVERSATION_RE.sub("[conversation]", value)
    value = _UUID_RE.sub("[id]", value)
    value = " ".join(value.split())
    if len(value) > max_chars:
        return value[: max(0, max_chars - 1)] + "…"
    return value


class AuditLogger:
    """Structured audit logger with secret redaction and daily rotation.

    Writes to ``<dir>/<stem>-YYYY-MM-DD<suffix>`` (e.g. audit-2026-03-12.jsonl).
    A new file is created automatically each day — no external rotation needed.
    If the file cannot be written a WARNING is emitted on each failed attempt.
    """

    def __init__(self, config: AuditConfig | None = None) -> None:
        self._enabled = config.enabled if config else False
        self._redact = config.redact_secrets if config else True

        base = Path(
            config.log_file if config and config.log_file else "~/.praestoclaw/audit/audit.jsonl"
        ).expanduser()
        self._audit_dir = base.parent
        self._stem = base.stem
        self._suffix = base.suffix or ".jsonl"

        try:
            self._audit_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            logger.warning(f"Audit log directory unavailable ({self._audit_dir}): {exc}")

    def _daily_file(self) -> Path:
        date = datetime.now(UTC).strftime("%Y-%m-%d")
        return self._audit_dir / f"{self._stem}-{date}{self._suffix}"

    def _write(self, event: str, fields: dict[str, Any]) -> None:
        """Write a single audit entry. Adds timestamp, strips None values."""
        if not self._enabled:
            return
        entry: dict[str, Any] = {
            "ts": datetime.now(UTC).isoformat(),
            "event": event,
            **{k: v for k, v in fields.items() if v is not None},
        }
        if self._redact:
            entry = _redact_dict(entry)
        line = json.dumps(entry, default=str, ensure_ascii=False)
        path = self._daily_file()
        try:
            with path.open("a", encoding="utf-8") as f:
                f.write(line + "\n")
        except OSError as exc:
            logger.warning(f"Audit log write failed ({path}): {exc}")

    def log_tool(
        self,
        *,
        tool: str,
        actor: str,
        args: dict[str, Any],
        result: str,
        is_error: bool = False,
        session_id: str | None = None,
        conversation_session_id: str | None = None,
        duration_ms: float | None = None,
        tool_call_id: str | None = None,
    ) -> None:
        # Redact the complete result before truncating it.  Reversing this order
        # can cut a credential below a detector's minimum length and leave a
        # secret fragment in the audit JSONL.
        result_text = result or ""
        result_preview = (_redact_string(result_text) if self._redact else result_text)[:200]
        self._write(
            "tool:execute",
            {
                "tool": tool,
                "actor": actor,
                "args": args,
                "result_preview": result_preview,
                # Public feedback diagnostics must never depend on the raw
                # audit preview: truncating first can cut a credential below
                # the detector's minimum length.  Sanitize the complete error
                # before taking its bounded preview and render only this field.
                "diagnostic_error_preview": (
                    sanitize_diagnostic_text(result or "", max_chars=200) if is_error else None
                ),
                "is_error": is_error,
                "session_id": session_id,
                "conversation_session_id": conversation_session_id or session_id,
                "duration_ms": duration_ms,
                "tool_call_id": tool_call_id,
            },
        )

    def log_message(
        self,
        *,
        channel: str,
        direction: str,
        actor: str,
        session_id: str | None = None,
    ) -> None:
        self._write(
            f"channel:{direction}",
            {
                "channel": channel,
                "actor": actor,
                "session_id": session_id,
                "conversation_session_id": session_id,
            },
        )

    def log_auth(
        self,
        *,
        provider: str,
        actor: str,
        result: str,
    ) -> None:
        self._write(
            "auth:attempt",
            {
                "provider": provider,
                "actor": actor,
                "result": result,
            },
        )

    def log_security(
        self,
        *,
        event: str,
        details: dict[str, Any],
        severity: str = "warning",
    ) -> None:
        self._write(
            f"security:{event}",
            {
                "severity": severity,
                **details,
            },
        )

    def log_event(self, *, action: str, data: dict[str, Any]) -> None:
        """Log a generic workflow/lifecycle event."""
        self._write(action, data)

    def recent_entries(self, limit: int = 200) -> list[dict[str, Any]]:
        """Read the most recent *limit* audit entries across daily files."""
        import json
        from collections import deque

        entries: list[dict[str, Any]] = []
        if not self._audit_dir.is_dir():
            return entries

        # Daily files sorted newest first
        pattern = f"{self._stem}-*{self._suffix}"
        files = sorted(self._audit_dir.glob(pattern), reverse=True)

        remaining = limit
        for f in files:
            if remaining <= 0:
                break
            try:
                with open(f, encoding="utf-8") as fh:
                    tail = deque(fh, maxlen=remaining)
                for line in reversed(tail):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entries.append(json.loads(line))
                        remaining -= 1
                    except json.JSONDecodeError:
                        continue
            except Exception:  # noqa: BLE001, S112
                continue
        return entries

    @staticmethod
    def _reverse_lines(path: Path, *, chunk_size: int = 64 * 1024) -> Iterator[str]:
        """Yield UTF-8 file lines newest-first without loading a whole audit file."""
        with path.open("rb") as stream:
            stream.seek(0, 2)
            position = stream.tell()
            pending = b""
            while position > 0:
                read_size = min(chunk_size, position)
                position -= read_size
                stream.seek(position)
                pending = stream.read(read_size) + pending
                lines = pending.split(b"\n")
                pending = lines[0]
                for line in reversed(lines[1:]):
                    if line:
                        yield line.decode("utf-8", errors="replace")
            if pending:
                yield pending.decode("utf-8", errors="replace")

    def recent_session_entries(
        self, conversation_session_id: str, *, limit: int = _MAX_DIAGNOSTIC_EVENTS
    ) -> list[dict[str, Any]]:
        """Read only entries owned by one trusted conversation session.

        The selector is an exact match against top-level audit provenance. It
        never searches model-controlled arguments and therefore cannot be used
        to retrieve another conversation's diagnostics.
        """
        session_id = str(conversation_session_id or "").strip()
        if not self._enabled or not session_id or not self._audit_dir.is_dir():
            return []
        safe_limit = max(0, min(int(limit), _MAX_DIAGNOSTIC_EVENTS))
        if not safe_limit:
            return []

        entries: list[dict[str, Any]] = []
        pattern = f"{self._stem}-*{self._suffix}"
        for path in sorted(self._audit_dir.glob(pattern), reverse=True):
            try:
                for line in self._reverse_lines(path):
                    try:
                        entry = json.loads(line)
                    except (json.JSONDecodeError, TypeError):
                        continue
                    owner = entry.get("conversation_session_id") or entry.get("session_id")
                    if owner != session_id:
                        continue
                    entries.append(entry)
                    if len(entries) >= safe_limit:
                        return entries
            except OSError:
                continue
        return entries

    def recent_session_diagnostics(
        self,
        conversation_session_id: str,
        *,
        limit: int = _MAX_DIAGNOSTIC_EVENTS,
        max_chars: int = _MAX_DIAGNOSTIC_CHARS,
    ) -> str:
        """Render a bounded, identity-safe diagnostic timeline for one session."""
        char_limit = max(0, min(int(max_chars), _MAX_DIAGNOSTIC_CHARS))
        if not char_limit:
            return ""
        newest_first: list[str] = []
        used = 0
        omitted = False
        # Select newest-first so a tight character budget never drops the
        # failure closest to the feedback request. Reverse only for display.
        for entry in self.recent_session_entries(conversation_session_id, limit=limit):
            line = self._render_diagnostic_entry(entry)
            if not line:
                continue
            addition = len(line) + (1 if newest_first else 0)
            if used + addition > char_limit:
                omitted = True
                break
            newest_first.append(line)
            used += addition
        chronological = list(reversed(newest_first))
        if omitted:
            marker = "… older diagnostics omitted to fit limit …"
            marker_space = len(marker) + (1 if chronological else 0)
            while chronological and used + marker_space > char_limit:
                removed = chronological.pop(0)
                used -= len(removed) + (1 if chronological else 0)
            if len(marker) <= char_limit:
                chronological.insert(0, marker)
        return "\n".join(chronological)

    @staticmethod
    def _render_diagnostic_entry(entry: dict[str, Any]) -> str:
        event = str(entry.get("event") or "")
        ts = str(entry.get("ts") or "")
        time_text = ts[11:19] if len(ts) >= 19 else "--:--:--"
        duration = entry.get("duration_ms")
        duration_text = ""
        if isinstance(duration, (int, float)):
            duration_text = f" after {duration / 1000:.2f}s"

        if event == "channel:inbound":
            detail = "turn received"
        elif event == "channel:outbound":
            detail = "turn reply sent"
        elif event == "agent:turn_start":
            detail = "turn started"
        elif event == "agent:turn_end":
            status = sanitize_diagnostic_text(str(entry.get("status") or "completed"), max_chars=80)
            detail = f"turn {status}{duration_text}"
        elif event == "agent:turn_error":
            error = sanitize_diagnostic_text(str(entry.get("error") or "internal error"))
            detail = f"turn failed{duration_text}: {error}"
        elif event == "agent:provider":
            status = "failed" if entry.get("is_error") else "completed"
            model = sanitize_diagnostic_text(str(entry.get("model") or "unknown"), max_chars=120)
            detail = f"provider model={model} {status}{duration_text}"
            if entry.get("is_error"):
                error = sanitize_diagnostic_text(str(entry.get("error") or "provider error"))
                detail += f": {error}"
        elif event == "tool:execute":
            tool = sanitize_diagnostic_text(str(entry.get("tool") or "unknown"), max_chars=120)
            args = entry.get("args")
            raw_action = args.get("action") if isinstance(args, dict) else None
            action = (
                f" action={sanitize_diagnostic_text(str(raw_action), max_chars=80)}"
                if raw_action is not None
                else ""
            )
            status = "failed" if entry.get("is_error") else "succeeded"
            detail = f"tool {tool}{action} {status}{duration_text}"
            if entry.get("is_error"):
                # Older audit rows do not have the safe preview.  Do not fall
                # back to their raw, possibly pre-truncated result text.
                error = sanitize_diagnostic_text(
                    str(entry.get("diagnostic_error_preview") or "tool error")
                )
                detail += f": {error}"
        elif event in {"agent:hook_reject", "agent:approval"}:
            status = sanitize_diagnostic_text(str(entry.get("status") or "rejected"), max_chars=80)
            detail = f"{event.removeprefix('agent:').replace('_', ' ')}: {status}"
        elif event.startswith("security:"):
            detail = event.removeprefix("security:").replace("_", " ")
        else:
            return ""
        return f"{time_text} {detail}"
