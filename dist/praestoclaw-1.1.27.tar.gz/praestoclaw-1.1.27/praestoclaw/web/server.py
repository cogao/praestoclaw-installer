"""
WebServer — FastAPI-based HTTP web server for PraestoClaw.

Provides:
- / — status dashboard (auto-refresh every 5 s)
- /app/ — single-page webui (the Vite-built client_gui bundle)
- /chat  /chat.html — redirect to /app/ (legacy chat.html fallback)
- /health — basic health check (backward compat)
- /api/chat — send prompt, receive response (via bus)
- /api/chat/stream — SSE streaming response
- /api/ws — WebSocket bidirectional chat
- /api/sessions — session management
- /api/tools — tool discovery
- /api/health — detailed health check
- /api/status — comprehensive runtime status (polled by dashboard)
- /api/estop — E-stop trigger
- /api/reset — E-stop reset

FastAPI and uvicorn are imported at use time so the rest of
PraestoClaw can start without them installed.
"""

from __future__ import annotations

import asyncio
import json
import uuid
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger
from pydantic import BaseModel, Field

from praestoclaw import __version__
from praestoclaw.config.schema import ChannelType, WebServerConfig
from praestoclaw.utils.helpers import webchat_url_from_connect
from praestoclaw.web.auth import AuthMiddleware, is_loopback_host
from praestoclaw.web.estop_middleware import EStopMiddleware
from praestoclaw.web.middleware import RateLimiter, RequestLogger

if TYPE_CHECKING:
    from praestoclaw.channels.web import WebChannel
    from praestoclaw.runtime import Runtime

# FastAPI types needed at module level for annotation resolution
# (from __future__ import annotations defers evaluation, so get_type_hints()
# needs these in module globals).
try:
    from fastapi import Request, WebSocket
except ImportError:
    pass


class HealthResponse(BaseModel):
    """Basic health check response."""

    status: str = "ok"
    version: str = __version__


class ErrorResponse(BaseModel):
    """Standard error response body."""

    error: str
    message: str = ""


# ── New /api/* schemas ─────────────────────────────────────────────────────


class ChatRequest(BaseModel):
    """Request for /api/chat and /api/chat/stream."""

    prompt: str
    session_id: str | None = None


class ChatResponse(BaseModel):
    """Response from /api/chat."""

    response: str
    session_id: str


class ToolInfo(BaseModel):
    """Tool metadata for /api/tools."""

    name: str
    description: str
    risk_score: int | None = None
    tier: str = "core"
    active: bool = True
    type: str = "builtin"  # builtin | mcp_tool | mcp_server
    state: str | None = None  # MCP only: idle, connected, etc.
    tool_count: int | None = None  # MCP only


class HealthDetailResponse(BaseModel):
    """Detailed health for /api/health."""

    status: str
    version: str = __version__
    estop: dict[str, Any] = Field(default_factory=dict)
    bus: dict[str, Any] = Field(default_factory=dict)


class EStopRequest(BaseModel):
    """Request for /api/estop."""

    reason: str


class EStopResetRequest(BaseModel):
    """Request for /api/reset."""

    actor: str = "api"


# ── Web Server ─────────────────────────────────────────────────────────────


class WebServer:
    """
    FastAPI-based HTTP web server for PraestoClaw.

    Wraps the Runtime to expose an HTTP API with:
    - Legacy endpoint: /health
    - New API endpoints: /api/chat, /api/chat/stream, /api/ws,
      /api/sessions, /api/tools, /api/health, /api/estop, /api/reset
    """

    def __init__(
        self,
        config: WebServerConfig,
        runtime: Runtime,
        on_started: Callable[[int], None] | None = None,
    ) -> None:
        self._config = config
        self._runtime = runtime
        self._rate_limiter = RateLimiter(config.rate_limit_per_minute)
        self._web_channel: WebChannel | None = None
        self._server: Any = None  # uvicorn.Server instance
        self._on_started = on_started

        # Generate a temporary in-memory API key when no API key is configured
        # AND either: (a) Entra ID is not configured, or (b) cloud channel
        # fell back to the shared app (primary app blocked → MSAL popup won't
        # work either).  Passed to browser via URL fragment (#key=...).
        self.temp_key: str | None = None
        # Separate loopback-only browser bootstrap key. This lets the SPA opened
        # manually at /app/ authenticate without exposing a configured API key.
        self.browser_temp_key: str | None = None
        _entra_configured = bool(config.entra_tenant_id and config.entra_client_id)
        _cloud_fallback = False
        cloud_ch = (
            runtime.channel_manager.get("cloud") if hasattr(runtime, "channel_manager") else None
        )
        if cloud_ch and getattr(cloud_ch, "_using_shared_app", False):
            _cloud_fallback = True
        if config.api_key is None and (not _entra_configured or _cloud_fallback):
            import secrets

            self.temp_key = secrets.token_urlsafe(32)
            from pydantic import SecretStr

            config.api_key = SecretStr(self.temp_key)
            logger.info("Generated temporary API key (in-memory only)")
        elif config.api_key is not None or _entra_configured:
            import secrets

            self.browser_temp_key = secrets.token_urlsafe(32)
            logger.info("Generated loopback browser bootstrap key (in-memory only)")

        self._app = self._create_app()

    def set_web_channel(self, channel: WebChannel) -> None:
        """Inject the WebChannel after construction (called by Runtime)."""
        self._web_channel = channel

    # ── App factory ──────────────────────────────────────────────────────

    def _create_app(self) -> Any:  # noqa: C901
        """Build and return the FastAPI application."""
        try:
            from fastapi import FastAPI, WebSocketDisconnect
            from fastapi.middleware.cors import CORSMiddleware
            from fastapi.responses import (
                HTMLResponse,
                JSONResponse,
                RedirectResponse,
                Response,
                StreamingResponse,
            )
        except ImportError as exc:
            raise ImportError(
                "FastAPI is required for the web server. "
                "Install it with: pip install fastapi uvicorn"
            ) from exc

        app = FastAPI(
            title="PraestoClaw Web Server",
            version=__version__,
            docs_url=None,
            redoc_url=None,
        )

        # ── Middleware (outermost first) ─────────────────────────────────
        # FastAPI executes middleware in reverse add order:
        # Auth (innermost) → E-stop → RequestLogger → CORS (outermost)

        # CORS
        app.add_middleware(
            CORSMiddleware,
            allow_origins=self._config.cors_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        # Request logging
        app.add_middleware(RequestLogger)

        # E-stop gate (returns 503 for /api/* when halted)
        app.add_middleware(EStopMiddleware, estop=self._runtime.estop)

        # Auth (skips /health and /api/health)
        if self._config.api_key is None and not (
            self._config.entra_tenant_id and self._config.entra_client_id
        ):
            logger.warning(
                "Web server running WITHOUT authentication — set api_key or Entra ID "
                "in config to secure the API"
            )
        extra_api_keys = [self.browser_temp_key] if self.browser_temp_key else None
        app.add_middleware(AuthMiddleware, config=self._config, extra_api_keys=extra_api_keys)

        # ── Helper ───────────────────────────────────────────────────────

        def _get_client_ip(request: Request) -> str:
            return request.client.host if request.client else "unknown"

        def _check_rate_limit(request: Request) -> JSONResponse | None:
            """Return a 429 JSONResponse if rate-limited, else None."""
            if not self._rate_limiter.check(_get_client_ip(request)):
                return JSONResponse(
                    status_code=429,
                    content=ErrorResponse(
                        error="rate_limit_exceeded",
                        message="Too many requests. Please try again later.",
                    ).model_dump(),
                )
            return None

        def _is_loopback_request(request: Request) -> bool:
            """Return True when a public auth-helper request came from loopback."""
            client_host = request.client.host if request.client else ""
            return is_loopback_host(client_host)

        def _require_web_channel() -> JSONResponse | None:
            """Return a 503 JSONResponse if WebChannel is not available."""
            if self._web_channel is None:
                return JSONResponse(
                    status_code=503,
                    content=ErrorResponse(
                        error="service_unavailable",
                        message="Web channel not initialized.",
                    ).model_dump(),
                )
            return None

        async def _publish_http_webchat_turn(
            *,
            channel_id: str,
            sender_id: str,
            content: str,
            conversation_id: str | None = None,
            message_id: str | None = None,
        ) -> None:
            """Normalize HTTP/SSE webchat ingress through ChannelTurnKernel."""
            assert self._web_channel is not None
            from praestoclaw.channels.local_interactive import (
                LocalInteractiveAdapter,
                LocalInteractiveInbound,
                LocalInteractiveSurface,
            )
            from praestoclaw.host.agent_host import TurnCompletion

            effective_conversation_id = conversation_id or channel_id
            agent_session_key = f"{ChannelType.WEB}:{sender_id}:{effective_conversation_id}"
            adapter = LocalInteractiveAdapter(LocalInteractiveSurface.WEBCHAT)
            envelope = await adapter.ingest(
                LocalInteractiveInbound(
                    connection_id=channel_id,
                    conversation_id=effective_conversation_id,
                    message_id=message_id or uuid.uuid4().hex,
                    sender_id=sender_id,
                    content=content,
                    metadata={
                        "agent_session_key": agent_session_key,
                        "source": "web_http",
                    },
                    surface=LocalInteractiveSurface.WEBCHAT.value,
                )
            )
            await self._runtime.agent_host.submit_turn(
                envelope,
                completion=TurnCompletion.WEB_DELIVERY,
            )

        # ── Static files (JS libs, favicon) ──────────────────────────────
        _static = Path(__file__).parent / "static"
        # The Vite-built client_gui SPA ships inside the package at static/spa/
        # (built via `npm run build:spa` in apps/client_gui). Tracked here so it
        # travels in the wheel — end users install a pre-built package and have
        # no Node/source to build it themselves.
        _spa_dir = _static / "spa"
        _spa_mounted = False
        # Only treat the SPA as shipped when its entrypoint is actually present,
        # not merely the directory — a packaging mishap could leave an empty
        # static/spa/, and we must not redirect /chat → /app/ into a 404.
        _spa_index = _spa_dir / "index.html"
        try:
            from starlette.staticfiles import StaticFiles

            app.mount("/static", StaticFiles(directory=str(_static)), name="static")

            # Mount the SPA at /app with html=True so `/app/` serves index.html
            # and `/app` redirects to it; the bundle's relative asset base
            # resolves under `/app/assets/…`. API/WS calls are origin-rooted
            # (`/api/…`), so the mount path doesn't affect them.
            if _spa_index.is_file():
                app.mount("/app", StaticFiles(directory=str(_spa_dir), html=True), name="spa")
                _spa_mounted = True
        except ImportError:
            pass  # starlette.staticfiles not available — JS served via CDN fallback

        # ── Web UI ────────────────────────────────────────────────────────

        # Cache both pages at startup

        _portal_html: str | None = None
        _portal_path = _static / "portal.html"
        if _portal_path.exists():
            _portal_html = _portal_path.read_text(encoding="utf-8")

        _chat_html: str | None = None
        _chat_path = _static / "chat.html"
        if _chat_path.exists():
            _chat_html = _chat_path.read_text(encoding="utf-8")

        _favicon_svg: str | None = None
        _favicon_path = _static / "favicon.svg"
        if _favicon_path.exists():
            _favicon_svg = _favicon_path.read_text(encoding="utf-8")

        # Track server start time for uptime calculation
        _started_at: datetime = datetime.now(UTC)

        @app.get("/", response_class=HTMLResponse)
        async def ui_index() -> HTMLResponse:
            """Status dashboard — system overview at a glance."""
            if _portal_html is None:
                return HTMLResponse(
                    "<h1>PraestoClaw</h1><p>Status dashboard not found.</p>", status_code=404
                )
            return HTMLResponse(_portal_html)

        @app.get("/chat")
        @app.get("/chat.html")
        async def ui_chat() -> Response:
            """Chat UI — superseded by the single-page webui at /app/.

            Redirect there when the SPA bundle shipped in this build; fall back
            to the legacy static chat.html only if it didn't (gradual cutover).
            """
            if _spa_mounted:
                return RedirectResponse(url="/app/", status_code=307)
            if _chat_html is None:
                return HTMLResponse(
                    "<h1>PraestoClaw Chat</h1><p>Chat UI not found.</p>", status_code=404
                )
            return HTMLResponse(_chat_html)

        @app.get("/auth/spa-callback", response_class=HTMLResponse)
        async def spa_callback() -> HTMLResponse:
            """MSAL.js v5 popup redirect bridge — broadcasts auth response to parent window."""
            return HTMLResponse(
                "<!DOCTYPE html><html><head><title>Auth</title></head><body>"
                '<script src="/static/msal-redirect-bridge.min.js"></script>'
                "<script>msalRedirectBridge.broadcastResponseToMainFrame();</script>"
                "</body></html>",
                headers={"Cache-Control": "no-store"},
            )

        @app.get("/favicon.svg")
        async def favicon() -> Response:
            """Serve the PraestoClaw SVG favicon."""
            if _favicon_svg is None:
                return Response(status_code=404)
            return Response(
                content=_favicon_svg,
                media_type="image/svg+xml",
                headers={"Cache-Control": "public, max-age=86400"},
            )

        # ── Legacy routes (backward compat) ──────────────────────────────

        @app.get("/health", response_model=HealthResponse)
        async def health() -> HealthResponse:
            return HealthResponse()

        # ── New /api/* routes ────────────────────────────────────────────

        @app.get("/api/auth/config")
        async def auth_config(request: Request) -> JSONResponse:
            entra_tid = self._config.entra_tenant_id
            entra_cid = self._config.entra_client_id
            content: dict[str, Any] = {
                "entra_enabled": bool(entra_tid and entra_cid),
                "entra_tenant_id": entra_tid,
                "entra_client_id": entra_cid,
                "api_key_enabled": self._config.api_key is not None
                or (self.browser_temp_key is not None and _is_loopback_request(request)),
            }
            temporary_api_key = self.temp_key or self.browser_temp_key
            if temporary_api_key and _is_loopback_request(request):
                content["temporary_api_key"] = temporary_api_key
            return JSONResponse(content=content)

        # ── Azure CLI token bridge ───────────────────────────────────────
        # Returns an ARM-audience access_token from the local `az` CLI so
        # the browser-side webchat can skip the MSAL.js consent popup. Only
        # callable from loopback — exposing this endpoint to the network
        # would let any caller siphon ARM tokens from the host user.
        @app.get("/api/auth/azcli-token")
        async def auth_azcli_token(request: Request) -> JSONResponse:
            if not _is_loopback_request(request):
                return JSONResponse(
                    status_code=403,
                    content={"error": "loopback_only"},
                )
            try:
                from praestoclaw.auth.azure_cli import AzureCliProvider
            except ImportError:
                return JSONResponse(
                    status_code=503,
                    content={"error": "azure_cli_unavailable"},
                )

            tenant_id = self._config.entra_tenant_id or None
            provider = AzureCliProvider(
                resource="https://management.azure.com",
                tenant_id=tenant_id,
            )
            if not provider.has_cached_credentials():
                return JSONResponse(
                    status_code=401,
                    content={"error": "az_not_logged_in"},
                )
            import time as _time

            from praestoclaw.auth._telemetry import emit_auth_outcome

            _silent_start = _time.monotonic()
            _err: str | None = None
            try:
                token = await asyncio.to_thread(provider.try_silent)
            except Exception as exc:  # noqa: BLE001
                logger.debug("[azcli-token] silent acquire failed: {}", exc)
                _err = type(exc).__name__
                token = None
            emit_auth_outcome(
                provider=provider.name,
                mode="silent",
                success=bool(token),
                duration_ms=int((_time.monotonic() - _silent_start) * 1000),
                error_type=_err or (None if token else "no_token"),
            )
            if not token:
                return JSONResponse(
                    status_code=401,
                    content={"error": "az_token_unavailable"},
                )

            # Pull exp from the JWT body so the client can schedule refresh.
            import base64
            import json as _json

            exp = 0
            name = ""
            upn = ""
            try:
                payload = token.split(".")[1]
                payload += "=" * (-len(payload) % 4)
                claims = _json.loads(base64.urlsafe_b64decode(payload).decode("utf-8"))
                exp = int(claims.get("exp", 0))
                name = str(claims.get("name") or "")
                upn = str(claims.get("upn") or claims.get("preferred_username") or "")
            except Exception:
                pass

            return JSONResponse(
                content={
                    "token": token,
                    "exp": exp,
                    "name": name,
                    "upn": upn,
                }
            )

        # ── Device code flow (no redirect URI needed) ────────────────────
        # Stores pending device code flows keyed by user_code
        _device_flows: dict[str, Any] = {}
        _device_msal_apps: dict[str, Any] = {}

        @app.post("/api/auth/device-code")
        async def device_code_start() -> JSONResponse:
            entra_tid = self._config.entra_tenant_id
            entra_cid = self._config.entra_client_id
            if not entra_tid or not entra_cid:
                return JSONResponse(
                    status_code=400,
                    content={
                        "error": "entra_not_configured",
                        "message": "Entra ID is not configured on this server.",
                    },
                )

            try:
                import msal as _msal

                app = _msal.PublicClientApplication(
                    client_id=entra_cid,
                    authority=f"https://login.microsoftonline.com/{entra_tid}",
                )
                flow = app.initiate_device_flow(scopes=[f"{entra_cid}/.default"])
                if "user_code" not in flow:
                    return JSONResponse(
                        status_code=500,
                        content={
                            "error": "device_flow_failed",
                            "message": flow.get(
                                "error_description", "Failed to initiate device code flow"
                            ),
                        },
                    )

                user_code = flow["user_code"]
                _device_flows[user_code] = flow
                _device_msal_apps[user_code] = app

                return JSONResponse(
                    content={
                        "user_code": user_code,
                        "verification_uri": flow.get(
                            "verification_uri", "https://microsoft.com/devicelogin"
                        ),
                        "expires_in": flow.get("expires_in", 900),
                        "message": flow.get("message", ""),
                    }
                )
            except ImportError:
                return JSONResponse(
                    status_code=500,
                    content={
                        "error": "msal_not_installed",
                        "message": "MSAL library is not installed on the server.",
                    },
                )
            except Exception as exc:
                logger.error(f"Device code initiation error: {exc}")
                return JSONResponse(
                    status_code=500,
                    content={
                        "error": "internal_error",
                        "message": "Failed to start device code flow.",
                    },
                )

        @app.post("/api/auth/device-code/poll")
        async def device_code_poll(request: Request) -> JSONResponse:
            body = await request.json()
            user_code = body.get("user_code", "")

            flow = _device_flows.get(user_code)
            msal_app = _device_msal_apps.get(user_code)
            if not flow or not msal_app:
                return JSONResponse(
                    status_code=404,
                    content={
                        "error": "flow_not_found",
                        "message": "No pending device code flow for this code.",
                    },
                )

            try:
                result = await asyncio.to_thread(
                    msal_app.acquire_token_by_device_flow,
                    flow,
                    exit_condition=lambda flow: True,  # Return immediately after one poll
                )

                token = result.get("id_token") or result.get("access_token")
                if token:
                    # Success — clean up
                    _device_flows.pop(user_code, None)
                    _device_msal_apps.pop(user_code, None)
                    # Persist user identity to USER.md (offloaded to thread — sync I/O)
                    from praestoclaw.utils.identity import save_identity

                    await asyncio.to_thread(
                        save_identity,
                        result.get("id_token_claims", {}),
                        self._runtime.workspace,
                        self._runtime.config.agents.default.user_file,
                    )
                    return JSONResponse(
                        content={
                            "status": "complete",
                            "access_token": token,
                            "account": {
                                "name": result.get("id_token_claims", {}).get("name", ""),
                                "username": result.get("id_token_claims", {}).get(
                                    "preferred_username", ""
                                ),
                            },
                        }
                    )
                elif result.get("error") == "authorization_pending":
                    return JSONResponse(content={"status": "pending"})
                else:
                    # Error — clean up
                    _device_flows.pop(user_code, None)
                    _device_msal_apps.pop(user_code, None)
                    return JSONResponse(
                        status_code=400,
                        content={
                            "status": "error",
                            "error": result.get("error", "unknown"),
                            "message": result.get("error_description", "Authentication failed."),
                        },
                    )
            except Exception as exc:
                logger.error(f"Device code poll error: {exc}")
                return JSONResponse(content={"status": "pending"})

        @app.get("/api/health")
        async def api_health() -> JSONResponse:
            from praestoclaw.web.api_handlers import handle_health

            return JSONResponse(content=handle_health(self._runtime))

        # ── Cron HTTP API (Phase 2 — BACK-05/06/07/08) ──────────────────
        # All /api/cron/* paths are intentionally NOT in
        # AuthMiddleware._PUBLIC_PATHS — the existing middleware therefore
        # rejects unauthenticated requests with 401 by default. See
        # tests/web/test_cron_routes.py::test_no_cron_path_in_public_paths
        # for the contract assertion.

        @app.post("/api/cron/preview")
        async def api_cron_preview(request: Request) -> JSONResponse:
            from praestoclaw.web.api_handlers import handle_cron_preview

            try:
                payload = await request.json()
            except Exception:
                payload = {}
            status, body = handle_cron_preview(self._runtime, payload)
            return JSONResponse(content=body, status_code=status)

        @app.get("/api/cron/jobs")
        async def api_cron_list() -> JSONResponse:
            from praestoclaw.web.api_handlers import handle_cron_list

            status, body = handle_cron_list(self._runtime)
            return JSONResponse(content=body, status_code=status)

        @app.post("/api/cron/jobs")
        async def api_cron_create(request: Request) -> JSONResponse:
            from praestoclaw.web.api_handlers import handle_cron_create

            try:
                payload = await request.json()
            except Exception:
                payload = {}
            status, body = handle_cron_create(self._runtime, payload)
            return JSONResponse(content=body, status_code=status)

        @app.put("/api/cron/jobs/{name}")
        async def api_cron_update(name: str, request: Request) -> JSONResponse:
            from praestoclaw.web.api_handlers import handle_cron_update

            try:
                payload = await request.json()
            except Exception:
                payload = {}
            status, body = handle_cron_update(self._runtime, name, payload)
            return JSONResponse(content=body, status_code=status)

        @app.delete("/api/cron/jobs/{name}")
        async def api_cron_delete(name: str) -> JSONResponse:
            from praestoclaw.web.api_handlers import handle_cron_delete

            status, body = handle_cron_delete(self._runtime, name)
            return JSONResponse(content=body, status_code=status)

        @app.post("/api/cron/jobs/{name}/enable")
        async def api_cron_enable(name: str) -> JSONResponse:
            from praestoclaw.web.api_handlers import handle_cron_enable

            status, body = handle_cron_enable(self._runtime, name)
            return JSONResponse(content=body, status_code=status)

        @app.post("/api/cron/jobs/{name}/disable")
        async def api_cron_disable(name: str) -> JSONResponse:
            from praestoclaw.web.api_handlers import handle_cron_disable

            status, body = handle_cron_disable(self._runtime, name)
            return JSONResponse(content=body, status_code=status)

        @app.post("/api/cron/jobs/{name}/run")
        async def api_cron_run(name: str) -> JSONResponse:
            from praestoclaw.web.api_handlers import handle_cron_run

            status, body = await handle_cron_run(self._runtime, name)
            return JSONResponse(content=body, status_code=status)

        # ── First-Run Experience (FRE) ──────────────────────────────────
        # The wizard fans out long tasks to background threads (see
        # ``praestoclaw.cli.init_async``) and records progress in
        # ``~/.praestoclaw/.fre-state.json``. The Portal polls this
        # endpoint to render a small status bar on the welcome screen.
        @app.get("/api/fre/state")
        async def api_fre_state() -> JSONResponse:
            from praestoclaw.defaults.starter_prompts import get_starter_prompts
            from praestoclaw.utils.fre_state import (
                load_fre_state,
                mark_stale_pending_as_failed,
            )

            # Garbage-collect orphaned workers (daemon threads from a
            # ``pc init`` that exited before finishing) so the user sees
            # a Retry button instead of a permanent "running" spinner.
            # Idempotent and cheap (~one disk RMW max once per ~2 s poll).
            mark_stale_pending_as_failed()
            state = load_fre_state()
            # Strip the user's tenant_id from the public response — the
            # Portal only needs first_name / display_name to greet the
            # user. tenant_id and oid stay server-side.
            user = dict(state.get("user") or {})
            for sensitive in ("oid", "tenant_id"):
                user.pop(sensitive, None)
            return JSONResponse(
                content={
                    "schema_version": state.get("schema_version", 1),
                    "user": user,
                    "pending": state.get("pending") or {},
                    "completed": state.get("completed") or {},
                    "starter_prompts": get_starter_prompts("web"),
                }
            )

        @app.post("/api/fre/retry/{key}")
        async def api_fre_retry(key: str) -> JSONResponse:
            """Re-fire a failed pending task. Idempotent."""
            # Map the public key onto a fan-out function. We *don't*
            # accept arbitrary keys to avoid the endpoint becoming a
            # generic "run anything" surface.
            from praestoclaw.cli import init_async
            from praestoclaw.utils.fre_state import (
                PENDING_MARKETPLACE,
                PENDING_MCP_SILENT,
                PENDING_TEAMS_SIDELOAD,
                get_subscribed_projects,
            )

            def _retry_marketplace() -> None:
                """Re-fire marketplace install using the user's current project + role subscriptions."""
                from praestoclaw.projects import resolve_assets
                from praestoclaw.skills.marketplace import BUILTIN_MARKETPLACES
                from praestoclaw.utils.fre_state import get_user_role

                known = {m.id for m in BUILTIN_MARKETPLACES}
                assets = resolve_assets(get_subscribed_projects(), role=get_user_role())
                ids = [mid for mid in assets.marketplaces if mid in known]
                if ids:
                    init_async.fire_marketplace_install(ids)

            handlers = {
                PENDING_TEAMS_SIDELOAD: init_async.fire_teams_sideload,
                # Retry MCP warm-up against the shared Entra app — that's
                # the canonical one. Specific server client_ids are not
                # exposed via this endpoint to keep the API surface thin.
                PENDING_MCP_SILENT: lambda: init_async.fire_mcp_silent_acquire(
                    [
                        __import__(
                            "praestoclaw.mcp.defaults", fromlist=["SHARED_ENTRA_CLIENT_ID"]
                        ).SHARED_ENTRA_CLIENT_ID
                    ]
                ),
                PENDING_MARKETPLACE: _retry_marketplace,
            }
            fn = handlers.get(key)
            if fn is None:
                return JSONResponse(
                    status_code=400,
                    content={"error": f"unknown FRE task '{key}'", "known": sorted(handlers)},
                )
            fn()
            return JSONResponse(content={"status": "queued", "key": key})

        @app.get("/api/status")
        async def api_status() -> JSONResponse:
            """Comprehensive runtime snapshot — polled by the status dashboard."""
            from praestoclaw.web.api_handlers import handle_status

            rt = self._runtime
            uptime = int((datetime.now(UTC) - _started_at).total_seconds())

            # Build channel list (web server-specific — tracks live connections)
            _cloud_chan = rt.channel_manager.get(ChannelType.CLOUD)
            cloud_connected = getattr(_cloud_chan, "is_connected", False)
            cloud_cfg = rt.config.channels.cloud

            def _channel_entries(name: str) -> list[dict]:
                if name == ChannelType.CLOUD:
                    return []
                if name in (ChannelType.WEB, "gateway"):
                    return [{"name": name, "url": "/chat", "connected": True}]
                return [{"name": name, "url": None, "connected": True}]

            channels = [e for n in rt.channel_manager._channels for e in _channel_entries(n)]
            if cloud_cfg.enabled and cloud_cfg.url:
                try:
                    wc_url: str | None = webchat_url_from_connect(cloud_cfg.url)
                except ValueError:
                    wc_url = None
                channels.append(
                    {"name": "Web Chat (Cloud)", "url": wc_url, "connected": cloud_connected}
                )
                teams_url = cloud_cfg.teams_bot_url or None
                channels.append(
                    {
                        "name": "Teams (Cloud)",
                        "url": teams_url,
                        "connected": cloud_connected and bool(teams_url),
                    }
                )

            try:
                session_count = (await rt.session_store.stats())["session_count"]
            except Exception:
                session_count = 0
            status = handle_status(
                rt,
                uptime_seconds=uptime,
                started_at=_started_at.isoformat(),
                channels=channels,
                session_count=session_count,
            )
            return JSONResponse(status)

        @app.post("/api/chat", response_model=ChatResponse)
        async def api_chat(body: ChatRequest, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            channel_check = _require_web_channel()
            if channel_check:
                return channel_check

            assert self._web_channel is not None  # guarded above
            channel_id = self._web_channel.make_channel_id("web-req")
            sender_id = "api-user"
            timeout = self._config.request_timeout

            try:
                response_queue = self._web_channel.register_request(channel_id)
                try:
                    await _publish_http_webchat_turn(
                        channel_id=channel_id,
                        sender_id=sender_id,
                        content=body.prompt,
                        conversation_id=body.session_id or channel_id,
                    )
                    result = await asyncio.wait_for(response_queue.get(), timeout=timeout)
                    if result is None:
                        raise TimeoutError("Channel shutting down")
                    response_text = result
                finally:
                    self._web_channel.unregister_request(channel_id)
            except TimeoutError:
                return JSONResponse(
                    status_code=504,
                    content=ErrorResponse(
                        error="timeout",
                        message=f"Agent did not respond within {timeout} seconds.",
                    ).model_dump(),
                )
            except Exception as exc:
                logger.error(f"API chat error: {exc}")
                return JSONResponse(
                    status_code=500,
                    content=ErrorResponse(
                        error="internal_error",
                        message="An internal error occurred while processing the request.",
                    ).model_dump(),
                )

            session_id = body.session_id
            if not session_id:
                session_id = await self._runtime.session_store.get_or_create_session(
                    str(ChannelType.WEB), sender_id
                )
            return JSONResponse(
                content=ChatResponse(
                    response=response_text,
                    session_id=session_id,
                ).model_dump(),
            )

        @app.post("/api/chat/stream")
        async def api_chat_stream(
            body: ChatRequest, request: Request
        ) -> StreamingResponse | JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            channel_check = _require_web_channel()
            if channel_check:
                return channel_check

            assert self._web_channel is not None
            channel_id = self._web_channel.make_channel_id("web-sse")
            sender_id = "api-user"
            timeout = self._config.request_timeout

            # Register response queue — SSE yields the final response as events
            response_queue = self._web_channel.register_request(channel_id)

            try:
                await _publish_http_webchat_turn(
                    channel_id=channel_id,
                    sender_id=sender_id,
                    content=body.prompt,
                    conversation_id=body.session_id or channel_id,
                )
            except asyncio.CancelledError:
                self._web_channel.unregister_request(channel_id)
                raise
            except Exception:
                self._web_channel.unregister_request(channel_id)
                logger.exception("SSE publish error")
                return JSONResponse(
                    status_code=500,
                    content=ErrorResponse(
                        error="internal_error",
                        message="An internal error occurred while processing the request.",
                    ).model_dump(),
                )
            except BaseException:
                self._web_channel.unregister_request(channel_id)
                raise

            async def event_generator():
                try:
                    result = await asyncio.wait_for(response_queue.get(), timeout=timeout)
                    if result is not None:
                        yield f"event: message\ndata: {json.dumps({'content': result, 'done': False}, ensure_ascii=False)}\n\n"
                    yield f"event: done\ndata: {json.dumps({'done': True})}\n\n"
                except TimeoutError:
                    yield f"event: error\ndata: {json.dumps({'error': 'timeout'})}\n\n"
                except Exception as exc:
                    logger.error(f"SSE stream error: {exc}")
                    yield f"event: error\ndata: {json.dumps({'error': 'internal_error'})}\n\n"
                finally:
                    self._web_channel.unregister_request(channel_id)  # type: ignore[union-attr]

            return StreamingResponse(
                event_generator(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",
                },
            )

        @app.websocket("/api/ws")
        async def websocket_endpoint(websocket: WebSocket) -> None:
            await websocket.accept()

            # Save user identity from Entra JWT (injected by AuthMiddleware).
            # Fire-and-forget background task — sync I/O offloaded to thread.
            user_claims: dict = websocket.scope.get("user_claims", {})
            if user_claims:
                from praestoclaw.utils.identity import save_identity

                asyncio.create_task(
                    asyncio.to_thread(
                        save_identity,
                        user_claims,
                        self._runtime.workspace,
                        self._runtime.config.agents.default.user_file,
                    )
                )

            from praestoclaw.channels.local_interactive import (
                LocalInteractiveAdapter,
                LocalInteractiveInbound,
                LocalInteractiveSurface,
            )
            from praestoclaw.host.agent_host import TurnCompletion

            channel_id = f"local-webchat-{uuid.uuid4().hex[:12]}"
            adapter = LocalInteractiveAdapter(LocalInteractiveSurface.WEBCHAT)
            # Register a push queue so unsolicited messages (scheduler notify,
            # a2a inbound notify, a2a reply notify) reach this WebSocket client.
            assert self._web_channel is not None
            push_queue = self._web_channel.register_push(channel_id)

            async def _push_forwarder() -> None:
                """Forward push-channel messages to this WebSocket as kind=push."""
                while True:
                    msg = await push_queue.get()
                    if msg is None:
                        break
                    try:
                        await websocket.send_json({"response": msg, "kind": "push"})
                    except Exception:
                        logger.debug(f"WebSocket push forward failed: {channel_id}")
                        break

            push_task = asyncio.create_task(_push_forwarder())

            def _trusted_sender_id(client_sender_id: object) -> str:
                if user_claims:
                    for key in ("oid", "sub", "preferred_username", "upn", "email", "name"):
                        value = user_claims.get(key)
                        if isinstance(value, str) and value.strip():
                            return value.strip()
                    return "authenticated-websocket-user"
                return str(client_sender_id or "ws-user")

            def _resolve_approval(prompt: str, sender_id: str) -> bool:
                """If prompt is an approval response, resolve it and return True."""
                if not self._runtime.approval_manager:
                    return False
                mgr = self._runtime.approval_manager
                pending_list = mgr.get_pending()
                cl = prompt.strip().lower()
                action: str | None = None
                req_id: str | None = None
                if len(pending_list) == 1 and cl in (
                    "yes",
                    "y",
                    "approve",
                    "/approve",
                    "no",
                    "n",
                    "deny",
                    "/deny",
                    "always",
                    "a",
                    "/always",
                ):
                    sole = pending_list[0]
                    if cl in ("yes", "y", "approve", "/approve"):
                        action, req_id = "approve", sole.id
                    elif cl in ("no", "n", "deny", "/deny"):
                        action, req_id = "deny", sole.id
                    else:
                        action, req_id = "always", sole.id
                elif prompt.startswith("/approve "):
                    action, req_id = "approve", prompt.split(maxsplit=1)[1]
                elif prompt.startswith("/deny "):
                    action, req_id = "deny", prompt.split(maxsplit=1)[1]
                elif prompt.startswith("/always "):
                    action, req_id = "always", prompt.split(maxsplit=1)[1]

                if action and req_id:
                    from praestoclaw.bus.events import EventType

                    self._runtime.bus.events.emit(
                        EventType.APPROVAL_RESOLVED,
                        {"request_id": req_id, "action": action, "resolver": sender_id},
                    )
                    return True
                return False

            try:
                while True:
                    data = await websocket.receive_json()
                    prompt = data.get("prompt", "")
                    sender_id = _trusted_sender_id(data.get("sender_id", "ws-user"))

                    if not prompt:
                        await websocket.send_json({"error": "prompt is required"})
                        continue

                    # Approval fast-path: resolve directly via bus event so the
                    # sequential legacy tool loop is not deadlocked during cutover.
                    if _resolve_approval(prompt, sender_id):
                        status_word = (
                            "approved"
                            if prompt.strip().lower() not in ("no", "n", "deny", "/deny")
                            else "denied"
                        )
                        await websocket.send_json({"response": f"Tool call {status_word}."})
                        continue

                    # ``/task <action> <task_id> [reason]`` → forward to the
                    # cloud channel as a ``task.control`` request so the
                    # human can approve / deny / cancel from chat without
                    # going through the LLM.
                    task_ack = await self._maybe_handle_task_control(prompt)
                    if task_ack is not None:
                        await websocket.send_json({"response": task_ack})
                        continue

                    conversation_id = "local-webchat-default"
                    agent_session_key = f"{adapter.logical_channel}:{sender_id}:{conversation_id}"
                    envelope = await adapter.ingest(
                        LocalInteractiveInbound(
                            connection_id=channel_id,
                            conversation_id=conversation_id,
                            message_id=str(data.get("message_id") or uuid.uuid4().hex),
                            sender_id=sender_id,
                            content=prompt,
                            metadata={
                                "agent_session_key": agent_session_key,
                                "supports_streaming": False,
                            },
                            surface=LocalInteractiveSurface.WEBCHAT.value,
                        )
                    )
                    session_key = str(
                        envelope.metadata.get("agent_session_key")
                        or f"{envelope.logical_channel}:{envelope.sender_id}:"
                        f"{envelope.conversation_id}"
                    )
                    await self._runtime.session_store.ensure_session(
                        session_key,
                        envelope.logical_channel,
                        envelope.sender_id,
                    )
                    self._web_channel.alias_push(session_key, channel_id)
                    response_queue = self._web_channel.register_request(channel_id)
                    try:
                        result = await self._runtime.agent_host.submit_turn(
                            envelope,
                            completion=TurnCompletion.WEB_DELIVERY,
                        )
                        if result.admission.synthetic_reply is not None:
                            await websocket.send_json(
                                {"response": str(result.admission.synthetic_reply)}
                            )
                            continue
                        response = await asyncio.wait_for(
                            response_queue.get(),
                            timeout=self._config.request_timeout,
                        )
                    except TimeoutError:
                        await websocket.send_json(
                            {
                                "error": (
                                    "Agent did not respond within "
                                    f"{self._config.request_timeout} seconds."
                                ),
                                "kind": "error",
                            }
                        )
                        continue
                    finally:
                        self._web_channel.unregister_request(channel_id)

                    if response is not None:
                        await websocket.send_json({"response": response})
                    else:
                        await websocket.send_json(
                            {"error": "Channel shutting down", "kind": "error"}
                        )
            except WebSocketDisconnect:
                logger.debug(f"WebSocket disconnected: {channel_id}")
            except Exception as exc:
                logger.error(f"WebSocket error: {exc}")
            finally:
                self._web_channel.unregister_push(channel_id)
                push_task.cancel()
                try:
                    await push_task
                except (asyncio.CancelledError, Exception):
                    pass

        @app.get("/api/sessions")
        async def list_sessions(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_sessions

            raw_limit = request.query_params.get("limit")
            limit: int | None = 200
            if raw_limit is not None:
                try:
                    parsed_limit = int(raw_limit)
                except ValueError:
                    parsed_limit = 200
                limit = None if parsed_limit <= 0 else max(1, min(parsed_limit, 1000))
            sessions = await handle_sessions(self._runtime, limit=limit)
            return JSONResponse(content=sessions)

        @app.get("/api/sessions/{session_id:path}")
        async def get_session(session_id: str, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_session_detail

            result = await handle_session_detail(self._runtime, session_id)
            if result is None:
                return JSONResponse(
                    status_code=404,
                    content=ErrorResponse(
                        error="not_found",
                        message=f"Session not found: {session_id}",
                    ).model_dump(),
                )
            return JSONResponse(content=result)

        @app.delete("/api/sessions/{session_id:path}")
        async def delete_session(session_id: str, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            await self._runtime.session_store.delete_session(session_id)
            return JSONResponse(content={"status": "deleted", "session_id": session_id})

        @app.get("/api/session/recent")
        async def api_session_recent(
            request: Request,
            channel: str = "web",
            sender_id: str = "ws-user",
            limit: int = 10,
        ) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_session_recent

            recent = await handle_session_recent(
                self._runtime, channel=channel, sender_id=sender_id, limit=limit
            )
            return JSONResponse(content=recent)

        @app.get("/api/tools")
        async def list_tools(request: Request, limit: int = 1000) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_tools

            clamped = max(1, min(limit, 1000))
            return JSONResponse(content=handle_tools(self._runtime)[:clamped])

        @app.get("/api/skills")
        async def list_skills(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_skills

            return JSONResponse(content=handle_skills(self._runtime))

        @app.get("/api/marketplace/sources")
        async def marketplace_sources(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_marketplace_sources

            return JSONResponse(content=handle_marketplace_sources(self._runtime))

        @app.get("/api/marketplace/skills")
        async def marketplace_skills(request: Request, source: str | None = None) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_marketplace_skills

            return JSONResponse(content=handle_marketplace_skills(self._runtime, source_id=source))

        @app.post("/api/marketplace/install")
        async def marketplace_install(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            body = await request.json()
            name = body.get("name", "")
            source = body.get("source", "")
            if not name or not source:
                return JSONResponse(
                    status_code=400,
                    content={"error": "name and source are required."},
                )
            from praestoclaw.web.api_handlers import handle_marketplace_install

            code, result = handle_marketplace_install(self._runtime, name, source)
            return JSONResponse(status_code=code, content=result)

        @app.post("/api/marketplace/uninstall")
        async def marketplace_uninstall(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            body = await request.json()
            name = body.get("name", "")
            if not name:
                return JSONResponse(
                    status_code=400,
                    content={"error": "name is required."},
                )
            from praestoclaw.web.api_handlers import handle_marketplace_uninstall

            code, result = handle_marketplace_uninstall(self._runtime, name)
            return JSONResponse(status_code=code, content=result)

        @app.post("/api/skills/disable")
        async def skill_disable(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            body = await request.json()
            name = body.get("name", "")
            if not name:
                return JSONResponse(
                    status_code=400,
                    content={"error": "name is required."},
                )
            from praestoclaw.web.api_handlers import handle_skill_disable

            code, result = handle_skill_disable(self._runtime, name)
            return JSONResponse(status_code=code, content=result)

        @app.post("/api/skills/enable")
        async def skill_enable(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            body = await request.json()
            name = body.get("name", "")
            if not name:
                return JSONResponse(
                    status_code=400,
                    content={"error": "name is required."},
                )
            from praestoclaw.web.api_handlers import handle_skill_enable

            code, result = handle_skill_enable(self._runtime, name)
            return JSONResponse(status_code=code, content=result)

        @app.get("/api/skills/content")
        async def skill_content_get(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            name = request.query_params.get("name", "")
            if not name:
                return JSONResponse(status_code=400, content={"error": "name is required."})
            from praestoclaw.web.api_handlers import handle_skill_content_get

            code, result = handle_skill_content_get(self._runtime, name)
            return JSONResponse(status_code=code, content=result)

        @app.put("/api/skills/content")
        async def skill_content_put(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            try:
                body = await request.json()
            except Exception:
                body = {}
            name = (body or {}).get("name", "")
            content = (body or {}).get("content")
            if not name or content is None:
                return JSONResponse(
                    status_code=400,
                    content={"error": "name and content are required."},
                )
            from praestoclaw.web.api_handlers import handle_skill_content_put

            code, result = handle_skill_content_put(self._runtime, name, content)
            return JSONResponse(status_code=code, content=result)

        @app.get("/api/skills/import/scan")
        async def skills_import_scan(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_local_skills_scan

            return JSONResponse(content=handle_local_skills_scan(self._runtime))

        @app.post("/api/skills/import")
        async def skills_import(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            try:
                body = await request.json()
            except Exception:
                body = {}
            from praestoclaw.web.api_handlers import handle_local_skills_import

            code, result = handle_local_skills_import(self._runtime, body or {})
            return JSONResponse(status_code=code, content=result)

        @app.get("/api/models")
        async def list_models(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_models

            return JSONResponse(content=handle_models(self._runtime))

        @app.get("/api/memory")
        async def api_memory(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_memory

            return JSONResponse(content=handle_memory(self._runtime))

        @app.get("/api/audit")
        async def api_audit(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_audit

            return JSONResponse(content=handle_audit(self._runtime))

        @app.get("/api/cost")
        async def api_cost(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_cost

            return JSONResponse(content=handle_cost(self._runtime))

        @app.get("/api/system-prompts")
        async def api_system_prompts(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_system_prompts

            return JSONResponse(content=handle_system_prompts(self._runtime))

        @app.get("/api/config")
        async def api_config(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_config

            result = handle_config(self._runtime)
            if result is None:
                return JSONResponse(
                    status_code=500, content={"error": "Failed to serialize config."}
                )
            return JSONResponse(content=result)

        @app.get("/api/approvals")
        async def api_approvals(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_approvals

            return JSONResponse(content=handle_approvals(self._runtime))

        @app.post("/api/approvals/{request_id}/resolve")
        async def api_resolve_approval(request_id: str, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_approval_resolve_async

            try:
                body = await request.json()
            except Exception:
                return JSONResponse(status_code=400, content={"error": "Invalid JSON body."})

            approved = body.get("approved", False)
            resolver = body.get("resolver", "web-user")
            code, result = await handle_approval_resolve_async(
                self._runtime,
                request_id,
                approved,
                resolver,
                always=body.get("always", False),
            )
            return JSONResponse(status_code=code, content=result)

        @app.post("/api/estop")
        async def trigger_estop(body: EStopRequest, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_estop

            return JSONResponse(content=handle_estop(self._runtime, body.reason))

        @app.post("/api/reset")
        async def reset_estop(body: EStopResetRequest, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from praestoclaw.web.api_handlers import handle_reset

            return JSONResponse(content=handle_reset(self._runtime, body.actor))

        return app

    # ── Lifecycle ────────────────────────────────────────────────────────

    async def _notify_when_started(self) -> None:
        """Wait until uvicorn is listening, then fire the on_started callback.

        Passes the *actual* bound port (from the server socket) so callers
        receive the correct port even when port=0 was configured (ephemeral).
        Exceptions from the callback are logged as warnings and swallowed so
        a pid-file write failure never takes down the web server.
        """
        while self._server is not None and not self._server.started:
            await asyncio.sleep(0.05)
        # Exit without calling the callback if stop() cleared the server
        # reference before uvicorn finished binding (rapid shutdown).
        if self._server is None or not self._server.started:
            return
        if self._on_started is None:
            return
        # Read the actual bound port from the first server socket.
        try:
            actual_port: int = self._server.servers[0].sockets[0].getsockname()[1]
        except Exception:
            actual_port = self._config.port  # fallback to configured value
        try:
            self._on_started(actual_port)
        except Exception:
            logger.warning(
                "Exception in on_started callback during web server startup", exc_info=True
            )

    @staticmethod
    def _install_access_log_filter() -> None:
        """Route all uvicorn loggers through loguru and redact JWT tokens.

        Replaces uvicorn's default StreamHandlers with an InterceptHandler that
        forwards records to loguru (unified format + token redaction).

        Must be called AFTER uvicorn's configure_logging() (i.e. from a FastAPI
        startup event) so uvicorn's handlers exist before we replace them.
        """
        import logging
        import re

        _TOKEN_RE = re.compile(r"(token=)[A-Za-z0-9._\-+/]+=*")

        class _RedactToken(logging.Filter):
            def filter(self, record: logging.LogRecord) -> bool:
                if record.levelno <= logging.DEBUG:
                    return True
                if record.args:
                    record.args = tuple(
                        _TOKEN_RE.sub(r"\1[redacted]", a) if isinstance(a, str) else a
                        for a in record.args
                    )
                return True

        # Route uvicorn's standard logging through loguru so all logs share
        # the same format.  Also install the token-redaction filter on the
        # intercept handler so JWT tokens are still redacted.
        from loguru import logger as _loguru

        class _InterceptHandler(logging.Handler):
            """Forward stdlib log records to loguru."""

            _f = _RedactToken()

            # Paths whose access-log entries should be downgraded to DEBUG
            # to avoid noisy repetition from health checks / monitoring.
            # Note: relies on uvicorn.access passing the URL path as a str arg
            # in record.args — stable across uvicorn 0.20+.
            _QUIET_PATHS = ("/health", "/api/health", "/api/status")

            def emit(self, record: logging.LogRecord) -> None:
                self._f.filter(record)  # redact tokens
                try:
                    level = _loguru.level(record.levelname).name
                except ValueError:
                    level = record.levelno  # type: ignore[assignment]
                # Downgrade health/status endpoint access logs to DEBUG.
                if (
                    record.name == "uvicorn.access"
                    and record.args
                    and any(isinstance(a, str) and a in self._QUIET_PATHS for a in record.args)
                ):
                    level = "DEBUG"
                frame, depth = logging.currentframe(), 0
                while frame and (depth == 0 or frame.f_code.co_filename == logging.__file__):
                    frame = frame.f_back  # type: ignore[assignment]
                    depth += 1
                _loguru.opt(depth=depth, exception=record.exc_info).log(level, record.getMessage())

        handler = _InterceptHandler()
        for name in ("uvicorn", "uvicorn.access", "uvicorn.error"):
            log = logging.getLogger(name)
            log.handlers = [handler]
            log.propagate = False

    async def start(self) -> None:
        """Start the web server using uvicorn."""
        try:
            import uvicorn
        except ImportError as exc:
            raise ImportError(
                "uvicorn is required for the web server. Install it with: pip install uvicorn"
            ) from exc

        config = uvicorn.Config(
            app=self._app,
            host=self._config.host,
            port=self._config.port,
            log_level="info",
            timeout_graceful_shutdown=3,
        )
        self._server = uvicorn.Server(config)

        # Register startup event so the filter is installed AFTER uvicorn's
        # configure_logging() runs (during server startup, not before serve()).
        @self._app.on_event("startup")
        async def _startup_token_filter() -> None:
            self._install_access_log_filter()

        if self._on_started is not None:
            asyncio.create_task(self._notify_when_started())

        logger.info(f"Web server starting on http://{self._config.host}:{self._config.port}")
        await self._server.serve()

    async def stop(self) -> None:
        """Gracefully shut down the web server."""
        if self._server is not None:
            logger.info("Web server shutting down")
            self._server.should_exit = True
            self._server = None

    async def _maybe_handle_task_control(self, prompt: str) -> str | None:
        """Parse ``/task <action> <task_id> [reason]`` and forward to cloud.

        Returns a short ack string to echo back to the user when the
        prompt was a task-control command, or ``None`` to fall through
        to the normal agent loop.

        Recognised actions: ``approve | deny | cancel | undo | interrupt``.
        The action set is intentionally aligned with the gateway's
        ``task.control`` topic so wrong actions produce a real wire
        error the user can read.
        """

        text = prompt.strip()
        if not text.startswith("/task "):
            return None
        parts = text.split(maxsplit=3)
        # /task <action> <task_id> [reason...]
        if len(parts) < 3:
            return "Usage: `/task approve|deny|cancel|undo|interrupt <task_id> [reason]`"
        action = parts[1].lower()
        if action not in {"approve", "deny", "cancel", "undo", "interrupt"}:
            return (
                f"Unknown task action `{action}`. Use approve | deny | cancel | undo | interrupt."
            )
        task_id = parts[2]
        reason = parts[3] if len(parts) >= 4 else None

        cloud = self._runtime.channel_manager.get(ChannelType.CLOUD)
        if cloud is None or not getattr(cloud, "is_connected", False):
            return "Cannot send `task.control`: cloud channel is not connected."
        send_task_control = getattr(cloud, "send_task_control", None)
        if send_task_control is None:
            return "Connected channel does not support `task.control`."

        try:
            result = await send_task_control(task_id, action, reason=reason)
        except Exception as exc:  # noqa: BLE001
            logger.exception("/task {} {} failed", action, task_id)
            return f"`/task {action} {task_id}` failed: {exc}"

        if result.get("ok"):
            return f"✓ `/task {action} {task_id}` accepted by gateway."
        code = result.get("error_code") or "unknown_error"
        msg = result.get("error_message") or ""
        suffix = f": {msg}" if msg else ""
        return f"✗ `/task {action} {task_id}` rejected ({code}){suffix}"

    @property
    def app(self) -> Any:
        """Return the underlying FastAPI app (for testing or ASGI mounting)."""
        return self._app
