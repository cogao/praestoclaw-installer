"""Append-only JSONL transcript storage for agent sessions.

SQLite owns queryable session metadata.  This module owns the canonical,
lossless conversation/event stream.  Runtime mutations never rewrite a
transcript: message appends, logical deletes, and working-set replacement are
all represented as new events.
"""

from __future__ import annotations

import hashlib
import json
import os
import uuid
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from filelock import FileLock

_FORMAT_VERSION = 1


class TranscriptError(RuntimeError):
    """Base class for transcript storage failures."""


class TranscriptCorruptionError(TranscriptError):
    """The persisted transcript cannot be replayed safely."""


class _TranscriptValidationError(TranscriptCorruptionError):
    def __init__(self, message: str, *, event_index: int, event_count: int, offset: int) -> None:
        super().__init__(message)
        self.event_index = event_index
        self.event_count = event_count
        self.offset = offset


@dataclass(frozen=True)
class TranscriptRecord:
    """One message in the current replay view."""

    event_id: int | None
    message: dict[str, Any]
    created_at: str


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _json_bytes(value: object) -> bytes:
    # No ``default=str``: silently stringifying an unknown object would make
    # the canonical replay differ from the in-memory message.
    return json.dumps(
        value,
        ensure_ascii=False,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def _fsync_directory(path: Path) -> None:
    """Persist a same-directory atomic rename where the platform supports it."""
    if os.name == "nt":
        return
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
    descriptor = os.open(path, flags)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _prepare_message(message: dict[str, Any]) -> dict[str, Any]:
    if "role" not in message:
        raise KeyError("role")
    # ``_created_at`` is store metadata used by checkpoint callers, not an LLM
    # payload field.  Preserve every other (including unknown) JSON field.
    payload = {key: value for key, value in message.items() if key != "_created_at"}
    _json_bytes(payload)  # validate before acquiring a file lock or appending
    return payload


def _searchable_text(message: dict[str, Any]) -> str:
    content = message.get("content")
    if isinstance(content, str):
        return content
    if content is None:
        return ""
    try:
        return json.dumps(content, ensure_ascii=False, sort_keys=True)
    except (TypeError, ValueError):
        return str(content)


class TranscriptStore:
    """Canonical append-only transcript files under ``<dataDir>/sessions``.

    Runtime writers acquire the in-process write lock and :meth:`file_lock` in
    ``SessionStore`` so the same guard can cover related SQLite metadata.
    Runtime readers use only the in-process read lock.  The migration-only
    :meth:`write_migrated_snapshot` acquires the cross-process file lock itself.
    """

    def __init__(self, directory: Path) -> None:
        self.directory = directory

    @staticmethod
    def storage_key(session_id: str) -> str:
        # Existing session ids are route-shaped strings and commonly contain
        # ':' (illegal in Windows filenames).  A full digest is deterministic,
        # collision-resistant, and avoids path-length/data-leak surprises.
        return hashlib.sha256(session_id.encode("utf-8")).hexdigest()

    def path_for(self, session_id: str) -> Path:
        return self.directory / f"{self.storage_key(session_id)}.jsonl"

    @classmethod
    def event_id(cls, session_id: str, offset: int) -> int:
        """Return a session-scoped integer id without a database sequence."""
        namespace = int(cls.storage_key(session_id)[:32], 16)
        return (namespace << 64) | offset

    def lock_path_for(self, session_id: str) -> Path:
        return self.directory / f"{self.storage_key(session_id)}.jsonl.lock"

    def file_lock(self, session_id: str) -> FileLock:
        self.directory.mkdir(parents=True, exist_ok=True)
        # SessionStore acquires/releases through ``asyncio.to_thread``; the
        # worker thread is not guaranteed to be the same on both calls.
        return FileLock(
            str(self.lock_path_for(session_id)),
            timeout=60,
            thread_local=False,
        )

    @staticmethod
    def _header(session_id: str, *, created_at: str | None = None, **extra: object) -> dict:
        header: dict[str, object] = {
            "type": "session",
            "version": _FORMAT_VERSION,
            "session_id": session_id,
            "created_at": created_at or _now(),
        }
        header.update(extra)
        return header

    def ensure_file(self, session_id: str, *, created_at: str | None = None) -> Path:
        """Create an empty transcript atomically; caller holds the file lock."""
        path = self.path_for(session_id)
        if path.exists():
            self.repair_tail_if_needed(session_id)
            return path
        self.directory.mkdir(parents=True, exist_ok=True)
        tmp = self.directory / f".{path.name}.{uuid.uuid4().hex}.tmp"
        try:
            with tmp.open("xb") as handle:
                handle.write(_json_bytes(self._header(session_id, created_at=created_at)) + b"\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp, path)
            _fsync_directory(path.parent)
        finally:
            tmp.unlink(missing_ok=True)
        return path

    def append_message(
        self,
        session_id: str,
        message: dict[str, Any],
        *,
        created_at: str,
    ) -> int:
        """Append one lossless message event; caller holds the file lock."""
        payload = _prepare_message(message)
        return self._append_event(
            session_id,
            {
                "type": "message",
                "version": _FORMAT_VERSION,
                "timestamp": created_at,
                "payload": payload,
            },
        )

    def append_checkpoint(
        self,
        session_id: str,
        messages: list[dict[str, Any]],
        *,
        reason: str,
        created_at: str,
    ) -> int:
        """Append a replacement-history checkpoint; caller holds the lock."""
        prepared: list[dict[str, object]] = []
        for message in messages:
            raw_ts = message.get("_created_at")
            timestamp = raw_ts if isinstance(raw_ts, str) else created_at
            prepared.append(
                {
                    "timestamp": timestamp,
                    "payload": _prepare_message(message),
                }
            )
        # Validate the complete event before appending so a failure cannot
        # publish a partial replacement history.
        event = {
            "type": "checkpoint",
            "version": _FORMAT_VERSION,
            "timestamp": created_at,
            "reason": reason,
            "replacement_history": prepared,
        }
        _json_bytes(event)
        return self._append_event(session_id, event)

    def delete_messages(self, session_id: str, event_ids: list[int], *, created_at: str) -> int:
        """Append a tombstone for active message events; caller holds the lock."""
        if not event_ids:
            return 0
        # This method replays before it appends, so repair a failed previous
        # append before that tail could ever become a middle record.
        self.ensure_file(session_id)
        requested = set(event_ids)
        active = {
            record.event_id for record in self.replay(session_id) if record.event_id is not None
        }
        matched = sorted(int(event_id) for event_id in requested & active)
        if not matched:
            return 0
        self._append_event(
            session_id,
            {
                "type": "tombstone",
                "version": _FORMAT_VERSION,
                "timestamp": created_at,
                "targets": matched,
            },
        )
        return len(matched)

    def replay(self, session_id: str) -> list[TranscriptRecord]:
        """Build the current model/UI-visible view; caller holds the lock."""
        events = self._read_events(session_id)
        records: list[TranscriptRecord] = []
        for event in events[1:]:
            event_type = event.get("type")
            if event_type == "message":
                payload = event.get("payload")
                if not isinstance(payload, dict):
                    raise TranscriptCorruptionError("message event payload is not an object")
                event_id = event.get("id")
                if not isinstance(event_id, int):
                    raise TranscriptCorruptionError("message event id is not an integer")
                records.append(
                    TranscriptRecord(
                        event_id=event_id,
                        message=dict(payload),
                        created_at=str(event.get("timestamp") or ""),
                    )
                )
            elif event_type == "checkpoint":
                replacement = event.get("replacement_history")
                if not isinstance(replacement, list):
                    raise TranscriptCorruptionError("checkpoint replacement_history is not a list")
                new_records: list[TranscriptRecord] = []
                for item in replacement:
                    if not isinstance(item, dict) or not isinstance(item.get("payload"), dict):
                        raise TranscriptCorruptionError("checkpoint message is malformed")
                    item_id = item.get("id")
                    if not isinstance(item_id, int):
                        raise TranscriptCorruptionError("checkpoint message id is malformed")
                    new_records.append(
                        TranscriptRecord(
                            event_id=item_id,
                            message=dict(item["payload"]),
                            created_at=str(item.get("timestamp") or event.get("timestamp") or ""),
                        )
                    )
                records = new_records
            elif event_type == "tombstone":
                targets = event.get("targets")
                if not isinstance(targets, list) or not all(
                    isinstance(value, int) for value in targets
                ):
                    raise TranscriptCorruptionError("tombstone targets are malformed")
                removed = set(targets)
                records = [record for record in records if record.event_id not in removed]
            else:
                raise TranscriptCorruptionError(f"unknown transcript event type: {event_type!r}")
        return records

    def message_rows(
        self, session_id: str, event_ids: Iterable[int]
    ) -> list[tuple[int, dict[str, Any], str]]:
        requested = set(event_ids)
        return [
            (record.event_id, dict(record.message), record.created_at)
            for record in self.replay(session_id)
            if record.event_id is not None and record.event_id in requested
        ]

    def search_many(
        self,
        session_ids: Iterable[str],
        query: str,
        *,
        limit: int,
    ) -> list[dict[str, Any]]:
        """Simple cold-path scan; each transcript remains its own authority."""
        results: list[dict[str, Any]] = []
        for session_id in session_ids:
            if not self.path_for(session_id).exists():
                continue
            results.extend(self.search_session(session_id, query, limit=limit - len(results)))
            if len(results) >= limit:
                return results
        return results

    def search_session(self, session_id: str, query: str, *, limit: int) -> list[dict[str, Any]]:
        """Search one transcript; caller holds its in-process read lock."""
        needle = query.casefold()
        results: list[dict[str, Any]] = []
        for record in self.replay(session_id):
            if needle not in _searchable_text(record.message).casefold():
                continue
            item = dict(record.message)
            item["session_id"] = session_id
            item["created_at"] = record.created_at
            results.append(item)
            if len(results) >= limit:
                break
        return results

    def remove_file(self, session_id: str) -> None:
        """Remove one transcript after its SQLite session row is deleted."""
        self.path_for(session_id).unlink(missing_ok=True)

    def write_migrated_snapshot(
        self,
        session_id: str,
        messages: list[tuple[dict[str, Any], str]],
        *,
        created_at: str,
        source: str,
    ) -> Path:
        """Migration-only full-file writer used before the new v1 opens."""
        lock = self.file_lock(session_id)
        with lock:
            path = self.path_for(session_id)
            tmp = self.directory / f".{path.name}.{uuid.uuid4().hex}.tmp"
            try:
                with tmp.open("xb") as handle:
                    header = self._header(
                        session_id,
                        created_at=created_at,
                        migration={"source": source},
                    )
                    handle.write(_json_bytes(header) + b"\n")
                    for message, timestamp in messages:
                        offset = handle.tell()
                        event = {
                            "type": "message",
                            "version": _FORMAT_VERSION,
                            "id": self.event_id(session_id, offset),
                            "timestamp": timestamp,
                            "payload": _prepare_message(message),
                        }
                        handle.write(_json_bytes(event) + b"\n")
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(tmp, path)
                _fsync_directory(path.parent)
            finally:
                tmp.unlink(missing_ok=True)
            # Parse what was published rather than trusting only the writer.
            try:
                if len(self.replay(session_id)) != len(messages):
                    raise TranscriptCorruptionError(
                        f"migrated transcript count mismatch for session {session_id}"
                    )
            except BaseException:
                path.unlink(missing_ok=True)
                raise
            return path

    def _append_event(self, session_id: str, event: dict[str, Any]) -> int:
        path = self.ensure_file(session_id)
        with path.open("r+b") as handle:
            handle.seek(0, os.SEEK_END)
            offset = handle.tell()
            event_id = self.event_id(session_id, offset)
            if offset:
                handle.seek(-1, os.SEEK_END)
                if handle.read(1) != b"\n":
                    raise TranscriptCorruptionError(f"transcript has an incomplete tail: {path}")
                handle.seek(0, os.SEEK_END)
            published = {**event, "id": event_id}
            if published.get("type") == "checkpoint":
                replacement = published.get("replacement_history")
                if not isinstance(replacement, list):
                    raise TranscriptCorruptionError("checkpoint replacement_history is not a list")
                published["replacement_history"] = [
                    {
                        **item,
                        # Runtime APIs historically expose integer SQLite
                        # rowids.  A negative id derived from the immutable
                        # checkpoint offset keeps that contract without an
                        # auxiliary database sequence.
                        "id": -((event_id << 32) | (index + 1)),
                    }
                    for index, item in enumerate(replacement)
                ]
            handle.write(_json_bytes(published) + b"\n")
            handle.flush()
            os.fsync(handle.fileno())
        return event_id

    def _read_events(self, session_id: str) -> list[dict[str, Any]]:
        path = self.path_for(session_id)
        if not path.exists():
            return []
        raw = path.read_bytes()
        return self._validate_events(session_id, path, raw)

    def repair_tail_if_needed(self, session_id: str) -> bool:
        """Drop one invalid final physical event; caller holds the writer lock."""
        path = self.path_for(session_id)
        if not path.exists():
            return False
        raw = path.read_bytes()
        try:
            self._validate_events(session_id, path, raw)
            return False
        except _TranscriptValidationError as exc:
            if exc.event_index == 0 or exc.event_index != exc.event_count - 1:
                raise
            with path.open("r+b") as handle:
                handle.truncate(exc.offset)
                handle.flush()
                os.fsync(handle.fileno())
            self._read_events(session_id)
            return True

    def _validate_events(self, session_id: str, path: Path, raw: bytes) -> list[dict[str, Any]]:
        physical: list[tuple[int, int, bytes, bool]] = []
        offset = 0
        lines = raw.split(b"\n")
        for line_number, line in enumerate(lines, start=1):
            start = offset
            terminated = line_number < len(lines)
            offset += len(line) + int(terminated)
            content = line.removesuffix(b"\r")
            if content:
                physical.append((start, line_number, content, terminated))
        events: list[dict[str, Any]] = []
        event_count = len(physical)
        for event_index, (start, line_number, line, terminated) in enumerate(physical):
            if not terminated:
                raise _TranscriptValidationError(
                    f"transcript has an incomplete tail: {path}",
                    event_index=event_index,
                    event_count=event_count,
                    offset=start,
                )
            try:
                value = json.loads(line)
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise _TranscriptValidationError(
                    f"invalid JSON in {path} at line {line_number}",
                    event_index=event_index,
                    event_count=event_count,
                    offset=start,
                ) from exc
            if not isinstance(value, dict):
                raise _TranscriptValidationError(
                    f"non-object event in {path} at line {line_number}",
                    event_index=event_index,
                    event_count=event_count,
                    offset=start,
                )
            if event_index == 0:
                if (
                    value.get("type") != "session"
                    or value.get("version") != _FORMAT_VERSION
                    or value.get("session_id") != session_id
                ):
                    raise TranscriptCorruptionError(f"transcript header mismatch: {path}")
            else:
                try:
                    self._validate_event(value)
                except TranscriptCorruptionError as exc:
                    raise _TranscriptValidationError(
                        f"invalid transcript event in {path} at line {line_number}: {exc}",
                        event_index=event_index,
                        event_count=event_count,
                        offset=start,
                    ) from exc
            events.append(value)
        if not events:
            raise TranscriptCorruptionError(f"empty transcript: {path}")
        return events

    @staticmethod
    def _validate_event(event: dict[str, Any]) -> None:
        event_type = event.get("type")
        if event_type == "message":
            if not isinstance(event.get("payload"), dict):
                raise TranscriptCorruptionError("message event payload is not an object")
            if not isinstance(event.get("id"), int):
                raise TranscriptCorruptionError("message event id is not an integer")
        elif event_type == "checkpoint":
            replacement = event.get("replacement_history")
            if not isinstance(replacement, list):
                raise TranscriptCorruptionError("checkpoint replacement_history is not a list")
            for item in replacement:
                if not isinstance(item, dict) or not isinstance(item.get("payload"), dict):
                    raise TranscriptCorruptionError("checkpoint message is malformed")
                if not isinstance(item.get("id"), int):
                    raise TranscriptCorruptionError("checkpoint message id is malformed")
        elif event_type == "tombstone":
            targets = event.get("targets")
            if not isinstance(targets, list) or not all(
                isinstance(value, int) for value in targets
            ):
                raise TranscriptCorruptionError("tombstone targets are malformed")
        else:
            raise TranscriptCorruptionError(f"unknown transcript event type: {event_type!r}")
