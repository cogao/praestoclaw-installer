"""Canonical paths for PraestoClaw process logs."""

from __future__ import annotations

from pathlib import Path

from praestoclaw import __version__
from praestoclaw.utils.helpers import get_data_dir


def resolve_log_path(configured: str | None = None) -> Path:
    """Resolve a log path relative to the data directory.

    Runtime currently intentionally uses the fixed default by passing ``None``.
    The CLI uses the same call so it always tails the file Runtime writes.
    """
    if configured is None:
        return get_data_dir() / "logs" / f"praestoclaw-{__version__}.log"
    path = Path(configured).expanduser()
    if not path.is_absolute():
        path = get_data_dir() / path
    return path
