"""Shared Entra ID token acquisition used by init and the cloud channel."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

from loguru import logger
from rich.console import Console


def acquire_entra_token(
    *,
    tenant_id: str,
    client_id: str,
    scopes: str | list[str] | None = None,
    interactive: bool = True,
) -> str | None:
    """Acquire an Entra ID token: silent from cache, then interactive.

    Args:
        scopes: Single scope string, list of scopes, or None (defaults to
                ``{client_id}/access_as_user``).
        interactive: If True (default), show a Native/Browser menu and
                     perform interactive login when no cache is available.
                     If False, only try silent acquisition.

    Uses the same MSAL cache as CloudChannel so a prior ``praestoclaw cloud``
    login is reused automatically.

    Returns the access token string, or None on failure.
    """
    import msal

    from praestoclaw.utils.helpers import get_auth_dir

    if isinstance(scopes, list):
        effective_scopes = scopes
    elif scopes:
        effective_scopes = [scopes]
    else:
        effective_scopes = [f"{client_id}/access_as_user"]
    cache_path = get_auth_dir() / f"token_cache_{client_id[:8]}.bin"
    cache = msal.SerializableTokenCache()
    if cache_path.exists():
        try:
            from praestoclaw.security.secrets import decrypt_at_rest

            raw = decrypt_at_rest(cache_path.read_bytes())
            if raw:
                cache.deserialize(raw.decode("utf-8"))
        except Exception as exc:
            logger.warning("Corrupted MSAL cache at {} ({}); starting fresh", cache_path, exc)
            cache_path.unlink(missing_ok=True)

    app = msal.PublicClientApplication(
        client_id,
        authority=f"https://login.microsoftonline.com/{tenant_id}",
        token_cache=cache,
    )

    # 1. Silent (cached)
    accounts = app.get_accounts()
    result = None
    if accounts:
        result = app.acquire_token_silent(effective_scopes, account=accounts[0])
        if result and "access_token" in result:
            logger.debug("Entra token acquired silently (cached)")
            _persist_cache(cache, cache_path)
            return str(result["access_token"])

    if not interactive:
        return None

    # 2. Interactive — let user choose Native (WAM) or Browser.
    #    Loop back to menu on failure so user can retry a different method.
    while True:
        choice = prompt_native_or_browser(client_id)
        if choice == "skip":
            return None

        use_wam = choice == "native"
        bkw = _broker_kwargs() if use_wam else {}
        if use_wam and not bkw:
            use_wam = False  # broker not available, fall back

        # Recreate app only when broker kwargs change (WAM needs broker enabled,
        # browser does not). Avoids unnecessary object creation on browser retry.
        if bkw:
            app = msal.PublicClientApplication(
                client_id,
                authority=f"https://login.microsoftonline.com/{tenant_id}",
                token_cache=cache,
                **bkw,
            )

        if use_wam:
            _console.print(
                "  [dim]An OS account picker will appear.\n"
                "  If you don't see it, check behind this terminal window.[/dim]"
            )
        else:
            _console.print(
                "  [dim]Opening browser for sign-in...\n"
                "  Please complete sign-in in the browser, then return here.[/dim]"
            )

        wam_kwargs: dict[str, Any] = {}
        if use_wam:
            wam_kwargs["parent_window_handle"] = _get_foreground_window_handle(app)

        # WAM can use custom scopes here — this function returns a one-shot
        # token (access_token or id_token). The "no refresh_token" WAM
        # limitation only matters for interactive_cloud_login which needs
        # refresh_token for reconnects.
        interactive_scopes = effective_scopes

        logger.debug("Entra ID interactive login required")
        try:
            result = app.acquire_token_interactive(
                interactive_scopes, prompt="select_account", **wam_kwargs
            )

            # WAM failed — auto-fallback to browser (no menu, no user action).
            # Recreate app WITHOUT broker so MSAL uses browser PKCE instead.
            if use_wam and result and "error" in result:
                err = result.get("error", "")
                _console.print(
                    f"  [dim]Native sign-in failed ({err}), falling back to browser...[/dim]"
                )
                browser_app = msal.PublicClientApplication(
                    client_id,
                    authority=f"https://login.microsoftonline.com/{tenant_id}",
                    token_cache=cache,
                )
                result = browser_app.acquire_token_interactive(
                    effective_scopes, prompt="select_account"
                )
        except KeyboardInterrupt:
            _console.print("\n  [dim]Sign-in cancelled.[/dim]")
            raise

        token_str = (result.get("access_token") or result.get("id_token")) if result else None
        if token_str and "error" not in (result or {}):
            _persist_cache(cache, cache_path)
            return str(token_str)

        error = (
            result.get("error_description", result.get("error", "unknown"))
            if result
            else "no result"
        )
        _console.print(f"  [red]Sign-in failed:[/red] {error}")
        _console.print("  [dim]Please try again or select Skip.[/dim]")


def _persist_cache(cache: Any, cache_path: Path) -> None:
    """Write MSAL cache to disk if changed, encrypting at rest."""
    if not (hasattr(cache, "has_state_changed") and cache.has_state_changed):
        return
    from praestoclaw.security.secrets import encrypt_at_rest, is_encrypted

    plaintext = cache.serialize().encode("utf-8")
    data = encrypt_at_rest(plaintext)
    # Don't overwrite encrypted cache with plaintext if key unavailable
    if data == plaintext and cache_path.exists():
        try:
            if is_encrypted(cache_path.read_bytes()):
                return
        except OSError:
            return  # can't read existing cache — don't risk overwriting
    from praestoclaw.security.secrets import _atomic_write_file

    _atomic_write_file(cache_path, data)


# ── Broker support ───────────────────────────────────────────────────────────


_broker_cache: dict[str, Any] | None = None


def _broker_kwargs() -> dict[str, Any]:
    """Return MSAL broker kwargs for the current platform, or empty dict.

    Checks that ``pymsalruntime`` is importable (required on all platforms).
    Result is cached after first call.
    """
    global _broker_cache  # noqa: PLW0603
    if _broker_cache is not None:
        return _broker_cache

    try:
        import pymsalruntime  # noqa: F401
    except Exception:
        # ImportError (not installed), OSError (missing native lib),
        # RuntimeError (SSO extension unavailable on macOS CI), etc.
        _broker_cache = {}
        return _broker_cache

    if sys.platform == "win32":
        _broker_cache = {"enable_broker_on_windows": True}
    elif sys.platform == "darwin":
        _broker_cache = {"enable_broker_on_mac": True}
    elif sys.platform == "linux":
        _broker_cache = {"enable_broker_on_linux": True}
    else:
        _broker_cache = {}
    return _broker_cache


def _get_foreground_window_handle(app: Any) -> Any:
    """Get the foreground window handle for WAM broker dialog.

    On Windows: ``GetForegroundWindow()`` (dialog appears on top of current terminal).
    On other platforms: ``app.CONSOLE_WINDOW_HANDLE`` (MSAL default).
    """
    if sys.platform == "win32":
        import ctypes

        return ctypes.windll.user32.GetForegroundWindow()  # type: ignore[attr-defined]
    return app.CONSOLE_WINDOW_HANDLE


# ── Interactive login menu ───────────────────────────────────────────────────

_console = Console()


def _arrow_menu(
    options: list[tuple[str, str]],
    *,
    default: int = 0,
    title: str = "Sign In",
    subtitle: str | None = None,
) -> str:
    """Arrow-key menu shared by all login prompts.

    *options*: list of ``(key, label)`` tuples.
    Returns the ``key`` of the selected option.
    """
    selected = default

    # Hint uses dim + dark gray (very subtle, distinct from options)
    _hint = "\033[90m  Up/Down switch  Enter confirm  Esc skip\033[0m"

    def _draw(initial: bool = False) -> None:
        buf: list[str] = []
        if not initial:
            # +1 for the hint line below options
            buf.append(f"\r\033[{len(options) + 1}A")
        for i, (_, label) in enumerate(options):
            marker = ">" if i == selected else " "
            if i == selected:
                buf.append(f"\033[K  \033[1;36m{marker} {label}\033[0m\n")
            else:
                buf.append(f"\033[K  \033[37m{marker} {label}\033[0m\n")
        buf.append(f"\033[K{_hint}\n")
        sys.stdout.write("".join(buf))
        sys.stdout.flush()

    header = f"[bold]{title}[/bold]" if title else ""
    if subtitle:
        header = f"{header}\n{subtitle}" if header else subtitle
    if header:
        _console.print(f"  {header}")

    from praestoclaw.utils.input import is_tty, read_key_blocking

    if not is_tty():
        # Non-interactive (CI, piped stdin) → auto-select last option (Skip)
        # to avoid triggering interactive MSAL flows that would hang.
        selected = len(options) - 1
        _console.print(f"  [dim](non-interactive: defaulting to {options[selected][1]})[/dim]")
        return options[selected][0]

    sys.stdout.write("\033[?25l")  # hide cursor
    _draw(initial=True)

    try:
        while True:
            key = read_key_blocking()
            if key == "enter":
                break
            if key == "esc":
                selected = len(options) - 1
                break
            if key == "up":
                selected = (selected - 1) % len(options)
                _draw()
            elif key == "down":
                selected = (selected + 1) % len(options)
                _draw()
    except (EOFError, KeyboardInterrupt, OSError):
        selected = len(options) - 1
    finally:
        sys.stdout.write("\033[?25h")  # show cursor
        sys.stdout.flush()

    return options[selected][0]


def prompt_native_or_browser(client_id: str = "") -> str:
    """Show a simple Native / Browser / Skip menu.

    Returns one of: ``"native"``, ``"browser"``, ``"skip"``.
    Hides Native option when broker is not available.
    """
    has_broker = bool(_broker_kwargs())
    if has_broker:
        options: list[tuple[str, str]] = [
            ("native", "OS account picker"),
            ("browser", "Browser sign-in"),
            ("skip", "Skip for now"),
        ]
        default = 0
    else:
        options = [
            ("browser", "Browser sign-in"),
            ("skip", "Skip for now"),
        ]
        default = 0
    return _arrow_menu(
        options,
        default=default,
        # No title/subtitle here — ``teams install`` already prints a
        # ``[2/3] Microsoft 365 sign-in`` header right above this menu,
        # and other callers (cloud sign-in step in ``init``) print their
        # own ``(4.1) Cloud sign-in`` header. Showing another bold
        # "Microsoft sign-in" + subtitle here would just duplicate it.
        title="",
        subtitle=None,
    )
