"""Canonical production entry point for every LLM-triggering agent turn."""

from __future__ import annotations

import json
from dataclasses import dataclass
from enum import StrEnum
from typing import Any

from praestoclaw.channels.turn.context import ChannelTurnEnvelope
from praestoclaw.channels.turn.kernel import (
    ChannelTurnKernel,
    ChannelTurnResult,
    DefaultSessionResolver,
    SessionResolver,
)
from praestoclaw.host.runtime_contracts import AgentRuntimeProtocol


class TurnCompletion(StrEnum):
    """Trusted completion policy selected by an ingress adapter."""

    RETURN = "return"
    WEB_DELIVERY = "web_delivery"
    CLOUD_DELIVERY = "cloud_delivery"


class SessionEventKind(StrEnum):
    """Closed set of durable events that never become LLM messages."""

    DELIVERY_RECEIPT = "delivery_receipt"
    EXTERNAL_NOTICE = "external_notice"
    PMO_HANDOFF = "pmo_handoff"
    WORKFLOW_TERMINAL = "workflow_terminal"


@dataclass(frozen=True, slots=True)
class SessionEvent:
    """A durable session event that must not trigger an LLM turn."""

    session_id: str
    channel: str
    sender: str
    kind: SessionEventKind
    content: str
    metadata: dict[str, Any] | None = None
    created_at: str | None = None


class AgentHost:
    """Own turn normalization and dispatch for one process-local agent runtime.

    The host owns every ``ChannelTurnKernel`` instance and one shared
    ``SessionResolver``. Completion policy changes only how the already-normalized
    request completes; it never changes canonical session identity.
    """

    def __init__(
        self,
        *,
        agent_id: str,
        inline_runtime: AgentRuntimeProtocol,
        web_runtime: AgentRuntimeProtocol | None = None,
        cloud_runtime: AgentRuntimeProtocol | None = None,
        session_resolver: SessionResolver | None = None,
        session_store: Any | None = None,
    ) -> None:
        self._agent_id = agent_id
        self._inline_runtime = inline_runtime
        self._delivery_runtimes = {
            TurnCompletion.WEB_DELIVERY: web_runtime,
            TurnCompletion.CLOUD_DELIVERY: cloud_runtime,
        }
        self._session_resolver = session_resolver or DefaultSessionResolver()
        self._session_store = session_store
        self._kernels: dict[TurnCompletion, ChannelTurnKernel] = {}

    async def submit_turn(
        self,
        envelope: ChannelTurnEnvelope,
        *,
        completion: TurnCompletion = TurnCompletion.RETURN,
    ) -> ChannelTurnResult:
        """Normalize, admit, sanitize, and submit one canonical agent turn."""
        kernel = self._kernel_for(completion)
        return await kernel.process(envelope)

    def for_runtime(
        self,
        *,
        agent_id: str,
        inline_runtime: AgentRuntimeProtocol,
    ) -> AgentHost:
        """Create a worker host sharing this host's session resolver and store."""
        return AgentHost(
            agent_id=agent_id,
            inline_runtime=inline_runtime,
            session_resolver=self._session_resolver,
            session_store=self._session_store,
        )

    async def record_session_event(self, event: SessionEvent) -> None:
        """Append a typed durable event without admission, delivery, or LLM work."""
        if self._session_store is None:
            raise RuntimeError("AgentHost has no session store")
        if not isinstance(event.kind, SessionEventKind):
            raise ValueError("session event kind must be a SessionEventKind")
        metadata = event.metadata or {}
        try:
            json.dumps(metadata)
        except (TypeError, ValueError) as exc:
            raise ValueError("session event metadata must be JSON-serializable") from exc
        existing_sender = await self._session_store.get_session_sender(event.session_id)
        if existing_sender is None:
            raise ValueError(f"Session event target {event.session_id!r} does not exist")
        # Synthetic event senders such as ``a2a-system`` are not session owners.
        # Claim with the existing owner so the store still validates that the
        # event channel matches the durable session binding.
        await self._session_store.ensure_session(
            event.session_id,
            event.channel,
            existing_sender,
        )
        await self._session_store.add_message(
            event.session_id,
            {
                "role": "session_event",
                "content": event.content,
                "event_kind": event.kind.value,
                "metadata": metadata,
            },
            created_at=event.created_at,
        )

    def resolve_session_key(self, envelope: ChannelTurnEnvelope) -> str:
        """Expose the canonical resolver for diagnostics and ingress tests."""
        return self._session_resolver.resolve_session_key(envelope)

    def _kernel_for(self, completion: TurnCompletion) -> ChannelTurnKernel:
        kernel = self._kernels.get(completion)
        if kernel is not None:
            return kernel
        runtime: AgentRuntimeProtocol
        if completion is TurnCompletion.RETURN:
            runtime = self._inline_runtime
        else:
            selected = self._delivery_runtimes.get(completion)
            if selected is None:
                raise RuntimeError(f"{completion.value} is not configured")
            runtime = selected
        kernel = ChannelTurnKernel(
            agent_id=self._agent_id,
            runtime=runtime,
            session_resolver=self._session_resolver,
        )
        self._kernels[completion] = kernel
        return kernel

    async def start(self) -> None:
        """Start host-owned services (currently managed by ``Runtime``)."""

    async def stop(self) -> None:
        """Stop host-owned services (currently managed by ``Runtime``)."""
