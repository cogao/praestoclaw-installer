"""Agent Host skeleton for the channel rewrite."""

from praestoclaw.host.runtime_contracts import (
    AgentRuntimeProtocol,
    AgentRuntimeRequest,
    AgentRuntimeResult,
    TurnProvenanceSummary,
)

__all__ = [
    "AgentRuntimeProtocol",
    "AgentRuntimeRequest",
    "AgentRuntimeResult",
    "AgentLoopRuntimeAdapter",
    "TurnProvenanceSummary",
]


def __getattr__(name: str) -> object:
    if name == "AgentLoopRuntimeAdapter":
        from praestoclaw.host.legacy_agent_runtime import AgentLoopRuntimeAdapter

        return AgentLoopRuntimeAdapter
    raise AttributeError(name)
