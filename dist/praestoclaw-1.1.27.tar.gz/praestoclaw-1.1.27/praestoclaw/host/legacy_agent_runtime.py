"""Host-owned adapters from canonical turn requests to ``AgentLoopV2``."""

from __future__ import annotations

from typing import Any

from agent_gateway_protocol.agent_link.v1 import LogicalChannel

from praestoclaw.agent.loop_v2 import AgentLoopV2
from praestoclaw.bus.events import InboundMessage
from praestoclaw.config.schema import ChannelType
from praestoclaw.host.runtime_contracts import AgentRuntimeRequest, AgentRuntimeResult

_LOGICAL_CHANNEL_MAP: dict[str, ChannelType] = {
    LogicalChannel.INTERNAL.value: ChannelType.INTERNAL,
    LogicalChannel.LOCAL_WEBCHAT.value: ChannelType.WEB,
    LogicalChannel.CLOUD_TUI.value: ChannelType.CLOUD,
    LogicalChannel.SCHEDULER_LOCAL.value: ChannelType.INTERNAL,
    LogicalChannel.TEAMS.value: ChannelType.CLOUD,
    LogicalChannel.A2A.value: ChannelType.CLOUD,
    LogicalChannel.U2U.value: ChannelType.CLOUD,
    LogicalChannel.SCHEDULER_REMOTE.value: ChannelType.CLOUD,
    LogicalChannel.FUTURE_EXTERNAL.value: ChannelType.CLOUD,
    "agent_link": ChannelType.CLOUD,
}


def _runtime_channel(request: AgentRuntimeRequest) -> ChannelType:
    channel = ChannelType.INTERNAL
    if request.turn_provenance is not None:
        logical = request.turn_provenance.logical_channel
        channel = _LOGICAL_CHANNEL_MAP.get(logical) or (
            ChannelType.INTERNAL
            if request.turn_provenance.human_initiated
            and request.turn_provenance.trust_boundary == "local"
            else ChannelType.CLOUD
        )
    raw_override = str(request.runtime_policy.get("channel_type") or "").strip()
    return ChannelType.of(raw_override, default=channel) if raw_override else channel


def _request_message(request: AgentRuntimeRequest, *, channel: ChannelType) -> InboundMessage:
    policy = request.runtime_policy
    metadata: dict[str, Any] = dict(policy.get("message_metadata") or {})
    if request.turn_id:
        metadata["turn_id"] = request.turn_id
    for key in ("telemetry_turn_id", "telemetry_session_id"):
        value = policy.get(key)
        if isinstance(value, str) and value:
            metadata[key] = value
    if request.turn_provenance is not None:
        provenance = request.turn_provenance
        metadata["turn_provenance"] = {
            "initiated_by": provenance.initiated_by.value,
            "human_initiated": provenance.human_initiated,
            "logical_channel": provenance.logical_channel,
            "trust_boundary": provenance.trust_boundary,
            "supervision_required": provenance.supervision_required,
        }
        if not provenance.human_initiated or provenance.logical_channel in {
            LogicalChannel.A2A.value,
            LogicalChannel.U2U.value,
            LogicalChannel.SCHEDULER_LOCAL.value,
            LogicalChannel.SCHEDULER_REMOTE.value,
        }:
            metadata.setdefault("execution_lane", "system")
    exclude_tools = request.tool_policy.get("exclude_tools")
    if isinstance(exclude_tools, list) and exclude_tools:
        metadata["exclude_tools"] = [str(tool) for tool in exclude_tools]
    route_identity = str(policy.get("route_identity") or request.session_id)
    return InboundMessage(
        logical_channel=channel,
        physical_ingress=str(policy.get("physical_ingress") or channel.value),
        delivery_route_id=route_identity,
        sender_id=str(policy.get("sender_id") or ""),
        sender_name=str(policy.get("sender_name") or policy.get("sender_id") or ""),
        content=request.user_content,
        content_format=str(policy.get("content_format") or "text"),
        conversation_id=str(policy.get("conversation_id") or request.session_id),
        turn_id=request.turn_id or route_identity,
        agent_session_key=request.session_id,
        session_sender_id=str(policy.get("session_sender_id") or "") or None,
        attachments=list(request.attachments) if request.attachments else None,
        timestamp=str(policy.get("received_at") or "") or None,
        metadata=metadata,
    )


class AgentLoopRuntimeAdapter:
    """Submit a return-only turn and await its canonical queue handle.

    ``forked_child`` is set only by the adapter the runtime builds for an
    isolated sub-agent. Return-only is not by itself evidence of one — the root
    runtime and the cron service construct this same adapter, and their turns
    state their own session binding. Only the sub-agent runs on a ``fork()``
    whose binding was inherited rather than stated.
    """

    def __init__(self, agent_loop: AgentLoopV2, *, forked_child: bool = False) -> None:
        self._agent_loop = agent_loop
        self._forked_child = forked_child

    async def run_once(self, request: AgentRuntimeRequest) -> AgentRuntimeResult:
        message = _request_message(request, channel=_runtime_channel(request))
        # Passed only when set, so the many test doubles and any other
        # implementation of this interface keep working with the two-argument
        # signature they already have. Seven doubles in this repo implement
        # `enqueue_inbound`; making all of them track an argument that matters
        # to one caller is a cost with no reader.
        extra = {"forked_child": True} if self._forked_child else {}
        handle = await self._agent_loop.enqueue_inbound(message, deliver=False, **extra)
        return AgentRuntimeResult(content=await handle)


class AgentLoopDeliveryRuntimeAdapter:
    """Enqueue a delivered turn and return once FIFO registration is complete."""

    def __init__(self, agent_loop: AgentLoopV2, *, channel: ChannelType) -> None:
        self._agent_loop = agent_loop
        self._channel = channel

    async def run_once(self, request: AgentRuntimeRequest) -> AgentRuntimeResult:
        message = _request_message(request, channel=self._channel)
        handle = await self._agent_loop.enqueue_inbound(message, deliver=True)

        def _observe(done: Any) -> None:
            try:
                done.exception()
            except BaseException:
                pass

        handle.add_done_callback(_observe)
        return AgentRuntimeResult(content="", metadata={"enqueued": True})
