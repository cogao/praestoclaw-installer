"""Praesto Tag Experiment — borrowed-identity capability gate.

EXPERIMENTAL / THROWAWAY. Pairs with the gateway/channel ``praesto_tag_exp``
glue (grep that prefix to see the whole experiment).

Context: in this mock the bot acts as a group's shared digital employee, but it
is physically backed by a *real* employee's agent — it borrows that employee's
identity and permissions. A real digital employee would have its own
permissions; until that exists we must not let the borrowed session silently
use permissions the lending employee never agreed to lend.

Policy (the gentleman's-mock trade-off):
  * Exposed built-ins — plan, group_memory, attachment_process, spawn, tasks,
    and tools.
  * Exposed MCP — Teams only. For the demo, every Teams MCP action is allowed
    without approval, including writes and cross-conversation operations.
  * Everything else — other MCP servers, host filesystem, shell, networking,
    skills, and all other tools — is unavailable to the group turn.

This module only *classifies*; the ``ApprovalGate`` in ``hooks/handlers.py``
turns an ``"approve"`` classification into a real human-in-the-loop prompt.
"""

from __future__ import annotations

from typing import Any

PRAESTO_TAG_EXP_METADATA_KEY = "praesto_tag_exp"

# The Teams MCP server is conventionally registered under the key ``teams`` and
# surfaces tools named ``MCP_teams_<tool>`` (see mcp/adapter.py).
_TEAMS_MCP_SERVER = "teams"

# Prefix marking an MCP-server-targeting ``tools`` meta-tool call (connecting a
# server can exercise the employee's agency creds, so it stays gated).
_MCP_PREFIX_FOR_GATE = "MCP_"

# Built-in tools exposed to a borrowed-identity group turn. Everything else is
# hidden from the model and rejected at the execution gate.
PRAESTO_TAG_EXP_ALLOWED_BUILTIN_TOOLS: frozenset[str] = frozenset(
    {"attachment_process", "group_memory", "plan", "spawn", "tasks", "tools"}
)

# MCP servers exposed to the group turn.
PRAESTO_TAG_EXP_ALLOWED_MCP_SERVERS: frozenset[str] = frozenset({"teams"})

# Built-ins that are safe to run without borrowing additional personal-agent
# permissions. ``tools`` is handled separately because it manages both local
# tools and MCP server connections.
_PRAESTO_TAG_EXP_BORROWED_TOOLS = frozenset(
    {"attachment_process", "group_memory", "plan", "spawn", "tasks"}
)

# Personal tools that must NOT surface in a borrowed-identity group turn: the
# shared employee persists facts via ``group_memory`` (the group's isolated local
# store), never the lending employee's private MEMORY.md / history. Canonical source shared by
# the loop (schema exclusion + prompt guidance) and the ``tools`` meta-tool (so
# it neither lists nor re-activates these behind the exclusion's back).
PRAESTO_TAG_EXP_PERSONAL_TOOLS: frozenset[str] = frozenset({"memory", "search_history"})

# Classification tokens returned to the gate.
PRAESTO_TAG_EXP_ALLOW = "allow"
PRAESTO_TAG_EXP_APPROVE = "approve"
PRAESTO_TAG_EXP_REJECT = "reject"


def praesto_tag_exp_is_active(metadata: dict[str, Any] | None) -> bool:
    """Whether the current turn is a praesto tag exp borrowed-identity turn."""
    return bool((metadata or {}).get(PRAESTO_TAG_EXP_METADATA_KEY))


def _mcp_server_and_raw(tool_name: str) -> tuple[str, str]:
    """Split an ``MCP_<server>_<tool>`` name into ``(server, raw_tool)`` lowered.

    Returns ``("", "")`` for non-MCP (built-in / host) tools.
    """
    if not tool_name or not tool_name.startswith("MCP_"):
        return "", ""
    rest = tool_name[len("MCP_") :]
    server, _, raw = rest.partition("_")
    return server.lower(), raw.lower()


def praesto_tag_exp_tool_is_exposed(tool_name: str) -> bool:
    """Whether a tool may be surfaced or invoked in a borrowed group turn."""
    if tool_name in PRAESTO_TAG_EXP_ALLOWED_BUILTIN_TOOLS:
        return True
    server, _ = _mcp_server_and_raw(tool_name)
    return server in PRAESTO_TAG_EXP_ALLOWED_MCP_SERVERS


def praesto_tag_exp_is_unconditional_teams_demo_call(
    tool_name: str, args: dict[str, Any] | None
) -> bool:
    """Whether this call bypasses every approval layer for the demo."""
    server, _ = _mcp_server_and_raw(tool_name)
    if server == _TEAMS_MCP_SERVER:
        return True
    if tool_name != "tools":
        return False
    target = str((args or {}).get("name") or "").strip()
    target_server, _ = _mcp_server_and_raw(target)
    return target_server == _TEAMS_MCP_SERVER


def praesto_tag_exp_classify_capability(
    tool_name: str, args: dict[str, Any] | None, *, current_cid: str
) -> str:
    """Classify an exposed tool as allow/approve, or reject an unavailable tool.

    ``current_cid`` is the Teams conversation id of the group this turn came
    from (``metadata["cid"]``). Only the small exposed tool set can run at all.
    For the demo, every exposed Teams MCP call is auto-borrowed before the
    scoring engine. This temporary bypass includes writes and cross-conversation
    operations and must be replaced by a redesigned approval model.
    """
    args = args or {}
    if not praesto_tag_exp_tool_is_exposed(tool_name):
        return PRAESTO_TAG_EXP_REJECT

    # The group's own shared store is part of the default-borrow surface.
    if tool_name in _PRAESTO_TAG_EXP_BORROWED_TOOLS:
        return PRAESTO_TAG_EXP_ALLOW
    # The ``tools`` meta-tool only manages the LOCAL tool registry (list /
    # describe / enable / disable a built-in tool). That is not a borrowed action
    # — any non-Teams tool it enables is independently re-gated when called.
    # So don't spam the employee with an approval just to inspect/enable a local
    # tool (e.g. the model poking at group_memory). The preconfigured Teams MCP
    # server is the only MCP surface exposed to this experiment, so enabling it
    # is unconditionally allowed for the demo. Other MCP servers remain
    # unavailable.
    if tool_name == "tools":
        target = str(args.get("name") or "").strip()
        if not target:
            return PRAESTO_TAG_EXP_ALLOW
        if target.startswith(_MCP_PREFIX_FOR_GATE):
            server, _ = _mcp_server_and_raw(target)
            if server in PRAESTO_TAG_EXP_ALLOWED_MCP_SERVERS:
                return PRAESTO_TAG_EXP_ALLOW
            return PRAESTO_TAG_EXP_REJECT
        if target in PRAESTO_TAG_EXP_ALLOWED_BUILTIN_TOOLS:
            return PRAESTO_TAG_EXP_ALLOW
        return PRAESTO_TAG_EXP_REJECT
    server, _ = _mcp_server_and_raw(tool_name)
    if server != _TEAMS_MCP_SERVER:
        return PRAESTO_TAG_EXP_REJECT
    return PRAESTO_TAG_EXP_ALLOW
