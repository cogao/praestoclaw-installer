"""Workflow tool — run a reusable single-agent recipe in an isolated session.

A workflow recipe is a Markdown file with YAML frontmatter, parsed with the
skill loader. **Honored frontmatter fields:** ``name``, ``description``, the
Markdown body (``content``), and the opt-in ``plan: true`` flag (run-as-Plan —
when set, ``run`` prepends a plan-driving preamble so the recipe executes as a
tracked, ``PlanStore``-persisted Plan; see ``_plan_preamble``). All other skill
frontmatter (``safe_tools``, ``keywords``, ``requires_*``, ``patterns``,
``workflow`` …) is IGNORED — in particular ``safe_tools`` is NOT applied, so a
recipe cannot grant itself approval-free tools; the spawned agent's shell/check
still go through the normal ApprovalGate.

Recipes live in the data dir's ``workflows/`` (default ``~/.praestoclaw/
workflows/*.md``, overridable via ``PRAESTOCLAW_DATA_DIR`` and different on
staging) plus a bundled dir shipped with the package (user recipes override
bundled by name). ``run`` executes the recipe body as a single ``default``
agent in a fresh isolated background session (reusing ``BackgroundTaskManager``);
the result is delivered back to the originating channel when it finishes.
"""

from __future__ import annotations

import json
import os
import re
import tempfile
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any

import yaml

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.host.background_tasks import origin_from_kwargs
from praestoclaw.skills.loader import Skill, parse_skill_file
from praestoclaw.utils.limits import positive_int

_BUNDLED_DIR = Path(__file__).parent / "bundled_workflows"

_MAX_NAME_LEN = 80
_MAX_DESC_LEN = 500
_MAX_BODY_LEN = 20000
_MAX_PARAMS = 30
_MAX_PARAM_NAME_LEN = 64
# A parameter name is interpolated as a ``{name}`` placeholder in the body and
# matched by the substitution regex, so it must be identifier-safe.
_PARAM_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
# Accepted parameter types (advisory + light run-time validation); anything else
# is normalized to "string" at save time.
_PARAM_TYPES = frozenset({"string", "integer", "int", "float", "number", "boolean", "select"})
# Aliases normalized to canonical types at save time so recipe files are
# consistent with the schema/docs ("integer"/"float", not "int"/"number").
_PARAM_TYPE_CANON = {"int": "integer", "number": "float"}

# Windows reserved device names — a file whose stem is one of these cannot be
# created on Windows (e.g. "con.md" fails / opens the console device). The slug
# is the filename stem, so guard against a user naming a workflow "con"/"nul"/
# "com1" etc. Compared case-insensitively.
_WIN_RESERVED = frozenset(
    {"con", "prn", "aux", "nul"}
    | {f"com{i}" for i in range(1, 10)}
    | {f"lpt{i}" for i in range(1, 10)}
)

BackgroundFn = Callable[..., Awaitable[tuple[str | None, str]]]

# Channel names accepted for a scheduled workflow's result delivery (ordered for
# display). The scheduler coerces unknown names via ChannelType.of(...), which
# silently maps a typo to CLI — so validate here and reject unknowns before
# scheduling. Mirrors the ChannelType values the scheduler can deliver to.
_NOTIFY_CHANNELS = ("cloud", "web", "local_webchat", "cli", "*")
_VALID_NOTIFY_CHANNELS = frozenset(_NOTIFY_CHANNELS)
_NOTIFY_CHANNELS_HELP = ", ".join(_NOTIFY_CHANNELS)


def _as_bool(value: Any) -> bool:
    """Coerce a tool arg that *should* be a bool but may arrive as a string.

    LLMs don't always honor the declared JSON type, so ``replace`` can show up
    as the string ``"false"`` — and ``bool("false")`` is ``True``, which would
    silently overwrite an existing recipe. Only an intentional true (real
    ``True``, or a ``"true"``-ish string) counts; everything else stays
    ``False`` so a stray value can't clobber a saved recipe.
    """
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"true", "1", "yes", "on"}
    # Anything else (None, numbers, dict/list/object) is NOT an intentional
    # true — stay False so a stray value can never clobber a saved recipe.
    return False


def _normalize_limits(raw: Any) -> dict[str, Any]:
    """Normalize a recipe's ``limits:`` mapping into ``workflow_*`` metadata keys.

    Drops anything invalid (non-positive/uncoercible ints, non-string tools, wrong
    types) — a dropped limit means "no cap for that dimension", never an error, and
    can never *widen* the harness/global caps. Returns only the keys that are set,
    so a recipe with no valid limits injects nothing. ``allowed_tools`` is an
    ALLOWLIST (intersected into the spawned run's tool palette / turned into the
    scheduler's exclude-list downstream, never a grant); the ``max_*`` caps are only
    ever tightened, never loosened, downstream.

    NOTE: ``max_iterations`` is intentionally NOT emitted here — bounding a run's
    iteration budget is the one cap that must touch the shared per-conversation loop
    (``_setup``'s ``IterationBudget``), so it's deferred to a follow-up to keep this
    change out of the core loop. It's still accepted in frontmatter (parsed into
    ``Skill.limits``) but currently unenforced.
    """
    out: dict[str, Any] = {}
    if not isinstance(raw, dict):
        return out
    tools = raw.get("allowed_tools")
    if isinstance(tools, list):
        cleaned = [s.strip() for s in tools if isinstance(s, str) and s.strip()]
        if cleaned:
            out["workflow_allowed_tools"] = cleaned
    for src, dst in (
        ("max_runtime", "workflow_max_runtime"),
        ("max_output", "workflow_max_output"),
    ):
        n = positive_int(raw.get(src))
        if n is not None:
            out[dst] = n
    return out


def intersect_allowed_tools(scoped_tools: list[str], metadata: dict[str, Any] | None) -> list[str]:
    """Task 9: narrow a spawned run's tool list to a workflow recipe's allowlist.

    Returns ``scoped_tools`` intersected with ``metadata['workflow_allowed_tools']``
    when that (non-empty) allowlist is present, else ``scoped_tools`` unchanged
    (inert for every non-workflow spawn). Only ever REMOVES — never grants a tool
    the agent's palette doesn't already contain. Used by ``runtime._spawn_agent``.
    """
    allow = (metadata or {}).get("workflow_allowed_tools")
    if isinstance(allow, list) and allow:
        return [t for t in scoped_tools if t in allow]
    return scoped_tools


def _slugify(name: str) -> str:
    """Lowercase; keep unicode letters/digits; collapse everything else to a
    single dash; trim dashes.

    Returns "" if nothing usable remains (the caller rejects). The slug is both
    the filename stem and the recipe's frontmatter ``name`` (what ``run`` keys
    off), so ``add`` and ``run`` agree on the identifier. Unicode letters
    (e.g. 中文) are kept so a non-ASCII name isn't silently rejected.
    """
    slug = re.sub(r"[^\w]+", "-", name.strip().lower(), flags=re.UNICODE).replace("_", "-")
    slug = re.sub(r"-+", "-", slug).strip("-")
    slug = slug[:_MAX_NAME_LEN].strip("-")  # re-trim: truncation can land on a dash
    if slug.lower() in _WIN_RESERVED:
        # "con.md" et al. can't be created on Windows — suffix so the id stays usable.
        slug = f"{slug}-wf"
    return slug


def _load_recipes(user_dir: Path) -> dict[str, Skill]:
    """Recipe name -> Skill, from bundled dir + user dir (user overrides bundled)."""
    recipes: dict[str, Skill] = {}
    for d in (_BUNDLED_DIR, user_dir):
        if not d.is_dir():
            continue
        for md in sorted(d.glob("*.md")):
            skill = parse_skill_file(md)
            if skill and skill.name:
                recipes[skill.name] = skill
    return recipes


def _make_cached_recipe_loader(workflow_dir: Path) -> Callable[[], dict[str, Skill]]:
    """A cached ``_load_recipes(workflow_dir)`` behind a cheap stat-only fingerprint
    (path + mtime + size of every recipe file). Re-parses only when a file is
    added / removed / edited, so recipe edits still take effect at the next call
    (freshness preserved) without paying the YAML-parse cost when nothing changed.
    Each caller gets its OWN cache — the body and limits scheduler resolvers build
    one each, so a fire re-parses at most once per resolver (not a single shared
    cache), which keeps steady-state fires parse-free.
    """
    cache: dict[str, Any] = {"fingerprint": None, "recipes": {}}

    def _fingerprint() -> tuple[tuple[str, int, int], ...]:
        entries: list[tuple[str, int, int]] = []
        for d in (_BUNDLED_DIR, workflow_dir):
            if not d.is_dir():
                continue
            for md in sorted(d.glob("*.md")):
                try:
                    st = md.stat()
                except OSError:
                    continue  # racing delete — treat as absent this fire
                entries.append((str(md), st.st_mtime_ns, st.st_size))
        return tuple(entries)

    def _load() -> dict[str, Skill]:
        fp = _fingerprint()
        if fp != cache["fingerprint"]:
            cache["recipes"] = _load_recipes(workflow_dir)
            cache["fingerprint"] = fp
        return cache["recipes"]  # type: ignore[no-any-return]

    return _load


def make_recipe_loader(workflow_dir: Path) -> Callable[[], dict[str, Skill]]:
    """Public factory: a cached ``{name: recipe}`` loader over ``workflow_dir``
    (user overrides bundled), refreshed on a cheap stat fingerprint. Used by the
    workflow auto-suggest hook so it re-parses recipes only when they change.
    Wraps the internal cached loader so callers don't depend on a private symbol.
    """
    return _make_cached_recipe_loader(workflow_dir)


def make_recipe_resolver(workflow_dir: Path) -> Callable[[str], str | None]:
    """Public factory: a resolver mapping a recipe name to its current body.

    The scheduler calls this at each fire so a scheduled workflow always runs the
    latest recipe. Returns ``None`` when the recipe no longer exists (the scheduler
    then raises → user notified, job auto-disables). Exposed so runtime wires the
    scheduler without reaching into a private helper.

    Resolves via ``_load_recipes`` (user-overrides-bundled, deduped by frontmatter
    name) and matches on the CANONICAL (whitespace-collapsed) id — schedule stores
    the canonical name and run/status/resume all key off it, so a recipe whose
    frontmatter name has irregular whitespace still fires. **Raises** ``ValueError``
    when 2+ distinct recipe names collapse to the same canonical id — same
    ambiguity refusal as run/resume/schedule, so a scheduled fire never silently
    runs the wrong body (the scheduler routes the raise to its error handler).

    Detecting ambiguity requires scanning ALL recipes (can't early-exit on the
    first match), so the parse is cached behind a stat fingerprint (see
    ``_make_cached_recipe_loader``) — no re-parse when nothing changed.
    """
    load = _make_cached_recipe_loader(workflow_dir)

    def _resolve(name: str) -> str | None:
        canonical = " ".join(str(name or "").split())
        matches = [s for k, s in load().items() if " ".join(k.split()) == canonical]
        if len(matches) > 1:
            raise ValueError(
                f"{len(matches)} recipes collapse to the canonical id {canonical!r} "
                "(whitespace-ambiguous) — rename them to distinct ids to disambiguate."
            )
        return matches[0].content if matches else None

    return _resolve


def make_limits_resolver(workflow_dir: Path) -> Callable[[str], dict[str, Any]]:
    """Public factory: resolve a recipe's normalized capability limits (Task 9).

    Returns the ``workflow_*`` metadata dict (allowed_tools / max_runtime /
    max_output — ``max_iterations`` is intentionally NOT emitted, see
    ``_normalize_limits``) for a recipe name, or ``{}`` when it declares none
    / doesn't exist / is whitespace-ambiguous. The scheduler consults this at each
    fire so a scheduled run is bounded by the recipe's *current* limits — the same
    caps an on-demand run gets. Matched on the canonical id like run/status/resume.
    Caches parsed recipes behind its own stat fingerprint (like the body resolver),
    so a steady-state fire re-parses nothing.
    """
    load = _make_cached_recipe_loader(workflow_dir)

    def _resolve(name: str) -> dict[str, Any]:
        canonical = " ".join(str(name or "").split())
        matches = [s for k, s in load().items() if " ".join(k.split()) == canonical]
        if len(matches) != 1:  # 0 = gone, 2+ = ambiguous (body resolver refuses too)
            return {}
        return _normalize_limits(getattr(matches[0], "limits", None))

    return _resolve


def _plan_preamble(name: str) -> str:
    """Preamble that makes a ``plan: true`` recipe run as a tracked Plan.

    Prepended to the recipe body at run time (see ``_run``). It steers the
    spawned single-agent run to create + drive a persisted plan (keyed to its
    own forked session id, ``workflow=<name>``) so the run has visible steps,
    per-step verification, optional HITL gates, and an audit file that survives
    restart — all through the existing ``plan`` tool, no new engine. Guidance,
    not enforcement: the agent still derives the concrete steps from the body.
    """
    # The recipe name is interpolated into the example call. Names are slugs in
    # practice (``add`` enforces ``[a-z0-9-]``) but a hand-authored recipe could
    # carry quotes/newlines, which would break a single-quoted literal. Use a
    # collapsed name for the bold header and a JSON literal (quote/newline-safe)
    # for the ``workflow=`` example value.
    display = " ".join(str(name).split()) or name
    workflow_lit = json.dumps(name)
    return (
        f"🧭 You are running the reusable workflow **{display}** as a tracked plan.\n\n"
        f"STEP 1 — Before doing any work, call "
        f"plan(action='create', workflow={workflow_lit}, items=[...]) to break the "
        "steps below into ordered items. Give each item a short `acceptance` "
        "(how you'll know it's done) and, where a step can be objectively "
        "verified, a `check` shell command.\n\n"
        "STEP 2 — Work through the plan one item at a time: call "
        "plan(action='update', id=<n>, status='in_progress') before starting an "
        "item, then after finishing it run its `check` (if any) and call "
        "plan(action='update', id=<n>, status='done', evidence=<result>). If an "
        "item needs the user's go-ahead before proceeding, use "
        "plan(action='checkpoint', ask_user=true).\n\n"
        "STEP 3 — When every item is done, give your final answer with the "
        "actual result the user asked for.\n\n"
        "--- workflow steps ---\n"
    )


def _resume_preamble(name: str, plan: Any) -> str:
    """Preamble for ``resume``: carry the interrupted plan's state + safety rules.

    A previous run-as-Plan run was interrupted (crash/restart) with its plan
    partly done. This tells the resuming agent what was already completed (so it
    does NOT redo it — the work + side effects already happened) and to plan +
    continue the remaining steps. An ``in_progress`` step gets an explicit
    idempotency warning (verify / checkpoint before redoing a side-effecting
    step) — resume never blindly re-runs.
    """
    try:
        done, total = plan.progress
    except Exception:  # noqa: BLE001
        done, total = 0, 0
    items = getattr(plan, "items", []) or []
    rows: list[str] = []
    has_in_progress = False
    for i, it in enumerate(items, 1):
        st = str(getattr(it, "status", "") or "")
        if st == "in_progress":
            has_in_progress = True
        mark = "✓" if st in ("done", "skipped") else ("▶" if st == "in_progress" else "☐")
        title = " ".join(str(getattr(it, "title", "")).split())[:120]
        rows.append(f"  {i}. [{mark}] {title}")
    rendered = "\n".join(rows) if rows else "  (no recorded steps)"
    display = " ".join(str(name).split()) or name
    wf_lit = json.dumps(name)
    warn = (
        "\n\n⚠️ A step above is [▶] in_progress — its **side effects may be PARTIAL** "
        "(e.g. an email or PR half-done). VERIFY the real state before redoing it, and "
        "use plan(action='checkpoint', ask_user=true) if you're unsure. Never blindly "
        "re-run a side-effecting step."
        if has_in_progress
        else ""
    )
    return (
        f"🔄 You are RESUMING the workflow **{display}** — a previous run was interrupted "
        f"(crash/restart) with {done}/{total} steps done:\n{rendered}\n\n"
        "Continue from the first UNFINISHED step. Do NOT redo any [✓] step — its work "
        f"already happened. Make a fresh plan(action='create', workflow={wf_lit}) for the "
        f"REMAINING steps only and work through them.{warn}\n\n"
        "--- workflow steps (for reference) ---\n"
    )


def _resolve_params(
    specs: list[dict[str, Any]] | None, provided: Any
) -> tuple[dict[str, str], list[str]]:
    """Resolve a recipe's declared parameters to string substitution values.

    Returns ``(name -> str value, errors)``. For each declared param the value
    is ``provided[name]`` if given (and non-null), else its ``default``, else
    "" for optional / an error for ``required``. Light validation: an
    ``integer``/``float`` value must coerce; a ``select`` value must be in
    ``options``. Values are stringified for **plain-text** substitution — there
    is no template engine (the Societas SSTI→RCE lesson, §1.8). ``provided`` may
    be a dict or a JSON object string (LLMs sometimes stringify the arg).
    """
    if not specs:
        return {}, []
    if isinstance(provided, str):
        try:
            provided = json.loads(provided)
        except (ValueError, TypeError):
            provided = {}
    if not isinstance(provided, dict):
        provided = {}
    values: dict[str, str] = {}
    errors: list[str] = []
    for spec in specs:
        name = str(spec.get("name") or "").strip()
        if not name:
            continue
        ptype = str(spec.get("type") or "string").strip().lower()
        if name in provided and provided[name] is not None:
            raw: Any = provided[name]
        elif spec.get("default") is not None:
            raw = spec.get("default")
        elif _as_bool(spec.get("required")):
            errors.append(f"missing required parameter {name!r}")
            continue
        else:
            raw = ""
        if ptype in ("integer", "int"):
            text = str(raw).strip()
            try:
                int(text)
            except (ValueError, TypeError):
                errors.append(f"parameter {name!r} must be an integer (got {raw!r})")
                continue
            raw = text  # substitute the validated (stripped) form, not the raw
        elif ptype in ("float", "number"):
            text = str(raw).strip()
            try:
                float(text)
            except (ValueError, TypeError):
                errors.append(f"parameter {name!r} must be a number (got {raw!r})")
                continue
            raw = text
        elif ptype == "select":
            raw_opts = spec.get("options")
            # Guard: only a list of options gates the value — a scalar/str
            # ``options`` must NOT be char-iterated into per-character choices.
            options = [str(o) for o in raw_opts] if isinstance(raw_opts, list) else []
            if options and str(raw) not in options:
                errors.append(f"parameter {name!r} must be one of {options} (got {raw!r})")
                continue
        values[name] = str(raw)
    return values, errors


def _substitute_params(body: str, values: dict[str, str]) -> str:
    """Replace ``{name}`` with ``values[name]`` for declared names only.

    Plain-text, **single-pass** (a value that itself contains ``{other}`` is NOT
    re-expanded), and unknown ``{…}`` tokens are left verbatim (recipe prose /
    code samples must not be mangled). No template engine — SSTI-safe.
    """
    if not values:
        return body
    pattern = re.compile(r"\{(" + "|".join(re.escape(k) for k in values) + r")\}")
    return pattern.sub(lambda m: values[m.group(1)], body)


def _normalize_param_specs(raw: Any) -> tuple[list[dict[str, Any]] | None, str | None]:
    """Validate + normalize an ``add`` ``parameters`` arg for frontmatter.

    Returns ``(specs, error)``. ``specs`` is None when no parameters were given
    (nothing to write) or on error; ``error`` is a user-facing message when the
    input is malformed. Authoring is strict (so the agent can correct): the input
    must be a list of dicts, each with a ``{placeholder}``-safe ``name``; names
    must be unique; unknown ``type`` normalizes to ``string``; count is capped.
    Only meaningful keys are emitted (``name``/``type`` always; ``required`` when
    true; ``default`` when provided; ``options`` for a select with a list).
    """
    if raw is None:
        return None, None
    if not isinstance(raw, list):
        return None, "'parameters' must be a list of {name, type, required, default} objects."
    if len(raw) > _MAX_PARAMS:
        return None, f"too many parameters (max {_MAX_PARAMS})."
    specs: list[dict[str, Any]] = []
    seen: set[str] = set()
    for entry in raw:
        if not isinstance(entry, dict):
            return None, "each parameter must be an object with a 'name'."
        name = str(entry.get("name") or "").strip()
        if not name:
            return None, "each parameter needs a non-empty 'name'."
        if len(name) > _MAX_PARAM_NAME_LEN:
            return None, f"parameter name {name[:20]!r}… is too long (max {_MAX_PARAM_NAME_LEN})."
        if not _PARAM_NAME_RE.match(name):
            return None, (
                f"parameter name {name!r} is not valid — it must start with a letter "
                "or underscore, then letters/digits/underscores only "
                "(it becomes a {name} placeholder)."
            )
        if name in seen:
            return None, f"duplicate parameter name {name!r}."
        seen.add(name)
        ptype = str(entry.get("type") or "string").strip().lower()
        if ptype not in _PARAM_TYPES:
            ptype = "string"
        ptype = _PARAM_TYPE_CANON.get(ptype, ptype)  # int→integer, number→float
        spec: dict[str, Any] = {"name": name, "type": ptype}
        if _as_bool(entry.get("required")):
            spec["required"] = True
        if "default" in entry and entry.get("default") is not None:
            spec["default"] = entry.get("default")
        if ptype == "select":
            opts = entry.get("options")
            # A select with no usable options can't gate anything — reject at
            # save time rather than persist an un-enforced select.
            if not (isinstance(opts, list) and opts):
                return None, f"select parameter {name!r} needs a non-empty 'options' list."
            options = [str(o) for o in opts]
            spec["options"] = options
            # A default that isn't one of the options would make every run (incl.
            # unattended/scheduled) fail _resolve_params — catch it at save time.
            if "default" in spec and str(spec["default"]) not in options:
                return None, (
                    f"select parameter {name!r} default {spec['default']!r} "
                    f"must be one of {options}."
                )
        specs.append(spec)
    return (specs or None), None


class WorkflowTool(Tool):
    """List and run reusable single-agent workflow recipes (opt-in, flag-gated)."""

    def __init__(
        self,
        workflow_dir: Path,
        background_fn: BackgroundFn,
        scheduler: Any = None,
        inflight_fn: Any = None,
        active_plans_fn: Any = None,
        run_history_fn: Any = None,
    ) -> None:
        self._dir = workflow_dir
        self._background_fn = background_fn
        # SchedulerService handle (duck-typed: add_job / remove_job / list_jobs).
        # None when the cron subsystem is disabled — schedule/unschedule then
        # return a clear error instead of silently doing nothing.
        self._scheduler = scheduler
        # Callable(*, owner) -> list of active workflow runs (BackgroundTaskManager.
        # list_workflow_runs) for the status "running now" view. None = no on-demand
        # run visibility (e.g. in tests / if not wired).
        self._inflight_fn = inflight_fn
        # Callable() -> list of active plan-like objects (PlanStore.list_active).
        # Used to show a run-as-Plan run's live step (第 K/M 步) in status,
        # correlated by plan.origin_task == run.task_id (6d-1). None = no step
        # enrichment (runs still show name + elapsed).
        self._active_plans_fn = active_plans_fn
        # Callable(recipe, limit) -> durable on-demand run records
        # (WorkflowRunStore.get_history) for `status name=<recipe>`. None = no
        # on-demand history section.
        self._run_history_fn = run_history_fn

    @property
    def name(self) -> str:
        return "workflow"

    @property
    def description(self) -> str:
        recipes = _load_recipes(self._dir)
        catalog: list[str] = []
        for recipe in recipes.values():
            description = " ".join(recipe.description.split()).replace(". ", "; ").rstrip(".")
            required = [
                str(spec.get("name"))
                for spec in (recipe.parameters or [])
                if _as_bool(spec.get("required")) and spec.get("default") is None
            ]
            suffix = f" [required: {', '.join(required)}]" if required else ""
            catalog.append(f"{recipe.name} ({description[:160]}{suffix})")
        discovery = " | ".join(catalog)[:2000]
        base = (
            "Manage and run reusable single-agent workflow recipes. "
            "action='list' shows available recipes (⏰ marks scheduled ones); "
            "action='run' name=<recipe> runs one in a fresh isolated background "
            "session (result posted back when done); pass params={..} to fill a "
            "parameterized recipe's inputs; "
            "action='add' name=.. description=.. body=.. saves a new recipe "
            "(compose the body as the step-by-step instructions the agent will follow; "
            "optionally parameters=[{name,type,required,default,options}] to declare {name} "
            "inputs the body uses); "
            "action='schedule' name=<recipe> schedule='0 9 * * *' runs a recipe "
            "automatically on a cron/interval schedule (result delivered to your "
            "active channels); action='unschedule' name=<recipe> stops it; "
            "action='status' shows scheduled workflows and their last/next run "
            "(add name=<recipe> for that one's recent run history), plus any "
            "interrupted runs; action='resume' name=<recipe> resumes an interrupted "
            "run from where it stopped (never redoes completed steps)."
        )
        if not discovery:
            return base
        return f"Available workflows — run one when the user's request matches: {discovery}. {base}"

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "run", "add", "schedule", "unschedule", "status", "resume"],
                },
                "name": {
                    "type": "string",
                    "description": (
                        "Recipe name (for 'run' / 'add' / 'schedule' / 'unschedule'; "
                        "optional for 'status' to see one workflow's run history)."
                    ),
                },
                "description": {
                    "type": "string",
                    "description": "Short one-line description (for 'add').",
                },
                "body": {
                    "type": "string",
                    "description": (
                        "For 'add': the recipe body — the natural-language, "
                        "step-by-step instructions a single agent will follow."
                    ),
                },
                "params": {
                    "type": "object",
                    "description": (
                        "For 'run': values for a parameterized recipe's declared "
                        "parameters, e.g. {'pr_number': 566}. A missing value falls "
                        "back to that parameter's default; a required parameter with "
                        "no default errors (the run does not start)."
                    ),
                },
                "parameters": {
                    "type": "array",
                    "description": (
                        "For 'add': declare typed inputs the recipe body references as "
                        "{name} placeholders. Each: {name (must start with a letter or "
                        "underscore, then letters/digits/underscores), type "
                        "(string|integer|float|boolean|select), required (bool), "
                        "default, options (for select)}. Give a `default` to any param "
                        "the recipe should be schedulable with (unattended runs supply "
                        "no values)."
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "type": {
                                "type": "string",
                                "description": (
                                    "One of string|integer|float|boolean|select "
                                    "(aliases int/number accepted; anything "
                                    "unrecognized is treated as string)."
                                ),
                            },
                            "required": {"type": "boolean"},
                            "default": {},
                            "options": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["name"],
                    },
                },
                "replace": {
                    "type": "boolean",
                    "description": "For 'add': overwrite an existing recipe of the same name.",
                },
                "schedule": {
                    "type": "string",
                    "description": (
                        "For 'schedule': cron expression (e.g. '0 9 * * *'), interval "
                        "seconds (e.g. '3600'), or a one-shot ('at:+300' / 'at:<ISO>')."
                    ),
                },
                "notify_channels": {
                    "anyOf": [
                        {"type": "string", "enum": list(_NOTIFY_CHANNELS)},
                        {
                            "type": "array",
                            "items": {"type": "string", "enum": list(_NOTIFY_CHANNELS)},
                        },
                    ],
                    "description": (
                        "For 'schedule': where to deliver the result — a single channel "
                        "name or a list (defaults to all active channels). Use '*' alone "
                        "for all active; don't combine '*' with specific channels."
                    ),
                },
            },
            "required": ["action"],
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(tier="standard")

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "")
        if action == "list":
            return self._list()
        if action == "run":
            return await self._run(kwargs)
        if action == "add":
            return self._add(kwargs)
        if action == "schedule":
            return self._schedule(kwargs)
        if action == "unschedule":
            return self._unschedule(kwargs)
        if action == "status":
            return self._status(kwargs)
        if action == "resume":
            return await self._resume(kwargs)
        return (
            f"Unknown action: {action!r}. "
            "Use 'list', 'run', 'add', 'schedule', 'unschedule', 'status', or 'resume'."
        )

    def _list(self) -> str:
        recipes = _load_recipes(self._dir)
        if not recipes:
            return f"No workflow recipes found. Add one to {self._dir}/*.md"
        scheduled = self._scheduled_map()
        lines = []
        for r in recipes.values():
            # _scheduled_map is keyed by the CANONICAL workflow_recipe id, so look
            # up the collapsed form of the (possibly irregular-whitespace)
            # frontmatter name — else the ⏰ suffix would be dropped for such a
            # recipe. Collapse is a no-op for normal slug names.
            sched = scheduled.get(" ".join(r.name.split()))
            suffix = f"  ⏰ {sched}" if sched else ""
            lines.append(f"- {r.name}: {r.description}{suffix}")
        return "Available workflows:\n" + "\n".join(lines)

    def _scheduled_map(self) -> dict[str, Any]:
        """Canonical recipe id -> its schedule, for workflow-backed cron jobs.

        Keyed off each job's structured ``workflow_recipe`` field — NOT the job
        name — so a plain cron job that merely happens to be named ``wf-…`` can't
        be mis-annotated as a scheduled workflow. ``schedule`` stores the CANONICAL
        (whitespace-collapsed) id there, so callers must look up the collapsed
        recipe name (see ``_list``).
        """
        if self._scheduler is None:
            return {}
        try:
            jobs = self._scheduler.list_jobs()
        except Exception:  # noqa: BLE001 - listing is best-effort UI sugar
            return {}
        out: dict[str, Any] = {}
        for j in jobs:
            recipe = j.get("workflow_recipe")
            if recipe:
                out[recipe] = j.get("schedule")
        return out

    def _status(self, kwargs: dict[str, Any]) -> str:
        # Normalize the name to the canonical workflow id (collapse whitespace,
        # cap) — the SAME as run / resume / plan storage — so a `status
        # name=<recipe>` query resolves scheduler entries + on-demand history that
        # were recorded under the collapsed id.
        name = " ".join(str(kwargs.get("name") or "").split())[:200]
        # Scheduled workflows (needs the scheduler); in-flight on-demand runs
        # are scheduler-independent, so status still works with cron off.
        wf_jobs: list[dict[str, Any]] = []
        sched_read_failed = False
        if self._scheduler is not None:
            try:
                jobs = self._scheduler.list_jobs()
                wf_jobs = [j for j in jobs if j.get("workflow_recipe")]
            except Exception:  # noqa: BLE001 - degrade to "no scheduled"; the
                # in-flight on-demand runs section (scheduler-independent) must
                # still render even if reading scheduled jobs fails.
                sched_read_failed = True
        if name:
            # On-demand history is scheduler-independent (6d-2), so a name query
            # works with cron off / for a never-scheduled recipe. Assemble the
            # scheduled detail (if any) + the durable on-demand history.
            ondemand = self._ondemand_history(name)
            job = None
            if self._scheduler is not None and not sched_read_failed:
                job = next((j for j in wf_jobs if j.get("workflow_recipe") == name), None)
            parts_detail: list[str] = []
            if job is not None:
                parts_detail.append(self._status_detail(job))
            if ondemand:
                parts_detail.append(self._ondemand_history_block(name, ondemand))
            if parts_detail:
                return "\n\n".join(parts_detail)
            # Nothing scheduled and no on-demand history recorded.
            if sched_read_failed:
                # Don't claim "not scheduled" when we simply couldn't read it.
                return f"Error: could not read scheduler status for {name!r}; try again."
            if self._scheduler is None:
                return (
                    f"Workflow {name!r} has no recorded runs. (Scheduling needs "
                    "config.cron.enabled.)"
                )
            return (
                f"Workflow {name!r} is not scheduled and has no recorded runs. Use "
                "action='status' for all scheduled workflows, or action='schedule' to add one."
            )
        # Overview: scheduled workflows + on-demand runs in flight now.
        inflight = self._inflight_runs(kwargs)
        caller = str(kwargs.get("_session_id") or "").strip()
        # One plan-store scan per render, reused for in-flight step enrichment and
        # orphan detection — but only when it can matter: step enrichment needs
        # in-flight runs, and orphan detection needs a caller (it refuses without
        # one). With neither, skip the IO entirely.
        active_plans = self._active_plans() if (inflight or caller) else []
        parts: list[str] = []
        if wf_jobs:
            parts.append(
                f"Scheduled workflows ({len(wf_jobs)}):\n"
                + "\n".join(self._status_line(j) for j in wf_jobs)
            )
        if inflight:
            run_lines = [
                f"- {' '.join(str(r.get('workflow') or '').split())} — ▶ running "
                f"{self._fmt_elapsed(r.get('elapsed_seconds', 0))}"
                f"{self._plan_step_suffix(str(r.get('task_id') or ''), active_plans)}"
                for r in inflight
            ]
            parts.append(f"Running now ({len(inflight)}):\n" + "\n".join(run_lines))
        # Interrupted runs (crashed / lost on restart) that can be resumed —
        # scoped to the caller's own runs (plan.owner == caller session).
        orphans = self._orphan_runs(active_plans, inflight, caller)
        if orphans:
            olines: list[str] = []
            for p in orphans:
                try:
                    done, total = p.progress
                except Exception:  # noqa: BLE001
                    done, total = 0, 0
                wf = " ".join(str(getattr(p, "workflow", "") or "").split())
                olines.append(
                    f"- ⚠️ {wf} — 中断于 {done}/{total} 步 — "
                    f"续跑: workflow(action='resume', name={json.dumps(wf)})"
                )
            parts.append(f"Interrupted / 中断 (resumable) ({len(orphans)}):\n" + "\n".join(olines))
        if sched_read_failed:
            # Be honest that the scheduled list is missing, not empty — prepend a
            # note whether or not there are in-flight runs to show alongside.
            parts.insert(0, "⚠️ Could not read scheduled workflows (try again).")
        if parts:
            return "\n\n".join(parts)
        if self._scheduler is None:
            return "No workflows are scheduled and none are running. (Scheduling needs config.cron.enabled.)"
        return (
            "No workflows are scheduled. Schedule one with: "
            "workflow(action='schedule', name=<recipe>, schedule='0 9 * * *')."
        )

    def _inflight_runs(self, kwargs: dict[str, Any]) -> list[dict[str, Any]]:
        """Active on-demand workflow runs (owner-scoped to the caller's session).

        Returns [] when there is no caller session id: ``list_workflow_runs``
        treats ``owner=None`` as "no filter" and returns ALL sessions' runs, so an
        unscoped call would leak other sessions' in-flight workflow names into
        this caller's status / resume output. Never query without a caller —
        consistent with orphan detection, which also refuses without one.
        """
        if self._inflight_fn is None:
            return []
        caller = str(kwargs.get("_session_id") or "").strip()
        if not caller:
            return []
        try:
            return self._inflight_fn(owner=caller) or []
        except Exception:  # noqa: BLE001 - status is read-only best-effort
            return []

    def _ondemand_history(self, recipe: str) -> list[dict[str, Any]]:
        """Durable on-demand run history for a recipe (best-effort, read-only)."""
        if self._run_history_fn is None:
            return []
        try:
            return self._run_history_fn(recipe, 5) or []
        except Exception:  # noqa: BLE001 - status is read-only best-effort
            return []

    def _ondemand_history_block(self, recipe: str, runs: list[dict[str, Any]]) -> str:
        """Render the durable on-demand run history for `status name=<recipe>`."""
        lines = [f"On-demand runs of {recipe!r} (recent):"]
        for r in reversed(runs):  # newest first
            icon = "✓" if r.get("status") == "success" else "✗"
            dur = r.get("duration_s")
            dur_s = f" ({dur}s)" if dur is not None else ""
            extra = f" {r['error_type']}" if r.get("error_type") else ""
            lines.append(
                f"  - {self._fmt_ts(r.get('triggered_at'))} {icon} {r.get('status')}{dur_s}{extra}"
            )
        return "\n".join(lines)

    def _orphan_runs(
        self, plans: list[Any], inflight: list[dict[str, Any]], caller: str
    ) -> list[Any]:
        """Interrupted workflow runs owned by ``caller`` (crashed / lost on restart).

        Takes the already-fetched ``plans`` (``_active_plans``) and ``inflight``
        (``_inflight_runs``) so ``status`` scans the plan store once per render.
        A run-as-Plan run persists its plan (keyed to its forked session); if the
        run dies its in-memory task is gone but the plan stays active. An orphan =
        a plan with ``workflow`` + ``origin_task`` set, **owned by the caller**
        (``plan.owner == caller``), and NOT in the current in-flight set.

        Owner scoping is REQUIRED: ``_active_plans`` (PlanStore.list_active) returns
        plans for ALL sessions, so without it ``status`` would leak another
        session's workflow and ``resume`` could discard another session's plan.
        """
        # Owner scoping needs a caller session; without one we can't safely
        # attribute an interrupted run, so surface nothing (never guess).
        if not plans or not caller:
            return []
        inflight_tasks = {str(r.get("task_id") or "") for r in inflight}
        # Recipes with a live run (the original still running, or a resume in
        # progress) — suppress their orphan so we don't nag about (or let resume
        # double-drive) a run that's currently being handled. ``inflight`` is
        # already owner-scoped, so this is the caller's live recipes. Collapse
        # whitespace to match ``plan.workflow`` (normalized on create/load) so an
        # irregularly-spaced recipe name still suppresses its own live run.
        inflight_recipes = {" ".join(str(r.get("workflow") or "").split()) for r in inflight}
        orphans: list[Any] = []
        for p in plans:
            wf = " ".join(str(getattr(p, "workflow", "") or "").split())
            ot = str(getattr(p, "origin_task", "") or "")
            if not wf or not ot:
                continue  # not a workflow-recipe background run
            if str(getattr(p, "owner", "") or "") != caller:
                continue  # another session's run — never surface/resume it
            if ot in inflight_tasks or wf in inflight_recipes:
                continue  # still running / being resumed — not (yet) interrupted
            orphans.append(p)
        return orphans

    def _active_plans(self) -> list[Any]:
        """Fetch active plans **once** per status render (best-effort, read-only).

        Returns [] when there is no lister or on any read error — never breaks
        the render.
        """
        if self._active_plans_fn is None:
            return []
        try:
            return self._active_plans_fn() or []
        except Exception:  # noqa: BLE001 - status is read-only best-effort
            return []

    @staticmethod
    def _plan_step_suffix(task_id: str, plans: list[Any]) -> str:
        """Live step of a run-as-Plan run, e.g. ' · 第 2/3 步：summarize CI'.

        Correlates by the run's **background_task_id** (``plan.origin_task ==
        task_id``) — NOT by recipe name. Task ids are unique and the in-flight
        runs are already owner-scoped, so this can only surface the caller's own
        plan: no other session's step title can leak in. Returns "" when there is
        no task id, no matching plan, or a malformed plan (best-effort — never
        breaks the render).
        """
        if not task_id:
            return ""
        for plan in plans:
            if getattr(plan, "origin_task", "") != task_id:
                continue
            try:
                done, total = plan.progress
            except Exception:  # noqa: BLE001 - malformed plan → no enrichment
                return ""
            # A malformed/empty plan (total missing/non-int/<=0) would render a
            # confusing "N/0 步" — bail out (best-effort UI enrichment).
            if not isinstance(total, int) or total <= 0:
                return ""
            items = getattr(plan, "items", []) or []
            for i, it in enumerate(items, 1):
                if getattr(it, "status", "") == "in_progress":
                    # Collapse ALL whitespace (LLM titles can carry \n/\t) so the
                    # run line stays single-line, then cap.
                    title = " ".join(str(getattr(it, "title", "")).split())[:60]
                    return f" · 第 {i}/{total} 步：{title}"
            return f" · {done}/{total} 步完成"
        return ""

    @staticmethod
    def _fmt_elapsed(seconds: Any) -> str:
        """Compact elapsed like '45s' / '3m' / '1h05m' from a seconds count."""
        try:
            s = int(float(seconds))
        except (TypeError, ValueError):
            return "?"
        if s < 60:
            return f"{s}s"
        if s < 3600:
            return f"{s // 60}m"
        return f"{s // 3600}h{(s % 3600) // 60:02d}m"

    @staticmethod
    def _fmt_ts(iso: Any) -> str:
        """Compact 'YYYY-MM-DD HH:MM' from an ISO timestamp, or '—' if absent.

        String-sliced (not parsed) so it's deterministic and timezone-agnostic —
        good enough for a status glance and testable without a clock.
        """
        if not isinstance(iso, str) or len(iso) < 16:
            return "—"
        return iso[:16].replace("T", " ")

    @classmethod
    def _fmt_last(cls, job: dict[str, Any]) -> str:
        last_at = job.get("last_run_at")
        if not last_at:
            return "never run"
        status = job.get("last_status")
        if status == "success":
            return f"✓ ran {cls._fmt_ts(last_at)}"
        # last_status persists as "error"; render as "failed" to match the run
        # history vocabulary so a summary line and its detail don't disagree.
        if status == "error":
            return f"✗ failed {cls._fmt_ts(last_at)}"
        return f"ran {cls._fmt_ts(last_at)}"

    @classmethod
    def _fmt_state(cls, job: dict[str, Any]) -> str:
        """Current state for the status view: prefer 'running now' (from the
        scheduler's computed ``status``) over the stale last-run summary, so an
        in-progress run isn't shown as its previous outcome."""
        if job.get("status") == "running":
            return "▶ running now"
        return cls._fmt_last(job)

    def _status_line(self, job: dict[str, Any]) -> str:
        dis = "" if job.get("enabled", True) else " (disabled)"
        return (
            f"- {job.get('workflow_recipe')} — ⏰ {job.get('schedule')}{dis} — "
            f"{self._fmt_state(job)} — next {self._fmt_ts(job.get('next_run'))}"
        )

    def _status_detail(self, job: dict[str, Any]) -> str:
        dis = "" if job.get("enabled", True) else " (disabled)"
        out = [
            f"Workflow {job.get('workflow_recipe')!r} — ⏰ {job.get('schedule')}{dis}",
            f"  last: {self._fmt_state(job)} · next: {self._fmt_ts(job.get('next_run'))}",
        ]
        if job.get("last_error"):
            out.append(f"  last error: {job['last_error']}")
        try:
            runs = self._scheduler.get_history(job.get("name"), limit=5) or []
        except Exception:  # noqa: BLE001 - history is best-effort
            runs = []
        if runs:
            out.append("  recent runs:")
            for r in reversed(runs):  # newest first
                icon = "✓" if r.get("status") == "success" else "✗"
                dur = r.get("duration_s")
                dur_s = f" ({dur}s)" if dur is not None else ""
                extra = f" {r['error_type']}" if r.get("error_type") else ""
                out.append(
                    f"  - {self._fmt_ts(r.get('triggered_at'))} {icon} "
                    f"{r.get('status')}{dur_s}{extra}"
                )
        return "\n".join(out)

    def _resolve_recipe(
        self, name: str, recipes: dict[str, Skill]
    ) -> tuple[Skill | None, str | None]:
        """Resolve a (already whitespace-collapsed) recipe name to its Skill.

        Matches by whitespace-collapsed equivalence (so a recipe whose frontmatter
        name carries irregular internal whitespace still resolves). Returns
        ``(recipe, error)``: ``error`` is set when 2+ distinct recipe names collapse
        to the same canonical id — we refuse rather than pick one, EVEN IF one is an
        exact match. Silently preferring the exact name would make the other recipe
        unreachable (user input is normalized) and could run/resume the wrong recipe
        (side-effects risk). ``recipe`` is None (no error) when nothing matches.
        """
        matches = [r for k, r in recipes.items() if " ".join(k.split()) == name]
        if len(matches) > 1:
            return None, (
                f"Error: {len(matches)} recipes collapse to the name {name!r} "
                "(whitespace-ambiguous) — rename them to distinct ids to disambiguate."
            )
        return (matches[0] if matches else None), None

    async def _run(self, kwargs: dict[str, Any]) -> str:
        # Normalize the recipe name the SAME way plans store `workflow` and
        # `_resume` resolves it (collapse whitespace, cap), so run / status /
        # resume / plan storage all share one canonical workflow id — a
        # legacy/hand-edited recipe name with irregular whitespace can't fragment
        # the identifier across those surfaces.
        name = " ".join(str(kwargs.get("name") or "").split())[:200]
        if not name:
            return "Error: 'name' is required for run."
        recipe, ambiguous = self._resolve_recipe(name, _load_recipes(self._dir))
        if ambiguous:
            return ambiguous
        if recipe is None:
            return f"Error: workflow {name!r} not found. Use action='list' to see recipes."
        # Parameterization (5b): resolve declared params against the caller's
        # ``params`` (use the provided value, else the parameter's default;
        # required with neither errors), then substitute ``{name}`` into the
        # body. Plain-text, no template engine.
        param_values, param_errors = _resolve_params(
            getattr(recipe, "parameters", None), kwargs.get("params")
        )
        if param_errors:
            return f"Error: {'; '.join(param_errors)}."
        # Shared public helper (also used by SpawnTool) — no private coupling.
        origin = origin_from_kwargs(kwargs)
        if origin is None:
            return (
                "Error: no originating channel; run a workflow from a chat / web / "
                "Teams context so its result can be delivered back."
            )
        # Forward the caller's session (so the background task is *owned* — an
        # unowned task is cancellable from any session) and the registry-injected
        # metadata (cron/heartbeat provenance the ApprovalGate keys off), mirroring
        # SpawnTool. Our workflow marker is merged on top.
        injected = kwargs.get("_metadata")
        metadata = dict(injected) if isinstance(injected, dict) else {}
        metadata["workflow"] = name
        # Owner = the caller session, normalized the SAME way PlanStore stores
        # Plan.owner (stripped) and _inflight_runs scopes (list_workflow_runs owner)
        # so owner-scoped status/resume matching can't diverge on stray whitespace.
        # Empty → an unowned task (cancellable from any session), as before.
        caller = str(kwargs.get("_session_id") or "").strip()
        metadata["workflow_owner"] = caller
        # Capability caps (Task 9): inject the recipe's normalized limits as
        # workflow_* keys so the harness (max_runtime/max_output via
        # background_tasks.start) and the spawn palette scoping (allowed_tools via
        # runtime._spawn_agent) can enforce them — none of it touches the core loop.
        # Nothing injected when the recipe declares no valid limits (gates inert).
        metadata.update(_normalize_limits(getattr(recipe, "limits", None)))
        # run-as-Plan: a recipe that opts in (`plan: true`) gets a plan-driving
        # preamble prepended so the spawned run creates + steps through a
        # persisted Plan keyed to its own session (its plan file is the audit +
        # progress source `status` reads back). Plain recipes are unchanged.
        prompt = _substitute_params(recipe.content, param_values)
        if getattr(recipe, "plan_mode", False):
            prompt = _plan_preamble(name) + prompt
        task_id, message = await self._background_fn(
            agent="default",
            prompt=prompt,
            origin=origin,
            metadata=metadata,
            parent_session=caller or None,
        )
        if task_id is None:
            # start() returns (None, <error message>) on shutdown / capacity —
            # don't claim the workflow is running when it isn't.
            return f"Workflow {name!r} could not start: {message}"
        return f"▶ Workflow {name!r} started in an isolated background session.\n{message}"

    async def _resume(self, kwargs: dict[str, Any]) -> str:
        # Normalize the recipe name the SAME way plans store `workflow` (collapse
        # whitespace, cap) so the orphan match below (plan.workflow == name) is
        # exact even for the already-collapsed name the status hint suggests.
        name = " ".join(str(kwargs.get("name") or "").split())[:200]
        if not name:
            return "Error: 'name' (the recipe to resume) is required."
        recipe, ambiguous = self._resolve_recipe(name, _load_recipes(self._dir))
        if ambiguous:
            return ambiguous
        if recipe is None:
            return (
                f"Error: workflow {name!r} not found (its recipe may have been deleted); "
                "cannot resume."
            )
        caller = str(kwargs.get("_session_id") or "").strip()
        if not caller:
            # No caller session → an interrupted run can't be attributed to this
            # caller (orphan detection refuses without one) and _inflight_runs is
            # empty too. Return early to skip a needless plan-store scan.
            return (
                f"No interrupted run of {name!r} to resume. Use action='status' to see "
                "interrupted runs."
            )
        inflight = self._inflight_runs(kwargs)
        mine = [
            p
            for p in self._orphan_runs(self._active_plans(), inflight, caller)
            if " ".join(str(getattr(p, "workflow", "") or "").split()) == name
        ]
        if not mine:
            # A live run of this recipe suppresses its orphan (see _orphan_runs),
            # so a bare "no interrupted run" would be misleading. Distinguish the
            # two: if the recipe is currently in-flight (owner-scoped), say it's
            # already running rather than implying there's nothing to resume.
            if any(" ".join(str(r.get("workflow") or "").split()) == name for r in inflight):
                return (
                    f"Workflow {name!r} is already running — wait for it to finish (see "
                    "action='status'); there's nothing to resume while it's in flight."
                )
            return (
                f"No interrupted run of {name!r} to resume. Use action='status' to see "
                "interrupted runs."
            )
        if len(mine) > 1:
            # Multiple interrupted runs of the same recipe — resuming would guess
            # which one (and could re-drive the wrong side effects). Refuse rather
            # than pick blindly; per-run selection is not yet supported.
            return (
                f"Error: {len(mine)} interrupted runs of {name!r} — resume can't tell which "
                "one. (Per-run selection isn't supported yet; run it fresh, or wait for a "
                "future per-run resume.)"
            )
        orphan = mine[0]
        origin = origin_from_kwargs(kwargs)
        if origin is None:
            return (
                "Error: no originating channel (need _channel + _channel_id) so the "
                "resumed run's result can be delivered back."
            )
        injected = kwargs.get("_metadata")
        metadata = dict(injected) if isinstance(injected, dict) else {}
        metadata["workflow"] = name
        # Owner = the stripped caller session (computed above), matching how
        # PlanStore stores Plan.owner and _inflight_runs scopes — so the resumed
        # run's owner can't diverge from the orphan/status scoping on whitespace.
        metadata["workflow_owner"] = caller
        # Capability caps (Task 9): same limit injection as `run` so a resumed run
        # is bounded identically to the original (limits re-resolve from the recipe,
        # which is the current source of truth). Inert when the recipe has none.
        metadata.update(_normalize_limits(getattr(recipe, "limits", None)))
        # Deferred supersede (6d-3): hand the interrupted plan's session id to the
        # resumed run so it retires the old plan ONLY AFTER it persists its own
        # successor plan (see PlanTool._create). Retiring here — before the run has
        # created anything — would hide the old plan if the resume crashed early,
        # leaving nothing resumable. Tying supersede to "the successor exists"
        # guarantees exactly one resumable orphan through a crash at any point.
        old_sid = str(getattr(orphan, "session_id", "") or "")
        if old_sid:
            metadata["workflow_supersede_prev"] = old_sid
        # Apply the same parameter resolution/substitution as `run` so a
        # parameterized recipe's `{param}`s are filled (not left raw). Values are
        # the caller-supplied `params`, else each parameter's default — the
        # original run's param values are NOT persisted, so the user must
        # re-provide any non-default params when resuming.
        param_values, param_errors = _resolve_params(
            getattr(recipe, "parameters", None), kwargs.get("params")
        )
        if param_errors:
            return f"Error: {'; '.join(param_errors)}."
        # Re-drive: the resume preamble carries the interrupted plan's state (done
        # vs remaining + idempotency warning), then the substituted recipe body. A
        # fresh isolated run continues the remaining steps (no loop-level plan
        # takeover).
        prompt = _resume_preamble(name, orphan) + _substitute_params(recipe.content, param_values)
        task_id, message = await self._background_fn(
            agent="default",
            prompt=prompt,
            origin=origin,
            metadata=metadata,
            parent_session=caller or None,
        )
        if task_id is None:
            return f"Workflow {name!r} could not resume: {message}"
        # NOTE: the old interrupted plan is NOT retired here. The resumed run
        # retires it (via workflow_supersede_prev) only after it persists its own
        # successor plan — so a crash before that leaves the old plan resumable.
        try:
            done, total = orphan.progress
        except Exception:  # noqa: BLE001
            done, total = 0, 0
        return (
            f"▶ Resuming workflow {name!r} from where it stopped ({done}/{total} steps were "
            f"done) in a fresh isolated background session.\n{message}"
        )

    def _add(self, kwargs: dict[str, Any]) -> str:
        # Strip first, then pre-cap the raw name before slugifying: stripping
        # first keeps leading whitespace from eating the cap budget (a name that
        # is 512 spaces + real text would otherwise slice down to all-whitespace
        # and be wrongly rejected), and the cap still bounds the regex work in
        # _slugify against a pathological megastring (the slug is capped again).
        slug = _slugify(str(kwargs.get("name") or "").strip()[:512])
        if not slug:
            return (
                "Error: 'name' is required and must contain letters or digits "
                "(it becomes the recipe id you run)."
            )
        # The shared skill parser strips the body on load (skills/loader.py), so
        # run receives a stripped prompt regardless of what we save — match that
        # here. Strip, then cap, then re-check non-empty so a body that is all
        # whitespace before the cap can't slip through.
        body = str(kwargs.get("body", "") or "").strip()[:_MAX_BODY_LEN]
        if not body:
            return "Error: 'body' is required — the step-by-step instructions the agent follows."
        # Collapse all whitespace to single spaces — description is one line (it
        # appears in the list output; a multi-line value would become a YAML
        # block scalar and break formatting).
        description = " ".join(str(kwargs.get("description", "") or "").split())[:_MAX_DESC_LEN]
        # Optional typed parameters (PR2): validated + normalized, then written
        # into the frontmatter so ``run`` can bind + substitute them.
        param_specs, param_err = _normalize_param_specs(kwargs.get("parameters"))
        if param_err:
            return f"Error: {param_err}"
        path = self._dir / f"{slug}.md"
        fm: dict[str, Any] = {"name": slug, "description": description}
        if param_specs:
            fm["parameters"] = param_specs
        # width=10**6 keeps the (single-line) description from being wrapped/
        # folded by the YAML dumper.
        frontmatter = yaml.safe_dump(
            fm,
            allow_unicode=True,
            sort_keys=False,
            width=10**6,
        ).strip()
        content = f"---\n{frontmatter}\n---\n{body}\n"
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            # e.g. a parent path component is a file — on Windows this surfaces
            # as FileExistsError, so keep it out of the write's collision branch.
            return f"Error: could not save workflow {slug!r}: {exc}"
        try:
            if _as_bool(kwargs.get("replace")):
                # Atomic durable overwrite: write to a securely-created unique
                # temp file in the same dir (NamedTemporaryFile owns the fd, so
                # it can't leak even if the write raises), then os.replace() it
                # into place. Cleanup is best-effort and can't mask the original
                # error.
                tmp: Path | None = None
                try:
                    with tempfile.NamedTemporaryFile(
                        dir=self._dir,
                        suffix=".md.tmp",
                        delete=False,
                        mode="w",
                        encoding="utf-8",
                    ) as fh:
                        tmp = Path(fh.name)
                        fh.write(content)
                    os.replace(tmp, path)
                finally:
                    if tmp is not None:
                        tmp.unlink(missing_ok=True)
            else:
                # Atomic exclusive create — no TOCTOU window vs a concurrent add.
                with open(path, "x", encoding="utf-8") as fh:
                    fh.write(content)
        except FileExistsError:
            return f"Error: workflow {slug!r} already exists. Pass replace=true to overwrite."
        except OSError as exc:
            return f"Error: could not save workflow {slug!r}: {exc}"
        if param_specs:
            pnames = ", ".join(str(p["name"]) for p in param_specs)
            return (
                f"✅ Saved workflow {slug!r} with parameters ({pnames}). Run it with: "
                f"workflow(action='run', name='{slug}', params={{…}})."
            )
        return f"✅ Saved workflow {slug!r}. Run it with: workflow(action='run', name='{slug}')."

    def _schedule(self, kwargs: dict[str, Any]) -> str:
        if self._scheduler is None:
            return (
                "Error: scheduling needs the cron subsystem — enable config.cron.enabled "
                "and restart."
            )
        name = " ".join(str(kwargs.get("name") or "").split())[:200]
        if not name:
            return "Error: 'name' (the recipe to schedule) is required."
        schedule = str(kwargs.get("schedule", "")).strip()
        if not schedule:
            return (
                "Error: 'schedule' is required — a cron expression (e.g. '0 9 * * *'), "
                "interval seconds ('3600'), or a one-shot ('at:+300' or 'at:<ISO>')."
            )
        # Resolve the recipe the SAME way run/resume do (canonical id + ambiguity
        # refusal) so a recipe runnable via its canonical id is also schedulable.
        # The job stores the CANONICAL id (`name`, below), which the scheduler's
        # resolver collapse-matches at fire time — a consistent round-trip that
        # keeps schedule/status/unschedule on the one identifier.
        recipe, ambiguous = self._resolve_recipe(name, _load_recipes(self._dir))
        if ambiguous:
            return ambiguous
        if recipe is None:
            return f"Error: workflow {name!r} not found. Use action='list' to see recipes."
        # Unattended-run guard (5b): a scheduled run supplies no param values, so
        # a required param with no default could never resolve — refuse to
        # schedule it (clearer than a silent failure on every fire).
        needs_value = [
            str(p.get("name"))
            for p in (getattr(recipe, "parameters", None) or [])
            if _as_bool(p.get("required")) and p.get("default") is None
        ]
        if needs_value:
            return (
                f"Error: workflow {name!r} needs parameter(s) {needs_value} at run time, "
                "but scheduled runs are unattended. Give each a `default` in the recipe "
                "to schedule it."
            )
        # Normalize notify_channels: absent/None means "all active channels"; a
        # bare string (schema-violating but common from LLMs) becomes a 1-element
        # list. An *explicitly empty* value ("" / []) is rejected rather than
        # silently broadening delivery to all channels; other types error too.
        notify = kwargs.get("notify_channels")
        if notify is None:
            notify_channels = None
        elif isinstance(notify, str):
            if not notify.strip():
                return (
                    "Error: 'notify_channels' is empty — omit it for all active "
                    f"channels, or name specific ones ({_NOTIFY_CHANNELS_HELP})."
                )
            notify_channels = [notify]
        elif isinstance(notify, list):
            if not notify:
                return (
                    "Error: 'notify_channels' is empty — omit it for all active "
                    f"channels, or name specific ones ({_NOTIFY_CHANNELS_HELP})."
                )
            notify_channels = [str(c) for c in notify]
        else:
            return "Error: 'notify_channels' must be a string or a list of channel names."
        # Validate/normalize (strip + lower) each entry against the supported set
        # and reject unknowns clearly — otherwise the scheduler coerces a typo to
        # CLI and the scheduled result silently lands on the wrong channel.
        if notify_channels is not None:
            normalized: list[str] = []
            for c in notify_channels:
                cc = c.strip().lower()
                if cc not in _VALID_NOTIFY_CHANNELS:
                    return (
                        f"Error: unknown notify_channels value {c!r}. "
                        f"Valid values: {_NOTIFY_CHANNELS_HELP} ('*' = all active)."
                    )
                if cc not in normalized:  # de-dupe (avoids duplicate deliveries)
                    normalized.append(cc)
            if "*" in normalized and len(normalized) > 1:
                # '*' expands to all active channels, so it can't be meaningfully
                # combined with specific ones — the extras would be discarded.
                return (
                    "Error: notify_channels '*' (all active) can't be combined with "
                    "specific channels."
                )
            notify_channels = normalized or None
        try:
            # workflow_recipe (not a static prompt): the scheduler re-resolves the
            # recipe body fresh at each fire, so edits take effect without rescheduling.
            # Key the job off the CANONICAL id (`name`), not the raw frontmatter
            # `recipe.name`, so `status name=<recipe>` / unschedule-by-name and the
            # scheduler resolver all share the one identifier run/resume use.
            self._scheduler.add_job(
                name=f"wf-{name}",
                schedule=schedule,
                workflow_recipe=name,
                notify_channels=notify_channels,
                channel=kwargs.get("_channel"),
                channel_id=kwargs.get("_channel_id"),
                description=f"workflow: {name}",
            )
        except ValueError as exc:
            # Bad cron/interval expression, reserved name, etc.
            return f"Error: could not schedule {name!r}: {exc}"
        # Reflect the actual delivery target. '*' means all active channels —
        # spell that out rather than echo a bare "*".
        where = (
            ", ".join(notify_channels)
            if notify_channels and notify_channels != ["*"]
            else "your active channels"
        )
        return (
            f"✅ Scheduled workflow {name!r} ({schedule}). Its result posts to "
            f"{where} each run. Stop it with: "
            f"workflow(action='unschedule', name='{name}')."
        )

    def _unschedule(self, kwargs: dict[str, Any]) -> str:
        if self._scheduler is None:
            return "Error: scheduling needs the cron subsystem (config.cron.enabled)."
        # Canonicalize the same way schedule stores the job (wf-<canonical id>) so
        # unschedule by a whitespace-variant of the name still removes it. A raw
        # job id copied from `cron list` is already canonical (schedule stored it).
        name = " ".join(str(kwargs.get("name") or "").split())[:200]
        if not name:
            return "Error: 'name' (the recipe to unschedule) is required."
        # schedule() always registers the job as ``wf-<recipe>``, so try the
        # prefixed form first; also try the raw name so a job id copied from
        # `cron list` works. Prefixed-first correctly handles a recipe whose own
        # name starts with "wf-" (scheduled as wf-wf-<name>). Don't require the
        # recipe to still exist — allow clearing a dangling schedule.
        for job_name in (f"wf-{name}", name):
            try:
                self._scheduler.remove_job(job_name)
            except ValueError:
                continue
            return f"✅ Unscheduled workflow {name!r}."
        return f"Error: workflow {name!r} is not scheduled."


def maybe_register_workflow_tool(
    registry: Any,
    *,
    enabled: bool,
    workflow_dir: Path,
    background_fn: BackgroundFn,
    scheduler: Any = None,
    inflight_fn: Any = None,
    active_plans_fn: Any = None,
    run_history_fn: Any = None,
) -> bool:
    """Register ``WorkflowTool`` iff ``enabled``. Returns whether it registered.

    Extracted from ``runtime`` so the feature-flag gate is behaviorally testable.
    ``scheduler`` (the SchedulerService, or None when cron is disabled) enables
    the ``schedule`` / ``unschedule`` actions. ``inflight_fn`` (BackgroundTaskManager.
    list_workflow_runs) surfaces in-flight on-demand runs in ``status``.
    ``active_plans_fn`` (PlanStore.list_active) shows a run-as-Plan run's live
    step (第 K/M 步), matched to the run by ``plan.origin_task``. ``run_history_fn``
    (WorkflowRunStore.get_history) shows a recipe's durable on-demand run history.
    """
    if not enabled:
        return False
    registry.register(
        WorkflowTool(
            workflow_dir=workflow_dir,
            background_fn=background_fn,
            scheduler=scheduler,
            inflight_fn=inflight_fn,
            active_plans_fn=active_plans_fn,
            run_history_fn=run_history_fn,
        )
    )
    return True
