---
name: fix-societas-bug
description: Fix a Societas bug end-to-end from ADO investigation through verified PR review.
plan: true
parameters:
- name: bug_id
  type: string
  required: true
- name: repo_path
  type: string
  required: false
---
Complete Societas bug #{bug_id} end-to-end. The optional repository path is
`{repo_path}`. If it is empty, use the agent's configured `ado_repo_local_path`;
if that is also unavailable, ask the user instead of guessing a path.

Create this seven-item plan at the start and update each item as work progresses.
Do not reuse a stale plan from another task.

1. **Pick up**: Read the ADO bug description, repro steps, comments, attachments,
   and linked items. Confirm its state and assignee.
2. **Root cause**: Analyze the Societas source, logs, and relevant git history or
   blame to identify the root cause.
3. **Repro**: Follow the repository's `AGENTS.md`, `CLAUDE.md`, and Societas skills
   to reproduce the bug appropriately. Record every process, port, and command
  started for local testing. Prefer starting multiple services in one managed shell command
  and `wait` for them. If a command must run longer than ~10 minutes, use
  `shell(timeout=0, ...)` so ShellTool tracks the PID and can terminate it on cancellation;
  avoid `nohup`, launchd, or other out-of-band detached mechanisms.
4. **Fix**: Choose the smallest correct fix from the root cause, code structure,
   and repository rules. This recipe does not prescribe a code solution.
5. **Verify**: Choose verification depth from the change risk and repository
   standards. Inspect existing coverage and add a regression test only when the
   agent judges it necessary. Exercise the real production path; do not present a
   temporary script that duplicates the implementation as proof of correctness.
6. **PR**: Before committing, verify the checkout is not on `dev` or `main`; create
   a feature branch that follows Societas conventions when needed. Commit, push,
   open an ADO PR, and link the bug. Never push directly to the target branch.
7. **Review**: Check CI, policies, and review comments. Leave the workflow
   `in_progress` or `blocked` while any required check is unresolved; do not report
   completion prematurely.

Consequential operations remain subject to the normal approval policy. Use the
Societas repository's own instructions and skills for debugging, commits, and PRs
instead of duplicating those changing details in this recipe.

## Cleanup

On success, failure, or cancellation, release resources created by this run:

- Stop backend/frontend servers, browsers, debuggers, watchers, and other local
  processes started by this run, then confirm their ports are free.
- Remove temporary files, scripts, test artifacts, and task-only directories.
- Clean up a temporary worktree or branch only after confirming it has no
  uncommitted work. Never remove the user's pre-existing worktrees, branches,
  stashes, or uncommitted files.
- Do not rewrite the user's primary checkout or leave a stale plan/checkpoint.
- List released resources in the final response. If something cannot be released
  safely, report its path, PID or port, and the reason.