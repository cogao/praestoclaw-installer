"""Local persistent memory tool for a Teams group conversation.

The current group is resolved from trusted runtime metadata. The model cannot
select another conversation id, so each group's local ``MEMORY.md`` remains
isolated from every other group and from personal memory.
"""

from __future__ import annotations

from typing import Any

from praestoclaw.agent.memory_edits import (
    add_memory_entry,
    remove_memory_entry,
    replace_memory_entry,
)
from praestoclaw.agent.praesto_tag_exp_group_store import PraestoTagExpGroupStore
from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.praesto_tag_exp import praesto_tag_exp_is_active
from praestoclaw.security.risk import RiskAssessment, RiskScore


class GroupMemoryTool(Tool):
    """Manage the current group's isolated local persistent memory."""

    risk_range = (0, 2)

    def __init__(self, store: PraestoTagExpGroupStore) -> None:
        self._store = store

    @property
    def name(self) -> str:
        return "group_memory"

    @property
    def description(self) -> str:
        return (
            "Manage persistent memory for THIS Teams group. It is local, private "
            "to this group, isolated from personal memory and every other group, "
            "and injected into every turn. Actions match the personal memory tool: "
            "add (append entry), replace (update entry), remove (delete entry). "
            "The group is determined automatically; you cannot target another group. "
            "Write memories as declarative facts, not instructions."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=10, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(1, reason="Write to the current group's local memory file")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["add", "replace", "remove"],
                    "description": "Action to perform.",
                },
                "content": {
                    "type": "string",
                    "description": "Entry to add (for 'add' action).",
                },
                "old_text": {
                    "type": "string",
                    "description": "Substring to find (for 'replace' and 'remove').",
                },
                "new_text": {
                    "type": "string",
                    "description": "Replacement text (for 'replace' action).",
                },
            },
            "required": ["action"],
        }

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata") or {}
        if not praesto_tag_exp_is_active(metadata):
            return "group_memory is only available inside a group shared-employee session."

        cid = str(metadata.get("cid") or "").strip()
        if not cid:
            return "group_memory: no group conversation id is available for this turn."

        action = str(kwargs.get("action") or "").strip().lower()
        existing = self._store.read_memory(cid)
        if action == "add":
            content = str(kwargs.get("content") or kwargs.get("text") or "")
            edit = add_memory_entry(existing, content, "group memory")
        elif action == "replace":
            edit = replace_memory_entry(
                existing,
                str(kwargs.get("old_text") or ""),
                str(kwargs.get("new_text") or ""),
                "group memory",
            )
        elif action == "remove":
            edit = remove_memory_entry(existing, str(kwargs.get("old_text") or ""), "group memory")
        else:
            return f"Error: unknown action '{action}'. Use add, replace, or remove."

        if edit.content is not None:
            self._store.write_memory(cid, edit.content)
        return edit.message
