"""Tiny helper: infer the gateway environment label from a cloud URL.

Used by client-side telemetry to tag A2A events with the gateway they were
sent through, so dashboards can split client_agent's A2A success rate by
staging vs production without back-correlating URLs.
"""

from __future__ import annotations

from urllib.parse import urlsplit


def infer_gateway_env(cloud_url: str | None) -> str:
    """Return ``"staging" | "production" | "local" | "unknown"``.

    Recognises the Azure App Service origin hostnames and Azure Front Door
    endpoints used by the PraestoClaw gateway deployments, plus the loopback
    URLs used in dev / multi-instance testing.
    """
    if not cloud_url:
        return "unknown"
    parts = urlsplit(cloud_url)
    host = (parts.hostname or "").lower()

    if not host:
        return "unknown"

    # Staging is reachable both via the App Service origin hostname and via the
    # Azure Front Door endpoint that now fronts it for client connections. The
    # origin hostname is still used by deploy tooling and older configs, so
    # recognise both.
    if (
        host.startswith("praestoclawgatewaystaging")
        or host == "default-webapp-endpoint-0f4bf5c3-f5ddb5cufdhfgbdb.b02.azurefd.net"
    ):
        return "staging"
    if (
        host.startswith("praestoclawgatewayproduction")
        or host == "default-webapp-endpoint-612f136f-d9a5b4age2h0adas.b02.azurefd.net"
    ):
        return "production"
    if host == "localhost" or host == "127.0.0.1" or host.startswith("0."):
        return "local"
    return "unknown"
