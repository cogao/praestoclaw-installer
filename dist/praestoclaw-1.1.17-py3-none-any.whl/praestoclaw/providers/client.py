"""
OpenAI-compatible unified provider.

Supports:
- GitHub Copilot  — gpt-* models via Responses API; claude-* models via
                    Copilot's OpenAI-compatible Chat Completions endpoint
- OpenAI direct   — chat/completions + Responses API
- Azure OpenAI / Azure AI Foundry — chat/completions + Responses API

Design follows nanobot (HKUDS/nanobot) provider patterns:
- choices[0]-first content merge; tool_calls merged across all choices
- max_completion_tokens for gpt-5.x / o-series (not max_tokens)
- temperature suppressed for reasoning models (gpt-5.x, o-series, reasoning_effort)
- empty-content sanitization (None for assistant+tools, "(empty)" otherwise)
- reasoning_effort forwarded as {"effort": ...} on Responses API
- reasoning_content extracted from Responses API output items
"""

from __future__ import annotations

import asyncio
import json
import time
from collections.abc import AsyncIterator
from typing import Any

from loguru import logger

from praestoclaw.config.schema import ProvidersConfig
from praestoclaw.providers.base import LLMChunk, LLMProvider, LLMResponse, ToolCallRequest
from praestoclaw.providers.resolver import resolve_credentials, resolve_model_chain
from praestoclaw.providers.usage import TokenUsageTracker

_COPILOT_TRANSPORT_API_KEY = "copilot-transport"
_CLOSE_ATTEMPTS = 2

# ── Routing ────────────────────────────────────────────────────────────────────


def _requires_responses_api(model_name: str) -> bool:
    """True for models that require /v1/responses regardless of provider.

    Applies to all *-codex variants and gpt-5.x-pro variants.
    """
    n = model_name.lower()
    return "codex" in n or (n.startswith("gpt-5") and n.endswith("-pro"))


def _api_model_name(resolved_model: str) -> str:
    for prefix in ("github_copilot/", "github/", "openai/", "azure/", "azure_ai/"):
        if resolved_model.startswith(prefix):
            return resolved_model.removeprefix(prefix)
    return resolved_model


def _should_prefer_responses_api(resolved_model: str) -> bool:
    name = _api_model_name(resolved_model).lower()
    if resolved_model.startswith(("github/", "github_copilot/")):
        if name.startswith("gpt-"):
            return True
        if name.startswith("claude-"):
            return False
    return _requires_responses_api(name)


def _is_chat_unsupported_error(exc: Exception) -> bool:
    body = getattr(exc, "body", None)
    if isinstance(body, dict):
        error = body.get("error", {})
        code = str(error.get("code", "")).lower()
        message = str(error.get("message", "")).lower()
        if code == "unsupported_api_for_model":
            return True
        if "/chat/completions" in message:
            return True
    text = str(exc).lower()
    return "unsupported_api_for_model" in text or "/chat/completions endpoint" in text


# ── Parameter helpers (nanobot patterns) ──────────────────────────────────────

# Model families that require max_completion_tokens instead of max_tokens.
_COMPLETION_TOKENS_FAMILIES: tuple[str, ...] = ("gpt-5", "o1", "o2", "o3", "o4")


def _uses_completion_tokens(model_name: str) -> bool:
    n = model_name.lower()
    return any(n.startswith(f) for f in _COMPLETION_TOKENS_FAMILIES)


def _supports_temperature(model_name: str, reasoning_effort: str | None) -> bool:
    """False for reasoning models — temperature is ignored or rejected."""
    if reasoning_effort and reasoning_effort != "none":
        return False
    n = model_name.lower()
    return not any(n.startswith(f) for f in ("gpt-5", "o1", "o2", "o3", "o4"))


# Models that restrict the set of accepted reasoning_effort values. Sending an
# unsupported value yields a 400 from the provider, e.g.
#   github/claude-opus-4.7: only "medium" is accepted (low/high → 400).
# Map the model-name prefix (after stripping the "<provider>/" prefix) to the
# set of values that provider/model actually accepts.
_REASONING_EFFORT_SUPPORTED: dict[str, frozenset[str]] = {
    "claude-opus-4.7": frozenset({"medium"}),
}

# Ordering for nearest-match clamping (low < medium < high).
_EFFORT_ORDER: tuple[str, ...] = ("low", "medium", "high")


def _clamp_reasoning_effort(model_name: str, effort: str | None) -> str | None:
    """Clamp reasoning_effort to a value the model actually supports.

    Some models accept only a subset of {low, medium, high} and 400 on the
    rest. When the requested value isn't supported we pick the closest
    supported value by ordinal distance instead of failing the request.
    Pass-through for None / "none" / unrestricted models.
    """
    if not effort or effort == "none":
        return effort
    n = model_name.lower()
    for prefix, supported in _REASONING_EFFORT_SUPPORTED.items():
        if not n.startswith(prefix):
            continue
        if effort in supported:
            return effort
        try:
            target_idx = _EFFORT_ORDER.index(effort)
        except ValueError:
            # Unknown value — just hand back any supported one.
            return next(iter(supported))
        ordered = [e for e in supported if e in _EFFORT_ORDER]
        if not ordered:
            return next(iter(supported))
        best = min(ordered, key=lambda e: abs(_EFFORT_ORDER.index(e) - target_idx))
        logger.warning(
            "reasoning_effort '{}' not supported by {} — clamping to '{}'",
            effort,
            model_name,
            best,
        )
        return best
    return effort


# ── Message sanitization ───────────────────────────────────────────────────────


def _sanitize_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Sanitize messages for OpenAI-compatible APIs.

    - Strip internal metadata keys (``_``-prefixed and ``is_error``)
    - Empty string content: None for assistant+tool_calls, "(empty)" otherwise
      (avoids 400 errors from providers that reject empty content)
    - tool_call arguments: dict → JSON string
    """
    out = []
    for msg in messages:
        msg = {k: v for k, v in msg.items() if not k.startswith("_") and k != "is_error"}
        role = msg.get("role")
        content = msg.get("content")

        if isinstance(content, str) and not content:
            msg["content"] = None if (role == "assistant" and msg.get("tool_calls")) else "(empty)"

        if msg.get("tool_calls"):
            fixed = []
            for tc in msg["tool_calls"]:
                tc = dict(tc)
                if "function" in tc:
                    fn = dict(tc["function"])
                    if isinstance(fn.get("arguments"), dict):
                        fn["arguments"] = json.dumps(fn["arguments"])
                    tc["function"] = fn
                fixed.append(tc)
            msg["tool_calls"] = fixed

        out.append(msg)
    return out


# ── Responses API helpers ──────────────────────────────────────────────────────


def _responses_content(content: Any) -> str | list[dict[str, Any]]:
    """Convert chat-style text/image parts into Responses API content."""
    if isinstance(content, str):
        return content
    if not isinstance(content, list):
        return json.dumps(content, ensure_ascii=False)

    converted: list[dict[str, Any]] = []
    for part in content:
        if not isinstance(part, dict):
            converted.append({"type": "input_text", "text": str(part)})
            continue
        part_type = part.get("type")
        if part_type == "text":
            converted.append({"type": "input_text", "text": str(part.get("text") or "")})
            continue
        if part_type == "image_url":
            image_url = part.get("image_url")
            if isinstance(image_url, dict):
                url = str(image_url.get("url") or "")
                detail = image_url.get("detail")
            else:
                url = str(image_url or "")
                detail = None
            item: dict[str, Any] = {"type": "input_image", "image_url": url}
            if detail:
                item["detail"] = detail
            converted.append(item)
            continue
        converted.append({"type": "input_text", "text": json.dumps(part, ensure_ascii=False)})
    return converted


def _responses_input(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert chat-style messages to Responses API input items.

    - tool messages → function_call_output (preserves call_id for multi-turn)
    - assistant + tool_calls → function_call items (fixes "no tool call found" errors)
    """
    items: list[dict[str, Any]] = []
    for msg in _sanitize_messages(messages):
        role = msg.get("role", "user")
        content = _responses_content(msg.get("content") or "")

        if role == "tool":
            items.append(
                {
                    "type": "function_call_output",
                    "call_id": msg.get("tool_call_id", ""),
                    "output": content,
                }
            )
            continue

        if role not in {"system", "user", "assistant"}:
            role = "user"

        if role == "assistant" and msg.get("tool_calls"):
            # Emit text content first (reasoning preamble from gpt-5.4 etc.),
            # then function_call items — Responses API supports this ordering.
            if content and isinstance(content, str):
                items.append({"role": "assistant", "content": content})
            for tc in msg["tool_calls"]:
                fn = tc.get("function", {})
                args = fn.get("arguments", "{}")
                items.append(
                    {
                        "type": "function_call",
                        "call_id": tc.get("id", ""),
                        "name": fn.get("name", ""),
                        "arguments": args if isinstance(args, str) else json.dumps(args),
                    }
                )
            continue

        items.append({"role": role, "content": content})

    return items


def _responses_tools(tools: list[dict[str, Any]] | None) -> list[dict[str, Any]] | None:
    if not tools:
        return None
    converted = []
    for tool in tools:
        if tool.get("type") != "function":
            continue
        fn = tool.get("function", {})
        converted.append(
            {
                "type": "function",
                "name": fn.get("name", ""),
                "description": fn.get("description", ""),
                "parameters": fn.get("parameters", {"type": "object", "properties": {}}),
            }
        )
    return converted


# ── Provider ───────────────────────────────────────────────────────────────────


class OpenAIProvider(LLMProvider):
    """Unified provider for GitHub Copilot, OpenAI, and Azure OpenAI.

    Routing logic:
    - github/gpt-*, github_copilot/gpt-*       → Responses API
    - github/claude-*, github_copilot/claude-* → Chat Completions on Copilot
      (Copilot does not expose Anthropic's /v1/messages endpoint)
    - *-codex, gpt-5.x-pro                     → Responses API (all providers)
    - everything else                           → Chat Completions
      - on unsupported_api_for_model error      → automatic fallback to Responses API
    """

    def __init__(self, providers: ProvidersConfig | None = None) -> None:
        self._providers = providers or ProvidersConfig()
        self._usage: TokenUsageTracker | None = None
        self._client_cache: dict[tuple[Any, ...], Any] = {}
        self._close_lock = asyncio.Lock()

    def set_usage_tracker(self, tracker: TokenUsageTracker) -> None:
        """Attach a token usage tracker for cost monitoring."""
        self._usage = tracker

    async def aclose(self) -> None:
        """Close every cached HTTP client and clear the cache."""
        async with self._close_lock:
            clients = list({id(client): client for client in self._client_cache.values()}.values())
            for client in clients:
                closed = False
                for attempt in range(_CLOSE_ATTEMPTS):
                    try:
                        await client.close()
                    except Exception as exc:
                        logger.warning(
                            "Failed to close LLM HTTP client (attempt {}/{}): {}",
                            attempt + 1,
                            _CLOSE_ATTEMPTS,
                            exc,
                        )
                    else:
                        closed = True
                        break
                if not closed:
                    continue
                stale_keys = [key for key, cached in self._client_cache.items() if cached is client]
                for key in stale_keys:
                    self._client_cache.pop(key, None)

    # ── Request building ───────────────────────────────────────────────────────

    def _build_kwargs(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> tuple[str, dict[str, Any], dict[str, Any]]:
        """Return (resolved_model, req_kwargs, creds)."""
        resolved_model = model
        creds = resolve_credentials(resolved_model, self._providers)
        model_name = _api_model_name(resolved_model)

        req_kwargs: dict[str, Any] = {
            "model": model_name,
            "messages": _sanitize_messages(messages),
        }
        api_key = creds.get("api_key")
        if resolved_model.startswith(("github/", "github_copilot/")) and api_key:
            request_headers = dict(creds.get("extra_headers") or {})
            request_headers["Authorization"] = f"Bearer {api_key}"
            req_kwargs["extra_headers"] = request_headers

        # Temperature: suppressed for reasoning models (nanobot pattern)
        if temperature is not None and _supports_temperature(model_name, reasoning_effort):
            req_kwargs["temperature"] = temperature

        # max_tokens → max_completion_tokens for gpt-5.x / o-series
        if max_tokens is not None:
            param = "max_completion_tokens" if _uses_completion_tokens(model_name) else "max_tokens"
            req_kwargs[param] = max_tokens

        if tools:
            req_kwargs["tools"] = tools

        # reasoning_effort for chat/completions (gpt-5.x, o-series)
        # Clamp to a value the model accepts (some models reject "high" etc.).
        clamped_effort = _clamp_reasoning_effort(model_name, reasoning_effort)
        if clamped_effort and clamped_effort != "none":
            req_kwargs["reasoning_effort"] = clamped_effort

        return resolved_model, req_kwargs, creds

    def _build_client(self, resolved_model: str, creds: dict[str, Any]) -> Any:
        from openai import AsyncAzureOpenAI, AsyncOpenAI

        api_key = creds.get("api_key")
        if not api_key:
            raise ValueError(f"Missing API key for model '{resolved_model}'")

        api_base: str | None = creds.get("api_base")
        api_version: str | None = creds.get("api_version")
        extra_headers = creds.get("extra_headers")
        headers_key = (
            tuple(sorted(extra_headers.items()))
            if isinstance(extra_headers, dict)
            else extra_headers
        )
        is_copilot = resolved_model.startswith(("github/", "github_copilot/"))
        if is_copilot:
            cache_key: tuple[Any, ...] = (_COPILOT_TRANSPORT_API_KEY,)
            transport_client = self._client_cache.get(cache_key)
            if transport_client is None:
                transport_client = AsyncOpenAI(
                    api_key=_COPILOT_TRANSPORT_API_KEY,
                    base_url=api_base,
                )
                self._client_cache[cache_key] = transport_client
            return transport_client.with_options(base_url=api_base)

        client_kind = "azure" if resolved_model.startswith(("azure/", "azure_ai/")) else "openai"
        cache_key = (client_kind, api_base, api_version, headers_key, api_key)

        if cache_key in self._client_cache:
            return self._client_cache[cache_key]

        client: AsyncAzureOpenAI | AsyncOpenAI
        if client_kind == "azure":
            if not api_base:
                raise ValueError("Azure OpenAI / Azure AI Foundry requires endpoint (api_base)")
            client = AsyncAzureOpenAI(
                api_key=api_key,
                azure_endpoint=api_base,
                api_version=api_version or "2024-10-21",
                default_headers=extra_headers,
            )
        else:
            client = AsyncOpenAI(
                api_key=api_key,
                base_url=api_base,
                default_headers=extra_headers,
            )

        self._client_cache[cache_key] = client
        return client

    # ── Response parsing ───────────────────────────────────────────────────────

    @staticmethod
    def _parse_chat_tool_calls(message: Any) -> list[ToolCallRequest]:
        if not getattr(message, "tool_calls", None):
            return []
        tool_calls = []
        for tc in message.tool_calls:
            args = tc.function.arguments
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {"raw": args}
            tool_calls.append(
                ToolCallRequest(
                    id=tc.id,
                    name=tc.function.name,
                    arguments=args,
                )
            )
        return tool_calls

    @staticmethod
    def _merge_choices(response: Any) -> tuple[str, list[ToolCallRequest], str]:
        """Merge content and tool_calls across all choices (nanobot pattern).

        choices[0] is authoritative for content and finish_reason.
        Content from other choices is only used if choices[0] has none.
        Tool calls are merged from ALL choices (GitHub Copilot may split them).
        """
        if not response.choices:
            return "", [], "stop"

        primary = response.choices[0]
        content: str = primary.message.content or ""
        finish_reason: str = primary.finish_reason or "stop"

        # Dedupe tool calls by id while merging across choices. Some
        # backends (notably GitHub Copilot fronting Claude on Vertex)
        # occasionally return the *same* tool_call replicated across
        # multiple choices instead of splitting *different* calls. If we
        # forwarded both, the next turn would attach two ``tool_result``
        # blocks with the same ``toolu_vrtx_*`` id, which the Anthropic
        # /v1/messages endpoint rejects with 400 "each tool_use must have
        # a single result".
        all_tool_calls: list[ToolCallRequest] = []
        seen_ids: set[str] = set()
        duplicates = 0
        for choice in response.choices:
            tcs = OpenAIProvider._parse_chat_tool_calls(choice.message)
            for tc in tcs:
                if tc.id and tc.id in seen_ids:
                    duplicates += 1
                    continue
                if tc.id:
                    seen_ids.add(tc.id)
                all_tool_calls.append(tc)
            if not content and choice.message.content:
                content = choice.message.content
            if tcs and choice.finish_reason == "tool_calls":
                finish_reason = "tool_calls"

        if all_tool_calls and finish_reason != "tool_calls":
            finish_reason = "tool_calls"

        if len(response.choices) > 1:
            logger.debug(
                "Chat response has {} choices, merged {} tool_calls ({} duplicate id(s) dropped)",
                len(response.choices),
                len(all_tool_calls),
                duplicates,
            )
        elif duplicates:
            logger.debug(
                "Chat response: {} duplicate tool_call id(s) dropped from single choice",
                duplicates,
            )

        return content, all_tool_calls, finish_reason

    @staticmethod
    def _parse_responses_result(
        response: Any,
    ) -> tuple[str, list[ToolCallRequest], str | None, int, int]:
        """Parse Responses API result.

        Returns (content, tool_calls, reasoning_content, prompt_tokens, completion_tokens).
        reasoning_content captures thinking blocks from gpt-5.4 / DeepSeek-R1 etc.
        """
        content: str = getattr(response, "output_text", "") or ""
        tool_calls: list[ToolCallRequest] = []
        reasoning_parts: list[str] = []

        for item in getattr(response, "output", []) or []:
            item_type = getattr(item, "type", None)

            if item_type == "function_call":
                raw_args = getattr(item, "arguments", "{}") or "{}"
                if isinstance(raw_args, str):
                    try:
                        args = json.loads(raw_args)
                    except json.JSONDecodeError:
                        args = {"raw": raw_args}
                else:
                    args = raw_args
                tool_calls.append(
                    ToolCallRequest(
                        id=str(
                            getattr(item, "call_id", None)
                            or getattr(item, "id", None)
                            or "function_call"
                        ),
                        name=getattr(item, "name", ""),
                        arguments=args,
                    )
                )

            elif item_type == "reasoning":
                # Preserve reasoning/thinking content (gpt-5.4, encrypted_content etc.)
                for part in getattr(item, "content", []) or []:
                    part_type = getattr(part, "type", None)
                    if part_type in ("thinking", "text"):
                        text = getattr(part, "thinking", None) or getattr(part, "text", "")
                        if text:
                            reasoning_parts.append(text)

            elif item_type == "message" and not content:
                texts: list[str] = []
                for part in getattr(item, "content", []) or []:
                    if getattr(part, "type", None) in ("output_text", "text"):
                        text = getattr(part, "text", "")
                        if text:
                            texts.append(text)
                if texts:
                    content = "".join(texts)

        reasoning_content: str | None = "\n".join(reasoning_parts) if reasoning_parts else None

        usage = getattr(response, "usage", None)
        prompt_tokens = (
            int(getattr(usage, "input_tokens", 0) or getattr(usage, "prompt_tokens", 0) or 0)
            if usage
            else 0
        )
        completion_tokens = (
            int(getattr(usage, "output_tokens", 0) or getattr(usage, "completion_tokens", 0) or 0)
            if usage
            else 0
        )

        return content, tool_calls, reasoning_content, prompt_tokens, completion_tokens

    # ── Responses API call ─────────────────────────────────────────────────────

    async def _complete_via_responses(
        self,
        *,
        client: Any,
        resolved_model: str,
        req_kwargs: dict[str, Any],
    ) -> LLMResponse:
        resp_kwargs: dict[str, Any] = {
            "model": req_kwargs["model"],
            "input": _responses_input(req_kwargs["messages"]),
        }
        if "temperature" in req_kwargs:
            resp_kwargs["temperature"] = req_kwargs["temperature"]

        # max_completion_tokens / max_tokens → max_output_tokens
        if "max_completion_tokens" in req_kwargs:
            resp_kwargs["max_output_tokens"] = req_kwargs["max_completion_tokens"]
        elif "max_tokens" in req_kwargs:
            resp_kwargs["max_output_tokens"] = req_kwargs["max_tokens"]

        # reasoning_effort → {"effort": ...} on Responses API
        if "reasoning_effort" in req_kwargs:
            resp_kwargs["reasoning"] = {"effort": req_kwargs["reasoning_effort"]}
        if "extra_headers" in req_kwargs:
            resp_kwargs["extra_headers"] = req_kwargs["extra_headers"]

        converted_tools = _responses_tools(req_kwargs.get("tools"))
        if converted_tools:
            resp_kwargs["tools"] = converted_tools

        start = time.monotonic()
        response = await client.responses.create(**resp_kwargs)
        elapsed_ms = (time.monotonic() - start) * 1000

        content, tool_calls, reasoning_content, prompt_tokens, completion_tokens = (
            self._parse_responses_result(response)
        )

        return LLMResponse(
            content=content,
            tool_calls=tool_calls,
            finish_reason="tool_calls" if tool_calls else "stop",
            model=getattr(response, "model", None) or resolved_model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            duration_ms=elapsed_ms,
            reasoning_content=reasoning_content,
        )

    # ── Public API ─────────────────────────────────────────────────────────────

    async def complete(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> LLMResponse:
        candidate_models = resolve_model_chain(model, self._providers)
        if not candidate_models:
            raise ValueError(
                f"No model candidates resolved for alias '{model}'. "
                "Configure GITHUB_COPILOT_TOKEN or OPENAI_API_KEY."
            )

        result: LLMResponse | None = None
        resolved_model = model
        last_error: Exception | None = None

        for idx, candidate in enumerate(candidate_models):
            resolved_model, req_kwargs, creds = self._build_kwargs(
                model=candidate,
                messages=messages,
                tools=tools,
                temperature=temperature,
                max_tokens=max_tokens,
                reasoning_effort=reasoning_effort,
            )
            try:
                client = self._build_client(resolved_model, creds)

                if _should_prefer_responses_api(resolved_model):
                    result = await self._complete_via_responses(
                        client=client,
                        resolved_model=resolved_model,
                        req_kwargs=req_kwargs,
                    )
                else:
                    try:
                        start = time.monotonic()
                        response = await client.chat.completions.create(**req_kwargs)
                        elapsed_ms = (time.monotonic() - start) * 1000

                        content, tool_calls, finish_reason = self._merge_choices(response)
                        usage = response.usage
                        result = LLMResponse(
                            content=content,
                            tool_calls=tool_calls,
                            finish_reason=finish_reason,
                            model=resolved_model,
                            prompt_tokens=usage.prompt_tokens if usage else 0,
                            completion_tokens=usage.completion_tokens if usage else 0,
                            duration_ms=elapsed_ms,
                        )
                    except Exception as exc:
                        if _is_chat_unsupported_error(exc):
                            logger.warning(
                                "Model '{}' does not support /chat/completions; "
                                "switching to Responses API",
                                resolved_model,
                            )
                            result = await self._complete_via_responses(
                                client=client,
                                resolved_model=resolved_model,
                                req_kwargs=req_kwargs,
                            )
                        else:
                            raise

                if idx > 0:
                    logger.warning(
                        "LLM fallback succeeded: '{}' -> '{}'",
                        candidate_models[0],
                        resolved_model,
                    )
                break

            except Exception as exc:
                last_error = exc
                logger.error("LLM error ({}): {}", resolved_model, exc)
                if idx < len(candidate_models) - 1:
                    logger.warning(
                        "Retrying LLM with fallback model '{}' after '{}' failed",
                        candidate_models[idx + 1],
                        resolved_model,
                    )

        if result is None:
            if last_error is not None:
                raise last_error
            raise RuntimeError("LLM completion failed without an exception")

        logger.debug(
            "LLM {}: {}+{} tokens, {:.0f}ms, {} tool calls{}",
            resolved_model,
            result.prompt_tokens,
            result.completion_tokens,
            result.duration_ms,
            len(result.tool_calls),
            " [reasoning]" if result.reasoning_content else "",
        )

        if self._usage:
            self._usage.record(
                model=resolved_model,
                prompt_tokens=result.prompt_tokens,
                completion_tokens=result.completion_tokens,
                duration_ms=result.duration_ms,
            )

        return result

    async def stream(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> AsyncIterator[LLMChunk]:
        candidate_models = resolve_model_chain(model, self._providers)
        if not candidate_models:
            raise ValueError(
                f"No model candidates resolved for alias '{model}'. "
                "Configure GITHUB_COPILOT_TOKEN or OPENAI_API_KEY."
            )

        last_error: Exception | None = None

        for idx, candidate in enumerate(candidate_models):
            resolved_model, req_kwargs, creds = self._build_kwargs(
                model=candidate,
                messages=messages,
                tools=tools,
                temperature=temperature,
                max_tokens=max_tokens,
                reasoning_effort=reasoning_effort,
            )

            try:
                client = self._build_client(resolved_model, creds)

                if _should_prefer_responses_api(resolved_model):
                    # Responses API is non-streaming: complete then yield
                    result = await self._complete_via_responses(
                        client=client,
                        resolved_model=resolved_model,
                        req_kwargs=req_kwargs,
                    )
                    if self._usage:
                        self._usage.record(
                            model=resolved_model,
                            prompt_tokens=result.prompt_tokens,
                            completion_tokens=result.completion_tokens,
                            duration_ms=result.duration_ms,
                        )
                    if result.content:
                        yield LLMChunk(
                            content=result.content,
                            finish_reason="stop",
                            model=result.model,
                        )
                    return

                try:
                    response = await client.chat.completions.create(**req_kwargs, stream=True)
                except Exception as exc:
                    if _is_chat_unsupported_error(exc):
                        logger.warning(
                            "Model '{}' does not support /chat/completions; "
                            "switching to Responses API",
                            resolved_model,
                        )
                        result = await self._complete_via_responses(
                            client=client,
                            resolved_model=resolved_model,
                            req_kwargs=req_kwargs,
                        )
                        if self._usage:
                            self._usage.record(
                                model=resolved_model,
                                prompt_tokens=result.prompt_tokens,
                                completion_tokens=result.completion_tokens,
                                duration_ms=result.duration_ms,
                            )
                        if result.content:
                            yield LLMChunk(
                                content=result.content,
                                finish_reason="stop",
                                model=result.model,
                            )
                        return
                    raise

                emitted_any = False
                try:
                    async for chunk in response:
                        if not chunk.choices:
                            continue
                        emitted_any = True
                        choice = chunk.choices[0]
                        delta = choice.delta
                        yield LLMChunk(
                            content=delta.content or "",
                            finish_reason=choice.finish_reason,
                            model=resolved_model,
                        )
                    if idx > 0:
                        logger.warning(
                            "LLM stream fallback succeeded: '{}' -> '{}'",
                            candidate_models[0],
                            resolved_model,
                        )
                    return
                except Exception as exc:
                    last_error = exc
                    logger.error("LLM stream iteration error ({}): {}", resolved_model, exc)
                    if emitted_any or idx >= len(candidate_models) - 1:
                        raise
                    logger.warning(
                        "Retrying stream with fallback model '{}' after early "
                        "stream failure in '{}'",
                        candidate_models[idx + 1],
                        resolved_model,
                    )

            except Exception as exc:
                last_error = exc
                logger.error("LLM stream error ({}): {}", resolved_model, exc)
                if idx < len(candidate_models) - 1:
                    logger.warning(
                        "Retrying stream with fallback model '{}' after '{}' failed",
                        candidate_models[idx + 1],
                        resolved_model,
                    )
                    continue
                raise

        if last_error is not None:
            raise last_error
        raise RuntimeError("LLM stream failed without an exception")
