"""Small shared coercion/capping helpers for workflow capability limits (Task 9).

Public so cron/service, host/background_tasks, and agent/tools/workflow all share
one implementation instead of importing each other's private ``_`` helpers or
duplicating them.
"""

from __future__ import annotations

from typing import Any


def positive_int(value: Any) -> int | None:
    """Coerce ``value`` to a positive int, else ``None`` (``bool`` rejected).

    A FRACTIONAL float (e.g. ``1.9``) is rejected rather than silently truncated —
    a limit should be an exact integer, so an ambiguous value applies *no* cap
    rather than a surprising one. Whole floats (``600.0``) and int-like strings
    (``"600"``) are accepted. Non-coercible / non-positive values return ``None``.
    """
    if isinstance(value, bool):
        return None
    if isinstance(value, float) and not value.is_integer():
        return None  # fractional / inf / nan → no cap (int() would truncate or raise)
    try:
        n = int(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return n if n > 0 else None


def cap_output(text: str, limit: int | None) -> str:
    """Truncate ``text`` so the returned string is a STRICT bound of ``limit`` chars.

    No-op when there's no positive limit, the input isn't a string, or it already
    fits. Otherwise reserves room for a visible marker so ``len(result) <= limit``
    exactly (for a limit too small to hold the marker, hard-truncates to ``limit``
    with no marker). Bounds a workflow run's delivered output (``limits.max_output``).
    """
    if not isinstance(text, str) or limit is None or limit <= 0 or len(text) <= limit:
        return text
    marker = f"\n… [truncated to {limit} chars by workflow limit]"
    if limit <= len(marker):
        return text[:limit]  # too small for a marker — hard truncate to the bound
    return text[: limit - len(marker)] + marker
